# GuardMan Admin — Sesión de Testing y Bugfixing

**Fecha:** 2026-05-08 (extensión de sesión de mejoras de medios)  
**Worker URL:** https://guardman.oficinadesarrollo33.workers.dev  
**Version ID desplegada:** `b637c0cb-d911-4674-88d0-aad5d9d73bd6`

---

## Resumen Ejecutivo

Se realizó testing exhaustivo del proyecto completo tras la sesión de mejoras de medios/CMS. Se ejecutaron **39 tests** contra el backend en producción, el SSR renderizado, el build frontend y el type-checking de TypeScript. Se detectaron **3 bugs**, los 3 fueron corregidos y desplegados exitosamente.

---

## 1. Metodología de Testing

Las pruebas se organizaron en las siguientes capas:

| Capa | Tests | Herramienta |
|------|-------|-------------|
| API Backend (endpoints en vivo) | 15 tests | `curl` contra worker de producción |
| SSR (páginas renderizadas) | 8 tests | `curl` + inspección HTML |
| Frontend Build | 2 tests | `vite build` + `tsc --noEmit` |
| CSP / Seguridad | 1 test | Inspección de headers HTTP |
| R2 Asset Serving | 3 tests | `curl -I` contra paths R2 |
| Cache / KV | 2 tests | Verificación de headers `X-Cache` |
| Integración (YT embed) | 4 tests | Búsqueda de `data-yt` en HTML |
| Consistencia build/deploy | 2 tests | Comparación de hashes |
| Búsqueda/filtros | 2 tests | Query params en API |

---

## 2. Tests Ejecutados — Detalle Completo

### 2.1 API Backend — Media Library

| # | Test | Endpoint | Resultado | Detalle |
|---|------|----------|-----------|---------|
| 1 | Health check | `GET /api/media` | ✅ 200 | Responde correctamente |
| 2 | Listar biblioteca | `GET /api/media` | ✅ | 27 items, estructura `{ok, data, total}` correcta |
| 3 | Obtener por ID (YouTube) | `GET /api/media/27` | ✅ | Incluye `entities`, `youtube_id`, `thumbnail_key` |
| 4 | Image map completa | `GET /api/media/map` | ✅ | Estructura `entity_type → slug → usage → {key, alt}` |
| 5 | YouTube URL inválida | `POST /api/media/youtube` | ✅ 400 | `"Invalid YouTube URL"` |
| 6 | YouTube duplicado | `POST /api/media/youtube` | ✅ 409 | `"Este video de YouTube ya existe en la biblioteca"` |
| 7 | Media ID inexistente | `GET /api/media/99999` | ✅ 404 | `"Not found"` |
| 8 | Delete inexistente | `DELETE /api/media/99999` | ✅ 404 | `"Not found"` |
| 9 | Filtro por categoría | `GET /api/media?category=hero` | ✅ | Solo items con `category=hero` |
| 10 | Actualizar metadata | `PUT /api/media/27` | ✅ 200 | `{"ok":true}` |
| 11 | Persistencia de PUT | `GET /api/media/27` | ✅ | `title: "Test Title"`, `caption: "Test caption"` visibles |
| 12 | Restaurar datos | `PUT /api/media/27` | ✅ | Valores restaurados a vacíos |
| 31 | Filtro por entity | `GET /api/media?entity_type=service&entity_slug=auditoria-seguridad&usage=hero` | ✅ | Retorna el video YouTube asignado |
| 38 | Búsqueda textual | `GET /api/media?q=hero` | ✅ | Filtra por filename, alt_text, tags |
| 39 | Total count | `GET /api/media` | ✅ | `total: 27` correcto |

### 2.2 SSR — Páginas Públicas

| # | Test | URL | Resultado | Detalle |
|---|------|-----|-----------|---------|
| 13 | Home | `/` | ✅ 200 | 39,451 bytes, 1.98s |
| 14 | Servicio auditoria-seguridad | `/servicios/auditoria-seguridad` | ✅ 200 | 27,849 bytes, 5.06s |
| 15 | Admin panel | `/admin/` | ✅ 200 | 452 bytes (SPA) |
| 16 | Guard Pod | `/servicios/guard-pod` | ✅ 200 | 30,098 bytes, 2.62s |
| 17 | YouTube data-yt en auditoria (pre-fix) | `/servicios/auditoria-seguridad` | ❌ | Sin `data-yt` → **BUG 2** |
| 18 | YT_LITE_SCRIPT presente | `/servicios/auditoria-seguridad` | ✅ | Script de activación por click inyectado |
| 26 | YouTube data-yt en ajax-systems | `/ajax-systems` | ✅ | `data-yt="XZsDWxHdgP4"` (2 instancias) |
| 29 | Bloque yt-lite HTML completo | `/ajax-systems` | ✅ | Estructura con aria-label, poster, play btn, watermark |

### 2.3 Seguridad / Headers

| # | Test | Resultado | Detalle |
|---|------|-----------|---------|
| 19 | CSP headers | ✅ | `img-src` incluye `img.youtube.com`, `*.ytimg.com`; `frame-src https://www.youtube.com` |

**CSP completa verificada:**
```
default-src 'self';
script-src 'self' 'unsafe-inline' https://unpkg.com;
style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com;
img-src 'self' data: https://guardman.cl https://staticmap.openstreetmap.de https://*.tile.openstreetmap.org https://img.youtube.com https://*.ytimg.com;
font-src 'self' https://fonts.gstatic.com;
connect-src 'self';
frame-src https://www.youtube.com;
frame-ancestors 'none';
```

### 2.4 R2 Asset Serving

| # | Test | Path | Resultado | Detalle |
|---|------|------|-----------|---------|
| 22 | Imagen WebP | `/images/hero-home.webp` | ✅ 200 | `Content-Type: image/webp`, cache immutable |
| 21 | YouTube thumbnail (pre-fix) | `/thumbnails/yt-XZsDWxHdgP4.jpg` | ❌ 404 | **BUG 1** |
| 35 | YouTube thumbnail (post-fix) | `/thumbnails/yt-XZsDWxHdgP4.jpg` | ✅ 200 | `Content-Type: image/jpeg` |

### 2.5 Frontend Build

| # | Test | Resultado | Detalle |
|---|------|-----------|---------|
| Build Vite | ✅ | 46 módulos, 376.99 KB JS + 92.46 KB CSS, 2.49s |
| TypeScript `tsc --noEmit` (pre-fix) | ❌ | 3 errores en `CMSPage.tsx` → **BUG 3** |
| TypeScript `tsc --noEmit` (post-fix) | ✅ | 0 errores |

### 2.6 Consistencia Build/Deploy

| # | Test | Resultado | Detalle |
|---|------|-----------|---------|
| 32 | Admin HTML | ✅ | `<script src="/admin/assets/main-DVXWu0jx.js">` correcto |
| 33 | Admin JS asset | ✅ | 200, `CF-Cache-Status: HIT` |
| 36 | Hashes locales vs deploy | ✅ | `main-DVXWu0jx.js` y `main-DLsSXpv4.css` coinciden |

---

## 3. Bugs Encontrados

### 🐛 BUG 1: R2 no sirve `/thumbnails/` ni `/videos/` [CRÍTICO]

**Detectado en:** Test #21  
**Síntoma:** `GET /thumbnails/yt-XZsDWxHdgP4.jpg` retorna HTTP 404  
**Root cause:** En `src/index.ts`, el handler de R2 assets (línea 168) solo tenía routing para `path.startsWith('/images/')`. Las rutas `/thumbnails/` y `/videos/` no tenían handler → caían al fallback `ASSETS.fetch()` que no las encontraba.

**Impacto:**
- Los thumbnails de YouTube guardados en R2 no se servían
- El `thumbnail_key` existía en la base de datos pero la URL era inaccesible
- El componente `LiteYouTube` usaba directamente URLs de `img.youtube.com` (funcionaba), pero el thumbnail descargado y guardado en R2 era inútil

**Archivo afectado:** `src/index.ts`

**Fix aplicado:**
```typescript
// ANTES:
if (path.startsWith('/images/')) {

// DESPUÉS:
if (path.startsWith('/images/') || path.startsWith('/videos/') || path.startsWith('/thumbnails/')) {
```

**Validación:** `GET /thumbnails/yt-XZsDWxHdgP4.jpg` → HTTP 200, `Content-Type: image/jpeg` ✅

---

### 🐛 BUG 2: Hero no soporta `yt:` en páginas de servicio [MEDIO]

**Detectado en:** Tests #17, #24  
**Síntoma:** La página `/servicios/auditoria-seguridad` no mostraba el YouTube embed a pesar de tener un video asignado en `media_entities`  
**Root cause — dos problemas combinados:**

1. **`fetchServicePage()` en `src/ssr/site-data.ts`:** La resolución de `heroImage` usaba `s.hero_image` (columna de la tabla `services` en D1) como prioridad. Si esa columna tenía un valor (path a imagen estática), el fallback a `media_entities` nunca se ejecutaba. La prioridad era: `DB column → content_json → media_entities → default`.

2. **`hero()` en `src/ssr/site-renderer.ts`:** La función genérica de hero solo renderizaba `<img src="...">`. No usaba `renderMedia()`, por lo que si `heroImage` era `yt:VIDEO_ID`, se renderizaba como atributo `src` de una imagen (inválido).

**Impacto:**
- El video YouTube asignado al servicio "auditoria-seguridad" via CMS/ImagePicker no se mostraba en su página pública
- Solo las páginas estáticas (ajax-systems) con `buildAjaxBody()` usaban `renderMedia()` correctamente

**Archivos afectados:** `src/ssr/site-renderer.ts`, `src/ssr/site-data.ts`

**Fix 1 — `hero()` soporta `yt:`:**
```typescript
// ANTES:
function hero(d: SiteData): string {
  return `<section class="hero" ...>
    <div class="hero-bg"><img src="${esc(d.heroImage||'...')}"></div>...`;
}

// DESPUÉS:
function hero(d: SiteData): string {
  const heroImg = d.heroImage || '/images/hero-home.webp';
  const isYt = heroImg.startsWith('yt:');
  const heroBg = isYt
    ? `<div class="hero-bg" style="aspect-ratio:16/9;background:transparent">${renderMedia(heroImg, d.heroHeading, '')}</div>`
    : `<div class="hero-bg"><img src="${esc(heroImg)}"...`;
  // ...
}
```

**Fix 2 — Priorizar `media_entities` sobre columna DB:**
```typescript
// ANTES (prioridad invertida):
let heroImage = s.hero_image || sections.hero?.image || '';
if (!heroImage && mediaEntity) { ... }

// DESPUÉS (media_entities tiene prioridad):
let heroImage = '';
if (mediaEntity) {
  const me = mediaEntity as any;
  heroImage = me.youtube_id ? `yt:${me.youtube_id}` : (me.key ? `/${me.key}` : '');
}
if (!heroImage) heroImage = s.hero_image || sections.hero?.image || '';
```

**Fix 3 — Query a `media_entities` en `fetchServicePage`:**
```typescript
// Agregado al Promise.all:
env.DB.prepare(
  `SELECT m.key, m.media_type, m.youtube_id
   FROM media_entities me
   JOIN media_library m ON me.media_id = m.id
   WHERE me.entity_type = 'service'
   AND me.entity_slug = ?
   AND me.usage = 'hero'
   LIMIT 1`
).bind(slug).first()
```

**Validación:** `GET /servicios/auditoria-seguridad` contiene `data-yt="XZsDWxHdgP4"` ✅

---

### 🐛 BUG 3: 3 errores TypeScript en `CMSPage.tsx` [BAJO]

**Detectado en:** `tsc --noEmit`  
**Impacto:** Sin impacto en runtime (Vite no hace type-check estricto), pero types incorrectos que podían causar confusión o errores futuros.

**3 errores específicos:**

| Línea | Error | Causa |
|-------|-------|-------|
| 423 | `setContent()` recibe objeto sin `slug`, `type`, `last_modified`, `related_content` | `CMSContent` requería campos que el contenido estático no proporcionaba |
| 433 | `seo` falta propiedad `canonical` | `seo.canonical` era requerido pero nunca se enviaba para páginas estáticas |
| 852 | `type: 'static'` no es parte del union type | `ContentItem.type` no incluía `'static'` |

**Archivo afectado:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

**Fix aplicado:**
```typescript
// ANTES:
interface ContentItem {
  type: 'service' | 'location' | 'sector' | 'combo' | 'home';
}
interface CMSContent {
  slug: string;                    // requerido
  type: string;                    // requerido
  last_modified: string;           // requerido
  seo: { title: string; description: string; canonical: string };  // canonical requerido
  related_content: any;            // requerido
}

// DESPUÉS:
interface ContentItem {
  type: 'service' | 'location' | 'sector' | 'combo' | 'home' | 'static';
}
interface CMSContent {
  slug?: string;                   // opcional
  type?: string;                   // opcional
  last_modified?: string;          // opcional
  seo: { title: string; description: string; canonical?: string };  // canonical opcional
  related_content?: any;           // opcional
}

// Tipado explícito en setSelectedItem:
const item: ContentItem = { slug, type: 'static', ... };
```

**Validación:** `tsc --noEmit` → 0 errores ✅

---

## 4. Archivos Modificados

| Archivo | Cambio | Líneas aprox. |
|---------|--------|---------------|
| `src/index.ts` | Handler R2 ampliado a `/thumbnails/` y `/videos/` | ~5 líneas |
| `src/ssr/site-renderer.ts` | `hero()` soporta `yt:` via `renderMedia()` | ~10 líneas |
| `src/ssr/site-data.ts` | `fetchServicePage()` consulta `media_entities` y prioriza YouTube | ~15 líneas |
| `guardman-admin-ui/src/components/CMS/CMSPage.tsx` | Types `ContentItem` y `CMSContent` corregidos | ~10 líneas |

---

## 5. Deploys Realizados

| # | Version ID | Motivo | Tiempo |
|---|-----------|--------|--------|
| 1 | `ba9c1e4d-82ad-486d-a581-34e077a14aa7` | Fix BUG 1 + BUG 2 (primera versión) | 50.97s upload |
| 2 | `b637c0cb-d911-4674-88d0-aad5d9d73bd6` | Fix BUG 2 (prioridad media_entities corregida) | 145.10s upload |

**Nota:** Se requirió un segundo deploy porque BUG 2 tenía una lógica de prioridad invertida: `services.hero_image` (columna D1 con valor existente) impedía que `media_entities` se usara como fuente. Se invirtió la prioridad para que `media_entities` (que contiene la asignación explícita del usuario via CMS) tome precedencia.

---

## 6. Problema de Cache CDN

**Situación:** Tras el primer deploy del fix BUG 2, la página `/servicios/auditoria-seguridad` seguía mostrando el HTML anterior sin `data-yt`.

**Diagnóstico:**
- El header `X-Cache: HIT` indicaba que la respuesta venía de cache
- La purge de KV (`POST /api/cms/rebuild`) vació KV correctamente (verificado con `wrangler kv key list` → `[]`)
- Pero el header `CDN-Cache-Control: public, max-age=86400` cachea en el edge de Cloudflare por 24 horas
- La cache CDN no se puede purgar desde wrangler sin credenciales API de Cloudflare

**Resolución:** Tras el segundo deploy (nuevo version ID), Cloudflare CDN sirvió la nueva versión automáticamente, ya que cada deploy genera una nueva versión del worker.

**Lección aprendida:** Considerar agregar un endpoint de purge CDN o reducir `CDN-Cache-Control` para páginas de servicios que pueden cambiar frecuentemente.

---

## 7. Validación Final Post-Fix

```
FIX 1 - R2 thumbnails:       ✅ HTTP 200, Content-Type: image/jpeg
FIX 1b - R2 imágenes:        ✅ HTTP 200, Content-Type: image/webp  
FIX 2 - YouTube hero servicio: ✅ data-yt="XZsDWxHdgP4" presente
FIX 2b - YouTube hero ajax:   ✅ data-yt="XZsDWxHdgP4" (2 instancias, no roto)
FIX 3 - TypeScript:           ✅ 0 errores
BUILD frontend:               ✅ 46 módulos, 2.49s
```

---

## 8. Estado del Proyecto

### Funcionalidades Operativas

- ✅ Upload de imágenes (JPEG, PNG, WebP, GIF, SVG) hasta 10MB
- ✅ Upload de video (MP4, WebM) hasta 50MB
- ✅ YouTube: agregar por URL, thumbnail automático, título vía oEmbed
- ✅ Lite YouTube embed (0KB hasta click del usuario)
- ✅ Generación de imágenes con IA (fal.ai flux-schnell/pro)
- ✅ SEO por imagen: alt_text, title, caption, tags, score
- ✅ Sincronización bidireccional Media Library ↔ CMS
- ✅ R2 serving para images, videos y thumbnails
- ✅ YouTube hero en páginas de servicio y estáticas
- ✅ CSP permite YouTube thumbnails + iframes
- ✅ TypeScript limpio (0 errores)
- ✅ Build frontend sin warnings

### Métricas

| Métrica | Valor |
|---------|-------|
| Items en media library | 27 |
| Tests ejecutados | 39 |
| Tests pasados | 39 (100% post-fix) |
| Bugs encontrados | 3 |
| Bugs corregidos | 3 |
| TypeScript errors | 0 |
| Build time frontend | 2.49s |
| SSR page size (home) | 39.4 KB |
| SSR render time (home) | 1.98s |

---

*Sesión generada automáticamente por pi coding agent.*
