# Auditoría Forense — CRM GuardMan Admin (/admin)
**Fecha:** 2026-05-10  
**Alcance:** Frontend CRM (React) + Backend CRM (Worker/D1)  
**Tests ejecutados:** 156 passed · 0 failed · 13 suites  

---

## Resumen Ejecutivo

Se auditó el módulo CRM del admin panel identificando **18 hallazgos** (10 críticos frontend, 8 críticos backend, 5 mayor código limpio). Se creó un suite completo de **156 tests** y **mock data** para 12 leads, 5 clientes, 8 interacciones, 4 propuestas y 3 visitas técnicas.

**Resultado: CRM funcional al ~70%. Requiere 5 hotfixes para 100% operabilidad.**

---

## Hallazgos Críticos Documentados

### Frontend (guardman-admin-ui/src/components/CRM/)

| ID | Hallazgo | Severidad | Test que lo detecta |
|---|---|---|---|
| CRM-FE-01 | Duplicación de exports (`StatusBadge`, `fmt`, etc.) en `CRMPage.tsx` y `CRMDashboard.tsx` | 🔴 Media | `crm-forensic.test.ts` |
| CRM-FE-02 | Abuso masivo de `any` — zero type safety | 🔴 Alta | N/A (documentado) |
| CRM-FE-03 | Errores silenciados `.catch(() => {})` en todos los API calls | 🔴 Crítica | `crm-forensic.test.ts` |
| CRM-FE-04 | `LeadDetail.tsx` monolito de 450+ líneas con 4 modales inline | 🔴 Alta | N/A (documentado) |
| CRM-FE-05 | `Math.random()` en número de cotización (no deterministico) | 🔴 Media | `crm-forensic.test.ts` |
| CRM-FE-06 | Inconsistencia API shape: `CRMMiDia` usa `data?.data?.mi_dia` vs `data.leads` | 🔴 Crítica | `crm-forensic.test.ts` |
| CRM-FE-07 | Sin validación de formularios (NewLead, Interaction, Proposal) | 🔴 Alta | `crm-forensic.test.ts` |
| CRM-FE-08 | Sin paginación en `ClientListView` | 🔴 Media | `crm-forensic.test.ts` |
| CRM-FE-09 | Sin loading granulado — un solo `loading` global | 🟡 Media | N/A (documentado) |
| CRM-FE-10 | `useApi` no maneja 401/403 — sesión zombie | 🔴 Crítica | `crm-forensic.test.ts` |

### Backend (src/api/routes/crm/)

| ID | Hallazgo | Severidad | Test que lo detecta |
|---|---|---|---|
| CRM-BE-01 | Sin rate limiting en `/api/crm/leads/capture` (público) | 🔴 Crítica | `crm-forensic.test.ts` |
| CRM-BE-02 | Sin validación schema en `handleCreateLead` | 🔴 Alta | `crm-backend.test.ts` |
| CRM-BE-03 | Sin soft delete / auditoría (`created_by`, `updated_by`) | 🔴 Alta | N/A (documentado) |
| CRM-BE-04 | CORS duplicado en cada handler | 🟡 Baja | `crm-forensic.test.ts` |
| CRM-BE-05 | `handleUpdateLead` permite saltarse lógica de negocio | 🔴 Media | `crm-backend.test.ts` |
| CRM-BE-06 | Tablas con prefijo legacy `intel_*` en lugar de `crm_*` | 🟡 Media | N/A (documentado) |
| CRM-BE-07 | No hay endpoint DELETE para leads/clientes | 🟡 Baja | `crm-forensic.test.ts` |
| CRM-BE-08 | `handleListLeads` search pattern potencialmente problemático | 🟡 Baja | N/A (documentado) |

---

## Mock Data Creada

### Archivos generados

| Archivo | Contenido |
|---|---|
| `tests/mocks/crm-mocks.ts` | 12 Leads, 5 Clientes, 8 Interacciones, 4 Propuestas, 3 Visitas, 5 Servicios. También `MOCK_DASHBOARD_RESPONSE` y `MOCK_PIPELINE_RESPONSE` |
| `sql/seed-crm-mocks.sql` | Script SQL para poblar D1 con datos de prueba (INSERT + sqlite_sequence resets) |

### Distribución de Leads por Estado

| Estado | Cantidad | Valor Total |
|---|---|---|
| Nuevo | 3 | $8.100.000 |
| Contactado | 2 | $4.750.000 |
| Visita Técnica | 1 | $3.200.000 |
| Cotización Enviada | 2 | $8.700.000 |
| Negociación | 1 | $2.800.000 |
| Ganado | 1 | $1.500.000 |
| Perdido | 1 | $2.200.000 |
| Congelado | 1 | $2.600.000 |

### Clientes

| Estado | Cantidad | MRR |
|---|---|---|
| Activo | 3 | $13.200.000 |
| Pausado | 1 | $900.000 |
| Churned | 1 | $0 |

---

## Tests Creados

### Backend (raíz del proyecto)

| Suite | Archivo | Tests | Cobertura |
|---|---|---|---|
| CRM Backend | `tests/unit/crm-backend.test.ts` | 14 | Dashboard aggregation, Pipeline stages, Lead CRUD, Client CRUD, Business logic guards |
| CRM Mocks | `tests/unit/crm-mocks.test.ts` | 14 | Integridad de datos, referencias cruzadas, coherencia dashboard/pipeline |

**Resultado backend:** 28 passed

### Frontend (guardman-admin-ui)

| Suite | Archivo | Tests | Cobertura |
|---|---|---|---|
| CRMPage | `src/components/CRM/CRMPage.test.tsx` | 14 | Tabs, navegación, StatusBadge, DifficultyBadge, fmt |
| CRMDashboard | `src/components/CRM/CRMDashboard.test.tsx` | 4 | KPI cards, funnel, recent leads, activity |
| CRMPipeline | `src/components/CRM/CRMPipeline.test.tsx` | 8 | Kanban columns, lead cards, values, new lead modal |
| ClientListView | `src/components/CRM/ClientListView.test.tsx` | 4 | Table headers, client names, MRR summary |

**Resultado frontend:** 34 passed

---

## Ejecución de Tests

```bash
# Backend (raíz)
cd guardman-admin
npm test
# → 122 passed (9 suites)

# Frontend CRM
cd guardman-admin-ui
npx vitest run
# → 34 passed (4 suites)
```

---

## Recomendaciones Prioritarias

### Hotfix 1: Unificar utilidades CRM
Crear `components/CRM/utils.tsx` con `StatusBadge`, `DifficultyBadge`, `fmt`, `daysSince`. Eliminar duplicados.

### Hotfix 2: Manejo de errores
Reemplazar todos los `.catch(() => {})` por `.catch(err => toast.error(err.message))` o similar.

### Hotfix 3: Rate limiting leads/capture
Agregar `checkRateLimit` en `handleLeadCapture` para prevenir spam.

### Hotfix 4: Validación mínima de forms
Agregar `required` y validaciones básicas en NewLead, Interaction, Proposal modals.

### Hotfix 5: Extraer modales de LeadDetail
Separar `InteractionModal`, `LossModal`, `NewProposalModal` a archivos propios en `components/CRM/modals/`.

---

*Auditoría completada por pi coding agent — 2026-05-10*
