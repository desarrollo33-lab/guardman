# REDESIGN GUARDMAN ADMIN v13 — Prompt para Open Design

## 🎯 CONTEXTO DEL PROYECTO

**Producto:** GuardMan Admin Panel v12 — Panel de administración para GuardMan Chile, empresa de seguridad privada (guardias, CCTV, escoltas, monitoreo 24/7).

**Stack:** React 19 + Vite + TailwindCSS v4, deployed en Cloudflare Pages. Backend en Cloudflare Workers con D1, R2 y AI SDK.

**Diseño actual:** Tema oscuro navy (#0D1525 → #1A2744) con accent azul (#3B82F6). Sidebar colapsable de 56px con iconos. Topbar con breadcrumb y deploy status.

**Objetivo:** Rediseñar TODA la interfaz enfocándose en usabilidad, manteniendo el 100% de las features actuales. No eliminar ni una sola funcionalidad.

---

## 🎨 TOKENS DE DISEÑO EXISTENTES

```
--surface-0: #0D1525  (fondo principal)
--surface-1: #131D33  (cards)
--surface-2: #1A2744  (inputs, elementos elevados)
--surface-3: #0f1729  (sidebar, topbar)
--fg: #e8ecf1         (texto primario)
--fg-muted: #8896ab   (texto secundario)
--fg-dim: #5a6880     (texto terciario)
--accent: #3B82F6     (azul primario)
--accent-hover: #2563eb
--success: #10B981
--warning: #F59E0B
--error: #EF4444
--sidebar-w: 56px
--topbar-h: 48px
--radius-sm: 6px / --radius: 10px / --radius-lg: 14px / --radius-xl: 18px
```

---

## 📐 PRINCIPIOS DE REDESIGN (USABILIDAD)

1. **Jerarquía visual clara** — El usuario debe entender dónde está y qué puede hacer en < 2 segundos
2. **Densidad adaptable** — Tablas densas para datos, cards espaciadas para dashboards
3. **Acciones prominentes** — CTAs principales siempre visibles, secundarios accesibles
4. **Feedback inmediato** — Loading states, toasts, skeletons, hover states
5. **Navegación predecible** — Breadcrumbs, tabs consistentes, keyboard shortcuts
6. **Mobile-first responsive** — Funciona en desktop, tablet y mobile
7. **Dark theme premium** — Mantener el navy oscuro pero con más profundidad (glassmorphism sutil, gradientes)
8. **Consistencia de patrones** — Todos los formularios, tablas, modales siguen las mismas reglas

---

## 🗂️ ESTRUCTURA COMPLETA — REDISEÑAR CADA COMPONENTE POR SEPARADO

### SECCIÓN 1: SHELL & LAYOUT (Componentes base)

#### 1.1 AppLayout
- Layout principal: grid con sidebar + topbar + main content
- Debe soportar navegación entre 5 vistas: CMS, Media, ADN, CRM, Intel
- Transiciones suaves entre vistas
- Estado de "deploy live" visible en topbar
- Mobile: sidebar colapsable con overlay + hamburger
- Breadcrumb dinámico según la vista activa

#### 1.2 Sidebar
- 56px ancho, icon-only con tooltips en hover
- Items: CMS (edit icon), ADN (layers icon), CRM (users icon), Intel (alert-circle icon), Media (image icon)
- Badge de leads pendientes en CRM (se actualiza cada 30s desde API)
- Item activo con indicador lateral (3px accent bar) y fondo accent-soft
- Botón settings al fondo con ícono gear
- Logo "GM" con gradiente accent arriba

#### 1.3 Topbar
- Breadcrumb: nombre de sección / subsección
- Título de la vista actual (h1)
- Deploy status pill con dot verde "Live"
- User avatar con iniciales (click → dropdown con logout)
- Mobile: hamburger button para abrir sidebar overlay

#### 1.4 LoginForm
- Centrado en pantalla con radial gradient background
- Logo shield con gradiente
- Email + password fields con focus ring accent
- Botón primary con loading spinner
- Error message con estilo error-soft
- Cert badge (OS-10) al pie

---

### SECCIÓN 2: CMS — HEADLESS CMS EDITOR

#### 2.1 CMSPage (Página principal)
**Layout de 3 columnas:**
- **Izq (280px):** Lista de contenido con tabs (Servicios, Ubicaciones, Sectores, Combos, Páginas)
  - Buscador para combos
  - Items clickeables con highlight del seleccionado
  - Homepage destacado primero
  - Páginas estáticas: nosotros, guard-pod, ajax-systems, contacto, cotización, privacidad, términos, hub-servicios, hub-sectores, hub-ubicaciones, gracias
- **Centro (flex):** Editor de contenido
  - Toolbar: título del item, tipo, versión, botones Guardar/Regenerar/Generar
  - Formulario dinámico según tipo de contenido
  - Secciones colapsables: Hero, Intro, Features, Issues, FAQs, CTA
  - Campos de texto, textarea, image picker
  - Image upload con drag & drop
  - YouTube embed support (yt:VIDEO_ID)
  - Preview inline de imágenes
- **Der (300px):** SEOPanel con score ring, checks, acciones

**Funcionalidades a mantener:**
- Generar contenido con IA (genera desde cero)
- Regenerar contenido con IA (mejora existente con deep merge)
- Guardar contenido (POST /api/cms/save)
- Cargar homepage, servicios, locations, sectors, combos, static pages
- SEO score client-side (title, desc, hero, word count, TTR, foreign words)
- Image picker integrado con MediaEditor
- Smart merge: preserva imágenes, badges, CTAs durante regeneración

#### 2.2 SEOPanel
- Score ring SVG circular (0-100, colores: green/amber/red)
- Breakdown: Contenido, SEO Técnico, Conversión (barras de progreso)
- SERP Intel: query volume, competitor count, position
- Pipeline Status: deployed/in_d1
- Content Quality Checks (lista de ✓/✗ con labels)
- Score warnings (badges amarillos)
- Quality Pipeline: score, passed/failed, violations, generic phrases, review text
- Acciones: "Regenerar con IA", "Publicar"

#### 2.3 Homepage Editor (sección especial dentro de CMSPage)
Secciones editables del home:
- SEO (title + description)
- Hero (headline, subheadline, background_image, phone, badge_image)
- Nosotros (badge, title, paragraph, image, image_badge, cta_text, cta_link, stats: guards/clients/locations/years, features[] con add/remove)
- Servicios (title, subtitle, cta_text, cta_link)
- Guard Pod (badge, title, paragraph, image, image_badge, cta_text, cta_link, features[] con add/remove)
- Sectores (title, subtitle, cta_text, cta_link)
- Ajax Systems (badge, title, paragraph, image, image_badge, cta_text, cta_link, features[] con add/remove)
- Clientes (title, subtitle, cta_text, cta_link, items[] con nombre, logo, initials, color picker, add/remove)
- Ubicaciones (badge, title, subtitle, cta_text, cta_link)
- CTA Final (badge, title, subtitle, cta_text, cta_link)

---

### SECCIÓN 3: ADN DE MARCA — BRAND DNA

#### 3.1 ADNPage
**Layout de 2 columnas:**
- **Izq (176px):** Sidebar de categorías con scroll
  - 10 categorías: Empresa, Redes Sociales, Estadísticas, Horarios, Voz de Marca, Diferenciadores, Exclusiones, Certificaciones, USPs, Colores
  - Cada categoría con icono emoji, label, count de campos
  - Indicador de "dirty" (dot amarillo si hay cambios sin guardar)
  - Categoría activa con fondo accent-soft y barra lateral

- **Centro (flex):** Editor de categoría
  - Header: título de categoría + descripción + botones (Revertir, +Campo, Guardar todo)
  - Stats bar visual (solo categoría stats): 5 mini cards con iconos
  - Palette preview (solo categoría colors): swatches de primary_50-900 + accent/success/warning/error
  - Lista de campos con:
    - Label font-mono con tag "modificado"
    - Input según tipo: text, textarea, color (picker + hex input + preview swatch), url, json
    - Schedule editor especial (días de la semana con quick actions: "Todos 24h", "Todos 9-18h", "Todos cerrado")
    - Structured card editor para USPs y Diferenciadores:
      - Cards con title, description, icon picker (15 emojis)
      - Key font-mono como identifier
      - Add new card con key input
      - Save individual por card
      - Delete con confirm modal
    - Extra fields section (campos no definidos en schema)
  - Form agregar campo: key, type selector (text/textarea/url/color), botón Agregar

**Funcionalidades:**
- Fetch brand data (GET /api/brand)
- Save entire category (PUT /api/brand)
- Save single field (PUT /api/brand)
- Delete field (DELETE /api/brand/:category/:key)
- Add field (client-side, save to persist)
- Undo category changes
- Revert all changes
- Dirty detection (JSON diff)
- Toast notifications (3s auto-dismiss)
- Confirm delete modal

---

### SECCIÓN 4: CRM — PIPELINE & CLIENTS

#### 4.1 CRMPage
- Tabs: Pipeline, Dashboard, Clientes
- Lead detail view con back button

#### 4.2 CRMDashboard
- Header: título + fecha actual
- KPI Row (5 cards): Nuevos, Pipeline Activo, Pipeline Total, Ponderado, Clientes (con MRR)
- Pipeline Funnel: barras horizontales por etapa (Nuevo, Contactado, Calificado, Propuesta, Ganado, Perdido) con count y valor
- Dos columnas:
  - Leads Recientes: lista clickeable con status badge, nombre, servicio+ubicación, valor estimado, difficulty badge
  - Actividad Reciente: timeline con fecha, tipo, summary, contact info
- Quick Actions: "Nuevo Lead", "Ver Clientes"

#### 4.3 CRMPipeline (Kanban)
- Header: título + total leads + pipeline ponderado + botón "+ Nuevo Lead"
- Kanban horizontal (scrollable): 7 columnas
  - Nuevo (blue), Contactado (yellow), Visita Técnica (orange), Cotización Enviada (purple), Negociación (cyan), Ganado (green), Perdido (red)
  - Cada columna: header con label + count, lista de cards scrollable
  - Lead cards: nombre, empresa, servicio+ubicación tags, valor estimado, follow-up date, frozen indicator (>7 días sin actividad = fondo rojo)
  - Move buttons (← →) en hover para mover entre etapas
  - "No contesta X/3" badge si hay intentos fallidos
- New Lead Modal:
  - Formulario: nombre*, email, teléfono, empresa, servicio (dropdown), ubicación (dropdown), valor estimado, mensaje
  - Submit crea lead via API

#### 4.4 LeadDetail
- Detalle completo de un lead
- Editar información
- Agregar interacciones/notas
- Cambiar etapa del pipeline

#### 4.5 ClientListView
- Lista/tabla de clientes activos
- Información: nombre, empresa, servicio, ubicación, MRR, estado

#### 4.6 VisitChecklist
- Checklist para visitas técnicas
- Items predefinidos + custom

---

### SECCIÓN 5: INTEL HUB — MARKET INTELLIGENCE

#### 5.1 IntelPage
- Tabs: Overview, Competidores, Oportunidades, Reportes
- Solo Overview tiene datos reales; otros muestran "en desarrollo"

#### 5.2 IntelDashboard
- Header: título + fecha
- KPI Row (4 cards): Competidores, Queries Serper, TOP 3, Presencias GM
- Dos columnas:
  - Presencia Digital GuardMan: TOP 3 positions + Presencias Totales
  - Top Competidores: lista con rank, domain, apariciones, avg position
- Acciones: Sincronizar Competidores, Alertas, Posiciones SEO, Estrategia de Contenido, Reporte

#### 5.3 IntelCRUD
- CRUD de competidores (crear, editar, eliminar)
- Lista con search y filtros
- Formulario: domain, nombre, descripción, servicios

#### 5.4 CompetitorView
- Vista detallada de competidor
- Comparación con GuardMan

#### 5.5 MarketMap
- Mapa visual del mercado
- Posicionamiento por ejes

#### 5.6 PositionTracker
- Tracker de posiciones SEO
- Keywords, posiciones actuales, historial

#### 5.7 ContentStrategyView
- Estrategia de contenido basada en datos Serper
- Oportunidades detectadas

#### 5.8 ReportView
- Reportes de inteligencia
- Exportable

#### 5.9 AlertsPanel
- Alertas de cambios en competencia

---

### SECCIÓN 6: MEDIA LIBRARY — BIBLIOTECA DE MEDIOS

#### 6.1 MediaLibrary
**Layout de 3 paneles:**
- **Izq (384px):** Grid de medios
  - Toolbar: título + filtros de tipo (Todos/Imágenes/Videos) + filtros de categoría (10 categorías) + buscador + botones de upload (Imagen, Video, YouTube)
  - YouTube URL input (toggle)
  - Thumbnail uploader para videos
  - Grid responsive (3 cols): thumbnails con overlay (nombre, categoría, tipo badge)
  - Selección visual (borde azul)
  - Footer stats: total medios, total videos
  - Empty state con icono
- **Centro (flex):** Preview + Tabs
  - Preview area: imagen/video/YouTube embebido con max-height
  - Info del archivo: nombre, tamaño, tipo, ruta, categoría, creado, dimensiones
  - Tabs: Info, AI (Editar con IA), SEO
  - **Tab Info:** metadata + formulario de asignación (entity_type, entity_slug, usage) + lista de asignaciones existentes con unassign
  - **Tab AI:** fal.ai key config + modelo selector (Flux Schnell/Pro) + prompt textarea + botones "Texto → Imagen" y "Transformar" + preview de imagen generada + botón "Usar esta imagen"
  - **Tab SEO:** score ring SVG + checks + campos editables (alt text, title, caption, tags con tag pills) + botón guardar
- **Der (256px):** Acciones rápidas
  - Abrir en nueva pestaña
  - Copiar ruta
  - Editar con IA (shortcut)
  - Editar SEO (shortcut)
  - Eliminar medio

#### 6.2 MediaEditor (v3 — picker mode + full mode)
- Modo full: igual a MediaLibrary pero con sección de AI generation asíncrona (generateAsync + waitForCompletion + saveToR2)
- Modo picker: modal para seleccionar imagen desde CMS, con currentImage highlight
- Mismo grid + preview + metadata

#### 6.3 LiteYouTube
- Embed optimizado de YouTube con thumbnail + play button
- Lazy loading

---

### SECCIÓN 7: CHAT — AI ORCHESTRATOR INTERFACE

#### 7.1 ChatView
**Layout principal:**
- Chat column (flex-1):
  - Slim header (44px): connection status dot + label + streaming indicator + panel toggle buttons (Preview, Editor, Approval, Chart) + clear button
  - MiniDashboard (collapsible): metrics row (serv, com, cont, score)
  - Messages area (scroll):
    - Welcome screen con 4 sugerencias clickeables
    - User bubbles (derecha, azul)
    - Assistant bubbles (izquierda, fondo sutil, markdown rendering)
    - Tool indicators (🔧 tool-name)
    - Thinking animation (3 dots bouncing)
    - Quick actions después de generación: Preview, H1, Intro, SEO Title
  - Mobile quick actions bar
  - Input area: textarea + send button (arrow icon, spinner cuando streaming)

- Side Panel (420px, conditional):
  - Header con título del panel + close button
  - **Preview panel:** iframe/preview de página generada
  - **Editor panel:** Monaco editor (campos largos) o SimpleEditor (campos cortos) + save/cancel
  - **Approval panel:** lista de items pendientes + aprobaciones pending con approve/reject buttons + badge count
  - **Chart panel:** Canvas con Chart.js (coverage, scores, gaps)

**Funcionalidades:**
- WebSocket connection a ORCHESTRATOR agent
- Send message (Enter = send, Shift+Enter = newline)
- Auto-scroll to bottom
- Tool result detection → auto-open panels
- LocalStorage + D1 sync de mensajes (debounced 2s)
- Session management: new session, select session, delete session
- SessionSelector panel (history sidebar)
- Panel toggle (click = open/close/toggle)
- Approval workflow (approve/reject via chat)

#### 7.2 ChatDrawer
- Versión drawer del chat (alternativa a ChatView)
- Toggle open/close desde sidebar
- Mismo contenido que ChatView pero en drawer

#### 7.3 MiniDashboard
- Collapsible metrics strip debajo del header
- 4 pills: servicios, comunas, contenido, score
- Fetch cada 60s desde /api/orchestrator/status
- Collapse/expand con ▼/▲

#### 7.4 SessionSelector
- Panel lateral de sesiones/historial
- Lista de sesiones con título, fecha, message count
- Seleccionar sesión carga mensajes desde D1
- Nueva sesión (clear)
- Eliminar sesión

#### 7.5 Notifications
- Toast notifications del sistema
- Alertas de deploy, errores, etc.

---

### SECCIÓN 8: PUBLISH — DEPLOY CONTROL

#### 8.1 PublishPage
- Header: título + refresh button
- Summary cards: Servicios, Ubicaciones, Sectores, Combos + Score avg + Total palabras
- Toolbar: buscador + seleccionar todos + count
- List de cambios pendientes:
  - Cada item: checkbox + icono tipo + nombre + metadata (tipo, nuevo/version/palabras/hace cuánto) + score badge + expand chevron
  - Expandido: draft vs publicada version, modificado por, lista de cambios (field → after)
- Footer: "Publicar TODO" + "Publicar seleccionados (count)"
- Deploy in progress view:
  - Fase icon grande + título + descripción
  - Progress animation (3 dots bouncing para deploying)
  - Deploy URL link
  - Error messages
  - Elapsed time
  - "Navegar a otras secciones — deploy sigue en background"

#### 8.2 ChangeList
- Lista simplificada de cambios
- Grouped by type

#### 8.3 DiffViewer
- Visualización de diffs entre versiones
- Before/after comparison

#### 8.4 DeployStatus
- Componente pequeño de status de deploy
- Dot + label (idle/exporting/deploying/success/failure)

---

### SECCIÓN 9: EDITOR & PREVIEW

#### 9.1 MonacoEditor
- Monaco code editor integrado
- Soporte markdown
- Height configurables (height, maxHeight)
- Placeholder
- onSave callback
- Solo para textos largos

#### 9.2 SimpleEditor
- Editor simple para campos cortos (H1, subheadings, etc.)
- Textarea mejorada con character counter
- onSave callback

#### 9.3 PreviewFrame
- Iframe o renderizado de preview de páginas
- entityType + entitySlug params
- Muestra cómo se verá la página publicada

---

### SECCIÓN 10: CHARTS & ANALYTICS

#### 10.1 ChartPanel
- Header con tabs: Coverage, Scores, Gaps
- Chart.js canvas (bar charts, doughnut)
- Coverage: grouped bar chart por servicio
- Scores: horizontal bar chart con color coding (green >=85, amber >=75, red <75)
- Gaps: doughnut chart (con contenido vs faltante)
- Stats text summary al pie
- Empty state: instrucciones para generar gráfico

---

### SECCIÓN 11: MOBILE

#### 11.1 DrawerMenu
- Menú drawer para mobile
- Items del sidebar en formato lista con labels

#### 11.2 MobileQuickActions
- Barra de acciones rápidas para mobile
- Sugerencias de mensajes predefinidos para el chat

---

### SECCIÓN 12: SHARED COMPONENTS

#### 12.1 PipelineBar
- Barra visual de pipeline de calidad
- Steps con status

---

## 📋 REQUERIMIENTOS DE USABILIDAD ESPECÍFICOS

### Navegación
- **Breadcrumbs siempre visibles** en topbar
- **Keyboard shortcuts:** Ctrl+K para command palette, Ctrl+S para guardar, Esc para cerrar modales
- **Hover states** en todos los elementos interactivos
- **Active states** claros en navegación

### Formularios
- **Labels siempre visibles** (no placeholder-only)
- **Validation inline** con mensajes claros
- **Auto-save** donde sea apropiado (ADNPage ya lo tiene por campo)
- **Unsaved changes warning** al navegar fuera de una vista con cambios

### Tablas y Listas
- **Sortable columns** donde aplique
- **Search/filter** en todas las listas largas
- **Pagination o virtual scroll** para listas > 50 items
- **Bulk actions** (select multiple + action bar)

### Loading States
- **Skeleton loaders** en lugar de "Cargando..."
- **Optimistic updates** donde sea seguro
- **Error boundaries** con retry option

### Feedback
- **Toast system** centralizado (success, error, warning, info)
- **Inline validation** en formularios
- **Confirmation dialogs** para acciones destructivas
- **Progress indicators** en operaciones largas (deploy, AI generation)

### Responsive
- **Desktop (>1024px):** Layout completo con sidebar + multi-panel
- **Tablet (768-1024px):** Sidebar colapsable, paneles apilados
- **Mobile (<768px):** Bottom nav o drawer, single column, touch-friendly targets (min 44px)

---

## 🎨 MEJORAS DE UI PROPUESTAS

1. **Glassmorphism sutil** en modales y overlays (backdrop-blur + fondo semi-transparente)
2. **Gradientes de fondo** en el login y secciones hero
3. **Micro-interacciones** en botones (scale, glow on hover)
4. **Score rings animados** con CSS transitions
5. **Kanban drag & drop** en CRM Pipeline
6. **Image lazy loading** con blur placeholder
7. **Command palette** (Ctrl+K) para navegación rápida
8. **Keyboard shortcuts** en tooltips
9. **Toasts** con auto-dismiss y undo
10. **Empty states** con ilustraciones y CTAs
11. **Data tables** con column resize y sticky headers
12. **Form sections** con visual grouping
13. **Breadcrumb** con dropdown en secciones largas
14. **Status badges** consistentes (pill shape, color-coded)
15. **Icon system** con Lucide React (ya instalado)

---

## 📁 ENTREGABLES ESPERADOS

Para cada componente, Open Design debe generar:

1. **HTML prototipe** completo y funcional del componente
2. **CSS con design tokens** consistentes con el sistema existente
3. **Responsive variants** (desktop, tablet, mobile)
4. **States:** default, hover, active, loading, empty, error
5. **Componentes anidados** bien organizados

El resultado final debe ser un sistema de diseño coherente donde todos los componentes funcionen juntos como un producto unificado.

---

## ⚠️ REGLAS CRÍTICAS

- ❌ NO eliminar ninguna funcionalidad existente
- ❌ NO cambiar las APIs ni los endpoints
- ❌ NO modificar la estructura de datos
- ✅ MEJORAR la presentación visual y la usabilidad
- ✅ MANTENER los mismos design tokens de color
- ✅ RESPETAR la jerarquía de información existente
- ✅ HACER cada componente autocontenido y reutilizable
- ✅ INCLUIR todos los estados (loading, empty, error, success)
- ✅ ASEGURAR consistencia visual entre todos los componentes
