import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    coverage: {
      reporter: ['text', 'json', 'html'],
      exclude: ['node_modules/', 'tests/', 'guardman-admin-ui/'],
    },
    // Allow importing TypeScript from src/
    deps: {
      interopDefault: true,
    },
  },
  resolve: {
    alias: {
      '~': './src',
    },
  },
});
