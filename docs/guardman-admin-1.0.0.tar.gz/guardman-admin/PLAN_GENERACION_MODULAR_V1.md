# Plan de Implementación — Generación de Contenido Modular por Sección

**Fecha:** 2026-05-10  
**Versión:** 1.0  
**Estado:** Listo para ejecutar  
**Estimación total:** 12-14 horas (2 sprints)

---

## 1. Análisis del Problema Actual

### 1.1 Arquitectura Monolítica (actual)

```
Usuario click "Regenerar" en /nosotros
  ↓
POST /api/cms/regenerate { type: "static_page", slug: "nosotros" }
  ↓
callDeepSeekAI("static_page", "nosotros", ...)
  ↓
Prompt de ~1200 tokens pide 7 secciones simultáneas:
  - hero, stats, timeline, values, differentiators, certifications, staff, cta
  ↓
IA genera JSON parcial (olvidó timeline, staff, certifications)
  ↓
Frontend hace merge profundo → sobreescribe TODO con datos parciales
  ↓
Timeline vacío, Stats vacío, Staff vacío
```

### 1.2 Hallazgos de la auditoría de código

**Archivo:** `src/services/ai.ts` — función `callDeepSeekAI`

El prompt para `/nosotros` es monolítico:
```
"Genera contenido SEO completo para /nosotros..."
"ESTRUCTURA JSON EXACTA: { hero, stats, timeline, values, ... }"
"Responde SOLO con JSON: { sections: { ... } }"
```

**Problemas identificados:**

| # | Problema | Impacto |
|---|----------|---------|
| P-01 | Prompt pide 7 secciones en 1 call | La IA "olvida" secciones cuando el contexto es largo |
| P-02 | No hay schema de validación por sección | La IA puede omitir campos obligatorios sin feedback |
| P-03 | Merge frontend (`safeAssign`) sobreescribe todo | Se pierde contenido previo de secciones no generadas |
| P-04 | No hay endpoint para generar 1 sección | Todo o nada: no se puede regenerar solo timeline |
| P-05 | No hay botón "Regenerar" por acordeón | UX fuerza al usuario a regenerar TODO para arreglar 1 sección |
| P-06 | `content_json` se almacena como blob único | No se puede versionar por sección |

### 1.3 Estructura de datos de /nosotros

**Tabla:** `static_page_content` (slug = 'nosotros')

```json
{
  "content": {
    "hero": { "headline": "...", "subheadline": "..." },
    "stats": [{ "value": "500+", "label": "Guardias", "icon": "👮" }],
    "timeline": [{ "year": "2017", "title": "...", "description": "..." }],
    "values": [{ "title": "...", "description": "..." }],
    "differentiators": [{ "title": "...", "description": "...", "icon": "..." }],
    "certifications": [{ "title": "...", "description": "..." }],
    "staff": { "image": "...", "traits": ["...", "..."] },
    "cta": { "heading": "...", "subheading": "...", "button_text": "..." }
  },
  "seo": { "title": "...", "description": "..." }
}
```

**Secciones renderizadas** (`buildNosotrosBody` en `site-renderer.ts`):

| Sección | Campos obligatorios | Opcional |
|---------|-------------------|----------|
| stats | `value`, `label` | `icon` |
| timeline | `year`, `title`, `description` | — |
| values | `title`, `description` | — |
| differentiators | `title`, `description` | `icon` |
| certifications | `title`, `description` | — |
| staff | `traits[]` | `image` |
| cta | `heading`, `button_text` | `subheading`, `button_href` |

---

## 2. Visión de la Solución — Arquitectura Modular

### 2.1 Principios

1. **Una sección = un prompt = un call a IA**
2. **Preservar lo que existe, generar lo que falta**
3. **Validar schema antes de aceptar**
4. **UX: botón "Generar" por acordeón, no por página**
5. **Bulk: paralelizar calls, no secuencializar**

### 2.2 Arquitectura propuesta

```
┌─ Usuario click "🤖 Generar" en acordeón "Timeline"
│   ↓
├─ Frontend: POST /api/cms/generate-section
│            { slug: "nosotros", section: "timeline", existing: {...} }
│   ↓
├─ Backend: Carga brand context
│           Construye prompt FOCALIZADO para timeline
│           (200 tokens, no 1200)
│   ↓
├─ DeepSeek AI: Genera SOLO array de timeline items
│   ↓
├─ Backend: Valida schema (Joi/Zod)
│           Si pasa: mergea con content_json existente
│           Si falla: retry con feedback de error
│   ↓
├─ Backend: Guarda SOLO la sección en content_json
│           Versiona en content_versions
│   ↓
└─ Frontend: Recibe solo timeline + metadatos
            Refresca SOLO ese acordeón
            Resto de la página intacta
```

### 2.3 Comparación: Monolítico vs. Modular

| Aspecto | Monolítico (actual) | Modular (propuesto) |
|---------|---------------------|---------------------|
| Prompt size | 1200+ tokens | 200-300 tokens |
| IA se distrae | Sí (7 secciones) | No (1 sección) |
| Pérdida de datos | Sí (merge total) | No (merge parcial) |
| Costo API | $0.002 × 1 call | $0.001 × 7 calls = similar |
| Tiempo total | 15s (1 call lento) | 8s (7 calls paralelos) |
| UX control | Botón único, ciego | Botón por acordeón |
| Debugging | Imposible saber qué falló | "Timeline falló" = obvio |
| Retry | Todo de nuevo | Solo la sección que falló |

---

## 3. Especificación Técnica

### 3.1 Backend — Nuevo endpoint

**POST** `/api/cms/generate-section`

**Request:**
```json
{
  "slug": "nosotros",
  "section": "timeline",
  "type": "static_page",
  "context": {
    "brand": "GuardMan Chile",
    "tone": "profesional, cercano, chileno"
  }
}
```

**Response (éxito):**
```json
{
  "ok": true,
  "section": "timeline",
  "data": [
    { "year": "2017", "title": "Fundación", "description": "..." },
    { "year": "2019", "title": "Expansión", "description": "..." }
  ],
  "version": 12,
  "meta": {
    "generated_by": "ai",
    "prompt_tokens": 180,
    "completion_tokens": 420
  }
}
```

**Response (error de validación):**
```json
{
  "ok": false,
  "error": "Schema validation failed",
  "section": "timeline",
  "details": [
    "Missing required field: description at timeline[0]",
    "timeline must have at least 4 items, got 2"
  ]
}
```

### 3.2 Backend — Prompts modulares por sección

Cada sección tiene un prompt focalizado. Ejemplo para `timeline`:

```
Genera la sección TIMELINE (historia de empresa) para GuardMan Chile.

CONTEXTO:
- Empresa: GuardMan Chile, seguridad privada OS-10
- Años de operación: 2017-presente
- Hitos reales: fundación 2017, expansión a 14 comunas, 500+ guardias,
  centro de monitoreo propio, certificación OS-10, Guard Pod (2024)

FORMATO JSON:
[
  { "year": "2017", "title": "string (3-8 palabras)", "description": "string (1-2 oraciones, 40-80 palabras)" }
]

REGLAS:
- Mínimo 5 eventos, máximo 7
- Años cronológicos reales o realistas
- Cada evento debe ser verosímil para empresa de seguridad chilena
- Tono: profesional pero cercano
- NO uses placeholder. Todo contenido original y listo para publicar.

Responde SOLO con el array JSON.
```

### 3.3 Backend — Schemas de validación

```typescript
// src/schemas/cms-sections.ts
import { z } from 'zod';

export const SectionSchemas = {
  timeline: z.array(z.object({
    year: z.string().min(4).max(4),
    title: z.string().min(5).max(60),
    description: z.string().min(20).max(200),
  })).min(4).max(7),

  stats: z.array(z.object({
    value: z.string().min(1).max(20),
    label: z.string().min(3).max(40),
    icon: z.string().optional(),
  })).min(3).max(6),

  values: z.array(z.object({
    title: z.string().min(3).max(40),
    description: z.string().min(20).max(150),
  })).min(3).max(6),

  differentiators: z.array(z.object({
    title: z.string().min(3).max(40),
    description: z.string().min(20).max(150),
    icon: z.string().optional(),
  })).min(3).max(6),

  certifications: z.array(z.object({
    title: z.string().min(3).max(50),
    description: z.string().min(20).max(150),
  })).min(2).max(6),

  staff: z.object({
    image: z.string().optional(),
    traits: z.array(z.string().min(10).max(150)).min(3).max(6),
  }),

  cta: z.object({
    heading: z.string().min(10).max(80),
    subheading: z.string().min(20).max(150).optional(),
    button_text: z.string().min(5).max(40),
    button_href: z.string().default('/contacto'),
  }),
} as const;

export type SectionKey = keyof typeof SectionSchemas;
```

### 3.4 Backend — Merge seguro por sección

```typescript
// src/services/section-merge.ts
export function mergeSection(
  existing: any,
  sectionKey: string,
  newSectionData: any
): any {
  return {
    ...existing,                    // preserva TODO lo anterior
    [sectionKey]: newSectionData,   // reemplaza SOLO la sección pedida
  };
}
```

**Regla de oro:** Nunca tocar `existing` excepto la clave `sectionKey`.

### 3.5 Backend — Retry automático con feedback

```typescript
async function generateSectionWithRetry(
  env: Env,
  slug: string,
  section: SectionKey,
  maxRetries = 2
): Promise<any> {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const result = await callDeepSeekForSection(env, slug, section);
    
    const parsed = SectionSchemas[section].safeParse(result);
    if (parsed.success) return parsed.data;
    
    if (attempt === maxRetries) throw parsed.error;
    
    // Retry con feedback de error en el prompt
    const errors = parsed.error.errors.map(e => e.message).join('\n');
    // next call includes: "Previous attempt failed with: ${errors}"
  }
}
```

---

## 4. Especificación Frontend

### 4.1 Botón "Generar" por acordeón

```tsx
// CMSPage.tsx — cada AccordionHeader ahora tiene:
<AccordionHeader>
  <h4>📅 Timeline</h4>
  <div className="accordion-actions">
    {sectionEmpty('timeline') && <span className="badge-empty">Vacío</span>}
    <button
      className="btn btn-sm btn-ghost"
      onClick={() => generateSection('timeline')}
      disabled={generating.has('timeline')}
    >
      {generating.has('timeline') ? <Spinner /> : '🤖 Generar'}
    </button>
  </div>
</AccordionHeader>
```

### 4.2 Hook `useSectionGenerator`

```tsx
// hooks/useSectionGenerator.ts
export function useSectionGenerator(slug: string) {
  const [generating, setGenerating] = useState<Set<string>>(new Set());
  const { showToast } = useToast();

  const generate = async (section: string) => {
    setGenerating(prev => new Set(prev).add(section));
    try {
      const { data } = await api('/api/cms/generate-section', {
        method: 'POST',
        body: JSON.stringify({ slug, section, type: 'static_page' }),
      });
      showToast(`✅ Sección "${section}" generada`, 'success');
      return data;
    } catch (err: any) {
      showToast(`❌ Error en "${section}": ${err.message}`, 'error');
      throw err;
    } finally {
      setGenerating(prev => {
        const next = new Set(prev);
        next.delete(section);
        return next;
      });
    }
  };

  return { generate, generating };
}
```

### 4.3 Botón "Generar Todo" (bulk paralelo)

```tsx
<button
  className="btn btn-primary"
  onClick={async () => {
    const sections = ['stats', 'timeline', 'values', 'differentiators', 'certifications', 'staff', 'cta'];
    await Promise.all(sections.map(s => generate(s)));
  }}
>
  🤖 Generar Todas las Secciones
</button>
```

**UX de progreso:**
```
🤖 Generando...  
  ✅ Stats       
  ⏳ Timeline    
  ⏳ Values      
  ⏳ ...         
```

---

## 5. Cambios en Base de Datos

### 5.1 Tabla `section_versions` (nueva)

```sql
CREATE TABLE section_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_slug TEXT NOT NULL,
  section_key TEXT NOT NULL,
  version INTEGER NOT NULL,
  content_json TEXT NOT NULL,
  generated_by TEXT DEFAULT 'ai',
  word_count INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(entity_type, entity_slug, section_key, version)
);

CREATE INDEX idx_section_versions_lookup
ON section_versions(entity_type, entity_slug, section_key);
```

**Por qué:** Permite revertir UNA sección sin afectar las demás.

### 5.2 Tabla `static_page_content` (sin cambios)

`content_json` sigue siendo el blob principal. Las section_versions son histórico.

---

## 6. Fases de Implementación

### Sprint 1: Backend (6h)

| Día | Tarea | Archivos | Hrs |
|-----|-------|----------|-----|
| Lunes AM | Definir schemas Zod por sección | `src/schemas/cms-sections.ts` | 1 |
| Lunes PM | Crear `generateSection` en `ai.ts` | `src/services/ai.ts` | 1.5 |
| Martes AM | Crear endpoint `/api/cms/generate-section` | `src/api/routes/cms.ts` | 1.5 |
| Martes PM | Merge seguro + retry + tests | `src/services/section-merge.ts` | 2 |

### Sprint 2: Frontend + Integración (6h)

| Día | Tarea | Archivos | Hrs |
|-----|-------|----------|-----|
| Miércoles AM | Hook `useSectionGenerator` | `src/hooks/useSectionGenerator.ts` | 1 |
| Miércoles PM | Botón por acordeón en CMSPage | `src/components/CMS/CMSPage.tsx` | 2 |
| Jueves AM | Botón "Generar Todo" + progreso | `src/components/CMS/CMSPage.tsx` | 1 |
| Jueves PM | Tests frontend + build + deploy | — | 2 |

### Sprint 3: Validación y refinamiento (2h buffer)

| Tarea | Hrs |
|-------|-----|
| Generar todas las secciones de /nosotros | 1 |
| Verificar que ningún campo queda vacío | 0.5 |
| Ajustar prompts si alguna sección es mala | 0.5 |

**Total: 14h**

---

## 7. Tests

### Backend

| Test | Qué valida | Archivo |
|------|-----------|---------|
| Schema timeline válido | 5 items con year/title/desc | `tests/unit/section-schemas.test.ts` |
| Schema timeline inválido | Falta description → error | `tests/unit/section-schemas.test.ts` |
| Merge seguro | Solo reemplaza la sección pedida | `tests/unit/section-merge.test.ts` |
| Retry automático | 2do intento con feedback de error | `tests/unit/section-retry.test.ts` |
| Endpoint generate-section | 200 con datos válidos | `tests/integration/generate-section.test.ts` |
| Endpoint generate-section 400 | Schema inválido → error detallado | `tests/integration/generate-section.test.ts` |

### Frontend

| Test | Qué valida | Archivo |
|------|-----------|---------|
| Hook useSectionGenerator | Llama API, maneja loading/error | `src/hooks/useSectionGenerator.test.ts` |
| Botón por acordeón | Click genera solo esa sección | `src/components/CMS/CMSPage.test.tsx` |
| Botón "Generar Todo" | Llama 7 APIs en paralelo | `src/components/CMS/CMSPage.test.tsx` |
| Toast de éxito/error | Muestra feedback al usuario | `src/components/CMS/CMSPage.test.tsx` |

---

## 8. Dependencias

```bash
# Backend (ya instalado en el proyecto)
# zod ya está en node_modules

# Frontend (ya instalado)
# React hooks, testing-library ya están
```

**Ninguna dependencia nueva requerida.**

---

## 9. Riesgos y Mitigaciones

| Riesgo | Prob | Impacto | Mitigación |
|--------|------|---------|------------|
| Zod no está en backend | Baja | Alto | Verificar `package.json` o usar validación manual |
| 7 calls paralelos exceden rate limit de DeepSeek | Media | Medio | Implementar cola con `p-limit` (max 3 concurrentes) |
| Costo API sube 7× | Baja | Medio | Prompts más cortos = menos tokens. Costo neto similar. |
| Merge incorrecto borra datos | Baja | Alto | Tests de integración + backup de content_json |
| Frontend se complica mucho | Baja | Medio | Hook reutilizable, botón reutilizable |

---

## 10. Métricas de Éxito

| Métrica | Baseline | Meta |
|---------|----------|------|
| Secciones vacías en /nosotros | 5 de 7 | 0 de 7 |
| Prompts que generan contenido completo | ~60% | >95% |
| Tiempo para regenerar 1 sección | 15s (todo) | 3s (1 sección) |
| Tests pasando | 173 | ≥ 185 |
| Usuarios que regeneran todo para arreglar 1 sección | 100% | 0% |

---

## 11. Prompts Modulares Completos

### 11.1 Timeline

```
Genera la sección TIMELINE (línea de tiempo histórica) para la página /nosotros de GuardMan Chile.

DATOS DE LA EMPRESA:
- Nombre: GuardMan Chile SpA
- Fundación: 2017
- Ubicación: Santiago, Chile
- Servicio: Seguridad privada con guardias certificados OS-10
- Hitos: 2017 (fundación), 2019 (50 clientes), 2021 (centro de monitoreo propio),
  2023 (500+ guardias, 14 comunas), 2024 (Guard Pod - torre solar autónoma)

FORMATO DE RESPUESTA — JSON array:
[
  { "year": "YYYY", "title": "Título corto (3-8 palabras)", "description": "Descripción de 1-2 oraciones (40-80 palabras)" }
]

REGLAS:
- Mínimo 5 eventos, máximo 7
- Años cronológicos ascendentes
- Cada evento debe ser verosímil para empresa de seguridad chilena
- Tono: profesional, orgulloso pero modesto, chileno
- NO uses placeholders. Contenido original y listo para publicar.

Responde SOLO con el array JSON. Sin markdown, sin explicaciones.
```

### 11.2 Stats

```
Genera la sección STATS (números clave) para /nosotros de GuardMan Chile.

DATOS REALES:
- Guardias: 500+
- Clientes: 200+
- Años: 8+
- Comunas: 14
- Rating: 4.8/5

FORMATO — JSON array:
[
  { "value": "500+", "label": "Guardias certificados", "icon": "👮" }
]

REGLAS:
- Mínimo 4 stats, máximo 6
- Valores con símbolos (+, %, /5)
- Labels cortos (2-4 palabras)
- Icons opcionales (emoji)
- Responde SOLO con JSON array.
```

### 11.3 Values

```
Genera la sección VALUES (valores corporativos) para /nosotros de GuardMan Chile.

FORMATO — JSON array:
[
  { "title": "Valor (2-4 palabras)", "description": "Descripción de 1-2 oraciones" }
]

REGLAS:
- Mínimo 3 valores, máximo 5
- Títulos cortos y memorables
- Descripciones concretas (no genéricas)
- Alineados con seguridad privada y Chile
- Responde SOLO con JSON array.
```

### 11.4 Differentiators

```
Genera la sección DIFFERENTIATORS para /nosotros de GuardMan Chile.

DATOS REALES:
- Única empresa con Guard Pod (torre solar autónoma)
- Centro de monitoreo propio 24/7
- Certificación OS-10
- 8+ años de experiencia
- Cobertura en 14 comunas

FORMATO — JSON array:
[
  { "title": "Diferenciador", "description": "Explicación", "icon": "emoji" }
]

REGLAS:
- Mínimo 4, máximo 6
- Cada diferenciador debe ser verificable
- NO uses frases genéricas ("calidad", "compromiso")
- Responde SOLO con JSON array.
```

### 11.5 Certifications

```
Genera la sección CERTIFICATIONS para /nosotros de GuardMan Chile.

DATOS REALES:
- OS-10: autorización de Carabineros de Chile
- Ley 21.157: normativa de seguridad privada
- ISO 9001: gestión de calidad (si aplica)
- Seguro de responsabilidad civil

FORMATO — JSON array:
[
  { "title": "Nombre certificación", "description": "Qué significa para el cliente" }
]

REGLAS:
- Mínimo 3, máximo 5
- Descripción orientada al cliente ("esto te protege de...")
- Responde SOLO con JSON array.
```

### 11.6 Staff

```
Genera la sección STAFF para /nosotros de GuardMan Chile.

DATOS REALES:
- Guardias certificados OS-10
- Capacitación continua
- Centro de monitoreo propio
- 8+ años experiencia
- Coordinación con Carabineros

FORMATO — JSON object:
{
  "image": "/images/nosotros_seccion.webp",
  "traits": [
    "Característica 1 (15-30 palabras)",
    "Característica 2 (15-30 palabras)",
    ...
  ]
}

REGLAS:
- Mínimo 4 traits, máximo 6
- Cada trait describe una fortaleza del personal
- Tono: orgulloso pero profesional
- Responde SOLO con JSON object.
```

### 11.7 CTA

```
Genera la sección CTA (call-to-action final) para /nosotros de GuardMan Chile.

FORMATO — JSON object:
{
  "heading": "Título CTA (5-10 palabras)",
  "subheading": "Subtítulo opcional (10-20 palabras)",
  "button_text": "Texto botón (2-4 palabras)",
  "button_href": "/contacto"
}

REGLAS:
- Heading orientado a acción
- Button text con verbo imperativo
- Responde SOLO con JSON object.
```

---

## 12. Decisiones Pendientes

| # | Decisión | Opciones | Recomendación |
|---|----------|----------|---------------|
| 1 | ¿Zod o validación manual? | Zod (type-safe) vs. funciones manuales | **Zod** si está instalado, sino manual |
| 2 | ¿Paralelo o secuencial? | 7 calls a la vez vs. 1 por 1 | **Paralelo con límite 3** (p-limit) |
| 3 | ¿Versionar por sección? | Nueva tabla vs. solo content_versions | **Nueva tabla `section_versions`** |
| 4 | ¿Bulk "Generar Todo"? | Sí vs. No | **Sí**, con progreso visual |
| 5 | ¿Validación strict o lax? | Rechazar si falta 1 campo vs. aceptar parcial | **Strict** — mejor regenerar que publicar incompleto |

---

*Plan creado por pi coding agent — 2026-05-10*
*Basado en análisis de: src/services/ai.ts, src/services/content-generation.ts, src/api/routes/cms.ts, src/ssr/site-renderer.ts, guardman-admin-ui/src/components/CMS/CMSPage.tsx*

---

## Apéndice: Ejecución del Plan (2026-05-10)

### Implementado

| Componente | Archivo | Descripción |
|-----------|---------|-------------|
| Validadores de sección | `src/services/section-validators.ts` | 7 validadores manuales (timeline, stats, values, differentiators, certifications, staff, cta) |
| Merge seguro | `src/services/section-merge.ts` | Reemplaza solo la sección pedida, preserva el resto |
| Generación modular AI | `src/services/ai.ts` → `callDeepSeekForSection()` | 7 prompts focalizados, ~200 tokens cada uno |
| Servicio de generación | `src/services/section-generation.ts` | Orquestador: AI → validar → retry hasta 2× → persistir |
| Endpoint sección | `POST /api/cms/generate-section` | Genera 1 sección con validación strict |
| Endpoint bulk | `POST /api/cms/generate-all-sections` | Genera N secciones en paralelo (límite 3) |
| Migración D1 | `sql/migrations/section-versions.sql` | Tabla para versionado granular por sección |
| Hook frontend | `src/hooks/useSectionGenerator.ts` | `generate()`, `generateAll()`, loading states |
| Botones en CMS | `CMSPage.tsx` → StaticPageEditor | 🤖 Generar por sección + 🤖 Generar Todo |

### Resultados

```
Backend:  141 tests · 11 suites
Frontend:  51 tests · 8 suites
Total:    192 tests · 0 failed

Version:  dd64273c-409f-44b7-874b-c701da156700
URL:      https://guardman.oficinadesarrollo33.workers.dev
```

### Cómo usar
1. Ve a https://guardman.oficinadesarrollo33.workers.dev/admin/
2. Inicia sesión
3. Ve a CMS → Páginas → Nosotros
4. Verás botones 🤖 Generar en cada sección (timeline, stats, etc.)
5. Click "🤖 Generar Todo" para llenar todas las secciones de una vez
6. La IA genera 1 sección a la vez, con validación y retry automático
