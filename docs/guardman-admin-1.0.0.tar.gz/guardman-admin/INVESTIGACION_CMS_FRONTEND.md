# Investigación CMS ↔ Frontend Público — Mapeo Completo

**Fecha:** 2026-05-08  
**Objetivo:** Identificar página por página qué elementos del sitio público están conectados al CMS y qué falta para que el CMS maneje el 100%.

---

## Resumen Ejecutivo

Se analizaron **16 tipos de páginas** del sitio público y su conexión con el editor CMS en `/admin`. El resultado:

- **Páginas con CMS completo:** 3 (Guard Pod, Ajax Systems, Homepage)
- **Páginas con CMS parcial:** 8 (Nosotros, Servicios, Ubicaciones, Sectores, Combos, Contacto, Cotización, Blog)
- **Páginas sin CMS:** 2 (Privacidad, Términos — solo SEO + body HTML crudo)
- **Componentes globales sin CMS:** 3 (Header, Footer, Gracias)

**Cobertura actual estimada: ~55% del contenido es CMS-editable.**

---

## Arquitectura General

### Flujo de datos CMS → SSR

```
┌─────────────────┐     ┌──────────────────┐     ┌───────────────────┐
│  Admin CMS UI    │────▶│  CMS API Routes  │────▶│  D1 Database      │
│  (CMSPage.tsx)   │     │  (cms.ts)        │     │  - static_page_content
│                  │     │                  │     │  - content_versions
│  Campos editados │     │  Guarda JSON +   │     │  - combo_content
│  por el usuario  │     │  columnas flat   │     │  - blog_posts
└─────────────────┘     └──────────────────┘     └───────────────────┘
                                                          │
                                                          ▼
┌─────────────────┐     ┌──────────────────┐     ┌───────────────────┐
│  Sitio Público   │◀────│  site-renderer   │◀────│  site-data.ts     │
│  (HTML final)    │     │  (SSR builders)  │     │  (fetchers D1+R2) │
└─────────────────┘     └──────────────────┘     └───────────────────┘
```

### Tablas involucradas

| Tabla | Propósito | Páginas que la usan |
|-------|-----------|---------------------|
| `static_page_content` | Páginas estáticas (columnas flat + content_json) | Homepage, Nosotros, Guard Pod, Ajax, Contacto, Cotización, Privacidad, Términos |
| `content_versions` | Versionado de contenido SEO generado | Servicios, Ubicaciones, Sectores |
| `services` | Datos maestros de servicios | Servicios, Homepage |
| `locations` | Datos maestros de ubicaciones | Ubicaciones, Homepage |
| `sectors` | Datos maestros de sectores | Sectores, Homepage |
| `combo_content` | Contenido servicio×ubicación | Combos |
| `media_library` + `media_entities` | Biblioteca de medios + asignaciones | Todas (hero images) |
| `blog_posts` | Posts del blog | Blog |

---

## MAPA COMPLETO: Página por Página

---

### PÁGINA 1: Homepage (`/`)

**Builder:** `buildHomepage()` en site-renderer.ts  
**Fuente de datos:** `fetchHomepage()` + `getStaticPageData('homepage')` → `static_page_content`

| Sección | Elemento en SSR | Campo CMS | ¿Conectado? | Notas |
|---------|----------------|-----------|:-----------:|-------|
| **SEO** | `<title>`, `<meta description>` | `meta_title`, `meta_description` | ✅ | Via static_page_content |
| **Hero** | H1 | `hero_heading` | ✅ | |
| | Subtítulo | `hero_subheading` | ✅ | |
| | Imagen de fondo | `hero_image` | ✅ | También via `content_json.content.hero.background_image` |
| | Badge | `hero_badge` | ✅ | |
| | CTAs | `hero.ctas[]` | ✅ | Via content_json |
| | Teléfono | `hero.phone` | ✅ | Via content_json |
| **Nosotros** | Badge/label | `nosotros.badge` | ✅ | |
| | Título H2 | `nosotros.title` | ✅ | |
| | Párrafo | `nosotros.paragraph` | ✅ | |
| | Imagen | `nosotros.image` | ✅ | |
| | Image badge | `nosotros.image_badge` | ✅ | |
| | CTA text | `nosotros.cta_text` | ✅ | |
| | CTA link | `nosotros.cta_link` | ✅ | |
| | Features | `nosotros.features[]` | ❌ | El CMS tiene `homeNosotrosFeatures` pero NO hay editor UI en HomepageSection |
| **Servicios** | Título | `servicios.title` | ✅ | |
| | Subtítulo | `servicios.subtitle` | ✅ | |
| | CTA text | `servicios.cta_text` | ✅ | |
| | CTA link | `servicios.cta_link` | ✅ | |
| | Grid de servicios | `homeServices[]` | ❌ | **Viene de D1 `services` table, no editable desde CMS.** Solo se puede cambiar el orden/nombre en BD directamente |
| | Iconos por servicio | `SERVICE_ICONS{}` | ❌ | **Hardcodeado** en site-renderer.ts |
| **Guard Pod** | Badge | `guardpod.badge` | ✅ | |
| | Título | `guardpod.title` | ✅ | |
| | Párrafo | `guardpod.paragraph` | ✅ | |
| | Imagen | `guardpod.image` | ✅ | |
| | Image badge | `guardpod.image_badge` | ✅ | |
| | CTA text | `guardpod.cta_text` | ✅ | |
| | CTA link | `guardpod.cta_link` | ✅ | |
| | Features tiles | `homeGuardPodFeatures[]` | ❌ | **No hay editor UI**. Los datos vienen de `fetchHomepage()` pero no se pueden editar |
| **Sectores** | Título | `sectores.title` | ✅ | |
| | Subtítulo | `sectores.subtitle` | ✅ | |
| | CTA text | `sectores.cta_text` | ✅ | |
| | CTA link | `sectores.cta_link` | ✅ | |
| | Grid de sectores | `homeSectors[]` | ❌ | **Viene de D1 `sectors`, no CMS** |
| | Imagen por sector | `/images/sector-{slug}.webp` | ❌ | **Hardcodeado** nombre de archivo |
| **Ajax Systems** | Badge | `ajax.badge` | ✅ | |
| | Título | `ajax.title` | ✅ | |
| | Párrafo | `ajax.paragraph` | ✅ | |
| | Imagen | `ajax.image` | ✅ | |
| | Image badge | `ajax.image_badge` | ✅ | |
| | CTA text | `ajax.cta_text` | ✅ | |
| | CTA link | `ajax.cta_link` | ✅ | |
| | Checklist | Hardcodeado | ❌ | **4 items `<li>` hardcodeados** en `buildHomepage()` |
| **Ubicaciones** | Badge | `ubicaciones.badge` | ✅ | |
| | Título | `ubicaciones.title` | ✅ | |
| | Subtítulo | `ubicaciones.subtitle` | ✅ | |
| | CTA text | `ubicaciones.cta_text` | ✅ | |
| | CTA link | `ubicaciones.cta_link` | ✅ | |
| | Zonas + comunas | `homeZones[]` | ❌ | **Viene de D1, no CMS** |
| | Mapa estático | Auto-generado | ❌ | Se genera desde coordenadas de locations |
| **Clientes** | Título | `clientes.title` | ✅ | |
| | Subtítulo | `clientes.subtitle` | ✅ | |
| | Logos | `homeClientLogos[]` | ❌ | **Viene de media_entities, no hay editor UI** |
| | CTA text | `clientes.cta_text` | ✅ | |
| | CTA link | `clientes.cta_link` | ✅ | |
| **CTA Final** | Badge | `cta_final.badge` | ✅ | |
| | Título | `cta_final.title` | ✅ | |
| | Subtítulo | `cta_final.subtitle` | ✅ | |
| | CTA 1 text/link | `cta_final.cta1_text/cta1_link` | ✅ | |
| | CTA 2 text/link | `cta_final.cta2_text/cta2_link` | ✅ | |

**Cobertura Homepage: ~70%** — La mayoría de textos/CTAs son editables. Lo que falta: features arrays, servicios grid, sectores grid, zonas, logos clientes, checklist Ajax.

---

### PÁGINA 2: Servicios (`/servicios/{slug}`)

**Builder:** `buildDetailPage()` → usa `hero()` + `buildSections()` + `sidebar()` + `cta()`  
**Fuente de datos:** `fetchServicePage()` → `services` table + `content_versions`

| Sección | Elemento en SSR | Campo CMS | ¿Conectado? | Notas |
|---------|----------------|-----------|:-----------:|-------|
| **SEO** | `<title>` | `meta.title` | ✅ | Via content_json → seo.title |
| | `<meta description>` | `meta.description` | ✅ | |
| | `<title>` fallback | `services.meta_title` o default | ⚠️ | Solo si no hay content_json |
| **Hero** | Imagen de fondo | `media_entities` → hero | ✅ | Prioriza media_entities sobre services.hero_image |
| | H1 | `sections.hero.heading` | ✅ | |
| | Subtítulo | `sections.hero.subheading` | ✅ | |
| | CTAs | Hardcodeado | ❌ | **Siempre "Cotizar Ahora" + "Ver cobertura", no CMS-editable** |
| **Intro** | Heading | `sections.intro.heading` | ✅ | |
| | Párrafos (3) | `sections.intro.paragraphs[]` | ✅ | |
| **Features** | Heading | `sections.features.heading` | ✅ | |
| | Items (checklist) | `sections.features.items[]` | ✅ | Strings simples |
| **Issues** | Items | `sections.issues.items[]` | ✅ | |
| **Staff** | Imagen | `staffImage` | ❌ | **Hardcodeado** `/images/nosotros_seccion.webp` |
| | Traits | `staffTraits` | ❌ | **Default hardcodeado** `DEFAULT_STAFF_TRAITS` |
| **Ubicaciones** | Lista | `locations[]` de D1 | ❌ | **De D1, no CMS** |
| | Combo links | Auto-generados | ❌ | |
| **FAQs** | Items | `sections.faqs.items[]` | ✅ | |
| **Sidebar** | Links "Otros servicios" | `allServices` de D1 | ❌ | **Dinámico de BD, no CMS** |
| | Tags de sectores | `sectorsJson` de services | ❌ | **De BD** |
| | CTA "Cotizar ahora" | Hardcodeado | ❌ | |
| **CTA** | Heading | `ctaHeading` | ❌ | **Generado automáticamente** `Solicita tu cotización de {name}` |
| | Subtítulo | `ctaSubheading` | ❌ | Hardcodeado |
| | Botón | `ctaButtonHref` | ❌ | Auto-generado `/cotizacion?service={slug}` |

**Cobertura Servicios: ~50%** — SEO, hero, intro, features, issues, FAQs son editables. No lo son: CTAs hero, staff, ubicaciones, sidebar, CTA final.

---

### PÁGINA 3: Ubicaciones (`/ubicaciones/{slug}`)

**Builder:** `buildDetailPage()`  
**Fuente de datos:** `fetchLocationPage()` → `locations` + `content_versions`

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | Via content_json |
| **Hero** | H1, subtítulo, zona dot | ⚠️ | H1 y zona dot vienen de `locations` table (no CMS) |
| | Hero image | ❌ | **Sin soporte hero image para ubicaciones** |
| **Intro** | Heading, párrafos | ✅ | |
| **Features** | Items | ✅ | |
| **Services grid** | Lista de servicios | ❌ | **Viene de combo_content + services de D1** |
| **Mapa** | Leaflet map | ❌ | **Coordenadas de `locations` table (lat/lng)** |
| **Sidebar** | Links | ❌ | Dinámico de BD |
| **CTA** | Textos | ❌ | Auto-generado |

**Cobertura Ubicaciones: ~35%** — SEO, intro, features editables. Falta: hero image, mapa, services grid, sidebar, CTA.

---

### PÁGINA 4: Sectores (`/sectores/{slug}`)

**Builder:** `buildDetailPage()`  
**Fuente de datos:** `fetchSectorPage()` → `sectors` + `content_versions`

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Hero** | H1, subtítulo, color glow | ⚠️ | color_tag viene de `sectors` table |
| | Hero image | ❌ | **Sin soporte** |
| **Intro** | Heading, párrafos | ✅ | |
| **Features** | Items | ✅ | |
| **Issues** | Items | ✅ | |
| **Locations** | Lista | ❌ | **De D1** |
| **Sidebar** | Links, tags | ❌ | Dinámico |
| **CTA** | Textos | ❌ | Auto-generado |

**Cobertura Sectores: ~40%**

---

### PÁGINA 5: Combos (`/servicios/{service}/{location}`)

**Builder:** `buildDetailPage()`  
**Fuente de datos:** `fetchComboPage()` → `combo_content` + `services` + `locations`

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Hero** | H1, subtítulo | ✅ | Generado del combo |
| | Hero image | ❌ | **Sin soporte** |
| **Intro** | Párrafos | ✅ | |
| **Features** | Items | ✅ | |
| **Locations** | Nearby locations | ❌ | Dinámico de BD |
| **CTA** | Textos | ❌ | Auto-generado |

**Cobertura Combos: ~45%**

---

### PÁGINA 6: Nosotros (`/nosotros`)

**Builder:** `buildNosotrosPage()` → usa `NOSOTROS_HTML` estático O `buildNosotrosBody()` dinámico  
**Fuente de datos:** `static_page_content` (slug='nosotros') + `content_json`

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Hero** | H1, subtítulo | ✅ | Via content_json.hero |
| | Hero image | ❌ | **El hero de nosotros NO usa imagen** — es solo texto |
| **Stats** | Items `{value, label}` | ✅ | |
| **Timeline** | Items `{year, title, desc}` | ✅ | |
| **Values** | Items `{title, desc}` | ✅ | Solo si `c.values` existe en content_json |
| **Differentiators** | Items `{title, desc}` | ✅ | |
| **Certifications** | Items `{title, desc}` | ✅ | |
| **Staff** | Imagen, traits | ✅ | |
| **CTA** | heading, sub, button | ✅ | |

**⚠️ Problema:** `STATIC_SECTIONS['nosotros']` = `['stats','timeline','values','differentiators','certifications','staff']`  
El editor muestra estos arrays, PERO **falta la sección `cta`** en `STATIC_SECTIONS`. El CTA en `buildNosotrosBody()` lee de `c.cta` pero no hay editor UI.

**Cobertura Nosotros: ~85%** — Muy buena. Solo falta: CTA section en STATIC_SECTIONS, hero image.

---

### PÁGINA 7: Guard Pod (`/guard-pod`)

**Builder:** `buildGuardPodPage()` → `GUARDPOD_HTML` estático O `buildGuardPodBody()` dinámico  
**Fuente de datos:** `static_page_content` (slug='guard-pod')

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Hero** | Badge, H1, subtítulo | ✅ | |
| | Hero image/video | ✅ | Via `content_json.hero.image` |
| | Stats (3) | ✅ | |
| | CTAs | ❌ | **Hardcodeado** "Cotizar Guard Pod" + "Ver características" |
| **Intro** | Párrafos | ✅ | |
| | Split image | ⚠️ | **Repite hero image, no es independiente** |
| **Features** | Cards `{title, desc}` | ✅ | |
| **Problems** | Cards | ✅ | |
| **FAQs** | Items | ✅ | |
| **CTA** | Textos | ❌ | **Hardcodeado** en `buildGuardPodBody()` |

**Cobertura Guard Pod: ~75%**

---

### PÁGINA 8: Ajax Systems (`/ajax-systems`)

**Builder:** `buildAjaxPage()` → `AJAX_HTML` estático O `buildAjaxBody()` dinámico  
**Fuente de datos:** `static_page_content` (slug='ajax-systems')

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Hero** | Badge, H1, subtítulo | ✅ | |
| | Hero image/video | ✅ | |
| | Stats (3) | ✅ | |
| | CTAs | ❌ | **Hardcodeado** |
| **Intro** | Párrafos | ✅ | |
| | Split image | ⚠️ | **Repite hero image** |
| **Features** | Cards | ✅ | |
| **Problems/WhyUs** | Cards | ✅ | Lee `c.problems` o `c.whyUs` |
| **FAQs** | Items | ✅ | |
| **CTA** | Textos | ❌ | **Hardcodeado** |

**Cobertura Ajax: ~75%**

---

### PÁGINA 9: Contacto (`/contacto`)

**Builder:** `buildContactoPage()` → `CONTACTO_HTML` estático  
**Fuente de datos:** `static_page_content` (slug='contacto')

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | Solo seo.title y seo.description |
| **Hero** | H1 "Contáctanos" | ❌ | **Hardcodeado** en `CONTACTO_HTML` |
| | Subtítulo | ❌ | **Hardcodeado** |
| **Formulario** | Campos del form | ❌ | **HTML estático completo** |
| **Mapa** | Lat/lng, dirección | ❌ | **Hardcodeado** `-33.4569, -70.6483` |
| | Popup text | ❌ | **Hardcodeado** |

**STATIC_SECTIONS['contacto'] = []** — Sin secciones editoras.  
`STATIC_SECTIONS` está vacío: el CMS solo permite editar SEO.

**Cobertura Contacto: ~10%** — Solo SEO. El body completo es HTML estático.

---

### PÁGINA 10: Cotización (`/cotizacion`)

**Builder:** `buildCotizacionPage()` → `COTIZACION_HTML` estático  
**Fuente de datos:** `static_page_content` (slug='cotizacion')

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Hero** | H1, subtítulo | ❌ | **Hardcodeado** |
| **Formulario** | Campos | ❌ | **HTML estático completo** |

**STATIC_SECTIONS['cotizacion'] = ['trust_badges']**  
Pero `trust_badges` **no se procesa** en `StaticPageEditor` ni en `buildCotizacionPage()`.

**Cobertura Cotización: ~10%**

---

### PÁGINA 11: Privacidad (`/privacidad`)

**Builder:** `buildPrivacidadPage()` → `PRIVACIDAD_HTML`  
**Fuente de datos:** `static_page_content` (slug='privacidad')

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Body** | HTML completo | ⚠️ | `body_content` en content_json — **textarea crudo HTML** |

**Cobertura Privacidad: ~30%** — SEO + HTML crudo. No es wysiwyg.

---

### PÁGINA 12: Términos (`/terminos`)

**Builder:** `buildTerminosPage()` → `TERMINOS_HTML`  
**Fuente de datos:** `static_page_content` (slug='terminos')

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ✅ | |
| **Body** | HTML completo | ⚠️ | `body_content` — textarea crudo |

**Cobertura Términos: ~30%**

---

### PÁGINA 13: Blog (`/blog`, `/blog/{slug}`)

**Builder:** `buildBlogListing()` / `buildBlogPost()`  
**Fuente de datos:** `blog_posts` table

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **Listing** | Título, descripción | ❌ | **Hardcodeado** "Blog GuardMan" |
| **Posts** | CRUD completo | ✅ | Via `/api/cms/blog/*` |
| | Título, contenido, imagen | ✅ | |
| **SEO** | Por post | ✅ | |

**Cobertura Blog: ~60%** — CRUD de posts funciona. Falta: SEO del listing, layout personalizable.

---

### PÁGINA 14: Hub de Servicios (`/servicios`)

**Builder:** `buildHubPage()`  
**Fuente de datos:** `fetchHubPage()` → `services` table

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| **SEO** | title, description | ⚠️ | **Generado automáticamente**, no editable |
| **Hero** | H1, subtítulo | ❌ | **Hardcodeado** "Servicios de Seguridad" |
| **Grid** | Cards de servicios | ❌ | **De `services` table** — nombre, descripción, imagen |
| **CTA** | Textos | ❌ | **Hardcodeado** |

**Cobertura Hub Servicios: ~5%**

---

### PÁGINA 15: Hub de Sectores (`/sectores`)

**Builder:** `buildHubPage()`  
**Fuente de datos:** `fetchHubPage()` → `sectors` table

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| Todo | 100% dinámico de BD | ❌ | **Sin CMS** |

**Cobertura: ~0%**

---

### PÁGINA 16: Hub de Ubicaciones (`/ubicaciones`)

**Builder:** `buildHubPage()`  
**Fuente de datos:** `fetchHubPage()` → `locations` + agrupación por zona

| Sección | Elemento | CMS | Notas |
|---------|----------|:---:|-------|
| Todo | 100% dinámico de BD | ❌ | **Sin CMS** |

**Cobertura: ~0%**

---

### PÁGINA EXTRA: Gracias (`/gracias`)

**Builder:** `buildGraciasPage()`  
**Fuente de datos:** Ninguna (hardcodeado)

| Sección | CMS |
|---------|:---:|
| Todo el contenido | ❌ **100% hardcodeado** |

---

## COMPONENTES GLOBALES

### Header (`hdr()`)

| Elemento | CMS | Notas |
|----------|:---:|-------|
| Logo (SVG + texto "GuardMan") | ❌ | **Hardcodeado** |
| Nav: Servicios dropdown | ❌ | **De `services` table, sin CMS** |
| Nav: Ubicaciones dropdown | ❌ | **De `locations` table** |
| Nav: Sectores dropdown | ❌ | **De `sectors` table** |
| Nav: "Nosotros" link | ❌ | Hardcodeado |
| Nav: "Blog" link | ❌ | Hardcodeado |
| Teléfono | ❌ | **Hardcodeado** `+56 9 300 000 10` |
| Botón "Cotizar" | ❌ | **Hardcodeado** `/cotizacion` |

### Footer (`ftr()`)

| Elemento | CMS | Notas |
|----------|:---:|-------|
| Logo + descripción | ❌ | Hardcodeado |
| Links "Servicios" | ❌ | Hardcodeado (5 links) |
| Links "Empresa" | ❌ | Hardcodeado |
| Links "Contacto" | ❌ | **Hardcodeado** teléfono, email |
| Redes sociales (IG, YT) | ❌ | Hardcodeado |
| Copyright | ❌ | Auto-año pero RUT hardcodeado |
| Dirección | ❌ | Hardcodeado |

---

## RESUMEN DE BRECHAS

### ❌ Elementos Hardcodeados que NO son CMS-editables

#### Prioridad ALTA (afectan muchas páginas)

| # | Elemento | Aparece en | Esfuerzo |
|---|----------|------------|----------|
| 1 | **Header completo** (logo, nav, teléfono, CTA) | Todas las páginas | Medio |
| 2 | **Footer completo** (links, contacto, redes, dirección) | Todas las páginas | Medio |
| 3 | **Hero CTAs** (texto + href de botones) | Guard Pod, Ajax, Servicios | Bajo |
| 4 | **CTA band** (texto final antes del footer) | Guard Pod, Ajax, Servicios, Hubs | Bajo |
| 5 | **Staff section** (imagen + traits) | Servicios | Bajo |
| 6 | **Sidebar** (links, tags, CTA) | Servicios, Ubicaciones, Sectores | Medio |

#### Prioridad MEDIA (afectan páginas específicas)

| # | Elemento | Aparece en | Esfuerzo |
|---|----------|------------|----------|
| 7 | **Contacto body** (hero, form, mapa) | `/contacto` | Alto (HTML estático grande) |
| 8 | **Cotización body** (hero, form) | `/cotizacion` | Alto |
| 9 | **Hub pages** (hero, grid, CTA) | `/servicios`, `/sectores`, `/ubicaciones` | Medio |
| 10 | **Gracias page** | `/gracias` | Bajo |
| 11 | **Blog listing** (título, descripción) | `/blog` | Bajo |
| 12 | **Homepage features arrays** (nosotros features, guardpod features, ajax checklist, client logos) | `/` | Medio |

#### Prioridad BAJA (nice-to-have)

| # | Elemento | Aparece en | Esfuerzo |
|---|----------|------------|----------|
| 13 | **Service icons** (`SERVICE_ICONS{}`) | Homepage, Hubs | Bajo |
| 14 | **Sector images** (`/images/sector-{slug}.webp`) | Homepage | Bajo |
| 15 | **Mapa estático homepage** | `/` | Bajo |
| 16 | **Service card images** | Homepage | Medio |
| 17 | **Blog post layout** | `/blog/{slug}` | Medio |

---

## PLAN DE IMPLEMENTACIÓN PROPUESTO

### Fase 1: CTAs + CTA Band (quick wins) — ~2 horas

**Archivos:** `CMSPage.tsx` (editor), `site-renderer.ts` (SSR)

1. Agregar campos de CTA al editor de:
   - Guard Pod: hero CTAs (2 botones) + CTA band (heading, sub, botón)
   - Ajax Systems: hero CTAs + CTA band
   - Servicios: hero CTAs + CTA band
   - Nosotros: agregar `'cta'` a `STATIC_SECTIONS`
2. Conectar en SSR los campos a los builders correspondientes

### Fase 2: Header + Footer configurable — ~4 horas

**Nuevo:** Tabla `site_settings` o uso de `static_page_content` slug=`'globals'`

1. Crear interfaz de "Site Settings" en `/admin`
2. Campos: logo, teléfono, email, dirección, RUT, redes sociales, nav links
3. `hdr()` y `ftr()` leen de BD con fallback a hardcodeado
4. Cachear en KV (TTL 1h)

### Fase 3: Staff + Sidebar — ~2 horas

1. Staff section: agregar campos `staff_image`, `staff_traits[]` al editor de servicios
2. Sidebar: permitir personalizar CTA heading, links manuales

### Fase 4: Contacto + Cotización — ~4 horas

1. Mover `CONTACTO_HTML` y `COTIZACION_HTML` a content_json
2. Agregar campos al `STATIC_SECTIONS`:
   - contacto: `hero` (H1, sub), `contact_info` (tel, email, dir, lat, lng)
   - cotizacion: `hero` (H1, sub), `form_config`
3. Builder dinámico en lugar de HTML estático

### Fase 5: Hub Pages — ~3 horas

1. SEO editable para `/servicios`, `/sectores`, `/ubicaciones`
2. Hero editable (H1, subtítulo)
3. CTA editable

### Fase 6: Homepage Features Arrays — ~3 horas

1. Nosotros features: editor de array `{title, description}` en homepage
2. Guard Pod features: editor de array en homepage
3. Ajax checklist: editor de array en homepage
4. Client logos: editor de array con ImagePicker

---

## Score Final por Página

| Página | Cobertura CMS | Prioridad mejorar |
|--------|:------------:|:-----------------:|
| Homepage | 70% | 🟡 Media |
| Servicios | 50% | 🟠 Alta |
| Nosotros | 85% | 🟢 Baja |
| Guard Pod | 75% | 🟡 Media |
| Ajax Systems | 75% | 🟡 Media |
| Ubicaciones | 35% | 🟠 Alta |
| Sectores | 40% | 🟠 Alta |
| Combos | 45% | 🟡 Media |
| Contacto | 10% | 🔴 Crítica |
| Cotización | 10% | 🔴 Crítica |
| Blog listing | 60% | 🟢 Baja |
| Blog posts | 80% | 🟢 Baja |
| Hub Servicios | 5% | 🟠 Alta |
| Hub Sectores | 0% | 🟠 Alta |
| Hub Ubicaciones | 0% | 🟠 Alta |
| Privacidad | 30% | 🟢 Baja |
| Términos | 30% | 🟢 Baja |
| Gracias | 0% | 🟢 Baja |
| **Header/Footer** | **0%** | **🔴 Crítica** |

**Cobertura global estimada: ~55%**

---

*Investigación generada por pi coding agent — 2026-05-08*
