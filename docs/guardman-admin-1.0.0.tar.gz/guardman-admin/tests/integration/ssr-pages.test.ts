import { describe, it, expect, beforeAll } from 'vitest';
import {
  buildHomepage,
  buildDetailPage,
  buildHubPage,
  buildNosotrosPage,
  buildGuardPodPage,
  buildAjaxPage,
  buildContactoPage,
  buildCotizacionPage,
  buildPrivacidadPage,
  buildTerminosPage,
  setSiteUrl,
  type SiteData,
} from '../../src/ssr/site-renderer';

// Gracias and 404/500 are inline in index.ts, test separately via string check

beforeAll(() => {
  setSiteUrl('https://guardman.oficinadesarrollo33.workers.dev');
});

function makeBaseData(): SiteData {
  return {
    title: 'T',
    description: 'D',
    canonical: '/',
    pageType: 'service',
    heroHeading: 'H',
    breadcrumbs: [{ label: 'Inicio', href: '/' }],
    sections: [],
  };
}

describe('INTEGRATION — SSR 16 Pages Render Valid HTML', () => {
  it('Page 1: Homepage', () => {
    const html = buildHomepage(makeBaseData());
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
    expect(html).toContain('GuardMan');
  });

  it('Page 2: Servicio detalle', () => {
    const d = makeBaseData();
    d.schemas = [{ '@context': 'https://schema.org', '@type': 'Service', name: 'Test' }];
    d.sections = [
      { type: 'intro', heading: 'I', paragraphs: ['P'] },
      { type: 'features', heading: 'F', items: ['F1'] },
      { type: 'issues', heading: 'Is', items: ['I1'] },
      { type: 'faq', heading: 'Q', items: [{ question: 'Q1', answer: 'A1' }] },
    ];
    const html = buildDetailPage(d);
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('P');
    expect(html).toContain('Q1');
    expect(html).toContain('application/ld+json');
  });

  it('Page 3: Ubicación detalle', () => {
    const d = makeBaseData();
    d.pageType = 'location';
    d.sections = [{ type: 'locations', heading: 'L', items: [{ slug: 'las-condes', name: 'Las Condes' }] }];
    const html = buildDetailPage(d);
    expect(html).toContain('Las Condes');
  });

  it('Page 4: Sector detalle', () => {
    const d = makeBaseData();
    d.pageType = 'sector';
    d.sections = [{ type: 'features', heading: 'F', items: ['F1'] }];
    const html = buildDetailPage(d);
    expect(html).toContain('F1');
  });

  it('Page 5: Combo detalle', () => {
    const d = makeBaseData();
    d.pageType = 'combo';
    d.heroHeading = 'Combo';
    d.sections = [{ type: 'intro', heading: 'I', paragraphs: ['P'] }];
    const html = buildDetailPage(d);
    expect(html).toContain('Combo');
  });

  it('Page 6: Nosotros', () => {
    const html = buildNosotrosPage();
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
  });

  it('Page 7: Guard Pod', () => {
    const html = buildGuardPodPage();
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
  });

  it('Page 8: Ajax', () => {
    const html = buildAjaxPage();
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
  });

  it('Page 9: Contacto', () => {
    const html = buildContactoPage();
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
    expect(html).toContain('leaflet');
    expect(html).toContain('tel:');
  });

  it('Page 10: Cotización', () => {
    const html = buildCotizacionPage();
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
    expect(html).toContain('form');
  });

  it('Page 11: Privacidad', () => {
    const html = buildPrivacidadPage();
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
  });

  it('Page 12: Términos', () => {
    const html = buildTerminosPage();
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
  });

  it('Page 13: Hub Servicios', () => {
    const d = makeBaseData();
    d.sections = [{ type: 'locations', heading: 'S', items: [{ slug: 's1', name: 'S1' }] }];
    const html = buildHubPage(d);
    expect(html).toMatch(/^<!doctype html>/i);
    expect(html).toContain('</html>');
  });

  it('Page 14: Hub Sectores', () => {
    const d = makeBaseData();
    d.pageType = 'sector';
    const html = buildHubPage(d);
    expect(html).toMatch(/^<!doctype html>/i);
  });

  it('Page 15: Hub Ubicaciones', () => {
    const d = makeBaseData();
    d.pageType = 'location';
    const html = buildHubPage(d);
    expect(html).toMatch(/^<!doctype html>/i);
  });

  it('Page 16: Gracias (inline in index.ts)', () => {
    const indexSource = require('fs').readFileSync('./src/index.ts', 'utf-8');
    expect(indexSource).toContain('buildGraciasPage');
    expect(indexSource).toContain('gracias');
  });

  it('All pages must include CSP header logic or base security tags', () => {
    const indexSource = require('fs').readFileSync('./src/index.ts', 'utf-8');
    expect(indexSource).toContain("Content-Security-Policy");
  });
});
