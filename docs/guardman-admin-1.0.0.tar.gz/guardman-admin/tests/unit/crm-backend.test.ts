import { describe, it, expect, vi } from 'vitest';
import { handleCRMDashboard } from '../../src/api/routes/crm/dashboard';
import { handlePipeline } from '../../src/api/routes/crm/pipeline';
import { handleListLeads, handleCreateLead, handleGetLead, handleUpdateLead } from '../../src/api/routes/crm/leads';
import { handleListClients, handleGetClient, handleCreateClient } from '../../src/api/routes/crm/clients';

// Minimal D1 mock builder
function makeDB(rows: any[] = []) {
  return {
    prepare: vi.fn(() => ({
      bind: vi.fn(() => ({
        all: vi.fn(async () => ({ results: rows })),
        first: vi.fn(async () => rows[0] || null),
        run: vi.fn(async () => ({ meta: { last_row_id: 999 } })),
      })),
      all: vi.fn(async () => ({ results: rows })),
      first: vi.fn(async () => rows[0] || null),
      run: vi.fn(async () => ({ meta: { last_row_id: 999 } })),
    })),
  };
}

// Helper to read JSON response
async function readJSON(res: Response) {
  return res.json();
}

describe('CRM BACKEND FORENSIC AUDIT', () => {
  describe('Dashboard', () => {
    it('should return aggregated lead stats', async () => {
      const db = makeDB([
        { status: 'new', cnt: 3, total_value: 1000000 },
        { status: 'won', cnt: 1, total_value: 500000 },
      ]);
      const env = { DB: db };
      const res = await handleCRMDashboard(env);
      const data = await readJSON(res);
      expect(data.ok).toBe(true);
      expect(data.data.leads.new.cnt).toBe(3);
      expect(data.data.leads.won.cnt).toBe(1);
      expect(data.data.leads.lost.cnt).toBe(0); // default
    });

    it('should calculate pipeline weighted value', async () => {
      const db = makeDB([{ weighted: 1234567 }]);
      const env = { DB: db };
      const res = await handleCRMDashboard(env);
      const data = await readJSON(res);
      expect(data.data.pipeline_weighted_value).toBe(1234567);
    });

    it('should include mi_dia buckets', async () => {
      const db = makeDB([]);
      const env = { DB: db };
      const res = await handleCRMDashboard(env);
      const data = await readJSON(res);
      expect(data.data.mi_dia).toBeDefined();
      expect(Array.isArray(data.data.mi_dia.urgent)).toBe(true);
      expect(Array.isArray(data.data.mi_dia.retry)).toBe(true);
      expect(Array.isArray(data.data.mi_dia.visits)).toBe(true);
      expect(Array.isArray(data.data.mi_dia.followup)).toBe(true);
      expect(Array.isArray(data.data.mi_dia.frozen)).toBe(true);
    });
  });

  describe('Pipeline', () => {
    it('should return all 7 stages', async () => {
      const db = makeDB([]);
      const env = { DB: db };
      const res = await handlePipeline(env);
      const data = await readJSON(res);
      expect(data.ok).toBe(true);
      expect(Object.keys(data.data.pipeline)).toEqual([
        'new', 'contacted', 'visit_scheduled', 'proposal_sent', 'negotiation', 'won', 'lost'
      ]);
    });

    it('should include summary object with numeric fields', async () => {
      const env = {
        DB: {
          prepare: vi.fn((sql: string) => {
            const isSummary = sql.includes('COUNT(*)') || sql.includes('SUM(') || sql.includes('AVG(');
            return {
              bind: vi.fn(() => ({
                all: vi.fn(async () => ({ results: [] })),
                first: vi.fn(async () => ({
                  cnt: 5, val: 2500000, avg: 0.35,
                })),
              })),
              all: vi.fn(async () => ({ results: [] })),
              first: vi.fn(async () => ({
                cnt: 5, val: 2500000, avg: 0.35,
              })),
            };
          }),
        },
      };
      const res = await handlePipeline(env);
      const data = await readJSON(res);
      expect(data.data.summary).toBeDefined();
      expect(typeof data.data.summary.total).toBe('number');
      expect(typeof data.data.summary.weighted_value).toBe('number');
      expect(typeof data.data.summary.avg_probability).toBe('number');
    });
  });

  describe('Leads', () => {
    it('list leads should support status filter', async () => {
      const db = makeDB([
        { id: 1, contact_name: 'A', status: 'new' },
        { id: 2, contact_name: 'B', status: 'new' },
      ]);
      const env = { DB: db };
      const url = new URL('https://example.com/api/crm/leads?status=new');
      const res = await handleListLeads(url, env);
      const data = await readJSON(res);
      expect(data.ok).toBe(true);
      expect(data.data).toHaveLength(2);
    });

    it('create lead should require contact_name', async () => {
      const db = makeDB([]);
      const env = { DB: db };
      const request = new Request('https://example.com/api/crm/leads', {
        method: 'POST',
        body: JSON.stringify({ contact_email: 'test@test.cl' }),
      });
      // Since the handler doesn't validate, it will try to insert with null contact_name
      // but our mock returns success. This test documents the MISSING validation.
      const res = await handleCreateLead(request, env);
      const data = await readJSON(res);
      // The handler currently allows this — this test serves as documentation of the bug
      expect(data.ok).toBe(true); // BUG: should be false if validation existed
    });

    it('get lead should return 404 for non-existent lead', async () => {
      const db = makeDB([]);
      const env = { DB: db };
      const res = await handleGetLead(99999, env);
      expect(res.status).toBe(404);
    });

    it('update lead should require loss_reason when status=lost', async () => {
      const db = makeDB([]);
      const env = { DB: db };
      const request = new Request('https://example.com/api/crm/leads/1', {
        method: 'PUT',
        body: JSON.stringify({ status: 'lost' }),
      });
      const res = await handleUpdateLead(1, request, env);
      expect(res.status).toBe(400);
      const data = await readJSON(res);
      expect(data.error).toContain('motivo de pérdida');
    });
  });

  describe('Clients', () => {
    it('list clients should support status filter', async () => {
      const db = makeDB([
        { id: 101, company_name: 'A', status: 'active' },
      ]);
      const env = { DB: db };
      const url = new URL('https://example.com/api/crm/clients?status=active');
      const res = await handleListClients(url, env);
      const data = await readJSON(res);
      expect(data.ok).toBe(true);
    });

    it('get client should include services and interactions', async () => {
      const db = makeDB([
        { id: 101, company_name: 'Test Client' },
      ]);
      const env = { DB: db };
      const res = await handleGetClient(101, env);
      const data = await readJSON(res);
      expect(data.ok).toBe(true);
      expect(data.data.client).toBeDefined();
      expect(Array.isArray(data.data.services)).toBe(true);
      expect(Array.isArray(data.data.interactions)).toBe(true);
    });

    it('create client should auto-update lead status to won', async () => {
      const db = makeDB([]);
      const env = { DB: db };
      const request = new Request('https://example.com/api/crm/clients', {
        method: 'POST',
        body: JSON.stringify({
          lead_id: 6,
          company_name: 'Test Co',
          primary_contact_name: 'Test',
          status: 'active',
        }),
      });
      const res = await handleCreateClient(request, env);
      const data = await readJSON(res);
      expect(data.ok).toBe(true);
      // The handler calls UPDATE intel_leads SET status='won' WHERE id=?
      // We verify the DB was called for the update
      const updateCall = db.prepare.mock.calls.find((c: any) =>
        c[0].includes("UPDATE intel_leads SET status = 'won'")
      );
      expect(updateCall).toBeDefined();
    });
  });

  describe('Security & Business Logic', () => {
    it('CRM routes pattern should match /api/crm/* paths', async () => {
      const { crmRoutes } = await import('../../src/api/routes/crm/index');
      expect(crmRoutes[0].pattern.test('/api/crm/dashboard')).toBe(true);
      expect(crmRoutes[0].pattern.test('/api/crm/leads')).toBe(true);
      expect(crmRoutes[0].pattern.test('/api/crm/leads/123')).toBe(true);
      expect(crmRoutes[0].pattern.test('/api/crm/leads/123/interactions')).toBe(true);
      expect(crmRoutes[0].pattern.test('/api/crm/clients')).toBe(true);
      expect(crmRoutes[0].pattern.test('/api/crm/pipeline')).toBe(true);
      expect(crmRoutes[0].pattern.test('/api/other')).toBe(false);
    });

    it('handleUpdateLead should enforce visit requirement before proposal_sent', async () => {
      const db = makeDB([]); // no visits
      const env = { DB: db };
      const request = new Request('https://example.com/api/crm/leads/1', {
        method: 'PUT',
        body: JSON.stringify({ status: 'proposal_sent' }),
      });
      const res = await handleUpdateLead(1, request, env);
      expect(res.status).toBe(400);
      const data = await readJSON(res);
      expect(data.error).toContain('visita tecnica');
    });
  });
});
