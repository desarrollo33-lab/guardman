import { describe, it, expect } from 'vitest';
import { generateFallbackContent, callDeepSeekAI } from '../../src/services/ai';

// We can't easily test callDeepSeekAI without mocking fetch + env,
// but we can verify the module exports and fallback behavior.

describe('AI SERVICE FORENSIC AUDIT', () => {
  describe('H-01 Fix: DeepSeek Consolidation', () => {
    it('should export callDeepSeekAI (not callMiniMaxAI)', () => {
      expect(typeof callDeepSeekAI).toBe('function');
    });

    it('should NOT export callMiniMaxAI', async () => {
      const aiModule = await import('../../src/services/ai');
      expect((aiModule as any).callMiniMaxAI).toBeUndefined();
    });

    it('source must NOT contain api.minimax.io references', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/services/ai.ts', 'utf-8');
      expect(source).not.toContain('api.minimax.io');
      expect(source).not.toContain('callMiniMaxAI');
    });

    it('source must point to api.deepseek.com', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/services/ai.ts', 'utf-8');
      expect(source).toContain('api.deepseek.com');
    });
  });

  describe('H-05 Fix: Homepage entityType check', () => {
    it('source must accept both "home" and "homepage" entity types', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/services/ai.ts', 'utf-8');
      const condition = source.match(/entityType\s*===?\s*['"]home['"]\s*\|\|\s*entityType\s*===?\s*['"]homepage['"]/);
      expect(condition).toBeTruthy();
    });
  });

  describe('H-03 Fix: JSON.parse must be guarded', () => {
    it('should wrap JSON.parse in try/catch or safe parser', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/services/ai.ts', 'utf-8');
      const jsonParseLines = source.split('\n').map((l: string, i: number) => ({ line: l, num: i + 1 }));
      const parseLine = jsonParseLines.find((l: any) => l.line.includes('JSON.parse(text)'));
      expect(parseLine).toBeTruthy();
      // Verify there is try/catch within scope (before or after)
      const surrounding = source.split('\n').slice(Math.max(0, parseLine.num - 15), parseLine.num + 15).join('\n');
      expect(surrounding).toMatch(/\btry\b/);
      expect(surrounding).toMatch(/catch\s*\(/);
    });
  });

  describe('generateFallbackContent', () => {
    it('should produce valid GeneratedContent for service type', () => {
      const result = generateFallbackContent('service', 'guardias-de-seguridad', 'Guardias de Seguridad');
      expect(result.sections).toBeDefined();
      expect(result.sections.hero).toBeDefined();
      expect(result.sections.hero.heading).toContain('Guardias de Seguridad');
      expect(result.sections.intro).toBeDefined();
      expect(result.sections.features).toBeDefined();
      expect(result.sections.issues).toBeDefined();
      expect(result.sections.stats).toBeDefined();
      expect(result.sections.faqs).toBeDefined();
      expect(result.sections.cta).toBeDefined();
      expect(result.sections.meta).toBeDefined();
      expect(result._meta).toBeDefined();
    });

    it('should produce valid GeneratedContent for location type', () => {
      const result = generateFallbackContent('location', 'las-condes', 'Las Condes');
      expect(result.sections.hero.heading).toContain('Las Condes');
      expect(result.sections.coverage).toBeDefined();
    });

    it('should produce valid GeneratedContent for sector type', () => {
      const result = generateFallbackContent('sector', 'comercial', 'Comercial');
      expect(result.sections.hero.heading).toContain('Comercial');
    });

    it('should produce valid GeneratedContent for homepage type', () => {
      const result = generateFallbackContent('home', 'homepage', 'Homepage');
      expect(result.sections).toBeDefined();
    });

    it('should produce valid GeneratedContent for homepage (entityType=homepage)', () => {
      const result = generateFallbackContent('homepage', 'homepage', 'Homepage');
      expect(result.sections).toBeDefined();
    });
  });

  describe('Image path enforcement', () => {
    it('fallback content hero image should be local path', () => {
      const result = generateFallbackContent('service', 'guardias-de-seguridad', 'Guardias de Seguridad');
      if (result.sections.hero?.image) {
        expect(result.sections.hero.image.startsWith('/images/')).toBe(true);
      }
    });
  });

  describe('Foreign word fixes', () => {
    it('should not contain banned foreign words in fallback content', () => {
      const result = generateFallbackContent('service', 'test', 'Test');
      const text = JSON.stringify(result).toLowerCase();
      const banned = ['vandalism', 'residential', 'advisable', 'operate', 'commercial', 'stockage', 'documentation', 'handle'];
      for (const word of banned) {
        expect(text).not.toContain(word);
      }
    });
  });
});
