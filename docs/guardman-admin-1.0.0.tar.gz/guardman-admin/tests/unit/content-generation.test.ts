import { describe, it, expect, vi, beforeEach } from 'vitest';
import { generateContent } from '../../src/services/content-generation';
import type { Env } from '../../src/types';

// Mock the ai module
vi.mock('../../src/services/ai', async () => {
  const actual = await vi.importActual('../../src/services/ai');
  return {
    ...actual as any,
    callDeepSeekAI: vi.fn(async (_entityType, _entitySlug, entityName, _env) => {
      return {
        sections: {
          hero: { heading: entityName, subheading: 'Test sub', image: '/images/test.webp' },
          intro: { heading: 'Intro', paragraphs: ['P1'] },
          features: { heading: 'Features', items: ['F1'] },
          issues: { heading: 'Issues', items: ['I1'] },
          stats: { heading: 'Stats', items: [{ label: 'L', value: 'V' }] },
          faqs: { heading: 'FAQs', items: [{ question: 'Q?', answer: 'A.' }] },
          cta: { heading: 'CTA', subheading: 'Sub', button: 'Btn' },
          meta: { title: 'T', description: 'D' },
        },
        _meta: { generated_by: 'ai', generated_at: new Date().toISOString() },
      };
    }),
  };
});

// Mock other services
vi.mock('../../src/services/brand-context', () => ({
  loadBrandContext: vi.fn(async () => null),
  buildBrandPromptBlock: vi.fn(() => ''),
}));

vi.mock('../../src/services/banned-patterns', () => ({
  scanBannedPatterns: vi.fn(() => ({ passed: true, violations: [], genericPhrases: [] })),
}));

vi.mock('../../src/services/guardrails', () => ({
  checkContentGuardrails: vi.fn(() => ({ passed: true, violations: [] })),
}));

vi.mock('../../src/services/quality-review', () => ({
  reviewWithWorkersAI: vi.fn(async () => ({
    score: 85,
    seo: 80,
    content: 85,
    structure: 90,
    voiceAlignment: 80,
    feedback: 'Good',
    suggestions: [],
    genericSections: [],
  })),
}));

vi.mock('../../src/services/de-generic-pass', () => ({
  deGenericPass: vi.fn(async (_env, content) => content),
}));

vi.mock('../../src/services/scoring', () => ({
  calculateContentScore: vi.fn(() => ({ score: 80, details: {} })),
}));

function makeEnv(): Env {
  return {
    DB: {} as any,
    IMAGES: {} as any,
    CACHE: {} as any,
    ASSETS: {} as any,
    AI: null,
    AI_SEARCH: null,
    AUTH_TOKEN: 'test',
    ADMIN_EMAIL: 'admin@guardman.cl',
    CONTENT_AGENT: {} as any,
    PUBLISHER_AGENT: {} as any,
    SERPER_AGENT_SQLITE: {} as any,
    ORCHESTRATOR: {} as any,
    LOG_SESSION: {} as any,
    RATE_LIMITER: {} as any,
    FAL_API_KEY: '',
    MINIMAX_API_KEY: 'test-key',
  };
}

describe('CONTENT GENERATION FORENSIC AUDIT', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should use the unified pipeline and return structured result', async () => {
    const env = makeEnv();
    const result = await generateContent(env, 'service', 'guardias-de-seguridad', 'Guardias de Seguridad');
    expect(result.content).toBeDefined();
    expect(result.content.sections).toBeDefined();
    expect(result.score).toBeGreaterThan(0);
    expect(result.algoScore).toBeGreaterThan(0);
    expect(result.review).toBeDefined();
    expect(Array.isArray(result.violations)).toBe(true);
    expect(Array.isArray(result.genericPhrases)).toBe(true);
  });

  it('should return passed=true when no violations', async () => {
    const env = makeEnv();
    const result = await generateContent(env, 'service', 'test', 'Test');
    expect(result.passed).toBe(true);
    expect(result.violations).toHaveLength(0);
  });

  it('should calculate combined score as average of algo + review', async () => {
    const env = makeEnv();
    const result = await generateContent(env, 'service', 'test', 'Test');
    // algoScore mocked to 80, review score mocked to 85 → combined = 82 or 83
    expect(result.score).toBeGreaterThanOrEqual(80);
    expect(result.score).toBeLessThanOrEqual(90);
  });

  it('should accept skipQualityPipeline for emergency fallback', async () => {
    const env = makeEnv();
    const result = await generateContent(env, 'service', 'test', 'Test', { skipQualityPipeline: true });
    expect(result.passed).toBe(true);
  });

  it('should handle missing API key gracefully via fallback', async () => {
    const env = makeEnv();
    env.MINIMAX_API_KEY = undefined;
    // When AI key is missing and pipeline fails, it should still return fallback content
    try {
      const result = await generateContent(env, 'service', 'test', 'Test');
      expect(result.content).toBeDefined();
    } catch (e) {
      // If it throws, it should be a configured error
      expect((e as Error).message).toMatch(/not configured|key/i);
    }
  });
});
