import { describe, it, expect } from 'vitest';
import {
  validateTimeline, validateStats, validateValues,
  validateDifferentiators, validateCertifications, validateStaff, validateCTA,
  SECTION_VALIDATORS,
} from '../../src/services/section-validators';

describe('Section Validators', () => {
  describe('validateTimeline', () => {
    it('passes valid timeline', () => {
      const data = [
        { year: '2017', title: 'Fundación GuardMan', description: 'Nacimos en Providencia con la misión de elevar el estándar de seguridad privada en Chile.' },
        { year: '2019', title: 'Expansión Regional', description: 'Alcanzamos 50 clientes activos y nos expandimos a 5 comunas de la Región Metropolitana.' },
        { year: '2021', title: 'Centro de Monitoreo', description: 'Inauguramos nuestro centro de monitoreo propio con operadores certificados 24/7.' },
        { year: '2023', title: '500+ Guardias', description: 'Superamos los 500 guardias activos con cobertura en 14 comunas de Santiago.' },
        { year: '2024', title: 'Innovación Guard Pod', description: 'Lanzamos Guard Pod, nuestra torre autónoma de vigilancia con energía solar.' },
      ];
      expect(validateTimeline(data).ok).toBe(true);
    });

    it('fails with too few items', () => {
      const data = [{ year: '2017', title: 'Test', description: 'This is a test description that is long enough.' }];
      const result = validateTimeline(data);
      expect(result.ok).toBe(false);
      expect(result.errors[0]).toContain('≥4');
    });

    it('fails with missing description', () => {
      const data = [
        { year: '2017', title: 'Test', description: 'Descripción válida para el timeline de GuardMan.' },
        { year: '2019', title: 'Test', description: 'Segunda descripción válida suficiente longitud.' },
        { year: '2021', title: 'Test', description: 'Tercera descripción con la longitud mínima requerida.' },
        { year: '2023', title: 'Test' },
      ];
      const result = validateTimeline(data);
      expect(result.ok).toBe(false);
      expect(result.errors[0]).toContain('description');
    });

    it('fails on non-array', () => {
      expect(validateTimeline(null).ok).toBe(false);
      expect(validateTimeline({}).ok).toBe(false);
    });
  });

  describe('validateStats', () => {
    it('passes valid stats', () => {
      const data = [
        { value: '500+', label: 'Guardias activos', icon: '👮' },
        { value: '200+', label: 'Clientes', icon: '🏢' },
        { value: '8+', label: 'Años experiencia', icon: '📅' },
        { value: '14', label: 'Comunas cobertura', icon: '📍' },
      ];
      expect(validateStats(data).ok).toBe(true);
    });

    it('fails with too few items', () => {
      expect(validateStats([{ value: '500+', label: 'Test' }]).ok).toBe(false);
    });
  });

  describe('validateValues', () => {
    it('passes valid values', () => {
      const data = [
        { title: 'Integridad', description: 'Actuamos con transparencia y ética en cada servicio que prestamos.' },
        { title: 'Excelencia', description: 'Buscamos los más altos estándares de calidad en todos nuestros procesos.' },
        { title: 'Compromiso', description: 'Nos involucramos completamente con la seguridad de cada cliente.' },
      ];
      expect(validateValues(data).ok).toBe(true);
    });
  });

  describe('validateDifferentiators', () => {
    it('passes valid differentiators', () => {
      const data = [
        { title: 'Guard Pod Propio', description: 'Única empresa de seguridad chilena con torre autónoma de vigilancia solar.', icon: '🔋' },
        { title: 'Monitoreo 24/7', description: 'Centro de monitoreo propio con operadores certificados las 24 horas.', icon: '📡' },
        { title: 'OS-10 Certificado', description: 'Todos nuestros guardias cuentan con certificación oficial de Carabineros.', icon: '✅' },
        { title: 'Cobertura 14 Comunas', description: 'Presencia operativa en las 14 comunas principales de Santiago.', icon: '📍' },
      ];
      expect(validateDifferentiators(data).ok).toBe(true);
    });
  });

  describe('validateCertifications', () => {
    it('passes valid certifications', () => {
      const data = [
        { title: 'Certificación OS-10', description: 'Autorización oficial de Carabineros de Chile que garantiza guardias capacitados y verificados.' },
        { title: 'Ley 21.157', description: 'Cumplimos con la normativa chilena de seguridad privada vigente desde 2019.' },
        { title: 'Seguro RC', description: 'Contamos con seguro de responsabilidad civil que protege a nuestros clientes.' },
      ];
      expect(validateCertifications(data).ok).toBe(true);
    });
  });

  describe('validateStaff', () => {
    it('passes valid staff', () => {
      const data = {
        traits: [
          'Certificación OS-10 vigente verificada por Carabineros de Chile.',
          'Capacitación continua en protocolos de seguridad y emergencias.',
          'Centro de monitoreo propio 24/7 con operadores especializados.',
          'Más de 8 años de experiencia protegiendo empresas y residencias.',
        ],
      };
      expect(validateStaff(data).ok).toBe(true);
    });

    it('fails on empty traits', () => {
      expect(validateStaff({ traits: [] }).ok).toBe(false);
    });
  });

  describe('validateCTA', () => {
    it('passes valid CTA', () => {
      expect(validateCTA({
        heading: '¿Listo para proteger lo que más importa?',
        subheading: 'Conversemos y te armamos una propuesta sin compromiso.',
        button_text: 'Solicitar Cotización',
      }).ok).toBe(true);
    });
  });

  describe('SECTION_VALIDATORS map', () => {
    it('has all 7 sections', () => {
      expect(Object.keys(SECTION_VALIDATORS)).toHaveLength(7);
      expect(SECTION_VALIDATORS.timeline).toBeDefined();
      expect(SECTION_VALIDATORS.stats).toBeDefined();
      expect(SECTION_VALIDATORS.values).toBeDefined();
      expect(SECTION_VALIDATORS.differentiators).toBeDefined();
      expect(SECTION_VALIDATORS.certifications).toBeDefined();
      expect(SECTION_VALIDATORS.staff).toBeDefined();
      expect(SECTION_VALIDATORS.cta).toBeDefined();
    });
  });
});
