import { describe, it, expect, beforeEach } from 'vitest';
import { isPublicEndpoint, validateAuth } from '../../src/api/middleware/auth';
import type { Env } from '../../src/types';

// Minimal mock env
function makeEnv(partial: Partial<Env> = {}): Env {
  return {
    DB: {} as any,
    IMAGES: {} as any,
    CACHE: {} as any,
    ASSETS: {} as any,
    AI: null,
    AI_SEARCH: null,
    AUTH_TOKEN: partial.AUTH_TOKEN ?? 'test-secret-token',
    ADMIN_EMAIL: partial.ADMIN_EMAIL ?? 'admin@guardman.cl',
    CONTENT_AGENT: {} as any,
    PUBLISHER_AGENT: {} as any,
    SERPER_AGENT_SQLITE: {} as any,
    ORCHESTRATOR: {} as any,
    LOG_SESSION: {} as any,
    RATE_LIMITER: {} as any,
    FAL_API_KEY: '',
    ...partial,
  } as Env;
}

describe('AUTH FORENSIC AUDIT', () => {
  describe('H-04 Fix: PUBLIC_ENDPOINTS must NOT contain "/"', () => {
    it('should NOT have "/" as a public endpoint (critical security fix)', () => {
      // Read the source file and verify the fix is in place
      const fs = require('fs');
      const source = fs.readFileSync('./src/api/middleware/auth.ts', 'utf-8');
      const publicEndpointsMatch = source.match(/PUBLIC_ENDPOINTS\s*=\s*\[([^\]]*)\]/s);
      expect(publicEndpointsMatch).toBeTruthy();
      const endpointsList = publicEndpointsMatch![1];
      // The old bug: including '/' caused startsWith('/') to match EVERY path
      expect(endpointsList).not.toContain("'/'");
      expect(endpointsList).not.toContain('"/"');
    });

    it('should keep legitimate public endpoints intact', () => {
      const publicPaths = [
        '/health',
        '/api/login',
        '/api/preview/',
        '/api/images/',
        '/api/export/',
        '/api/cms/image',
        '/api/cms/blog/list',
        '/api/cms/blog/get',
        '/api/cms/content',
        '/api/cms/list',
        '/api/cms/homepage',
        '/api/media/list',
        '/api/intel/leads/capture',
      ];
      for (const path of publicPaths) {
        expect(isPublicEndpoint(path)).toBe(true);
      }
    });

    it('should reject admin/CMS write endpoints as public', () => {
      const protectedPaths = [
        '/api/cms/save',
        '/api/cms/generate',
        '/api/cms/regenerate',
        '/api/cms/delete',
        '/api/admin/dashboard',
        '/api/agents/status',
        '/api/content/publish',
        '/',
        '/admin',
        '/admin/',
      ];
      for (const path of protectedPaths) {
        expect(isPublicEndpoint(path)).toBe(false);
      }
    });
  });

  describe('Fail-secure behavior', () => {
    it('should return 503 when AUTH_TOKEN is not configured', () => {
      const env = makeEnv({ AUTH_TOKEN: '' });
      const req = new Request('https://example.com/api/cms/save', {
        headers: { Authorization: 'Bearer something' },
      });
      const res = validateAuth(req, env);
      expect(res).not.toBeNull();
      expect(res!.status).toBe(503);
    });

    it('should return 401 when Authorization header is missing', () => {
      const env = makeEnv();
      const req = new Request('https://example.com/api/cms/save');
      const res = validateAuth(req, env);
      expect(res).not.toBeNull();
      expect(res!.status).toBe(401);
    });

    it('should allow valid Bearer token', () => {
      const env = makeEnv({ AUTH_TOKEN: 'my-secret' });
      const req = new Request('https://example.com/api/cms/save', {
        headers: { Authorization: 'Bearer my-secret' },
      });
      const res = validateAuth(req, env);
      expect(res).toBeNull();
    });

    it('should accept login tokens (email:timestamp format)', () => {
      const env = makeEnv();
      const req = new Request('https://example.com/api/cms/save', {
        headers: { Authorization: 'Bearer admin@guardman.cl:1766880000' },
      });
      const res = validateAuth(req, env);
      expect(res).toBeNull();
    });

    it('should reject invalid tokens', () => {
      const env = makeEnv({ AUTH_TOKEN: 'correct-token' });
      const req = new Request('https://example.com/api/cms/save', {
        headers: { Authorization: 'Bearer wrong-token' },
      });
      const res = validateAuth(req, env);
      expect(res).not.toBeNull();
      expect(res!.status).toBe(401);
    });
  });

  describe('CMS read vs write authorization boundaries', () => {
    it('GET /api/cms/content should be public (no auth required)', () => {
      expect(isPublicEndpoint('/api/cms/content')).toBe(true);
    });
    it('GET /api/cms/list should be public', () => {
      expect(isPublicEndpoint('/api/cms/list')).toBe(true);
    });
    it('POST /api/cms/save should NOT be public', () => {
      expect(isPublicEndpoint('/api/cms/save')).toBe(false);
    });
    it('POST /api/cms/generate should NOT be public', () => {
      expect(isPublicEndpoint('/api/cms/generate')).toBe(false);
    });
  });
});
