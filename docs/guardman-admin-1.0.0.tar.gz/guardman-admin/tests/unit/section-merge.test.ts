import { describe, it, expect } from 'vitest';
import { mergeSection, getSection } from '../../src/services/section-merge';

describe('Section Merge', () => {
  const existingContent = {
    content: {
      hero: { headline: 'Existing hero', subheadline: 'Existing sub' },
      stats: [{ value: '10', label: 'Old stat' }],
      timeline: [{ year: '2020', title: 'Old', description: 'Old description kept intact.' }],
      cta: { heading: 'Old CTA', button_text: 'Old button' },
    },
    seo: { title: 'Existing SEO title', description: 'Existing description' },
  };

  it('replaces only the requested section', () => {
    const newTimeline = [
      { year: '2024', title: 'New Event', description: 'A brand new event for the company timeline.' },
      { year: '2023', title: 'Another', description: 'Another new event with enough description length.' },
      { year: '2022', title: 'Third', description: 'Third event with a valid long enough description here.' },
      { year: '2021', title: 'Fourth', description: 'Fourth event description that meets the minimum length criteria.' },
    ];

    const merged = mergeSection(existingContent, 'timeline', newTimeline);

    // Only timeline should change
    expect(merged.content.timeline).toEqual(newTimeline);
    // Hero preserved
    expect(merged.content.hero).toEqual(existingContent.content.hero);
    // Stats preserved
    expect(merged.content.stats).toEqual(existingContent.content.stats);
    // CTA preserved
    expect(merged.content.cta).toEqual(existingContent.content.cta);
    // SEO preserved
    expect(merged.seo).toEqual(existingContent.seo);
  });

  it('creates minimal structure when existing is null', () => {
    const newStats = [{ value: '100', label: 'Fresh' }];
    const merged = mergeSection(null, 'stats', newStats);
    expect(merged.content.stats).toEqual(newStats);
    expect(merged.seo).toEqual({});
  });

  it('preserves SEO when replacing a section', () => {
    const newCta = { heading: 'New heading for CTA', button_text: 'Click' };
    const merged = mergeSection(existingContent, 'cta', newCta);
    expect(merged.seo).toEqual(existingContent.seo);
    expect(merged.content.cta).toEqual(newCta);
  });
});

describe('getSection', () => {
  const content = {
    content: {
      timeline: [{ year: '2020', title: 'Test', description: 'Valid timeline description here.' }],
      stats: [{ value: '10', label: 'Test' }],
    },
  };

  it('extracts a section by key', () => {
    expect(getSection(content, 'timeline')).toBeDefined();
    expect(getSection(content, 'stats')).toBeDefined();
  });

  it('returns null for missing section', () => {
    expect(getSection(content, 'cta')).toBeNull();
  });

  it('returns null for null content', () => {
    expect(getSection(null, 'timeline')).toBeNull();
  });
});
