import { describe, it, expect } from 'vitest';
import {
  MOCK_LEADS,
  MOCK_CLIENTS,
  MOCK_INTERACTIONS,
  MOCK_PROPOSALS,
  MOCK_VISITS,
  MOCK_CLIENT_SERVICES,
  MOCK_DASHBOARD_RESPONSE,
  MOCK_PIPELINE_RESPONSE,
} from '../mocks/crm-mocks';

describe('CRM Mock Data Integrity', () => {
  it('MOCK_LEADS should have 12 leads', () => {
    expect(MOCK_LEADS).toHaveLength(12);
  });

  it('MOCK_LEADS should cover all 7 pipeline stages', () => {
    const stages = new Set(MOCK_LEADS.map(l => l.status));
    expect(stages).toContain('new');
    expect(stages).toContain('contacted');
    expect(stages).toContain('visit_scheduled');
    expect(stages).toContain('proposal_sent');
    expect(stages).toContain('negotiation');
    expect(stages).toContain('won');
    expect(stages).toContain('lost');
  });

  it('MOCK_LEADS should have positive estimated_value when probability > 0', () => {
    for (const lead of MOCK_LEADS) {
      if (lead.probability > 0) {
        expect(lead.estimated_value).toBeGreaterThan(0);
      }
    }
  });

  it('MOCK_CLIENTS should have 5 clients', () => {
    expect(MOCK_CLIENTS).toHaveLength(5);
  });

  it('MOCK_CLIENTS should have 3 active, 1 paused, 1 churned', () => {
    const active = MOCK_CLIENTS.filter(c => c.status === 'active');
    const paused = MOCK_CLIENTS.filter(c => c.status === 'paused');
    const churned = MOCK_CLIENTS.filter(c => c.status === 'churned');
    expect(active).toHaveLength(3);
    expect(paused).toHaveLength(1);
    expect(churned).toHaveLength(1);
  });

  it('MOCK_INTERACTIONS should reference valid lead_ids or client_ids', () => {
    const leadIds = new Set(MOCK_LEADS.map(l => l.id));
    const clientIds = new Set(MOCK_CLIENTS.map(c => c.id));
    for (const i of MOCK_INTERACTIONS) {
      if (i.lead_id) expect(leadIds.has(i.lead_id)).toBe(true);
      if (i.client_id) expect(clientIds.has(i.client_id)).toBe(true);
    }
  });

  it('MOCK_PROPOSALS should reference valid lead_ids', () => {
    const leadIds = new Set(MOCK_LEADS.map(l => l.id));
    for (const p of MOCK_PROPOSALS) {
      expect(leadIds.has(p.lead_id)).toBe(true);
    }
  });

  it('MOCK_VISITS should reference valid lead_ids', () => {
    const leadIds = new Set(MOCK_LEADS.map(l => l.id));
    for (const v of MOCK_VISITS) {
      expect(leadIds.has(v.lead_id)).toBe(true);
    }
  });

  it('MOCK_CLIENT_SERVICES should reference valid client_ids', () => {
    const clientIds = new Set(MOCK_CLIENTS.map(c => c.id));
    for (const s of MOCK_CLIENT_SERVICES) {
      expect(clientIds.has(s.client_id)).toBe(true);
    }
  });

  it('MOCK_DASHBOARD_RESPONSE should match lead counts', () => {
    const db = MOCK_DASHBOARD_RESPONSE.data;
    const leadCounts = {
      new: MOCK_LEADS.filter(l => l.status === 'new').length,
      contacted: MOCK_LEADS.filter(l => l.status === 'contacted').length,
      visit_scheduled: MOCK_LEADS.filter(l => l.status === 'visit_scheduled').length,
      proposal_sent: MOCK_LEADS.filter(l => l.status === 'proposal_sent').length,
      negotiation: MOCK_LEADS.filter(l => l.status === 'negotiation').length,
      won: MOCK_LEADS.filter(l => l.status === 'won').length,
      lost: MOCK_LEADS.filter(l => l.status === 'lost').length,
    };
    for (const [stage, count] of Object.entries(leadCounts)) {
      expect(db.leads[stage].cnt).toBe(count);
    }
  });

  it('MOCK_PIPELINE_RESPONSE should contain all non-frozen leads (frozen is a flag, not a stage)', () => {
    const allPipelineLeads = Object.values(MOCK_PIPELINE_RESPONSE.data.pipeline).flat();
    const nonFrozenLeads = MOCK_LEADS.filter(l => l.status !== 'frozen');
    expect(allPipelineLeads).toHaveLength(nonFrozenLeads.length);
  });

  it('won lead should link to a client via lead_id', () => {
    const wonLead = MOCK_LEADS.find(l => l.status === 'won');
    expect(wonLead).toBeDefined();
    const linkedClient = MOCK_CLIENTS.find(c => c.lead_id === wonLead!.id);
    expect(linkedClient).toBeDefined();
  });

  it('all slugs should be unique', () => {
    const leadSlugs = MOCK_LEADS.map(l => l.slug);
    const clientSlugs = MOCK_CLIENTS.map(c => c.slug);
    expect(new Set(leadSlugs).size).toBe(leadSlugs.length);
    expect(new Set(clientSlugs).size).toBe(clientSlugs.length);
  });

  it('no mock IDs should collide across entities', () => {
    const leadIds = MOCK_LEADS.map(l => l.id);
    const clientIds = MOCK_CLIENTS.map(c => c.id);
    const allIds = [...leadIds, ...clientIds];
    expect(new Set(allIds).size).toBe(allIds.length);
  });
});
