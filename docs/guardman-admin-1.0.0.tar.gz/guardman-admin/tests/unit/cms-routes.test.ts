import { describe, it, expect } from 'vitest';
import { cmsRoutes } from '../../src/api/routes/cms';

describe('CMS ROUTES FORENSIC AUDIT', () => {
  describe('Endpoint registry completeness', () => {
    it('should have exactly the expected number of CMS route handlers', () => {
      // blog/list, blog/get, blog/save, blog/delete
      // media/list
      // content, list, save, image, regenerate, generate, score, homepage, rebuild, deploy-status
      expect(cmsRoutes.length).toBeGreaterThanOrEqual(14);
    });

    it('should register /api/cms/generate as POST', () => {
      const route = cmsRoutes.find(r => r.pattern.test('/api/cms/generate'));
      expect(route).toBeDefined();
      expect(route!.methods).toContain('POST');
    });

    it('should register /api/cms/regenerate as POST', () => {
      const route = cmsRoutes.find(r => r.pattern.test('/api/cms/regenerate'));
      expect(route).toBeDefined();
      expect(route!.methods).toContain('POST');
    });

    it('should register /api/cms/save as POST', () => {
      const route = cmsRoutes.find(r => r.pattern.test('/api/cms/save'));
      expect(route).toBeDefined();
      expect(route!.methods).toContain('POST');
    });

    it('should register /api/cms/content as GET', () => {
      const route = cmsRoutes.find(r => r.pattern.test('/api/cms/content'));
      expect(route).toBeDefined();
      expect(route!.methods).toContain('GET');
    });

    it('should register /api/cms/homepage as GET', () => {
      const route = cmsRoutes.find(r => r.pattern.test('/api/cms/homepage'));
      expect(route).toBeDefined();
      expect(route!.methods).toContain('GET');
    });
  });

  describe('H-01 Fix: Generate endpoint uses unified DeepSeek pipeline', () => {
    it('generate handler source must import generateContent from content-generation', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/api/routes/cms.ts', 'utf-8');
      expect(source).toContain("import('../../services/content-generation')");
      expect(source).toContain('generateContent');
      // Must NOT call minimax directly
      expect(source).not.toContain('api.minimax.io');
    });

    it('regenerate handler source must use generateContent', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/api/routes/cms.ts', 'utf-8');
      const regenerateSection = source.substring(source.indexOf('/api/cms/regenerate'));
      expect(regenerateSection).toContain('generateContent');
      expect(regenerateSection).not.toContain('api.minimax.io');
    });
  });

  describe('Safe content persistence', () => {
    it('save handler must normalize content into { sections, seo } format', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/api/routes/cms.ts', 'utf-8');
      expect(source).toContain('sections');
      expect(source).toContain('seo');
      expect(source).toContain('content_versions');
    });

    it('save handler must invalidate cache after write', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/api/routes/cms.ts', 'utf-8');
      expect(source).toContain('invalidateCache');
    });
  });

  describe('JSON.parse safety in CMS routes', () => {
    it('cms.ts handlers must wrap JSON.parse operations in try/catch scopes', () => {
      const fs = require('fs');
      const source = fs.readFileSync('./src/api/routes/cms.ts', 'utf-8');
      // Split by handler blocks (each route object has a handler function)
      const handlers = source.split(/handler:\s*async/);
      expect(handlers.length).toBeGreaterThan(1);
      for (let i = 1; i < handlers.length; i++) {
        const handler = handlers[i];
        if (!handler.includes('JSON.parse')) continue;
        // Each handler with JSON.parse must have a try/catch
        expect(handler).toMatch(/\btry\b/);
        expect(handler).toMatch(/catch\s*\(/);
      }
    });
  });
});
