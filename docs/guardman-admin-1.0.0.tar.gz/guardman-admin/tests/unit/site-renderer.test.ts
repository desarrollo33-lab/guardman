import { describe, it, expect, beforeAll } from 'vitest';
import {
  esc,
  buildHomepage,
  buildContactoPage,
  buildCotizacionPage,
  buildPrivacidadPage,
  buildTerminosPage,
  buildNosotrosPage,
  buildGuardPodPage,
  buildAjaxPage,
  buildDetailPage,
  buildHubPage,
  buildOrganizationSchema,
  buildFAQSchema,
  setSiteUrl,
  type SiteData,
} from '../../src/ssr/site-renderer';

beforeAll(() => {
  setSiteUrl('https://guardman.oficinadesarrollo33.workers.dev');
});

describe('SITE RENDERER FORENSIC AUDIT', () => {
  describe('XSS Protection (esc function)', () => {
    it('should escape HTML entities', () => {
      expect(esc('<script>alert(1)</script>')).toBe('&lt;script&gt;alert(1)&lt;/script&gt;');
      expect(esc('" onclick="evil()')).toBe('&quot; onclick=&quot;evil()');
      expect(esc("'")).toBe("'"); // single quotes not escaped by this impl
    });

    it('should handle undefined/null', () => {
      expect(esc(undefined)).toBe('');
      expect(esc(null)).toBe('');
    });
  });

  describe('Homepage 100% CMS — 24 fields', () => {
    it('buildHomepage renders all CMS sections without throwing', () => {
      const data: SiteData = {
        title: 'GuardMan Chile',
        description: 'Seguridad privada',
        canonical: 'https://guardman.oficinadesarrollo33.workers.dev/',
        pageType: 'home',
        heroHeading: 'Seguridad que protege lo que más te importa',
        heroSubheading: 'Guardias OS-10 certificados',
        heroImage: '/images/hero-home.webp',
        homeNosotrosBadge: 'Grupo GuardMan Chile',
        homeNosotrosTitle: 'GuardMan Chile — Seguridad privada de excelencia',
        homeNosotrosParagraph: 'Somos una empresa...',
        homeNosotrosImage: '/images/nosotros_seccion.webp',
        homeNosotrosFeatures: [
          { title: 'Experiencia', description: '8+ años' },
          { title: 'Cobertura', description: '14 comunas' },
        ],
        homeServiciosBadge: 'Nuestros Servicios',
        homeServiciosTitle: 'Soluciones de seguridad a medida',
        homeServiciosSubtitle: 'Cobertura completa para empresas y residencias',
        homeServices: [
          { slug: 'guardias', name: 'Guardias', description: 'Seguridad física', image: '/images/guardias.webp' },
        ],
        homeGuardPodBadge: 'Tecnología',
        homeGuardPodTitle: 'Guard Pod',
        homeGuardPodParagraph: 'Vigilancia autónoma solar',
        homeGuardPodCtaText: 'Conoce más',
        homeGuardPodCtaLink: '/guard-pod',
        homeGuardPodFeatures: [{ title: 'Solar', description: '100% autónomo' }],
        homeGuardPodImage: '/images/s4-thumbnail.webp',
        homeSectoresBadge: 'Sectores',
        homeSectoresTitle: 'Industrias que protegemos',
        homeSectoresSubtitle: 'Especialización por sector',
        homeSectors: [{ slug: 'comercial', name: 'Comercial', colorClass: 'blue' }],
        homeAjaxBadge: 'Ajax',
        homeAjaxTitle: 'Ajax Systems',
        homeAjaxParagraph: 'Alarmas inalámbricas Grado 3',
        homeAjaxCtaText: 'Ver más',
        homeAjaxCtaLink: '/ajax-systems',
        homeAjaxFeatures: [{ title: 'Jeweller', description: 'Radio encriptada' }],
        homeAjaxImage: '/images/Ajax-systems-header.jpg',
        homeClientesTitle: 'Clientes',
        homeClientesSubtitle: 'Empresas que confían',
        homeClientesCtaText: 'Ver todos',
        homeClientesCtaLink: '/nosotros',
        homeClientesItems: [{ name: 'Avanzapark', initials: 'AV', color: '#3B82F6', image: '' }],
        homeUbicacionesBadge: 'Cobertura',
        homeUbicacionesTitle: 'Donde operamos',
        homeUbicacionesSubtitle: '14 comunas de Santiago',
        homeUbicacionesCtaText: 'Ver ubicaciones',
        homeUbicacionesCtaLink: '/ubicaciones',
        homeUbicacionesZonesTitle: 'Zonas',
        homeUbicacionesZonesSubtitle: 'Cobertura por zona',
        homeZones: [{ name: 'Oriente', dotClass: 'dot-e', locations: [{ slug: 'las-condes', name: 'Las Condes' }] }],
        homeCtaFinalBadge: 'Contacto',
        homeCtaFinalTitle: 'Protege tu propiedad hoy',
        homeCtaFinalSubtitle: 'Cotiza sin compromiso',
        homeCtaFinalCta1Text: 'Cotizar',
        homeCtaFinalCta1Link: '/cotizacion',
        homeCtaFinalCta2Text: 'Conocer más',
        homeCtaFinalCta2Link: '/nosotros',
        breadcrumbs: [{ label: 'Inicio', href: '/' }],
        sections: [],
      };
      const html = buildHomepage(data);
      expect(html).toContain(data.heroHeading);
      expect(html).toContain(data.homeNosotrosTitle!);
      expect(html).toContain(data.homeNosotrosParagraph!);
      expect(html).toContain(data.homeServiciosTitle!);
      expect(html).toContain(data.homeGuardPodTitle!);
      expect(html).toContain(data.homeSectoresTitle!);
      expect(html).toContain(data.homeAjaxTitle!);
      expect(html).toContain(data.homeClientesTitle!);
      expect(html).toContain(data.homeUbicacionesZonesTitle!); // zones title takes precedence
      expect(html).toContain(data.homeCtaFinalTitle!);
      expect(html).toContain('Avanzapark');
      expect(html).toContain('Las Condes');
    });

    it('buildHomepage uses fallback defaults when CMS fields are missing', () => {
      const data: SiteData = {
        title: 'GuardMan Chile',
        description: '',
        canonical: '/',
        pageType: 'home',
        heroHeading: 'H',
        breadcrumbs: [],
        sections: [],
      };
      const html = buildHomepage(data);
      expect(html).toContain('<!doctype html>');
      expect(html).toContain('</html>');
    });
  });

  describe('Contacto Page — Dynamic Builder', () => {
    it('buildContactoPage renders with CMS overrides from content_json', () => {
      const env = {
        _staticData: {
          content_json: JSON.stringify({
            seo: { title: 'Contacto CMS', description: 'Desc CMS' },
            content: {
              hero: { headline: 'Hablemos CMS', subheadline: 'Sub CMS' },
              contact_info: {
                phone: '+56 9 3000 0000',
                email: 'cms@guardman.cl',
                address: 'Dirección CMS',
                section_title: 'Título Sección CMS',
                section_subtitle: 'Subtítulo CMS',
              },
              cta: {
                heading: 'CTA CMS',
                subheading: 'CTA Sub CMS',
                button_text: 'Botón CMS',
                button_href: 'https://wa.me/56930000010',
              },
            },
          }),
        },
      };
      const html = buildContactoPage(env);
      expect(html).toContain('Hablemos CMS');
      expect(html).toContain('Sub CMS');
      expect(html).toContain('+56 9 3000 0000');
      expect(html).toContain('cms@guardman.cl');
      expect(html).toContain('Dirección CMS');
      expect(html).toContain('Título Sección CMS');
      expect(html).toContain('Subtítulo CMS');
      expect(html).toContain('CTA CMS');
      expect(html).toContain('Botón CMS');
      expect(html).toContain('https://wa.me/56930000010');
      expect(html).toContain('leaflet'); // map library included
    });

    it('buildContactoPage renders with defaults when no CMS data', () => {
      const html = buildContactoPage();
      expect(html).toContain('Contáctanos');
      expect(html).toContain('+56 9 300 000 10');
      expect(html).toContain('info@guardman.cl');
    });
  });

  describe('Cotización Page — Dynamic Builder', () => {
    it('buildCotizacionPage renders with CMS overrides from content_json', () => {
      const env = {
        _staticData: {
          content_json: JSON.stringify({
            seo: { title: 'Cotiza CMS', description: 'Desc Cotiza' },
            content: {
              hero: { headline: 'Cotiza tu Seguridad CMS', subheadline: 'Sub CMS' },
              trust_badges: ['Badge 1', 'Badge 2', 'Badge 3', 'Badge 4'],
              cta: {
                heading: 'WhatsApp CMS',
                button_text: 'Escribir CMS',
                button_href: 'https://wa.me/56999999999',
              },
            },
          }),
        },
      };
      const html = buildCotizacionPage(env);
      expect(html).toContain('Cotiza tu Seguridad CMS');
      expect(html).toContain('Badge 1');
      expect(html).toContain('WhatsApp CMS');
      expect(html).toContain('https://wa.me/56999999999');
    });

    it('buildCotizacionPage renders with defaults when no CMS data', () => {
      const html = buildCotizacionPage();
      expect(html).toContain('Cotiza tu Servicio de Seguridad');
      expect(html).toContain('Certificación OS-10 vigente');
    });
  });

  describe('Privacidad & Términos — body_content CMS', () => {
    it('buildPrivacidadPage uses body_content from content_json when available', () => {
      const customBody = '<h2>Política CMS</h2><p>Texto personalizado</p>';
      const env = {
        _staticData: {
          content_json: JSON.stringify({
            seo: { title: 'Priv CMS', description: 'Desc' },
            content: { body_content: customBody },
          }),
        },
      };
      const html = buildPrivacidadPage(env);
      expect(html).toContain('Política CMS');
      expect(html).toContain('Texto personalizado');
    });

    it('buildTerminosPage uses body_content from content_json when available', () => {
      const customBody = '<h2>Términos CMS</h2><p>Cláusula 1</p>';
      const env = {
        _staticData: {
          content_json: JSON.stringify({
            seo: { title: 'Term CMS', description: 'Desc' },
            content: { body_content: customBody },
          }),
        },
      };
      const html = buildTerminosPage(env);
      expect(html).toContain('Términos CMS');
      expect(html).toContain('Cláusula 1');
    });
  });

  describe('Detail Page (Service/Location/Sector/Combo)', () => {
    it('buildDetailPage renders a complete service page', () => {
      const data: SiteData = {
        title: 'Guardias de Seguridad | GuardMan Chile',
        description: 'Desc',
        canonical: '/servicios/guardias-de-seguridad',
        pageType: 'service',
        heroHeading: 'Guardias de Seguridad',
        heroSubheading: 'Protección 24/7',
        breadcrumbs: [{ label: 'Inicio', href: '/' }, { label: 'Servicios' }, { label: 'Guardias' }],
        schemas: [
          { '@context': 'https://schema.org', '@type': 'Service', name: 'Guardias' },
        ],
        sections: [
          { type: 'intro', heading: 'Intro', paragraphs: ['P1', 'P2'] },
          { type: 'features', heading: 'Features', items: ['F1', 'F2'] },
          { type: 'issues', heading: 'Issues', items: ['I1'] },
          { type: 'faq', heading: 'FAQ', items: [{ question: 'Q1', answer: 'A1' }] },
        ],
      };
      const html = buildDetailPage(data);
      expect(html).toContain('Guardias de Seguridad');
      expect(html).toContain('P1');
      expect(html).toContain('F1');
      expect(html).toContain('Q1');
      expect(html).toContain('application/ld+json');
    });
  });

  describe('JSON-LD Schemas', () => {
    it('buildOrganizationSchema produces valid structure', () => {
      const schema = buildOrganizationSchema();
      expect(schema['@type']).toBe('Organization');
      expect(schema.name).toBe('GuardMan Chile');
      expect(schema.telephone).toBe('+56 9 300 000 10');
    });

    it('buildFAQSchema produces valid FAQPage', () => {
      const schema = buildFAQSchema([{ question: 'Q?', answer: 'A.' }]);
      expect(schema['@type']).toBe('FAQPage');
      expect(schema.mainEntity).toHaveLength(1);
      expect(schema.mainEntity[0].acceptedAnswer.text).toBe('A.');
    });
  });
});
