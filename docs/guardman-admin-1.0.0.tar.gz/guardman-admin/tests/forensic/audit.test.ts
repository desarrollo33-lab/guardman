import { describe, it, expect } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';

function readSrc(filePath: string): string {
  return fs.readFileSync(path.join('./src', filePath), 'utf-8');
}

function globSrc(pattern: string): string[] {
  const results: string[] = [];
  function walk(dir: string) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.endsWith('.ts')) results.push(full);
    }
  }
  walk('./src');
  return results;
}

describe('FORENSIC AUDIT — GuardMan CMS 100% Operability', () => {
  const allSources = globSrc('**/*.ts');
  const combinedSource = allSources.map(p => fs.readFileSync(p, 'utf-8')).join('\n');

  describe('H-01 Dual Provider Chaos — DeepSeek Consolidation', () => {
    it('must NOT contain any api.minimax.io references', () => {
      expect(combinedSource).not.toContain('api.minimax.io');
    });

    it('must NOT export or call callMiniMaxAI', () => {
      expect(combinedSource).not.toContain('callMiniMaxAI');
    });

    it('must reference api.deepseek.com in AI service', () => {
      const aiSource = readSrc('services/ai.ts');
      expect(aiSource).toContain('api.deepseek.com');
    });

    it('src/ai/minimax.ts must be deleted', () => {
      expect(fs.existsSync('./src/ai/minimax.ts')).toBe(false);
    });

    it('inference.ts must use deepseek-chat model', () => {
      const inference = readSrc('services/inference.ts');
      expect(inference).toContain('deepseek-chat');
    });
  });

  describe('H-02 Merge destructivo — Safe Merge', () => {
    it('frontend CMSPage must NOT use destructive deepMerge', () => {
      const cmsPage = fs.readFileSync('./guardman-admin-ui/src/components/CMS/CMSPage.tsx', 'utf-8');
      expect(cmsPage).not.toContain('deepMerge');
    });

    it('frontend must implement safe merge preserving user arrays', () => {
      const cmsPage = fs.readFileSync('./guardman-admin-ui/src/components/CMS/CMSPage.tsx', 'utf-8');
      // Evidence of safe merge: copying original content and only replacing AI keys
      expect(cmsPage).toMatch(/original|prev|existing|user/i);
    });
  });

  describe('H-03 JSON.parse blindaje', () => {
    const criticalFiles = [
      'services/ai.ts',
      'api/routes/cms.ts',
      'index.ts',
      'ssr/site-renderer.ts',
    ];

    it('critical files must guard JSON.parse within try/catch scope', () => {
      const issues: string[] = [];
      for (const relPath of criticalFiles) {
        const file = path.join('./src', relPath);
        if (!fs.existsSync(file)) continue;
        const source = fs.readFileSync(file, 'utf-8');
        const lines = source.split('\n');
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          if (line.includes('JSON.parse')) {
            // Check current line + surrounding lines for try/catch scope
            const context = lines.slice(Math.max(0, i - 5), Math.min(lines.length, i + 1)).join('\n');
            const before = lines.slice(Math.max(0, i - 200), i + 1).join('\n');
            const after = lines.slice(i, Math.min(lines.length, i + 200)).join('\n');
            const hasTry = /\btry\b/.test(before);
            const hasCatch = /catch\s*[\({]/.test(after);
            // Single-line try/catch: try { ... JSON.parse ... } catch
            const isSingleLineGuard = /try\s*\{[^}]*JSON\.parse/.test(context) && /catch/.test(context);
            if ((!hasTry || !hasCatch) && !isSingleLineGuard) {
              issues.push(`${file}:${i + 1}`);
            }
          }
        }
      }
      if (issues.length > 0) {
        console.warn('JSON.parse without try/catch scope found at:', issues);
      }
      expect(issues).toHaveLength(0);
    });
  });

  describe('H-04 Auth Bug — PUBLIC_ENDPOINTS', () => {
    it('auth.ts must NOT contain "/" in PUBLIC_ENDPOINTS', () => {
      const auth = readSrc('api/middleware/auth.ts');
      const match = auth.match(/PUBLIC_ENDPOINTS\s*=\s*\[([^\]]*)\]/s);
      expect(match).toBeTruthy();
      const list = match![1];
      expect(list).not.toContain("'/'");
      expect(list).not.toContain('"/"');
    });

    it('validateAuth must implement fail-secure for missing AUTH_TOKEN', () => {
      const auth = readSrc('api/middleware/auth.ts');
      expect(auth).toContain('503');
      expect(auth).toContain('Auth not configured');
    });
  });

  describe('Homepage 100% CMS — 24 fields', () => {
    it('site-renderer.ts SiteData must declare all 24 homepage CMS fields', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      const requiredFields = [
        'homeNosotrosBadge', 'homeNosotrosTitle',
        'homeServiciosBadge', 'homeServiciosTitle', 'homeServiciosSubtitle',
        'homeGuardPodBadge', 'homeGuardPodTitle', 'homeGuardPodParagraph', 'homeGuardPodCtaText', 'homeGuardPodCtaLink',
        'homeSectoresBadge', 'homeSectoresTitle', 'homeSectoresSubtitle',
        'homeAjaxBadge', 'homeAjaxTitle', 'homeAjaxParagraph', 'homeAjaxCtaText', 'homeAjaxCtaLink',
        'homeUbicacionesBadge', 'homeUbicacionesTitle', 'homeUbicacionesSubtitle', 'homeUbicacionesCtaText', 'homeUbicacionesCtaLink',
        'homeCtaFinalBadge', 'homeCtaFinalTitle', 'homeCtaFinalSubtitle', 'homeCtaFinalCta1Text', 'homeCtaFinalCta1Link', 'homeCtaFinalCta2Text', 'homeCtaFinalCta2Link',
        'homeUbicacionesZonesTitle', 'homeUbicacionesZonesSubtitle',
      ];
      for (const field of requiredFields) {
        expect(renderer).toContain(field);
      }
    });

    it('index.ts must inject all homepage CMS fields from content_json', () => {
      const index = readSrc('index.ts');
      const requiredInjections = [
        'homeNosotrosBadge', 'homeNosotrosTitle',
        'homeServiciosBadge', 'homeServiciosTitle', 'homeServiciosSubtitle',
        'homeGuardPodBadge', 'homeGuardPodTitle', 'homeGuardPodParagraph', 'homeGuardPodCtaText', 'homeGuardPodCtaLink',
        'homeSectoresBadge', 'homeSectoresTitle', 'homeSectoresSubtitle',
        'homeAjaxBadge', 'homeAjaxTitle', 'homeAjaxParagraph', 'homeAjaxCtaText', 'homeAjaxCtaLink',
        'homeUbicacionesBadge', 'homeUbicacionesTitle', 'homeUbicacionesSubtitle', 'homeUbicacionesCtaText', 'homeUbicacionesCtaLink',
        'homeCtaFinalBadge', 'homeCtaFinalTitle', 'homeCtaFinalSubtitle', 'homeCtaFinalCta1Text', 'homeCtaFinalCta1Link', 'homeCtaFinalCta2Text', 'homeCtaFinalCta2Link',
      ];
      for (const field of requiredInjections) {
        expect(index).toContain(field);
      }
    });
  });

  describe('Contacto + Cotización — Dynamic Builders', () => {
    it('site-renderer.ts must contain buildContactoPage function', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      expect(renderer).toContain('export function buildContactoPage');
    });

    it('buildContactoPage must parse content_json for CMS overrides', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      const contactFn = renderer.substring(renderer.indexOf('export function buildContactoPage'));
      expect(contactFn).toContain('content_json');
      expect(contactFn).toContain('JSON.parse');
    });

    it('site-renderer.ts must contain buildCotizacionPage function', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      expect(renderer).toContain('export function buildCotizacionPage');
    });

    it('buildCotizacionPage must parse content_json for CMS overrides', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      const cotFn = renderer.substring(renderer.indexOf('export function buildCotizacionPage'));
      expect(cotFn).toContain('content_json');
      expect(cotFn).toContain('JSON.parse');
    });
  });

  describe('Nosotros CMS — Not fully hardcoded', () => {
    it('buildNosotrosPage must read from _staticData and content_json', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      const nosotrosFn = renderer.substring(renderer.indexOf('export function buildNosotrosPage'));
      expect(nosotrosFn).toContain('_staticData');
      expect(nosotrosFn).toContain('content_json');
      expect(nosotrosFn).toContain('JSON.parse');
    });
  });

  describe('16 Páginas Operativas', () => {
    const pages = [
      { name: 'Homepage', builder: 'buildHomepage' },
      { name: 'Servicios detalle', builder: 'buildDetailPage' },
      { name: 'Ubicaciones detalle', builder: 'buildDetailPage' },
      { name: 'Sectores detalle', builder: 'buildDetailPage' },
      { name: 'Combos detalle', builder: 'buildDetailPage' },
      { name: 'Nosotros', builder: 'buildNosotrosPage' },
      { name: 'Guard Pod', builder: 'buildGuardPodPage' },
      { name: 'Ajax', builder: 'buildAjaxPage' },
      { name: 'Contacto', builder: 'buildContactoPage' },
      { name: 'Cotización', builder: 'buildCotizacionPage' },
      { name: 'Privacidad', builder: 'buildPrivacidadPage' },
      { name: 'Términos', builder: 'buildTerminosPage' },
      { name: 'Hub Servicios', builder: 'buildHubPage' },
      { name: 'Hub Sectores', builder: 'buildHubPage' },
      { name: 'Hub Ubicaciones', builder: 'buildHubPage' },
      { name: 'Gracias', builder: 'buildGraciasPage' },
    ];

    it('site-renderer.ts must export builders for pages 1-15', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      for (const page of pages.filter(p => p.builder !== 'buildGraciasPage')) {
        expect(renderer).toContain(`export function ${page.builder}`);
      }
    });

    it('index.ts must define buildGraciasPage for page 16', () => {
      const index = readSrc('index.ts');
      expect(index).toContain('function buildGraciasPage');
    });

    it('index.ts must route all 16 pages through SSR', () => {
      const index = readSrc('index.ts');
      expect(index).toContain('buildHomepage');
      expect(index).toContain('buildDetailPage');
      expect(index).toContain('buildNosotrosPage');
      expect(index).toContain('buildGuardPodPage');
      expect(index).toContain('buildAjaxPage');
      expect(index).toContain('buildContactoPage');
      expect(index).toContain('buildCotizacionPage');
      expect(index).toContain('buildPrivacidadPage');
      expect(index).toContain('buildTerminosPage');
      expect(index).toContain('buildHubPage');
      expect(index).toContain('buildGraciasPage');
    });
  });

  describe('Static HTML fallbacks removed', () => {
    it('buildContactoPage body must NOT reference _CONTACTO_AFTER_HERO', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      const contactFn = renderer.substring(renderer.indexOf('export function buildContactoPage'));
      expect(contactFn).not.toContain('_CONTACTO_AFTER_HERO');
    });

    it('buildCotizacionPage body must NOT reference _COTIZACION_AFTER_HERO', () => {
      const renderer = readSrc('ssr/site-renderer.ts');
      const cotFn = renderer.substring(renderer.indexOf('export function buildCotizacionPage'));
      expect(cotFn).not.toContain('_COTIZACION_AFTER_HERO');
    });
  });

  describe('Quality Pipeline Integrity', () => {
    it('content-generation.ts must implement 7-layer pipeline', () => {
      const cg = readSrc('services/content-generation.ts');
      expect(cg).toContain('Brand DNA');
      expect(cg).toContain('Banned patterns');
      expect(cg).toContain('Guardrails');
      expect(cg).toContain('LLM review');
      expect(cg).toContain('De-generic');
      expect(cg).toContain('Combined scoring');
    });
  });
});
