import type { Env, ContentJob } from '../types';

export interface QueuedPageJob {
  pageId: string;
  service: string;
  location: string;
  serperData: string;
  action: 'generate' | 'regenerate';
  entityType: 'service' | 'combo';
  entitySlug: string;
  entityName: string;
}

export async function enqueueContentJob(
  env: Env,
  job: QueuedPageJob
): Promise<{ queued: boolean; messageId: string }> {
  if (!env.SEO_CONTENT_QUEUE) {
    throw new Error('SEO_CONTENT_QUEUE not configured');
  }
  const messageId = await env.SEO_CONTENT_QUEUE.send(job);
  return { queued: true, messageId };
}

export async function enqueueBulkContentJobs(
  env: Env,
  jobs: QueuedPageJob[]
): Promise<{ queued: number; messageIds: string[] }> {
  if (!env.SEO_CONTENT_QUEUE) {
    throw new Error('SEO_CONTENT_QUEUE not configured');
  }
  const messageIds: string[] = [];
  for (const job of jobs) {
    const id = await env.SEO_CONTENT_QUEUE.send(job);
    messageIds.push(id);
  }
  return { queued: jobs.length, messageIds };
}

export function contentJobToQueued(job: ContentJob, action: 'generate' | 'regenerate' = 'generate'): QueuedPageJob {
  const serviceSlug = job.comboServiceSlug || job.entitySlug;
  const locationSlug = job.comboLocationSlug || '';
  return {
    pageId: `${job.entityType}-${job.entitySlug}`,
    service: serviceSlug,
    location: locationSlug,
    serperData: '',
    action,
    entityType: job.entityType === 'sector' ? 'service' : job.entityType as 'service' | 'combo',
    entitySlug: job.entitySlug,
    entityName: job.entityName,
  };
}
