import type { Env } from '../types';
import type { QueuedPageJob } from './content-queue';
import { generateContent } from '../services/content-generation';

export default {
  async queue(batch: { messages: Array<{ body: QueuedPageJob; attempts: number; ack: () => void; retry: (opts?: { delaySeconds?: number }) => void }> }, env: Env): Promise<void> {
    for (const message of batch.messages) {
      try {
        const job = message.body;

        const existing = await env.DB.prepare(
          'SELECT id, version, confidence_score FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
        ).bind(job.entityType, job.entitySlug).first();

        if (existing && (existing as any).confidence_score >= 75) {
          console.log(`[Queue] ${job.entitySlug}: already has score ${(existing as any).confidence_score}, skipping`);
          message.ack();
          continue;
        }

        // Unified pipeline: brand DNA + 4-layer quality
        const result = await generateContent(env, job.entityType, job.entitySlug, job.entityName);
        const content = result.content;

        if (job.entityType === 'combo' && job.service && job.location) {
          const s = content.sections || (content as any);
          const wordCount = JSON.stringify(content).split(/\s+/).length;
          await env.DB.prepare(
            `INSERT INTO combo_content (service_slug, location_slug, seo_title, meta_description, h1, intro_paragraph, local_context, faqs_json, cta_text, cta_button, status, word_count, generated_at, content_json)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, datetime('now'), ?)
             ON CONFLICT(service_slug, location_slug) DO UPDATE SET
               seo_title=excluded.seo_title, meta_description=excluded.meta_description, h1=excluded.h1,
               intro_paragraph=excluded.intro_paragraph, local_context=excluded.local_context, faqs_json=excluded.faqs_json,
               cta_text=excluded.cta_text, cta_button=excluded.cta_button, status='draft', word_count=excluded.word_count,
               generated_at=datetime('now'), updated_at=datetime('now'), content_json=excluded.content_json`
          ).bind(
            job.service, job.location,
            s.meta?.title || '', s.meta?.description || '',
            s.hero?.heading || '', (s.intro?.paragraphs || []).join('\n'),
            s.cta?.subheading || '',
            s.faqs?.items ? JSON.stringify(s.faqs.items) : null,
            s.cta?.heading || '', s.cta?.button || '',
            wordCount, JSON.stringify(content)
          ).run();
        } else {
          const wordCount = JSON.stringify(content).split(/\s+/).length;
          const versionResult = await env.DB.prepare(
            'SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?'
          ).bind(job.entityType, job.entitySlug).first();
          const nextVersion = versionResult?.next_version || 1;
          await env.DB.prepare(
            'INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, confidence_score, word_count) VALUES (?, ?, ?, ?, ?, ?, ?)'
          ).bind(job.entityType, job.entitySlug, nextVersion, JSON.stringify(content), 'ai-queue', result.score, wordCount).run();
        }

        // Save lesson
        try {
          await env.DB.prepare(`INSERT INTO content_lessons (entity_type, entity_slug, score, feedback, improvements) VALUES (?, ?, ?, ?, ?)`).bind(
            job.entityType, job.entitySlug, result.score,
            JSON.stringify(result.review || {}), JSON.stringify(result.review?.suggestions || [])
          ).run();
        } catch { /* non-critical */ }

        if (result.score >= 75) {
          await env.DB.prepare(
            `INSERT INTO publish_queue (entity_type, entity_slug, content_json, score, status, created_at)
             VALUES (?, ?, ?, ?, 'approved', datetime('now'))`
          ).bind(job.entityType, job.entitySlug, JSON.stringify(content), result.score).run();
        }

        console.log(`[Queue] Processed ${job.entitySlug}: score=${result.score} algo=${result.algoScore} passed=${result.passed}`);
        message.ack();
      } catch (error) {
        console.error(`[Queue] Failed ${message.body.entitySlug}:`, error);
        if (message.attempts >= 3) {
          await env.DB.prepare(
            'UPDATE pages SET status = ? WHERE id = ?'
          ).bind('generation_failed', message.body.pageId).run().catch(() => {});
          message.ack();
        } else {
          message.retry({
            delaySeconds: Math.min(Math.pow(2, message.attempts) * 5, 300),
          });
        }
      }
    }
  },
};
