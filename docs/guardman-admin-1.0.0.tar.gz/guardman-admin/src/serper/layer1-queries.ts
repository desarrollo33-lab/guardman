/**
 * Serper Agent — Layer 1: Strategic Query Generation
 * 
 * Generates high-value search queries tailored to GuardMan's SEO strategy.
 * Instead of generic "Service + Location" queries, we produce intent-specific
 * queries that surface competitor intelligence, local demand, and content gaps.
 */

import type { StrategicQuery, QueryPlan, QueryIntent, QueryPriority } from './types';

// ===== Service/Location config =====

interface ServiceInfo {
  slug: string;
  name: string;
  shortName: string;
  keywords: string[];
}

interface LocationInfo {
  slug: string;
  name: string;
  zone: string;
  region: string;
}

const SERVICES: ServiceInfo[] = [
  { slug: 'guardias-de-seguridad', name: 'Guardias de Seguridad', shortName: 'guardias', keywords: ['guardias', 'vigilantes', 'guardias de seguridad', 'personal de seguridad'] },
  { slug: 'cctv-videovigilancia', name: 'CCTV y Videovigilancia', shortName: 'cctv', keywords: ['cctv', 'videovigilancia', 'camaras de seguridad', 'camaras'] },
  { slug: 'control-de-accesos', name: 'Control de Accesos', shortName: 'accesos', keywords: ['control de accesos', 'biometrico', 'acceso biométrico', 'porton electrico'] },
  { slug: 'escoltas-privados', name: 'Escoltas Privados', shortName: 'escoltas', keywords: ['escoltas', 'escoltas privados', 'escolta VIP', 'custodia personal'] },
  { slug: 'monitoreo-24-7', name: 'Monitoreo 24/7', shortName: 'monitoreo', keywords: ['monitoreo 24/7', 'monitoreo remoto', 'alarma monitoreo', 'central de alarmas'] },
  { slug: 'seguridad-eventos', name: 'Seguridad para Eventos', shortName: 'eventos', keywords: ['seguridad eventos', 'vigilancia eventos', 'guardias eventos', 'seguridad fiestas'] },
  { slug: 'seguridad-industrial', name: 'Seguridad Industrial', shortName: 'industrial', keywords: ['seguridad industrial', 'vigilancia fabrica', 'guardias industriales', 'seguridad minera'] },
  { slug: 'auditoria-seguridad', name: 'Auditoría de Seguridad', shortName: 'auditoria', keywords: ['auditoria seguridad', 'evaluacion riesgos', 'consulta seguridad', 'diagnostico seguridad'] },
  { slug: 'guard-pod', name: 'Guard Pod', shortName: 'guardpod', keywords: ['guard pod', 'modulo seguridad', 'pod seguridad', 'caseta inteligente'] },
];

const LOCATION_NAMES: Record<string, LocationInfo> = {
  'las-condes':      { slug: 'las-condes', name: 'Las Condes', zone: 'Oriente', region: 'Metropolitana' },
  'vitacura':        { slug: 'vitacura', name: 'Vitacura', zone: 'Oriente', region: 'Metropolitana' },
  'lo-barnechea':    { slug: 'lo-barnechea', name: 'Lo Barnechea', zone: 'Oriente', region: 'Metropolitana' },
  'la-reina':        { slug: 'la-reina', name: 'La Reina', zone: 'Oriente', region: 'Metropolitana' },
  'huechuraba':      { slug: 'huechuraba', name: 'Huechuraba', zone: 'Norte', region: 'Metropolitana' },
  'quilicura':       { slug: 'quilicura', name: 'Quilicura', zone: 'Norte', region: 'Metropolitana' },
  'conchali':        { slug: 'conchali', name: 'Conchalí', zone: 'Norte', region: 'Metropolitana' },
  'santiago-centro':  { slug: 'santiago-centro', name: 'Santiago Centro', zone: 'Centro', region: 'Metropolitana' },
  'pudahuel':        { slug: 'pudahuel', name: 'Pudahuel', zone: 'Occidente', region: 'Metropolitana' },
  'la-pintana':      { slug: 'la-pintana', name: 'La Pintana', zone: 'Sur', region: 'Metropolitana' },
  'renca':            { slug: 'renca', name: 'Renca', zone: 'Norte', region: 'Metropolitana' },
  'lampa':            { slug: 'lampa', name: 'Lampa', zone: 'Norte', region: 'Metropolitana' },
  'los-andes':        { slug: 'los-andes', name: 'Los Andes', zone: 'Valle', region: 'Valparaíso' },
  'san-felipe':       { slug: 'san-felipe', name: 'San Felipe', zone: 'Valle', region: 'Valparaíso' },
};

// ===== Query Templates by Intent =====
// Each template defines a query pattern and what we expect to learn from it.

interface QueryTemplate {
  pattern: (svc: ServiceInfo, loc: LocationInfo) => string;
  intent: QueryIntent;
  priority: QueryPriority;
  endpoint: 'search' | 'places';
  rationale: string;
  expectedInsights: string[];
}

const QUERY_TEMPLATES: QueryTemplate[] = [
  // — CRITICAL: Transactional "ready to buy" queries —
  {
    pattern: (s, l) => `${s.name} ${l.name}`,
    intent: 'transactional',
    priority: 'critical',
    endpoint: 'search',
    rationale: 'Core SEO keyword — must rank in top 3',
    expectedInsights: ['SERP landscape', 'top competitors', 'content gap']
  },
  {
    pattern: (s, l) => `${s.name} ${l.name} precio`,
    intent: 'transactional',
    priority: 'critical',
    endpoint: 'search',
    rationale: 'High commercial intent — pricing queries are gold',
    expectedInsights: ['competitor pricing pages', 'price comparison directories', 'paid ads']
  },
  {
    pattern: (s, l) => `contratar ${s.shortName} ${l.name}`,
    intent: 'transactional',
    priority: 'critical',
    endpoint: 'search',
    rationale: 'Purchase-intent query — signals immediate need',
    expectedInsights: ['active competitors', 'lead-gen directories', 'ad competition']
  },
  {
    pattern: (s, l) => `empresa de ${s.keywords[0]} ${l.name}`,
    intent: 'commercial',
    priority: 'high',
    endpoint: 'search',
    rationale: 'Comparison shopping — user evaluating options',
    expectedInsights: ['competitor list', 'directory listings', 'review pages']
  },
  // — HIGH: Commercial comparison queries —
  {
    pattern: (s, l) => `mejor ${s.name} en ${l.name}`,
    intent: 'commercial',
    priority: 'high',
    endpoint: 'search',
    rationale: '"Best of" query — ranking here = authority signal',
    expectedInsights: ['competitor comparison content', 'review aggregators', 'forum discussions']
  },
  {
    pattern: (s, l) => `${s.shortName} ${l.name} opiniones`,
    intent: 'commercial',
    priority: 'high',
    endpoint: 'search',
    rationale: 'Reviews query — reveals reputation landscape',
    expectedInsights: ['review sites', 'Google Business profiles', 'social proof']
  },
  // — HIGH: Local/Places —
  {
    pattern: (s, l) => `${s.name} ${l.name}`,
    intent: 'local',
    priority: 'high',
    endpoint: 'places',
    rationale: 'Local pack results — must appear in Google Maps',
    expectedInsights: ['local competitors', 'map rankings', 'review counts']
  },
  // — MEDIUM: Informational content gap queries —
  {
    pattern: (s, l) => `como elegir ${s.keywords[0]} en ${l.name}`,
    intent: 'informational',
    priority: 'medium',
    endpoint: 'search',
    rationale: 'Content opportunity — blog/guide that captures top-of-funnel',
    expectedInsights: ['blog content gaps', 'guide formatting opportunities']
  },
  {
    pattern: (s, l) => `${s.keywords[0]} ${l.name} cobertura 24 horas`,
    intent: 'informational',
    priority: 'medium',
    endpoint: 'search',
    rationale: 'Specific service feature query — highlights 24/7 positioning',
    expectedInsights: ['competitor 24/7 claims', 'availability messaging']
  },
  // — MEDIUM: Urgency / emergency queries —
  {
    pattern: (s, l) => `${s.keywords[0]} urgente ${l.name}`,
    intent: 'transactional',
    priority: 'medium',
    endpoint: 'search',
    rationale: 'Emergency intent — very high conversion if we rank',
    expectedInsights: ['emergency services competitors', 'ads competition']
  },
  // — LOW: Long-tail —
  {
    pattern: (s, l) => `${s.name} ${l.name} OS-10 certificado`,
    intent: 'commercial',
    priority: 'low',
    endpoint: 'search',
    rationale: 'OS-10 is our competitive advantage — differentiate from bottom-tier providers',
    expectedInsights: ['OS-10 mentions', 'certification requirements content']
  },
];

// ===== Plan Generator =====

export function generateQueryPlan(serviceSlug: string, locationSlug: string): QueryPlan {
  const service = SERVICES.find(s => s.slug === serviceSlug);
  const location = LOCATION_NAMES[locationSlug];
  
  if (!service || !location) {
    throw new Error('Unknown service or location: ' + serviceSlug + ' / ' + locationSlug);
  }

  const queries: StrategicQuery[] = [];
  
  for (const template of QUERY_TEMPLATES) {
    const queryText = template.pattern(service, location);
    // Check for duplicates
    if (queries.some(q => q.query_text === queryText && q.endpoint === template.endpoint)) continue;
    
    queries.push({
      query_text: queryText,
      intent: template.intent,
      priority: template.priority,
      endpoint: template.endpoint,
      service_slug: serviceSlug,
      location_slug: locationSlug,
      rationale: template.rationale,
      expected_insights: template.expectedInsights,
    });
  }

  return {
    service_slug: serviceSlug,
    location_slug: locationSlug,
    service_name: service.name,
    location_name: location.name,
    queries,
    total_credits: queries.filter(q => q.endpoint === 'search').length + Math.ceil(queries.filter(q => q.endpoint === 'places').length * 0.5),
    generated_by: 'template',
    generated_at: new Date().toISOString(),
  };
}

/**
 * Generate ALL query plans for a given set of services × locations
 */
export function generateAllPlans(serviceSlugs: string[], locationSlugs: string[]): QueryPlan[] {
  return serviceSlugs.flatMap(svc => 
    locationSlugs.map(loc => generateQueryPlan(svc, loc))
  );
}

/**
 * Get service info by slug
 */
export function getServiceInfo(slug: string): ServiceInfo | undefined {
  return SERVICES.find(s => s.slug === slug);
}

/**
 * Get location info by slug
 */
export function getLocationInfo(slug: string): LocationInfo | undefined {
  return LOCATION_NAMES[slug];
}

/**
 * Get all service slugs
 */
export function getAllServiceSlugs(): string[] {
  return SERVICES.map(s => s.slug);
}

/**
 * Get all location slugs
 */
export function getAllLocationSlugs(): string[] {
  return Object.keys(LOCATION_NAMES);
}