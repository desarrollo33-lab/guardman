/**
 * Serper Agent — Main Pipeline Orchestrator
 * 
 * Coordinates the 3-layer pipeline and provides the API interface.
 * Also includes the "re-process existing data" utility to extract
 * results from already-stored response_json without burning new credits.
 */

import { generateQueryPlan, generateAllPlans, getAllServiceSlugs, getAllLocationSlugs } from './layer1-queries';
import { executeQueryPlan, callSerperSearch, callSerperPlaces, storeQueryAndResults, storePlacesResults } from './layer2-executor';
import { classifyAllResults, getClassificationStats } from './layer3-classifier';
import type { QueryPlan, StrategicQuery, ExecutionResult, ClassificationStats, PipelineResult } from './types';

interface Env {
  DB: any;
  SERPER_API_KEY?: string;
}

// ===== Pipeline Execution Modes =====

export type PipelineMode = 
  | 'dry-run'          // Show plan without executing
  | 'single-combo'     // Execute for one service×location combo
  | 'full'             // Execute for all combos
  | 'reprocess-existing'; // Re-process stored response_json without API calls

export interface PipelineRequest {
  mode: PipelineMode;
  serviceSlug?: string;
  locationSlug?: string;
  serviceSlugs?: string[];
  locationSlugs?: string[];
  skipIfExists?: boolean;   // Don't re-query if already have results
  reclassifyOnly?: boolean;  // Only re-classify, no new API calls
}

// ===== Execute Full Pipeline =====

export async function runPipeline(env: Env, request: PipelineRequest): Promise<{
  plan?: QueryPlan;
  executionResults?: ExecutionResult[];
  classificationStats?: ClassificationStats;
  error?: string;
}> {
  
  // MODE: Reprocess existing data
  if (request.mode === 'reprocess-existing') {
    const stats = await reprocessExistingData(env);
    return { classificationStats: stats };
  }

  // MODE: Reclassify only
  if (request.reclassifyOnly) {
    const stats = await classifyAllResults(env);
    return { classificationStats: stats };
  }

  // Generate query plans
  let plans: StrategicQuery[][] = [];

  if (request.mode === 'single-combo' && request.serviceSlug && request.locationSlug) {
    const plan = generateQueryPlan(request.serviceSlug, request.locationSlug);
    plans = [plan.queries];
  } else if (request.mode === 'full' || request.mode === 'dry-run') {
    const serviceSlugs = request.serviceSlugs || getAllServiceSlugs();
    const locationSlugs = request.locationSlugs || getAllLocationSlugs();
    const allPlans = generateAllPlans(serviceSlugs, locationSlugs);
    plans = allPlans.map(p => p.queries);
  } else {
    return { error: 'Invalid mode or missing parameters' };
  }

  // Flatten all queries
  const allQueries = plans.flat();

  // DRY-RUN: Just return the plan
  if (request.mode === 'dry-run') {
    const firstPlan = generateQueryPlan(request.serviceSlug || getAllServiceSlugs()[0], request.locationSlug || getAllLocationSlugs()[0]);
    return { plan: { ...firstPlan, queries: allQueries } };
  }

  // Check which queries already exist (skip if requested)
  let queriesToExecute = allQueries;
  if (request.skipIfExists) {
    const existing = await env.DB.prepare(
      'SELECT query_text, endpoint FROM serper_queries WHERE status = ?'
    ).bind('completed').all();
    const existingSet = new Set((existing.results as any[]).map(r => r.query_text + '|' + r.endpoint));
    queriesToExecute = allQueries.filter(q => !existingSet.has(q.query_text + '|' + q.endpoint));
  }

  // Execute
  const executionResults = await executeQueryPlan(env, queriesToExecute);

  // Classify
  const classificationStats = await classifyAllResults(env);

  return { executionResults, classificationStats };
}

// ===== Re-process Existing Data =====

/**
 * Parses ALL stored response_json in serper_queries and re-extracts
 * results into serper_results. This is crucial for recovering from
 * the old pipeline that only saved 11 results out of ~12,680.
 */
export async function reprocessExistingData(env: Env): Promise<ClassificationStats> {
  const BATCH_SIZE = 50;
  let offset = 0;
  let totalProcessed = 0;
  let totalResultsSaved = 0;

  while (true) {
    const { results } = await env.DB.prepare(
      'SELECT id, service_slug, location_slug, query_text, endpoint, response_json, credits_used FROM serper_queries WHERE status = ? AND response_json IS NOT NULL AND LENGTH(response_json) > 100 ORDER BY id LIMIT ? OFFSET ?'
    ).bind('completed', BATCH_SIZE, offset).all();

    if (results.length === 0) break;

    for (const row of results as any[]) {
      try {
        const response = JSON.parse(row.response_json);
        const query: StrategicQuery = {
          query_text: row.query_text,
          intent: 'commercial', // We don't know the original intent, default
          priority: 'medium',
          endpoint: row.endpoint,
          service_slug: row.service_slug,
          location_slug: row.location_slug,
          rationale: 'Reprocessed from existing data',
          expected_insights: [],
        };

        if (row.endpoint === 'search') {
          const { resultsSaved } = await storeQueryAndResults(env, query, response, row.credits_used || 1);
          totalResultsSaved += resultsSaved;
        } else if (row.endpoint === 'places') {
          const places = response.places || response.organic || [];
          const { resultsSaved } = await storePlacesResults(env, query, places, row.credits_used || 1);
          totalResultsSaved += resultsSaved;
        }

        totalProcessed++;
      } catch (err: any) {
        console.error('Error reprocessing query ' + row.id + ': ' + (err.message || err));
      }
    }

    offset += BATCH_SIZE;
  }

  // After reprocessing, classify everything
  const stats = await classifyAllResults(env);
  return stats;
}

// ===== Export Stats for Dashboard =====

export async function getSerperDashboardData(env: Env) {
  const [
    totalQueries,
    completedQueries,
    totalCreditsUsed,
    totalResults,
    resultsByType,
    resultsBySiteType,
    topCompetitors,
    topDirectories,
    jobBoards,
    guardmanPresence,
    recentQueries,
    paidCreditsWasted,
  ] = await Promise.all([
    env.DB.prepare('SELECT COUNT(*) as c FROM serper_queries').first(),
    env.DB.prepare('SELECT COUNT(*) as c FROM serper_queries WHERE status = ?').bind('completed').first(),
    env.DB.prepare('SELECT COALESCE(SUM(credits_used), 0) as c FROM serper_queries').first(),
    env.DB.prepare('SELECT COUNT(*) as c FROM serper_results').first(),
    env.DB.prepare('SELECT result_type, COUNT(*) as c FROM serper_results GROUP BY result_type ORDER BY c DESC').all(),
    env.DB.prepare('SELECT site_type, COUNT(*) as c FROM serper_results WHERE result_type IN (?, ?, ?) GROUP BY site_type ORDER BY c DESC').bind('organic', 'place', 'knowledge_graph').all(),
    env.DB.prepare('SELECT domain, COUNT(*) as appearances, AVG(position) as avg_pos FROM serper_results WHERE site_type = ? GROUP BY domain ORDER BY appearances DESC LIMIT 20').bind('direct_competitor').all(),
    env.DB.prepare('SELECT DISTINCT domain FROM serper_results WHERE site_type = ?').bind('directory').all(),
    env.DB.prepare('SELECT DISTINCT domain FROM serper_results WHERE site_type = ?').bind('job_board').all(),
    env.DB.prepare('SELECT sq.query_text, sr.position, sr.title, sr.link FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.site_type = ? ORDER BY sr.position ASC LIMIT 20').bind('own').all(),
    env.DB.prepare('SELECT sq.query_text, sq.endpoint, sq.status, sq.credits_used, sq.executed_at FROM serper_queries sq ORDER BY sq.id DESC LIMIT 10').all(),
    env.DB.prepare('SELECT COALESCE(SUM(credits_used), 0) as c FROM serper_queries WHERE status = ? AND (response_json IS NULL OR LENGTH(response_json) < 100)').bind('completed').first(),
  ]);

  return {
    totalQueries: totalQueries?.c || 0,
    completedQueries: completedQueries?.c || 0,
    totalCreditsUsed: totalCreditsUsed?.c || 0,
    totalResults: totalResults?.c || 0,
    resultsByType: resultsByType.results,
    resultsBySiteType: resultsBySiteType.results,
    topCompetitors: topCompetitors.results,
    directories: (resultsBySiteType.results as any[]).filter(r => r.site_type === 'directory').reduce((sum, r) => sum + (r.c as number), 0),
    jobBoardsCount: (jobBoards.results as any[]).length,
    guardmanPresence: guardmanPresence.results,
    recentQueries: recentQueries.results,
    paidCreditsWasted: paidCreditsWasted?.c || 0,
  };
}

// Re-export for convenience
export { generateQueryPlan, generateAllPlans, getAllServiceSlugs, getAllLocationSlugs } from './layer1-queries';
export { executeQueryPlan, storeQueryAndResults, callSerperSearch, callSerperPlaces } from './layer2-executor';
export { classifyAllResults, getClassificationStats } from './layer3-classifier';