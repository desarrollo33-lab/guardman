/**
 * Serper Agent — Layer 3: Classification & Quality Filtering
 * 
 * Takes raw serper_results and classifies them into meaningful categories.
 * Uses batch D1 operations to avoid Worker CPU timeout.
 */

import type { DomainCategory, QualityTier, ClassificationStats } from './types';

interface Env {
  DB: any;
}

// ===== Domain Classification Rules =====

interface DomainRule {
  pattern: RegExp;
  category: DomainCategory;
  quality: QualityTier;
  label: string;
}

const DOMAIN_RULES: DomainRule[] = [
  // — Job Boards ( Bronze ) —
  { pattern: /computrabajo\.com/i, category: 'job_board', quality: 'bronze', label: 'Computrabajo' },
  { pattern: /indeed\.com/i, category: 'job_board', quality: 'bronze', label: 'Indeed' },
  { pattern: /linkedin\.com/i, category: 'job_board', quality: 'bronze', label: 'LinkedIn' },
  { pattern: /jooble\.org/i, category: 'job_board', quality: 'bronze', label: 'Jooble' },
  { pattern: /laborum\.cl/i, category: 'job_board', quality: 'bronze', label: 'Laborum' },
  { pattern: /trabajando\.cl/i, category: 'job_board', quality: 'bronze', label: 'Trabajando.cl' },
  { pattern: /getonbrd/i, category: 'job_board', quality: 'bronze', label: 'GetOnBoard' },
  { pattern: /jobsora/i, category: 'job_board', quality: 'bronze', label: 'Jobsora' },
  
  // — Directories ( Bronze ) —
  { pattern: /2x3\.cl/i, category: 'directory', quality: 'bronze', label: '2x3' },
  { pattern: /amarillas\.cl|amarillas\.com/i, category: 'directory', quality: 'bronze', label: 'Amarillas' },
  { pattern: /yelp\.com/i, category: 'directory', quality: 'bronze', label: 'Yelp' },
  { pattern: /tripadvisor/i, category: 'directory', quality: 'bronze', label: 'TripAdvisor' },
  { pattern: /directorio|catalogo|guia.*chile/i, category: 'directory', quality: 'bronze', label: 'Directorio' },
  
  // — Social ( Bronze ) —
  { pattern: /facebook\.com/i, category: 'social', quality: 'bronze', label: 'Facebook' },
  { pattern: /instagram\.com/i, category: 'social', quality: 'bronze', label: 'Instagram' },
  { pattern: /youtube\.com/i, category: 'social', quality: 'bronze', label: 'YouTube' },
  { pattern: /tiktok\.com/i, category: 'social', quality: 'bronze', label: 'TikTok' },
  { pattern: /twitter\.com|x\.com/i, category: 'social', quality: 'bronze', label: 'X/Twitter' },
  { pattern: /reddit\.com/i, category: 'social', quality: 'bronze', label: 'Reddit' },
  { pattern: /pinterest\.com/i, category: 'social', quality: 'bronze', label: 'Pinterest' },
  { pattern: /whatsapp/i, category: 'social', quality: 'bronze', label: 'WhatsApp' },
  
  // — Marketplace ( Bronze ) —
  { pattern: /mercadolibre|mercadolivre/i, category: 'marketplace', quality: 'bronze', label: 'MercadoLibre' },
  { pattern: /sodimac|easy|construmart/i, category: 'marketplace', quality: 'bronze', label: 'Retail' },
  
  // — Service Marketplaces ( Bronze — competitor directories we can list on ) —
  { pattern: /cronoshare/i, category: 'directory', quality: 'bronze', label: 'Cronoshare' },
  { pattern: /habitissimo/i, category: 'directory', quality: 'bronze', label: 'Habitissimo' },
  { pattern: /starofservice/i, category: 'directory', quality: 'bronze', label: 'StarOfService' },
  { pattern: /branner/i, category: 'directory', quality: 'bronze', label: 'Branner' },
  
  // — Government ( Silver ) —
  { pattern: /gob\.cl|\.gob\.cl/i, category: 'government', quality: 'silver', label: 'Gobierno' },
  { pattern: /municipal|\.mun\./i, category: 'government', quality: 'silver', label: 'Municipalidad' },
  { pattern: /carabineros|pdi\./i, category: 'government', quality: 'silver', label: 'Fuerzas Orden' },
  
  // — Media ( Silver ) —
  { pattern: /latercera|t13|emol|biobiochile|cooperativa|24horas|chv|megatv|canal13/i, category: 'media', quality: 'silver', label: 'Medio' },
  
  // — GuardMan ( Gold ) —
  { pattern: /guardman/i, category: 'own', quality: 'gold', label: 'GuardMan' },
  
  // — Known Chilean Security Competitors ( Gold — real competitors ) —
  { pattern: /sicseguridad/i, category: 'direct_competitor', quality: 'gold', label: 'SIC Seguridad' },
  { pattern: /federalseguridad/i, category: 'direct_competitor', quality: 'gold', label: 'Federal Seguridad' },
  { pattern: /c3a\.cl/i, category: 'direct_competitor', quality: 'gold', label: 'C3A Chile' },
  { pattern: /ayressecurity/i, category: 'direct_competitor', quality: 'gold', label: 'Ayres Security' },
  { pattern: /isegchile/i, category: 'direct_competitor', quality: 'gold', label: 'ISEG Chile' },
  { pattern: /prosegur/i, category: 'direct_competitor', quality: 'gold', label: 'Prosegur' },
  { pattern: /brinks/i, category: 'direct_competitor', quality: 'gold', label: 'Brinks' },
  { pattern: /adt\.cl|adtseguridad/i, category: 'direct_competitor', quality: 'gold', label: 'ADT' },
  { pattern: /secruna/i, category: 'direct_competitor', quality: 'gold', label: 'Secruna' },
  { pattern: /patrullaverde/i, category: 'direct_competitor', quality: 'gold', label: 'Patrulla Verde' },
  { pattern: /seguridadprivadachile/i, category: 'direct_competitor', quality: 'gold', label: 'SegPrivChile' },
  { pattern: /santiagoseguridadprivada/i, category: 'direct_competitor', quality: 'gold', label: 'StgoSegPrivada' },
  { pattern: /guardiasempresas/i, category: 'direct_competitor', quality: 'gold', label: 'GuardiasEmpresas' },
  { pattern: /federalchile|federalaccess/i, category: 'direct_competitor', quality: 'gold', label: 'Federal Chile' },
  { pattern: /gaspal/i, category: 'direct_competitor', quality: 'gold', label: 'Gaspal' },
  { pattern: /tricap/i, category: 'direct_competitor', quality: 'gold', label: 'Tricap' },
  { pattern: /asepri/i, category: 'direct_competitor', quality: 'gold', label: 'Asepri' },
  { pattern: /marvi\.cl/i, category: 'direct_competitor', quality: 'gold', label: 'Marvi' },
  { pattern: /spysecurity|spychile/i, category: 'direct_competitor', quality: 'gold', label: 'SpySecurity' },
  { pattern: /tecnoprotec/i, category: 'direct_competitor', quality: 'gold', label: 'Tecnoprotec' },
  { pattern: /monitorseguridad|monitor.*seguridad/i, category: 'direct_competitor', quality: 'gold', label: 'MonitorSeguridad' },
  { pattern: /vigilaprivada/i, category: 'direct_competitor', quality: 'gold', label: 'Vigiladora' },
  { pattern: /seguridadtotal|seguridadelectronica/i, category: 'direct_competitor', quality: 'gold', label: 'SegTotal' },
  { pattern: /chilena.*seguridad|seguridad.*chile/i, category: 'direct_competitor', quality: 'gold', label: 'SegChile' },
];

function classifyDomain(domain: string): { category: DomainCategory; quality: QualityTier; label: string } {
  for (const rule of DOMAIN_RULES) {
    if (rule.pattern.test(domain)) {
      return { category: rule.category, quality: rule.quality, label: rule.label };
    }
  }
  
  const isCl = domain.endsWith('.cl');
  if (isCl) {
    return { category: 'indirect_competitor', quality: 'silver', label: 'Sitio CL' };
  }
  
  return { category: 'irrelevant', quality: 'bronze', label: 'Internacional' };
}

// ===== Relevance Scoring =====

function calculateRelevance(
  title: string,
  snippet: string,
  domain: string,
  category: DomainCategory,
  position: number,
  serviceKeywords: string[],
  locationName: string
): number {
  let score = 0;
  const text = (title + ' ' + snippet + ' ' + domain).toLowerCase();
  
  for (const kw of serviceKeywords) {
    if (text.includes(kw.toLowerCase())) { score += 10; break; }
  }
  if (text.includes(locationName.toLowerCase())) score += 25;
  if (position <= 3) score += 20;
  else if (position <= 5) score += 15;
  else if (position <= 10) score += 8;
  
  const categoryScores: Record<string, number> = {
    'own': 15, 'direct_competitor': 15, 'indirect_competitor': 10,
    'government': 8, 'directory': 5, 'media': 8,
    'job_board': 2, 'social': 3, 'marketplace': 2, 'irrelevant': 0,
  };
  score += categoryScores[category] || 0;
  if (domain.endsWith('.cl')) score += 10;
  
  return Math.min(100, score);
}

// ===== Key insights extraction =====

function extractInsights(title: string, snippet: string, category: DomainCategory, position: number): string[] {
  const insights: string[] = [];
  const text = (title + ' ' + snippet).toLowerCase();
  
  if (category === 'direct_competitor') {
    if (text.includes('os-10') || text.includes('os10') || text.includes('certificado')) insights.push('Menciona OS-10');
    if (text.includes('24/7') || text.includes('24 horas')) insights.push('Ofrece 24/7');
    if (text.includes('precio') || text.includes('cotizar') || text.includes('presupuesto')) insights.push('CTA de cotizacion');
    if (position <= 3) insights.push('TOP 3');
  }
  if (category === 'job_board') insights.push('Portal de empleo');
  if (category === 'directory') insights.push('Directorio');
  return insights;
}

// ===== Main classification function (batch D1 operations) =====

export async function classifyAllResults(env: Env): Promise<ClassificationStats> {
  const BATCH_SIZE = 100;
  let offset = 0;
  let totalProcessed = 0;

  const services = await env.DB.prepare('SELECT slug, name FROM services').all();
  const serviceKeywordMap: Record<string, string[]> = {};
  for (const svc of services.results as any[]) {
    serviceKeywordMap[svc.slug] = svc.name.toLowerCase().split(/\s+/);
  }
  
  const locations = await env.DB.prepare('SELECT slug, name FROM locations').all();
  const locationNameMap: Record<string, string> = {};
  for (const loc of locations.results as any[]) {
    locationNameMap[loc.slug] = loc.name;
  }

  const categories: DomainCategory[] = ['direct_competitor', 'indirect_competitor', 'job_board', 'directory', 'government', 'social', 'marketplace', 'media', 'own', 'irrelevant'];
  const qualities: QualityTier[] = ['gold', 'silver', 'bronze', 'spam'];
  
  const stats: ClassificationStats = {
    total_results: 0,
    by_category: {} as any,
    by_quality: {} as any,
    real_competitors: 0,
    real_competitor_domains: [],
    guardman_positions: 0,
    directories: [],
    job_boards: [],
    opportunities: [],
  };

  for (const c of categories) stats.by_category[c] = 0;
  for (const q of qualities) stats.by_quality[q] = 0;

  const competitorDomains = new Set<string>();
  const directoryDomains = new Set<string>();
  const jobBoardDomains = new Set<string>();

  // Process in batches to avoid Worker CPU timeout
  while (true) {
    const { results } = await env.DB.prepare(
      'SELECT sr.id, sr.result_type, sr.position, sr.title, sr.domain, sr.snippet, sr.extra_json, sq.service_slug, sq.location_slug FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.result_type IN (\'organic\', \'place\', \'knowledge_graph\') ORDER BY sr.id LIMIT ? OFFSET ?'
    ).bind(BATCH_SIZE, offset).all();

    if (results.length === 0) break;

    const batch: any[] = [];
    for (const row of results as any[]) {
      const domain = row.domain || '';
      const classification = classifyDomain(domain);
      const serviceKeywords = serviceKeywordMap[row.service_slug] || [];
      const locationName = locationNameMap[row.location_slug] || '';
      
      const relevanceScore = calculateRelevance(
        row.title || '', row.snippet || '', domain,
        classification.category, row.position, serviceKeywords, locationName
      );
      
      const insights = extractInsights(row.title || '', row.snippet || '', classification.category, row.position);
      const isChilean = domain.endsWith('.cl') ? 1 : 0;

      let existingExtra: any = {};
      try { existingExtra = JSON.parse(row.extra_json || '{}'); } catch {}

      const newExtra = JSON.stringify({
        ...existingExtra,
        quality_tier: classification.quality,
        relevance_score: relevanceScore,
        classification_label: classification.label,
        key_insights: insights,
      });

      batch.push(
        env.DB.prepare(
          'UPDATE serper_results SET site_type = ?, is_cl = ?, extra_json = ? WHERE id = ?'
        ).bind(classification.category, isChilean, newExtra, row.id)
      );

      stats.by_category[classification.category]++;
      stats.by_quality[classification.quality]++;
      totalProcessed++;

      if (classification.category === 'direct_competitor') {
        stats.real_competitors++;
        competitorDomains.add(domain);
      }
      if (classification.category === 'own') stats.guardman_positions++;
      if (classification.category === 'directory') directoryDomains.add(domain);
      if (classification.category === 'job_board') jobBoardDomains.add(domain);
    }

    // Execute batch
    if (batch.length > 0) {
      await env.DB.batch(batch);
    }

    offset += BATCH_SIZE;
    if (results.length < BATCH_SIZE) break;
  }

  stats.total_results = totalProcessed;
  stats.real_competitor_domains = Array.from(competitorDomains);
  stats.directories = Array.from(directoryDomains);
  stats.job_boards = Array.from(jobBoardDomains);

  // PAA opportunities
  const paaResults = await env.DB.prepare(
    'SELECT DISTINCT sr.title FROM serper_results sr WHERE sr.result_type = \'paa\''
  ).all();
  stats.opportunities = (paaResults.results as any[]).map(r => r.title);

  return stats;
}

// ===== Get classification stats (fast, no writes) =====

export async function getClassificationStats(env: Env): Promise<ClassificationStats> {
  const categories = ['direct_competitor', 'indirect_competitor', 'job_board', 'directory', 'government', 'social', 'marketplace', 'media', 'own', 'irrelevant'] as DomainCategory[];
  const qualities = ['gold', 'silver', 'bronze', 'spam'] as QualityTier[];
  
  const stats: ClassificationStats = {
    total_results: 0,
    by_category: {} as any,
    by_quality: {} as any,
    real_competitors: 0,
    real_competitor_domains: [],
    guardman_positions: 0,
    directories: [],
    job_boards: [],
    opportunities: [],
  };

  for (const c of categories) stats.by_category[c] = 0;
  for (const q of qualities) stats.by_quality[q] = 0;

  const { results: typeResults } = await env.DB.prepare(
    'SELECT site_type, COUNT(*) as cnt FROM serper_results WHERE result_type IN (\'organic\', \'place\', \'knowledge_graph\') GROUP BY site_type'
  ).all();
  
  for (const row of typeResults as any[]) {
    const cat = row.site_type as DomainCategory;
    if (cat && stats.by_category[cat] !== undefined) {
      stats.by_category[cat] = row.cnt as number;
    }
  }

  const totalResult = await env.DB.prepare('SELECT COUNT(*) as cnt FROM serper_results WHERE result_type IN (\'organic\', \'place\', \'knowledge_graph\')').first();
  stats.total_results = (totalResult?.cnt as number) || 0;

  const compResult = await env.DB.prepare('SELECT DISTINCT domain FROM serper_results WHERE site_type = \'direct_competitor\'').all();
  stats.real_competitor_domains = (compResult.results as any[]).map(r => r.domain);
  stats.real_competitors = stats.real_competitor_domains.length;

  const gmResult = await env.DB.prepare('SELECT COUNT(*) as cnt FROM serper_results WHERE site_type = \'own\'').first();
  stats.guardman_positions = (gmResult?.cnt as number) || 0;

  const dirResult = await env.DB.prepare('SELECT DISTINCT domain FROM serper_results WHERE site_type = \'directory\'').all();
  stats.directories = (dirResult.results as any[]).map(r => r.domain);

  const jobResult = await env.DB.prepare('SELECT DISTINCT domain FROM serper_results WHERE site_type = \'job_board\'').all();
  stats.job_boards = (jobResult.results as any[]).map(r => r.domain);

  return stats;
}