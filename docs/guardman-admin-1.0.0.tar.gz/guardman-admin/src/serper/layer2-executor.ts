/**
 * Serper Agent — Layer 2: Execution & Storage
 * 
 * Executes Serper API calls and stores ALL results properly
 * in serper_queries + serper_results tables.
 * 
 * Key fix: The old pipeline only stored 11 of ~12,680 results.
 * This layer ensures 100% fidelity between API response and DB storage.
 */

import type { StrategicQuery, SerperResponse, ExecutionResult } from './types';

// API key is provided via Cloudflare wrangler secret (env.SERPER_API_KEY)
const SERPER_BASE = 'https://google.serper.dev';

interface Env {
  DB: any;
  SERPER_API_KEY?: string;
}

// ===== Rate-limited fetch =====
let lastCallTime = 0;
const MIN_INTERVAL = 250; // 250ms between calls = ~4/sec max

async function rateLimitedFetch(url: string, options: RequestInit): Promise<Response> {
  const now = Date.now();
  const elapsed = now - lastCallTime;
  if (elapsed < MIN_INTERVAL) {
    await new Promise(r => setTimeout(r, MIN_INTERVAL - elapsed));
  }
  lastCallTime = Date.now();
  return fetch(url, options);
}

// ===== Serper API Calls =====

export async function callSerperSearch(query: string, gl = 'cl', hl = 'es', num = 10, apiKey?: string): Promise<SerperResponse> {
  if (!apiKey) throw new Error('SERPER_API_KEY not configured');
  const key = apiKey;
  const res = await rateLimitedFetch(SERPER_BASE + '/search', {
    method: 'POST',
    headers: {
      'X-API-KEY': key,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ q: query, gl, hl, num }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error('Serper search API error ' + res.status + ': ' + errText.substring(0, 300));
  }

  return res.json();
}

export async function callSerperPlaces(query: string, gl = 'cl', hl = 'es', apiKey?: string): Promise<SerperResponse> {
  if (!apiKey) throw new Error('SERPER_API_KEY not configured');
  const key = apiKey;
  const res = await rateLimitedFetch(SERPER_BASE + '/places', {
    method: 'POST',
    headers: {
      'X-API-KEY': key,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ q: query, gl, hl }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error('Serper places API error ' + res.status + ': ' + errText.substring(0, 300));
  }

  return res.json()
}

// ===== Domain Extraction =====

function extractDomain(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url.replace(/^https?:\/\//, '').split('/')[0].replace(/^www\./, '');
  }
}

// ===== Store Results in D1 =====

export async function storeQueryAndResults(
  env: Env,
  query: StrategicQuery,
  response: SerperResponse,
  creditsUsed: number
): Promise<{ queryId: number; resultsSaved: number }> {
  
  // 1. Insert or update the query record
  const existingQuery = await env.DB.prepare(
    'SELECT id FROM serper_queries WHERE service_slug = ? AND location_slug = ? AND endpoint = ? AND query_text = ?'
  ).bind(query.service_slug, query.location_slug, query.endpoint, query.query_text).first();

  let queryId: number;
  const responseJson = JSON.stringify(response);

  if (existingQuery) {
    queryId = existingQuery.id as number;
    await env.DB.prepare(
      'UPDATE serper_queries SET response_json = ?, status = ?, credits_used = ?, executed_at = datetime(\'now\') WHERE id = ?'
    ).bind(responseJson, 'completed', creditsUsed, queryId).run();
  } else {
    const insertResult = await env.DB.prepare(
      'INSERT INTO serper_queries (service_slug, location_slug, query_text, endpoint, response_json, status, credits_used, executed_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime(\'now\'))'
    ).bind(query.service_slug, query.location_slug, query.query_text, query.endpoint, responseJson, 'completed', creditsUsed).run();
    queryId = insertResult.meta.last_row_id as number;
  }

  // 2. Delete old results for this query (re-parse fresh)
  await env.DB.prepare('DELETE FROM serper_results WHERE query_id = ?').bind(queryId).run();

  // 3. Parse and insert organic results
  let resultsSaved = 0;

  if (response.organic && response.organic.length > 0) {
    const stmt = env.DB.prepare(
      'INSERT INTO serper_results (query_id, result_type, position, title, link, domain, snippet, site_type, is_cl, extra_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    const batch = [];
    for (const result of response.organic) {
      const domain = extractDomain(result.link);
      const siteType = classifyDomainQuick(domain);
      const isCl = domain.endsWith('.cl') ? 1 : 0;
      const extra = JSON.stringify({ date: result.date || null });
      batch.push(stmt.bind(queryId, 'organic', result.position, result.title, result.link, domain, result.snippet, siteType, isCl, extra));
    }
    const batchResult = await env.DB.batch(batch);
    resultsSaved += batch.length;
  }

  // 4. Parse knowledge graph
  if (response.knowledgeGraph) {
    const kg = response.knowledgeGraph;
    await env.DB.prepare(
      'INSERT INTO serper_results (query_id, result_type, position, title, link, domain, snippet, rating, reviews_count, address, site_type, is_cl, extra_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(
      queryId, 'knowledge_graph', 0,
      kg.title || null, kg.website || null, kg.website ? extractDomain(kg.website) : null,
      kg.description || null, kg.rating || null, kg.reviews || null, kg.address || null,
      'authority', kg.website?.endsWith('.cl') ? 1 : 0,
      JSON.stringify({ type: kg.type || null })
    ).run();
    resultsSaved++;
  }

  // 5. Parse People Also Ask (handle both 'peopleAlsoAsk' and 'paa' key formats)
  const paaData = (response as any).peopleAlsoAsk || (response as any).paa || [];
  if (paaData && paaData.length > 0) {
    const stmt = env.DB.prepare(
      'INSERT INTO serper_results (query_id, result_type, position, title, link, domain, snippet, site_type, is_cl, extra_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    const batch = [];
    for (let i = 0; i < paaData.length; i++) {
      const paa = paaData[i];
      const domain = paa.link ? extractDomain(paa.link) : null;
      batch.push(stmt.bind(
        queryId, 'paa', i + 1,
        paa.question || paa.title || paa.snippet, paa.link || null, domain,
        paa.snippet || paa.title || null,
        domain ? classifyDomainQuick(domain) : null,
        domain?.endsWith('.cl') ? 1 : 0,
        JSON.stringify({})
      ));
    }
    await env.DB.batch(batch);
    resultsSaved += batch.length;
  }

  // 6. Parse related searches — store as result_type='related_search'
  // Handle both 'relatedSearches' format [{query: '...'}] and plain string format
  const rsData = (response as any).relatedSearches || [];
  if (rsData && rsData.length > 0) {
    const stmt = env.DB.prepare(
      'INSERT INTO serper_results (query_id, result_type, position, title, site_type, extra_json) VALUES (?, ?, ?, ?, ?, ?)'
    );
    const batch = [];
    for (let i = 0; i < rsData.length; i++) {
      const rs = rsData[i];
      // rs can be {query: '...'} or a plain string
      const queryText = typeof rs === 'string' ? rs : (rs.query || rs.title || String(rs));
      batch.push(stmt.bind(queryId, 'related_search', i + 1, queryText, null, JSON.stringify({})));
    }
    await env.DB.batch(batch);
    resultsSaved += batch.length;
  }

  // 7. Parse places (if this was a places query, this arrives differently)
  // For search endpoint, localPack results
  // Note: Serper's 'search' endpoint doesn't return places separately;
  // places come from the 'places' endpoint. We handle that below.

  return { queryId, resultsSaved };
}

export async function storePlacesResults(
  env: Env,
  query: StrategicQuery,
  places: any[],
  creditsUsed: number
): Promise<{ queryId: number; resultsSaved: number }> {
  
  const responseJson = JSON.stringify({ places });

  // Upsert query
  const existingQuery = await env.DB.prepare(
    'SELECT id FROM serper_queries WHERE service_slug = ? AND location_slug = ? AND endpoint = ? AND query_text = ?'
  ).bind(query.service_slug, query.location_slug, query.endpoint, query.query_text).first();

  let queryId: number;
  if (existingQuery) {
    queryId = existingQuery.id as number;
    await env.DB.prepare(
      'UPDATE serper_queries SET response_json = ?, status = ?, credits_used = ?, executed_at = datetime(\'now\') WHERE id = ?'
    ).bind(responseJson, 'completed', creditsUsed, queryId).run();
  } else {
    const insertResult = await env.DB.prepare(
      'INSERT INTO serper_queries (service_slug, location_slug, query_text, endpoint, response_json, status, credits_used, executed_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime(\'now\'))'
    ).bind(query.service_slug, query.location_slug, query.query_text, query.endpoint, responseJson, 'completed', creditsUsed).run();
    queryId = insertResult.meta.last_row_id as number;
  }

  // Delete old place results
  await env.DB.prepare('DELETE FROM serper_results WHERE query_id = ? AND result_type = ?').bind(queryId, 'place').run();

  // Store each place
  let resultsSaved = 0;
  if (places && places.length > 0) {
    const stmt = env.DB.prepare(
      'INSERT INTO serper_results (query_id, result_type, position, title, link, domain, snippet, rating, reviews_count, address, has_website, site_type, is_cl, extra_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    const batch = [];
    for (let i = 0; i < places.length; i++) {
      const p = places[i];
      const website = p.website || null;
      const domain = website ? extractDomain(website) : null;
      const siteType = domain ? classifyDomainQuick(domain) : 'competitor';
      const address_parts = [
        p.address,
        p.category,
        p.phone
      ].filter(Boolean).join(' · ');
      
      batch.push(stmt.bind(
        queryId, 'place', (p.position || i + 1),
        p.title, website, domain,
        p.snippet || p.category || null,
        p.rating || null, p.reviews || null,
        p.address || null,
        website ? 1 : 0,
        siteType,
        domain?.endsWith('.cl') ? 1 : 0,
        JSON.stringify({ 
          latitude: p.latitude || null,
          longitude: p.longitude || null,
          category: p.category || null,
          phone: p.phone || null
        })
      ));
    }
    await env.DB.batch(batch);
    resultsSaved = batch.length;
  }

  return { queryId, resultsSaved };
}

// ===== Quick domain classifier (basic heuristic) =====
// Full AI classification happens in Layer 3

function classifyDomainQuick(domain: string): string {
  const d = domain.toLowerCase();
  
  // Job boards
  if (/computrabajo|indeed|linkedin\.com\/jobs|jooble|laborum|trabajando\.cl|getonbrd|empleo/.test(d)) return 'directory';
  
  // Directories / aggregators
  if (/2x3\.cl|amarillas|guia|yelp|tripadvisor|directorio|catalogo|大发|feriados/.test(d)) return 'directory';
  
  // Social
  if (/facebook|instagram|twitter|tiktok|youtube|pinterest|reddit|whatsapp/.test(d)) return 'social';
  
  // Government
  if (/gob\.cl|municipal|\.gob|carabineros|pdi|minsegpres/.test(d)) return 'authority';
  
  // GuardMan
  if (/guardman|guard-man|guardman\.cl/.test(d)) return 'own';
  
  // Marketplace
  if (/mercadolibre|sodimac|falabella|ripley|paris/.test(d)) return 'social';
  
  // Default: .cl domains are likely competitors
  if (d.endsWith('.cl')) return 'competitor';
  
  return 'competitor';
}

// ===== Execute a full query plan for one combo =====

export async function executeQueryPlan(
  env: Env,
  plan: StrategicQuery[],
  onProgress?: (step: string, index: number, total: number) => void
): Promise<ExecutionResult[]> {
  const results: ExecutionResult[] = [];

  for (let i = 0; i < plan.length; i++) {
    const q = plan[i];
    onProgress?.(q.query_text, i, plan.length);

    try {
      if (q.endpoint === 'search') {
        const response = await callSerperSearch(q.query_text, 'cl', 'es', 10, env.SERPER_API_KEY);
        const credits = response.creditsUsed || 1;
        const { queryId, resultsSaved } = await storeQueryAndResults(env, q, response, credits);

        results.push({
          query_id: queryId,
          query_text: q.query_text,
          endpoint: 'search',
          credits_used: credits,
          results_count: {
            organic: response.organic?.length || 0,
            places: response.organic?.length || 0,
            paa: response.peopleAlsoAsk?.length || 0,
            knowledge_graph: response.knowledgeGraph ? 1 : 0,
            related_searches: response.relatedSearches?.length || 0,
          },
          status: 'completed',
        });

      } else if (q.endpoint === 'places') {
        const response = await callSerperPlaces(q.query_text, 'cl', 'es', env.SERPER_API_KEY);
        const places = (response as any).places || response.organic || [];
        const credits = response.creditsUsed || 1;
        const { queryId, resultsSaved } = await storePlacesResults(env, q, places, credits);

        results.push({
          query_id: queryId,
          query_text: q.query_text,
          endpoint: 'places',
          credits_used: credits,
          results_count: {
            organic: 0,
            places: places.length,
            paa: 0,
            knowledge_graph: 0,
            related_searches: 0,
          },
          status: 'completed',
        });
      }
    } catch (err: any) {
      results.push({
        query_id: 0,
        query_text: q.query_text,
        endpoint: q.endpoint,
        credits_used: 0,
        results_count: { organic: 0, places: 0, paa: 0, knowledge_graph: 0, related_searches: 0 },
        status: 'failed',
        error: err.message?.substring(0, 200),
      });
    }
  }

  return results;
}