/**
 * Serper Agent Types
 * Multi-layer pipeline for strategic SERP data collection
 */

// ===== Layer 1: Strategic Query Generation =====

export type QueryIntent = 'transactional' | 'informational' | 'commercial' | 'navigational' | 'local';
export type QueryPriority = 'critical' | 'high' | 'medium' | 'low';

export interface StrategicQuery {
  query_text: string;
  intent: QueryIntent;
  priority: QueryPriority;
  endpoint: 'search' | 'places';
  service_slug: string;
  location_slug: string;
  /** Why this query matters — human-readable rationale */
  rationale: string;
  /** Expected result types we care about */
  expected_insights: string[];
}

export interface QueryPlan {
  service_slug: string;
  location_slug: string;
  service_name: string;
  location_name: string;
  queries: StrategicQuery[];
  total_credits: number;
  generated_by: 'ai' | 'template';
  generated_at: string;
}

// ===== Layer 2: Execution & Storage =====

export interface SerperSearchResult {
  position: number;
  title: string;
  link: string;
  domain: string;
  snippet: string;
  date?: string;
  sitelinks?: any[];
  position_on_page?: number;
}

export interface SerperPlaceResult {
  position: number;
  title: string;
  address: string;
  latitude: number;
  longitude: number;
  rating?: number;
  reviews?: number;
  category?: string;
  website?: string;
  phone?: string;
  snippet?: string;
}

export interface SerperPAAResult {
  question: string;
  snippet?: string;
  title?: string;
  link?: string;
}

export interface SerperKnowledgeGraph {
  title?: string;
  description?: string;
  type?: string;
  website?: string;
  rating?: number;
  reviews?: number;
  address?: string;
  thumbnail?: string;
}

export interface SerperRelatedSearch {
  query: string;
}

export interface SerperResponse {
  searchParameters?: { q: string; gl: string; hl: string; type?: string; num?: number };
  organic?: SerperSearchResult[];
  places?: SerperPlaceResult[];
  knowledgeGraph?: SerperKnowledgeGraph;
  peopleAlsoAsk?: SerperPAAResult[];
  paa?: SerperPAAResult[];  // Alternative key name from Serper API
  relatedSearches?: SerperRelatedSearch[];
  localPack?: any[];
  ads?: any[];
  creditsUsed?: number;
  credits?: number;  // Alternative key for credits
  query?: string;    // Serper API sometimes includes query
}

export interface ExecutionResult {
  query_id: number;
  query_text: string;
  endpoint: string;
  credits_used: number;
  results_count: {
    organic: number;
    places: number;
    paa: number;
    knowledge_graph: number;
    related_searches: number;
  };
  status: 'completed' | 'failed';
  error?: string;
}

// ===== Layer 3: Classification & Filtering =====

export type DomainCategory = 
  | 'direct_competitor'    // Empresa de seguridad privada chilena
  | 'indirect_competitor'  // Ofrece servicios similares pero no es 100% seguridad
  | 'job_board'            // LinkedIn, Computrabajo, Indeed
  | 'directory'            // 2x3, Amarillas, Yuker
  | 'government'           // Municipalidades, gov.cl
  | 'social'               // Facebook, Instagram, YouTube
  | 'marketplace'          // MercadoLibre, Sodimac
  | 'media'                // Noticias, blogs de prensa
  | 'own'                  // GuardMan
  | 'irrelevant';          // No relacionado con seguridad

export type QualityTier = 'gold' | 'silver' | 'bronze' | 'spam';

export interface ClassifiedResult {
  id: number;
  query_id: number;
  result_type: string;
  position: number;
  title: string;
  link: string;
  domain: string;
  snippet: string;
  domain_category: DomainCategory;
  quality_tier: QualityTier;
  relevance_score: number; // 0-100
  is_competitor_real: number; // 0 or 1
  is_guardman: number;
  is_chilean: number;
  is_directory: number;
  is_job_board: number;
  key_insights: string; // JSON array of observations
}

export interface ClassificationStats {
  total_results: number;
  by_category: Record<DomainCategory, number>;
  by_quality: Record<QualityTier, number>;
  real_competitors: number;
  real_competitor_domains: string[];
  guardman_positions: number;
  directories: string[];
  job_boards: string[];
  opportunities: string[];
}

// ===== Pipeline =====

export interface PipelineStatus {
  layer: number;
  step: string;
  progress: number;
  total: number;
  message: string;
}

export interface PipelineResult {
  plan: QueryPlan;
  execution_results: ExecutionResult[];
  classification_stats: ClassificationStats;
  keywords_extracted: number;
  competitors_identified: number;
  total_credits_used: number;
}