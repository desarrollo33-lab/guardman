// GuardMan Admin — Auth Middleware
import type { Env } from '../index';

const PUBLIC_ENDPOINTS = [
  '/health',
  '/api/login',
  '/api/preview/',  // Preview is public (for iframes)
  '/api/images/',   // R2 images are public
  '/api/export/',   // Export endpoints for static site generation
  '/api/cms/image', // CMS image proxy is public
  '/api/cms/blog/list', // Blog listing (public SSR)
  '/api/cms/blog/get',  // Blog post (public SSR)
  '/api/cms/content',   // CMS content read (public SSR + admin list)
  '/api/cms/list',      // CMS entity list (admin UI data)
  '/api/cms/homepage',  // Homepage read (public SSR)
  '/api/media/list',    // Media library list (admin UI data)
  '/api/intel/leads/capture', // Public lead capture from website forms
  '/api/cuestionario-ceo',    // Cuestionario de ADN de Marca para CEO (público con token de sesión)
];

export function isPublicEndpoint(pathname: string): boolean {
  return PUBLIC_ENDPOINTS.some(ep => pathname === ep || pathname.startsWith(ep));
}

export function validateAuth(request: Request, env: Env): Response | null {
  const auth = request.headers.get('Authorization');

  // Fail-secure: if AUTH_TOKEN is not set, reject all requests
  const token = (env.AUTH_TOKEN || '').trim();
  if (!token) {
    console.error('[Auth] AUTH_TOKEN not configured — rejecting all protected endpoints');
    return Response.json({ ok: false, error: 'Auth not configured' }, { status: 503 });
  }

  if (!auth) {
    return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401 });
  }

  // Accept: Bearer + API key (service-to-service, CLI, scripts)
  if (auth.includes(token)) return null;

  // Accept: Bearer + login token (email:timestamp from /api/login)
  // Login tokens are generated as admin@guardman.cl:1766880000000
  if (/^Bearer [\w.@-]+:\d{10,}$/.test(auth)) return null;

  return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401 });
}
