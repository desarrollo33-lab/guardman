// GuardMan Intel — Shared Helpers
import { CORS_HEADERS } from '../../../types';
const cors = CORS_HEADERS;

export { cors };

export function generateSlug(): string {
  return 'ld-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 7);
}

export function calculateOpportunityScore(density: number, ourPos: number, queries: number): number {
  let score = 50;
  if (density <= 2) score += 30;
  else if (density <= 5) score += 15;
  else score -= 10;
  if (ourPos <= 3) score += 20;
  else if (ourPos <= 10) score += 5;
  else if (ourPos === 999) score += 0;
  else score -= 5;
  if (queries >= 8) score += 10;
  else if (queries >= 4) score += 5;
  return Math.max(0, Math.min(100, score));
}

export async function enrichLeadWithIntel(env: any, serviceSlug: string | null, locationSlug: string | null, leadId: number) {
  if (!serviceSlug || !locationSlug) return;
  try {
    const [queryCount, compCount, ourPos] = await Promise.all([
      env.DB.prepare(
        'SELECT COUNT(*) as cnt FROM serper_queries WHERE service_slug = ? AND location_slug = ? AND status = ?'
      ).bind(serviceSlug, locationSlug, 'completed').first(),
      env.DB.prepare(
        `SELECT COUNT(DISTINCT sr.domain) as cnt FROM serper_results sr
         JOIN serper_queries sq ON sr.query_id = sq.id
         WHERE sq.service_slug = ? AND sq.location_slug = ? AND sr.site_type = ?`
      ).bind(serviceSlug, locationSlug, 'direct_competitor').first(),
      env.DB.prepare(
        `SELECT MIN(sr.position) as best FROM serper_results sr
         JOIN serper_queries sq ON sr.query_id = sq.id
         WHERE sq.service_slug = ? AND sq.location_slug = ? AND sr.site_type = ?`
      ).bind(serviceSlug, locationSlug, 'own').first(),
    ]);
    const density = (compCount?.cnt as number) || 0;
    const pos = (ourPos?.best as number) || 999;
    const queries = (queryCount?.cnt as number) || 0;
    const score = calculateOpportunityScore(density, pos, queries);
    const difficulty: string = density > 5 ? 'hard' : density > 2 ? 'medium' : 'easy';
    await env.DB.prepare(
      `UPDATE intel_leads SET serper_opportunity_score = ?, competitor_density = ?,
       guardman_position = ?, market_difficulty = ? WHERE id = ?`
    ).bind(score, density, pos, difficulty, leadId).run();
  } catch (e) {
    console.error('[Intel] Enrichment failed:', (e as Error).message);
  }
}
