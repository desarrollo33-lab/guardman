// GuardMan Intel — SEO (Positions, Keywords, Content Strategy)
import { cors } from './helpers';

// ===================================================================
// POSITION TIMELINE
// ===================================================================

export async function handlePositionTimeline(url: URL, env: any): Promise<Response> {
  try {
    const service = url.searchParams.get('service');
    const location = url.searchParams.get('location');
    const dates = await env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots ORDER BY snapshot_date DESC LIMIT 15').all();
    const dateList = (dates.results as any[]).map(r => r.snapshot_date);
    const timeline: any[] = [];
    for (const date of dateList) {
      let sql = 'SELECT site_type, COUNT(DISTINCT query_text) as queries, COUNT(*) as positions, ROUND(AVG(position),1) as avg_pos, MIN(position) as best_pos, COUNT(CASE WHEN position <= 3 THEN 1 END) as top3, COUNT(CASE WHEN position <= 10 THEN 1 END) as top10 FROM position_snapshots WHERE snapshot_date = ?';
      const params: any[] = [date];
      if (service) { sql += ' AND service_slug = ?'; params.push(service); }
      if (location) { sql += ' AND location_slug = ?'; params.push(location); }
      sql += ' GROUP BY site_type';
      const { results } = await env.DB.prepare(sql).bind(...params).all();
      timeline.push({ date, breakdown: results });
    }
    let ownSql = 'SELECT snapshot_date, COUNT(DISTINCT service_slug || location_slug) as combos, AVG(position) as avg_pos FROM position_snapshots WHERE site_type = ?';
    const ownParams: any[] = ['own'];
    if (service) { ownSql += ' AND service_slug = ?'; ownParams.push(service); }
    if (location) { ownSql += ' AND location_slug = ?'; ownParams.push(location); }
    ownSql += ' GROUP BY snapshot_date ORDER BY snapshot_date DESC LIMIT 15';
    const ownHistory = await env.DB.prepare(ownSql).bind(...ownParams).all();
    return Response.json({ ok: true, data: { dates: dateList, timeline, own_history: ownHistory.results } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// POSITION SCORECARD
// ===================================================================

export async function handlePositionScorecard(env: any): Promise<Response> {
  try {
    const [combos, ownPositions, diffData] = await Promise.all([
      env.DB.prepare('SELECT sq.service_slug, sq.location_slug, MIN(CASE WHEN sr.site_type = \'own\' THEN sr.position ELSE 999 END) as best_position, COUNT(DISTINCT CASE WHEN sr.site_type = \'direct_competitor\' THEN sr.domain END) as competitors FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.status = \'completed\' GROUP BY sq.service_slug, sq.location_slug').all(),
      env.DB.prepare('SELECT COUNT(CASE WHEN position <= 3 THEN 1 END) as top3, COUNT(CASE WHEN position <= 5 THEN 1 END) as top5, COUNT(CASE WHEN position <= 10 THEN 1 END) as top10, COUNT(*) as total FROM serper_results WHERE site_type = \'own\'').first(),
      env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots ORDER BY snapshot_date DESC LIMIT 2').all(),
    ]);
    const comboRows = combos.results as any[];
    const total = comboRows.length;
    const top3C = comboRows.filter(r => r.best_position <= 3).length;
    const top5C = comboRows.filter(r => r.best_position > 3 && r.best_position <= 5).length;
    const top10C = comboRows.filter(r => r.best_position > 5 && r.best_position <= 10).length;
    const noP = comboRows.filter(r => r.best_position === 999).length;
    let trend: any = { improved: 0, declined: 0, new: 0, lost: 0 };
    const dateList = (diffData.results as any[]).map(r => r.snapshot_date);
    if (dateList.length >= 2) {
      const [latest, previous] = dateList;
      const [latestOwn, prevOwn] = await Promise.all([
        env.DB.prepare('SELECT service_slug, location_slug, position FROM position_snapshots WHERE snapshot_date = ? AND site_type = ?').bind(latest, 'own').all(),
        env.DB.prepare('SELECT service_slug, location_slug, position FROM position_snapshots WHERE snapshot_date = ? AND site_type = ?').bind(previous, 'own').all(),
      ]);
      const prevMap = new Map((prevOwn.results as any[]).map(r => [r.service_slug + '|' + r.location_slug, r.position]));
      for (const curr of (latestOwn.results as any[])) {
        const key = curr.service_slug + '|' + curr.location_slug;
        const prevPos = prevMap.get(key);
        if (prevPos === undefined) trend.new++; else if (curr.position < prevPos) trend.improved++; else if (curr.position > prevPos) trend.declined++;
      }
      const currKeys = new Set((latestOwn.results as any[]).map((r: any) => r.service_slug + '|' + r.location_slug));
      for (const [key, pos] of prevMap) { if (!currKeys.has(key as string)) trend.lost++; }
    }
    return Response.json({ ok: true, data: { summary: { total_combos: total, with_presence: total - noP, no_presence: noP }, positions: { top3: top3C, top5: top5C, top10: top10C, no_presence: noP }, own_counts: ownPositions, trend, snapshot_dates: dateList } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// QUICK WINS
// ===================================================================

export async function handleQuickWins(env: any): Promise<Response> {
  try {
    const quickWins = await env.DB.prepare('SELECT sq.service_slug, sq.location_slug, MIN(CASE WHEN sr.site_type = \'own\' THEN sr.position ELSE 999 END) as best_position, COUNT(DISTINCT CASE WHEN sr.site_type = \'direct_competitor\' THEN sr.domain END) as competitors, COUNT(DISTINCT sq.id) as queries FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.status = \'completed\' GROUP BY sq.service_slug, sq.location_slug HAVING best_position BETWEEN 4 AND 10 ORDER BY queries DESC, competitors ASC').all();
    const easyWins = await env.DB.prepare('SELECT sq.service_slug, sq.location_slug, COUNT(DISTINCT sq.id) as queries FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = \'direct_competitor\' WHERE sq.status = \'completed\' GROUP BY sq.service_slug, sq.location_slug HAVING COUNT(sr.id) = 0 ORDER BY queries DESC LIMIT 20').all().catch(() => ({ results: [] }));
    return Response.json({ ok: true, data: { quick_wins: quickWins.results, easy_wins: easyWins.results } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// KEYWORD MATRIX
// ===================================================================

export async function handleKeywordMatrix(env: any): Promise<Response> {
  try {
    const [queries, intentDist, topKw] = await Promise.all([
      env.DB.prepare('SELECT sq.query_text, sq.service_slug, sq.location_slug, MIN(CASE WHEN sr.site_type = \'own\' THEN sr.position ELSE 999 END) as guardman_pos, COUNT(DISTINCT CASE WHEN sr.site_type = \'direct_competitor\' THEN sr.domain END) as competitors FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.status = \'completed\' AND sq.endpoint = \'search\' GROUP BY sq.id ORDER BY guardman_pos ASC').all(),
      env.DB.prepare('SELECT \'transactional\' as intent, COUNT(*) as cnt FROM serper_queries WHERE query_text LIKE \'%precio%\' OR query_text LIKE \'%contratar%\' UNION ALL SELECT \'commercial\', COUNT(*) FROM serper_queries WHERE query_text LIKE \'%mejor%\' OR query_text LIKE \'%empresa de%\' UNION ALL SELECT \'local\', COUNT(*) FROM serper_queries WHERE endpoint = \'places\' UNION ALL SELECT \'other\', COUNT(*) FROM serper_queries WHERE endpoint = \'search\'').all(),
      env.DB.prepare('SELECT sq.query_text, COUNT(DISTINCT CASE WHEN sr.site_type = \'direct_competitor\' THEN sr.domain END) as competitor_count, MIN(CASE WHEN sr.site_type = \'own\' THEN sr.position ELSE 999 END) as guardman_pos FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.status = \'completed\' AND sq.endpoint = \'search\' GROUP BY sq.query_text ORDER BY competitor_count DESC LIMIT 50').all(),
    ]);
    return Response.json({ ok: true, data: { queries: queries.results, intent_distribution: intentDist.results, top_keywords: topKw.results } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// CONTENT STRATEGY
// ===================================================================

export async function handleContentStrategy(env: any): Promise<Response> {
  try {
    const [gaps, refresh, paaOpps] = await Promise.all([
      env.DB.prepare('SELECT sq.service_slug, sq.location_slug, COUNT(DISTINCT sq.query_text) as demand_queries, COUNT(DISTINCT CASE WHEN sr.site_type = \'direct_competitor\' THEN sr.domain END) as competitors, GROUP_CONCAT(DISTINCT sq.query_text) as sample_queries FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.status = \'completed\' GROUP BY sq.service_slug, sq.location_slug HAVING MIN(CASE WHEN sr.site_type = \'own\' THEN sr.position ELSE 999 END) > 5 ORDER BY demand_queries DESC LIMIT 30').all(),
      env.DB.prepare('SELECT sq.service_slug, sq.location_slug, MIN(CASE WHEN sr.site_type = \'own\' THEN sr.position ELSE 999 END) as best_pos, COUNT(DISTINCT sq.query_text) as queries FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.status = \'completed\' GROUP BY sq.service_slug, sq.location_slug HAVING best_pos BETWEEN 4 AND 10 ORDER BY queries DESC LIMIT 20').all(),
      env.DB.prepare('SELECT sr.title as question, sq.service_slug, COUNT(*) as frequency FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.result_type = \'paa\' GROUP BY sr.title ORDER BY frequency DESC LIMIT 30').all(),
    ]);
    return Response.json({ ok: true, data: { priority_pages: gaps.results, refresh_candidates: refresh.results, faq_opportunities: paaOpps.results } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// FAQ OPPORTUNITIES
// ===================================================================

export async function handleFAQOpportunities(url: URL, env: any): Promise<Response> {
  try {
    const service = url.searchParams.get('service');
    let sql = 'SELECT sr.title as question, sr.snippet as answer_snippet, sq.service_slug, sq.location_slug, COUNT(*) as frequency FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.result_type = \'paa\'';
    const params: any[] = [];
    if (service) { sql += ' AND sq.service_slug = ?'; params.push(service); }
    sql += ' GROUP BY sr.title ORDER BY frequency DESC LIMIT 50';
    const { results } = await env.DB.prepare(sql).bind(...params).all();
    return Response.json({ ok: true, data: results }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// CONTENT ROI
// ===================================================================

export async function handleContentROI(env: any): Promise<Response> {
  try {
    const [pub, pubPresence, leadsPub] = await Promise.all([
      env.DB.prepare('SELECT COUNT(*) as cnt FROM combo_content WHERE status = \'published\'').first(),
      env.DB.prepare('SELECT COUNT(DISTINCT sq.service_slug || \'|\' || sq.location_slug) as cnt FROM combo_content cc JOIN serper_queries sq ON cc.service_slug = sq.service_slug AND cc.location_slug = sq.location_slug JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = \'own\' WHERE cc.status = \'published\'').first(),
      env.DB.prepare('SELECT COUNT(*) as cnt, COALESCE(SUM(estimated_value),0) as total_value FROM intel_leads l WHERE EXISTS (SELECT 1 FROM combo_content cc WHERE cc.service_slug = l.service_slug AND cc.location_slug = l.location_slug AND cc.status = \'published\')').first(),
    ]);
    return Response.json({ ok: true, data: { published_pages: pub?.cnt || 0, published_with_serper_presence: pubPresence?.cnt || 0, leads_from_published: leadsPub?.cnt || 0, pipeline_from_published: leadsPub?.total_value || 0 } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

