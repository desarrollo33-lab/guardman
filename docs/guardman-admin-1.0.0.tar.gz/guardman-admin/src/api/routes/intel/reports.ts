// GuardMan Intel — Alerts & Reports
import { cors } from './helpers';

// ===================================================================
// ALERTS
// ===================================================================

export async function handleAlerts(env: any): Promise<Response> {
  try {
    const alerts: any[] = [];
    const dates = await env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots ORDER BY snapshot_date DESC LIMIT 2').all();
    const dateList = (dates.results as any[]).map(r => r.snapshot_date);
    if (dateList.length >= 2) {
      const [latest, previous] = dateList;
      const [latestOwn, prevOwn] = await Promise.all([
        env.DB.prepare('SELECT service_slug, location_slug, position FROM position_snapshots WHERE snapshot_date = ? AND site_type = ?').bind(latest, 'own').all(),
        env.DB.prepare('SELECT service_slug, location_slug, position FROM position_snapshots WHERE snapshot_date = ? AND site_type = ?').bind(previous, 'own').all(),
      ]);
      const prevMap = new Map((prevOwn.results as any[]).map(r => [r.service_slug + '|' + r.location_slug, r.position]));
      for (const curr of (latestOwn.results as any[])) {
        const key = curr.service_slug + '|' + curr.location_slug;
        const prevPos = prevMap.get(key);
        if (prevPos === undefined) alerts.push({ type: 'new_appearance', severity: 'info', title: 'Nueva aparición', description: 'GuardMan en ' + curr.service_slug.replace(/-/g,' ') + ' · ' + curr.location_slug.replace(/-/g,' ') + ' (#' + curr.position + ')' });
        else if (curr.position > prevPos + 2) alerts.push({ type: 'position_lost', severity: 'warning', title: 'Posición perdida', description: curr.service_slug.replace(/-/g,' ') + ' · ' + curr.location_slug.replace(/-/g,' ') + ': #' + prevPos + ' → #' + curr.position });
        else if (curr.position < prevPos - 2) alerts.push({ type: 'position_gained', severity: 'info', title: 'Posición ganada', description: curr.service_slug.replace(/-/g,' ') + ' · ' + curr.location_slug.replace(/-/g,' ') + ': #' + prevPos + ' → #' + curr.position });
      }
      const currKeys = new Set((latestOwn.results as any[]).map((r: any) => r.service_slug + '|' + r.location_slug));
      for (const [key, pos] of prevMap) { if (!currKeys.has(key as string)) { const [s,l] = (key as string).split('|'); alerts.push({ type: 'position_lost', severity: 'warning', title: 'Presencia perdida', description: 'Desapareció de ' + s.replace(/-/g,' ') + ' · ' + l.replace(/-/g,' ') }); } }
      const risingComps = await env.DB.prepare('SELECT domain, COUNT(*) as appearances FROM position_snapshots WHERE snapshot_date = ? AND site_type = \'direct_competitor\' AND position <= 3 GROUP BY domain ORDER BY appearances DESC LIMIT 5').bind(latest).all();
      for (const comp of (risingComps.results as any[])) {
        const prevComp = await env.DB.prepare('SELECT COUNT(*) as cnt FROM position_snapshots WHERE snapshot_date = ? AND domain = ? AND position <= 3').bind(previous, comp.domain).first();
        const prevCnt = prevComp?.cnt || 0;
        if ((comp.appearances as number) > prevCnt + 2) alerts.push({ type: 'competitor_rising', severity: 'warning', title: 'Competidor en ascenso', description: comp.domain + ': ' + comp.appearances + ' TOP 3 (antes ' + prevCnt + ')' });
      }
    }
    const staleLeads = await env.DB.prepare("SELECT id, contact_name, company_name, created_at FROM intel_leads WHERE status IN ('new','contacted') AND (last_contact_at IS NULL OR datetime(last_contact_at) < datetime('now', '-3 days')) ORDER BY created_at ASC LIMIT 10").all().catch(() => ({ results: [] }));
    for (const lead of (staleLeads.results as any[])) { const d = Math.floor((Date.now() - new Date(lead.created_at).getTime()) / 86400000); alerts.push({ type: 'stale_lead', severity: 'warning', title: 'Lead sin seguimiento', description: lead.contact_name + (lead.company_name ? ' (' + lead.company_name + ')' : '') + ' — ' + d + ' días', lead_id: lead.id }); }
    const critComps = await env.DB.prepare("SELECT domain, total_appearances FROM intel_competitors WHERE threat_level = 'critical'").all().catch(() => ({ results: [] }));
    for (const c of (critComps.results as any[])) alerts.push({ type: 'critical_competitor', severity: 'info', title: 'Competidor crítico', description: c.domain + ': ' + c.total_appearances + ' apariciones' });
    return Response.json({ ok: true, data: alerts, total: alerts.length }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleDismissAlert(id: number, env: any): Promise<Response> {
  return Response.json({ ok: true, data: { dismissed: id } }, { headers: cors });
}

// ===================================================================
// REPORTS
// ===================================================================

export async function handleLatestReport(env: any): Promise<Response> {
  try {
    const report = await env.DB.prepare('SELECT * FROM scheduled_reports ORDER BY created_at DESC LIMIT 1').first();
    if (!report) return await handleGenerateReport(env);
    return Response.json({ ok: true, data: report }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleGenerateReport(env: any): Promise<Response> {
  try {
    const date = new Date().toISOString().split('T')[0];
    const [leadStats, clientStats, scorecard, topComp, gaps] = await Promise.all([
      env.DB.prepare('SELECT status, COUNT(*) as cnt, COALESCE(SUM(estimated_value),0) as value FROM intel_leads GROUP BY status').all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT COUNT(*) as total, COALESCE(SUM(CASE WHEN status='active' THEN monthly_value ELSE 0 END),0) as mrr FROM intel_clients").first().catch(() => ({ total: 0, mrr: 0 })),
      env.DB.prepare("SELECT COUNT(CASE WHEN sr.site_type='own' AND sr.position<=3 THEN 1 END) as top3, COUNT(CASE WHEN sr.site_type='own' AND sr.position<=10 THEN 1 END) as top10, COUNT(DISTINCT CASE WHEN sr.site_type='direct_competitor' THEN sr.domain END) as competitors FROM serper_results sr").first().catch(() => ({})),
      env.DB.prepare("SELECT domain, COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos FROM serper_results WHERE site_type = 'direct_competitor' GROUP BY domain ORDER BY appearances DESC LIMIT 5").all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT sq.service_slug, sq.location_slug, MIN(CASE WHEN sr.site_type='own' THEN sr.position ELSE 999 END) as pos, COUNT(DISTINCT sq.query_text) as queries FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.status='completed' GROUP BY sq.service_slug, sq.location_slug HAVING pos > 5 ORDER BY queries DESC LIMIT 10").all().catch(() => ({ results: [] })),
    ]);
    return Response.json({ ok: true, data: { date, leads: { by_status: leadStats.results }, clients: { total: (clientStats as any)?.total || 0, active_mrr: (clientStats as any)?.mrr || 0 }, seo: scorecard, top_competitors: topComp.results, priority_gaps: gaps.results } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleReportHistory(url: URL, env: any): Promise<Response> {
  try {
    const limit = parseInt(url.searchParams.get('limit') || '10');
    const { results } = await env.DB.prepare('SELECT id, type, report_date, created_at FROM scheduled_reports ORDER BY created_at DESC LIMIT ?').bind(limit).all();
    return Response.json({ ok: true, data: results }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

