// GuardMan Intel — Market Map & Matrix
import { cors } from './helpers';

// ===================================================================
// MARKET MAP
// ===================================================================

export async function handleMarketMap(env: any): Promise<Response> {
  try {
    const { results } = await env.DB.prepare(`
      SELECT
        sq.location_slug,
        l.name as location_name,
        l.zone,
        COUNT(DISTINCT sq.id) as total_queries,
        COUNT(DISTINCT sq.query_text) as unique_keywords,
        COUNT(DISTINCT CASE WHEN sr.site_type = 'direct_competitor' THEN sr.domain END) as competitor_count,
        COUNT(DISTINCT CASE WHEN sr.site_type = 'own' THEN sq.id END) as queries_with_presence,
        AVG(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE NULL END) as avg_own_position,
        MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as best_own_position,
        COUNT(DISTINCT CASE WHEN sr.site_type = 'own' AND sr.position <= 3 THEN sq.id END) as top3_count,
        COUNT(CASE WHEN sr.result_type = 'paa' THEN 1 END) as paa_count
      FROM serper_queries sq
      LEFT JOIN serper_results sr ON sq.id = sr.query_id
      LEFT JOIN locations l ON sq.location_slug = l.slug
      WHERE sq.status = 'completed'
      GROUP BY sq.location_slug
      ORDER BY competitor_count DESC
    `).all();

    // Lead counts per location
    const leadCounts = await env.DB.prepare(
      'SELECT location_slug, COUNT(*) as cnt FROM intel_leads WHERE status NOT IN (\'won\', \'lost\') GROUP BY location_slug'
    ).all();
    const leadMap = new Map((leadCounts.results as any[]).map(r => [r.location_slug, r.cnt]));

    // Client counts per location
    const clientCounts = await env.DB.prepare(
      'SELECT location_slug, COUNT(*) as cnt FROM intel_clients WHERE status = \'active\' GROUP BY location_slug'
    ).all();
    const clientMap = new Map((clientCounts.results as any[]).map(r => [r.location_slug, r.cnt]));

    const locations = (results as any[]).map(r => ({
      ...r,
      active_leads: leadMap.get(r.location_slug) || 0,
      active_clients: clientMap.get(r.location_slug) || 0,
      coverage_pct: r.total_queries > 0 ? Math.round((r.queries_with_presence / r.total_queries) * 100) : 0,
    }));

    return Response.json({ ok: true, data: locations }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleMarketMatrix(env: any): Promise<Response> {
  try {
    const [services, locations, matrix] = await Promise.all([
      env.DB.prepare('SELECT slug, name FROM services ORDER BY sort, name').all(),
      env.DB.prepare('SELECT slug, name, zone FROM locations ORDER BY zone, name').all(),
      env.DB.prepare(`
        SELECT
          sq.service_slug, sq.location_slug,
          MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as best_position,
          COUNT(DISTINCT CASE WHEN sr.site_type = 'direct_competitor' THEN sr.domain END) as competitor_count,
          COUNT(DISTINCT sq.id) as queries_executed
        FROM serper_queries sq
        LEFT JOIN serper_results sr ON sq.id = sr.query_id
        WHERE sq.status = 'completed'
        GROUP BY sq.service_slug, sq.location_slug
      `).all(),
    ]);

    return Response.json({
      ok: true,
      data: {
        services: services.results,
        locations: locations.results,
        matrix: matrix.results,
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
