// GuardMan Intel — Dashboard
import { cors } from './helpers';

// DASHBOARD
// ===================================================================

export async function handleIntelDashboard(env: any): Promise<Response> {
  try {
    const [
      leadStats, clientStats, proposalStats,
      pipelineValue, marketStats, topCompetitors,
      recentLeads, recentInteractions,
    ] = await Promise.all([
      // Lead stats by status
      env.DB.prepare('SELECT status, COUNT(*) as cnt, COALESCE(SUM(estimated_value), 0) as total_value FROM intel_leads GROUP BY status').all().catch(() => ({ results: [] })),
      // Client stats
      env.DB.prepare('SELECT status, COUNT(*) as cnt, COALESCE(SUM(monthly_value), 0) as mrr FROM intel_clients GROUP BY status').all().catch(() => ({ results: [] })),
      // Proposal stats
      env.DB.prepare('SELECT status, COUNT(*) as cnt FROM intel_proposals GROUP BY status').all().catch(() => ({ results: [] })),
      // Pipeline weighted value
      env.DB.prepare('SELECT COALESCE(SUM(estimated_value * probability), 0) as weighted FROM intel_leads WHERE status NOT IN (\'won\', \'lost\')').first().catch(() => ({ weighted: 0 })),
      // Market stats
      Promise.all([
        env.DB.prepare('SELECT COUNT(DISTINCT domain) as cnt FROM serper_results WHERE site_type = \'direct_competitor\'').first().catch(() => ({ cnt: 0 })),
        env.DB.prepare('SELECT COUNT(*) as cnt FROM serper_queries WHERE status = \'completed\'').first().catch(() => ({ cnt: 0 })),
        env.DB.prepare('SELECT COUNT(*) as cnt FROM serper_results WHERE site_type = \'own\' AND position <= 3').first().catch(() => ({ cnt: 0 })),
        env.DB.prepare('SELECT COUNT(*) as cnt FROM serper_results WHERE site_type = \'own\'').first().catch(() => ({ cnt: 0 })),
      ]),
      // Top 5 competitors
      env.DB.prepare(`
        SELECT domain, COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos
        FROM serper_results WHERE site_type = 'direct_competitor'
        GROUP BY domain ORDER BY appearances DESC LIMIT 5
      `).all().catch(() => ({ results: [] })),
      // Recent leads
      env.DB.prepare('SELECT id, contact_name, company_name, service_slug, location_slug, status, estimated_value, market_difficulty, created_at FROM intel_leads ORDER BY created_at DESC LIMIT 5').all().catch(() => ({ results: [] })),
      // Recent interactions
      env.DB.prepare('SELECT i.*, l.contact_name, l.company_name FROM intel_interactions i LEFT JOIN intel_leads l ON i.lead_id = l.id ORDER BY i.created_at DESC LIMIT 10').all().catch(() => ({ results: [] })),
    ]);

    // Build lead status map
    const leadMap: Record<string, any> = { new: { cnt: 0, total_value: 0 }, contacted: { cnt: 0, total_value: 0 }, qualified: { cnt: 0, total_value: 0 }, proposal: { cnt: 0, total_value: 0 }, won: { cnt: 0, total_value: 0 }, lost: { cnt: 0, total_value: 0 } };
    for (const row of (leadStats.results as any[])) {
      if (leadMap[row.status]) leadMap[row.status] = { cnt: row.cnt, total_value: row.total_value };
    }

    // Build client status map
    let activeMRR = 0;
    let totalClients = 0;
    for (const row of (clientStats.results as any[])) {
      totalClients += row.cnt as number;
      if (row.status === 'active') activeMRR = (row.mrr as number) || 0;
    }

    return Response.json({
      ok: true,
      data: {
        leads: leadMap,
        clients: { total: totalClients, active_mrr: activeMRR },
        proposals: proposalStats.results,
        pipeline_weighted_value: (pipelineValue as any)?.weighted || 0,
        market: {
          unique_competitors: (marketStats[0] as any)?.cnt || 0,
          serper_queries: (marketStats[1] as any)?.cnt || 0,
          top3_positions: (marketStats[2] as any)?.cnt || 0,
          total_own_positions: (marketStats[3] as any)?.cnt || 0,
        },
        top_competitors: topCompetitors.results,
        recent_leads: recentLeads.results,
        recent_interactions: recentInteractions.results,
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
