// GuardMan Intel — CRUD (Serper Results, Competitors, Opportunities, Stats)
import { cors } from './helpers';

// ===================================================================
// CRUD: SERPER RESULTS
// ===================================================================

export async function handleListSerperResults(url: URL, env: any): Promise<Response> {
  try {
    const service = url.searchParams.get('service') || '';
    const location = url.searchParams.get('location') || '';
    const siteType = url.searchParams.get('site_type') || '';
    const domain = url.searchParams.get('domain') || '';
    const resultType = url.searchParams.get('result_type') || '';
    const isCl = url.searchParams.get('is_cl') || '';
    const search = url.searchParams.get('q') || '';
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'));
    const limit = Math.min(200, Math.max(10, parseInt(url.searchParams.get('limit') || '50')));
    const offset = (page - 1) * limit;

    const conds: string[] = [];
    const params: any[] = [];

    if (service) { conds.push('sq.service_slug = ?'); params.push(service); }
    if (location) { conds.push('sq.location_slug = ?'); params.push(location); }
    if (siteType) { conds.push('sr.site_type = ?'); params.push(siteType); }
    if (domain) { conds.push('sr.domain LIKE ?'); params.push(`%${domain}%`); }
    if (resultType) { conds.push('sr.result_type = ?'); params.push(resultType); }
    if (isCl === '1') { conds.push('sr.is_cl = 1'); }
    if (isCl === '0') { conds.push('sr.is_cl = 0'); }
    if (search) { conds.push('(sr.title LIKE ? OR sr.snippet LIKE ? OR sr.domain LIKE ?)'); params.push(`%${search}%`, `%${search}%`, `%${search}%`); }

    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';

    const [countResult, rows] = await Promise.all([
      env.DB.prepare(`SELECT COUNT(*) as total FROM serper_results sr LEFT JOIN serper_queries sq ON sr.query_id = sq.id ${where}`).bind(...params).first(),
      env.DB.prepare(`
        SELECT sr.id, sr.result_type, sr.position, sr.title, sr.link, sr.domain, sr.snippet,
               sr.site_type, sr.is_cl, sr.rating, sr.reviews_count, sr.address,
               sq.service_slug, sq.location_slug, sq.query_text, sq.endpoint,
               sr.extra_json
        FROM serper_results sr
        LEFT JOIN serper_queries sq ON sr.query_id = sq.id
        ${where}
        ORDER BY sr.id DESC
        LIMIT ? OFFSET ?
      `).bind(...params, limit, offset).all(),
    ]);

    const [services, locations, siteTypes, domains] = await Promise.all([
      env.DB.prepare('SELECT DISTINCT service_slug FROM serper_queries ORDER BY service_slug').all(),
      env.DB.prepare('SELECT DISTINCT location_slug FROM serper_queries ORDER BY location_slug').all(),
      env.DB.prepare('SELECT DISTINCT site_type FROM serper_results WHERE site_type IS NOT NULL ORDER BY site_type').all(),
      env.DB.prepare('SELECT domain, COUNT(*) as cnt FROM serper_results WHERE domain IS NOT NULL GROUP BY domain ORDER BY cnt DESC LIMIT 30').all(),
    ]);

    return Response.json({
      ok: true,
      data: {
        results: rows.results,
        total: (countResult as any).total,
        page,
        limit,
        pages: Math.ceil(((countResult as any).total) / limit),
        filters: {
          services: services.results.map((r: any) => r.service_slug),
          locations: locations.results.map((r: any) => r.location_slug),
          site_types: siteTypes.results.map((r: any) => r.site_type),
          top_domains: domains.results,
        },
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleUpdateSerperResult(id: number, request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const fields: string[] = [];
    const values: any[] = [];

    if (body.site_type !== undefined) { fields.push('site_type = ?'); values.push(body.site_type); }
    if (body.is_cl !== undefined) { fields.push('is_cl = ?'); values.push(body.is_cl ? 1 : 0); }
    if (body.title !== undefined) { fields.push('title = ?'); values.push(body.title); }
    if (body.snippet !== undefined) { fields.push('snippet = ?'); values.push(body.snippet); }

    if (fields.length === 0) {
      return Response.json({ ok: false, error: 'No fields to update' }, { status: 400, headers: cors });
    }

    values.push(id);
    await env.DB.prepare(`UPDATE serper_results SET ${fields.join(', ')} WHERE id = ?`).bind(...values).run();

    const updated = await env.DB.prepare(`
      SELECT sr.*, sq.service_slug, sq.location_slug, sq.query_text
      FROM serper_results sr LEFT JOIN serper_queries sq ON sr.query_id = sq.id
      WHERE sr.id = ?
    `).bind(id).first();

    return Response.json({ ok: true, data: updated }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleDeleteSerperResult(id: number, env: any): Promise<Response> {
  try {
    await env.DB.prepare('DELETE FROM serper_results WHERE id = ?').bind(id).run();
    return Response.json({ ok: true, deleted: id }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleBulkClassify(request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const { ids, site_type } = body;
    if (!Array.isArray(ids) || !site_type) {
      return Response.json({ ok: false, error: 'ids (array) and site_type required' }, { status: 400, headers: cors });
    }
    const placeholders = ids.map(() => '?').join(',');
    const result = await env.DB.prepare(
      `UPDATE serper_results SET site_type = ? WHERE id IN (${placeholders})`
    ).bind(site_type, ...ids).run();
    return Response.json({ ok: true, updated: result.meta?.changes || ids.length }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// CRUD: COMPETITORS
// ===================================================================

export async function handleUpdateCompetitor(domain: string, request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const fields: string[] = [];
    const values: any[] = [];

    const allowedFields = [
      'company_name', 'status', 'website_url', 'has_ssl', 'website_quality',
      'has_blog', 'has_pricing_page', 'has_whatsapp', 'google_rating', 'google_reviews',
      'google_business_name', 'strengths', 'weaknesses', 'pricing_strategy',
      'target_market', 'certifications', 'threat_level', 'trend', 'notes',
    ];

    for (const f of allowedFields) {
      if (body[f] !== undefined) {
        fields.push(`${f} = ?`);
        values.push(typeof body[f] === 'object' ? JSON.stringify(body[f]) : body[f]);
      }
    }

    if (fields.length === 0) {
      return Response.json({ ok: false, error: 'No fields to update' }, { status: 400, headers: cors });
    }

    fields.push("updated_at = datetime('now')");
    values.push(domain);
    await env.DB.prepare(`UPDATE intel_competitors SET ${fields.join(', ')} WHERE domain = ?`).bind(...values).run();

    const updated = await env.DB.prepare('SELECT * FROM intel_competitors WHERE domain = ?').bind(domain).first();
    return Response.json({ ok: true, data: updated }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleDeleteCompetitor(domain: string, env: any): Promise<Response> {
  try {
    await env.DB.prepare('DELETE FROM intel_competitors WHERE domain = ?').bind(domain).run();
    return Response.json({ ok: true, deleted: domain }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// CRUD: OPPORTUNITIES
// ===================================================================

export async function handleListOpportunities(url: URL, env: any): Promise<Response> {
  try {
    const status = url.searchParams.get('status') || '';
    const priority = url.searchParams.get('priority') || '';
    const type = url.searchParams.get('type') || '';
    const service = url.searchParams.get('service') || '';
    const location = url.searchParams.get('location') || '';

    const conds: string[] = [];
    const params: any[] = [];
    if (status) { conds.push('status = ?'); params.push(status); }
    if (priority) { conds.push('priority = ?'); params.push(priority); }
    if (type) { conds.push('type = ?'); params.push(type); }
    if (service) { conds.push('service_slug = ?'); params.push(service); }
    if (location) { conds.push('location_slug = ?'); params.push(location); }

    const where = conds.length ? 'WHERE ' + conds.join(' AND ') : '';

    const rows = await env.DB.prepare(
      `SELECT * FROM intel_opportunities ${where} ORDER BY roi_score DESC, created_at DESC`
    ).bind(...params).all();

    const [types, statuses] = await Promise.all([
      env.DB.prepare('SELECT DISTINCT type FROM intel_opportunities ORDER BY type').all(),
      env.DB.prepare('SELECT DISTINCT status FROM intel_opportunities ORDER BY status').all(),
    ]);

    return Response.json({
      ok: true,
      data: {
        results: rows.results,
        filters: {
          types: types.results.map((r: any) => r.type),
          statuses: statuses.results.map((r: any) => r.status),
        },
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleCreateOpportunity(request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const result = await env.DB.prepare(`
      INSERT INTO intel_opportunities (type, priority, service_slug, location_slug, title, description, estimated_value, effort, roi_score, competitor_count, guardman_position, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      body.type || 'gap', body.priority || 'medium', body.service_slug || null,
      body.location_slug || null, body.title, body.description || null,
      body.estimated_value || 0, body.effort || 'medium', body.roi_score || 0,
      body.competitor_count || 0, body.guardman_position || 999,
      body.status || 'open'
    ).run();

    return Response.json({ ok: true, data: { id: result.meta?.last_row_id } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleUpdateOpportunity(id: number, request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const fields: string[] = [];
    const values: any[] = [];

    const allowedFields = [
      'type', 'priority', 'status', 'service_slug', 'location_slug',
      'title', 'description', 'estimated_value', 'effort', 'roi_score',
      'assigned_to', 'competitor_count', 'guardman_position',
    ];

    for (const f of allowedFields) {
      if (body[f] !== undefined) { fields.push(`${f} = ?`); values.push(body[f]); }
    }

    if (fields.length === 0) {
      return Response.json({ ok: false, error: 'No fields' }, { status: 400, headers: cors });
    }

    values.push(id);
    await env.DB.prepare(`UPDATE intel_opportunities SET ${fields.join(', ')} WHERE id = ?`).bind(...values).run();

    const updated = await env.DB.prepare('SELECT * FROM intel_opportunities WHERE id = ?').bind(id).first();
    return Response.json({ ok: true, data: updated }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleDeleteOpportunity(id: number, env: any): Promise<Response> {
  try {
    await env.DB.prepare('DELETE FROM intel_opportunities WHERE id = ?').bind(id).run();
    return Response.json({ ok: true, deleted: id }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// CRUD STATS
// ===================================================================

export async function handleCrudStats(env: any): Promise<Response> {
  try {
    const [
      totalResults, classifiedResults, unclassifiedResults,
      totalCompetitors, activeCompetitors,
      totalOpportunities, openOpportunities,
      siteTypeDist, resultTypeDist,
    ] = await Promise.all([
      env.DB.prepare('SELECT COUNT(*) as c FROM serper_results').first(),
      env.DB.prepare('SELECT COUNT(*) as c FROM serper_results WHERE site_type IS NOT NULL').first(),
      env.DB.prepare('SELECT COUNT(*) as c FROM serper_results WHERE site_type IS NULL').first(),
      env.DB.prepare('SELECT COUNT(*) as c FROM intel_competitors').first(),
      env.DB.prepare('SELECT COUNT(*) as c FROM intel_competitors WHERE status = ?').bind('active').first(),
      env.DB.prepare('SELECT COUNT(*) as c FROM intel_opportunities').first(),
      env.DB.prepare('SELECT COUNT(*) as c FROM intel_opportunities WHERE status = ?').bind('open').first(),
      env.DB.prepare('SELECT site_type, COUNT(*) as c FROM serper_results WHERE site_type IS NOT NULL GROUP BY site_type ORDER BY c DESC').all(),
      env.DB.prepare('SELECT result_type, COUNT(*) as c FROM serper_results GROUP BY result_type ORDER BY c DESC').all(),
    ]);

    return Response.json({
      ok: true,
      data: {
        serper_results: {
          total: (totalResults as any).c,
          classified: (classifiedResults as any).c,
          unclassified: (unclassifiedResults as any).c,
          site_type_distribution: (siteTypeDist as any).results,
          result_type_distribution: (resultTypeDist as any).results,
        },
        competitors: {
          total: (totalCompetitors as any).c,
          active: (activeCompetitors as any).c,
        },
        opportunities: {
          total: (totalOpportunities as any).c,
          open: (openOpportunities as any).c,
        },
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
