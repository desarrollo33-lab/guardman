// GuardMan Intel — Competitors (List, Get, Sync, Timeline)
import { cors } from './helpers';

// COMPETITORS
// ===================================================================

export async function handleListCompetitors(url: URL, env: any): Promise<Response> {
  try {
    const service = url.searchParams.get('service');
    const location = url.searchParams.get('location');

    let sql = `
      SELECT sr.domain,
        JSON_EXTRACT(sr.extra_json, '$.classification_label') as label,
        COUNT(DISTINCT sq.service_slug) as services,
        COUNT(DISTINCT sq.location_slug) as locations,
        COUNT(*) as appearances,
        ROUND(AVG(sr.position), 1) as avg_position,
        MIN(sr.position) as best_position,
        GROUP_CONCAT(DISTINCT sq.service_slug) as service_list
      FROM serper_results sr
      JOIN serper_queries sq ON sr.query_id = sq.id
      WHERE sr.site_type IN ('direct_competitor', 'indirect_competitor')
    `;
    const params: any[] = [];
    if (service) { sql += ' AND sq.service_slug = ?'; params.push(service); }
    if (location) { sql += ' AND sq.location_slug = ?'; params.push(location); }

    sql += ' GROUP BY sr.domain ORDER BY appearances DESC LIMIT 50';

    const { results } = await env.DB.prepare(sql).bind(...params).all();

    // Enrich with intel_competitors data if available
    const enriched = await Promise.all((results as any[]).map(async (r: any) => {
      try {
        const intel = await env.DB.prepare('SELECT threat_level, trend, pricing_strategy, target_market, strengths, weaknesses FROM intel_competitors WHERE domain = ?').bind(r.domain).first();
        return { ...r, ...intel };
      } catch {
        return r;
      }
    }));

    return Response.json({ ok: true, data: enriched }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleGetCompetitor(domain: string, env: any): Promise<Response> {
  try {
    // Get full competitor data from serper
    const serperData = await env.DB.prepare(`
      SELECT sr.domain, sr.title, sr.snippet, sr.position, sr.site_type, sr.link, sr.rating, sr.reviews_count,
        sq.service_slug, sq.location_slug, sq.query_text,
        JSON_EXTRACT(sr.extra_json, '$.classification_label') as label,
        JSON_EXTRACT(sr.extra_json, '$.key_insights') as insights,
        JSON_EXTRACT(sr.extra_json, '$.relevance_score') as relevance_score
      FROM serper_results sr
      JOIN serper_queries sq ON sr.query_id = sq.id
      WHERE sr.domain = ? AND sr.site_type IN ('direct_competitor', 'indirect_competitor')
      ORDER BY sr.position ASC
    `).bind(domain).all();

    // Aggregate
    const rows = serperData.results as any[];
    const services = new Set(rows.map(r => r.service_slug));
    const locations = new Set(rows.map(r => r.location_slug));
    const positions = rows.filter(r => r.position).map(r => r.position as number);
    const avgPos = positions.length > 0 ? (positions.reduce((a, b) => a + b, 0) / positions.length).toFixed(1) : null;
    const bestPos = positions.length > 0 ? Math.min(...positions) : null;

    // Get intel_competitor profile if exists
    let profile: any = null;
    try {
      profile = await env.DB.prepare('SELECT * FROM intel_competitors WHERE domain = ?').bind(domain).first();
    } catch {}

    // Where they beat us
    const whereWeLose = await env.DB.prepare(`
      SELECT sq.service_slug, sq.location_slug, sq.query_text,
        comp.position as their_pos, own.position as our_pos
      FROM serper_results comp
      JOIN serper_queries sq ON comp.query_id = sq.id
      JOIN serper_results own ON own.query_id = sq.id AND own.site_type = 'own'
      WHERE comp.domain = ? AND comp.site_type IN ('direct_competitor', 'indirect_competitor')
      AND comp.position < own.position
      ORDER BY (own.position - comp.position) DESC
      LIMIT 10
    `).bind(domain).all().catch(() => ({ results: [] }));

    // Where we beat them
    const whereWeWin = await env.DB.prepare(`
      SELECT sq.service_slug, sq.location_slug, sq.query_text,
        comp.position as their_pos, own.position as our_pos
      FROM serper_results comp
      JOIN serper_queries sq ON comp.query_id = sq.id
      JOIN serper_results own ON own.query_id = sq.id AND own.site_type = 'own'
      WHERE comp.domain = ? AND comp.site_type IN ('direct_competitor', 'indirect_competitor')
      AND own.position < comp.position
      ORDER BY (comp.position - own.position) DESC
      LIMIT 10
    `).bind(domain).all().catch(() => ({ results: [] }));

    // Detect weaknesses from snippets
    const allText = rows.map(r => `${r.title} ${r.snippet}`).join(' ').toLowerCase();
    const weaknesses: string[] = [];
    const strengths: string[] = [];

    if (!allText.includes('os-10') && !allText.includes('os10')) weaknesses.push('No menciona OS-10');
    if (!allText.includes('24/7') && !allText.includes('24 horas')) weaknesses.push('No menciona cobertura 24/7');
    if (!allText.includes('cotizar') && !allText.includes('presupuesto')) weaknesses.push('Sin CTA de cotización visible');
    if (allText.includes('mejor precio') || allText.includes('barato') || allText.includes('económico')) {
      strengths.push('Compiten agresivamente en precio');
      weaknesses.push('Estrategia de precios bajos (potencial calidad baja)');
    }
    if (allText.includes('certificado') || allText.includes('certificación')) strengths.push('Mencionan certificaciones');
    if (allText.includes('monitoreo') || allText.includes('central')) strengths.push('Ofrecen monitoreo/central');
    if (allText.includes('gratis') || allText.includes('evaluación gratuita')) strengths.push('Ofrecen evaluación gratis');

    return Response.json({
      ok: true,
      data: {
        domain,
        profile,
        summary: {
          appearances: rows.length,
          services: Array.from(services),
          locations: Array.from(locations),
          avg_position: avgPos ? parseFloat(avgPos) : null,
          best_position: bestPos,
          detected_strengths: strengths,
          detected_weaknesses: weaknesses,
        },
        serper_results: rows.slice(0, 30),
        where_we_win: whereWeWin.results,
        where_we_lose: whereWeLose.results,
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================

// COMPETITOR SYNC — Populate intel_competitors from serper data
// ===================================================================

export async function handleSyncCompetitors(env: any): Promise<Response> {
  try {
    const { results } = await env.DB.prepare(`
      SELECT sr.domain,
        COUNT(DISTINCT sq.service_slug) as services_present,
        COUNT(DISTINCT sq.location_slug) as locations_present,
        COUNT(*) as total_appearances,
        ROUND(AVG(sr.position), 1) as avg_position,
        MIN(sr.position) as best_position
      FROM serper_results sr
      JOIN serper_queries sq ON sr.query_id = sq.id
      WHERE sr.site_type IN ('direct_competitor', 'indirect_competitor')
      GROUP BY sr.domain
    `).all();

    let synced = 0;
    for (const row of results as any[]) {
      const snippets = await env.DB.prepare(`
        SELECT sr.title, sr.snippet FROM serper_results sr
        JOIN serper_queries sq ON sr.query_id = sq.id
        WHERE sr.domain = ? AND sr.site_type IN ('direct_competitor', 'indirect_competitor')
        LIMIT 50
      `).bind(row.domain).all();

      const allText = (snippets.results as any[]).map(r => `${r.title} ${r.snippet}`).join(' ').toLowerCase();
      const weaknesses: string[] = [];
      const strengths: string[] = [];

      if (!allText.includes('os-10') && !allText.includes('os10')) weaknesses.push('No menciona OS-10');
      if (!allText.includes('24/7') && !allText.includes('24 horas')) weaknesses.push('Sin 24/7');
      if (!allText.includes('cotizar') && !allText.includes('presupuesto')) weaknesses.push('Sin CTA cotización');
      if (allText.includes('certificado') || allText.includes('certificación')) strengths.push('Menciona certificaciones');
      if (allText.includes('monitoreo') || allText.includes('central')) strengths.push('Ofrece monitoreo');
      if (allText.includes('precio') && (allText.includes('mejor') || allText.includes('más bajo'))) {
        strengths.push('Compite en precio');
        weaknesses.push('Precio como estrategia');
      }

      let threat = 'medium';
      if (row.total_appearances > 300 && row.avg_position <= 4) threat = 'critical';
      else if (row.total_appearances > 100 && row.avg_position <= 5) threat = 'high';
      else if (row.total_appearances < 50) threat = 'low';

      let pricing = 'unknown';
      if (allText.includes('mejor precio') || allText.includes('económico') || allText.includes('barato')) pricing = 'low_cost';
      else if (allText.includes('premium') || allText.includes('exclusivo')) pricing = 'premium';
      else if (allText.includes('precio') || allText.includes('cotizar') || allText.includes('$')) pricing = 'visible';

      let trend = 'stable';
      try {
        const dates = await env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots ORDER BY snapshot_date DESC LIMIT 2').all();
        if ((dates.results as any[]).length >= 2) {
          const [latest, prev] = (dates.results as any[]).map(r => r.snapshot_date);
          const [latestAvg, prevAvg] = await Promise.all([
            env.DB.prepare('SELECT AVG(position) as avg FROM position_snapshots WHERE domain = ? AND snapshot_date = ?').bind(row.domain, latest).first(),
            env.DB.prepare('SELECT AVG(position) as avg FROM position_snapshots WHERE domain = ? AND snapshot_date = ?').bind(row.domain, prev).first(),
          ]);
          const diff = ((prevAvg?.avg || 0) - (latestAvg?.avg || 0));
          if (diff > 0.5) trend = 'rising';
          else if (diff < -0.5) trend = 'declining';
        }
      } catch {}

      await env.DB.prepare(`
        INSERT INTO intel_competitors (domain, total_appearances, services_present, locations_present,
          avg_position, best_position, strengths, weaknesses, pricing_strategy, threat_level, trend, last_analyzed)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        ON CONFLICT(domain) DO UPDATE SET
          total_appearances = excluded.total_appearances,
          services_present = excluded.services_present,
          locations_present = excluded.locations_present,
          avg_position = excluded.avg_position,
          best_position = excluded.best_position,
          strengths = excluded.strengths,
          weaknesses = excluded.weaknesses,
          pricing_strategy = excluded.pricing_strategy,
          threat_level = excluded.threat_level,
          trend = excluded.trend,
          last_analyzed = datetime('now')
      `).bind(
        row.domain, row.total_appearances, row.services_present, row.locations_present,
        row.avg_position, row.best_position,
        JSON.stringify(strengths), JSON.stringify(weaknesses),
        pricing, threat, trend
      ).run();
      synced++;
    }

    return Response.json({ ok: true, data: { synced, competitors: results.length } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

// ===================================================================
// COMPETITOR TIMELINE
// ===================================================================

export async function handleCompetitorTimeline(domain: string, env: any): Promise<Response> {
  try {
    const dates = await env.DB.prepare(
      'SELECT DISTINCT snapshot_date FROM position_snapshots WHERE domain = ? ORDER BY snapshot_date DESC LIMIT 15'
    ).bind(domain).all();

    const timeline: any[] = [];
    for (const d of (dates.results as any[])) {
      const row = await env.DB.prepare(
        'SELECT COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos, MIN(position) as best_pos FROM position_snapshots WHERE domain = ? AND snapshot_date = ?'
      ).bind(domain, d.snapshot_date).first();
      timeline.push({ date: d.snapshot_date, ...row });
    }

    return Response.json({ ok: true, data: { domain, timeline } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
