// GuardMan Admin — Intel Routes (Index)
// Delegates to modular handler files
import { CORS_HEADERS } from '../../../types';
import { handleLeadCapture, handleListLeads, handleCreateLead, handleGetLead, handleUpdateLead, handleListInteractions, handleCreateInteraction } from '../crm/leads';
import { handleListClients, handleGetClient, handleCreateClient, handleUpdateClient } from '../crm/clients';
import { handleListProposals, handleCreateProposal } from '../crm/proposals';
import { handlePipeline } from '../crm/pipeline';
import { handleMarketMap, handleMarketMatrix } from './market';
import { handleIntelDashboard } from './dashboard';
import { handleListCompetitors, handleGetCompetitor, handleSyncCompetitors, handleCompetitorTimeline } from './competitors';
import { handlePositionTimeline, handlePositionScorecard, handleQuickWins, handleKeywordMatrix, handleContentStrategy, handleFAQOpportunities, handleContentROI } from './seo';
import { handleAlerts, handleDismissAlert, handleLatestReport, handleGenerateReport, handleReportHistory } from './reports';
import { handleListSerperResults, handleUpdateSerperResult, handleDeleteSerperResult, handleBulkClassify, handleUpdateCompetitor, handleDeleteCompetitor, handleListOpportunities, handleCreateOpportunity, handleUpdateOpportunity, handleDeleteOpportunity, handleCrudStats } from './crud';

const cors = CORS_HEADERS;

export const intelRoutes = [
  {
    pattern: /^\/api\/intel\/.+/,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

      // PUBLIC: Lead capture from website
      if (path === '/api/intel/leads/capture' && method === 'POST') {
        return await handleLeadCapture(request, env);
      }

      // LEADS CRUD
      if (path === '/api/intel/leads' && method === 'GET') return await handleListLeads(url, env);
      if (path === '/api/intel/leads' && method === 'POST') return await handleCreateLead(request, env);
      if (path.match(/^\/api\/intel\/leads\/\d+$/) && method === 'GET') return await handleGetLead(parseInt(path.split('/').pop()!), env);
      if (path.match(/^\/api\/intel\/leads\/\d+$/) && method === 'PUT') return await handleUpdateLead(parseInt(path.split('/').pop()!), request, env);

      // INTERACTIONS
      if (path.match(/^\/api\/intel\/leads\/\d+\/interactions$/) && method === 'GET') return await handleListInteractions(parseInt(path.split('/')[5]), env);
      if (path.match(/^\/api\/intel\/leads\/\d+\/interactions$/) && method === 'POST') return await handleCreateInteraction(parseInt(path.split('/')[5]), request, env);

      // PROPOSALS
      if (path.match(/^\/api\/intel\/leads\/\d+\/proposals$/) && method === 'GET') return await handleListProposals(parseInt(path.split('/')[5]), env);
      if (path.match(/^\/api\/intel\/leads\/\d+\/proposals$/) && method === 'POST') return await handleCreateProposal(parseInt(path.split('/')[5]), request, env);

      // CLIENTS
      if (path === '/api/intel/clients' && method === 'GET') return await handleListClients(url, env);
      if (path.match(/^\/api\/intel\/clients\/\d+$/) && method === 'GET') return await handleGetClient(parseInt(path.split('/').pop()!), env);
      if (path === '/api/intel/clients' && method === 'POST') return await handleCreateClient(request, env);
      if (path.match(/^\/api\/intel\/clients\/\d+$/) && method === 'PUT') return await handleUpdateClient(parseInt(path.split('/').pop()!), request, env);

      // PIPELINE
      if (path === '/api/intel/pipeline' && method === 'GET') return await handlePipeline(env);

      // MARKET MAP
      if (path === '/api/intel/market-map' && method === 'GET') return await handleMarketMap(env);
      if (path === '/api/intel/market-matrix' && method === 'GET') return await handleMarketMatrix(env);

      // DASHBOARD
      if (path === '/api/intel/dashboard' && method === 'GET') return await handleIntelDashboard(env);

      // COMPETITORS
      if (path === '/api/intel/competitors/sync' && method === 'POST') return await handleSyncCompetitors(env);
      if (path === '/api/intel/competitors' && method === 'GET') return await handleListCompetitors(url, env);
      if (path.match(/^\/api\/intel\/competitors\/.+\/timeline$/) && method === 'GET') {
        const parts = path.split('/');
        return await handleCompetitorTimeline(decodeURIComponent(parts[parts.length - 2]), env);
      }
      if (path.match(/^\/api\/intel\/competitors\/.+$/) && method === 'GET') {
        return await handleGetCompetitor(decodeURIComponent(path.split('/').pop()!), env);
      }

      // POSITIONS & SEO
      if (path === '/api/intel/positions/timeline' && method === 'GET') return await handlePositionTimeline(url, env);
      if (path === '/api/intel/positions/scorecard' && method === 'GET') return await handlePositionScorecard(env);
      if (path === '/api/intel/quick-wins' && method === 'GET') return await handleQuickWins(env);
      if (path === '/api/intel/keyword-matrix' && method === 'GET') return await handleKeywordMatrix(env);
      if (path === '/api/intel/content-strategy' && method === 'GET') return await handleContentStrategy(env);
      if (path === '/api/intel/faq-opportunities' && method === 'GET') return await handleFAQOpportunities(url, env);
      if (path === '/api/intel/content-roi' && method === 'GET') return await handleContentROI(env);

      // ALERTS
      if (path === '/api/intel/alerts' && method === 'GET') return await handleAlerts(env);
      if (path.match(/^\/api\/intel\/alerts\/\d+\/dismiss$/) && method === 'PUT') return await handleDismissAlert(parseInt(path.split('/')[4]), env);

      // REPORTS
      if (path === '/api/intel/report/latest' && method === 'GET') return await handleLatestReport(env);
      if (path === '/api/intel/report/generate' && method === 'POST') return await handleGenerateReport(env);
      if (path === '/api/intel/report/history' && method === 'GET') return await handleReportHistory(url, env);

      // CRUD: SERPER RESULTS
      if (path === '/api/intel/serper-results/bulk/classify' && method === 'PUT') return await handleBulkClassify(request, env);
      if (path === '/api/intel/serper-results' && method === 'GET') return await handleListSerperResults(url, env);
      const serperResMatch = path.match(/^\/api\/intel\/serper-results\/(\d+)$/);
      if (serperResMatch && method === 'PUT') return await handleUpdateSerperResult(parseInt(serperResMatch[1]), request, env);
      if (serperResMatch && method === 'DELETE') return await handleDeleteSerperResult(parseInt(serperResMatch[1]), env);

      // CRUD: COMPETITORS (PUT/DELETE)
      const compUpdateMatch = path.match(/^\/api\/intel\/competitors\/([\w.-]+)$/);
      if (compUpdateMatch && !path.includes('/sync') && !path.includes('/timeline') && method === 'PUT') return await handleUpdateCompetitor(decodeURIComponent(compUpdateMatch[1]), request, env);
      if (compUpdateMatch && method === 'DELETE') return await handleDeleteCompetitor(decodeURIComponent(compUpdateMatch[1]), env);

      // CRUD: OPPORTUNITIES
      if (path === '/api/intel/opportunities' && method === 'GET') return await handleListOpportunities(url, env);
      if (path === '/api/intel/opportunities' && method === 'POST') return await handleCreateOpportunity(request, env);
      const oppMatch = path.match(/^\/api\/intel\/opportunities\/(\d+)$/);
      if (oppMatch && method === 'PUT') return await handleUpdateOpportunity(parseInt(oppMatch[1]), request, env);
      if (oppMatch && method === 'DELETE') return await handleDeleteOpportunity(parseInt(oppMatch[1]), env);

      // CRUD STATS
      if (path === '/api/intel/crud-stats' && method === 'GET') return await handleCrudStats(env);

      // === WORKFLOW INTEL ENDPOINTS ===
      // Snapshot endpoints (from SEOIntelWorkflow)
      if (path === '/api/intel/snapshot/latest' && method === 'GET') {
        try {
          const snapshot = await env.DB.prepare(
            'SELECT * FROM intel_snapshots ORDER BY created_at DESC LIMIT 1'
          ).first();
          if (!snapshot) return Response.json({ ok: false, error: 'No snapshots yet' }, { status: 404, headers: cors });
          return Response.json({ ok: true, data: snapshot }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      if (path === '/api/intel/snapshots' && method === 'GET') {
        try {
          const { results } = await env.DB.prepare(
            'SELECT id, trigger_type, created_at, summary FROM intel_snapshots ORDER BY created_at DESC LIMIT 20'
          ).all();
          return Response.json({ ok: true, data: results }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      if (path === '/api/intel/proposals' && method === 'GET') {
        try {
          const snapshot = await env.DB.prepare(
            'SELECT content_proposals FROM intel_snapshots ORDER BY created_at DESC LIMIT 1'
          ).first();
          if (!snapshot) return Response.json({ ok: false, error: 'No snapshots yet' }, { status: 404, headers: cors });
          return Response.json({ ok: true, data: JSON.parse(snapshot.content_proposals as string) }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      return null;
    },
  },
];
