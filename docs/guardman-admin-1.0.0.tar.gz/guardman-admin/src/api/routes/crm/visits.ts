// GuardMan CRM — Visitas Técnicas
// FASE CRM-2: Checklist + fotos en R2
import { CORS_HEADERS } from '../../../types';
const cors = CORS_HEADERS;

export async function handleGetVisitByLead(leadId: number, env: any): Promise<Response> {
  try {
    const visit = await env.DB.prepare('SELECT * FROM intel_visits WHERE lead_id = ? ORDER BY created_at DESC LIMIT 1').bind(leadId).first();
    const photos = visit ? (await env.DB.prepare('SELECT * FROM intel_visit_photos WHERE visit_id = ? ORDER BY photo_order').bind(visit.id).all()).results : [];
    return Response.json({ ok: true, data: { visit, photos } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleCreateVisit(request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    if (body.id) {
      await env.DB.prepare(
        `UPDATE intel_visits SET visit_date = ?, facility_type = ?, facility_sqm = ?, num_access_points = ?,
         has_current_security = ?, current_competitor = ?, current_contract_end = ?, shifts_needed = ?,
         armed_service = ?, risks_noted = ?, notes = ?, completed_at = ?, photos_count = ?
         WHERE id = ?`
      ).bind(
        body.visit_date, body.facility_type || null, body.facility_sqm || null, body.num_access_points || null,
        body.has_current_security || 0, body.current_competitor || null, body.current_contract_end || null,
        body.shifts_needed || null, body.armed_service || 0, body.risks_noted || null, body.notes || null,
        body.completed_at || null, body.photos_count || 0, body.id,
      ).run();
      const visit = await env.DB.prepare('SELECT * FROM intel_visits WHERE id = ?').bind(body.id).first();
      return Response.json({ ok: true, data: visit }, { headers: cors });
    }
    const result = await env.DB.prepare(
      `INSERT INTO intel_visits (lead_id, visit_date, facility_type, facility_sqm, num_access_points,
       has_current_security, current_competitor, current_contract_end, shifts_needed, armed_service,
       risks_noted, notes, photos_count, completed_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      body.lead_id, body.visit_date, body.facility_type || null, body.facility_sqm || null,
      body.num_access_points || null, body.has_current_security || 0, body.current_competitor || null,
      body.current_contract_end || null, body.shifts_needed || null, body.armed_service || 0,
      body.risks_noted || null, body.notes || null, body.photos_count || 0, body.completed_at || null,
    ).run();
    const visit = await env.DB.prepare('SELECT * FROM intel_visits WHERE id = ?').bind(result.meta.last_row_id).first();
    return Response.json({ ok: true, data: visit }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleUploadVisitPhoto(visitId: number, request: Request, env: any): Promise<Response> {
  try {
    const formData = await request.formData();
    const file = formData.get('photo') as File;
    const caption = (formData.get('caption') as string) || '';
    if (!file) return Response.json({ ok: false, error: 'No file' }, { status: 400, headers: cors });

    const ext = file.name.split('.').pop() || 'jpg';
    const key = `visits/${visitId}/${Date.now()}.${ext}`;
    await env.IMAGES.put(key, file.stream(), { httpMetadata: { contentType: file.type } });

    await env.DB.prepare(
      `INSERT INTO intel_visit_photos (visit_id, r2_key, caption, photo_order)
       VALUES (?, ?, ?, (SELECT COALESCE(MAX(photo_order),0)+1 FROM intel_visit_photos WHERE visit_id = ?))`
    ).bind(visitId, key, caption, visitId).run();

    await env.DB.prepare(
      'UPDATE intel_visits SET photos_count = (SELECT COUNT(*) FROM intel_visit_photos WHERE visit_id = ?) WHERE id = ?'
    ).bind(visitId, visitId).run();

    return Response.json({ ok: true, data: { key } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
