// GuardMan CRM — Clients
// FASE CRM-0: Movido desde intel/crm.ts
import { CORS_HEADERS } from '../../../types';
const cors = CORS_HEADERS;

export async function handleListClients(url: URL, env: any): Promise<Response> {
  try {
    const status = url.searchParams.get('status');
    let sql = 'SELECT c.*, (SELECT COUNT(*) FROM intel_client_services ics WHERE ics.client_id = c.id AND ics.status = \'active\') as active_services FROM intel_clients c WHERE 1=1';
    const params: any[] = [];
    if (status) { sql += ' AND c.status = ?'; params.push(status); }
    sql += ' ORDER BY c.created_at DESC';

    const { results } = await env.DB.prepare(sql).bind(...params).all();
    return Response.json({ ok: true, data: results }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleGetClient(id: number, env: any): Promise<Response> {
  try {
    const client = await env.DB.prepare('SELECT * FROM intel_clients WHERE id = ?').bind(id).first();
    if (!client) return Response.json({ ok: false, error: 'Client not found' }, { status: 404, headers: cors });

    const services = await env.DB.prepare(
      'SELECT * FROM intel_client_services WHERE client_id = ? ORDER BY status'
    ).bind(id).all();

    const interactions = await env.DB.prepare(
      'SELECT * FROM intel_interactions WHERE client_id = ? ORDER BY created_at DESC LIMIT 20'
    ).bind(id).all();

    return Response.json({ ok: true, data: { client, services: services.results, interactions: interactions.results } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleCreateClient(request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const slug = 'cl-' + Date.now().toString(36);

    const result = await env.DB.prepare(
      `INSERT INTO intel_clients (lead_id, slug, status, company_name, company_rut, industry, size,
       employee_count, primary_contact_name, primary_contact_email, primary_contact_phone,
       contract_start, contract_end, contract_type, monthly_value,
       location_slug, address, notes, tags)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      body.lead_id || null, slug, body.status || 'active',
      body.company_name, body.company_rut, body.industry, body.size,
      body.employee_count || null,
      body.primary_contact_name, body.primary_contact_email, body.primary_contact_phone,
      body.contract_start, body.contract_end, body.contract_type, body.monthly_value || 0,
      body.location_slug, body.address, body.notes, body.tags ? JSON.stringify(body.tags) : null,
    ).run();

    const clientId = result.meta.last_row_id as number;

    if (body.lead_id) {
      await env.DB.prepare("UPDATE intel_leads SET status = 'won', updated_at = datetime('now') WHERE id = ?").bind(body.lead_id).run();
    }

    if (body.services && Array.isArray(body.services)) {
      for (const svc of body.services) {
        await env.DB.prepare(
          `INSERT INTO intel_client_services (client_id, service_slug, status, quantity, unit, monthly_price, start_date)
           VALUES (?, ?, 'active', ?, ?, ?, ?)`
        ).bind(clientId, svc.service_slug, svc.quantity || 1, svc.unit || null, svc.monthly_price || 0, body.contract_start || null).run();
      }
    }

    const client = await env.DB.prepare('SELECT * FROM intel_clients WHERE id = ?').bind(clientId).first();
    return Response.json({ ok: true, data: client }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleUpdateClient(id: number, request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const fields: string[] = [];
    const params: any[] = [];

    const allowed = ['status', 'company_name', 'company_rut', 'industry', 'size', 'employee_count',
      'primary_contact_name', 'primary_contact_email', 'primary_contact_phone',
      'contract_start', 'contract_end', 'contract_type', 'monthly_value',
      'location_slug', 'address', 'notes', 'tags'];

    for (const key of allowed) {
      if (body[key] !== undefined) {
        fields.push(`${key} = ?`);
        params.push(key === 'tags' && typeof body[key] !== 'string' ? JSON.stringify(body[key]) : body[key]);
      }
    }

    if (fields.length === 0) return Response.json({ ok: false, error: 'No fields to update' }, { status: 400, headers: cors });

    fields.push("updated_at = datetime('now')");
    params.push(id);

    await env.DB.prepare(`UPDATE intel_clients SET ${fields.join(', ')} WHERE id = ?`).bind(...params).run();

    const client = await env.DB.prepare('SELECT * FROM intel_clients WHERE id = ?').bind(id).first();
    return Response.json({ ok: true, data: client }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
