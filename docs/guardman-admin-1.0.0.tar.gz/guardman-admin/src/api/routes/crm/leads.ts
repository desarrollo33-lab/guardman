// GuardMan CRM — Leads & Interactions
// FASE CRM-0: Movido desde intel/crm.ts
import { CORS_HEADERS } from '../../../types';
const cors = CORS_HEADERS;
import { generateSlug, enrichLeadWithIntel } from '../intel/helpers';

export async function handleLeadCapture(request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;

    const slug = generateSlug();
    const result = await env.DB.prepare(
      `INSERT INTO intel_leads (slug, status, source, contact_name, contact_email, contact_phone,
       company_name, company_industry, service_slug, location_slug, message,
       utm_source, utm_medium, utm_campaign, landing_page, ip_hash)
       VALUES (?, 'new', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      slug,
      body.source || 'web',
      body.name || body.contact_name || 'Sin nombre',
      body.email || body.contact_email || null,
      body.phone || body.contact_phone || null,
      body.company || body.company_name || null,
      body.company_industry || null,
      body.service || body.service_slug || null,
      body.location || body.location_slug || null,
      body.message || null,
      body.utm_source || null,
      body.utm_medium || null,
      body.utm_campaign || null,
      body.landing_page || null,
      body.ip_hash || null,
    ).run();

    const leadId = result.meta.last_row_id as number;

    await enrichLeadWithIntel(env, body.service || body.service_slug, body.location || body.location_slug, leadId);

    const lead = await env.DB.prepare('SELECT * FROM intel_leads WHERE id = ?').bind(leadId).first();

    return Response.json({ ok: true, data: lead }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleListLeads(url: URL, env: any): Promise<Response> {
  try {
    const status = url.searchParams.get('status');
    const service = url.searchParams.get('service');
    const location = url.searchParams.get('location');
    const search = url.searchParams.get('q');
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const offset = parseInt(url.searchParams.get('offset') || '0');

    let sql = 'SELECT * FROM intel_leads WHERE 1=1';
    const params: any[] = [];

    if (status) { sql += ' AND status = ?'; params.push(status); }
    if (service) { sql += ' AND service_slug = ?'; params.push(service); }
    if (location) { sql += ' AND location_slug = ?'; params.push(location); }
    if (search) {
      sql += ' AND (contact_name LIKE ? OR company_name LIKE ? OR contact_email LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const { results } = await env.DB.prepare(sql).bind(...params).all();
    const total = await env.DB.prepare('SELECT COUNT(*) as cnt FROM intel_leads').first();

    return Response.json({ ok: true, data: results, total: total?.cnt || 0 }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleCreateLead(request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const slug = generateSlug();

    const result = await env.DB.prepare(
      `INSERT INTO intel_leads (slug, status, source, contact_name, contact_email, contact_phone,
       company_name, company_rut, company_industry, service_slug, location_slug,
       location_address, message, estimated_sqm, has_existing_system,
       assigned_to, estimated_value, probability)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      slug, body.status || 'new', body.source || 'manual',
      body.contact_name, body.contact_email, body.contact_phone,
      body.company_name, body.company_rut, body.company_industry,
      body.service_slug, body.location_slug,
      body.location_address, body.message, body.estimated_sqm || null,
      body.has_existing_system || 0,
      body.assigned_to || null, body.estimated_value || 0, body.probability || 0.3,
    ).run();

    const leadId = result.meta.last_row_id as number;
    await enrichLeadWithIntel(env, body.service_slug, body.location_slug, leadId);

    const lead = await env.DB.prepare('SELECT * FROM intel_leads WHERE id = ?').bind(leadId).first();
    return Response.json({ ok: true, data: lead }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleGetLead(id: number, env: any): Promise<Response> {
  try {
    const lead = await env.DB.prepare('SELECT * FROM intel_leads WHERE id = ?').bind(id).first();
    if (!lead) return Response.json({ ok: false, error: 'Lead not found' }, { status: 404, headers: cors });

    const interactions = await env.DB.prepare(
      'SELECT * FROM intel_interactions WHERE lead_id = ? ORDER BY created_at DESC LIMIT 20'
    ).bind(id).all();

    const proposals = await env.DB.prepare(
      'SELECT * FROM intel_proposals WHERE lead_id = ? ORDER BY created_at DESC'
    ).bind(id).all();

    let intel: any = null;
    const svc = lead.service_slug as string;
    const loc = lead.location_slug as string;
    if (svc && loc) {
      const [topCompetitors, ourPositions, contentGaps] = await Promise.all([
        env.DB.prepare(
          `SELECT sr.domain, sr.title, sr.snippet, sr.position,
           JSON_EXTRACT(sr.extra_json, '$.classification_label') as label
           FROM serper_results sr
           JOIN serper_queries sq ON sr.query_id = sq.id
           WHERE sq.service_slug = ? AND sq.location_slug = ? AND sr.site_type = 'direct_competitor'
           ORDER BY sr.position ASC LIMIT 5`
        ).bind(svc, loc).all().catch(() => ({ results: [] })),
        env.DB.prepare(
          `SELECT sq.query_text, sr.position, sr.title
           FROM serper_results sr
           JOIN serper_queries sq ON sr.query_id = sq.id
           WHERE sq.service_slug = ? AND sq.location_slug = ? AND sr.site_type = 'own'
           ORDER BY sr.position ASC LIMIT 5`
        ).bind(svc, loc).all().catch(() => ({ results: [] })),
        env.DB.prepare(
          `SELECT sq.query_text
           FROM serper_queries sq
           LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = 'own'
           WHERE sq.service_slug = ? AND sq.location_slug = ? AND sq.status = 'completed'
           AND (sr.position IS NULL OR sr.position > 5)
           LIMIT 5`
        ).bind(svc, loc).all().catch(() => ({ results: [] })),
      ]);
      intel = { topCompetitors: topCompetitors.results, ourPositions: ourPositions.results, contentGaps: contentGaps.results };
    }

    return Response.json({ ok: true, data: { lead, interactions: interactions.results, proposals: proposals.results, intel } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleUpdateLead(id: number, request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const fields: string[] = [];
    const params: any[] = [];

    const allowed = ['status', 'contact_name', 'contact_email', 'contact_phone', 'company_name',
      'company_rut', 'company_industry', 'service_slug', 'location_slug', 'location_address',
      'message', 'assigned_to', 'estimated_value', 'probability', 'next_follow_up', 'notes',
      'facility_type', 'facility_sqm', 'has_current_security', 'current_competitor',
      'current_contract_end', 'shifts_needed', 'armed_service', 'no_contact_attempts',
      'loss_reason', 'loss_competitor', 'loss_price_ref', 'last_activity_at', 'frozen_flag'];

    if (body.status === 'lost' && !body.loss_reason) {
      return Response.json({ ok: false, error: 'Debe seleccionar un motivo de pérdida' }, { status: 400, headers: cors });
    }

    if (body.status === 'proposal_sent') {
      const visit = await env.DB.prepare(
        'SELECT id FROM intel_visits WHERE lead_id = ? AND completed_at IS NOT NULL'
      ).bind(id).first();
      if (!visit) {
        return Response.json({ ok: false, error: 'Debe completar la visita tecnica antes de enviar cotizacion' }, { status: 400, headers: cors });
      }
    }

    for (const key of allowed) {
      if (body[key] !== undefined) {
        fields.push(`${key} = ?`);
        params.push(body[key]);
      }
    }

    if (fields.length === 0) return Response.json({ ok: false, error: 'No fields to update' }, { status: 400, headers: cors });

    if (body.status) {
      if (body.status === 'contacted' || body.status === 'contactado') {
        fields.push('first_contact_at = datetime(\'now\')');
      }
      fields.push('last_contact_at = datetime(\'now\')');
      fields.push('last_activity_at = datetime(\'now\')');
    }

    fields.push("updated_at = datetime('now')");
    params.push(id);

    await env.DB.prepare(`UPDATE intel_leads SET ${fields.join(', ')} WHERE id = ?`).bind(...params).run();

    const lead = await env.DB.prepare('SELECT * FROM intel_leads WHERE id = ?').bind(id).first();
    return Response.json({ ok: true, data: lead }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleListInteractions(leadId: number, env: any): Promise<Response> {
  try {
    const { results } = await env.DB.prepare(
      'SELECT * FROM intel_interactions WHERE lead_id = ? ORDER BY created_at DESC'
    ).bind(leadId).all();
    return Response.json({ ok: true, data: results }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleCreateInteraction(leadId: number, request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    await env.DB.prepare(
      `INSERT INTO intel_interactions (lead_id, type, direction, summary, outcome, next_action, next_action_date, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      leadId, body.type || 'note', body.direction || 'outbound',
      body.summary, body.outcome, body.next_action, body.next_action_date, body.created_by || 'admin',
    ).run();

    await env.DB.prepare("UPDATE intel_leads SET last_contact_at = datetime('now'), updated_at = datetime('now') WHERE id = ?").bind(leadId).run();

    return Response.json({ ok: true, data: { created: true } }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
