// GuardMan CRM — Pipeline
// FASE CRM-0: Movido desde intel/crm.ts
import { CORS_HEADERS } from '../../../types';
const cors = CORS_HEADERS;

export async function handlePipeline(env: any): Promise<Response> {
  try {
    const stages = ['new', 'contacted', 'visit_scheduled', 'proposal_sent', 'negotiation', 'won', 'lost'];
    const pipeline: Record<string, any[]> = {};
    const stats: Record<string, number> = {};

    for (const stage of stages) {
      const { results } = await env.DB.prepare(
        'SELECT id, slug, contact_name, company_name, service_slug, location_slug, estimated_value, probability, market_difficulty, guardman_position, competitor_density, serper_opportunity_score, created_at, next_follow_up FROM intel_leads WHERE status = ? ORDER BY created_at DESC'
      ).bind(stage).all();
      pipeline[stage] = results as any[];
      stats[stage] = results.length;
    }

    const [totalLeads, totalValue, avgProbability] = await Promise.all([
      env.DB.prepare('SELECT COUNT(*) as cnt FROM intel_leads').first(),
      env.DB.prepare('SELECT COALESCE(SUM(estimated_value * probability), 0) as val FROM intel_leads WHERE status NOT IN (\'won\', \'lost\')').first(),
      env.DB.prepare('SELECT AVG(probability) as avg FROM intel_leads WHERE status NOT IN (\'won\', \'lost\')').first(),
    ]);

    return Response.json({
      ok: true,
      data: {
        pipeline,
        stats,
        summary: {
          total: totalLeads?.cnt || 0,
          weighted_value: totalValue?.val || 0,
          avg_probability: avgProbability?.avg || 0,
        },
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
