// GuardMan CRM — Proposals + Items + Versionado
// FASE CRM-4: Cotización técnica con items, versionado y condiciones comerciales
import { CORS_HEADERS } from '../../../types';
const cors = CORS_HEADERS;

export async function handleListProposals(leadId: number, env: any): Promise<Response> {
  try {
    const { results } = await env.DB.prepare(
      'SELECT * FROM intel_proposals WHERE lead_id = ? ORDER BY created_at DESC'
    ).bind(leadId).all();
    return Response.json({ ok: true, data: results }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleListAllProposals(url: URL, env: any): Promise<Response> {
  try {
    const status = url.searchParams.get('status');
    let sql = 'SELECT p.*, l.contact_name, l.company_name FROM intel_proposals p LEFT JOIN intel_leads l ON p.lead_id = l.id WHERE 1=1';
    const params: any[] = [];
    if (status) { sql += ' AND p.status = ?'; params.push(status); }
    sql += ' ORDER BY p.created_at DESC LIMIT 100';
    const { results } = await env.DB.prepare(sql).bind(...params).all();
    return Response.json({ ok: true, data: results }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}

export async function handleCreateProposal(leadId: number, request: Request, env: any): Promise<Response> {
  try {
    const body = await request.json() as any;
    const slug = 'prop-' + Date.now().toString(36);

    const maxVersion = await env.DB.prepare(
      'SELECT COALESCE(MAX(version), 0) as mv FROM intel_proposals WHERE lead_id = ?'
    ).bind(leadId).first();
    const version = ((maxVersion?.mv as number) || 0) + 1;

    const result = await env.DB.prepare(
      `INSERT INTO intel_proposals (lead_id, slug, status, services_json, total_monthly, total_setup,
       discount_pct, valid_until, notes, ai_generated, competitor_price_ref, win_probability,
       contract_period_months, payment_terms, annual_adjustment, sla_response_minutes, version, parent_proposal_id, executive_notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      leadId, slug, body.status || 'draft',
      typeof body.services_json === 'string' ? body.services_json : JSON.stringify(body.services_json || []),
      body.total_monthly || 0, body.total_setup || 0,
      body.discount_pct || 0, body.valid_until || null,
      body.notes || null, body.ai_generated ? 1 : 0,
      body.competitor_price_ref || null, body.win_probability || 0.3,
      body.contract_period_months || null, body.payment_terms || null,
      body.annual_adjustment || null, body.sla_response_minutes || null,
      version, body.parent_proposal_id || null, body.executive_notes || null,
    ).run();

    const proposalId = result.meta.last_row_id as number;

    if (body.items && Array.isArray(body.items)) {
      for (const item of body.items) {
        await env.DB.prepare(
          `INSERT INTO intel_proposal_items (proposal_id, service_type, quantity, unit_price, total, details)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).bind(
          proposalId, item.service_type, item.quantity || 1,
          item.unit_price || 0, (item.quantity || 1) * (item.unit_price || 0),
          item.details || null,
        ).run();
      }
    }

    await env.DB.prepare("UPDATE intel_leads SET status = 'proposal_sent', updated_at = datetime('now') WHERE id = ? AND status NOT IN ('won', 'lost')").bind(leadId).run();

    const proposal = await env.DB.prepare('SELECT * FROM intel_proposals WHERE slug = ?').bind(slug).first();
    return Response.json({ ok: true, data: proposal }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
