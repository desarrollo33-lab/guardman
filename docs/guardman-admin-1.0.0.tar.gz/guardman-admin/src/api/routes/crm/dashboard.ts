// GuardMan CRM — Dashboard Comercial (sin SEO)
// FASE CRM-0 + CRM-3: KPIs comerciales + Mi Día
import { CORS_HEADERS } from '../../../types';
const cors = CORS_HEADERS;

export async function handleCRMDashboard(env: any): Promise<Response> {
  try {
    const today = new Date().toISOString().split('T')[0];
    const [
      leadStats,
      clientStats,
      pipelineValue,
      recentLeads,
      recentInteractions,
      frozenLeads,
      uncontactedLeads,
      upcomingRenewals,
      followUpsVencidos,
      visitasHoy,
      cotizacionesSinSeguimiento,
      noContacta,
    ] = await Promise.all([
      env.DB.prepare('SELECT status, COUNT(*) as cnt, COALESCE(SUM(estimated_value), 0) as total_value FROM intel_leads GROUP BY status').all().catch(() => ({ results: [] })),
      env.DB.prepare('SELECT status, COUNT(*) as cnt, COALESCE(SUM(monthly_value), 0) as total_value FROM intel_clients GROUP BY status').all().catch(() => ({ results: [] })),
      env.DB.prepare('SELECT COALESCE(SUM(estimated_value * probability), 0) as weighted FROM intel_leads WHERE status NOT IN (\'won\', \'lost\')').first().catch(() => ({ weighted: 0 })),
      env.DB.prepare('SELECT id, contact_name, company_name, service_slug, location_slug, status, estimated_value, created_at FROM intel_leads ORDER BY created_at DESC LIMIT 5').all().catch(() => ({ results: [] })),
      env.DB.prepare('SELECT i.*, l.contact_name, l.company_name FROM intel_interactions i LEFT JOIN intel_leads l ON i.lead_id = l.id ORDER BY i.created_at DESC LIMIT 10').all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT id, contact_name, company_name, status, last_contact_at FROM intel_leads WHERE status NOT IN ('won', 'lost') AND (last_contact_at IS NULL OR last_contact_at < datetime('now', '-7 days')) ORDER BY last_contact_at ASC LIMIT 10").all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT id, contact_name, company_name, status, created_at FROM intel_leads WHERE status = 'new' AND created_at < datetime('now', '-4 hours') ORDER BY created_at ASC LIMIT 10").all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT id, company_name, contract_end, monthly_value FROM intel_clients WHERE contract_end IS NOT NULL AND contract_end <= date('now', '+60 days') AND status = 'active' ORDER BY contract_end ASC LIMIT 10").all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT id, contact_name, company_name, status, next_follow_up FROM intel_leads WHERE status NOT IN ('won', 'lost') AND next_follow_up IS NOT NULL AND next_follow_up < date('now') ORDER BY next_follow_up ASC LIMIT 10").all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT v.*, l.contact_name, l.company_name FROM intel_visits v LEFT JOIN intel_leads l ON v.lead_id = l.id WHERE v.visit_date = ? ORDER BY v.visit_date ASC LIMIT 10").bind(today).all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT p.*, l.contact_name, l.company_name FROM intel_proposals p LEFT JOIN intel_leads l ON p.lead_id = l.id WHERE p.status = 'sent' AND p.sent_at < datetime('now', '-2 days') ORDER BY p.sent_at ASC LIMIT 10").all().catch(() => ({ results: [] })),
      env.DB.prepare("SELECT id, contact_name, company_name, status, no_contact_attempts FROM intel_leads WHERE status NOT IN ('won', 'lost') AND no_contact_attempts > 0 ORDER BY no_contact_attempts DESC LIMIT 10").all().catch(() => ({ results: [] })),
    ]);

    const leadMap: Record<string, any> = { new: { cnt: 0, total_value: 0 }, contacted: { cnt: 0, total_value: 0 }, visit_scheduled: { cnt: 0, total_value: 0 }, proposal_sent: { cnt: 0, total_value: 0 }, negotiation: { cnt: 0, total_value: 0 }, won: { cnt: 0, total_value: 0 }, lost: { cnt: 0, total_value: 0 } };
    for (const row of (leadStats.results as any[] || [])) {
      if (leadMap[row.status]) leadMap[row.status] = { cnt: row.cnt, total_value: row.total_value };
    }

    let activeClients = 0;
    let monthlyRevenue = 0;
    for (const row of (clientStats.results as any[] || [])) {
      if (row.status === 'active') {
        activeClients += row.cnt;
        monthlyRevenue += row.total_value || 0;
      }
    }

    return Response.json({
      ok: true,
      data: {
        leads: leadMap,
        clients: { total: activeClients, monthly_revenue: monthlyRevenue },
        pipeline_weighted_value: (pipelineValue as any)?.weighted || 0,
        recent_leads: recentLeads.results,
        recent_interactions: recentInteractions.results,
        frozen_leads: frozenLeads.results,
        uncontacted_leads: uncontactedLeads.results,
        upcoming_renewals: upcomingRenewals.results,
        mi_dia: {
          urgent: [
            ...(uncontactedLeads.results || []),
            ...(followUpsVencidos.results || []),
          ],
          retry: noContacta.results || [],
          visits: visitasHoy.results || [],
          followup: cotizacionesSinSeguimiento.results || [],
          frozen: frozenLeads.results || [],
        },
      },
    }, { headers: cors });
  } catch (err: any) {
    return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
  }
}
