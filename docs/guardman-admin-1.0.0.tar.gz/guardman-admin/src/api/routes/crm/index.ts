// GuardMan CRM Router — /api/crm/*
// FASE CRM-0: Router independiente para endpoints comerciales

import { handleListLeads, handleCreateLead, handleGetLead, handleUpdateLead, handleLeadCapture, handleListInteractions, handleCreateInteraction } from './leads';
import { handleListClients, handleGetClient, handleCreateClient, handleUpdateClient } from './clients';
import { handleListProposals, handleCreateProposal, handleListAllProposals } from './proposals';
import { handlePipeline } from './pipeline';
import { handleCRMDashboard } from './dashboard';
import { handleListTasks, handleCreateTask, handleUpdateTask } from './tasks';
import { handleGetVisitByLead, handleCreateVisit, handleUploadVisitPhoto } from './visits';

export const crmRoutes = [
  {
    pattern: /^\/api\/crm\/.+/,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

      // DASHBOARD
      if (path === '/api/crm/dashboard' && method === 'GET') return await handleCRMDashboard(env);

      // LEADS
      if (path === '/api/crm/leads/capture' && method === 'POST') return await handleLeadCapture(request, env);
      if (path === '/api/crm/leads' && method === 'GET') return await handleListLeads(url, env);
      if (path === '/api/crm/leads' && method === 'POST') return await handleCreateLead(request, env);

      const leadIdMatch = path.match(/^\/api\/crm\/leads\/(\d+)$/);
      if (leadIdMatch && method === 'GET') return await handleGetLead(parseInt(leadIdMatch[1]), env);
      if (leadIdMatch && method === 'PUT') return await handleUpdateLead(parseInt(leadIdMatch[1]), request, env);

      // INTERACTIONS
      const interactMatch = path.match(/^\/api\/crm\/leads\/(\d+)\/interactions$/);
      if (interactMatch && method === 'GET') return await handleListInteractions(parseInt(interactMatch[1]), env);
      if (interactMatch && method === 'POST') return await handleCreateInteraction(parseInt(interactMatch[1]), request, env);

      // PROPOSALS
      const proposalMatch = path.match(/^\/api\/crm\/leads\/(\d+)\/proposals$/);
      if (proposalMatch && method === 'GET') return await handleListProposals(parseInt(proposalMatch[1]), env);
      if (proposalMatch && method === 'POST') return await handleCreateProposal(parseInt(proposalMatch[1]), request, env);
      if (path === '/api/crm/proposals' && method === 'GET') return await handleListAllProposals(url, env);

      // CLIENTS
      if (path === '/api/crm/clients' && method === 'GET') return await handleListClients(url, env);
      if (path === '/api/crm/clients' && method === 'POST') return await handleCreateClient(request, env);

      const clientIdMatch = path.match(/^\/api\/crm\/clients\/(\d+)$/);
      if (clientIdMatch && method === 'GET') return await handleGetClient(parseInt(clientIdMatch[1]), env);
      if (clientIdMatch && method === 'PUT') return await handleUpdateClient(parseInt(clientIdMatch[1]), request, env);

      // PIPELINE
      if (path === '/api/crm/pipeline' && method === 'GET') return await handlePipeline(env);

      // TASKS
      if (path === '/api/crm/tasks' && method === 'GET') return await handleListTasks(url, env);
      if (path === '/api/crm/tasks' && method === 'POST') return await handleCreateTask(request, env);
      const taskIdMatch = path.match(/^\/api\/crm\/tasks\/(\d+)$/);
      if (taskIdMatch && method === 'PUT') return await handleUpdateTask(parseInt(taskIdMatch[1]), request, env);

      // VISITS
      const visitLeadMatch = path.match(/^\/api\/crm\/visits\/(\d+)$/);
      if (visitLeadMatch && method === 'GET') return await handleGetVisitByLead(parseInt(visitLeadMatch[1]), env);
      if (path === '/api/crm/visits' && method === 'POST') return await handleCreateVisit(request, env);
      const visitPhotoMatch = path.match(/^\/api\/crm\/visits\/(\d+)\/photos$/);
      if (visitPhotoMatch && method === 'POST') return await handleUploadVisitPhoto(parseInt(visitPhotoMatch[1]), request, env);

      return null;
    },
  },
];
