// GuardMan Admin — Monitor Routes (Enhanced v5.2)
// Provides system overview: D1, R2, KV, AI Search, Workflows, Serper stats
export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export const monitorRoutes = [
  {
    pattern: /^\/api\/monitor\/overview$/,
    methods: ['GET'],
    handler: async (request: Request, env: any) => {
      try {
        const [systemStatus, workflows, serperDashboard, seoData, storageStats] = await Promise.all([
          getSystemStatus(env),
          getWorkflowStatus(env),
          getSerperStats(env),
          getSEOStats(env),
          getStorageStats(env),
        ]);

        return Response.json({
          ok: true,
          data: {
            system: systemStatus,
            workflows,
            serper: serperDashboard,
            seo: seoData,
            storage: storageStats,
            alerts: buildAlerts(serperDashboard, systemStatus, storageStats),
          },
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
  // POST /api/monitor/alerts/test — Create a test alert (insert into workflow_logs)
  {
    pattern: /^\/api\/monitor\/alerts\/test$/,
    methods: ['POST'],
    handler: async (request: Request, env: any) => {
      try {
        const body = await request.json() as any;
        const message = body?.message || 'Test alert from Monitor';
        await env.DB.prepare(
          'INSERT INTO workflow_logs (workflow_type, instance_id, event_type, data_json) VALUES (?, ?, ?, ?)'
        ).bind('monitor', 'test-alert', 'alert', JSON.stringify({ message, triggered_by: 'manual' })).run();

        return Response.json({ ok: true, data: { message: 'Test alert created', text: message } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
];

async function getSystemStatus(env: any) {
  try {
    const id = env.ORCHESTRATOR.idFromName('default');
    const stub = env.ORCHESTRATOR.get(id);
    const messages = await stub.getMessages();
    return {
      status: 'online',
      orchestrator: 'active',
      messageCount: messages.length,
      ai_search: !!env.AI_SEARCH,
      ai_search_available: !!env.AI_SEARCH,
    };
  } catch {
    return { status: 'degraded', orchestrator: 'error', ai_search_available: !!env.AI_SEARCH };
  }
}

async function getWorkflowStatus(env: any) {
  try {
    const [serper, bulk, publish] = await Promise.all([
      env.SERPER_SCAN_WORKFLOW ? env.SERPER_SCAN_WORKFLOW.list({ limit: 10 }) : Promise.resolve([]),
      env.BULK_GENERATE_WORKFLOW ? env.BULK_GENERATE_WORKFLOW.list({ limit: 10 }) : Promise.resolve([]),
      env.PUBLISH_WORKFLOW ? env.PUBLISH_WORKFLOW.list({ limit: 10 }) : Promise.resolve([]),
    ]);
    return {
      serper_scan: (serper as any[]).map((w: any) => ({ id: w.id, status: w.status })),
      bulk_generate: (bulk as any[]).map((w: any) => ({ id: w.id, status: w.status })),
      publish: (publish as any[]).map((w: any) => ({ id: w.id, status: w.status })),
    };
  } catch {
    return { serper_scan: [], bulk_generate: [], publish: [] };
  }
}

async function getSerperStats(env: any) {
  try {
    const [queryStats, resultStats, guardmanCount, topCompetitors] = await Promise.all([
      env.DB.prepare('SELECT COUNT(*) as total, SUM(CASE WHEN status=\'completed\' THEN 1 ELSE 0 END) as completed, SUM(CASE WHEN status=\'failed\' THEN 1 ELSE 0 END) as failed, SUM(credits_used) as total_credits FROM serper_queries').first(),
      env.DB.prepare('SELECT result_type, COUNT(*) as cnt FROM serper_results GROUP BY result_type').all(),
      env.DB.prepare('SELECT COUNT(*) as cnt FROM serper_results WHERE site_type = \'own\'').first(),
      env.DB.prepare('SELECT domain, COUNT(*) as appearances FROM serper_results WHERE site_type IN (\'direct_competitor\', \'indirect_competitor\') GROUP BY domain ORDER BY appearances DESC LIMIT 10').all(),
    ]);
    return {
      queries: queryStats,
      results_by_type: resultStats.results,
      guardman_positions: guardmanCount?.cnt || 0,
      top_competitors: topCompetitors.results,
    };
  } catch {
    return { queries: null, results_by_type: [], guardman_positions: 0, top_competitors: [] };
  }
}

async function getSEOStats(env: any) {
  try {
    const [kwCnt, compCnt] = await Promise.all([
      env.DB.prepare('SELECT COUNT(*) as c FROM keywords').first(),
      env.DB.prepare('SELECT COUNT(DISTINCT domain) as c FROM serper_results WHERE site_type IN (\'direct_competitor\', \'indirect_competitor\')').first(),
    ]);
    return { keywords: kwCnt?.c || 0, competitors: compCnt?.c || 0 };
  } catch {
    return { keywords: 0, competitors: 0 };
  }
}

/**
 * NEW: Storage stats — D1 size, R2 usage, KV cache stats
 */
async function getStorageStats(env: any) {
  const stats: any = {};

  // D1 Database size — PRAGMA is restricted in D1 HTTP, so we estimate from known tables
  try {
    const tableInfo = await env.DB.prepare(`
      SELECT
        (SELECT COUNT(*) FROM content_versions) as content_versions,
        (SELECT COUNT(*) FROM serper_queries) as serper_queries,
        (SELECT COUNT(*) FROM serper_results) as serper_results,
        (SELECT COUNT(*) FROM combo_content) as combo_content,
        (SELECT COUNT(*) FROM services) as services,
        (SELECT COUNT(*) FROM locations) as locations,
        (SELECT COUNT(*) FROM keywords) as keywords,
        (SELECT COUNT(*) FROM images) as images
    `).first();
    const totalRows = Object.values(tableInfo || {}).reduce((sum: number, v: any) => sum + (Number(v) || 0), 0);
    // Rough estimate: ~1KB per row average, D1 overhead
    const estimatedMB = (totalRows * 0.001).toFixed(2);
    stats.d1 = {
      estimated_mb: estimatedMB,
      total_rows: totalRows,
      tables: tableInfo,
    };
  } catch {
    stats.d1 = { estimated_mb: '?', total_rows: 0, tables: {} };
  }

  // R2 Images
  try {
    const listed = await env.IMAGES.list({ limit: 1000 });
    let totalSize = 0;
    let count = listed.objects.length;
    for (const obj of listed.objects) {
      totalSize += obj.size;
    }
    // If truncated, estimate total
    if (listed.truncated) {
      count = count + 500; // Estimate
    }
    stats.r2 = {
      image_count: count,
      total_size_bytes: totalSize,
      total_size_mb: (totalSize / (1024 * 1024)).toFixed(2),
      truncated: listed.truncated,
    };
  } catch {
    stats.r2 = { image_count: 0, total_size_bytes: 0, total_size_mb: '0', truncated: false };
  }

  // KV Cache stats
  try {
    const contentKeys = await env.CACHE.list({ prefix: 'content:' });
    const serperKeys = await env.CACHE.list({ prefix: 'serper:' });
    const previewKeys = await env.CACHE.list({ prefix: 'preview-' });
    stats.kv = {
      content_cache_count: contentKeys.keys.length,
      serper_cache_count: serperKeys.keys.length,
      preview_cache_count: previewKeys.keys.length,
      total_cached: contentKeys.keys.length + serperKeys.keys.length + previewKeys.keys.length,
      list_complete: contentKeys.list_complete && serperKeys.list_complete && previewKeys.list_complete,
    };
  } catch {
    stats.kv = { content_cache_count: 0, serper_cache_count: 0, preview_cache_count: 0, total_cached: 0, list_complete: true };
  }

  // AI Search status
  stats.ai_search = {
    available: !!env.AI_SEARCH,
    binding: env.AI_SEARCH ? 'guardman' : null,
  };

  return stats;
}

function buildAlerts(serper: any, system: any, storage: any) {
  const alerts: { type: string; message: string }[] = [];
  if (serper?.queries?.failed > 0) {
    alerts.push({ type: 'warning', message: `${serper.queries.failed} queries Serper fallidas` });
  }
  if (serper?.queries?.total_credits > 4000) {
    alerts.push({ type: 'warning', message: `Credits Serper altos: ${serper.queries.total_credits}` });
  }
  if (system?.status === 'degraded') {
    alerts.push({ type: 'error', message: 'Sistema degradado — Orchestrator no responde' });
  }
  if (storage?.d1?.size_mb && parseFloat(storage.d1.size_mb) > 100) {
    alerts.push({ type: 'warning', message: `D1 database size: ${storage.d1.size_mb} MB` });
  }
  if (!storage?.ai_search?.available) {
    alerts.push({ type: 'info', message: 'AI Search no disponible en este entorno' });
  }
  return alerts;
}
