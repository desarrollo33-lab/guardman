// GuardMan Admin — Workflow Routes
// Handles all workflow trigger + status endpoints
import { CORS_HEADERS } from '../../types';

const cors = CORS_HEADERS;

export const workflowsRoutes = [
  {
    pattern: /^\/api\/workflows\/.+/,
    methods: ['GET', 'POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

      // === SEO INTEL WORKFLOW ===

      // POST /api/workflows/seo-intel/trigger
      if (path === '/api/workflows/seo-intel/trigger' && method === 'POST') {
        try {
          if (!env.SEO_INTEL_WORKFLOW) {
            return Response.json({ ok: false, error: 'SEO Intel workflow not configured' }, { status: 503, headers: cors });
          }
          const instance = await env.SEO_INTEL_WORKFLOW.create({
            id: `seo-intel-${Date.now()}`,
            params: { trigger: 'manual' },
          });
          return Response.json({ ok: true, data: { workflow_id: instance.id, message: 'SEO Intel workflow started' } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // GET /api/intel/snapshot/latest
      if (path === '/api/intel/snapshot/latest' && method === 'GET') {
        try {
          const snapshot = await env.DB.prepare(
            'SELECT * FROM intel_snapshots ORDER BY created_at DESC LIMIT 1'
          ).first();
          if (!snapshot) return Response.json({ ok: false, error: 'No snapshots yet' }, { status: 404, headers: cors });
          return Response.json({ ok: true, data: snapshot }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // GET /api/intel/proposals
      if (path === '/api/intel/proposals' && method === 'GET') {
        try {
          const snapshot = await env.DB.prepare(
            'SELECT content_proposals FROM intel_snapshots ORDER BY created_at DESC LIMIT 1'
          ).first();
          if (!snapshot) return Response.json({ ok: false, error: 'No snapshots yet' }, { status: 404, headers: cors });
          return Response.json({ ok: true, data: JSON.parse(snapshot.content_proposals as string) }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // GET /api/intel/snapshots — list all snapshots
      if (path === '/api/intel/snapshots' && method === 'GET') {
        try {
          const { results } = await env.DB.prepare(
            'SELECT id, trigger_type, created_at, summary FROM intel_snapshots ORDER BY created_at DESC LIMIT 20'
          ).all();
          return Response.json({ ok: true, data: results }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // === CONTENT PIPELINE WORKFLOW ===

      // POST /api/workflows/content-pipeline/trigger
      if (path === '/api/workflows/content-pipeline/trigger' && method === 'POST') {
        try {
          if (!env.CONTENT_PIPELINE_WORKFLOW) {
            return Response.json({ ok: false, error: 'Content Pipeline workflow not configured' }, { status: 503, headers: cors });
          }
          const body = await request.json().catch(() => ({})) as any;
          const combos = body.combos || [];
          const mode = body.mode || 'manual';
          const autoApproveThreshold = body.auto_approve_threshold || 90;

          if (!combos.length) {
            return Response.json({ ok: false, error: 'No combos specified' }, { status: 400, headers: cors });
          }

          const instance = await env.CONTENT_PIPELINE_WORKFLOW.create({
            id: `content-${Date.now()}`,
            params: { combos, mode, autoApproveThreshold },
          });
          return Response.json({ ok: true, data: { workflow_id: instance.id, message: `Content pipeline started for ${combos.length} combos` } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // POST /api/workflows/content-pipeline/:id/event
      const pipeEventMatch = path.match(/^\/api\/workflows\/content-pipeline\/([\w-]+)\/event$/);
      if (pipeEventMatch && method === 'POST') {
        try {
          if (!env.CONTENT_PIPELINE_WORKFLOW) {
            return Response.json({ ok: false, error: 'Content Pipeline workflow not configured' }, { status: 503, headers: cors });
          }
          const instanceId = pipeEventMatch[1];
          const body = await request.json();
          const instance = await env.CONTENT_PIPELINE_WORKFLOW.get(instanceId);
          await instance.sendEvent({ type: body.type || 'content-approved', payload: body.payload || {} });
          return Response.json({ ok: true, data: { event_sent: body.type } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // === SITE DEPLOY WORKFLOW ===

      // POST /api/workflows/site-deploy/trigger
      if (path === '/api/workflows/site-deploy/trigger' && method === 'POST') {
        try {
          if (!env.SITE_DEPLOY_WORKFLOW) {
            return Response.json({ ok: false, error: 'Site Deploy workflow not configured' }, { status: 503, headers: cors });
          }
          const body = await request.json().catch(() => ({})) as any;
          const instance = await env.SITE_DEPLOY_WORKFLOW.create({
            id: `deploy-${Date.now()}`,
            params: { mode: body.mode || 'manual', maxItems: body.max_items || 10 },
          });
          return Response.json({ ok: true, data: { workflow_id: instance.id, message: 'Site deploy workflow started' } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // === SERPER SCAN WORKFLOW (existing, enhanced) ===

      if (path === '/api/workflows/serper-scan' && method === 'POST') {
        try {
          if (!env.SERPER_SCAN_WORKFLOW) {
            return Response.json({ ok: false, error: 'Serper scan workflow not configured' }, { status: 503, headers: cors });
          }
          const body = await request.json().catch(() => ({})) as any;
          const instance = await env.SERPER_SCAN_WORKFLOW.create({
            id: `scan-${Date.now()}`,
            params: { trigger: 'manual', serviceSlugs: body.service_slugs, locationSlugs: body.location_slugs },
          });
          return Response.json({ ok: true, data: { workflow_id: instance.id, message: 'Serper scan workflow started' } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // === BULK GENERATE WORKFLOW (existing) ===

      // POST /api/workflows/bulk-generate - Trigger bulk generation workflow
      if (path === '/api/workflows/bulk-generate' && method === 'POST') {
        try {
          if (!env.BULK_GENERATE_WORKFLOW) {
            return Response.json({ ok: false, error: 'Bulk generate workflow not configured' }, { status: 503, headers: cors });
          }
          const body = await request.json().catch(() => ({})) as any;
          const instance = await env.BULK_GENERATE_WORKFLOW.create({
            id: `bulk-${Date.now()}`,
            params: {
              entityTypes: body.entity_types,
              scoreThreshold: body.score_threshold || 75,
              autoApprove: body.auto_approve !== false,
            },
          });
          return Response.json({ ok: true, data: { workflow_id: instance.id, message: 'Bulk generation workflow started' } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // === PUBLISH PIPELINE (existing) ===

      // POST /api/workflows/publish - Trigger publish pipeline
      if (path === '/api/workflows/publish' && method === 'POST') {
        try {
          if (!env.PUBLISH_WORKFLOW) {
            return Response.json({ ok: false, error: 'Publish workflow not configured' }, { status: 503, headers: cors });
          }
          const instance = await env.PUBLISH_WORKFLOW.create({
            id: `publish-${Date.now()}`,
            params: { mode: 'manual', maxItems: 10 },
          });
          return Response.json({ ok: true, data: { workflow_id: instance.id, message: 'Publish pipeline started' } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // === UNIVERSAL STATUS ===

      // GET /api/workflows/status - Status of all workflows
      if (path === '/api/workflows/status' && method === 'GET') {
        try {
          const fmt = async (binding: any, name: string) => {
            if (!binding) return { binding: name, status: 'not_configured' };
            try {
              const list = await binding.list({ limit: 5 });
              return (Array.isArray(list) ? list : []).map((w: any) => ({ id: w.id, status: w.status, created: w.created, updated: w.updated }));
            } catch {
              return { binding: name, status: 'list_unavailable' };
            }
          };
          return Response.json({ ok: true, data: {
            serper_scan: await fmt(env.SERPER_SCAN_WORKFLOW, 'serper-scan'),
            bulk_generate: await fmt(env.BULK_GENERATE_WORKFLOW, 'bulk-generate'),
            publish: await fmt(env.PUBLISH_WORKFLOW, 'publish'),
            seo_intel: await fmt(env.SEO_INTEL_WORKFLOW, 'seo-intel'),
            content_pipeline: await fmt(env.CONTENT_PIPELINE_WORKFLOW, 'content-pipeline'),
            site_deploy: await fmt(env.SITE_DEPLOY_WORKFLOW, 'site-deploy'),
          }}, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // GET /api/workflows/:binding/:id/status — individual workflow status
      const statusMatch = path.match(/^\/api\/workflows\/([\w-]+)\/([\w-]+)\/status$/);
      if (statusMatch && method === 'GET') {
        try {
          const binding = getWorkflowBinding(env, statusMatch[1]);
          if (!binding) return Response.json({ ok: false, error: `Unknown workflow: ${statusMatch[1]}` }, { status: 404, headers: cors });
          const instance = await binding.get(statusMatch[2]);
          const status = await instance.status();
          return Response.json({ ok: true, data: status }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // GET /api/workflows/:binding/:id — get workflow instance info
      const instanceMatch = path.match(/^\/api\/workflows\/([\w-]+)\/([\w-]+)$/);
      if (instanceMatch && method === 'GET') {
        try {
          const binding = getWorkflowBinding(env, instanceMatch[1]);
          if (!binding) return Response.json({ ok: false, error: `Unknown workflow: ${instanceMatch[1]}` }, { status: 404, headers: cors });
          const instance = await binding.get(instanceMatch[2]);
          const status = await instance.status();
          return Response.json({ ok: true, data: status }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      return null;
    },
  },
];

function getWorkflowBinding(env: any, name: string): any | null {
  const map: Record<string, any> = {
    'seo-intel': env.SEO_INTEL_WORKFLOW,
    'content-pipeline': env.CONTENT_PIPELINE_WORKFLOW,
    'site-deploy': env.SITE_DEPLOY_WORKFLOW,
    'serper-scan': env.SERPER_SCAN_WORKFLOW,
    'bulk-generate': env.BULK_GENERATE_WORKFLOW,
    'publish': env.PUBLISH_WORKFLOW,
  };
  return map[name] || null;
}
