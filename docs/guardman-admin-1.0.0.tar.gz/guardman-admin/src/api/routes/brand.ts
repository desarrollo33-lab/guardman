// GuardMan Admin — Brand DNA Routes
// Single source of truth for brand identity data

import { cors } from '../index';

const VALID_CATEGORIES = ['company', 'stats', 'colors', 'voice', 'differentiators', 'exclusions', 'certifications', 'usps', 'social', 'hours'];

function parseBrandUrl(url: string) {
  const parts = new URL(url).pathname.replace(/\/$/, '').split('/');
  // /api/brand/stats → ['','api','brand','stats']
  // /api/brand/colors/accent → ['','api','brand','colors','accent']
  return { category: parts[3] || '', key: parts[4] || '' };
}

function parseValue(row: any): any {
  let val: any = row.value;
  if (row.type === 'json') { try { val = JSON.parse(row.value); } catch {} }
  else if (row.type === 'number') { val = Number(row.value); }
  else if (row.type === 'boolean') { val = row.value === 'true'; }
  return val;
}

export const brandRoutes: Array<{
  pattern: RegExp;
  methods: string[];
  handler: (request: Request, env: any, ctx: any, match: RegExpMatchArray) => Promise<Response | null>;
}> = [
  // ===== GET /api/brand — Get full brand DNA (structured) =====
  {
    pattern: /^\/api\/brand\/?$/,
    methods: ['GET'],
    handler: async (req, env) => {
      const { results } = await env.DB.prepare(
        'SELECT category, key, value, type, description, updated_at FROM brand_dna ORDER BY category, key'
      ).all();

      const brand: Record<string, Record<string, any>> = {};
      for (const row of results as any[]) {
        if (!brand[row.category]) brand[row.category] = {};
        brand[row.category][row.key] = parseValue(row);
      }

      return Response.json({ ok: true, data: brand }, { headers: cors });
    },
  },

  // ===== GET /api/brand/map — Flat map for sync (before /:category) =====
  {
    pattern: /^\/api\/brand\/map$/,
    methods: ['GET'],
    handler: async (req, env) => {
      const { results } = await env.DB.prepare(
        'SELECT category, key, value, type FROM brand_dna ORDER BY category, key'
      ).all();

      const map: Record<string, any> = {};
      for (const row of results as any[]) {
        map[`${row.category}.${row.key}`] = parseValue(row);
      }

      return Response.json({ ok: true, data: map }, { headers: cors });
    },
  },

  // ===== PUT /api/brand — Upsert brand values =====
  {
    pattern: /^\/api\/brand\/?$/,
    methods: ['PUT'],
    handler: async (req, env) => {
      const body = await req.json() as { items: Array<{ category: string; key: string; value: string; type?: string; description?: string }> };

      if (!body.items?.length) {
        return Response.json({ ok: false, error: 'items array required' }, { status: 400, headers: cors });
      }

      const stmt = env.DB.prepare(
        `INSERT INTO brand_dna (category, key, value, type, description, updated_at) VALUES (?, ?, ?, ?, ?, datetime('now'))
         ON CONFLICT(category, key) DO UPDATE SET value = excluded.value, type = excluded.type, description = excluded.description, updated_at = datetime('now')`
      );

      const batch = body.items.map(item =>
        stmt.bind(item.category, item.key, String(item.value), item.type || 'string', item.description || '')
      );

      await env.DB.batch(batch);

      return Response.json({ ok: true, updated: body.items.length }, { headers: cors });
    },
  },

  // ===== GET /api/brand/:category =====
  {
    pattern: /^\/api\/brand\/[a-z_]+$/,
    methods: ['GET'],
    handler: async (req, env) => {
      const { category } = parseBrandUrl(req.url);
      const { results } = await env.DB.prepare(
        'SELECT key, value, type, description FROM brand_dna WHERE category = ? ORDER BY key'
      ).bind(category).all();

      const data: Record<string, any> = {};
      for (const row of results as any[]) {
        data[row.key] = { value: parseValue(row), type: row.type, description: row.description };
      }

      return Response.json({ ok: true, category, data }, { headers: cors });
    },
  },

  // ===== PUT /api/brand/:category =====
  {
    pattern: /^\/api\/brand\/[a-z_]+$/,
    methods: ['PUT'],
    handler: async (req, env) => {
      const { category } = parseBrandUrl(req.url);
      if (!VALID_CATEGORIES.includes(category)) {
        return Response.json({ ok: false, error: 'Invalid category: ' + category }, { status: 400, headers: cors });
      }

      const body = await req.json() as Record<string, { value: string; type?: string; description?: string }>;

      const stmt = env.DB.prepare(
        `INSERT INTO brand_dna (category, key, value, type, description, updated_at) VALUES (?, ?, ?, ?, ?, datetime('now'))
         ON CONFLICT(category, key) DO UPDATE SET value = excluded.value, type = excluded.type, description = excluded.description, updated_at = datetime('now')`
      );

      const batch = Object.entries(body).map(([key, data]) =>
        stmt.bind(category, key, String(data.value), data.type || 'string', data.description || '')
      );

      await env.DB.batch(batch);

      return Response.json({ ok: true, category, updated: batch.length }, { headers: cors });
    },
  },

  // ===== DELETE /api/brand/:category/:key =====
  {
    pattern: /^\/api\/brand\/[a-z_]+\/[a-z0-9_-]+$/,
    methods: ['DELETE'],
    handler: async (req, env) => {
      const { category, key } = parseBrandUrl(req.url);

      if (!category || !key) {
        return Response.json({ ok: false, error: 'Missing category or key' }, { status: 400, headers: cors });
      }

      await env.DB.prepare('DELETE FROM brand_dna WHERE category = ? AND key = ?')
        .bind(category, key).run();

      return Response.json({ ok: true, deleted: `${category}.${key}` }, { headers: cors });
    },
  },
];
