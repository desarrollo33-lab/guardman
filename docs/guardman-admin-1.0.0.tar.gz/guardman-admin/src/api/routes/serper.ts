// GuardMan Admin — Serper Routes (extracted from api.ts)
// All /api/serper/* endpoints
import { CORS_HEADERS } from '../../types';
import { cachedFetch, invalidateCache, CACHE_TTL } from '../../services/cache';
import {
  generateQueryPlan, generateAllPlans, getAllServiceSlugs, getAllLocationSlugs,
  executeQueryPlan, classifyAllResults, getClassificationStats, reprocessExistingData
} from '../../serper/index';

const cors = CORS_HEADERS;

export const serperRoutes = [
  {
    pattern: /^\/api\/serper\/.+/,
    methods: ['GET', 'POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

    if (path === '/api/serper/dashboard' && method === 'GET') {
      try {
        const serperData = await cachedFetch(env.CACHE, 'serper:dashboard', { ttl: CACHE_TTL.SERPER_DASHBOARD }, async () => {
        const stats = await getClassificationStats(env);
        const [queryStats, resultResults, topCompetitors, guardmanPositions, recentQueries, qualityByTier, snapshotDatesResult] = await Promise.all([
          env.DB.prepare('SELECT COUNT(*) as total, SUM(CASE WHEN status=\'completed\' THEN 1 ELSE 0 END) as completed, SUM(CASE WHEN status=\'failed\' THEN 1 ELSE 0 END) as failed, SUM(credits_used) as total_credits FROM serper_queries').first(),
          env.DB.prepare('SELECT result_type, COUNT(*) as cnt FROM serper_results GROUP BY result_type').all(),
          env.DB.prepare('SELECT domain, COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos FROM serper_results WHERE site_type=\'direct_competitor\' GROUP BY domain ORDER BY appearances DESC LIMIT 30').all(),
          env.DB.prepare('SELECT sr.position, sq.query_text, sr.title, sr.link, sq.service_slug, sq.location_slug FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.site_type=\'own\' ORDER BY sr.position ASC LIMIT 30').all(),
          env.DB.prepare('SELECT sq.query_text, sq.endpoint, sq.status, sq.credits_used, sq.executed_at FROM serper_queries sq ORDER BY sq.id DESC LIMIT 10').all(),
          // Quality tiers from extra_json (was showing 0/0/0 before - fixed)
          env.DB.prepare("SELECT JSON_EXTRACT(extra_json, '$.quality_tier') as tier, COUNT(*) as cnt FROM serper_results WHERE result_type IN ('organic','place') AND extra_json IS NOT NULL GROUP BY tier").all(),
          // Latest 2 snapshot dates for alert calculation
          env.DB.prepare("SELECT snapshot_date FROM position_snapshots GROUP BY snapshot_date ORDER BY snapshot_date DESC LIMIT 2").all(),
        ]);

        // Parse quality tiers correctly (was always 0 before this fix)
        const qualityTiers: Record<string, number> = { gold: 0, silver: 0, bronze: 0, spam: 0 };
        for (const row of (qualityByTier.results as any[])) {
          if (row.tier && qualityTiers.hasOwnProperty(row.tier)) {
            qualityTiers[row.tier] = (qualityTiers[row.tier] || 0) + row.cnt;
          }
        }

        // Calculate position-change alerts from latest 2 snapshots
        const dates = (snapshotDatesResult.results as any[]).map((r: any) => r.snapshot_date);
        let alerts = { significant_changes: 0, improved: 0, declined: 0, new_appearances: 0, lost_positions: 0 };
        if (dates.length >= 2) {
          const [latest, previous] = dates;
          const [latestRows, prevRows] = await Promise.all([
            env.DB.prepare('SELECT service_slug, location_slug, query_text, position FROM position_snapshots WHERE snapshot_date = ? AND site_type=\'own\'').bind(latest).all(),
            env.DB.prepare('SELECT service_slug, location_slug, query_text, position FROM position_snapshots WHERE snapshot_date = ? AND site_type=\'own\'').bind(previous).all(),
          ]);
          const prevMap = new Map((prevRows.results as any[]).map((r: any) => [r.service_slug + '|' + r.location_slug + '|' + r.query_text, r.position]));
          for (const curr of (latestRows.results as any[])) {
            const key = curr.service_slug + '|' + curr.location_slug + '|' + curr.query_text;
            const prevPos = prevMap.get(key);
            if (prevPos === undefined) { alerts.new_appearances++; }
            else if (curr.position < prevPos) { alerts.improved++; }
            else if (curr.position > prevPos) { alerts.declined++; }
          }
          for (const [key, prevPos] of prevMap) {
            if (!(latestRows.results as any[]).some((r: any) => r.service_slug + '|' + r.location_slug + '|' + r.query_text === key)) {
              alerts.lost_positions++;
            }
          }
          alerts.significant_changes = alerts.improved + alerts.declined + alerts.new_appearances;
        }

        // Endpoint breakdown
        const endpointStats = await env.DB.prepare('SELECT endpoint, status, COUNT(*) as cnt, SUM(credits_used) as credits FROM serper_queries GROUP BY endpoint, status').all();

        return {
          queries: queryStats,
          results_by_type: resultResults.results,
          classification_stats: { ...stats, by_quality: qualityTiers },
          top_competitors: topCompetitors.results,
          guardman_positions: guardmanPositions.results,
          recent_queries: recentQueries.results,
          endpoint_stats: endpointStats.results,
          quality_tiers: qualityTiers,
          alerts: alerts,
          snapshot_dates: dates,
        };
        }); // end cachedFetch

        return Response.json({ ok: true, data: serperData }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/serper/plan - Generate strategic query plan (dry-run)
    if (path === '/api/serper/plan' && method === 'POST') {
      const body = await request.json() as any;
      const { service_slugs, location_slugs } = body;
      try {
        const svcSlugs = service_slugs || getAllServiceSlugs();
        const locSlugs = location_slugs || getAllLocationSlugs();
        const plans = generateAllPlans(svcSlugs, locSlugs);
        const totalQueries = plans.reduce((sum, p) => sum + p.queries.length, 0);
        const totalCredits = plans.reduce((sum, p) => sum + p.total_credits, 0);
        return Response.json({ ok: true, data: { plans, total_queries: totalQueries, total_credits: totalCredits, total_combos: plans.length } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/serper/execute - Execute queries for a specific combo
    if (path === '/api/serper/execute' && method === 'POST') {
      const body = await request.json() as any;
      const { service_slug, location_slug } = body;
      if (!service_slug || !location_slug) {
        return Response.json({ ok: false, error: 'service_slug and location_slug required' }, { status: 400, headers: cors });
      }
      try {
        const plan = generateQueryPlan(service_slug, location_slug);
        const results = await executeQueryPlan(
          { DB: env.DB },
          plan.queries,
          (step, idx, total) => { console.log('[Serper] ' + (idx+1) + '/' + total + ': ' + step); }
        );
        const classification = await classifyAllResults({ DB: env.DB });
        // Invalidate serper caches after execution
        await invalidateCache(env.CACHE, 'serper:');
        await invalidateCache(env.CACHE, 'seo:');
        const totalCredits = results.reduce((s, r) => s + r.credits_used, 0);
        const totalResults = results.reduce((s, r) => s + r.results_count.organic + r.results_count.places + r.results_count.paa + r.results_count.knowledge_graph + r.results_count.related_searches, 0);
        return Response.json({ ok: true, data: { plan, execution_results: results, classification_stats: classification, total_credits: totalCredits, total_results_saved: totalResults } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/serper/execute-places - Execute only places queries for combos where places failed
    if (path === '/api/serper/execute-places' && method === 'POST') {
      const body = await request.json() as any;
      const { service_slug, location_slug, all } = body;
      try {
        // Get failed places queries (response_json is null or < 100 chars)
        let queries;
        if (service_slug && location_slug) {
          queries = await env.DB.prepare(
            'SELECT id, service_slug, location_slug, query_text, endpoint FROM serper_queries WHERE endpoint = ? AND service_slug = ? AND location_slug = ? AND (response_json IS NULL OR LENGTH(response_json) < 100)'
          ).bind('places', service_slug, location_slug).all();
        } else if (all) {
          queries = await env.DB.prepare(
            'SELECT id, service_slug, location_slug, query_text, endpoint FROM serper_queries WHERE endpoint = ? AND (response_json IS NULL OR LENGTH(response_json) < 100)'
          ).bind('places').all();
        } else {
          return Response.json({ ok: false, error: 'Provide service_slug+location_slug or all=true' }, { status: 400, headers: cors });
        }

        const failedQueries = (queries.results as any[]).map(q => ({
          query_text: q.query_text,
          intent: 'local' as const,
          priority: 'high' as const,
          endpoint: 'places' as const,
          service_slug: q.service_slug,
          location_slug: q.location_slug,
          rationale: 'Re-executing failed places query',
          expected_insights: ['local pack', 'map rankings'],
        }));

        if (failedQueries.length === 0) {
          return Response.json({ ok: true, data: { message: 'No failed places queries found', executed: 0 } }, { headers: cors });
        }

        // Execute in batches of 5 to avoid timeout
        const BATCH_SIZE = 5;
        let totalResults = 0;
        let totalCredits = 0;
        let executed = 0;
        let batchSize = Math.min(failedQueries.length, BATCH_SIZE);
        const batch = failedQueries.slice(0, batchSize);

        const results = await executeQueryPlan(
          { DB: env.DB, SERPER_API_KEY: env.SERPER_API_KEY },
          batch,
          (step, idx, total) => { console.log('[Serper Places] ' + (idx+1) + '/' + total + ': ' + step); }
        );

        for (const r of results) {
          totalCredits += r.credits_used;
          totalResults += r.results_count.places || 0;
          if (r.status === 'completed') executed++;
        }

        return Response.json({
          ok: true,
          data: {
            total_failed: failedQueries.length,
            executed: executed,
            total_credits: totalCredits,
            total_results: totalResults,
            remaining: failedQueries.length - batchSize,
            results: results
          }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/serper/classify - Re-classify all existing results
    if (path === '/api/serper/classify' && method === 'POST') {
      try {
        const stats = await classifyAllResults({ DB: env.DB });
        await invalidateCache(env.CACHE, 'serper:');
        return Response.json({ ok: true, data: stats }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/serper/reprocess - Re-process stored response_json, with optional offset/limit
    if (path === '/api/serper/reprocess' && method === 'POST') {
      try {
        const body = await request.json().catch(() => ({})) as any;
        const offset = parseInt(body?.offset || '0');
        const limit = parseInt(body?.limit || '50');
        const classify = body?.classify !== false; // default true

        if (offset === 0 && limit >= 10000) {
          // Full reprocess (old behavior)
          const stats = await reprocessExistingData({ DB: env.DB });
          await invalidateCache(env.CACHE, 'serper:');
          return Response.json({ ok: true, data: stats }, { headers: cors });
        }

        // Batch reprocess - process only one batch
        const { results } = await env.DB.prepare(
          'SELECT id, service_slug, location_slug, query_text, endpoint, response_json, credits_used FROM serper_queries WHERE status = ? AND response_json IS NOT NULL AND LENGTH(response_json) > 100 ORDER BY id LIMIT ? OFFSET ?'
        ).bind('completed', limit, offset).all();

        let processed = 0;
        let resultsSaved = 0;
        const { storeQueryAndResults: storeQA, storePlacesResults: storePR } = await import('../../serper/layer2-executor');

        for (const row of results as any[]) {
          try {
            const response = JSON.parse(row.response_json);
            const query = { query_text: row.query_text, intent: 'commercial' as const, priority: 'medium' as const, endpoint: row.endpoint, service_slug: row.service_slug, location_slug: row.location_slug, rationale: 'Reprocessed batch', expected_insights: [] };
            if (row.endpoint === 'search') {
              const r = await storeQA({ DB: env.DB }, query, response, row.credits_used || 1);
              resultsSaved += r.resultsSaved;
            } else if (row.endpoint === 'places') {
              const places = response.places || response.organic || [];
              const r = await storePR({ DB: env.DB }, query, places, row.credits_used || 1);
              resultsSaved += r.resultsSaved;
            }
            processed++;
          } catch {}
        }

        let classificationStats = null;
        if (classify && offset + limit >= 1400) {
          classificationStats = await classifyAllResults({ DB: env.DB });
        }

        return Response.json({ ok: true, data: { processed, resultsSaved, offset, limit, hasMore: results.length === limit, classification: classificationStats } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/results - Get classified results with filters
    if (path === '/api/serper/results' && method === 'GET') {
      const siteType = url.searchParams.get('site_type');
      const resultType = url.searchParams.get('result_type');
      const serviceSlug = url.searchParams.get('service');
      const locationSlug = url.searchParams.get('location');
      const limit = parseInt(url.searchParams.get('limit') || '200');
      try {
        let sql = 'SELECT sr.id, sr.query_id, sr.result_type, sr.position, sr.title, sr.link, sr.domain, sr.snippet, sr.site_type, sr.is_cl, sr.rating, sr.reviews_count, sr.address, sr.has_website, sq.service_slug, sq.location_slug, sq.query_text FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE 1=1';
        const params: any[] = [];
        if (siteType) { sql += ' AND sr.site_type = ?'; params.push(siteType); }
        if (resultType) { sql += ' AND sr.result_type = ?'; params.push(resultType); }
        if (serviceSlug) { sql += ' AND sq.service_slug = ?'; params.push(serviceSlug); }
        if (locationSlug) { sql += ' AND sq.location_slug = ?'; params.push(locationSlug); }
        sql += ' ORDER BY sr.position ASC LIMIT ?';
        params.push(limit);
        const { results } = await env.DB.prepare(sql).bind(...params).all();
        return Response.json({ ok: true, data: results, count: results.length }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/competitors - Get real competitor analysis
    if (path === '/api/serper/competitors' && method === 'GET') {
      try {
        const { results } = await env.DB.prepare('SELECT sr.domain, sr.site_type, COUNT(DISTINCT sq.service_slug) as services, COUNT(DISTINCT sq.location_slug) as locations, COUNT(*) as appearances, ROUND(AVG(sr.position),1) as avg_position, GROUP_CONCAT(DISTINCT sq.service_slug) as service_list FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.site_type IN (\'direct_competitor\', \'indirect_competitor\') GROUP BY sr.domain ORDER BY appearances DESC LIMIT 50').all();
        return Response.json({ ok: true, data: results }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/serper/snapshot - Save position snapshot for trend tracking
    if (path === '/api/serper/snapshot' && method === 'POST') {
      try {
        const snapshotDate = new Date().toISOString().split('T')[0];
        // Delete any existing snapshot for today first
        await env.DB.prepare('DELETE FROM position_snapshots WHERE snapshot_date = ?').bind(snapshotDate).run();
        // Insert current positions for GuardMan
        const { results } = await env.DB.prepare(
          'SELECT sq.service_slug, sq.location_slug, sq.query_text, sr.position, sr.domain, sr.site_type, sr.title FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.site_type = \'own\' ORDER BY sr.position ASC'
        ).all();
        let inserted = 0;
        const batch: any[] = [];
        for (const row of results as any[]) {
          batch.push(env.DB.prepare(
            'INSERT INTO position_snapshots (snapshot_date, service_slug, location_slug, domain, position, site_type, title, query_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
          ).bind(snapshotDate, row.service_slug, row.location_slug, row.domain, row.position, row.site_type, row.title, row.query_text));
        }
        // Also insert top 5 competitors per combo
        const topCompetitors = await env.DB.prepare(
          'SELECT sq.service_slug, sq.location_slug, sq.query_text, sr.position, sr.domain, sr.site_type, sr.title FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sr.site_type = \'direct_competitor\' AND sr.position <= 5 ORDER BY sq.service_slug, sq.location_slug, sr.position'
        ).all();
        for (const row of topCompetitors.results as any[]) {
          batch.push(env.DB.prepare(
            'INSERT INTO position_snapshots (snapshot_date, service_slug, location_slug, domain, position, site_type, title, query_text) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
          ).bind(snapshotDate, row.service_slug, row.location_slug, row.domain, row.position, row.site_type, row.title, row.query_text));
        }
        if (batch.length > 0) {
          await env.DB.batch(batch);
        }
        inserted = batch.length;
        await invalidateCache(env.CACHE, 'serper:');
        return Response.json({ ok: true, data: { date: snapshotDate, inserted, guardman_positions: results.length, top_competitors: topCompetitors.results.length } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/history - Get position snapshot history
    if (path === '/api/serper/history' && method === 'GET') {
      try {
        const serviceSlug = url.searchParams.get('service');
        const locationSlug = url.searchParams.get('location');
        let sql = 'SELECT snapshot_date, service_slug, location_slug, domain, position, site_type, title, query_text FROM position_snapshots WHERE 1=1';
        const params: any[] = [];
        if (serviceSlug) { sql += ' AND service_slug = ?'; params.push(serviceSlug); }
        if (locationSlug) { sql += ' AND location_slug = ?'; params.push(locationSlug); }
        sql += ' ORDER BY snapshot_date DESC, position ASC';
        const { results } = await env.DB.prepare(sql).bind(...params).all();
        const dates = await env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots ORDER BY snapshot_date DESC LIMIT 30').all();
        return Response.json({ ok: true, data: { snapshots: results, dates: dates.results } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/coverage - Service×Location coverage matrix
    if (path === '/api/serper/coverage' && method === 'GET') {
      try {
        const [services, locations, combos] = await Promise.all([
          env.DB.prepare('SELECT slug, name FROM services ORDER BY name').all(),
          env.DB.prepare('SELECT slug, name, zone FROM locations ORDER BY zone, name').all(),
          env.DB.prepare(`
            SELECT sq.service_slug, sq.location_slug,
              COUNT(DISTINCT sq.id) as query_count,
              SUM(sq.credits_used) as credits_used,
              COUNT(CASE WHEN sr.site_type = 'own' THEN 1 END) as own_positions,
              MIN(CASE WHEN sr.site_type = 'own' THEN sr.position END) as best_own_pos,
              COUNT(CASE WHEN sr.site_type = 'direct_competitor' THEN 1 END) as competitor_results,
              COUNT(DISTINCT CASE WHEN sr.site_type = 'direct_competitor' THEN sr.domain END) as competitor_domains,
              COUNT(CASE WHEN sr.result_type = 'organic' THEN 1 END) as organic_results,
              COUNT(CASE WHEN sr.result_type = 'place' THEN 1 END) as place_results
            FROM serper_queries sq
            LEFT JOIN serper_results sr ON sq.id = sr.query_id
            GROUP BY sq.service_slug, sq.location_slug
          `).all(),
        ]);
        return Response.json({ ok: true, data: { services: services.results, locations: locations.results, combos: combos.results } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/opportunities - SEO gaps where GuardMan could improve
    if (path === '/api/serper/opportunities' && method === 'GET') {
      try {
        // Find combos where GuardMan has no position or average position > 5
        const { results } = await env.DB.prepare(`
          SELECT sq.service_slug, sq.location_slug, sq.query_text, sq.endpoint,
            COUNT(DISTINCT sr.id) as total_results,
            COUNT(CASE WHEN sr.site_type = 'direct_competitor' THEN 1 END) as competitor_count,
            MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as guardman_pos,
            ROUND(AVG(CASE WHEN sr.site_type = 'direct_competitor' THEN CAST(JSON_EXTRACT(sr.extra_json, '$.relevance_score') AS REAL) ELSE NULL END), 1) as avg_comp_relevance
          FROM serper_queries sq
          LEFT JOIN serper_results sr ON sq.id = sr.query_id
          WHERE sq.status = 'completed'
          GROUP BY sq.id
          ORDER BY guardman_pos ASC, competitor_count DESC
        `).all();

        // Also get combo-level summary
        const comboSummary = await env.DB.prepare(`
          SELECT sq.service_slug, sq.location_slug,
            COUNT(DISTINCT sq.id) as total_queries,
            SUM(CASE WHEN sr.site_type = 'own' THEN 1 ELSE 0 END) as own_appearances,
            MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as best_position,
            COUNT(DISTINCT CASE WHEN sr.site_type = 'direct_competitor' THEN sr.domain END) as unique_competitors
          FROM serper_queries sq
          LEFT JOIN serper_results sr ON sq.id = sr.query_id
          WHERE sq.status = 'completed'
          GROUP BY sq.service_slug, sq.location_slug
          ORDER BY best_position ASC
        `).all();

        const weakSpots = (comboSummary.results as any[]).filter((r: any) => r.best_position > 5 || r.own_appearances === 0);
        const strongSpots = (comboSummary.results as any[]).filter((r: any) => r.best_position <= 3 && r.own_appearances > 0);
        const noPresence = (comboSummary.results as any[]).filter((r: any) => r.own_appearances === 0);

        return Response.json({ ok: true, data: {
          queries: results,
          combo_summary: comboSummary.results,
          weak_spots: weakSpots,
          strong_spots: strongSpots,
          no_presence: noPresence,
          stats: {
            total_combos: (comboSummary.results as any[]).length,
            with_presence: (comboSummary.results as any[]).filter((r: any) => r.own_appearances > 0).length,
            weak_presence: weakSpots.length,
            no_presence: noPresence.length
          }
        }}, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/diff - Position changes between 2 snapshots
    if (path === '/api/serper/diff' && method === 'GET') {
      try {
        const fromDate = url.searchParams.get('from');
        const toDate = url.searchParams.get('to');
        if (!fromDate || !toDate) {
          return Response.json({ ok: false, error: 'Provide from and to dates as query params' }, { status: 400, headers: cors });
        }

        const [fromSnap, toSnap, fromComp, toComp] = await Promise.all([
          env.DB.prepare('SELECT service_slug, location_slug, query_text, position, domain, title FROM position_snapshots WHERE snapshot_date = ? AND site_type = \'own\' ORDER BY service_slug, location_slug').bind(fromDate).all(),
          env.DB.prepare('SELECT service_slug, location_slug, query_text, position, domain, title FROM position_snapshots WHERE snapshot_date = ? AND site_type = \'own\' ORDER BY service_slug, location_slug').bind(toDate).all(),
          env.DB.prepare('SELECT domain, COUNT(*) as cnt, AVG(position) as avg_pos FROM position_snapshots WHERE snapshot_date = ? AND site_type = \'direct_competitor\' GROUP BY domain ORDER BY cnt DESC LIMIT 20').bind(fromDate).all(),
          env.DB.prepare('SELECT domain, COUNT(*) as cnt, AVG(position) as avg_pos FROM position_snapshots WHERE snapshot_date = ? AND site_type = \'direct_competitor\' GROUP BY domain ORDER BY cnt DESC LIMIT 20').bind(toDate).all(),
        ]);

        const fromMap = new Map((fromSnap.results as any[]).map((r: any) => [r.service_slug + '|' + r.location_slug + '|' + r.query_text, r]));
        const toMap = new Map((toSnap.results as any[]).map((r: any) => [r.service_slug + '|' + r.location_slug + '|' + r.query_text, r]));
        const fromCompMap = new Map((fromComp.results as any[]).map((r: any) => [r.domain, r]));
        const toCompMap = new Map((toComp.results as any[]).map((r: any) => [r.domain, r]));

        const guardmanChanges: any[] = [];
        const allKeys = new Set([...fromMap.keys(), ...toMap.keys()]);
        for (const key of allKeys) {
          const from = fromMap.get(key);
          const to = toMap.get(key);
          if (from && !to) {
            guardmanChanges.push({ service: from.service_slug, location: from.location_slug, query: from.query_text, from_pos: from.position, to_pos: null, domain: from.domain, change: 'LOST', title: from.title });
          } else if (!from && to) {
            guardmanChanges.push({ service: to.service_slug, location: to.location_slug, query: to.query_text, from_pos: null, to_pos: to.position, domain: to.domain, change: 'NEW', title: to.title });
          } else if (from && to && from.position !== to.position) {
            const delta = from.position - to.position;
            guardmanChanges.push({ service: from.service_slug, location: from.location_slug, query: from.query_text, from_pos: from.position, to_pos: to.position, delta: delta, change: delta > 0 ? '+' + delta : delta.toString(), domain: to.domain, title: to.title });
          }
        }

        const competitorChanges: any[] = [];
        const allCompDomains = new Set([...fromCompMap.keys(), ...toCompMap.keys()]);
        for (const domain of allCompDomains) {
          const from = fromCompMap.get(domain);
          const to = toCompMap.get(domain);
          if (from && !to) {
            competitorChanges.push({ domain, from_appearances: from.cnt, to_appearances: 0, from_avg: from.avg_pos, to_avg: null, change: 'LEFT_SERP' });
          } else if (!from && to) {
            competitorChanges.push({ domain, from_appearances: 0, to_appearances: to.cnt, from_avg: null, to_avg: to.avg_pos, change: 'NEW_COMPETITOR' });
          } else if (from && to && (from.cnt !== to.cnt || Math.abs((from.avg_pos || 0) - (to.avg_pos || 0)) > 0.5)) {
            competitorChanges.push({ domain, from_appearances: from.cnt, to_appearances: to.cnt, from_avg: from.avg_pos, to_avg: to.avg_pos, appearances_delta: to.cnt - from.cnt, avg_delta: to.avg_pos && from.avg_pos ? +(to.avg_pos - from.avg_pos).toFixed(1) : null });
          }
        }

        return Response.json({ ok: true, data: {
          from_date: fromDate, to_date: toDate,
          guardman: {
            total_changes: guardmanChanges.length,
            improved: guardmanChanges.filter((c: any) => c.change.startsWith('+')).length,
            declined: guardmanChanges.filter((c: any) => c.change.startsWith('-')).length,
            new: guardmanChanges.filter((c: any) => c.change === 'NEW').length,
            lost: guardmanChanges.filter((c: any) => c.change === 'LOST').length,
            changes: guardmanChanges.slice(0, 50),
          },
          competitors: {
            total_changes: competitorChanges.length,
            rising: competitorChanges.filter((c: any) => (c.appearances_delta || 0) > 0).length,
            declining: competitorChanges.filter((c: any) => (c.appearances_delta || 0) < 0).length,
            changes: competitorChanges.slice(0, 30),
          },
        }}, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/positions - Position intelligence by service
    if (path === '/api/serper/positions' && method === 'GET') {
      try {
        const serviceSlug = url.searchParams.get('service');
        const locationSlug = url.searchParams.get('location');
        const allPositions = url.searchParams.get('all');

        let sql = `
          SELECT sq.service_slug, sq.location_slug, sq.query_text, sq.endpoint,
            MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as guardman_pos,
            COUNT(DISTINCT CASE WHEN sr.site_type = 'own' THEN sr.id END) as guardman_appearances,
            COUNT(DISTINCT CASE WHEN sr.site_type = 'direct_competitor' THEN sr.domain END) as competitor_domains_in_top10,
            COUNT(CASE WHEN sr.site_type = 'direct_competitor' AND sr.position <= 10 THEN 1 END) as competitor_top10_count,
            ROUND(AVG(CASE WHEN sr.site_type = 'direct_competitor' THEN CAST(JSON_EXTRACT(sr.extra_json, '$.relevance_score') AS REAL) ELSE NULL END), 1) as avg_competitor_relevance,
            MAX(sr.position) as max_position
          FROM serper_queries sq
          LEFT JOIN serper_results sr ON sq.id = sr.query_id
          WHERE sq.status = 'completed'
        `;
        const params: any[] = [];
        if (serviceSlug) { sql += ' AND sq.service_slug = ?'; params.push(serviceSlug); }
        if (locationSlug) { sql += ' AND sq.location_slug = ?'; params.push(locationSlug); }
        sql += ' GROUP BY sq.service_slug, sq.location_slug, sq.query_text, sq.endpoint ORDER BY sq.service_slug, sq.location_slug, guardman_pos ASC';

        const { results } = await env.DB.prepare(sql).bind(...params).all();
        const rows = results as any[];

        // Aggregate by combo
        const comboMap = new Map<string, any>();
        for (const row of rows) {
          const key = row.service_slug + '|' + row.location_slug;
          if (!comboMap.has(key)) {
            comboMap.set(key, { service_slug: row.service_slug, location_slug: row.location_slug, positions: [], best_position: 999, top3_count: 0, no_presence: 0 });
          }
          const combo = comboMap.get(key);
          combo.positions.push(row);
          if (row.guardman_pos < combo.best_position) combo.best_position = row.guardman_pos;
          if (row.guardman_pos <= 3) combo.top3_count++;
          if (row.guardman_pos === 999) combo.no_presence++;
        }

        const combos = Array.from(comboMap.values());
        const summary = {
          total_combos: combos.length,
          with_presence: combos.filter((c: any) => c.best_position < 999).length,
          top3_positions: combos.filter((c: any) => c.best_position <= 3).length,
          no_presence: combos.filter((c: any) => c.best_position === 999).length,
          avg_best_position: combos.length > 0 ? +(combos.reduce((s, c) => s + (c.best_position === 999 ? 0 : c.best_position), 0) / combos.filter(c => c.best_position < 999).length || 0).toFixed(1) : 0,
        };

        return Response.json({ ok: true, data: { positions: rows, combos: combos, summary } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/competitor-movement - Track competitor position changes over time
    if (path === '/api/serper/competitor-movement' && method === 'GET') {
      try {
        const domain = url.searchParams.get('domain');
        const all = url.searchParams.get('all');

        if (domain) {
          // Single domain detail
          const dates = await env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots WHERE domain = ? AND snapshot_date IS NOT NULL ORDER BY snapshot_date DESC LIMIT 10').bind(domain).all();
          const dateList = (dates.results as any[]).map((r: any) => r.snapshot_date);
          const historyByDate: any[] = [];
          for (const d of dateList) {
            const rows = await env.DB.prepare('SELECT service_slug, location_slug, query_text, position, title FROM position_snapshots WHERE snapshot_date = ? AND domain = ? ORDER BY position ASC').bind(d, domain).all();
            historyByDate.push({ date: d, positions: rows.results, count: rows.results.length, avg_pos: rows.results.length > 0 ? +(rows.results.reduce((s: number, r: any) => s + r.position, 0) / rows.results.length).toFixed(1) : null });
          }
          return Response.json({ ok: true, data: { domain, history: historyByDate } }, { headers: cors });
        }

        if (all === 'true') {
          // All competitor movement summary (compare latest 2 snapshots)
          const [snapDates, latestComp, prevComp] = await Promise.all([
            env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots WHERE site_type = \'direct_competitor\' ORDER BY snapshot_date DESC LIMIT 2').all(),
            env.DB.prepare('SELECT domain, COUNT(*) as appearances, ROUND(AVG(position), 1) as avg_pos FROM position_snapshots WHERE site_type = \'direct_competitor\' GROUP BY domain ORDER BY appearances DESC LIMIT 20').bind().all(),
            env.DB.prepare('SELECT domain, COUNT(*) as appearances, ROUND(AVG(position), 1) as avg_pos FROM position_snapshots WHERE site_type = \'direct_competitor\' AND snapshot_date != (SELECT MAX(snapshot_date) FROM position_snapshots) GROUP BY domain ORDER BY appearances DESC LIMIT 20').bind().all(),
          ]);
          const latestDate = snapDates.results[0]?.snapshot_date;
          const prevDate = snapDates.results[1]?.snapshot_date;
          const prevMap = new Map((prevComp.results as any[]).map((r: any) => [r.domain, r]));
          const movement: any[] = [];
          for (const curr of (latestComp.results as any[])) {
            const prev = prevMap.get(curr.domain);
            const appearances_delta = prev ? curr.appearances - prev.appearances : curr.appearances;
            const avg_delta = prev && curr.avg_pos && prev.avg_pos ? +(curr.avg_pos - prev.avg_pos).toFixed(1) : null;
            let trend = 'STABLE';
            if (avg_delta !== null && avg_delta < -0.5) trend = 'IMPROVING';
            else if (avg_delta !== null && avg_delta > 0.5) trend = 'DECLINING';
            else if (appearances_delta > 5) trend = 'EXPANDING';
            else if (appearances_delta < -5) trend = 'SHRINKING';
            movement.push({ domain: curr.domain, appearances: curr.appearances, avg_pos: curr.avg_pos, appearances_delta, avg_delta, trend });
          }
          return Response.json({ ok: true, data: { latest_date: latestDate, previous_date: prevDate, movement: movement.sort((a, b) => b.appearances_delta - a.appearances_delta) } }, { headers: cors });
        }

        return Response.json({ ok: false, error: 'Provide domain param or all=true' }, { status: 400, headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/content-gaps - Content opportunities based on keyword gaps
    if (path === '/api/serper/content-gaps' && method === 'GET') {
      try {
        const { results } = await env.DB.prepare(`
          SELECT sq.service_slug, sq.location_slug, sq.query_text, sq.endpoint,
            MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as guardman_pos,
            COUNT(CASE WHEN sr.site_type = 'direct_competitor' AND sr.position <= 5 THEN 1 END) as competitors_in_top5,
            COUNT(CASE WHEN sr.site_type = 'direct_competitor' AND sr.position <= 10 THEN 1 END) as competitors_in_top10,
            ROUND(AVG(CASE WHEN sr.site_type = 'direct_competitor' THEN CAST(JSON_EXTRACT(sr.extra_json, '$.relevance_score') AS REAL) ELSE NULL END), 1) as avg_relevance,
            sq.credits_used
          FROM serper_queries sq
          LEFT JOIN serper_results sr ON sq.id = sr.query_id
          WHERE sq.status = 'completed' AND sq.endpoint = 'search'
          GROUP BY sq.id
          HAVING guardman_pos > 5 OR guardman_pos = 999
          ORDER BY competitors_in_top5 DESC, avg_relevance DESC
          LIMIT 50
        `).all();

        const gaps = (results as any[]).map((r: any) => {
          let priority = 'LOW';
          let difficulty = 'EASY';
          if (r.competitors_in_top5 >= 3) { priority = 'HIGH'; difficulty = 'HARD'; }
          else if (r.competitors_in_top5 >= 1) { priority = 'MEDIUM'; difficulty = 'MEDIUM'; }
          else if (r.competitors_in_top5 === 0 && r.competitors_in_top10 > 0) { priority = 'MEDIUM'; difficulty = 'EASY'; }
          return { ...r, priority, difficulty, gap_type: r.guardman_pos === 999 ? 'NO_PRESENCE' : 'WEAK_POSITION' };
        });

        return Response.json({ ok: true, data: { gaps, total_gaps: gaps.length, by_priority: { high: gaps.filter((g: any) => g.priority === 'HIGH').length, medium: gaps.filter((g: any) => g.priority === 'MEDIUM').length, low: gaps.filter((g: any) => g.priority === 'LOW').length } } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/serper/snapshot/summary - Overview of all snapshots with diff summary
    if (path === '/api/serper/snapshot/summary' && method === 'GET') {
      try {
        const dates = await env.DB.prepare('SELECT DISTINCT snapshot_date FROM position_snapshots ORDER BY snapshot_date DESC LIMIT 10').all();
        const dateList = (dates.results as any[]).map((r: any) => r.snapshot_date);
        const summaries: any[] = [];
        for (const d of dateList) {
          const [gm, comp, total] = await Promise.all([
            env.DB.prepare('SELECT COUNT(DISTINCT query_text) as cnt, AVG(position) as avg_pos FROM position_snapshots WHERE snapshot_date = ? AND site_type = \'own\'').bind(d).first(),
            env.DB.prepare('SELECT COUNT(DISTINCT domain) as domains, AVG(position) as avg_pos FROM position_snapshots WHERE snapshot_date = ? AND site_type = \'direct_competitor\' AND position <= 5').bind(d).first(),
            env.DB.prepare('SELECT COUNT(*) as total FROM position_snapshots WHERE snapshot_date = ?').bind(d).first(),
          ]);
          summaries.push({ date: d, guardman_count: gm?.cnt || 0, guardman_avg: gm?.avg_pos || null, top5_competitors: comp?.domains || 0, competitor_avg: comp?.avg_pos || null, total_records: total?.total || 0 });
        }

        // Calculate deltas between consecutive snapshots
        const withDeltas = summaries.map((s, i) => {
          if (i === summaries.length - 1) return { ...s, guardman_delta: 0, competitor_delta: 0 };
          const prev = summaries[i + 1];
          return { ...s, guardman_delta: s.guardman_count - (prev?.guardman_count || 0), competitor_delta: s.top5_competitors - (prev?.top5_competitors || 0) };
        });

        return Response.json({ ok: true, data: { snapshots: withDeltas, latest_date: dateList[0], total_snapshots: dateList.length } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // ===== AGENT ENDPOINTS =====



      return null; // Not matched
    },
  },
];
