// GuardMan Admin — AI Search Routes (extracted from api.ts)
import { CORS_HEADERS } from '../../types';
import { seedAllInstances, updateSearchIndexFromSerper } from '../../services/search-seed';

const cors = CORS_HEADERS;

export const searchRoutes = [
  // POST /api/search/seed
  {
    pattern: /^\/api\/search\/seed$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const result = await seedAllInstances(env);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
  // POST /api/search/update
  {
    pattern: /^\/api\/search\/update$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const body = await request.json() as any;
        const { service_slug, location_slug } = body;
        const result = await updateSearchIndexFromSerper(env);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
];
