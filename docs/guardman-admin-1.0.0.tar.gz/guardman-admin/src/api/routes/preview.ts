// GuardMan Admin — Preview Routes (Dynamic Worker Preview Engine)
// Uses @cloudflare/worker-bundler + ctx.exports for proper Dynamic Worker rendering.
// Following the pattern from cloudflare/dynamic-worker-based-reports.

import { createWorker } from "@cloudflare/worker-bundler";
import { exports as runtimeExports } from "cloudflare:workers";
import { renderPreviewHTML } from '../../services/preview';
import { getLocationSlugs } from '../../utils/location';

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

// Cross-isolate DO access (runtimeExports) — for LogSession.getByName() only
// This is DIFFERENT from ctx.exports — runtimeExports accesses DOs by name across isolates
type LogSessionExports = {
  LogSession: {
    getByName(name: string): {
      addLogs(logs: any[]): Promise<void>;
      waitForLogs(): Promise<any>;
    };
  };
};
const moduleExports = runtimeExports as unknown as LogSessionExports;

// Dynamic Worker entrypoint instantiation (ctx.exports)
// ctx is ExecutionContext in the Worker's fetch handler — ctx.exports instantiates WorkerEntrypoints
// for Dynamic Worker bindings. This is the OFFICIAL API (see dynamic-worker-based-reports/src/index.ts ~L191)
type CtxExports = {
  PreviewDataService(options: { props: Record<string, unknown> }): Fetcher;
  DynamicWorkerTail(options: { props: { workerId: string } }): Fetcher;
};

const LOCATION_SLUGS = [
  'santiago-centro', 'huechuraba', 'lampa', 'quilicura', 'la-reina',
  'las-condes', 'lo-barnechea', 'vitacura', 'conchali', 'pudahuel',
  'renca', 'la-pintana', 'los-andes', 'san-felipe',
];

function parseComboSlug(slug: string): { serviceSlug: string; locationSlug: string } {
  for (const loc of LOCATION_SLUGS) {
    if (slug.endsWith('-' + loc)) {
      return { serviceSlug: slug.substring(0, slug.length - loc.length - 1), locationSlug: loc };
    }
  }
  return { serviceSlug: slug, locationSlug: '' };
}

/**
 * Generate a content hash for cache key
 */
async function makeContentHash(entityType: string, entitySlug: string): Promise<string> {
  const raw = `${entityType}:${entitySlug}`;
  const data = new TextEncoder().encode(raw);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return `preview-${entityType}-${entitySlug}-${hashHex.substring(0, 12)}`;
}

/**
 * Build the Dynamic Worker code that renders a preview page.
 * This code runs inside the Dynamic Worker and calls env.DATA.getContent() via RPC.
 */
function buildPreviewWorkerCode(): string {
  return `export default {
  async fetch(request) {
    const url = new URL(request.url);
    const entityType = url.searchParams.get('type') || 'service';
    const entitySlug = url.searchParams.get('slug') || '';

    // Fetch data via RPC from PreviewDataService
    const data = await env.DATA.getContent(entityType, entitySlug);
    if (!data) {
      return new Response('<html><body style="font-family:sans-serif;padding:40px;background:#1a1a1a;color:#fff;"><h1 style="color:#ef4444">No Content</h1><p>No content found for ' + entityType + '/' + entitySlug + '</p></body></html>', { headers: { 'Content-Type': 'text/html' } });
    }

    const s = data.content?.sections || data.content || {};
    const meta = s.meta || {};
    const hero = s.hero || {};
    const score = data.score || 0;
    const titleLen = (meta.title || '').length;
    const descLen = (meta.description || '').length;

    function esc(str) {
      if (!str) return '';
      return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    const html = \`<!DOCTYPE html>
<html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>\${esc(meta.title || data.entityName)} — GuardMan Chile</title>
<style>
  :root { --primary: #1A2744; --accent: #3B82F6; }
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: 'Inter', system-ui, sans-serif; color: #1a1a1a; background: #fff; line-height: 1.6; }
  .badge { position:fixed;top:0;left:0;right:0;z-index:100;background:linear-gradient(90deg,#7c3aed,#2563eb);color:white;padding:8px 16px;font-size:13px;font-weight:600;text-align:center; }
  .container { max-width:1200px; margin:0 auto; padding:0 20px; padding-top:48px; }
  .serp { background:white; border:1px solid #e5e7eb; border-radius:8px; padding:16px 20px; margin:12px auto; max-width:600px; font-family:Arial,sans-serif; }
  .serp-title { color:#1a0dab; font-size:20px; line-height:1.3; text-decoration:none; display:block; }
  .serp-url { color:#006621; font-size:14px; margin:4px 0; }
  .serp-desc { color:#545454; font-size:14px; line-height:1.58; }
  .warn { background:#fef3c7; border:1px solid #fbbf24; border-radius:8px; padding:8px 16px; margin:8px auto; max-width:600px; font-size:13px; color:#92400e; }
  .hero { background:var(--primary); color:white; padding:80px 0; margin-top:16px; border-radius:16px 16px 0 0; }
  .hero h1 { font-size:3rem; font-weight:800; margin-bottom:16px; }
  .hero .sub { font-size:1.25rem; opacity:0.9; max-width:600px; }
  .score-bar { background:white; border:1px solid #e5e7eb; border-radius:12px; padding:12px 16px; margin:16px auto; display:flex; align-items:center; gap:12px; }
  .schema { background:white; border:1px solid #e5e7eb; border-radius:8px; padding:16px 20px; margin:12px auto; max-width:600px; }
  .schema pre { font-size:11px; line-height:1.4; color:#374151; background:#f9fafb; padding:12px; border-radius:8px; overflow:auto; }
</style></head><body>
<div class="badge">⚡ PREVIEW — \${esc(data.entityType)}/\${esc(data.entitySlug)} [Dynamic Worker]</div>
<div class="container">
  \${score > 0 ? '<div class="score-bar"><span style="font-size:13px;color:#6c757d">Score:</span><span style="font-size:1.5rem;font-weight:800;color:' + (score >= 80 ? '#10b981' : score >= 60 ? '#f59e0b' : '#ef4444') + '">' + score + '/120</span></div>' : ''}
  <div class="serp">
    <a href="#" class="serp-title">\${esc(meta.title || data.entityName)}</a>
    <div class="serp-url">https://guardman.cl\${esc(data.urlPath || '')}</div>
    <div class="serp-desc">\${esc(meta.description || '')}</div>
  </div>
  \${titleLen > 60 || descLen > 160 ? '<div class="warn"><strong>⚠️ SEO:</strong>' + (titleLen > 60 ? ' Title ' + titleLen + '/60' : '') + (descLen > 160 ? ' Description ' + descLen + '/160' : '') + '</div>' : ''}
  <section class="hero"><div class="container" style="padding-top:0">
    <h1>\${esc(hero.heading || data.entityName)}</h1>
    \${hero.subheading ? '<p class="sub">' + esc(hero.subheading) + '</p>' : ''}
  </div></section>
</div>
<div style="text-align:center;padding:24px;color:#9ca3af;font-size:12px">Dynamic Worker Preview — \${esc(data.entityType)}/\${esc(data.entitySlug)}</div>
</body></html>\`;
    return new Response(html, { headers: { 'Content-Type': 'text/html' } });
  }
};`;
}

/**
 * Render preview using Dynamic Worker with bundler
 */
async function renderWithDynamicWorker(
  env: any,
  ctx: any,
  entityType: string,
  entitySlug: string,
): Promise<Response | null> {
  if (!env.LOADER) return null;

  try {
    const workerCode = buildPreviewWorkerCode();

    // Bundle the generated worker code
    const result = await createWorker({
      files: { "src/index.js": workerCode },
    });

    const workerId = `preview-${entityType}-${entitySlug}`;

    // CORRECTO — ctx.exports instancia WorkerEntrypoints para Dynamic Worker bindings
    // ctx is ExecutionContext in the Worker's fetch handler — ctx.exports is the official API
    // See: dynamic-worker-based-reports/src/index.ts ~L191
    const ctxExports = (ctx as unknown as { exports: CtxExports }).exports;
    const dataBinding = ctxExports.PreviewDataService({ props: {} });

    // Set up log session for this worker (via runtimeExports — cross-isolate DO access)
    const logSession = moduleExports.LogSession.getByName(workerId);
    const logWaiter = await logSession.waitForLogs();

    // Get the Dynamic Worker with proper env binding + tails
    const worker = env.LOADER.get(workerId, async () => ({
      mainModule: result.mainModule,
      modules: result.modules as Record<string, string>,
      compatibilityDate: result.wranglerConfig?.compatibilityDate ?? "2025-01-01",
      compatibilityFlags: result.wranglerConfig?.compatibilityFlags ?? [],
      globalOutbound: null,
      env: { DATA: dataBinding },
      tails: [ctxExports.DynamicWorkerTail({ props: { workerId } })],  // Tail capture via ctx.exports
    }));

    // Warmup the Dynamic Worker before fetch (recommended by dynamic-workers-playground)
    const entrypoint = worker.getEntrypoint() as Fetcher & { __warmup__?: () => Promise<void> };
    try { await entrypoint.__warmup__?.(); } catch {}

    // Execute the Dynamic Worker
    const workerUrl = `https://worker.internal/?type=${entityType}&slug=${entitySlug}`;
    const response = await entrypoint.fetch(new Request(workerUrl));

    const html = await response.text();

    // Collect logs (don't block the response)
    try {
      const logs = await logWaiter.getLogs(3000);
      if (logs.length > 0) {
        console.log(`[preview] Dynamic Worker logs for ${workerId}:`, logs.length);
      }
    } catch {}

    return new Response(html, {
      status: response.status,
      headers: { 'Content-Type': 'text/html', 'X-Preview-Engine': 'dynamic-worker', ...cors },
    });
  } catch (err: any) {
    console.error('[preview] Dynamic Worker failed:', err.message);
    return null;
  }
}

export const previewRoutes = [
  {
    pattern: /^\/api\/preview\/([^/]+)\/([^/]+)$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const [, entityType, entitySlug] = match;

      try {
        const cacheKey = await makeContentHash(entityType, entitySlug);

        // 1. KV cache (fastest path)
        if (env.CACHE) {
          const cached = await env.CACHE.get(cacheKey, 'text');
          if (cached) {
            return new Response(cached, {
              headers: { 'Content-Type': 'text/html', 'X-Preview-Cache': 'HIT', ...cors },
            });
          }
        }

        // 2. Try Dynamic Worker rendering
        const dynamicResponse = await renderWithDynamicWorker(env, ctx, entityType, entitySlug);
        if (dynamicResponse && dynamicResponse.status === 200) {
          const html = await dynamicResponse.text();
          // Cache the Dynamic Worker output
          if (env.CACHE) {
            await env.CACHE.put(cacheKey, html, { expirationTtl: 3600 });
          }
          return new Response(html, {
            headers: { 'Content-Type': 'text/html', 'X-Preview-Cache': 'MISS', 'X-Preview-Engine': 'dynamic-worker', ...cors },
          });
        }

        // 3. Fallback: direct HTML rendering (always works)
        const { calculateContentScore } = await import('../../services/scoring');

        let entityName = entitySlug;
        let content: any = null;
        let images: { hero?: string; og?: string; gallery?: string[] } = {};
        let score = 0;
        let scoreDetails = { seo: 0, content: 0, structure: 0, keywords: 0 };

        // Fetch entity name
        if (entityType === 'service') {
          const svc = await env.DB.prepare('SELECT name FROM services WHERE slug = ?').bind(entitySlug).first();
          entityName = svc?.name || entitySlug;
        } else if (entityType === 'location') {
          const loc = await env.DB.prepare('SELECT name FROM locations WHERE slug = ?').bind(entitySlug).first();
          entityName = loc?.name || entitySlug;
        } else if (entityType === 'combo') {
          const { serviceSlug, locationSlug } = parseComboSlug(entitySlug);
          if (locationSlug) {
            const [svc, loc] = await Promise.all([
              env.DB.prepare('SELECT name FROM services WHERE slug = ?').bind(serviceSlug).first(),
              env.DB.prepare('SELECT name FROM locations WHERE slug = ?').bind(locationSlug).first(),
            ]);
            entityName = `${svc?.name || serviceSlug} en ${loc?.name || locationSlug}`;
          }
        }

        // Fetch content
        if (entityType === 'combo') {
          const { serviceSlug, locationSlug } = parseComboSlug(entitySlug);
          if (locationSlug) {
            const comboRow = await env.DB.prepare(
              'SELECT content_json, h1, seo_title, meta_description, intro_paragraph, faqs_json, cta_text, cta_button FROM combo_content WHERE service_slug = ? AND location_slug = ?'
            ).bind(serviceSlug, locationSlug).first();
            if (comboRow) {
              // FIX ERROR 20: Preferir content_json completo (nested) para scoring fiel
              if (comboRow.content_json) {
                try { content = JSON.parse(comboRow.content_json as string); } catch {}
              }
              // Fallback: reconstruir desde campos planos si no hay content_json
              if (!content) {
                const sections: any = {};
                if (comboRow.h1) sections.hero = { heading: comboRow.h1 };
                if (comboRow.intro_paragraph) sections.intro = { paragraphs: [comboRow.intro_paragraph] };
                if (comboRow.seo_title) sections.meta = { title: comboRow.seo_title, description: comboRow.meta_description || '' };
                if (comboRow.cta_text) sections.cta = { heading: comboRow.cta_text, button: comboRow.cta_button || '' };
                if (comboRow.faqs_json) { try { sections.faqs = { items: JSON.parse(comboRow.faqs_json as string) }; } catch {} }
                content = { sections };
              }
            }
          }
        } else {
          const latest = await env.DB.prepare(
            'SELECT content_json, version FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
          ).bind(entityType, entitySlug).first();
          if (latest?.content_json) content = JSON.parse(latest.content_json as string);
        }

        // Fetch images
        try {
          const { results: imgRows } = await env.DB.prepare(
            'SELECT me.usage, m.key FROM media_entities me JOIN media_library m ON me.media_id = m.id WHERE me.entity_type = ? AND me.entity_slug = ?'
          ).bind(entityType, entitySlug).all();
          for (const img of (imgRows as any[])) {
            const url = `/${img.key}`;
            if (img.usage === 'hero') images.hero = url;
            else if (img.usage === 'og') images.og = url;
            else { if (!images.gallery) images.gallery = []; images.gallery.push(url); }
          }
        } catch {}

        if (content) {
          const scored = calculateContentScore(content);
          score = scored.score;
          scoreDetails = scored.details;
        }

        const html = renderPreviewHTML({ entityType, entitySlug, entityName, content, images, score, scoreDetails });

        if (env.CACHE) await env.CACHE.put(cacheKey, html, { expirationTtl: 3600 });

        return new Response(html, {
          headers: { 'Content-Type': 'text/html', 'X-Preview-Cache': 'MISS', 'X-Preview-Engine': 'fallback', ...cors },
        });
      } catch (err: any) {
        return new Response(
          `<html><body style="font-family:sans-serif;padding:40px;background:#1a1a1a;color:#fff;">
            <h1 style="color:#ef4444">Preview Error</h1><p>${err.message}</p>
          </body></html>`,
          { headers: { 'Content-Type': 'text/html', ...cors } },
        );
      }
    },
  },
];
