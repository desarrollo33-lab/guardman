// GuardMan v3.0 — Admin Routes
// Endpoints de administración: backfill, regenerate-faqs, check-duplicates.
// Acciones que antes requerían intervención manual ahora son automáticas.

import { CORS_HEADERS } from '../../types';

const cors = CORS_HEADERS;

// Jaccard similarity para detección de duplicate content
function jaccardSimilarity(a: string, b: string): number {
  const wordsA = new Set(a.toLowerCase().split(/\s+/).filter(w => w.length > 3));
  const wordsB = new Set(b.toLowerCase().split(/\s+/).filter(w => w.length > 3));
  if (wordsA.size === 0 || wordsB.size === 0) return 0;
  const intersection = [...wordsA].filter(w => wordsB.has(w)).length;
  return intersection / (wordsA.size + wordsB.size - intersection);
}

function extractJSON(text: string): string {
  const start = text.indexOf('[');
  const end = text.lastIndexOf(']');
  if (start === -1 || end <= start) {
    const braceStart = text.indexOf('{');
    const braceEnd = text.lastIndexOf('}');
    if (braceStart === -1 || braceEnd <= braceStart) return '[]';
    return text.substring(braceStart, braceEnd + 1);
  }
  return text.substring(start, end + 1);
}

export const adminRoutes = [
  // ===== BACKFILL CONTENT (C1) =====
  {
    pattern: /^\/api\/admin\/backfill-content$/,
    methods: ['POST'],
    handler: async (request: Request, env: any) => {
      try {
        const { results: gaps } = await env.DB.prepare(`
          SELECT s.slug as service_slug, l.slug as location_slug
          FROM services s CROSS JOIN locations l
          LEFT JOIN combo_content cc ON cc.service_slug = s.slug AND cc.location_slug = l.slug
          WHERE cc.service_slug IS NULL
        `).all();

        const gapList = gaps as any[];

        if (gapList.length === 0) {
          return Response.json({ ok: true, gaps_found: 0, message: 'No gaps detected. All combos have content.' }, { headers: cors });
        }

        // Encolar en batches de 10
        const batchSize = 10;
        for (let i = 0; i < gapList.length; i += batchSize) {
          const batch = gapList.slice(i, i + batchSize);
          if (env.SEO_CONTENT_QUEUE) {
            await env.SEO_CONTENT_QUEUE.sendBatch(
              batch.map((g: any) => ({
                body: { type: 'combo', service_slug: g.service_slug, location_slug: g.location_slug },
              }))
            );
          }
        }

        return Response.json({
          ok: true,
          gaps_found: gapList.length,
          batches_queued: Math.ceil(gapList.length / batchSize),
          eta_minutes: Math.ceil(gapList.length * 1.5 / batchSize),
          gaps: gapList.map((g: any) => `${g.service_slug}/${g.location_slug}`),
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== CHECK DUPLICATES (C2) =====
  {
    pattern: /^\/api\/admin\/check-duplicates$/,
    methods: ['POST'],
    handler: async (request: Request, env: any) => {
      try {
        const { service_slug } = await request.json() as any;

        const { results: combos } = await env.DB.prepare(`
          SELECT cc.location_slug, cc.intro_paragraph, cc.h1
          FROM combo_content cc
          WHERE cc.service_slug = ?
        `).bind(service_slug).all();

        const comboList = combos as any[];
        const alerts: any[] = [];

        for (let i = 0; i < comboList.length; i++) {
          for (let j = i + 1; j < comboList.length; j++) {
            const a = (comboList[i].intro_paragraph || comboList[i].h1 || '');
            const b = (comboList[j].intro_paragraph || comboList[j].h1 || '');
            const sim = jaccardSimilarity(a, b);

            // Guardar en DB para tracking
            try {
              await env.DB.prepare(`
                INSERT INTO content_similarity (service_slug, location_a, location_b, similarity_score)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(service_slug, location_a, location_b) DO UPDATE SET
                  similarity_score = excluded.similarity_score, checked_at = datetime('now')
              `).bind(service_slug, comboList[i].location_slug, comboList[j].location_slug, Math.round(sim * 100) / 100).run();
            } catch { /* tabla puede no existir aún */ }

            if (sim > 0.6) {
              alerts.push({
                locations: [comboList[i].location_slug, comboList[j].location_slug],
                similarity: Math.round(sim * 100),
                severity: sim > 0.8 ? 'critical' : 'warning',
              });
            }
          }
        }

        return Response.json({
          ok: true,
          service: service_slug,
          combos_checked: comboList.length,
          pairs_compared: (comboList.length * (comboList.length - 1)) / 2,
          alerts,
          alerts_count: alerts.length,
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== REGENERATE FAQS (A11) =====
  {
    pattern: /^\/api\/admin\/regenerate-faqs$/,
    methods: ['POST'],
    handler: async (request: Request, env: any) => {
      try {
        const { service_slug, location_slug } = await request.json() as any;

        if (!service_slug || !location_slug) {
          return Response.json({ ok: false, error: 'Missing service_slug or location_slug' }, { status: 400, headers: cors });
        }

        // Obtener landmarks y competidores locales
        const [landmarks, competitors, locationInfo] = await Promise.all([
          env.DB.prepare('SELECT name, type FROM landmarks WHERE location_slug = ?').bind(location_slug).all(),
          env.DB.prepare(`
            SELECT DISTINCT sr.domain
            FROM serper_results sr
            JOIN serper_queries sq ON sr.query_id = sq.id
            WHERE sq.location_slug = ? AND sr.site_type = 'direct_competitor'
            LIMIT 5
          `).bind(location_slug).all(),
          env.DB.prepare('SELECT name, zone FROM locations WHERE slug = ?').bind(location_slug).first(),
        ]);

        const locationName = (locationInfo as any)?.name || location_slug;
        const landmarksStr = ((landmarks as any)?.results || []).map((l: any) => l.name).join(', ');
        const competitorsStr = ((competitors as any)?.results || []).map((c: any) => c.domain).join(', ');

        const prompt = `Genera 6 FAQs ÚNICAS y ESPECÍFICAS para "${service_slug.replace(/-/g, ' ')} en ${locationName}".

CONTEXTO LOCAL REAL (USA ESTOS DATOS EN LAS RESPUESTAS):
- Landmarks cercanos en ${locationName}: ${landmarksStr || 'zona residencial/comercial'}
- Competidores locales detectados: ${competitorsStr || 'competencia local'}
- Cada FAQ debe mencionar al menos un detalle específico de ${locationName}
- NO uses frases genéricas como "Contáctenos para una evaluación gratuita" sin contexto local
- Las respuestas deben tener 40+ palabras y ser informativas
- Responde SOLO con un JSON array sin markdown: [{"question": "pregunta", "answer": "respuesta larga con detalle local"}]`;

        const aiResponse = await env.AI.run('@cf/meta/llama-3-8b-instruct', {
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 2000,
        });

        const faqs = JSON.parse(extractJSON(aiResponse.response));

        if (!Array.isArray(faqs) || faqs.length === 0) {
          return Response.json({ ok: false, error: 'AI did not generate valid FAQs' }, { status: 500, headers: cors });
        }

        // Eliminar FAQs viejas y guardar nuevas
        await env.DB.prepare(
          'DELETE FROM faqs WHERE service_slug = ? AND location_slug = ?'
        ).bind(service_slug, location_slug).run();

        for (const faq of faqs) {
          await env.DB.prepare(`
            INSERT INTO faqs (service_slug, location_slug, question, answer, source, status)
            VALUES (?, ?, ?, ?, 'ai-generated-v3', 'approved')
          `).bind(service_slug, location_slug, faq.question, faq.answer).run();
        }

        return Response.json({
          ok: true,
          faqs_generated: faqs.length,
          faqs,
          context: { landmarks: landmarksStr, competitors: competitorsStr },
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== BATCH REGENERATE FAQS (todos los combos de un servicio) =====
  {
    pattern: /^\/api\/admin\/regenerate-faqs-batch$/,
    methods: ['POST'],
    handler: async (request: Request, env: any) => {
      try {
        const { service_slug } = await request.json() as any;

        const { results: locations } = await env.DB.prepare(
          'SELECT DISTINCT location_slug FROM combo_content WHERE service_slug = ?'
        ).bind(service_slug).all();

        let processed = 0;
        const errors: string[] = [];

        for (const loc of locations as any[]) {
          try {
            // Re-llamar al endpoint individual internamente
            const fakeReq = new Request('https://internal/api/admin/regenerate-faqs', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ service_slug, location_slug: loc.location_slug }),
            });

            const handler = adminRoutes.find(r => r.pattern.test('/api/admin/regenerate-faqs'))?.handler;
            if (handler) {
              const resp = await handler(fakeReq, env, null);
              if (resp && resp.status === 200) processed++;
              else errors.push(`${loc.location_slug}: ${resp?.status}`);
            }
          } catch (e: any) {
            errors.push(`${loc.location_slug}: ${e.message}`);
          }
        }

        return Response.json({
          ok: errors.length === 0,
          service: service_slug,
          locations_total: (locations as any[]).length,
          processed,
          errors,
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== SYSTEM STATUS =====
  {
    pattern: /^\/api\/admin\/status$/,
    methods: ['GET'],
    handler: async (request: Request, env: any) => {
      try {
        const [
          services, locations, sectors,
          combosTotal, combosWithContent, combosPublished,
          serperQueries, serperResults,
          contentVersions, faqs, leads,
          lastScan, lastIntel,
        ] = await Promise.all([
          env.DB.prepare('SELECT COUNT(*) as c FROM services').first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM locations').first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM sectors').first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM (SELECT s.slug, l.slug FROM services s CROSS JOIN locations l)').first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM combo_content').first(),
          env.DB.prepare("SELECT COUNT(*) as c FROM combo_content WHERE status='published'").first(),
          env.DB.prepare("SELECT COUNT(*) as c FROM serper_queries WHERE status='completed'").first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM serper_results').first(),
          env.DB.prepare('SELECT COUNT(DISTINCT entity_slug) as c FROM content_versions').first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM faqs').first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM intel_leads').first(),
          env.DB.prepare('SELECT created_at FROM serper_queries ORDER BY created_at DESC LIMIT 1').first(),
          env.DB.prepare('SELECT created_at FROM intel_snapshots ORDER BY created_at DESC LIMIT 1').first(),
        ]);

        const totalCombos = (combosTotal as any)?.c || 126;
        const withContent = (combosWithContent as any)?.c || 0;

        return Response.json({
          ok: true,
          data: {
            entities: {
              services: (services as any)?.c || 0,
              locations: (locations as any)?.c || 0,
              sectors: (sectors as any)?.c || 0,
              combos_total_possible: totalCombos,
              combos_with_content: withContent,
              combos_published: (combosPublished as any)?.c || 0,
              coverage_pct: Math.round((withContent / totalCombos) * 100),
            },
            serper: {
              queries: (serperQueries as any)?.c || 0,
              results: (serperResults as any)?.c || 0,
              last_scan: (lastScan as any)?.created_at || null,
            },
            content: {
              versions: (contentVersions as any)?.c || 0,
              faqs: (faqs as any)?.c || 0,
            },
            crm: {
              leads: (leads as any)?.c || 0,
            },
            intel: {
              last_analysis: (lastIntel as any)?.created_at || null,
            },
            worker: {
              version: '3.0.0-workers-native',
              uptime: 'running',
            },
          },
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
];
