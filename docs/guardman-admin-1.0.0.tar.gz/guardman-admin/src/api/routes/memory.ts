// GuardMan Admin — Memory & Continuous Improvement Routes (extracted from api.ts)
import { CORS_HEADERS } from '../../types';
import { detectCannibalization, getWeeklyInsights, getFAQCoverage, getCompetitorWeaknessMap, analyzeBestPublishTime } from '../../services/memory';
import { calculateContentScore } from '../../services/scoring';

const cors = CORS_HEADERS;

export const memoryRoutes = [
  // GET /api/memory/cannibalization
  {
    pattern: /^\/api\/memory\/cannibalization$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const result = await detectCannibalization(env);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
  // GET /api/memory/weekly
  {
    pattern: /^\/api\/memory\/weekly$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const result = await getWeeklyInsights(env);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
  // GET /api/memory/faq-coverage
  {
    pattern: /^\/api\/memory\/faq-coverage$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const result = await getFAQCoverage(env);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
  // GET /api/memory/competitor-weaknesses
  {
    pattern: /^\/api\/memory\/competitor-weaknesses$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const result = await getCompetitorWeaknessMap(env);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
  // GET /api/memory/best-publish-time
  {
    pattern: /^\/api\/memory\/best-publish-time$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const result = await analyzeBestPublishTime(env);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
  // GET /api/content/latest/:type/:slug
  {
    pattern: /^\/api\/content\/latest\/([^/]+)\/(.+)$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      try {
        const [, entityType, entitySlug] = match;
        const latest = await env.DB.prepare(
          'SELECT content_json, generated_by, word_count, created_at, version FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
        ).bind(entityType, entitySlug).first();

        if (!latest?.content_json) {
          return Response.json({ ok: false, error: 'No content found' }, { status: 404, headers: cors });
        }

        const content = JSON.parse(latest.content_json as string);
        const score = calculateContentScore(content);

        return Response.json({ ok: true, data: {
          entityType, entitySlug,
          content, score: score.score, details: score.details,
          generatedBy: latest.generated_by, wordCount: latest.word_count,
          createdAt: latest.created_at, version: latest.version,
        }}, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
];
