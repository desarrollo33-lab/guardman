// GuardMan Admin — SEO Routes (extracted from api.ts)
import { CORS_HEADERS } from '../../types';
import { cachedFetch, CACHE_TTL } from '../../services/cache';

const cors = CORS_HEADERS;

export const seoRoutes = [
  // GET /api/seo/dashboard
  {
    pattern: /^\/api\/seo\/dashboard$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const seoData = await cachedFetch(env.CACHE, 'seo:dashboard', { ttl: CACHE_TTL.SEO_DASHBOARD }, async () => {
        const [kwCnt, kwEasy, sqCnt, srCnt, compCnt, rcCnt, recentKw] = await Promise.all([
          env.DB.prepare('SELECT COUNT(*) as c FROM keywords').first(),
          env.DB.prepare("SELECT COUNT(*) as c FROM keywords WHERE is_easy_win = 1 OR sds_tier = 'easy'").first(),
          env.DB.prepare("SELECT COUNT(*) as c FROM serper_queries WHERE status = 'completed'").first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM serper_results').first(),
          env.DB.prepare('SELECT COUNT(DISTINCT domain) as c FROM competitors WHERE is_guardman = 0').first(),
          env.DB.prepare('SELECT COUNT(*) as c FROM research_cache').first(),
          env.DB.prepare('SELECT intent, sds_tier, COUNT(*) as c FROM keywords GROUP BY intent, sds_tier ORDER BY c DESC LIMIT 10').all()
        ]);
        return { keywords: kwCnt?.c || 0, keywordsEasy: kwEasy?.c || 0, queries: sqCnt?.c || 0, results: srCnt?.c || 0, competitors: compCnt?.c || 0, researchCache: rcCnt?.c || 0, breakdown: recentKw.results };
      });
      return Response.json({ ok: true, data: seoData }, { headers: cors });
    },
  },
  // GET /api/seo/keywords
  {
    pattern: /^\/api\/seo\/keywords$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const tier = url.searchParams.get('tier');
      const intent = url.searchParams.get('intent');
      const easy = url.searchParams.get('easy');
      const limit = parseInt(url.searchParams.get('limit') || '100');
      let sql = 'SELECT * FROM keywords WHERE 1=1';
      const params: any[] = [];
      if (tier) { sql += ' AND sds_tier = ?'; params.push(tier); }
      if (intent) { sql += ' AND intent = ?'; params.push(intent); }
      if (easy === '1') { sql += ' AND is_easy_win = 1'; }
      sql += ' ORDER BY priority_score DESC, sds_score ASC LIMIT ?';
      params.push(limit);
      const { results } = await env.DB.prepare(sql).bind(...params).all();
      return Response.json({ ok: true, data: results }, { headers: cors });
    },
  },
  // GET /api/seo/competitors
  {
    pattern: /^\/api\/seo\/competitors$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const { results } = await env.DB.prepare('SELECT domain, site_type, AVG(avg_position) as avg_pos, COUNT(*) as appearances FROM competitors WHERE is_guardman = 0 GROUP BY domain ORDER BY appearances DESC LIMIT 50').all();
      return Response.json({ ok: true, data: results }, { headers: cors });
    },
  },
  // GET /api/seo/serper
  {
    pattern: /^\/api\/seo\/serper$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const service = url.searchParams.get('service');
      const location = url.searchParams.get('location');
      let sql = 'SELECT sq.id, sq.service_slug, sq.location_slug, sq.query_text, sq.endpoint, sq.status, sq.credits_used, sq.executed_at FROM serper_queries sq';
      const params: any[] = [];
      if (service) { sql += ' WHERE sq.service_slug = ?'; params.push(service); }
      if (location) { sql += (params.length ? ' AND' : ' WHERE') + ' sq.location_slug = ?'; params.push(location); }
      sql += ' ORDER BY sq.id DESC LIMIT 100';
      const { results } = await env.DB.prepare(sql).bind(...params).all();
      return Response.json({ ok: true, data: results }, { headers: cors });
    },
  },
  // GET /api/seo/research
  {
    pattern: /^\/api\/seo\/research$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const { results } = await env.DB.prepare('SELECT * FROM research_cache ORDER BY fetched_at DESC LIMIT 50').all();
      return Response.json({ ok: true, data: results }, { headers: cors });
    },
  },
];
