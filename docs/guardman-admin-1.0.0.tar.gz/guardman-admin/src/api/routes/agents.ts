// GuardMan Admin — Agent Routes (extracted from api.ts)
import { CORS_HEADERS, LOCATION_SLUGS } from '../../types';
import { calculateContentScore } from '../../services/scoring';

const cors = CORS_HEADERS;

export const agentsRoutes = [
  {
    pattern: /^\/api\/agents\/.+/,
    methods: ['GET', 'POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

    if (path === '/api/agents/content/status' && method === 'GET') {
      try {
        const id = env.CONTENT_AGENT.idFromName('default');
        const stub = env.CONTENT_AGENT.get(id);
        const status = await stub.getStatus();
        return Response.json({ ok: true, data: status }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }


    // GET /api/agents/content/images/:type/:slug - Get images for entity
    if (path.match(/^\/api\/agents\/content\/images\/([^\/]+)\/([^\/]+)$/) && method === 'GET') {
      try {
        const parts = path.split('/');
        const entityType = parts[4];
        const entitySlug = parts[5];
        const id = env.CONTENT_AGENT.idFromName('default');
        const stub = env.CONTENT_AGENT.get(id);
        const images = await stub.getImages(entityType, entitySlug);
        return Response.json({ ok: true, data: images }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/agents/content/generate - Generate via Content Agent
    if (path === '/api/agents/content/generate' && method === 'POST') {
      try {
        const body = await request.json() as any;
        const { entity_type, entity_slug, entity_name } = body;
        if (!entity_type || !entity_slug || !entity_name) {
          return Response.json({ ok: false, error: 'entity_type, entity_slug, entity_name required' }, { status: 400, headers: cors });
        }

        // Parse combo info
        let comboServiceSlug = '';
        let comboLocationSlug = '';
        if (entity_type === 'combo') {
          for (const loc of LOCATION_SLUGS) {
            if (entity_slug.endsWith('-' + loc)) {
              comboLocationSlug = loc;
              comboServiceSlug = entity_slug.substring(0, entity_slug.length - loc.length - 1);
              break;
            }
          }
        }

        const id = env.CONTENT_AGENT.idFromName('default');
        const stub = env.CONTENT_AGENT.get(id);
        const result = await stub.generateContent({
          entityType: entity_type,
          entitySlug: entity_slug,
          entityName: entity_name,
          comboServiceSlug,
          comboLocationSlug,
        });
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/agents/content/bulk - Bulk generate via Content Agent
    if (path === '/api/agents/content/bulk' && method === 'POST') {
      try {
        const body = await request.json() as any;
        const { entity_types } = body;

        const [services, locations, sectors, existingContent] = await Promise.all([
          env.DB.prepare('SELECT slug, name FROM services').all(),
          env.DB.prepare('SELECT slug, name FROM locations').all(),
          env.DB.prepare('SELECT slug, name FROM sectors').all(),
          env.DB.prepare(`
            SELECT DISTINCT entity_type, entity_slug FROM content_versions cv1
            WHERE version = (SELECT MAX(version) FROM content_versions cv2 WHERE cv2.entity_type = cv1.entity_type AND cv2.entity_slug = cv1.entity_slug)
            AND EXISTS (SELECT 1 FROM content_versions cv3 WHERE cv3.entity_type = cv1.entity_type AND cv3.entity_slug = cv1.entity_slug AND cv3.content_json IS NOT NULL)
          `).all(),
        ]);

        const existingSet = new Set((existingContent.results as any[]).map((c: any) => c.entity_type + '|' + c.entity_slug));
        const jobs: any[] = [];

        const shouldInclude = (type: string) => !entity_types || entity_types.includes(type);

        if (shouldInclude('service')) {
          (services.results as any[]).forEach((s: any) => {
            if (!existingSet.has('service|' + s.slug)) jobs.push({ entityType: 'service', entitySlug: s.slug, entityName: s.name });
          });
        }
        if (shouldInclude('location')) {
          (locations.results as any[]).forEach((l: any) => {
            if (!existingSet.has('location|' + l.slug)) jobs.push({ entityType: 'location', entitySlug: l.slug, entityName: l.name });
          });
        }
        if (shouldInclude('sector')) {
          (sectors.results as any[]).forEach((s: any) => {
            if (!existingSet.has('sector|' + s.slug)) jobs.push({ entityType: 'sector', entitySlug: s.slug, entityName: s.name });
          });
        }

        if (jobs.length === 0) {
          return Response.json({ ok: true, data: { message: 'No entities need content generation', queued: 0 } }, { headers: cors });
        }

        const id = env.CONTENT_AGENT.idFromName('default');
        const stub = env.CONTENT_AGENT.get(id);
        const result = await stub.generateBulk(jobs);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/agents/publisher/status - Publisher Agent status
    if (path === '/api/agents/publisher/status' && method === 'GET') {
      try {
        const id = env.PUBLISHER_AGENT.idFromName('default');
        const stub = env.PUBLISHER_AGENT.get(id);
        const status = await stub.getStatus();
        return Response.json({ ok: true, data: status }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/agents/publisher/queue - Get publish queue
    if (path === '/api/agents/publisher/queue' && method === 'GET') {
      try {
        const status = url.searchParams.get('status');
        const id = env.PUBLISHER_AGENT.idFromName('default');
        const stub = env.PUBLISHER_AGENT.get(id);
        const queue = await stub.fetchQueue(status || undefined);
        return Response.json({ ok: true, data: queue }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/agents/publisher/approve - Approve content for publishing
    if (path === '/api/agents/publisher/approve' && method === 'POST') {
      try {
        const body = await request.json() as any;
        const { entity_type, entity_slug } = body;
        if (!entity_type || !entity_slug) {
          return Response.json({ ok: false, error: 'entity_type and entity_slug required' }, { status: 400, headers: cors });
        }

        // Get latest content
        let contentJson = '';
        let score = 0;
        let version = 1;

        if (entity_type === 'combo') {
          // Parse combo slugs
          let comboServiceSlug = '';
          let comboLocationSlug = '';
          for (const loc of LOCATION_SLUGS) {
            if (entity_slug.endsWith('-' + loc)) {
              comboLocationSlug = loc;
              comboServiceSlug = entity_slug.substring(0, entity_slug.length - loc.length - 1);
              break;
            }
          }
          const comboData = await env.DB.prepare(
            'SELECT seo_title, h1, intro_paragraph, faqs_json, cta_text, cta_button, meta_description, word_count FROM combo_content WHERE service_slug = ? AND location_slug = ?'
          ).bind(comboServiceSlug, comboLocationSlug).first();
          if (!comboData) {
            return Response.json({ ok: false, error: 'No combo content found' }, { status: 404, headers: cors });
          }
          const sections: any = {};
          if (comboData.h1) sections.hero = { heading: comboData.h1 };
          if (comboData.intro_paragraph) sections.intro = { heading: comboData.h1 || '', paragraphs: [comboData.intro_paragraph] };
          if (comboData.seo_title) sections.meta = { title: comboData.seo_title, description: comboData.meta_description || '' };
          if (comboData.cta_text) sections.cta = { heading: comboData.cta_text, button: comboData.cta_button || '' };
          if (comboData.faqs_json) { try { sections.faqs = { items: JSON.parse(comboData.faqs_json as string) }; } catch {} }
          contentJson = JSON.stringify({ sections });
          score = calculateContentScore({ sections }).score;
        } else {
          const latest = await env.DB.prepare(
            'SELECT content_json, version FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
          ).bind(entity_type, entity_slug).first();
          if (!latest?.content_json) {
            return Response.json({ ok: false, error: 'No content found' }, { status: 404, headers: cors });
          }
          contentJson = latest.content_json as string;
          version = (latest.version as number) || 1;
          score = calculateContentScore(JSON.parse(contentJson)).score;
        }

        // Insert into publish queue
        await env.DB.prepare(`
          INSERT INTO publish_queue (entity_type, entity_slug, content_json, score, status, version)
          VALUES (?, ?, ?, ?, 'approved', ?)
          ON CONFLICT(entity_type, entity_slug) DO UPDATE SET
            content_json = excluded.content_json, score = excluded.score, status = 'approved', version = excluded.version
        `).bind(entity_type, entity_slug, contentJson, score, version).run();

        // Schedule with Publisher Agent
        const id = env.PUBLISHER_AGENT.idFromName('default');
        const stub = env.PUBLISHER_AGENT.get(id);
        const result = await stub.schedulePublish({
          entityType: entity_type,
          entitySlug: entity_slug,
          contentJson,
          score,
          version,
        });

        return Response.json({ ok: true, data: { approved: true, scheduled: result.scheduled, delayMinutes: result.delayMinutes } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/agents/publisher/process - Manually trigger queue processing
    if (path === '/api/agents/publisher/process' && method === 'POST') {
      try {
        const id = env.PUBLISHER_AGENT.idFromName('default');
        const stub = env.PUBLISHER_AGENT.get(id);
        const result = await stub.triggerProcessQueue();
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/agents/publisher/history - Get publish history
    if (path === '/api/agents/publisher/history' && method === 'GET') {
      try {
        const entityType = url.searchParams.get('type');
        const entitySlug = url.searchParams.get('slug');
        const id = env.PUBLISHER_AGENT.idFromName('default');
        const stub = env.PUBLISHER_AGENT.get(id);
        const history = await stub.getHistory(entityType || undefined, entitySlug || undefined);
        return Response.json({ ok: true, data: history }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/agents/publisher/rebuild - Trigger site rebuild
    if (path === '/api/agents/publisher/rebuild' && method === 'POST') {
      try {
        const id = env.PUBLISHER_AGENT.idFromName('default');
        const stub = env.PUBLISHER_AGENT.get(id);
        const result = await stub.rebuildSite();
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // ===== SERPER AGENT ENDPOINTS =====

    // GET /api/agents/serper/status - Serper Agent status
    if (path === '/api/agents/serper/status' && method === 'GET') {
      try {
        const id = env.SERPER_AGENT_SQLITE.idFromName('main');
        const stub = env.SERPER_AGENT_SQLITE.get(id);
        const status = await stub.getStatus();
        return Response.json({ ok: true, data: status }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/agents/serper/scan - Scan a single combo via Serper Agent
    if (path === '/api/agents/serper/scan' && method === 'POST') {
      try {
        const body = await request.json() as any;
        const { service_slug, location_slug } = body;
        if (!service_slug || !location_slug) {
          return Response.json({ ok: false, error: 'service_slug and location_slug required' }, { status: 400, headers: cors });
        }
        const id = env.SERPER_AGENT_SQLITE.idFromName('main');
        const stub = env.SERPER_AGENT_SQLITE.get(id);
        const result = await stub.scanCombo(service_slug, location_slug);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/agents/serper/full-scan - Trigger full pipeline via Serper Agent
    if (path === '/api/agents/serper/full-scan' && method === 'POST') {
      try {
        const id = env.SERPER_AGENT_SQLITE.idFromName('main');
        const stub = env.SERPER_AGENT_SQLITE.get(id);
        const result = await stub.fullScan();
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/agents/serper/research - Get research context for content generation
    if (path === '/api/agents/serper/research' && method === 'GET') {
      try {
        const serviceSlug = url.searchParams.get('service');
        const locationSlug = url.searchParams.get('location');
        if (!serviceSlug) {
          return Response.json({ ok: false, error: 'service query param required' }, { status: 400, headers: cors });
        }
        const id = env.SERPER_AGENT_SQLITE.idFromName('main');
        const stub = env.SERPER_AGENT_SQLITE.get(id);
        const result = await stub.getResearchContext(serviceSlug, locationSlug || undefined);
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/agents/serper/stats - Get classification stats
    if (path === '/api/agents/serper/stats' && method === 'GET') {
      try {
        const id = env.SERPER_AGENT_SQLITE.idFromName('main');
        const stub = env.SERPER_AGENT_SQLITE.get(id);
        const stats = await stub.getStats();
        return Response.json({ ok: true, data: stats }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // ===== ORCHESTRATOR ENDPOINTS (v4 — Think SDK) =====


      return null;
    },
  },
];
