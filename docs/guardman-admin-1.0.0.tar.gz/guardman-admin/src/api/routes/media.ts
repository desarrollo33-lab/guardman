// GuardMan Admin — Media Library Routes
// CRUD for media_library + media_entities (image ↔ entity assignments)

import { cors } from '../index';

// Rate limit helper for fal.ai generate/save endpoints (50 req/hora máximo)
async function checkFalRateLimit(env: any): Promise<boolean> {
  const key = 'fal:ratelimit:' + new Date().toISOString().slice(0, 13); // por hora
  const count = parseInt((await env.CACHE.get(key)) || '0');
  if (count >= 50) return false;
  await env.CACHE.put(key, String(count + 1), { expirationTtl: 3600 });
  return true;
}

// Rate limit helper for status polling (200 req/hora — no compite con generaciones)
async function checkFalStatusRateLimit(env: any): Promise<boolean> {
  const key = 'fal:status-ratelimit:' + new Date().toISOString().slice(0, 13);
  const count = parseInt((await env.CACHE.get(key)) || '0');
  if (count >= 200) return false;
  await env.CACHE.put(key, String(count + 1), { expirationTtl: 3600 });
  return true;
}

// ─── WebP Optimization (Cloudflare Image Resizing) ───
const VARIANT_CONFIGS = [
  { variant_type: 'webp-desktop', width: 1920, quality: 85 },
  { variant_type: 'webp-tablet',  width: 1024, quality: 65 },
  { variant_type: 'webp-mobile',  width: 640,  quality: 45 },
];

async function generateWebpVariants(env: any, originalKey: string, mediaId: number): Promise<void> {
  const baseKey = originalKey.replace(/\.[^.]+$/, '').replace('images/media/', 'images/webp/').replace('images/staff-raw/', 'images/webp/');
  
  for (const variant of VARIANT_CONFIGS) {
    try {
      // Try Image Resizing first, fallback to direct copy
      const cdnUrl = `https://guardman.oficinadesarrollo33.workers.dev/cdn-cgi/image/width=${variant.width},quality=${variant.quality},format=webp,fit=scale-down/${originalKey}`;
      const res = await fetch(cdnUrl);
      
      if (res.ok && res.headers.get('Content-Type')?.includes('webp')) {
        const blob = await res.arrayBuffer();
        const variantKey = `${baseKey}-${variant.variant_type}.webp`;
        
        await env.IMAGES.put(variantKey, blob, {
          httpMetadata: { contentType: 'image/webp' },
        });
        
        await env.DB.prepare(
          `INSERT INTO media_library_variants (media_id, variant_type, key, file_size, quality) VALUES (?, ?, ?, ?, ?)`
        ).bind(mediaId, variant.variant_type, variantKey, blob.byteLength, variant.quality).run();
      } else {
        // Fallback: copy original with WebP extension via R2
        const originalObj = await env.IMAGES.get(originalKey);
        if (originalObj) {
          const blob = await originalObj.arrayBuffer();
          const variantKey = `${baseKey}-${variant.variant_type}.webp`;
          
          await env.IMAGES.put(variantKey, blob, {
            httpMetadata: { contentType: 'image/webp' },
          });
          
          await env.DB.prepare(
            `INSERT INTO media_library_variants (media_id, variant_type, key, file_size, quality) VALUES (?, ?, ?, ?, ?)`
          ).bind(mediaId, variant.variant_type, variantKey, blob.byteLength, variant.quality).run();
        }
      }
    } catch (err) {
      console.error(`[WebP] Failed to generate ${variant.variant_type} for ${originalKey}:`, err);
    }
  }
}

export const mediaRoutes: Array<{
  pattern: RegExp;
  methods: string[];
  handler: (request: Request, env: any, ctx: any, match: RegExpMatchArray) => Promise<Response | null>;
}> = [
  // ===== GET /api/media — List library (with optional filters) =====
  {
    pattern: /^\/api\/media\/?$/,
    methods: ['GET'],
    handler: async (req, env, ctx) => {
      const url = new URL(req.url);
      const category = url.searchParams.get('category');
      const entity_type = url.searchParams.get('entity_type');
      const entity_slug = url.searchParams.get('entity_slug');
      const usage = url.searchParams.get('usage');
      const search = url.searchParams.get('q');
      const limit = Math.min(parseInt(url.searchParams.get('limit') || '100'), 500);
      const offset = parseInt(url.searchParams.get('offset') || '0');

      // If filtering by entity, join with media_entities
      if (entity_type || entity_slug || usage) {
        let sql = `SELECT m.* FROM media_library m JOIN media_entities me ON m.id = me.media_id WHERE 1=1`;
        const binds: any[] = [];
        if (entity_type)  { sql += ` AND me.entity_type = ?`; binds.push(entity_type); }
        if (entity_slug)  { sql += ` AND me.entity_slug = ?`; binds.push(entity_slug); }
        if (usage)        { sql += ` AND me.usage = ?`; binds.push(usage); }
        if (category)     { sql += ` AND m.category = ?`; binds.push(category); }
        sql += ` ORDER BY m.created_at DESC LIMIT ? OFFSET ?`;
        binds.push(limit, offset);

        const { results } = await env.DB.prepare(sql).bind(...binds).all();
        return Response.json({ ok: true, data: results }, { headers: cors });
      }

      // Simple library list
      let sql = `SELECT * FROM media_library WHERE 1=1`;
      const binds: any[] = [];
      if (category)  { sql += ` AND category = ?`; binds.push(category); }
      if (search)    { sql += ` AND (filename LIKE ? OR alt_text LIKE ? OR tags LIKE ?)`; binds.push(`%${search}%`, `%${search}%`, `%${search}%`); }
      sql += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
      binds.push(limit, offset);

      const { results } = await env.DB.prepare(sql).bind(...binds).all();

      // Get total count
      let countSql = `SELECT COUNT(*) as total FROM media_library WHERE 1=1`;
      const countBinds: any[] = [];
      if (category)  { countSql += ` AND category = ?`; countBinds.push(category); }
      if (search)    { countSql += ` AND (filename LIKE ? OR alt_text LIKE ? OR tags LIKE ?)`; countBinds.push(`%${search}%`, `%${search}%`, `%${search}%`); }
      const { results: countResults } = await env.DB.prepare(countSql).bind(...countBinds).all();

      return Response.json({ ok: true, data: results, total: countResults[0]?.total || 0 }, { headers: cors });
    },
  },

  // ===== GET /api/media/map — Full image map for frontend sync =====
  {
    pattern: /^\/api\/media\/map$/,
    methods: ['GET'],
    handler: async (req, env, ctx) => {
      // Build the complete image map: entity_type → entity_slug → { usage: image_path }
      const { results: assignments } = await env.DB.prepare(
        `SELECT me.entity_type, me.entity_slug, me.usage, m.key, m.filename, m.alt_text, m.category
         FROM media_entities me
         JOIN media_library m ON me.media_id = m.id
         ORDER BY me.entity_type, me.entity_slug, me.usage`
      ).all();

      // Build structured map
      const map: Record<string, Record<string, Record<string, { key: string; alt: string }>>> = {};
      for (const a of (assignments as any[])) {
        if (!map[a.entity_type]) map[a.entity_type] = {};
        if (!map[a.entity_type][a.entity_slug]) map[a.entity_type][a.entity_slug] = {};
        map[a.entity_type][a.entity_slug][a.usage] = { key: a.key, alt: a.alt_text || '' };
      }

      return Response.json({ ok: true, data: map }, { headers: cors });
    },
  },

  // ===== POST /api/media/fal/generate — Async proxy to fal.ai (Fase 0) =====
  {
    pattern: /^\/api\/media\/fal\/generate$/,
    methods: ['POST'],
    handler: async (req, env, ctx) => {
      if (!(await checkFalRateLimit(env))) {
        return Response.json({ ok: false, error: 'Límite de generaciones por hora alcanzado' }, { status: 429, headers: cors });
      }

      try {
        const body = await req.json() as any;
        const { prompt, model, image_size, num_images, seed, image_url, strength, negative_prompt, guidance_scale, num_inference_steps } = body;
        if (!prompt || !model) {
          return Response.json({ ok: false, error: 'Missing prompt or model' }, { status: 400, headers: cors });
        }

        // URL validation for img2img (Fase 2)
        if (image_url) {
          const allowedPrefixes = [
            'https://guardman.oficinadesarrollo33.workers.dev/',
            'https://v3b.fal.media/',
            'https://fal.media/',
          ];
          const isValid = allowedPrefixes.some(p => image_url.startsWith(p));
          if (!isValid) {
            return Response.json({ ok: false, error: 'Solo imágenes de GuardMan o fal.ai permitidas' }, { status: 400, headers: cors });
          }
        }

        const falBody: any = {
          prompt,
          image_size: image_size || 'landscape_4_3',
          num_images: num_images || 1,
          enable_safety_checker: true,
        };
        if (seed !== undefined) falBody.seed = seed;
        if (negative_prompt) falBody.negative_prompt = negative_prompt;
        if (image_url) { 
          falBody.image_url = image_url; 
          falBody.strength = strength ?? 0.45;  // Default 0.45 para staff photos
        }
        if (guidance_scale !== undefined) falBody.guidance_scale = guidance_scale;
        if (num_inference_steps !== undefined) falBody.num_inference_steps = num_inference_steps;

        const falRes = await fetch(`https://fal.run/${model}`, {
          method: 'POST',
          headers: {
            'Authorization': `Key ${env.FAL_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(falBody),
        });

        if (!falRes.ok) {
          const errText = await falRes.text();
          let friendlyError = 'Error al generar la imagen.';
          if (errText.includes('NSFW') || errText.includes('safety')) {
            friendlyError = 'La imagen fue rechazada por el filtro de seguridad. Intenta con un prompt diferente.';
          } else if (errText.includes('rate limit')) {
            friendlyError = 'Límite de generaciones alcanzado. Intenta de nuevo en unos minutos.';
          }
          return Response.json({ ok: false, error: friendlyError }, { status: 500, headers: cors });
        }

        const falData = await falRes.json() as any;

        // If immediate response (Schnell, ESRGAN, BiRefNet)
        if (falData.images && falData.images.length > 0) {
          const requestId = crypto.randomUUID();
          const record: any = {
            falRequestId: falData.request_id || requestId,
            status: 'completed',
            model,
            prompt,
            seed: seed ?? null,
            images: falData.images,
            created_at: Date.now(),
          };
          await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
          return Response.json({ ok: true, request_id: requestId, status: 'completed', images: falData.images }, { headers: cors });
        }

        // Async response (Flux Pro) — poll later
        if (falData.request_id) {
          const requestId = crypto.randomUUID();
          const record: any = {
            falRequestId: falData.request_id,
            status: 'queued',
            model,
            prompt,
            seed: seed ?? null,
            created_at: Date.now(),
          };
          await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
          return Response.json({ ok: true, request_id: requestId, status: 'queued' }, { headers: cors });
        }

        return Response.json({ ok: false, error: 'No request_id from fal.ai' }, { status: 500, headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== GET /api/media/fal/status/:request_id (Fase 0) =====
  {
    pattern: /^\/api\/media\/fal\/status\/([a-zA-Z0-9-]+)$/,
    methods: ['GET'],
    handler: async (req, env, ctx, match) => {
      if (!(await checkFalStatusRateLimit(env))) {
        return Response.json({ ok: false, error: 'Límite de consultas de estado alcanzado. Espera unos segundos.' }, { status: 429, headers: cors });
      }

      const requestId = match[1];

      try {
        // Check KV cache first
        const cached = await env.CACHE.get(`fal:req:${requestId}`);
        if (cached) {
          const record = JSON.parse(cached);
          if (record.status === 'completed' || record.status === 'failed') {
            return Response.json({ ok: true, ...record }, { headers: cors });
          }
        }

        // Not in cache or still processing — poll fal.ai
        const record = cached ? JSON.parse(cached) : null;
        if (!record) {
          return Response.json({ ok: false, error: 'Request not found' }, { status: 404, headers: cors });
        }

        // Usar el modelo original tal cual (sin strippear /image-to-image)
        const statusRes = await fetch(
          `https://fal.run/${record.model}/requests/${record.falRequestId}/status`,
          { headers: { 'Authorization': `Key ${env.FAL_API_KEY}` } }
        );

        if (!statusRes.ok) {
          record.status = 'failed';
          record.error = `Status check failed: ${statusRes.status}`;
          await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
          return Response.json({ ok: true, status: 'failed', error: record.error }, { headers: cors });
        }

        const statusData = await statusRes.json() as any;

        if (statusData.status === 'COMPLETED') {
          record.status = 'completed';
          record.images = statusData.images || [];
          await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
          return Response.json({ ok: true, request_id: requestId, status: 'completed', images: record.images }, { headers: cors });
        }

        if (statusData.status === 'FAILED') {
          record.status = 'failed';
          record.error = statusData.error || 'Generation failed';
          await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
          return Response.json({ ok: true, status: 'failed', error: record.error }, { headers: cors });
        }

        // Still processing
        return Response.json({ ok: true, request_id: requestId, status: 'processing' }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== POST /api/media/fal/save-to-r2 — Worker descarga de fal.ai y sube a R2 (Fase 0) =====
  {
    pattern: /^\/api\/media\/fal\/save-to-r2$/,
    methods: ['POST'],
    handler: async (req, env, ctx) => {
      if (!(await checkFalRateLimit(env))) {
        return Response.json({ ok: false, error: 'Límite de generaciones por hora alcanzado' }, { status: 429, headers: cors });
      }

      try {
        const body = await req.json() as any;
        const { request_id, image_index = 0, filename, category, alt_text, tags, parent_media_id } = body;
        if (!request_id || !filename) {
          return Response.json({ ok: false, error: 'Missing request_id or filename' }, { status: 400, headers: cors });
        }

        // Get image URL from KV
        const cached = await env.CACHE.get(`fal:req:${request_id}`);
        if (!cached) {
          return Response.json({ ok: false, error: 'Request not found (expired?)' }, { status: 404, headers: cors });
        }
        const record = JSON.parse(cached);
        if (record.status !== 'completed' || !record.images || !record.images[image_index]) {
          return Response.json({ ok: false, error: 'Image not available yet' }, { status: 400, headers: cors });
        }

        const imgUrl = record.images[image_index].url;

        // Download image from fal.ai
        const imgRes = await fetch(imgUrl);
        if (!imgRes.ok) {
          return Response.json({ ok: false, error: 'Failed to download generated image' }, { status: 500, headers: cors });
        }
        const blob = await imgRes.arrayBuffer();
        const contentType = imgRes.headers.get('Content-Type') || 'image/jpeg';

        // Derive extension from actual content-type (not forced to .webp)
        const extMap: Record<string, string> = {
          'image/jpeg': '.jpg',
          'image/png': '.png',
          'image/webp': '.webp',
          'image/gif': '.gif',
        };
        const ext = extMap[contentType] || '.jpg';

        // Generate R2 key
        const safeName = filename.replace(/[^a-z0-9-]/gi, '-').substring(0, 60);
        const key = `images/media/${Date.now()}-${safeName}${ext}`;

        // Upload to R2
        await env.IMAGES.put(key, blob, {
          httpMetadata: { contentType },
        });

        // Register in D1 (seed leído del KV record, no hardcodeado)
        const result = await env.DB.prepare(`
          INSERT INTO media_library (key, filename, alt_text, category, mime_type, file_size, media_type, tags, prompt_used, generation_model, generation_seed, generation_time_ms, fal_request_id, parent_media_id, created_at)
          VALUES (?, ?, ?, ?, ?, ?, 'image', ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        `).bind(
          key,
          filename,
          alt_text || '',
          category || 'ai-generated',
          contentType,
          blob.byteLength,
          tags ? JSON.stringify(tags) : '["ai-generated","fal-ai","img2img"]',
          record.prompt || '',
          record.model || '',
          record.seed ?? null,
          Date.now() - record.created_at,
          record.falRequestId || '',
          parent_media_id ?? null,
        ).run();

        const id = result.meta.last_row_id as number;

        // Generate WebP variants async (non-blocking)
        ctx.waitUntil(generateWebpVariants(env, key, id));

        return Response.json({
          ok: true,
          data: { id, key, url: `/${key}` }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== POST /api/media/:id/optimize — Generate WebP variants on demand (Fase 3) =====
  {
    pattern: /^\/api\/media\/(\d+)\/optimize$/,
    methods: ['POST'],
    handler: async (req, env, ctx, match) => {
      const token = req.headers.get('Authorization')?.replace('Bearer ', '');
      if (!token || token !== env.AUTH_TOKEN) {
        return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
      }
      const mediaId = parseInt(match[1]);
      try {
        const media = await env.DB.prepare(`SELECT key FROM media_library WHERE id = ?`).bind(mediaId).first() as any;
        if (!media) return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: cors });
        
        // Delete existing variants
        await env.DB.prepare(`DELETE FROM media_library_variants WHERE media_id = ?`).bind(mediaId).run();
        
        // Generate new variants
        await generateWebpVariants(env, media.key, mediaId);
        
        // Return variant info
        const { results: variants } = await env.DB.prepare(
          `SELECT * FROM media_library_variants WHERE media_id = ? ORDER BY quality DESC`
        ).bind(mediaId).all();
        
        return Response.json({ ok: true, data: variants }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== GET /api/media/prompts (Fase 1) =====
  {
    pattern: /^\/api\/media\/prompts$/,
    methods: ['GET'],
    handler: async (req, env, ctx) => {
      const token = req.headers.get('Authorization')?.replace('Bearer ', '');
      if (!token || token !== env.AUTH_TOKEN) {
        return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
      }
      try {
        // Try KV first, fallback to code defaults
        const cached = await env.CACHE.get('prompts:all');
        if (cached) {
          return Response.json({ ok: true, data: JSON.parse(cached) }, { headers: cors });
        }

        const { DEFAULT_PROMPTS } = await import('../../services/image-prompts');
        return Response.json({ ok: true, data: DEFAULT_PROMPTS }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== PUT /api/media/prompts (Fase 1) =====
  {
    pattern: /^\/api\/media\/prompts$/,
    methods: ['PUT'],
    handler: async (req, env, ctx) => {
      const token = req.headers.get('Authorization')?.replace('Bearer ', '');
      if (!token || token !== env.AUTH_TOKEN) {
        return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
      }
      try {
        const body = await req.json() as any;
        const { prompts } = body;
        if (!prompts || !Array.isArray(prompts)) {
          return Response.json({ ok: false, error: 'Missing prompts array' }, { status: 400, headers: cors });
        }

        await env.CACHE.put('prompts:all', JSON.stringify(prompts));
        return Response.json({ ok: true }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== GET /api/media/fal/credits — Check fal.ai account (Fase 3) =====
  {
    pattern: /^\/api\/media\/fal\/credits$/,
    methods: ['GET'],
    handler: async (req, env, ctx) => {
      const token = req.headers.get('Authorization')?.replace('Bearer ', '');
      if (!token || token !== env.AUTH_TOKEN) {
        return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
      }
      try {
        // Check multiple fal.ai endpoints for account info
        const headers = { 'Authorization': `Key ${env.FAL_API_KEY}` };
        
        // Try fal.ai dashboard API
        const endpoints = [
          'https://api.fal.ai/v1/user',
          'https://api.fal.ai/user',
          'https://fal.ai/api/user',
        ];
        
        let result: any = null;
        for (const url of endpoints) {
          const res = await fetch(url, { headers });
          if (res.ok) {
            result = { endpoint: url, status: res.status, data: await res.json() };
            break;
          }
        }
        
        if (!result) {
          result = { status: 'all_endpoints_returned_non_200', note: 'No billing endpoint found. Schnell (fast model) works and has free tier.' };
        }
        
        return Response.json({ ok: true, data: result }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== GET /api/media/feature-flag/:key (Fase 1) =====
  {
    pattern: /^\/api\/media\/feature-flag\/([a-zA-Z0-9:-]+)$/,
    methods: ['GET'],
    handler: async (req, env, ctx, match) => {
      const token = req.headers.get('Authorization')?.replace('Bearer ', '');
      if (!token || token !== env.AUTH_TOKEN) {
        return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
      }
      try {
        const flagKey = match[1];
        const raw = await env.CACHE.get(`feature:${flagKey}`);
        if (!raw) return Response.json({ ok: true, enabled: false }, { headers: cors });
        const parsed = JSON.parse(raw);
        return Response.json({ ok: true, enabled: parsed.enabled === true }, { headers: cors });
      } catch {
        return Response.json({ ok: true, enabled: false }, { headers: cors });
      }
    }
  },

  // ===== GET /api/media/:id — Get single image =====
  {
    pattern: /^\/api\/media\/(\d+)$/,
    methods: ['GET'],
    handler: async (req, env, ctx, match) => {
      const id = match[1];
      const media = await env.DB.prepare(`SELECT * FROM media_library WHERE id = ?`).bind(id).first();
      if (!media) return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: cors });

      // Get entity assignments
      const { results: entities } = await env.DB.prepare(
        `SELECT * FROM media_entities WHERE media_id = ? ORDER BY entity_type, entity_slug`
      ).bind(id).all();

      return Response.json({ ok: true, data: { ...media, entities } }, { headers: cors });
    },
  },

  // ===== POST /api/media/upload — Upload image or video =====
  {
    pattern: /^\/api\/media\/upload$/,
    methods: ['POST'],
    handler: async (req, env, ctx) => {
      try {
        const formData = await req.formData();
        const file = formData.get('file') as File;
        const thumbnail = formData.get('thumbnail') as File | null;
        const category = (formData.get('category') as string) || 'generic';
        const alt_text = (formData.get('alt_text') as string) || '';
        const tags = (formData.get('tags') as string) || '[]';

        if (!file) return Response.json({ ok: false, error: 'No file provided' }, { status: 400, headers: cors });

        const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
        const VIDEO_TYPES = ['video/mp4', 'video/webm'];
        const ALL_IMAGE = [...IMAGE_TYPES, 'image/gif', 'image/svg+xml'];
        const isVideo = VIDEO_TYPES.includes(file.type);
        const isImage = ALL_IMAGE.includes(file.type) || file.type.startsWith('image/');

        if (!isVideo && !isImage) {
          return Response.json({ ok: false, error: 'Invalid type. Allowed: JPEG, PNG, WebP, GIF, SVG, MP4, WebM' }, { status: 400, headers: cors });
        }

        // Size limits: 10MB images, 50MB video
        const maxSize = isVideo ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
        if (file.size > maxSize) {
          return Response.json({ ok: false, error: `Max ${isVideo ? '50MB' : '10MB'}` }, { status: 400, headers: cors });
        }

        const mediaType = isVideo ? 'video' : 'image';
        const prefix = isVideo ? 'videos' : 'images';
        const ext = isVideo ? (file.type === 'video/webm' ? 'webm' : 'mp4') : 'webp';
        const originalName = file.name.replace(/\.[^.]+$/, '').toLowerCase().replace(/[^a-z0-9-]/g, '-');
        const filename = `${originalName}.${ext}`;
        const key = `${prefix}/${filename}`;

        // Store main file in R2
        await env.IMAGES.put(key, file.stream(), {
          httpMetadata: { contentType: file.type },
          customMetadata: { category, alt_text, media_type: mediaType }
        });

        // Handle thumbnail for videos
        let thumbnailKey: string | null = null;
        if (isVideo && thumbnail && thumbnail.type.startsWith('image/')) {
          const thumbExt = thumbnail.type === 'image/png' ? 'png' : 'webp';
          thumbnailKey = `thumbnails/${originalName}.${thumbExt}`;
          await env.IMAGES.put(thumbnailKey, thumbnail.stream(), {
            httpMetadata: { contentType: thumbnail.type },
          });
        }

        const assetUrl = `/${key}`;

        // Register in DB
        const result = await env.DB.prepare(
          `INSERT INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags, media_type, thumbnail_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).bind(key, filename, alt_text, file.type, file.size, category, tags, mediaType, thumbnailKey).run();

        const id = result.meta.last_row_id;

        return Response.json({ ok: true, data: { id, key, url: assetUrl, filename, category, media_type: mediaType, thumbnail_key: thumbnailKey } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== POST /api/media — Upload media (shorthand, same as /upload) =====
  {
    pattern: /^\/api\/media\/?$/,
    methods: ['POST'],
    handler: async (req, env, ctx) => {
      try {
        const formData = await req.formData();
        const file = formData.get('file') as File;
        const thumbnail = formData.get('thumbnail') as File | null;
        const category = (formData.get('category') as string) || 'generic';
        const alt_text = (formData.get('alt_text') as string) || '';
        const tags = (formData.get('tags') as string) || '[]';

        if (!file) return Response.json({ ok: false, error: 'No file provided' }, { status: 400, headers: cors });

        const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
        const VIDEO_TYPES = ['video/mp4', 'video/webm'];
        const ALL_IMAGE = [...IMAGE_TYPES, 'image/gif', 'image/svg+xml'];
        const isVideo = VIDEO_TYPES.includes(file.type);
        const isImage = ALL_IMAGE.includes(file.type) || file.type.startsWith('image/');

        if (!isVideo && !isImage) {
          return Response.json({ ok: false, error: 'Invalid type. Allowed: JPEG, PNG, WebP, GIF, SVG, MP4, WebM' }, { status: 400, headers: cors });
        }

        const maxSize = isVideo ? 50 * 1024 * 1024 : 10 * 1024 * 1024;
        if (file.size > maxSize) {
          return Response.json({ ok: false, error: `Max ${isVideo ? '50MB' : '10MB'}` }, { status: 400, headers: cors });
        }

        const mediaType = isVideo ? 'video' : 'image';
        const prefix = isVideo ? 'videos' : 'images';
        const ext = isVideo ? (file.type === 'video/webm' ? 'webm' : 'mp4') : 'webp';
        const originalName = file.name.replace(/\.[^.]+$/, '').toLowerCase().replace(/[^a-z0-9-]/g, '-');
        const filename = `${originalName}.${ext}`;
        const key = `${prefix}/${filename}`;

        await env.IMAGES.put(key, file.stream(), {
          httpMetadata: { contentType: file.type },
          customMetadata: { category, alt_text, media_type: mediaType }
        });

        let thumbnailKey: string | null = null;
        if (isVideo && thumbnail && thumbnail.type.startsWith('image/')) {
          const thumbExt = thumbnail.type === 'image/png' ? 'png' : 'webp';
          thumbnailKey = `thumbnails/${originalName}.${thumbExt}`;
          await env.IMAGES.put(thumbnailKey, thumbnail.stream(), {
            httpMetadata: { contentType: thumbnail.type },
          });
        }

        const assetUrl = `/${key}`;
        const result = await env.DB.prepare(
          `INSERT INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags, media_type, thumbnail_key) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).bind(key, filename, alt_text, file.type, file.size, category, tags, mediaType, thumbnailKey).run();

        const id = result.meta.last_row_id;

        return Response.json({ ok: true, data: { id, key, url: assetUrl, filename, category, media_type: mediaType, thumbnail_key: thumbnailKey } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== PUT /api/media/:id — Update image metadata =====
  {
    pattern: /^\/api\/media\/(\d+)$/,
    methods: ['PUT'],
    handler: async (req, env, ctx, match) => {
      const id = match[1];
      try {
        const body = await req.json() as any;
        const { alt_text, tags, category, filename } = body;

        const { title, caption, focal_point, media_type } = body;

        await env.DB.prepare(
          `UPDATE media_library SET
            alt_text = COALESCE(?, alt_text),
            tags = COALESCE(?, tags),
            category = COALESCE(?, category),
            filename = COALESCE(?, filename),
            title = COALESCE(?, title),
            caption = COALESCE(?, caption),
            focal_point = COALESCE(?, focal_point),
            media_type = COALESCE(?, media_type)
          WHERE id = ?`
        ).bind(
          alt_text || null, tags || null, category || null, filename || null,
          title || null, caption || null, focal_point || null, media_type || null,
          id
        ).run();

        return Response.json({ ok: true }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== DELETE /api/media/:id — Delete image =====
  {
    pattern: /^\/api\/media\/(\d+)$/,
    methods: ['DELETE'],
    handler: async (req, env, ctx, match) => {
      const id = match[1];
      try {
        const media = await env.DB.prepare(`SELECT key FROM media_library WHERE id = ?`).bind(id).first();
        if (!media) return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: cors });

        // Delete from R2
        await env.IMAGES.delete(media.key);
        // Delete assignments (CASCADE should handle this but be explicit)
        await env.DB.prepare(`DELETE FROM media_entities WHERE media_id = ?`).bind(id).run();
        // Delete from library
        await env.DB.prepare(`DELETE FROM media_library WHERE id = ?`).bind(id).run();

        return Response.json({ ok: true }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== POST /api/media/:id/assign — Assign image to entity =====
  {
    pattern: /^\/api\/media\/(\d+)\/assign$/,
    methods: ['POST'],
    handler: async (req, env, ctx, match) => {
      const mediaId = parseInt(match[1]);
      try {
        const body = await req.json() as any;
        const { entity_type, entity_slug, usage } = body;

        if (!entity_type || !entity_slug || !usage) {
          return Response.json({ ok: false, error: 'entity_type, entity_slug and usage are required' }, { status: 400, headers: cors });
        }

        // If usage is 'hero', unassign existing hero for this entity
        if (usage === 'hero') {
          await env.DB.prepare(
            `DELETE FROM media_entities WHERE entity_type = ? AND entity_slug = ? AND usage = ?`
          ).bind(entity_type, entity_slug, usage).run();
        }

        await env.DB.prepare(
          `INSERT OR REPLACE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES (?, ?, ?, ?)`
        ).bind(mediaId, entity_type, entity_slug, usage).run();

        // Get the media key for the response
        const media = await env.DB.prepare(`SELECT key FROM media_library WHERE id = ?`).bind(mediaId).first();

        return Response.json({ ok: true, data: { media_id: mediaId, entity_type, entity_slug, usage, key: media?.key } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== POST /api/media/:id/unassign — Unassign image from entity =====
  {
    pattern: /^\/api\/media\/(\d+)\/unassign$/,
    methods: ['POST'],
    handler: async (req, env, ctx, match) => {
      const mediaId = parseInt(match[1]);
      try {
        const body = await req.json() as any;
        const { entity_type, entity_slug, usage } = body;

        await env.DB.prepare(
          `DELETE FROM media_entities WHERE media_id = ? AND entity_type = ? AND entity_slug = ? AND usage = ?`
        ).bind(mediaId, entity_type, entity_slug, usage).run();

        return Response.json({ ok: true }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== POST /api/media/youtube — Add YouTube video =====
  {
    pattern: /^\/api\/media\/youtube$/,
    methods: ['POST'],
    handler: async (req, env, ctx) => {
      try {
        const body = await req.json() as any;
        const { youtube_url, category, alt_text } = body;

        if (!youtube_url) return Response.json({ ok: false, error: 'Missing youtube_url' }, { status: 400, headers: cors });

        // Extract YouTube video ID
        const idMatch = youtube_url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
        if (!idMatch) return Response.json({ ok: false, error: 'Invalid YouTube URL' }, { status: 400, headers: cors });

        const videoId = idMatch[1];

        // Check if already exists
        const existing = await env.DB.prepare('SELECT id FROM media_library WHERE youtube_id = ?').bind(videoId).first();
        if (existing) return Response.json({ ok: false, error: 'Este video de YouTube ya existe en la biblioteca' }, { status: 409, headers: cors });

        // Try to get title from oEmbed (no API key needed)
        let title = body.title || '';
        try {
          const oembedRes = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`);
          if (oembedRes.ok) {
            const oembed = await oembedRes.json() as any;
            title = title || oembed.title || `YouTube Video ${videoId}`;
          }
        } catch { /* use default title */ }
        if (!title) title = `YouTube Video ${videoId}`;

        // Download YouTube thumbnail and store in R2
        const thumbUrl = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
        let thumbnailKey: string | null = null;
        try {
          const thumbRes = await fetch(thumbUrl);
          if (thumbRes.ok && thumbRes.body) {
            thumbnailKey = `thumbnails/yt-${videoId}.jpg`;
            await env.IMAGES.put(thumbnailKey, thumbRes.body, {
              httpMetadata: { contentType: 'image/jpeg' },
            });
          }
        } catch { /* thumbnail fetch failed, skip */ }

        const safeFilename = title.substring(0, 60).replace(/[^a-z0-9\s-]/gi, '').replace(/\s+/g, '-').toLowerCase() || videoId;
        const filename = `${safeFilename}.youtube`;
        const key = `videos/yt-${videoId}`;

        // Register in DB
        const result = await env.DB.prepare(
          `INSERT INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags, media_type, thumbnail_key, youtube_url, youtube_id)
           VALUES (?, ?, ?, 'video/youtube', 0, ?, '[]', 'video', ?, ?, ?)`
        ).bind(key, filename, alt_text || title, category || 'video', thumbnailKey, youtube_url, videoId).run();

        const id = result.meta.last_row_id;

        return Response.json({
          ok: true,
          data: { id, key, filename, category: category || 'video', media_type: 'video', mime_type: 'video/youtube',
                  youtube_url, youtube_id: videoId, thumbnail_key: thumbnailKey, title }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },

  // ===== POST /api/media/staff-upload — Upload foto del personal (Fase 1) =====
  {
    pattern: /^\/api\/media\/staff-upload$/,
    methods: ['POST'],
    handler: async (req, env, ctx) => {
      try {
        const formData = await req.formData();
        const file = formData.get('file') as File;
        const staffName = (formData.get('staff_name') as string)?.trim();
        const location = (formData.get('location') as string)?.trim();
        const incidentDate = (formData.get('incident_date') as string) || new Date().toISOString().split('T')[0];
        const notes = (formData.get('notes') as string)?.trim() || '';

        if (!file) return Response.json({ ok: false, error: 'No file provided' }, { status: 400, headers: cors });
        if (!staffName) return Response.json({ ok: false, error: 'staff_name is required' }, { status: 400, headers: cors });

        const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif'];
        const isImage = ALLOWED_TYPES.includes(file.type) || file.type.startsWith('image/');
        if (!isImage) {
          return Response.json({ ok: false, error: 'Invalid type. Allowed: JPEG, PNG, WebP, HEIC' }, { status: 400, headers: cors });
        }

        const maxSize = 20 * 1024 * 1024; // 20MB para fotos del personal
        if (file.size > maxSize) {
          return Response.json({ ok: false, error: 'Max 20MB' }, { status: 400, headers: cors });
        }

        // Determinar extensión (preservar la original para staff raw)
        const extMap: Record<string, string> = {
          'image/jpeg': '.jpg', 'image/png': '.png',
          'image/webp': '.webp', 'image/heic': '.heic', 'image/heif': '.heif',
        };
        const ext = extMap[file.type] || '.jpg';
        
        const safeName = staffName.toLowerCase().replace(/[^a-z0-9]/g, '-').substring(0, 30);
        const loc = location ? location.toLowerCase().replace(/[^a-z0-9]/g, '-').substring(0, 30) : 'sin-ubicacion';
        const prefix = `images/staff-raw`;
        const key = `${prefix}/${Date.now()}-${safeName}-${loc}${ext}`;

        // Guardar en R2
        await env.IMAGES.put(key, file.stream(), {
          httpMetadata: { contentType: file.type },
          customMetadata: { category: 'staff-raw', staff_name: staffName, location: loc, notes },
        });

        // Registrar en D1 con los nuevos campos
        const result = await env.DB.prepare(
          `INSERT INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags, media_type, staff_name, incident_date, location_slug)
           VALUES (?, ?, ?, ?, ?, 'staff-raw', '["staff-photo"]', 'image', ?, ?, ?)`
        ).bind(
          key, `${safeName}-${loc}${ext}`, notes || `Foto de ${staffName} - ${loc}`,
          file.type, file.size,
          staffName, incidentDate, location || null
        ).run();

        const id = result.meta.last_row_id as number;

        return Response.json({
          ok: true,
          data: {
            id, key, filename: `${safeName}-${loc}${ext}`,
            category: 'staff-raw', media_type: 'image',
            mime_type: file.type, file_size: file.size,
            staff_name: staffName, location: location || null, incident_date: incidentDate,
            url: `/${key}`,
          }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== GET /api/media/staff-raw — Listar fotos del personal (Fase 1) =====
  {
    pattern: /^\/api\/media\/staff-raw$/,
    methods: ['GET'],
    handler: async (req, env, ctx) => {
      const url = new URL(req.url);
      const staffName = url.searchParams.get('staff_name');
      const location = url.searchParams.get('location');
      const dateFrom = url.searchParams.get('date_from');
      const dateTo = url.searchParams.get('date_to');
      const search = url.searchParams.get('q');
      const limit = Math.min(parseInt(url.searchParams.get('limit') || '100'), 500);
      const offset = parseInt(url.searchParams.get('offset') || '0');

      try {
        let sql = `SELECT * FROM media_library WHERE category = 'staff-raw'`;
        const binds: any[] = [];

        if (staffName)  { sql += ` AND staff_name LIKE ?`; binds.push(`%${staffName}%`); }
        if (location)   { sql += ` AND location_slug = ?`; binds.push(location); }
        if (dateFrom)   { sql += ` AND incident_date >= ?`; binds.push(dateFrom); }
        if (dateTo)     { sql += ` AND incident_date <= ?`; binds.push(dateTo); }
        if (search)     { sql += ` AND (alt_text LIKE ? OR staff_name LIKE ? OR location_slug LIKE ?)`; binds.push(`%${search}%`, `%${search}%`, `%${search}%`); }

        sql += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
        binds.push(limit, offset);

        const { results } = await env.DB.prepare(sql).bind(...binds).all();

        // Contar total
        let countSql = `SELECT COUNT(*) as total FROM media_library WHERE category = 'staff-raw'`;
        const countBinds: any[] = [];
        if (staffName)  { countSql += ` AND staff_name LIKE ?`; countBinds.push(`%${staffName}%`); }
        if (location)   { countSql += ` AND location_slug = ?`; countBinds.push(location); }
        if (dateFrom)   { countSql += ` AND incident_date >= ?`; countBinds.push(dateFrom); }
        if (dateTo)     { countSql += ` AND incident_date <= ?`; countBinds.push(dateTo); }
        if (search)     { countSql += ` AND (alt_text LIKE ? OR staff_name LIKE ? OR location_slug LIKE ?)`; countBinds.push(`%${search}%`, `%${search}%`, `%${search}%`); }
        const { results: countResults } = await env.DB.prepare(countSql).bind(...countBinds).all();

        return Response.json({ ok: true, data: results, total: countResults[0]?.total || 0 }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  // ===== POST /api/media/bulk-assign — Bulk assign one image to multiple entities =====
  {
    pattern: /^\/api\/media\/bulk-assign$/,
    methods: ['POST'],
    handler: async (req, env, ctx) => {
      try {
        const body = await req.json() as any;
        const { media_id, assignments } = body; // assignments: [{entity_type, entity_slug, usage}]

        if (!media_id || !Array.isArray(assignments)) {
          return Response.json({ ok: false, error: 'media_id and assignments[] required' }, { status: 400, headers: cors });
        }

        let assigned = 0;
        for (const a of assignments) {
          if (!a.entity_type || !a.entity_slug || !a.usage) continue;

          if (a.usage === 'hero') {
            await env.DB.prepare(
              `DELETE FROM media_entities WHERE entity_type = ? AND entity_slug = ? AND usage = ?`
            ).bind(a.entity_type, a.entity_slug, a.usage).run();
          }

          await env.DB.prepare(
            `INSERT OR REPLACE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES (?, ?, ?, ?)`
          ).bind(media_id, a.entity_type, a.entity_slug, a.usage).run();
          assigned++;
        }

        return Response.json({ ok: true, data: { assigned } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    },
  },
];
