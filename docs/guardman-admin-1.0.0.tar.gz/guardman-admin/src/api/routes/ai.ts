// GuardMan Admin — AI Generation Route (v5.2 — unified pipeline)
import { CORS_HEADERS } from '../../types';
import { calculateContentScore } from '../../services/scoring';
import { generateContent } from '../../services/content-generation';
import { invalidateCache } from '../../services/cache';
import { getLocationSlugs, parseComboSlug } from '../../utils/location';

const cors = CORS_HEADERS;

export const aiRoutes = [
  {
    pattern: /^\/api\/ai\/generate$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

    if (path === '/api/ai/generate' && method === 'POST') {
      const body = await request.json() as any;
      let { entity_type, entity_slug, entity_name } = body;
      const originalEntityType = entity_type;
      const originalEntitySlug = entity_slug;

      // Invalidate content caches on new generation
      await invalidateCache(env.CACHE, 'content:');
      await invalidateCache(env.CACHE, 'preview-');

      let comboServiceSlug = '';
      let comboLocationSlug = '';
      if (entity_type === 'combo') {
        if (body.combo_service_slug && body.combo_location_slug) {
          comboServiceSlug = body.combo_service_slug;
          comboLocationSlug = body.combo_location_slug;
        } else {
          const locationNames = await getLocationSlugs(env.DB);
          const { serviceSlug, locationSlug } = parseComboSlug(entity_slug, locationNames);
          if (locationSlug) {
            comboLocationSlug = locationSlug;
            comboServiceSlug = serviceSlug;
          } else {
            return Response.json({ ok: false, error: 'Combo slug format not recognized: ' + entity_slug }, { status: 400, headers: cors });
          }
        }
        const locationName = comboLocationSlug.split('-').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
        entity_type = 'service';
        entity_name = entity_name + ' en ' + locationName;
        entity_slug = comboServiceSlug + '-' + comboLocationSlug;
      }

      // Load current content for context
      let currentContent = null;
      let currentScore: any = null;
      let previousWasManual = false;
      try {
        if (originalEntityType === 'combo' && comboServiceSlug && comboLocationSlug) {
          const comboRow = await env.DB.prepare('SELECT seo_title, meta_description, h1, intro_paragraph, faqs_json, cta_text, cta_button, status, word_count FROM combo_content WHERE service_slug = ? AND location_slug = ?').bind(comboServiceSlug, comboLocationSlug).first();
          if (comboRow) {
            const sections: any = {};
            if (comboRow.h1) { sections.hero = { heading: comboRow.h1, subheading: comboRow.cta_text || '' }; }
            if (comboRow.intro_paragraph) { sections.intro = { heading: comboRow.h1 || '', paragraphs: [comboRow.intro_paragraph] }; }
            if (comboRow.seo_title) { sections.meta = { title: comboRow.seo_title, description: comboRow.meta_description || '' }; }
            if (comboRow.cta_heading || comboRow.cta_text) { sections.cta = { heading: comboRow.cta_text || '', subheading: '', button: comboRow.cta_button || '' }; }
            if (comboRow.faqs_json) { try { sections.faqs = { items: JSON.parse(comboRow.faqs_json) }; } catch {} }
            if (Object.keys(sections).length > 0) {
              currentContent = { sections };
              previousWasManual = comboRow.status === 'approved';
            }
          }
        } else {
          const latestResult = await env.DB.prepare('SELECT content_json, generated_by FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1').bind(entity_type, entity_slug).first();
          if (latestResult?.content_json) {
            currentContent = JSON.parse(latestResult.content_json);
            previousWasManual = latestResult.generated_by === 'manual';
          }
        }
        if (currentContent) {
          currentScore = calculateContentScore(currentContent);
        }
      } catch(e) { /* ignore */ }

      // === UNIFIED PIPELINE: generate with 4-layer quality ===
      const MAX_ATTEMPTS = 3;
      let bestResult: any = null;
      let bestScore = 0;
      let bestAttempt = 0;
      let lastError: string | null = null;

      for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
        try {
          const result = await generateContent(env, entity_type, entity_slug, entity_name, {
            currentContent,
            currentScore,
            previousWasManual,
          });

          if (result.score > bestScore) {
            bestResult = result;
            bestScore = result.score;
            bestAttempt = attempt;
          }

          if (result.score >= 75) break;
          if (attempt < MAX_ATTEMPTS && result.content) {
            currentScore = { score: result.score, details: calculateContentScore(result.content).details };
            currentContent = result.content;
          }
        } catch (err: any) {
          lastError = err.message;
        }
      }

      if (!bestResult) {
        return Response.json({ ok: false, error: lastError || 'All generation attempts failed' }, { status: 500, headers: cors });
      }

      const bestContent = bestResult.content;
      const finalScore = bestResult.score;
      const finalDetails = calculateContentScore(bestContent);
      const wordCount = JSON.stringify(bestContent).split(/\s+/).length;
      const shouldSave = !currentScore || previousWasManual === false || finalScore > currentScore.score;

      // Save content
      if (originalEntityType === 'combo' && comboServiceSlug && comboLocationSlug) {
        const s = bestContent.sections || bestContent;
        const contentJsonStr = JSON.stringify(bestContent);
        await env.DB.prepare(`INSERT INTO combo_content (service_slug, location_slug, seo_title, meta_description, h1, intro_paragraph, local_context, faqs_json, cta_text, cta_button, status, word_count, generated_at, content_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, datetime('now'), ?) ON CONFLICT(service_slug, location_slug) DO UPDATE SET seo_title=excluded.seo_title, meta_description=excluded.meta_description, h1=excluded.h1, intro_paragraph=excluded.intro_paragraph, local_context=excluded.local_context, faqs_json=excluded.faqs_json, cta_text=excluded.cta_text, cta_button=excluded.cta_button, status='draft', word_count=excluded.word_count, generated_at=datetime('now'), updated_at=datetime('now'), content_json=excluded.content_json`).bind(
          comboServiceSlug, comboLocationSlug,
          s.meta?.title || '', s.meta?.description || '',
          s.hero?.heading || '', (s.intro?.paragraphs || []).join('\n'),
          s.cta?.subheading || '',
          s.faqs?.items ? JSON.stringify(s.faqs.items) : null,
          s.cta?.heading || '', s.cta?.button || '',
          wordCount,
          contentJsonStr
        ).run();

        // Save lesson
        try {
          await env.DB.prepare(`INSERT INTO content_lessons (entity_type, entity_slug, score, feedback, improvements) VALUES (?, ?, ?, ?, ?)`).bind(
            'combo', `${comboServiceSlug}-${comboLocationSlug}`, finalScore,
            JSON.stringify(bestResult.review || {}), JSON.stringify(bestResult.review?.suggestions || [])
          ).run();
        } catch { /* non-critical */ }

        return Response.json({ ok: true, data: {
          content: bestContent, wordCount,
          previousScore: currentScore, newScore: finalScore,
          newDetails: finalDetails.details,
          attempts: bestAttempt,
          improved: currentScore ? finalScore > currentScore.score : true,
          savedTo: 'combo_content',
          comboServiceSlug, comboLocationSlug,
          qualityPipeline: {
            passed: bestResult.passed,
            violations: bestResult.violations,
            genericPhrases: bestResult.genericPhrases,
            review: bestResult.review,
          },
        }}, { headers: cors });
      }

      // Service/location/sector pages
      const shouldSaveToVersions = shouldSave || finalScore >= (currentScore?.score || 0);
      if (shouldSaveToVersions) {
        const versionResult = await env.DB.prepare('SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?').bind(entity_type, entity_slug).first();
        const nextVersion = versionResult?.next_version || 1;
        const result = await env.DB.prepare('INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count) VALUES (?, ?, ?, ?, ?, ?)').bind(entity_type, entity_slug, nextVersion, JSON.stringify(bestContent), 'ai', wordCount).run();

        // Save lesson
        try {
          await env.DB.prepare(`INSERT INTO content_lessons (entity_type, entity_slug, score, feedback, improvements) VALUES (?, ?, ?, ?, ?)`).bind(
            entity_type, entity_slug, finalScore,
            JSON.stringify(bestResult.review || {}), JSON.stringify(bestResult.review?.suggestions || [])
          ).run();
        } catch { /* non-critical */ }

        return Response.json({ ok: true, data: {
          id: result.meta.last_row_id, version: nextVersion,
          content: bestContent, wordCount,
          previousScore: currentScore, newScore: finalScore,
          newDetails: finalDetails.details,
          attempts: bestAttempt,
          improved: currentScore ? finalScore > currentScore.score : true,
          qualityPipeline: {
            passed: bestResult.passed,
            violations: bestResult.violations,
            genericPhrases: bestResult.genericPhrases,
            review: bestResult.review,
          },
        }}, { headers: cors });
      } else {
        return Response.json({ ok: true, data: {
          content: bestContent, wordCount,
          previousScore: currentScore, newScore: finalScore,
          newDetails: finalDetails.details,
          attempts: bestAttempt,
          saved: false, reason: 'score_not_improved',
          message: 'Score (' + finalScore + ') no supera manual (' + currentScore.score + '). Contenido preservado.',
          qualityPipeline: {
            passed: bestResult.passed,
            violations: bestResult.violations,
            genericPhrases: bestResult.genericPhrases,
            review: bestResult.review,
          },
        }}, { headers: cors });
      }
    }

      return null;
    },
  },
];
