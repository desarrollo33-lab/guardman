// GuardMan Admin — Orchestrator Routes (PASO 2 fix: correct Think SDK chat API)
// Uses RpcTarget-based StreamCallback for cross-RPC-boundary communication with Think DO
import { RpcTarget } from 'cloudflare:workers';
import { CORS_HEADERS } from '../../types/index';
import { isAISearchAvailable } from '../../services/search';

const cors = CORS_HEADERS;

/**
 * StreamCallback implementation as RpcTarget — required for Think SDK chat() RPC.
 * Plain objects lose their methods when crossing the DO RPC boundary;
 * RpcTarget preserves the proxy so the DO can call back into our methods.
 */
class ChatStreamCallback extends RpcTarget {
  private onEventFn: (json: string) => void | Promise<void>;
  private onDoneFn: () => void | Promise<void>;
  private onErrorFn: (error: string) => void | Promise<void>;

  constructor(
    onEvent: (json: string) => void | Promise<void>,
    onDone: () => void | Promise<void>,
    onError: (error: string) => void | Promise<void>,
  ) {
    super();
    this.onEventFn = onEvent;
    this.onDoneFn = onDone;
    this.onErrorFn = onError;
  }

  onEvent(json: string): void | Promise<void> {
    return this.onEventFn(json);
  }

  onDone(): void | Promise<void> {
    return this.onDoneFn();
  }

  onError(error: string): void | Promise<void> {
    return this.onErrorFn(error);
  }
}

export const orchestratorRoutes = [
  {
    pattern: /^\/api\/orchestrator\/.+/,
    methods: ['GET', 'POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

      // WebSocket upgrade — forward to Think DO (Think handles WS internally)
      if (path === '/api/orchestrator/ws' && method === 'GET') {
        const id = env.ORCHESTRATOR.idFromName('default');
        const doUrl = new URL(request.url);
        doUrl.hostname = `${id.toString()}.${doUrl.hostname}`;
        doUrl.protocol = 'https:';
        return fetch(doUrl.toString(), request);
      }

      // POST /api/orchestrator/chat - Chat via Think DO using correct RPC API
      if (path === '/api/orchestrator/chat' && method === 'POST') {
        try {
          const body = await request.json() as any;
          const { message, session_id, stream: wantStream } = body;
          if (!message) {
            return Response.json({ ok: false, error: 'message required' }, { status: 400, headers: cors });
          }

          const id = env.ORCHESTRATOR.idFromName('default');
          const stub = env.ORCHESTRATOR.get(id);

          // Initialize the DO: setName triggers onStart() which initializes session
          // Using _initAndFetch combines setName + fetch in one RPC call
          try {
            await stub._initAndFetch('default', undefined, new Request('https://do/ping'));
          } catch (initErr: any) {
            // _initAndFetch may 404 — that's fine, the init still happens
            console.log('[orchestrator/chat] Init ping:', initErr?.message || 'ok');
          }

          // NO clearMessages() — session was corrupted by previous models;
          // after fresh deploy + one reset call, the session will be clean.

          // Streaming SSE response
          if (wantStream) {
            const stream = new ReadableStream({
              async start(controller) {
                const encoder = new TextEncoder();
                const send = (event: string, data: any) => {
                  try {
                    controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
                  } catch {}
                };
                send('status', { state: 'processing' });

                // Timeout guard: 180s (reasoning models can take 90-120s)
                const timeoutId = setTimeout(() => {
                  console.error('[orchestrator/chat] Streaming timeout after 180s');
                  send('error', { message: 'Request timed out after 180 seconds' });
                  try { controller.close(); } catch {}
                }, 180000);

                try {
                  let fullText = '';
                  let reasoning = '';
                  let tools: string[] = [];

                  // Create RpcTarget-based callback — this is the critical fix
                  const callback = new ChatStreamCallback(
                    // onEvent: Think streams UIMessage chunks as JSON strings
                    (json: string) => {
                      try {
                        const parsed = JSON.parse(json);
                        // Handle different event types from Think's streamText → toUIMessageStream
                        if (parsed.type === 'text-delta' && parsed.textDelta) {
                          fullText += parsed.textDelta;
                          send('chunk', { type: 'text-delta', textDelta: parsed.textDelta });
                        }
                        if (parsed.type === 'reasoning-delta' && parsed.delta) {
                          reasoning += parsed.delta;
                          send('chunk', { type: 'reasoning-delta', delta: parsed.delta });
                        }
                        if (parsed.type === 'tool-call' && parsed.toolName) {
                          tools.push(parsed.toolName);
                          send('chunk', { type: 'tool-call', toolName: parsed.toolName });
                        }
                        if (parsed.type === 'tool-result') {
                          send('chunk', { type: 'tool-result', toolName: parsed.toolName });
                        }
                        // Final complete message
                        if (parsed.type === 'message') {
                          const text = extractTextFromUIMessage(parsed);
                          if (text) fullText = text;
                          send('chunk', { type: 'message', response: fullText, tools_used: tools });
                        }
                        // Catch-all: forward any other events
                        if (parsed.type && parsed.type !== 'text-delta' && parsed.type !== 'tool-call' && parsed.type !== 'tool-result' && parsed.type !== 'message') {
                          send('chunk', parsed);
                        }
                      } catch (parseErr: any) {
                        console.error('[orchestrator/chat] onEvent parse error:', parseErr?.message || parseErr);
                      }
                    },
                    // onDone: streaming complete (DO NOT close stream here — we need to run fallback first)
                    () => {
                      clearTimeout(timeoutId);
                      // Don't send 'done' yet — we'll send it after fallback below
                    },
                    // onError: Think reported an error
                    (error: string) => {
                      clearTimeout(timeoutId);
                      console.error('[orchestrator/chat] Think SDK onError:', error);
                      send('error', { message: error });
                    },
                  );

                  // Call Think's chat() — this is the correct RPC API
                  await stub.chat(message, callback);

                  // After chat() completes, get the actual response from Think's messages
                  // DeepSeek may emit text-start/text-end without text-delta in streaming mode,
                  // but Think stores the full assistant message internally.
                  if (!fullText) {
                    try {
                      const messages = await stub.getMessages();
                      if (Array.isArray(messages) && messages.length > 0) {
                        // Find the last assistant message
                        for (let i = messages.length - 1; i >= 0; i--) {
                          const msg = messages[i] as any;
                          if (msg.role === 'assistant') {
                            const text = extractTextFromUIMessage(msg);
                            if (text) {
                              fullText = text;
                              // Send the recovered text as a final text-delta chunk
                              send('chunk', { type: 'text-delta', textDelta: text });
                              break;
                            }
                          }
                        }
                      }
                    } catch {}
                  }

                  // Now send done with the final response
                  clearTimeout(timeoutId);
                  const response = fullText || reasoning || '';
                  send('done', { response, tools_used: tools });
                } catch (err: any) {
                  clearTimeout(timeoutId);
                  console.error('[orchestrator/chat] Streaming chat error:', err?.message || err);
                  send('error', { message: err.message || 'Internal streaming error' });
                } finally {
                  try { controller.close(); } catch {}
                }
              },
            });

            return new Response(stream, {
              headers: {
                'Content-Type': 'text/event-stream',
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                ...cors,
              },
            });
          }

          // Non-streaming: collect full response via RpcTarget callback
          let finalText = '';
          let reasoningText = '';
          let toolsUsed: string[] = [];

          const callback = new ChatStreamCallback(
            (json: string) => {
              try {
                const parsed = JSON.parse(json);
                if (parsed.type === 'text-delta' && parsed.textDelta) {
                  finalText += parsed.textDelta;
                }
                if (parsed.type === 'reasoning-delta' && parsed.delta) {
                  reasoningText += parsed.delta;
                }
                if (parsed.type === 'tool-call' && parsed.toolName) {
                  toolsUsed.push(parsed.toolName);
                }
                if (parsed.type === 'message') {
                  const text = extractTextFromUIMessage(parsed);
                  if (text) finalText = text;
                }
              } catch {}
            },
            () => {}, // onDone — we await the chat() promise anyway
            (err: string) => {
              console.error('[orchestrator/chat] Non-stream Think SDK onError:', err);
            },
          );

          // 180s timeout for non-streaming (reasoning models need more time)
          await Promise.race([
            stub.chat(message, callback),
            new Promise((_, reject) => setTimeout(() => reject(new Error('Chat request timed out after 180 seconds')), 180000)),
          ]);

          // After chat() completes, get the actual response from Think's messages
          // The stream events may not include text-delta (workers-ai-provider streaming bug),
          // but Think stores the full assistant message internally.
          if (!finalText) {
            try {
              const messages = await stub.getMessages();
              if (Array.isArray(messages) && messages.length > 0) {
                for (let i = messages.length - 1; i >= 0; i--) {
                  const msg = messages[i] as any;
                  if (msg.role === 'assistant') {
                    const text = extractTextFromUIMessage(msg);
                    if (text) {
                      finalText = text;
                      break;
                    }
                  }
                }
              }
            } catch {}
          }

          // If model only produced reasoning but no text, use reasoning as response
          const response = finalText || reasoningText || '';
          return Response.json(
            { ok: true, data: { response: response || 'Sin respuesta', tools_used: toolsUsed } },
            { headers: cors },
          );
        } catch (err: any) {
          console.error('[orchestrator/chat] Fatal error:', err?.message || err);
          return Response.json({ ok: false, error: err.message || 'Internal server error' }, { status: 500, headers: cors });
        }
      }

      // GET /api/orchestrator/status — Think session info
      if (path === '/api/orchestrator/status' && method === 'GET') {
        try {
          const id = env.ORCHESTRATOR.idFromName('default');
          const stub = env.ORCHESTRATOR.get(id);

          // Initialize the DO first
          try {
            await stub._initAndFetch('default', undefined, new Request('https://do/ping'));
          } catch {}

          // Use getMessages() RPC to get message count
          let messageCount = 0;
          try {
            const messages = await stub.getMessages();
            messageCount = Array.isArray(messages) ? messages.length : 0;
          } catch (msgErr: any) {
            console.warn('[orchestrator/status] getMessages failed:', msgErr?.message || msgErr);
            try {
              const doResponse = await stub.fetch(new Request('https://do/status'));
              const doData = await doResponse.json() as any;
              messageCount = doData?.messages?.length || 0;
            } catch {}
          }

          return Response.json({
            ok: true,
            data: {
              messageCount,
              ai_search: isAISearchAvailable(env),
              type: 'think-agent',
            },
          }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // POST /api/orchestrator/clear — Clear corrupted session messages (admin maintenance)
      if (path === '/api/orchestrator/clear' && method === 'POST') {
        try {
          const id = env.ORCHESTRATOR.idFromName('default');
          const stub = env.ORCHESTRATOR.get(id);

          try {
            await stub._initAndFetch('default', undefined, new Request('https://do/ping'));
          } catch {}

          try {
            await stub.clearMessages();
          } catch (e: any) {
            return Response.json({ ok: false, error: `clearMessages failed: ${e?.message || e}` }, { status: 500, headers: cors });
          }

          return Response.json({ ok: true, message: 'Session messages cleared' }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // No match
      return null;
    },
  },
];

/**
 * Extract text content from a UIMessage object.
 * UIMessage has parts: [{ type: "text", text: "..." }, ...]
 */
function extractTextFromUIMessage(msg: any): string {
  if (msg.text) return msg.text;
  if (msg.content) return typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content);
  if (Array.isArray(msg.parts)) {
    return msg.parts
      .filter((p: any) => p.type === 'text')
      .map((p: any) => p.text)
      .join('');
  }
  return '';
}
