// GuardMan · API del Cuestionario de ADN de Marca — CEO Rodrigo Mora
// Patrón basado en dcr-motors-mvp brand-dna.astro
// Endpoints:
//   GET    /api/cuestionario-ceo                  → estado completo (sections + questions + answers + services)
//   GET    /api/cuestionario-ceo/sections         → solo secciones con stats
//   GET    /api/cuestionario-ceo/section/:id      → preguntas de una sección
//   POST   /api/cuestionario-ceo/answer           → guardar/actualizar respuesta
//   POST   /api/cuestionario-ceo/session          → registrar/iniciar sesión
//   PATCH  /api/cuestionario-ceo/section/:id      → marcar sección como completada
//   GET    /api/cuestionario-ceo/export           → exportar todo (JSON)
//   POST   /api/cuestionario-ceo/message          → nota libre en conversation
//
//   GET    /api/cuestionario-ceo/services         → catálogo dinámico de servicios (CRUD)
//   POST   /api/cuestionario-ceo/service          → crear servicio
//   PUT    /api/cuestionario-ceo/service/:id      → actualizar servicio
//   DELETE /api/cuestionario-ceo/service/:id      → eliminar (soft) o archivar servicio

import { cors } from '../index';

const SECTIONS = ['identidad', 'servicios', 'comercial', 'personas', 'diferenciacion'];

function genId() {
  return 'svc_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function safeJSON(s: any, fallback: any = null) {
  if (!s) return fallback;
  try { return typeof s === 'string' ? JSON.parse(s) : s; }
  catch { return fallback; }
}

function parseQuestion(row: any) {
  return {
    id: row.id,
    section_id: row.section_id,
    sort_order: row.sort_order,
    type: row.type,
    question: row.question_es,
    subtitle: row.subtitle_es,
    options: safeJSON(row.options_json, []),
    helper: row.helper_text,
    objective: row.objective_es,
    required: row.required === 1
  };
}

export const cuestionarioCEORoutes: Array<{
  pattern: RegExp;
  methods: string[];
  handler: (request: Request, env: any, ctx: any, match: RegExpMatchArray) => Promise<Response | null>;
}> = [

  /* ============================================================
     GET /api/cuestionario-ceo — Estado completo
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/?$/,
    methods: ['GET'],
    handler: async (_req, env) => {
      try {
        const sections = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_sections ORDER BY sort_order ASC'
        ).all();

        const questions = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_questions ORDER BY section_id, sort_order ASC'
        ).all();

        const answers = await env.DB.prepare(
          "SELECT * FROM ceo_questionnaire_answers WHERE status = 'final'"
        ).all();

        const sessions = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_session ORDER BY last_seen_at DESC LIMIT 5'
        ).all();

        const questionsParsed = (questions.results as any[]).map(parseQuestion);
        const answersParsed = (answers.results as any[]).map((a: any) => ({
          question_id: a.question_id,
          section_id: a.section_id,
          selected_values: safeJSON(a.selected_values_json, []),
          scale_value: a.scale_value,
          binary_value: a.binary_value,
          free_text: a.free_text,
          comparison_choice: a.comparison_choice,
          comparison_why: a.comparison_why,
          notes: a.notes,
          tags: safeJSON(a.tags_json, []),
          confidence: a.confidence,
          status: a.status,
          answered_at: a.answered_at
        }));

        // Servicios del catálogo dinámico
        const services = await env.DB.prepare(
          "SELECT * FROM ceo_questionnaire_services WHERE status = 'active' ORDER BY sort_order ASC, created_at ASC"
        ).all();

        // Stats globales
        const totalQ = questionsParsed.length;
        const requiredQ = questionsParsed.filter(q => q.required).length;
        const answeredQ = new Set(answersParsed.map(a => a.question_id)).size;
        const globalPct = requiredQ > 0 ? Math.round((answeredQ / requiredQ) * 100) : 0;

        return Response.json({
          ok: true,
          data: {
            sections: sections.results,
            questions: questionsParsed,
            answers: answersParsed,
            sessions: sessions.results,
            services: services.results,
            stats: {
              total_questions: totalQ,
              required_questions: requiredQ,
              answered: answeredQ,
              completion_pct: globalPct,
              custom_services: (services.results as any[]).length
            }
          }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     GET /api/cuestionario-ceo/sections — Solo secciones con stats
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/sections$/,
    methods: ['GET'],
    handler: async (_req, env) => {
      try {
        const sections = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_sections ORDER BY sort_order ASC'
        ).all();

        const stats = await env.DB.prepare(
          `SELECT
             s.id AS section_id,
             COUNT(q.id) AS total_q,
             SUM(CASE WHEN q.required = 1 THEN 1 ELSE 0 END) AS required_q,
             COUNT(DISTINCT a.question_id) AS answered_q
           FROM ceo_questionnaire_sections s
           LEFT JOIN ceo_questionnaire_questions q ON q.section_id = s.id
           LEFT JOIN ceo_questionnaire_answers a ON a.question_id = q.id AND a.status = 'final'
           GROUP BY s.id
           ORDER BY s.sort_order`
        ).all();

        const statsMap: Record<string, any> = {};
        for (const r of (stats.results as any[])) {
          statsMap[r.section_id] = r;
        }

        const data = (sections.results as any[]).map((s: any) => {
          const st = statsMap[s.id] || { required_q: 0, answered_q: 0 };
          const total = Number(st.required_q) || 0;
          const done = Number(st.answered_q) || 0;
          return {
            ...s,
            total_questions: Number(st.total_q) || 0,
            required_questions: total,
            answered_questions: done,
            completion_pct: total > 0 ? Math.round((done / total) * 100) : 0,
            is_complete: total > 0 && done === total
          };
        });

        return Response.json({ ok: true, data }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     GET /api/cuestionario-ceo/section/:id — Preguntas + respuestas de una sección
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/section\/[a-z_]+$/,
    methods: ['GET'],
    handler: async (req, env) => {
      const sid = new URL(req.url).pathname.split('/').pop() || '';
      if (!SECTIONS.includes(sid)) {
        return Response.json({ ok: false, error: 'Invalid section: ' + sid }, { status: 400, headers: cors });
      }

      try {
        const section = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_sections WHERE id = ?'
        ).bind(sid).first();

        const questions = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_questions WHERE section_id = ? ORDER BY sort_order ASC'
        ).bind(sid).all();

        const answers = await env.DB.prepare(
          "SELECT * FROM ceo_questionnaire_answers WHERE section_id = ? AND status = 'final'"
        ).bind(sid).all();

        const answersMap: Record<string, any> = {};
        for (const a of (answers.results as any[])) {
          answersMap[a.question_id] = {
            selected_values: safeJSON(a.selected_values_json, []),
            scale_value: a.scale_value,
            binary_value: a.binary_value,
            free_text: a.free_text,
            comparison_choice: a.comparison_choice,
            comparison_why: a.comparison_why,
            notes: a.notes,
            tags: safeJSON(a.tags_json, []),
            confidence: a.confidence,
            answered_at: a.answered_at
          };
        }

        const qs = (questions.results as any[]).map((q: any) => ({
          ...parseQuestion(q),
          answer: answersMap[q.id] || null
        }));

        return Response.json({
          ok: true,
          data: { section, questions: qs, answers: answersMap }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     POST /api/cuestionario-ceo/answer — Guardar/actualizar una respuesta
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/answer$/,
    methods: ['POST'],
    handler: async (req, env) => {
      try {
        const body = await req.json() as {
          question_id: string;
          section_id: string;
          selected_values?: string[];
          scale_value?: number;
          binary_value?: number;
          free_text?: string;
          comparison_choice?: string;
          comparison_why?: string;
          comparison_a?: string;
          comparison_b?: string;
          notes?: string;
          tags?: string[];
          confidence?: number;
          answered_by?: string;
          status?: 'draft' | 'final';
        };

        if (!body.question_id || !body.section_id) {
          return Response.json({ ok: false, error: 'question_id and section_id required' }, { status: 400, headers: cors });
        }

        // Verificar que la pregunta existe
        const q = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_questions WHERE id = ?'
        ).bind(body.question_id).first();
        if (!q) {
          return Response.json({ ok: false, error: 'Question not found: ' + body.question_id }, { status: 404, headers: cors });
        }

        const status = body.status || 'final';
        const answeredBy = body.answered_by || 'rodrigo.mora@guardman.cl';
        const confidence = body.confidence != null ? Math.max(1, Math.min(5, Math.round(body.confidence))) : null;

        // Upsert
        await env.DB.prepare(`
          INSERT INTO ceo_questionnaire_answers
            (question_id, section_id, selected_values_json, scale_value, binary_value,
             free_text, comparison_a, comparison_b, comparison_choice, comparison_why,
             notes, tags_json, confidence, status, answered_by, answered_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
          ON CONFLICT(question_id) DO UPDATE SET
            selected_values_json = excluded.selected_values_json,
            scale_value = excluded.scale_value,
            binary_value = excluded.binary_value,
            free_text = excluded.free_text,
            comparison_a = excluded.comparison_a,
            comparison_b = excluded.comparison_b,
            comparison_choice = excluded.comparison_choice,
            comparison_why = excluded.comparison_why,
            notes = excluded.notes,
            tags_json = excluded.tags_json,
            confidence = excluded.confidence,
            status = excluded.status,
            answered_by = excluded.answered_by,
            updated_at = datetime('now')
        `).bind(
          body.question_id,
          body.section_id,
          JSON.stringify(body.selected_values || []),
          body.scale_value != null ? Number(body.scale_value) : null,
          body.binary_value != null ? Number(body.binary_value) : null,
          body.free_text || null,
          body.comparison_a || null,
          body.comparison_b || null,
          body.comparison_choice || null,
          body.comparison_why || null,
          body.notes || null,
          JSON.stringify(body.tags || []),
          confidence,
          status,
          answeredBy
        ).run();

        // Actualizar timestamp de sección
        await env.DB.prepare(`
          UPDATE ceo_questionnaire_sections
          SET updated_at = datetime('now'),
              status = CASE WHEN status = 'pending' THEN 'in_progress' ELSE status END
          WHERE id = ?
        `).bind(body.section_id).run();

        return Response.json({
          ok: true,
          data: { question_id: body.question_id, status, confidence, saved_at: new Date().toISOString() }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     POST /api/cuestionario-ceo/session — Iniciar/actualizar sesión
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/session$/,
    methods: ['POST'],
    handler: async (req, env) => {
      try {
        const body = await req.json() as {
          email: string;
          name: string;
          ip_hash?: string;
          user_agent?: string;
        };

        if (!body.email || !body.name) {
          return Response.json({ ok: false, error: 'email and name required' }, { status: 400, headers: cors });
        }

        // Buscar sesión existente
        const existing = await env.DB.prepare(
          'SELECT id FROM ceo_questionnaire_session WHERE respondent_email = ? ORDER BY started_at DESC LIMIT 1'
        ).bind(body.email).first();

        if (existing) {
          await env.DB.prepare(`
            UPDATE ceo_questionnaire_session
            SET last_seen_at = datetime('now'),
                ip_hash = COALESCE(?, ip_hash),
                user_agent = COALESCE(?, user_agent)
            WHERE id = ?
          `).bind(body.ip_hash || null, body.user_agent || null, (existing as any).id).run();

          return Response.json({ ok: true, data: { id: (existing as any).id, action: 'updated' } }, { headers: cors });
        }

        // Crear nueva sesión
        const result = await env.DB.prepare(`
          INSERT INTO ceo_questionnaire_session (respondent_email, respondent_name, ip_hash, user_agent)
          VALUES (?, ?, ?, ?)
        `).bind(body.email, body.name, body.ip_hash || null, body.user_agent || null).run();

        return Response.json({
          ok: true,
          data: { id: (result as any).meta?.last_row_id, action: 'created' }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     PATCH /api/cuestionario-ceo/section/:id — Marcar sección como completada
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/section\/[a-z_]+$/,
    methods: ['PATCH'],
    handler: async (req, env) => {
      try {
        const sid = new URL(req.url).pathname.split('/').pop() || '';
        if (!SECTIONS.includes(sid)) {
          return Response.json({ ok: false, error: 'Invalid section: ' + sid }, { status: 400, headers: cors });
        }

        // Verificar que todas las preguntas requeridas estén respondidas
        const result = await env.DB.prepare(`
          SELECT
            COUNT(q.id) AS total,
            SUM(CASE WHEN q.required = 1 THEN 1 ELSE 0 END) AS required,
            SUM(CASE WHEN q.required = 1 AND a.id IS NOT NULL THEN 1 ELSE 0 END) AS answered
          FROM ceo_questionnaire_questions q
          LEFT JOIN ceo_questionnaire_answers a
            ON a.question_id = q.id AND a.status = 'final'
          WHERE q.section_id = ?
        `).bind(sid).first();

        const r = result as any;
        const required = Number(r?.required) || 0;
        const answered = Number(r?.answered) || 0;

        if (required > answered) {
          return Response.json({
            ok: false,
            error: 'Faltan preguntas obligatorias',
            data: { required, answered, missing: required - answered }
          }, { status: 400, headers: cors });
        }

        await env.DB.prepare(`
          UPDATE ceo_questionnaire_sections
          SET status = 'complete',
              completed_at = datetime('now'),
              updated_at = datetime('now')
          WHERE id = ?
        `).bind(sid).run();

        return Response.json({ ok: true, data: { section_id: sid, action: 'completed' } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     GET /api/cuestionario-ceo/export — Exportar todo a JSON
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/export$/,
    methods: ['GET'],
    handler: async (_req, env) => {
      try {
        const sections = await env.DB.prepare('SELECT * FROM ceo_questionnaire_sections ORDER BY sort_order ASC').all();
        const questions = await env.DB.prepare('SELECT * FROM ceo_questionnaire_questions ORDER BY section_id, sort_order ASC').all();
        const answers = await env.DB.prepare("SELECT * FROM ceo_questionnaire_answers WHERE status = 'final'").all();
        const sessions = await env.DB.prepare('SELECT * FROM ceo_questionnaire_session ORDER BY started_at DESC').all();
        const conversation = await env.DB.prepare('SELECT * FROM ceo_questionnaire_conversation ORDER BY created_at ASC').all();

        const data = {
          exported_at: new Date().toISOString(),
          project: 'GuardMan Chile',
          questionnaire: 'Cuestionario de ADN de Marca — CEO Rodrigo Mora',
          summary: {
            total_questions: (questions.results as any[]).length,
            answered: (answers.results as any[]).length,
            completion_pct: Math.round(((answers.results as any[]).length / (questions.results as any[]).length) * 100),
            sessions_count: (sessions.results as any[]).length
          },
          sections: sections.results,
          questions: (questions.results as any[]).map(parseQuestion),
          answers: (answers.results as any[]).map((a: any) => ({
            question_id: a.question_id,
            section_id: a.section_id,
            selected_values: safeJSON(a.selected_values_json, []),
            scale_value: a.scale_value,
            binary_value: a.binary_value,
            free_text: a.free_text,
            comparison_choice: a.comparison_choice,
            comparison_why: a.comparison_why,
            notes: a.notes,
            tags: safeJSON(a.tags_json, []),
            confidence: a.confidence,
            status: a.status,
            answered_by: a.answered_by,
            answered_at: a.answered_at
          })),
          sessions: sessions.results,
          conversation: conversation.results
        };

        return new Response(JSON.stringify(data, null, 2), {
          headers: {
            ...cors,
            'Content-Type': 'application/json',
            'Content-Disposition': `attachment; filename="guardman-ceo-rodrigo-${new Date().toISOString().split('T')[0]}.json"`
          }
        });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     POST /api/cuestionario-ceo/message — Mensaje libre
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/message$/,
    methods: ['POST'],
    handler: async (req, env) => {
      try {
        const body = await req.json() as {
          speaker: 'rodrigo' | 'pi' | 'system';
          message: string;
          section_id?: string;
          question_id?: string;
          session_id?: number;
        };

        if (!body.speaker || !body.message) {
          return Response.json({ ok: false, error: 'speaker and message required' }, { status: 400, headers: cors });
        }

        const result = await env.DB.prepare(`
          INSERT INTO ceo_questionnaire_conversation (session_id, section_id, question_id, speaker, message, context_json)
          VALUES (?, ?, ?, ?, ?, ?)
        `).bind(
          body.session_id || null,
          body.section_id || null,
          body.question_id || null,
          body.speaker,
          body.message,
          JSON.stringify({})
        ).run();

        return Response.json({ ok: true, data: { id: (result as any).meta?.last_row_id } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     GET /api/cuestionario-ceo/services — Listar catálogo de servicios
     Query params:
       ?question_id=srv_01 → filtra por pregunta
       ?status=active|archived|all → por estado
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/services\/?$/,
    methods: ['GET'],
    handler: async (req, env) => {
      try {
        const url = new URL(req.url);
        const questionId = url.searchParams.get('question_id');
        const status = url.searchParams.get('status') || 'active';

        let sql = 'SELECT * FROM ceo_questionnaire_services';
        const wheres: string[] = [];
        const params: any[] = [];
        if (status !== 'all') { wheres.push('status = ?'); params.push(status); }
        if (questionId) { wheres.push('question_id = ?'); params.push(questionId); }
        if (wheres.length) sql += ' WHERE ' + wheres.join(' AND ');
        sql += ' ORDER BY sort_order ASC, created_at ASC';

        const rows = await env.DB.prepare(sql).bind(...params).all();

        return Response.json({
          ok: true,
          data: { services: rows.results, count: (rows.results as any[]).length }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     POST /api/cuestionario-ceo/service — Crear servicio
     body: { question_id, name, description?, sort_order? }
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/service$/,
    methods: ['POST'],
    handler: async (req, env) => {
      try {
        const body = await req.json() as {
          question_id: string;
          name: string;
          description?: string;
          sort_order?: number;
          source?: 'custom' | 'predefined';
          actor?: string;
        };

        if (!body.question_id || !body.name) {
          return Response.json({
            ok: false, error: 'question_id y name son obligatorios'
          }, { status: 400, headers: cors });
        }

        const name = body.name.trim();
        if (name.length < 2 || name.length > 200) {
          return Response.json({
            ok: false, error: 'El nombre debe tener entre 2 y 200 caracteres'
          }, { status: 400, headers: cors });
        }

        // Verificar que la pregunta existe
        const q = await env.DB.prepare(
          'SELECT id, options_json FROM ceo_questionnaire_questions WHERE id = ?'
        ).bind(body.question_id).first();
        if (!q) {
          return Response.json({
            ok: false, error: 'Pregunta no encontrada: ' + body.question_id
          }, { status: 404, headers: cors });
        }

        // Verificar duplicados (case-insensitive)
        const dup = await env.DB.prepare(
          "SELECT id FROM ceo_questionnaire_services WHERE question_id = ? AND LOWER(name) = LOWER(?) AND status = 'active'"
        ).bind(body.question_id, name).first();
        if (dup) {
          return Response.json({
            ok: false, error: 'Ya existe un servicio con ese nombre'
          }, { status: 409, headers: cors });
        }

        // Verificar duplicados contra las opciones predefinidas también
        const opts = safeJSON((q as any).options_json, []) as string[];
        const nameLower = name.toLowerCase();
        const dupPredef = opts.find(o => o.toLowerCase() === nameLower);
        if (dupPredef) {
          return Response.json({
            ok: false, error: 'Ese nombre ya existe en el catálogo predefinido: ' + dupPredef
          }, { status: 409, headers: cors });
        }

        const id = genId();
        const source = body.source || 'custom';
        const description = (body.description || '').trim().slice(0, 500);
        const sortOrder = body.sort_order != null ? Number(body.sort_order) : 0;

        await env.DB.prepare(`
          INSERT INTO ceo_questionnaire_services (id, question_id, name, description, source, status, sort_order, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, 'active', ?, datetime('now'), datetime('now'))
        `).bind(id, body.question_id, name, description, source, sortOrder).run();

        // Auditoría
        await env.DB.prepare(`
          INSERT INTO ceo_questionnaire_audit (entity, entity_id, action, payload, actor, created_at)
          VALUES ('service', ?, 'create', ?, ?, datetime('now'))
        `).bind(id, JSON.stringify({ question_id: body.question_id, name, description, source }), body.actor || 'rodrigo.mora@guardman.cl').run();

        return Response.json({
          ok: true,
          data: { id, question_id: body.question_id, name, description, source, action: 'created' }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     PUT /api/cuestionario-ceo/service/:id — Actualizar servicio
     body: { name?, description?, sort_order?, status? }
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/service\/[a-zA-Z0-9_-]+$/,
    methods: ['PUT'],
    handler: async (req, env) => {
      try {
        const id = new URL(req.url).pathname.split('/').pop() || '';
        const body = await req.json() as {
          name?: string;
          description?: string;
          sort_order?: number;
          status?: 'active' | 'archived';
          actor?: string;
        };

        const existing = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_services WHERE id = ?'
        ).bind(id).first();
        if (!existing) {
          return Response.json({ ok: false, error: 'Servicio no encontrado' }, { status: 404, headers: cors });
        }

        const updates: Record<string, any> = {};
        if (body.name !== undefined) {
          const n = body.name.trim();
          if (n.length < 2 || n.length > 200) {
            return Response.json({ ok: false, error: 'Nombre inválido (2-200 caracteres)' }, { status: 400, headers: cors });
          }
          updates.name = n;
        }
        if (body.description !== undefined) {
          updates.description = body.description.trim().slice(0, 500);
        }
        if (body.sort_order !== undefined) {
          updates.sort_order = Number(body.sort_order);
        }
        if (body.status !== undefined) {
          if (!['active', 'archived'].includes(body.status)) {
            return Response.json({ ok: false, error: 'Status inválido' }, { status: 400, headers: cors });
          }
          updates.status = body.status;
        }

        if (Object.keys(updates).length === 0) {
          return Response.json({ ok: false, error: 'Nada que actualizar' }, { status: 400, headers: cors });
        }

        // Validar duplicados si se cambió el nombre
        if (updates.name && updates.name.toLowerCase() !== (existing as any).name.toLowerCase()) {
          // 1) Contra otros servicios personalizados
          const dup = await env.DB.prepare(
            "SELECT id FROM ceo_questionnaire_services WHERE question_id = ? AND LOWER(name) = LOWER(?) AND status = 'active' AND id != ?"
          ).bind((existing as any).question_id, updates.name, id).first();
          if (dup) {
            return Response.json({ ok: false, error: 'Ya existe otro servicio con ese nombre' }, { status: 409, headers: cors });
          }
          // 2) Contra las opciones predefinidas de la pregunta
          const q = await env.DB.prepare(
            'SELECT options_json FROM ceo_questionnaire_questions WHERE id = ?'
          ).bind((existing as any).question_id).first();
          const opts = safeJSON((q as any)?.options_json, []) as string[];
          const nameLower = updates.name.toLowerCase();
          const dupPredef = opts.find(o => o.toLowerCase() === nameLower);
          if (dupPredef) {
            return Response.json({
              ok: false, error: 'Ese nombre ya existe en el catálogo predefinido: ' + dupPredef
            }, { status: 409, headers: cors });
          }
        }

        const setSql = Object.keys(updates).map(k => `${k} = ?`).join(', ');
        await env.DB.prepare(
          `UPDATE ceo_questionnaire_services SET ${setSql}, updated_at = datetime('now') WHERE id = ?`
        ).bind(...Object.values(updates), id).run();

        // Auditoría
        await env.DB.prepare(`
          INSERT INTO ceo_questionnaire_audit (entity, entity_id, action, payload, actor, created_at)
          VALUES ('service', ?, 'update', ?, ?, datetime('now'))
        `).bind(id, JSON.stringify(updates), body.actor || 'rodrigo.mora@guardman.cl').run();

        return Response.json({
          ok: true, data: { id, ...updates, action: 'updated' }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  },

  /* ============================================================
     DELETE /api/cuestionario-ceo/service/:id — Eliminar (soft delete = archived)
     ?hard=true para borrado físico
     ============================================================ */
  {
    pattern: /^\/api\/cuestionario-ceo\/service\/[a-zA-Z0-9_-]+$/,
    methods: ['DELETE'],
    handler: async (req, env) => {
      try {
        const id = new URL(req.url).pathname.split('/').pop() || '';
        const url = new URL(req.url);
        const hard = url.searchParams.get('hard') === 'true';
        const actor = url.searchParams.get('actor') || 'rodrigo.mora@guardman.cl';

        const existing = await env.DB.prepare(
          'SELECT * FROM ceo_questionnaire_services WHERE id = ?'
        ).bind(id).first();
        if (!existing) {
          return Response.json({ ok: false, error: 'Servicio no encontrado' }, { status: 404, headers: cors });
        }

        if (hard) {
          await env.DB.prepare('DELETE FROM ceo_questionnaire_services WHERE id = ?').bind(id).run();
          await env.DB.prepare(`
            INSERT INTO ceo_questionnaire_audit (entity, entity_id, action, payload, actor, created_at)
            VALUES ('service', ?, 'delete', ?, ?, datetime('now'))
          `).bind(id, JSON.stringify({ hard: true, name: (existing as any).name }), actor).run();
          return Response.json({ ok: true, data: { id, action: 'deleted_hard' } }, { headers: cors });
        } else {
          await env.DB.prepare(
            "UPDATE ceo_questionnaire_services SET status = 'archived', updated_at = datetime('now') WHERE id = ?"
          ).bind(id).run();
          await env.DB.prepare(`
            INSERT INTO ceo_questionnaire_audit (entity, entity_id, action, payload, actor, created_at)
            VALUES ('service', ?, 'archive', ?, ?, datetime('now'))
          `).bind(id, JSON.stringify({ name: (existing as any).name }), actor).run();
          return Response.json({ ok: true, data: { id, action: 'archived' } }, { headers: cors });
        }
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
  }
];
