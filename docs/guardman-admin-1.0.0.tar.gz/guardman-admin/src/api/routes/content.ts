// GuardMan Admin — Content Routes (extracted from api.ts)
export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};
import { calculateContentScore } from '../../services/scoring';
import { cachedFetch, invalidateCache, CACHE_TTL } from '../../services/cache';

export const contentRoutes = [
  // GET /api/services
  {
    pattern: /^\/api\/services$/,
    methods: ['GET'],
    handler: async (request: Request, env: any) => {
      const data = await cachedFetch(env.CACHE, 'services', { ttl: CACHE_TTL.SERVICES }, async () => {
        const { results } = await env.DB.prepare('SELECT * FROM services ORDER BY name').all();
        return results;
      });
      return Response.json({ ok: true, data }, { headers: cors });
    },
  },
  // GET /api/locations
  {
    pattern: /^\/api\/locations$/,
    methods: ['GET'],
    handler: async (request: Request, env: any) => {
      const data = await cachedFetch(env.CACHE, 'locations', { ttl: CACHE_TTL.SERVICES }, async () => {
        const { results } = await env.DB.prepare('SELECT * FROM locations ORDER BY name').all();
        return results;
      });
      return Response.json({ ok: true, data }, { headers: cors });
    },
  },
  // GET /api/sectors
  {
    pattern: /^\/api\/sectors$/,
    methods: ['GET'],
    handler: async (request: Request, env: any) => {
      const data = await cachedFetch(env.CACHE, 'sectors', { ttl: CACHE_TTL.SERVICES }, async () => {
        const { results } = await env.DB.prepare('SELECT * FROM sectors ORDER BY name').all();
        return results;
      });
      return Response.json({ ok: true, data }, { headers: cors });
    },
  },
  // GET /api/content — list content versions
  {
    pattern: /^\/api\/content$/,
    methods: ['GET'],
    handler: async (request: Request, env: any) => {
      const url = new URL(request.url);
      const entityType = url.searchParams.get('type');
      const entitySlug = url.searchParams.get('slug');
      let sql = 'SELECT * FROM content_versions WHERE 1=1';
      const params: any[] = [];
      if (entityType) { sql += ' AND entity_type = ?'; params.push(entityType); }
      if (entitySlug) { sql += ' AND entity_slug = ?'; params.push(entitySlug); }
      sql += ' ORDER BY created_at DESC';
      const { results } = await env.DB.prepare(sql).bind(...params).all();
      return Response.json({ ok: true, data: results }, { headers: cors });
    },
  },
  // POST /api/content — save content version
  {
    pattern: /^\/api\/content$/,
    methods: ['POST'],
    handler: async (request: Request, env: any) => {
      const body = await request.json() as any;
      const { entity_type, entity_slug, content_json, generated_by = 'manual', word_count } = body;
      const versionResult = await env.DB.prepare('SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?').bind(entity_type, entity_slug).first();
      const nextVersion = versionResult?.next_version || 1;
      const result = await env.DB.prepare('INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count) VALUES (?, ?, ?, ?, ?, ?)').bind(entity_type, entity_slug, nextVersion, JSON.stringify(content_json), generated_by, word_count || 0).run();
      await invalidateCache(env.CACHE, `content:latest:${entity_type}:${entity_slug}`);
      await invalidateCache(env.CACHE, 'content:overview');
      return Response.json({ ok: true, data: { id: result.meta.last_row_id, version: nextVersion } }, { headers: cors });
    },
  },
];
