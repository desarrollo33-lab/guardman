// GuardMan Admin v5.2 — CMS Routes for headless content management
import { CORS_HEADERS } from '../../types';
import { invalidateCache, flushAllCache } from '../../services/cache';

// Helper: Build brand context from D1 for AI prompts

async function getBrandContext(db: any): Promise<string> {
  try {
    const { results } = await db.prepare(
      'SELECT category, key, value FROM brand_dna WHERE category IN (\'company\', \'stats\', \'voice\', \'differentiators\', \'exclusions\') ORDER BY category, key'
    ).all();
    const brand: Record<string, Record<string, string>> = {};
    for (const row of results as any[]) {
      if (!brand[row.category]) brand[row.category] = {};
      brand[row.category][row.key] = row.value;
    }
    const c = brand.company || {};
    const s = brand.stats || {};
    const v = brand.voice || {};
    const d = brand.differentiators || {};
    const e = brand.exclusions || {};
    return `IDENTIDAD DE MARCA:
- Empresa: ${c.brand_name || 'GuardMan Chile'} (${c.legal_name || ''})
- Tagline: ${c.tagline || ''}
- Estadisticas: ${s.years || '8+'} anos, ${s.guards || '500+'} guardias, ${s.clients || '200+'} clientes, ${s.locations || '14'} comunas, rating ${s.rating || '4.8'}/5
- Tono: ${v.tone || 'Profesional, orientado a conversion, en espanol chileno'}
- Audiencia: ${v.audience || 'Empresas y residencias que buscan seguridad privada'}
- Personalidad: ${v.personality || 'Confiable, profesional, cercano'}
- Menciones obligatorias: ${v.mandatory_mentions || 'certificacion OS-10, experiencia, cobertura'}
- Palabras prohibidas: ${v.forbidden_words || 'garantia 100%, impecable, infalible'}
DIFERENCIADORES:
${Object.entries(d).map(([, val]) => `- ${val}`).join('\n')}
EXCLUSIONES:
${Object.entries(e).map(([, val]) => `- ${val}`).join('\n')}`;
  } catch {
    return '';
  }
}

export const cmsRoutes = [
  // ═══════════ BLOG ROUTES ═══════════
  {
    pattern: /^\/api\/cms\/blog\/list$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        const { results } = await env.DB.prepare(
          'SELECT id, slug, title, excerpt, image, author, status, published_at, created_at FROM blog_posts ORDER BY created_at DESC'
        ).all();
        return Response.json({ ok: true, posts: results }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: true, posts: [] }, { headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/blog\/get$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const url = new URL(request.url);
      const slug = url.searchParams.get('slug');
      if (!slug) return Response.json({ ok: false, error: 'Missing slug' }, { status: 400, headers: CORS_HEADERS });
      try {
        const row = await env.DB.prepare('SELECT * FROM blog_posts WHERE slug = ?').bind(slug).first();
        if (!row) return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: CORS_HEADERS });
        return Response.json({ ok: true, post: row }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/blog\/save$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        const { slug, title, excerpt, content, image, author, status, meta_title, meta_description, tags } = await request.json();
        if (!slug || !title || !content) {
          return Response.json({ ok: false, error: 'Missing required fields' }, { status: 400, headers: CORS_HEADERS });
        }
        const publishedAt = status === 'published' ? new Date().toISOString() : null;
        await env.DB.prepare(`
          INSERT INTO blog_posts (slug, title, excerpt, content, image, author, status, published_at, meta_title, meta_description, tags, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
          ON CONFLICT(slug) DO UPDATE SET
            title=excluded.title, excerpt=excluded.excerpt, content=excluded.content,
            image=excluded.image, author=excluded.author, status=excluded.status,
            published_at=COALESCE(excluded.published_at, blog_posts.published_at),
            meta_title=excluded.meta_title, meta_description=excluded.meta_description,
            tags=excluded.tags, updated_at=datetime('now')
        `).bind(slug, title, excerpt || null, content, image || null, author || 'GuardMan Chile', status || 'draft', publishedAt, meta_title || null, meta_description || null, tags || null).run();
        // Invalidate blog cache
        ctx?.waitUntil?.(invalidateCache(env, 'blog'));
        return Response.json({ ok: true, slug }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/blog\/delete$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        const { slug } = await request.json();
        if (!slug) return Response.json({ ok: false, error: 'Missing slug' }, { status: 400, headers: CORS_HEADERS });
        await env.DB.prepare('DELETE FROM blog_posts WHERE slug = ?').bind(slug).run();
        ctx?.waitUntil?.(invalidateCache(env, 'blog'));
        return Response.json({ ok: true }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },

  // ═══════════ MEDIA ROUTES ═══════════
  {
    pattern: /^\/api\/media\/list$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        const images: Array<{key:string;size:number;uploaded:string}> = [];
        const result = await env.IMAGES.list({ limit: 500 });
        for (const obj of result.objects) {
          images.push({
            key: obj.key,
            size: obj.size,
            uploaded: obj.uploaded?.toISOString?.() || '',
          });
        }
        // Cache the list for 5 min
        return Response.json({ ok: true, images, count: images.length }, {
          headers: { ...CORS_HEADERS, 'Cache-Control': 'public, max-age=300' },
        });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },

  // ═══════════ CMS CONTENT ROUTES ═══════════
  {
    pattern: /^\/api\/cms\/content$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const url = new URL(request.url);
      const type = url.searchParams.get('type');
      const slug = url.searchParams.get('slug');
      const location = url.searchParams.get('location');

      if (!type || !slug) {
        return Response.json({ ok: false, error: 'Missing type or slug' }, { status: 400, headers: CORS_HEADERS });
      }

      try {
        if (type === 'combo' && location) {
          const row = await env.DB.prepare(
            'SELECT content_json FROM combo_content WHERE service_slug = ? AND location_slug = ?'
          ).bind(slug, location).first();
          if (!row || !row.content_json) {
            return Response.json({ ok: false, error: 'Content not found' }, { status: 404, headers: CORS_HEADERS });
          }
          const parsed = typeof row.content_json === 'string' ? JSON.parse(row.content_json) : row.content_json;
          const sections = parsed.sections || parsed;
          const metaSection = sections.meta || parsed.meta || {};
          return Response.json({
            ok: true,
            content: {
              slug: `${slug}/${location}`,
              type: 'combo',
              version: 1,
              last_modified: new Date().toISOString(),
              seo: {
                title: metaSection.title || sections.hero?.heading || '',
                description: metaSection.description || sections.hero?.subheading || '',
                canonical: metaSection.canonical || ''
              },
              content: sections,
              related_content: null,
              meta: { author: 'admin', quality_score: 0, published: true }
            }
          }, { headers: CORS_HEADERS });
        }

        // Static pages
        if (type === 'static_page') {
          const spRow = await env.DB.prepare('SELECT * FROM static_page_content WHERE slug = ?').bind(slug).first();
          if (!spRow) return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: CORS_HEADERS });
          const sp = spRow as any;

          // If content_json has full editor structure, use it; otherwise build minimal from columns
          let editorContent: any = {};
          if (sp.content_json) {
            try {
              const parsed = typeof sp.content_json === 'string' ? JSON.parse(sp.content_json) : sp.content_json;
              // New format: { sections, seo } (same as services/sectors)
              if (parsed.sections) {
                return Response.json({ ok: true, content: {
                  slug, type: 'static_page', version: 1, last_modified: sp.updated_at || sp.created_at,
                  seo: parsed.seo || { title: sp.meta_title || '', description: sp.meta_description || '', canonical: '' },
                  content: parsed.sections,
                  meta: parsed.meta || { author: 'admin', quality_score: 0, published: true }
                }}, { headers: CORS_HEADERS });
              }
              // Old format: { seo, content } (editor state directly)
              if (parsed.seo || parsed.content) {
                return Response.json({ ok: true, content: {
                  slug, type: 'static_page', version: 1, last_modified: sp.updated_at || sp.created_at,
                  seo: parsed.seo || { title: sp.meta_title || '', description: sp.meta_description || '', canonical: '' },
                  content: parsed.content || {},
                  meta: parsed.meta || { author: 'admin', quality_score: 0, published: true }
                }}, { headers: CORS_HEADERS });
              }
            } catch { /* fall through to minimal format */ }
          }

          // Fallback: minimal from columns
          return Response.json({ ok: true, content: {
            slug, type: 'static_page', version: 1, last_modified: sp.updated_at || sp.created_at,
            seo: { title: sp.meta_title || '', description: sp.meta_description || '', canonical: '' },
            content: { hero: { headline: sp.hero_heading || '', subheadline: sp.hero_subheading || '', badge: sp.hero_badge || '', background_image: sp.hero_image || '' } },
            meta: { author: 'admin', quality_score: 0, published: true }
          }}, { headers: CORS_HEADERS });
        }

        const row = await env.DB.prepare(
          'SELECT content_json, version, created_at FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
        ).bind(type, slug).first();

        if (!row || !row.content_json) {
          return Response.json({ ok: false, error: 'Content not found' }, { status: 404, headers: CORS_HEADERS });
        }

        const parsed = typeof row.content_json === 'string' ? JSON.parse(row.content_json) : row.content_json;
        const sections = parsed.sections || parsed;
        const metaSection = sections.meta || parsed.meta || parsed._meta || {};
        return Response.json({
          ok: true,
          content: {
            slug,
            type,
            version: row.version,
            last_modified: row.created_at,
            seo: {
              title: metaSection.title || sections.hero?.heading || '',
              description: metaSection.description || sections.hero?.subheading || '',
              canonical: metaSection.canonical || ''
            },
            content: sections,
            related_content: parsed.related_content || null,
            meta: { author: 'admin', quality_score: 0, published: true }
          }
        }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/list$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const url = new URL(request.url);
      const type = url.searchParams.get('type');

      if (!type) {
        return Response.json({ ok: false, error: 'Missing type' }, { status: 400, headers: CORS_HEADERS });
      }

      try {
        let items: any[] = [];
        if (type === 'service') {
          const { results } = await env.DB.prepare('SELECT slug, name FROM services ORDER BY name').all();
          items = results;
        } else if (type === 'location') {
          const { results } = await env.DB.prepare('SELECT slug, name FROM locations ORDER BY name').all();
          items = results;
        } else if (type === 'sector') {
          const { results } = await env.DB.prepare('SELECT slug, name FROM sectors ORDER BY name').all();
          items = results;
        } else if (type === 'combo') {
          const { results: services } = await env.DB.prepare('SELECT slug, name FROM services ORDER BY name').all();
          const { results: locations } = await env.DB.prepare('SELECT slug, name FROM locations ORDER BY name').all();
          items = services.flatMap((s: any) =>
            locations.map((l: any) => ({ slug: `${s.slug}/${l.slug}`, name: `${s.name} + ${l.name}` }))
          );
        }
        return Response.json({ ok: true, items }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/save$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        const { path, content } = await request.json();

        if (!path || !content) {
          return Response.json({ ok: false, error: 'Missing path or content' }, { status: 400, headers: CORS_HEADERS });
        }

        const parts = path.split('/');
        let entityType = '';
        let entitySlug = '';
        let locationSlug = '';

        if (path === 'homepage.json') {
          const contentStr = JSON.stringify(content, null, 2);
          const d = content as any;
          const seo = d.seo || {};
          const hero = d.content?.hero || d.hero || {};

          // Save to content_versions (version history)
          try {
            const wordCount = contentStr.split(/\s+/).length;
            await env.DB.prepare(`
              INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count)
              VALUES ('page', 'homepage', 1, ?, 'manual', ?)
              ON CONFLICT(entity_type, entity_slug) DO UPDATE SET
                content_json = excluded.content_json,
                generated_by = 'manual',
                word_count = excluded.word_count
            `).bind(contentStr, wordCount).run();
          } catch (e) {
            console.warn('[CMS] Homepage content_versions save failed:', (e as Error).message);
          }

          // ALSO save to static_page_content so SSR picks up changes
          try {
            await env.DB.prepare(`
              INSERT INTO static_page_content (slug, hero_heading, hero_subheading, hero_badge, hero_image, meta_title, meta_description, content_json, updated_at)
              VALUES ('homepage', ?, ?, ?, ?, ?, ?, ?, datetime('now'))
              ON CONFLICT(slug) DO UPDATE SET
                hero_heading = excluded.hero_heading, hero_subheading = excluded.hero_subheading,
                hero_badge = excluded.hero_badge, hero_image = excluded.hero_image,
                meta_title = excluded.meta_title, meta_description = excluded.meta_description,
                content_json = excluded.content_json, updated_at = datetime('now')
            `).bind(
              hero.headline || hero.heading || null,
              hero.subheadline || hero.subheading || null,
              hero.badge || null,
              hero.background_image || hero.image || null,
              seo.title || null,
              seo.description || null,
              contentStr
            ).run();
          } catch (e) {
            console.warn('[CMS] Homepage static_page_content save failed:', (e as Error).message);
          }

          // Invalidate cache after homepage save (ARCH-01)
          ctx?.waitUntil?.(invalidateCache(env, 'homepage'));
          return Response.json({ ok: true, path }, { headers: CORS_HEADERS });
        }

        if (parts[0] === 'static') {
          // Static pages: extract same format as services/sectors
          const staticSlug = parts[1].replace('.json', '');
          const rawContent = content as any;
          // Extract nested content (same logic as sectors/locations)
          let sections: any = {};
          if (rawContent.content && (rawContent.content.hero || rawContent.content.intro)) {
            sections = rawContent.content;
          }
          const seo = rawContent.seo || sections.meta || null;
          const hero = sections.hero || {};
          // Build content_json in same format as sectors: { sections, seo }
          const dbContent: any = { sections, content: sections };
          if (seo) { dbContent.seo = seo; dbContent.content = sections; }
          const contentJson = JSON.stringify(dbContent);
          await env.DB.prepare(`
            INSERT INTO static_page_content (slug, hero_heading, hero_subheading, hero_badge, hero_image, meta_title, meta_description, content_json, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
            ON CONFLICT(slug) DO UPDATE SET
              hero_heading=excluded.hero_heading, hero_subheading=excluded.hero_subheading,
              hero_badge=excluded.hero_badge, hero_image=excluded.hero_image,
              meta_title=excluded.meta_title, meta_description=excluded.meta_description,
              content_json=excluded.content_json, updated_at=datetime('now')
          `).bind(staticSlug,
            hero.headline || hero.heading || null,
            hero.subheadline || hero.subheading || null,
            hero.badge || null,
            hero.image || hero.background_image || null,
            seo?.title || null,
            seo?.description || null,
            contentJson
          ).run();
          // Invalidate cache after static page save (ARCH-01)
          ctx?.waitUntil?.(invalidateCache(env, 'static', staticSlug));
          return Response.json({ ok: true, path, entity_type: 'static_page', entity_slug: staticSlug }, { headers: CORS_HEADERS });
        }

        if (parts[0] === 'services') { entityType = 'service'; entitySlug = parts[1].replace('.json', ''); }
        else if (parts[0] === 'locations') { entityType = 'location'; entitySlug = parts[1].replace('.json', ''); }
        else if (parts[0] === 'sectors') { entityType = 'sector'; entitySlug = parts[1].replace('.json', ''); }
        else if (parts[0] === 'static') { entityType = 'static_page'; entitySlug = parts[1].replace('.json', ''); }
        else if (parts[0] === 'combos') {
          entityType = 'combo';
          entitySlug = parts[1];
          locationSlug = parts[2].replace('.json', '');
        }

        if (!entityType || !entitySlug) {
          return Response.json({ ok: false, error: 'Invalid path' }, { status: 400, headers: CORS_HEADERS });
        }

        // Normalize content into consistent { sections, seo, related_content } format
        const rawContent: any = content;
        let sections: any;

        if (rawContent.content && (rawContent.content.hero || rawContent.content.intro)) {
          // API format: { content: { hero: {...} }, seo: {...} }
          sections = rawContent.content;
        } else if (rawContent.sections) {
          // CMS JSON format: { sections: { hero: {...} } }
          sections = rawContent.sections;
        } else {
          // Flat format: { hero: {...}, intro: {...} }
          sections = rawContent;
        }

        const seo = rawContent.seo || sections.meta || null;
        const relatedContent = rawContent.related_content || null;
        const dbContent: any = { sections };
        if (seo) dbContent.seo = seo;
        if (relatedContent) dbContent.related_content = relatedContent;
        const contentJson = JSON.stringify(dbContent);

        if (entityType === 'combo' && locationSlug) {
          await env.DB.prepare(
            `INSERT INTO combo_content (service_slug, location_slug, content_json, status, generated_at) VALUES (?, ?, ?, 'published', datetime('now'))
             ON CONFLICT(service_slug, location_slug) DO UPDATE SET content_json=excluded.content_json, status='published', generated_at=datetime('now')`
          ).bind(entitySlug, locationSlug, contentJson).run();
        } else {
          const versionResult = await env.DB.prepare(
            'SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?'
          ).bind(entityType, entitySlug).first();
          const nextVersion = versionResult?.next_version || 1;
          const wordCount = contentJson.split(/\s+/).length;
          await env.DB.prepare(
            'INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count) VALUES (?, ?, ?, ?, ?, ?)'
          ).bind(entityType, entitySlug, nextVersion, contentJson, 'manual', wordCount).run();
        }

        // Invalidate cache after content save (ARCH-01)
        const invSlug = entityType === 'combo' && locationSlug ? `${entitySlug}/${locationSlug}` : entitySlug;
        ctx?.waitUntil?.(invalidateCache(env, entityType, invSlug));
        return Response.json({ ok: true, path, entity_type: entityType, entity_slug: entitySlug }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  // GET /api/cms/image?path=/images/hero-home.webp — Proxy from R2
  {
    pattern: /^\/api\/cms\/image$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const url = new URL(request.url);
      const imgPath = url.searchParams.get('path');

      if (!imgPath) {
        return Response.json({ ok: false, error: 'Missing path' }, { status: 400, headers: CORS_HEADERS });
      }

      // Remove leading slash for R2 key (e.g., /images/hero-home.webp → images/hero-home.webp)
      const r2Key = imgPath.startsWith('/') ? imgPath.substring(1) : imgPath;

      try {
        const object = await env.IMAGES.get(r2Key);
        if (!object) {
          return Response.json({ ok: false, error: 'Image not found in R2' }, { status: 404, headers: CORS_HEADERS });
        }

        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('Cache-Control', 'public, max-age=86400');
        headers.set('Access-Control-Allow-Origin', '*');
        const ct3 = headers.get('Content-Type') || '';
        if (ct3 === 'application/octet-stream' || !ct3) {
          if (r2Key.endsWith('.webp')) headers.set('Content-Type', 'image/webp');
          else if (r2Key.endsWith('.jpg') || r2Key.endsWith('.jpeg')) headers.set('Content-Type', 'image/jpeg');
          else if (r2Key.endsWith('.png')) headers.set('Content-Type', 'image/png');
          else if (r2Key.endsWith('.svg')) headers.set('Content-Type', 'image/svg+xml');
          else if (r2Key.endsWith('.gif')) headers.set('Content-Type', 'image/gif');
        }

        return new Response(object.body, { headers });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },

  // POST /api/cms/regenerate - Regenerate content through unified pipeline
  {
    pattern: /^\/api\/cms\/regenerate$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const body = await request.json();
      const { type, slug, content } = body;

      if (!type || !slug) {
        return Response.json({ ok: false, error: 'Missing type or slug' }, { status: 400, headers: CORS_HEADERS });
      }

      // Build entity name from slug
      const nameMap: Record<string, string> = {
        'auditoria-seguridad': 'Auditor\u00eda de Seguridad',
        'cctv-videovigilancia': 'CCTV Videovigilancia',
        'control-de-accesos': 'Control de Accesos',
        'escoltas-privados': 'Escoltas Privados',
        'guard-pod': 'Guard Pod',
        'guardias-de-seguridad': 'Guardias de Seguridad',
        'monitoreo-24-7': 'Monitoreo 24/7',
        'seguridad-industrial': 'Seguridad Industrial',
        'seguridad-eventos': 'Seguridad de Eventos',
        'comercial': 'Sector Comercial',
        'construccion': 'Sector Construcci\u00f3n',
        'educacion': 'Sector Educaci\u00f3n',
        'eventos': 'Sector Eventos',
        'industrial': 'Sector Industrial',
        'residencial': 'Sector Residencial',
        'salud': 'Sector Salud',
      };
      const entityName = nameMap[slug] || slug.split('-').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

      try {
        const { generateContent } = await import('../../services/content-generation');
        const { calculateContentScore } = await import('../../services/scoring');
        const currentContent = content?.content || content;
        const currentScore = currentContent ? calculateContentScore(currentContent) : undefined;

        const result = await generateContent(env, type, slug, entityName, {
          currentContent,
          currentScore,
        });

        // Return in the format the CMS editor expects
        const sections = result.content.sections || result.content;
        return Response.json({
          ok: true,
          improved: sections,
          _meta: result.content._meta,
          qualityPipeline: {
            score: result.score,
            algoScore: result.algoScore,
            passed: result.passed,
            violations: result.violations,
            genericPhrases: result.genericPhrases,
            review: result.review,
          },
        }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/generate$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const body = await request.json();
      const { type, slug } = body;
      if (!type || !slug) {
        return Response.json({ ok: false, error: 'Missing type or slug' }, { status: 400, headers: CORS_HEADERS });
      }

      const entityName = slug.split('-').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');

      try {
        const { generateContent } = await import('../../services/content-generation');
        const result = await generateContent(env, type, slug, entityName, {});

        const sections = result.content.sections || result.content;
        const contentJson = JSON.stringify({ sections, seo: sections.meta || {} });
        const wordCount = contentJson.split(/\s+/).length;

        const versionResult = await env.DB.prepare(
          'SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?'
        ).bind(type, slug).first();
        const nextVersion = versionResult?.next_version || 1;

        await env.DB.prepare(
          'INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count) VALUES (?, ?, ?, ?, ?, ?)'
        ).bind(type, slug, nextVersion, contentJson, 'ai', wordCount).run();

        ctx?.waitUntil?.(invalidateCache(env, type, slug));
        return Response.json({ ok: true, slug, version: nextVersion }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  // POST /api/cms/score — Unified SEO scoring endpoint
  {
    pattern: /^\/api\/cms\/score$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        const { content } = await request.json();
        if (!content) {
          return Response.json({ ok: false, error: 'Missing content' }, { status: 400, headers: CORS_HEADERS });
        }

        const { calculateContentScore } = await import('../../services/scoring');
        const score = calculateContentScore(content);
        return Response.json({ ok: true, ...score }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/homepage$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        // Load homepage from D1 static_page_content (not GitHub)
        const row = await env.DB.prepare('SELECT * FROM static_page_content WHERE slug = ?').bind('homepage').first();
        if (!row) {
          return Response.json({ ok: false, error: 'Homepage not found in D1' }, { status: 404, headers: CORS_HEADERS });
        }
        const sp = row as any;
        let content: any = {};
        if (sp.content_json) {
          try {
            content = typeof sp.content_json === 'string' ? JSON.parse(sp.content_json) : sp.content_json;
          } catch { /* use empty */ }
        }
        return Response.json({ ok: true, content }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/rebuild$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      try {
        // ARCH-05: Flush KV cache instead of deploying to Cloudflare Pages
        await flushAllCache(env);
        return Response.json({
          ok: true,
          message: 'Caché eliminada. El sitio se regenerará en la próxima visita.'
        }, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    }
  },
  {
    pattern: /^\/api\/cms\/deploy-status$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      // ARCH-05: Return cache status instead of Pages deploy status
      return Response.json({
        ok: true,
        status: 'active',
        stage: 'live',
        message: 'Sitio servido directamente desde el Worker. La caché se invalida al guardar contenido.'
      }, { headers: CORS_HEADERS });
    }
  },

  // POST /api/cms/generate-section — Generate ONE section (modular)
  {
    pattern: /^\/api\/cms\/generate-section$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const body = await request.json();
      const { slug, section } = body;
      if (!slug || !section) {
        return Response.json({ ok: false, error: 'Missing slug or section' }, { status: 400, headers: CORS_HEADERS });
      }

      const { generateSection } = await import('../../services/section-generation');
      const result = await generateSection(env, slug, section);

      if (!result.ok) {
        return Response.json({ ok: false, error: result.error || 'Generation failed', data: null }, { status: 422, headers: CORS_HEADERS });
      }

      ctx?.waitUntil?.(invalidateCache(env, 'static_page', slug));
      return Response.json({ ok: true, data: { section, data: result.data, attempt: result.attempt } }, { headers: CORS_HEADERS });
    }
  },

  // POST /api/cms/generate-all-sections — Bulk generate all sections
  {
    pattern: /^\/api\/cms\/generate-all-sections$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any): Promise<Response | null> => {
      const body = await request.json();
      const { slug, sections } = body;
      if (!slug || !sections || !Array.isArray(sections)) {
        return Response.json({ ok: false, error: 'Missing slug or sections array' }, { status: 400, headers: CORS_HEADERS });
      }

      const { generateAllSections } = await import('../../services/section-generation');
      const result = await generateAllSections(env, slug, sections);

      ctx?.waitUntil?.(invalidateCache(env, 'static_page', slug));
      return Response.json({
        ok: true,
        data: { slug, generated: result.successes.length, total: sections.length, successes: result.successes, failures: result.failures },
      }, { headers: CORS_HEADERS });
    }
  },
];