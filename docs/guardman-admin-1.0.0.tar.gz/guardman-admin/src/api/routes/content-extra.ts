// GuardMan Admin — Content Extra Routes (extracted from api.ts)
import { CORS_HEADERS, LOCATION_SLUGS } from '../../types';
import { calculateContentScore } from '../../services/scoring';
import { cachedFetch, invalidateCache, CACHE_TTL } from '../../services/cache';
import { reviewContent } from '../../agents/content-reviewer';
import { generateContent } from '../../services/content-generation';

const cors = CORS_HEADERS;

export const contentExtraRoutes = [
  {
    pattern: /^\/api\/content\/(overview|intelligence|generate|review|latest|publish)/,
    methods: ['GET', 'POST'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

    if (path === '/api/content/overview' && method === 'GET') {
      try {
        const overviewData = await cachedFetch(env.CACHE, 'content:overview', { ttl: CACHE_TTL.OVERVIEW }, async () => {
        const [services, locations, sectors, allContent, allComboContent] = await Promise.all([
          env.DB.prepare('SELECT slug, name FROM services ORDER BY name').all(),
          env.DB.prepare('SELECT slug, name, zone FROM locations ORDER BY name').all(),
          env.DB.prepare('SELECT slug, name FROM sectors ORDER BY name').all(),
          env.DB.prepare(`SELECT entity_type, entity_slug, version, content_json, word_count, generated_by, created_at FROM content_versions cv1 WHERE version = (SELECT MAX(version) FROM content_versions cv2 WHERE cv2.entity_type = cv1.entity_type AND cv2.entity_slug = cv1.entity_slug)`).all(),
          env.DB.prepare('SELECT service_slug, location_slug, h1, seo_title, meta_description, word_count, status, generated_at FROM combo_content').all(),
        ]);

        const contentMap = new Map((allContent.results as any[]).map((c: any) => [c.entity_type + '|' + c.entity_slug, c]));
        const comboContentMap = new Map((allComboContent.results as any[]).map((c: any) => [c.service_slug + '|' + c.location_slug, c]));

        const buildEntity = (type: string, slug: string, name: string, zone?: string) => {
          const key = type + '|' + slug;
          const content = contentMap.get(key);
          let parsed: any = null;
          if (content?.content_json) { try { parsed = JSON.parse(content.content_json); } catch { parsed = null; } }
          const { score, details } = calculateContentScore(parsed);
          const meta = parsed?._meta || {};
          return {
            type, slug, name, zone,
            has_content: !!parsed && !!parsed.sections,
            score, score_details: details,
            word_count: content?.word_count || 0,
            version: content?.version || 0,
            generated_by: content?.generated_by || null,
            updated_at: content?.created_at || null,
            keywords: meta.keywords || [],
            serper_queries_count: meta.serper_queries?.length || 0,
            competitors_count: meta.serper_competitors?.length || 0,
          };
        };

        const entities = [
          ...(services.results as any[]).map((s: any) => buildEntity('service', s.slug, s.name)),
          ...(locations.results as any[]).map((l: any) => buildEntity('location', l.slug, l.name, l.zone)),
          ...(sectors.results as any[]).map((s: any) => buildEntity('sector', s.slug, s.name)),
        ];

        // Generate combo entities using combo_content table
        const serviceList = (services.results as any[]).map((s: any) => s.slug);
        const locationList = (locations.results as any[]).map((l: any) => ({ slug: l.slug, name: l.name, zone: l.zone }));

        for (const serviceSlug of serviceList) {
          for (const location of locationList) {
            const comboSlug = serviceSlug + '-' + location.slug;
            const comboName = serviceSlug.replace(/-/g, ' ') + ' en ' + location.name;
            const comboData = comboContentMap.get(serviceSlug + '|' + location.slug);
            let hasContent = false;
            let score = 0;
            let details: any = {};
            let wordCount = 0;
            let updatedAt: string | null = null;
            if (comboData) {
              hasContent = !!(comboData.h1 || comboData.seo_title);
              const fakeContent: any = {};
              if (comboData.h1) fakeContent.hero = { heading: comboData.h1 };
              if (comboData.seo_title) fakeContent.meta = { title: comboData.seo_title, description: comboData.meta_description || '' };
              if (comboData.intro_paragraph) fakeContent.intro = { heading: comboData.h1 || '', paragraphs: [comboData.intro_paragraph] };
              const scored = calculateContentScore({ sections: fakeContent });
              score = scored.score;
              details = scored.details;
              wordCount = comboData.word_count || 0;
              updatedAt = comboData.generated_at || null;
            }
            entities.push({
              type: 'combo',
              slug: comboSlug,
              name: comboName,
              zone: location.zone,
              has_content: hasContent,
              score, score_details: details,
              word_count: wordCount,
              version: 0,
              generated_by: hasContent ? 'ai' : null,
              updated_at: updatedAt,
              keywords: [],
              serper_queries_count: 0,
              competitors_count: 0,
              serper_gaps: 0,
              service_slug: serviceSlug,
              location_slug: location.slug,
              location_name: location.name,
            });
          }
        }

        // Get content gap counts per service for intelligence
        const gapCounts = await env.DB.prepare(`
          SELECT service_slug, COUNT(*) as gaps_count FROM (
            SELECT sq.service_slug, sq.id
            FROM serper_queries sq
            LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = 'own'
            WHERE sq.status = 'completed' AND (sr.position IS NULL OR sr.position > 5)
            GROUP BY sq.id
          ) GROUP BY service_slug
        `).all();
        const gapMap = new Map((gapCounts.results as any[]).map((g: any) => [g.service_slug, g.gaps_count]));

        // Get content gap counts per location
        const locGapCounts = await env.DB.prepare(`
          SELECT location_slug, COUNT(*) as gaps_count FROM (
            SELECT sq.location_slug, sq.id
            FROM serper_queries sq
            LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = 'own'
            WHERE sq.status = 'completed' AND (sr.position IS NULL OR sr.position > 5)
            GROUP BY sq.id
          ) GROUP BY location_slug
        `).all();
        const locGapMap = new Map((locGapCounts.results as any[]).map((g: any) => [g.location_slug, g.gaps_count]));

        // Sector to service mapping
        const sectorToService: Record<string, string> = {
          'comercial': 'guardias-de-seguridad',
          'construccion': 'seguridad-industrial',
          'educacion': 'guardias-de-seguridad',
          'eventos': 'seguridad-eventos',
          'industrial': 'seguridad-industrial',
          'residencial': 'guardias-de-seguridad',
          'salud': 'guardias-de-seguridad',
        };

        entities.forEach((e: any) => {
          if (e.type === 'service') {
            e.serper_gaps = gapMap.get(e.slug) || 0;
          } else if (e.type === 'location') {
            e.serper_gaps = locGapMap.get(e.slug) || 0;
          } else if (e.type === 'sector') {
            const mappedService = sectorToService[e.slug];
            e.serper_gaps = mappedService ? (gapMap.get(mappedService) || 0) : 0;
            e.mapped_service = mappedService || null;
          }
        });

        const stats = {
          total: entities.length,
          with_content: entities.filter((e: any) => e.has_content).length,
          missing_content: entities.filter((e: any) => !e.has_content).length,
          avg_score: entities.length > 0 ? Math.round(entities.reduce((s: number, e: any) => s + e.score, 0) / entities.length) : 0,
          by_type: {
            service: entities.filter((e: any) => e.type === 'service'),
            location: entities.filter((e: any) => e.type === 'location'),
            sector: entities.filter((e: any) => e.type === 'sector'),
            combo: entities.filter((e: any) => e.type === 'combo'),
          },
        };

        const overviewResult = { entities, stats };
        return overviewResult;
        }); // end cachedFetch

        return Response.json({ ok: true, data: overviewData }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // GET /api/content/intelligence/:type/:slug - Serper data for specific entity
    if (path.startsWith('/api/content/intelligence/') && method === 'GET') {
      try {
        const parts = path.replace('/api/content/intelligence/', '').split('/');
        const entityType = parts[0];
        const entitySlug = parts[1];

        // Get entity name
        let entityName = entitySlug;
        if (entityType === 'service') {
          const svc = await env.DB.prepare('SELECT name FROM services WHERE slug = ?').bind(entitySlug).first();
          entityName = svc?.name || entitySlug;
        } else if (entityType === 'location') {
          const loc = await env.DB.prepare('SELECT name FROM locations WHERE slug = ?').bind(entitySlug).first();
          entityName = loc?.name || entitySlug;
        } else if (entityType === 'sector') {
          const sec = await env.DB.prepare('SELECT name FROM sectors WHERE slug = ?').bind(entitySlug).first();
          entityName = sec?.name || entitySlug;
        } else if (entityType === 'combo') {
          // Combo format: service-location (e.g., guardias-de-seguridad-las-condes)
          const parts = entitySlug.split('-');
          // Find service slug (first part until a location slug match)
          const locationNames = ['santiago-centro', 'huechuraba', 'lampa', 'quilicura', 'la-reina', 'las-condes', 'lo-barnechea', 'vitacura', 'conchali', 'pudahuel', 'renca', 'la-pintana', 'los-andes', 'san-felipe'];
          const matchingLocation = locationNames.find(loc => entitySlug.endsWith('-' + loc));
          if (matchingLocation) {
            const serviceSlug = entitySlug.replace('-' + matchingLocation, '');
            const svc = await env.DB.prepare('SELECT name FROM services WHERE slug = ?').bind(serviceSlug).first();
            const loc = await env.DB.prepare('SELECT name FROM locations WHERE slug = ?').bind(matchingLocation).first();
            entityName = (svc?.name || serviceSlug) + ' en ' + (loc?.name || matchingLocation);
          } else {
            entityName = entitySlug.replace(/-/g, ' ');
          }
        }

        // If location, sector, or combo, find related service(s)
        let serviceSlugs: string[] = [];
        if (entityType === 'location') {
          const srvs = await env.DB.prepare('SELECT slug FROM services').all();
          serviceSlugs = (srvs.results as any[]).map((s: any) => s.slug);
        } else if (entityType === 'sector') {
          const srvs = await env.DB.prepare('SELECT slug FROM services').all();
          serviceSlugs = (srvs.results as any[]).map((s: any) => s.slug);
        } else if (entityType === 'combo') {
          // Extract service slug from combo slug
          const locationNames = ['santiago-centro', 'huechuraba', 'lampa', 'quilicura', 'la-reina', 'las-condes', 'lo-barnechea', 'vitacura', 'conchali', 'pudahuel', 'renca', 'la-pintana', 'los-andes', 'san-felipe'];
          const matchingLocation = locationNames.find(loc => entitySlug.endsWith('-' + loc));
          if (matchingLocation) {
            const serviceSlug = entitySlug.replace('-' + matchingLocation, '');
            serviceSlugs = [serviceSlug];
          }
        } else {
          serviceSlugs = [entitySlug];
        }

        // Get positions from Serper for this entity
        let positionsQuery = '';
        const params: any[] = [];
        if (entityType === 'service') {
          positionsQuery = `
            SELECT sq.query_text, sq.location_slug, sr.position, sr.title, sr.link, sr.domain, sr.site_type, sr.snippet
            FROM serper_queries sq
            LEFT JOIN serper_results sr ON sq.id = sr.query_id
            WHERE sq.service_slug = ? AND sq.status = 'completed'
            ORDER BY sq.location_slug, sr.position ASC
          `;
          params.push(entitySlug);
        } else if (entityType === 'location') {
          positionsQuery = `
            SELECT sq.service_slug, sq.query_text, sr.position, sr.title, sr.link, sr.domain, sr.site_type, sr.snippet
            FROM serper_queries sq
            LEFT JOIN serper_results sr ON sq.id = sr.query_id
            WHERE sq.location_slug = ? AND sq.status = 'completed'
            ORDER BY sq.service_slug, sr.position ASC
          `;
          params.push(entitySlug);
        } else if (entityType === 'combo') {
          // Extract service and location from combo slug
          const locationNames = ['santiago-centro', 'huechuraba', 'lampa', 'quilicura', 'la-reina', 'las-condes', 'lo-barnechea', 'vitacura', 'conchali', 'pudahuel', 'renca', 'la-pintana', 'los-andes', 'san-felipe'];
          const matchingLocation = locationNames.find(loc => entitySlug.endsWith('-' + loc));
          if (matchingLocation) {
            const serviceSlug = entitySlug.replace('-' + matchingLocation, '');
            positionsQuery = `
              SELECT sq.service_slug, sq.location_slug, sq.query_text, sr.position, sr.title, sr.link, sr.domain, sr.site_type, sr.snippet
              FROM serper_queries sq
              LEFT JOIN serper_results sr ON sq.id = sr.query_id
              WHERE sq.service_slug = ? AND sq.location_slug = ? AND sq.status = 'completed'
              ORDER BY sr.position ASC
            `;
            params.push(serviceSlug, matchingLocation);
          } else {
            positionsQuery = 'SELECT 1 as empty';
          }
        } else {
          positionsQuery = `
            SELECT sq.service_slug, sq.location_slug, sq.query_text, sr.position, sr.title, sr.link, sr.domain, sr.site_type, sr.snippet
            FROM serper_queries sq
            LEFT JOIN serper_results sr ON sq.id = sr.query_id
            WHERE sq.status = 'completed'
            ORDER BY sq.service_slug, sq.location_slug, sr.position ASC
          `;
        }

        const [positionsResult, paaResult, gapsResult] = await Promise.all([
          env.DB.prepare(positionsQuery).bind(...params).all(),
          // PAA questions for this entity's keywords
          entityType !== 'sector'
            ? env.DB.prepare(`
                SELECT sr.title as question, sr.snippet as answer_preview, sq.service_slug, sq.location_slug
                FROM serper_results sr
                JOIN serper_queries sq ON sr.query_id = sq.id
                WHERE sr.result_type = 'paa' AND sq.status = 'completed'
                ${entityType === 'service' ? 'AND sq.service_slug = ?' : entityType === 'location' ? 'AND sq.location_slug = ?' : entityType === 'combo' ? 'AND sq.service_slug = ? AND sq.location_slug = ?' : ''}
                ORDER BY sq.service_slug, sq.location_slug
                LIMIT 20
              `).bind(...params).all()
            : env.DB.prepare('SELECT 1 as dummy').all(),
          // Content gaps - keywords where GuardMan doesn't appear or is weak
          env.DB.prepare(`
            SELECT sq.service_slug, sq.location_slug, sq.query_text, sq.endpoint,
              MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as guardman_pos,
              COUNT(CASE WHEN sr.site_type = 'direct_competitor' AND sr.position <= 5 THEN 1 END) as top5_competitors,
              COUNT(CASE WHEN sr.site_type = 'direct_competitor' AND sr.position <= 10 THEN 1 END) as top10_competitors
            FROM serper_queries sq
            LEFT JOIN serper_results sr ON sq.id = sr.query_id
            WHERE sq.status = 'completed' AND sq.endpoint = 'search'
            ${entityType === 'service' ? 'AND sq.service_slug = ?' : entityType === 'location' ? 'AND sq.location_slug = ?' : entityType === 'combo' ? 'AND sq.service_slug = ? AND sq.location_slug = ?' : ''}
            GROUP BY sq.id
            HAVING guardman_pos > 5 OR guardman_pos = 999
            ORDER BY top5_competitors DESC, guardman_pos ASC
            LIMIT 20
          `).bind(...params).all(),
        ]);

        const positions = positionsResult.results as any[];
        const paa = paaResult.results as any[];
        const gaps = gapsResult.results as any[];

        // Separate GuardMan positions vs competitors
        const guardmanPositions = positions.filter((p: any) => p.site_type === 'own' && p.position);
        const competitorPositions = positions.filter((p: any) => p.site_type === 'direct_competitor' && p.position);

        // Get unique competitor domains for this entity
        const competitorDomains = [...new Set(competitorPositions.map((p: any) => p.domain))];

        // Calculate stats
        const stats = {
          total_queries: new Set(positions.map((p: any) => p.query_text)).size,
          guardman_appearances: guardmanPositions.length,
          guardman_top3: guardmanPositions.filter((p: any) => p.position <= 3).length,
          guardman_top10: guardmanPositions.filter((p: any) => p.position <= 10).length,
          guardman_no_show: new Set(positions.filter((p: any) => !p.position || p.position > 10).map((p: any) => p.query_text)).size,
          competitors_tracked: competitorDomains.length,
          content_gaps: gaps.length,
          paa_available: paa.length,
        };

        // Build intelligence summary
        const intelligence = {
          entity: { type: entityType, slug: entitySlug, name: entityName },
          positions: {
            guardman: guardmanPositions.slice(0, 20),
            competitors: competitorPositions.slice(0, 50),
            domains: competitorDomains.slice(0, 20),
          },
          gaps: gaps.slice(0, 15).map((g: any) => ({
            service: g.service_slug,
            location: g.location_slug,
            query: g.query_text,
            guardman_pos: g.guardman_pos === 999 ? null : g.guardman_pos,
            top5: g.top5_competitors,
            top10: g.top10_competitors,
            priority: g.top5_competitors >= 3 ? 'HIGH' : g.top5_competitors >= 1 ? 'MEDIUM' : 'LOW',
          })),
          paa: paa.slice(0, 10).map((p: any) => ({
            question: p.question,
            answer_preview: p.answer_preview,
            service: p.service_slug,
            location: p.location_slug,
          })),
          stats,
        };

        return Response.json({ ok: true, data: intelligence }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/content/generate/bulk - Generate content for entities without content
    if (path === '/api/content/generate/bulk' && method === 'POST') {
      const body = await request.json() as any;
      const { entity_types } = body; // optional filter: ['service', 'location', 'sector', 'combo']

      try {
        // Get all entities without content
        let typeFilter = '';
        const params: any[] = [];
        if (entity_types && entity_types.length > 0) {
          typeFilter = ' AND entity_type IN (' + entity_types.map(() => '?').join(',') + ')';
          params.push(...entity_types);
        }

        // Get entities that have no content or score < 50
        const [services, locations, sectors] = await Promise.all([
          env.DB.prepare('SELECT slug, name FROM services').all(),
          env.DB.prepare('SELECT slug, name FROM locations').all(),
          env.DB.prepare('SELECT slug, name FROM sectors').all(),
        ]);

        // Get existing content
        const existingContent = await env.DB.prepare(`
          SELECT DISTINCT entity_type, entity_slug FROM content_versions cv1
          WHERE version = (SELECT MAX(version) FROM content_versions cv2 WHERE cv2.entity_type = cv1.entity_type AND cv2.entity_slug = cv1.entity_slug)
          AND EXISTS (SELECT 1 FROM content_versions cv3 WHERE cv3.entity_type = cv1.entity_type AND cv3.entity_slug = cv1.entity_slug AND cv3.content_json IS NOT NULL)
        `).all();

        const existingSet = new Set((existingContent.results as any[]).map((c: any) => c.entity_type + '|' + c.entity_slug));

        const entitiesToGenerate: { type: string, slug: string, name: string }[] = [];
        (services.results as any[]).forEach((s: any) => { if (!existingSet.has('service|' + s.slug)) entitiesToGenerate.push({ type: 'service', slug: s.slug, name: s.name }); });
        (locations.results as any[]).forEach((l: any) => { if (!existingSet.has('location|' + l.slug)) entitiesToGenerate.push({ type: 'location', slug: l.slug, name: l.name }); });
        (sectors.results as any[]).forEach((s: any) => { if (!existingSet.has('sector|' + s.slug)) entitiesToGenerate.push({ type: 'sector', slug: s.slug, name: s.name }); });

        if (entitiesToGenerate.length === 0) {
          return Response.json({ ok: true, data: { message: 'No entities need content generation', generated: 0, failed: 0, results: [] } }, { headers: cors });
        }

        // Generate content for each entity sequentially to avoid rate limiting
        const results: { type: string, slug: string, name: string, success: boolean, error?: string }[] = [];
        for (const entity of entitiesToGenerate) {
          try {
            const result = await generateContent(env, entity.type, entity.slug, entity.name);
            const content = result.content;
            const wordCount = JSON.stringify(content).length;
            const versionResult = await env.DB.prepare('SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?').bind(entity.type, entity.slug).first();
            const nextVersion = versionResult?.next_version || 1;
            await env.DB.prepare('INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count) VALUES (?, ?, ?, ?, ?, ?)').bind(entity.type, entity.slug, nextVersion, JSON.stringify(content), 'ai', wordCount).run();
            results.push({ type: entity.type, slug: entity.slug, name: entity.name, success: true });
          } catch (err: any) {
            results.push({ type: entity.type, slug: entity.slug, name: entity.name, success: false, error: err.message });
          }
          // Small delay to avoid rate limiting
          await new Promise(r => setTimeout(r, 500));
        }

        const generated = results.filter(r => r.success).length;
        const failed = results.filter(r => !r.success).length;

        return Response.json({ ok: true, data: { message: 'Bulk generation complete', generated, failed, total: entitiesToGenerate.length, results } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/content/generate/selected - Generate content for specific entities
    if (path === '/api/content/generate/selected' && method === 'POST') {
      const body = await request.json() as any;
      const { entities } = body;

      if (!entities || !Array.isArray(entities) || entities.length === 0) {
        return Response.json({ ok: false, error: 'entities array required' }, { status: 400, headers: cors });
      }

      try {
        const results: { type: string, slug: string, name: string, success: boolean, error?: string }[] = [];

        for (const entity of entities) {
          const { type, slug, name } = entity;
          try {
            const result = await generateContent(env, type, slug, name || slug);
            const content = result.content;
            const wordCount = JSON.stringify(content).length;
            const versionResult = await env.DB.prepare('SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?').bind(type, slug).first();
            const nextVersion = versionResult?.next_version || 1;
            await env.DB.prepare('INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count) VALUES (?, ?, ?, ?, ?, ?)').bind(type, slug, nextVersion, JSON.stringify(content), 'ai', wordCount).run();
            results.push({ type, slug, name: name || slug, success: true });
          } catch (err: any) {
            results.push({ type, slug, name: name || slug, success: false, error: err.message });
          }
          await new Promise(r => setTimeout(r, 500));
        }

        const generated = results.filter(r => r.success).length;
        const failed = results.filter(r => !r.success).length;

        return Response.json({ ok: true, data: { message: 'Selective generation complete', generated, failed, total: entities.length, results } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // POST /api/content/publish/selected - Publish specific entities
    if (path === '/api/content/publish/selected' && method === 'POST') {
      const body = await request.json() as any;
      const { entities } = body;

      if (!entities || !Array.isArray(entities) || entities.length === 0) {
        return Response.json({ ok: false, error: 'entities array required' }, { status: 400, headers: cors });
      }

      try {
        const results: { type: string, slug: string, success: boolean, error?: string }[] = [];
        const id = env.PUBLISHER_AGENT.idFromName('default');
        const stub = env.PUBLISHER_AGENT.get(id);

        for (const entity of entities) {
          const { type, slug } = entity;
          try {
            const latest = await env.DB.prepare(
              'SELECT content_json, version FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
            ).bind(type, slug).first();

            if (!latest?.content_json) {
              results.push({ type, slug, success: false, error: 'No content found' });
              continue;
            }

            const contentJson = latest.content_json as string;
            const version = (latest.version as number) || 1;
            const score = calculateContentScore(JSON.parse(contentJson)).score;

            await env.DB.prepare(`
              INSERT INTO publish_queue (entity_type, entity_slug, content_json, score, status, version)
              VALUES (?, ?, ?, ?, 'approved', ?)
              ON CONFLICT(entity_type, entity_slug) DO UPDATE SET
                content_json = excluded.content_json, score = excluded.score, status = 'approved', version = excluded.version
            `).bind(type, slug, contentJson, score, version).run();

            const result = await stub.schedulePublish({
              entityType: type,
              entitySlug: slug,
              contentJson,
              score,
              version,
            });

            results.push({ type, slug, success: true });
          } catch (err: any) {
            results.push({ type, slug, success: false, error: err.message });
          }
        }

        const published = results.filter(r => r.success).length;
        const failed = results.filter(r => !r.success).length;

        return Response.json({ ok: true, data: { message: 'Selective publish complete', published, failed, total: entities.length, results } }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }
    
    // ===== ENTITY IMAGE MANAGEMENT =====
    
    // GET /api/entities/:type/:slug/images — List images for entity
    // POST /api/entities/:type/:slug/images — Upload + associate image
    // POST /api/entities/:type/:slug/images/hero — Set hero image
    // POST /api/entities/:type/:slug/images/og — Set OG image
    // PUT /api/entities/:type/:slug/images/:id — Update image metadata
    // DELETE /api/entities/:type/:slug/images/:id — Delete image
    
    // ===== Entity Images → now uses media_library + media_entities =====
    const entityImgMatch = path.match(/^\/api\/entities\/([^/]+)\/([^/]+)\/images(?:\/(\d+))?(?:\/(hero|og))?$/);
    if (entityImgMatch) {
      const [, entityType, entitySlug, imageId, specialUsage] = entityImgMatch;
      
      // GET: List images for entity
      if (method === 'GET' && !imageId && !specialUsage) {
        const { results } = await env.DB.prepare(
          `SELECT me.id, me.usage, m.key, m.filename, m.alt_text, m.category, m.mime_type, m.file_size
           FROM media_entities me JOIN media_library m ON me.media_id = m.id
           WHERE me.entity_type = ? AND me.entity_slug = ? ORDER BY me.sort_order`
        ).bind(entityType, entitySlug).all();
        return Response.json({ ok: true, data: results }, { headers: cors });
      }
      
      // POST: Set hero/og via media_id
      if (method === 'POST' && !imageId && (specialUsage === 'hero' || specialUsage === 'og')) {
        try {
          const body = await request.json() as any;
          const { media_id } = body;
          if (!media_id) return Response.json({ ok: false, error: 'media_id required' }, { status: 400, headers: cors });
          // Upsert: assign media to entity with usage
          await env.DB.prepare(
            `INSERT INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES (?, ?, ?, ?)
             ON CONFLICT(media_id, entity_type, entity_slug, usage) DO UPDATE SET sort_order = 0`
          ).bind(media_id, entityType, entitySlug, specialUsage).run();
          return Response.json({ ok: true }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }
      
      // POST: Upload new image and assign to entity
      if (method === 'POST' && !imageId) {
        try {
          const formData = await request.formData();
          const file = formData.get('file') as File;
          const usage = (formData.get('type') as string) || 'gallery';
          const altText = (formData.get('alt_text') as string) || '';
          
          if (!file) return Response.json({ ok: false, error: 'No file' }, { status: 400, headers: cors });
          const ALLOWED = ['image/jpeg', 'image/png', 'image/webp'];
          if (!ALLOWED.includes(file.type)) return Response.json({ ok: false, error: 'Invalid type' }, { status: 400, headers: cors });
          
          const ext = file.name.split('.').pop()?.toLowerCase() || 'webp';
          const key = `images/${entityType}-${entitySlug}-${usage}-${Date.now()}.${ext}`;
          await env.IMAGES.put(key, file.stream(), { httpMetadata: { contentType: file.type } });
          
          // Insert into media_library
          const mediaResult = await env.DB.prepare(
            'INSERT INTO media_library (key, filename, alt_text, mime_type, file_size, category) VALUES (?, ?, ?, ?, ?, ?)'
          ).bind(key, file.name, altText, file.type, file.size, entityType).run();
          const mediaId = mediaResult.meta.last_row_id;
          
          // Assign to entity
          await env.DB.prepare(
            'INSERT INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES (?, ?, ?, ?)'
          ).bind(mediaId, entityType, entitySlug, usage).run();
          
          return Response.json({ ok: true, data: { id: mediaId, key, url: `/${key}`, usage, size: file.size } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }
      
      // DELETE: Remove image assignment
      if (method === 'DELETE' && imageId) {
        try {
          await env.DB.prepare('DELETE FROM media_entities WHERE id = ? AND entity_type = ? AND entity_slug = ?')
            .bind(imageId, entityType, entitySlug).run();
          return Response.json({ ok: true }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }
    }
    
    // SEO & Intelligence APIs

      return null;
    },
  },
  {
    pattern: /^\/api\/entities\//,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;
      // Entity images are handled in the content_code block above (entityImgMatch)
      return null;
    },
  },
  {
    pattern: /^\/api\/images$/,
    methods: ['GET', 'POST', 'DELETE'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

    if (path === '/api/images' && method === 'GET') {
      const objects = await env.IMAGES.list({ limit: 1000 });
      const apiBase = 'https://guardman-admin-api.oficinadesarrollo33.workers.dev';
      return Response.json({
        ok: true,
        data: objects.objects.map(o => ({ key: o.key, size: o.size, uploaded: o.uploaded, url: `${apiBase}/api/images/${o.key}` }))
      }, { headers: cors });
    }

    if (path === '/api/images' && method === 'POST') {
      const formData = await request.formData();
      const file = formData.get('file') as File;
      const folder = (formData.get('folder') as string) || 'images';
      const key = `${folder}/${file.name}`;
      await env.IMAGES.put(key, file.stream(), { httpMetadata: { contentType: file.type } });
      const imageUrl = `https://guardman-admin-api.oficinadesarrollo33.workers.dev/api/images/${key}`;
      return Response.json({ ok: true, data: { key, url: imageUrl, size: file.size } }, { headers: cors });
    }

    // Serve images from R2
    if (path.startsWith('/api/images/') && method === 'GET') {
      const key = path.replace('/api/images/', '');
      const object = await env.IMAGES.get(key);
      if (!object) return new Response('Not found', { status: 404 });
      const ext = key.split('.').pop()?.toLowerCase();
      const mimeMap: Record<string, string> = { webp: 'image/webp', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png' };
      const ct = object.httpMetadata?.contentType || mimeMap[ext || ''] || 'application/octet-stream';
      const headers = new Headers();
      headers.set('Cache-Control', 'public, max-age=31536000');
      headers.set('Content-Type', ct);
      return new Response(object.body, { headers });
    }

    if (path.startsWith('/api/images/') && method === 'DELETE') {
      const key = path.replace('/api/images/', '');
      await env.IMAGES.delete(key);
      return Response.json({ ok: true }, { headers: cors });
    }

    // SEO & Intelligence APIs

      return null;
    },
  },
];
