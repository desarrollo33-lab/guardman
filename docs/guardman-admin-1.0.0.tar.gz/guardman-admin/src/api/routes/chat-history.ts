// GuardMan Admin — Chat History Routes (D1 persistence)
// Item 14: Persistencia de historial en D1
import { CORS_HEADERS } from '../../types';

const cors = CORS_HEADERS;
const MAX_MESSAGES_PER_SESSION = 100;
const MAX_SESSIONS = 20;

export const chatHistoryRoutes = [
  {
    pattern: /^\/api\/chat\//,
    methods: ['GET', 'POST', 'DELETE'],
    handler: async (request: Request, env: any, ctx: any, match: RegExpMatchArray) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

      // ── Ensure tables exist ──────────────────
      await ensureTables(env);

      // ── GET /api/chat/sessions — List sessions ──
      if (path === '/api/chat/sessions' && method === 'GET') {
        try {
          const sessions = await env.DB.prepare(
            `SELECT id, title, created_at, updated_at, message_count
             FROM chat_sessions ORDER BY updated_at DESC LIMIT ?`
          ).bind(MAX_SESSIONS).all();

          return Response.json({ ok: true, data: { sessions: sessions.results } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // ── POST /api/chat/sessions — Create new session ──
      if (path === '/api/chat/sessions' && method === 'POST') {
        try {
          const body = await request.json().catch(() => ({})) as any;
          const title = body.title || 'Nueva sesión';
          const now = new Date().toISOString();

          const result = await env.DB.prepare(
            `INSERT INTO chat_sessions (title, created_at, updated_at, message_count)
             VALUES (?, ?, ?, 0)`
          ).bind(title, now, now).run();

          const sessionId = result.meta?.last_row_id;

          return Response.json({
            ok: true,
            data: { id: sessionId, title, created_at: now, updated_at: now, message_count: 0 }
          }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // ── GET /api/chat/sessions/:id — Get session with messages ──
      const sessionMatch = path.match(/^\/api\/chat\/sessions\/(\d+)$/);
      if (sessionMatch && method === 'GET') {
        try {
          const sessionId = parseInt(sessionMatch[1]);

          const session = await env.DB.prepare(
            `SELECT id, title, created_at, updated_at, message_count FROM chat_sessions WHERE id = ?`
          ).bind(sessionId).first();

          if (!session) {
            return Response.json({ ok: false, error: 'Session not found' }, { status: 404, headers: cors });
          }

          const messages = await env.DB.prepare(
            `SELECT id, role, parts, created_at FROM chat_messages WHERE session_id = ? ORDER BY id ASC`
          ).bind(sessionId).all();

          return Response.json({
            ok: true,
            data: { session, messages: messages.results.map((m: any) => ({
              ...m,
              parts: typeof m.parts === 'string' ? JSON.parse(m.parts) : m.parts,
            }))}
          }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // ── DELETE /api/chat/sessions/:id — Delete session ──
      if (sessionMatch && method === 'DELETE') {
        try {
          const sessionId = parseInt(sessionMatch[1]);

          await env.DB.prepare('DELETE FROM chat_messages WHERE session_id = ?').bind(sessionId).run();
          await env.DB.prepare('DELETE FROM chat_sessions WHERE id = ?').bind(sessionId).run();

          return Response.json({ ok: true, data: { deleted: sessionId } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // ── POST /api/chat/sessions/:id/messages — Save messages (batch) ──
      const msgMatch = path.match(/^\/api\/chat\/sessions\/(\d+)\/messages$/);
      if (msgMatch && method === 'POST') {
        try {
          const sessionId = parseInt(msgMatch[1]);
          const body = await request.json() as any;
          const messages: any[] = body.messages || [];

          if (!Array.isArray(messages) || messages.length === 0) {
            return Response.json({ ok: false, error: 'No messages provided' }, { status: 400, headers: cors });
          }

          // Verify session exists
          const session = await env.DB.prepare('SELECT id FROM chat_sessions WHERE id = ?').bind(sessionId).first();
          if (!session) {
            return Response.json({ ok: false, error: 'Session not found' }, { status: 404, headers: cors });
          }

          // Clear existing messages and insert new batch (full sync approach)
          await env.DB.prepare('DELETE FROM chat_messages WHERE session_id = ?').bind(sessionId).run();

          const now = new Date().toISOString();
          let count = 0;
          for (const msg of messages.slice(-MAX_MESSAGES_PER_SESSION)) {
            try {
              await env.DB.prepare(
                `INSERT INTO chat_messages (session_id, role, parts, created_at) VALUES (?, ?, ?, ?)`
              ).bind(
                sessionId,
                msg.role || 'user',
                JSON.stringify(msg.parts || [{ type: 'text', text: msg.content || '' }]),
                msg.created_at || now
              ).run();
              count++;
            } catch (e) {
              // Skip malformed messages
              console.error('Failed to save message:', e);
            }
          }

          // Update session metadata
          const lastMsg = messages[messages.length - 1];
          const title = extractTitle(messages);
          await env.DB.prepare(
            `UPDATE chat_sessions SET updated_at = ?, message_count = ?, title = COALESCE(?, title) WHERE id = ?`
          ).bind(now, count, title, sessionId).run();

          return Response.json({ ok: true, data: { saved: count } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      // ── POST /api/chat/sync — Save current session (auto-create if needed) ──
      if (path === '/api/chat/sync' && method === 'POST') {
        try {
          const body = await request.json() as any;
          const { session_id, messages, title } = body;

          if (!Array.isArray(messages)) {
            return Response.json({ ok: false, error: 'messages array required' }, { status: 400, headers: cors });
          }

          let sessionId = session_id;
          const now = new Date().toISOString();

          // Create session if not provided
          if (!sessionId) {
            const result = await env.DB.prepare(
              `INSERT INTO chat_sessions (title, created_at, updated_at, message_count) VALUES (?, ?, ?, 0)`
            ).bind(title || extractTitle(messages) || 'Nueva sesión', now, now).run();
            sessionId = result.meta?.last_row_id;
          }

          // Clear + insert messages
          await env.DB.prepare('DELETE FROM chat_messages WHERE session_id = ?').bind(sessionId).run();

          let count = 0;
          for (const msg of messages.slice(-MAX_MESSAGES_PER_SESSION)) {
            try {
              await env.DB.prepare(
                `INSERT INTO chat_messages (session_id, role, parts, created_at) VALUES (?, ?, ?, ?)`
              ).bind(
                sessionId,
                msg.role || 'user',
                JSON.stringify(msg.parts || [{ type: 'text', text: msg.content || '' }]),
                msg.created_at || now
              ).run();
              count++;
            } catch (e) {
              console.error('Failed to save message:', e);
            }
          }

          // Update session
          const autoTitle = extractTitle(messages);
          await env.DB.prepare(
            `UPDATE chat_sessions SET updated_at = ?, message_count = ?, title = COALESCE(?, title) WHERE id = ?`
          ).bind(now, count, autoTitle, sessionId).run();

          return Response.json({ ok: true, data: { session_id: sessionId, saved: count } }, { headers: cors });
        } catch (err: any) {
          return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
        }
      }

      return null;
    },
  },
];

// ── Helpers ──────────────────────────────────

async function ensureTables(env: any) {
  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS chat_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL DEFAULT 'Nueva sesión',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      message_count INTEGER DEFAULT 0
    )
  `).run().catch(() => {});

  await env.DB.prepare(`
    CREATE TABLE IF NOT EXISTS chat_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
      parts TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      FOREIGN KEY (session_id) REFERENCES chat_sessions(id) ON DELETE CASCADE
    )
  `).run().catch(() => {});

  // Create index for fast lookup
  await env.DB.prepare(
    `CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id)`
  ).run().catch(() => {});
}

function extractTitle(messages: any[]): string | null {
  // Use first user message as title (truncated)
  const firstUser = messages.find(m => m.role === 'user');
  if (!firstUser) return null;

  let text = '';
  const parts = firstUser.parts || [];
  for (const p of parts) {
    if (p.type === 'text' && p.text) {
      text = p.text;
      break;
    }
  }
  if (!text && (firstUser as any).content) text = (firstUser as any).content;

  if (!text) return null;
  return text.length > 60 ? text.substring(0, 57) + '...' : text;
}
