// GuardMan Admin — Preview Data Service (WorkerEntrypoint)
// Provides RPC methods for Dynamic Worker preview rendering.
// Following the Dynamic Workers pattern from cloudflare/dynamic-worker-based-reports.

import { WorkerEntrypoint } from "cloudflare:workers";

const LOCATION_SLUGS = [
  'santiago-centro', 'huechuraba', 'lampa', 'quilicura', 'la-reina',
  'las-condes', 'lo-barnechea', 'vitacura', 'conchali', 'pudahuel',
  'renca', 'la-pintana', 'los-andes', 'san-felipe',
];

interface PreviewData {
  entityType: string;
  entitySlug: string;
  entityName: string;
  urlPath: string;
  content: any;
  images: { hero?: string; og?: string; gallery?: string[] };
  score: number;
  scoreDetails: { seo: number; content: number; structure: number; keywords: number };
}

export class PreviewDataService extends WorkerEntrypoint {
  /**
   * Fetch content data for preview rendering — called via RPC from Dynamic Worker
   */
  async getContent(entityType: string, entitySlug: string): Promise<PreviewData> {
    const env = this.env as any;

    const entityName = await this.resolveEntityName(env, entityType, entitySlug);
    const urlPath = this.resolveUrlPath(entityType, entitySlug);
    const content = await this.fetchContent(env, entityType, entitySlug);
    const images = await this.fetchImages(env, entityType, entitySlug);

    let score = 0;
    let scoreDetails = { seo: 0, content: 0, structure: 0, keywords: 0 };
    if (content) {
      const { calculateContentScore } = await import('../../services/scoring');
      const scored = calculateContentScore(content);
      score = scored.score;
      scoreDetails = scored.details;
    }

    return { entityType, entitySlug, entityName, urlPath, content, images, score, scoreDetails };
  }

  private async resolveEntityName(env: any, entityType: string, entitySlug: string): Promise<string> {
    if (entityType === 'service') {
      const svc = await env.DB.prepare('SELECT name FROM services WHERE slug = ?').bind(entitySlug).first();
      return svc?.name || entitySlug;
    } else if (entityType === 'location') {
      const loc = await env.DB.prepare('SELECT name FROM locations WHERE slug = ?').bind(entitySlug).first();
      return loc?.name || entitySlug;
    } else if (entityType === 'sector') {
      const sec = await env.DB.prepare('SELECT name FROM sectors WHERE slug = ?').bind(entitySlug).first();
      return sec?.name || entitySlug;
    } else if (entityType === 'combo') {
      const { serviceSlug, locationSlug } = parseComboSlug(entitySlug);
      if (serviceSlug && locationSlug) {
        const [svc, loc] = await Promise.all([
          env.DB.prepare('SELECT name FROM services WHERE slug = ?').bind(serviceSlug).first(),
          env.DB.prepare('SELECT name FROM locations WHERE slug = ?').bind(locationSlug).first(),
        ]);
        return `${svc?.name || serviceSlug} en ${loc?.name || locationSlug}`;
      }
    }
    return entitySlug;
  }

  private async fetchContent(env: any, entityType: string, entitySlug: string): Promise<any> {
    if (entityType === 'combo') {
      const { serviceSlug, locationSlug } = parseComboSlug(entitySlug);
      if (serviceSlug && locationSlug) {
        const comboRow = await env.DB.prepare(
          'SELECT h1, seo_title, meta_description, intro_paragraph, faqs_json, cta_text, cta_button FROM combo_content WHERE service_slug = ? AND location_slug = ?'
        ).bind(serviceSlug, locationSlug).first();
        if (comboRow) {
          const sections: any = {};
          if (comboRow.h1) sections.hero = { heading: comboRow.h1 };
          if (comboRow.intro_paragraph) sections.intro = { paragraphs: [comboRow.intro_paragraph] };
          if (comboRow.seo_title) sections.meta = { title: comboRow.seo_title, description: comboRow.meta_description || '' };
          if (comboRow.cta_text) sections.cta = { heading: comboRow.cta_text, button: comboRow.cta_button || '' };
          if (comboRow.faqs_json) { try { sections.faqs = { items: JSON.parse(comboRow.faqs_json as string) }; } catch {} }
          return { sections };
        }
      }
      return null;
    }
    const latest = await env.DB.prepare(
      'SELECT content_json, version FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
    ).bind(entityType, entitySlug).first();
    if (latest?.content_json) return JSON.parse(latest.content_json as string);
    return null;
  }

  private async fetchImages(env: any, entityType: string, entitySlug: string): Promise<{ hero?: string; og?: string; gallery?: string[] }> {
    const images: { hero?: string; og?: string; gallery?: string[] } = {};
    try {
      const { results: imgRows } = await env.DB.prepare(
        'SELECT me.usage, m.key FROM media_entities me JOIN media_library m ON me.media_id = m.id WHERE me.entity_type = ? AND me.entity_slug = ?'
      ).bind(entityType, entitySlug).all();
      for (const img of (imgRows as any[])) {
        const url = `/${img.key}`;
        if (img.usage === 'hero') images.hero = url;
        else if (img.usage === 'og') images.og = url;
        else { if (!images.gallery) images.gallery = []; images.gallery.push(url); }
      }
    } catch {}
    return images;
  }

  private resolveUrlPath(entityType: string, entitySlug: string): string {
    switch (entityType) {
      case 'service': return `/servicios/${entitySlug}`;
      case 'location': return `/ubicaciones/${entitySlug}`;
      case 'sector': return `/sectores/${entitySlug}`;
      default: return `/servicios/${entitySlug}`;
    }
  }
}

function parseComboSlug(slug: string): { serviceSlug: string; locationSlug: string } {
  for (const loc of LOCATION_SLUGS) {
    if (slug.endsWith('-' + loc)) {
      return { serviceSlug: slug.substring(0, slug.length - loc.length - 1), locationSlug: loc };
    }
  }
  return { serviceSlug: slug, locationSlug: '' };
}
