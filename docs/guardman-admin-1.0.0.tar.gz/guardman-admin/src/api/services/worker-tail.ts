// GuardMan Admin — Dynamic Worker Tail Service
// Captures logs from Dynamic Workers and forwards them to LogSession DO.
// Also provides the /api/monitor/logs endpoint for querying logs.

import { LogSession } from './log-session';

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

/**
 * Log capture functions for use in routes and services.
 * These send logs to a LogSession DO identified by a session key.
 */
export async function captureLog(
  env: any,
  sessionKey: string,
  entry: { source: string; level: string; message: string; data?: any }
): Promise<void> {
  try {
    if (!env.LOG_SESSION) return;
    const id = env.LOG_SESSION.idFromName(sessionKey);
    const stub = env.LOG_SESSION.get(id);
    await stub.fetch(new Request('https://log-session.local/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entries: [entry] }),
    }));
  } catch (err: any) {
    console.error('LogSession capture failed:', err.message);
  }
}

/**
 * Capture multiple logs at once
 */
export async function captureLogs(
  env: any,
  sessionKey: string,
  entries: Array<{ source: string; level: string; message: string; data?: any }>
): Promise<void> {
  try {
    if (!env.LOG_SESSION) return;
    const id = env.LOG_SESSION.idFromName(sessionKey);
    const stub = env.LOG_SESSION.get(id);
    await stub.fetch(new Request('https://log-session.local/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entries }),
    }));
  } catch (err: any) {
    console.error('LogSession capture failed:', err.message);
  }
}

/**
 * Register monitor logs routes
 * GET /api/monitor/logs — Query logs from LogSession
 * GET /api/monitor/logs/stream — SSE real-time log stream
 * POST /api/monitor/logs/clear — Clear logs
 * GET /api/monitor/logs/stats — Log statistics
 */
export const logRoutes = [
  // POST /api/monitor/logs/add — Add a log entry to LogSession
  {
    pattern: /^\/api\/monitor\/logs\/add$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any) => {
      if (!env.LOG_SESSION) {
        return Response.json({ ok: false, error: 'LogSession not configured' }, { status: 501, headers: CORS_HEADERS });
      }
      try {
        const body = await request.json() as any;
        const sessionKey = body.session || 'default';
        const entry = { source: body.source || 'api', level: body.level || 'info', message: body.message || '', data: body.data };
        const id = env.LOG_SESSION.idFromName(sessionKey);
        const stub = env.LOG_SESSION.get(id);
        const resp = await stub.fetch(new Request('https://log-session.local/add', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ entries: [entry] }),
        }));
        const data = await resp.json();
        return Response.json(data, { headers: CORS_HEADERS });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: CORS_HEADERS });
      }
    },
  },
  // GET /api/monitor/logs/stream — SSE real-time log stream
  {
    pattern: /^\/api\/monitor\/logs\/stream$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any) => {
      if (!env.LOG_SESSION) {
        return Response.json({ ok: false, error: 'LogSession not configured' }, { status: 501, headers: CORS_HEADERS });
      }
      const url = new URL(request.url);
      const sessionKey = url.searchParams.get('session') || 'default';
      const since = url.searchParams.get('since') || '0';

      const id = env.LOG_SESSION.idFromName(sessionKey);
      const stub = env.LOG_SESSION.get(id);

      // Proxy SSE stream from LogSession DO
      const doUrl = `https://log-session.local/stream?since=${since}`;
      const response = await stub.fetch(new Request(doUrl));

      // Return the SSE stream directly
      return new Response(response.body, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
          'Access-Control-Allow-Origin': '*',
        },
      });
    },
  },
  {
    pattern: /^\/api\/monitor\/logs$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any) => {
      if (!env.LOG_SESSION) {
        return Response.json({ ok: false, error: 'LogSession not configured' }, { status: 501, headers: CORS_HEADERS });
      }
      const url = new URL(request.url);
      const sessionKey = url.searchParams.get('session') || 'default';
      const since = url.searchParams.get('since') || '0';
      const source = url.searchParams.get('source');
      const level = url.searchParams.get('level');
      const limit = url.searchParams.get('limit') || '100';

      const id = env.LOG_SESSION.idFromName(sessionKey);
      const stub = env.LOG_SESSION.get(id);

      const doUrl = `https://log-session.local/logs?since=${since}${source ? '&source=' + source : ''}${level ? '&level=' + level : ''}&limit=${limit}`;
      const response = await stub.fetch(new Request(doUrl));
      const data = await response.json();
      return Response.json(data, { headers: CORS_HEADERS });
    },
  },
  {
    pattern: /^\/api\/monitor\/logs\/stats$/,
    methods: ['GET'],
    handler: async (request: Request, env: any, ctx: any) => {
      if (!env.LOG_SESSION) {
        return Response.json({ ok: false, error: 'LogSession not configured' }, { status: 501, headers: CORS_HEADERS });
      }
      const url = new URL(request.url);
      const sessionKey = url.searchParams.get('session') || 'default';

      const id = env.LOG_SESSION.idFromName(sessionKey);
      const stub = env.LOG_SESSION.get(id);

      const response = await stub.fetch(new Request('https://log-session.local/stats'));
      const data = await response.json();
      return Response.json(data, { headers: CORS_HEADERS });
    },
  },
  {
    pattern: /^\/api\/monitor\/logs\/clear$/,
    methods: ['POST'],
    handler: async (request: Request, env: any, ctx: any) => {
      if (!env.LOG_SESSION) {
        return Response.json({ ok: false, error: 'LogSession not configured' }, { status: 501, headers: CORS_HEADERS });
      }
      const url = new URL(request.url);
      const sessionKey = url.searchParams.get('session') || 'default';

      const id = env.LOG_SESSION.idFromName(sessionKey);
      const stub = env.LOG_SESSION.get(id);

      const response = await stub.fetch(new Request('https://log-session.local/clear', { method: 'POST' }));
      const data = await response.json();
      return Response.json(data, { headers: CORS_HEADERS });
    },
  },
];
