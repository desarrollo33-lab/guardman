// GuardMan Admin — LogSession DO + DynamicWorkerTail
// Following the Dynamic Workers pattern from cloudflare/dynamic-worker-based-reports
// Uses RpcTarget for cross-isolate log waiting and WorkerEntrypoint for tail capture.

import {
  DurableObject,
  RpcTarget,
  WorkerEntrypoint,
  exports as runtimeExports,
} from "cloudflare:workers";

export interface LogEntry {
  level: string;
  message: string;
  timestamp: number;
}

type DynamicWorkerEventKind = "request" | "log" | "exception";

interface StructuredDynamicWorkerEvent {
  source: "dynamic-worker-tail";
  workerId: string;
  kind: DynamicWorkerEventKind;
  level: string;
  message: string;
  timestamp: number;
  outcome?: string;
  method?: string;
  url?: string;
  path?: string;
  status?: number;
  name?: string;
  stack?: string;
}

function normalizeLogMessage(message: unknown): string {
  if (Array.isArray(message)) {
    return message.map((entry) => typeof entry === "string" ? entry : JSON.stringify(entry)).join(" ");
  }
  return typeof message === "string" ? message : JSON.stringify(message);
}

function isFetchTraceEvent(event: TraceItem["event"]): event is TraceItemFetchEventInfo {
  return event !== null && "request" in (event as object);
}

function toRequestSummary(event: TraceItem, workerId: string): StructuredDynamicWorkerEvent | null {
  if (!isFetchTraceEvent(event.event)) return null;
  const url = (event.event as TraceItemFetchEventInfo).request.url;
  const path = new URL(url).pathname;
  const status = (event.event as TraceItemFetchEventInfo).response?.status;
  return {
    source: "dynamic-worker-tail",
    workerId,
    kind: "request",
    level: event.outcome === "exception" ? "error" : "info",
    message: `${(event.event as TraceItemFetchEventInfo).request.method} ${path}${status !== undefined ? ` -> ${status}` : ""} (${event.outcome})`,
    timestamp: event.eventTimestamp ?? Date.now(),
    outcome: event.outcome,
    method: (event.event as TraceItemFetchEventInfo).request.method,
    url,
    path,
    status,
  };
}

function toExceptionEvents(event: TraceItem, workerId: string): StructuredDynamicWorkerEvent[] {
  return event.exceptions.map((exception: TraceException) => ({
    source: "dynamic-worker-tail" as const,
    workerId,
    kind: "exception" as const,
    level: "error",
    message: exception.message,
    timestamp: exception.timestamp,
    name: exception.name,
    stack: exception.stack,
  }));
}

function toLogEvents(event: TraceItem, workerId: string): StructuredDynamicWorkerEvent[] {
  return event.logs.map((log: TraceLog) => ({
    source: "dynamic-worker-tail" as const,
    workerId,
    kind: "log" as const,
    level: log.level,
    message: normalizeLogMessage(log.message),
    timestamp: log.timestamp,
  }));
}

function toRealtimeLogEntries(events: StructuredDynamicWorkerEvent[]): LogEntry[] {
  return events
    .filter((e) => e.kind !== "request")
    .map((e) => ({
      level: e.level,
      message: e.kind === "exception" && e.name ? `${e.name}: ${e.message}` : e.message,
      timestamp: e.timestamp,
    }));
}

// LogWaiter is an RpcTarget — stays alive in the DO isolate while the caller holds the stub
class LogWaiter extends RpcTarget {
  private logs: LogEntry[] = [];
  private resolve: ((logs: LogEntry[]) => void) | undefined;

  addLogs(logs: LogEntry[]) {
    this.logs.push(...logs);
    if (this.resolve) {
      this.resolve(this.logs);
      this.resolve = undefined;
    }
  }

  async getLogs(timeoutMs: number): Promise<LogEntry[]> {
    if (this.logs.length > 0) return this.logs;
    return new Promise<LogEntry[]>((resolve) => {
      const timeout = setTimeout(() => resolve(this.logs), timeoutMs);
      this.resolve = (logs) => {
        clearTimeout(timeout);
        resolve(logs);
      };
    });
  }
}

export class LogSession extends DurableObject {
  private waiter: LogWaiter | null = null;

  async addLogs(logs: LogEntry[]) {
    if (this.waiter) {
      this.waiter.addLogs(logs);
    }
  }

  async waitForLogs(): Promise<LogWaiter> {
    this.waiter = new LogWaiter();
    return this.waiter;
  }

  // Also support HTTP-based access for the monitor/logs API
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;
    const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });

    // GET /stats
    if (path === '/stats') {
      return Response.json({ ok: true, data: { total: 0, by_level: {}, by_source: {}, oldest: null, newest: null } }, { headers });
    }

    // GET /logs
    if (path === '/logs') {
      return Response.json({ ok: true, data: [], count: 0 }, { headers });
    }

    // POST /add
    if (path === '/add' && request.method === 'POST') {
      return Response.json({ ok: true, added: 0 }, { headers });
    }

    // POST /clear
    if (path === '/clear' && request.method === 'POST') {
      return Response.json({ ok: true, message: 'Logs cleared' }, { headers });
    }

    return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers });
  }
}

// --- Cross-isolate exports access ---
type LogSessionExports = {
  LogSession: {
    getByName(name: string): {
      addLogs(logs: LogEntry[]): Promise<void>;
      waitForLogs(): Promise<LogWaiter>;
    };
  };
};

const moduleExports = runtimeExports as unknown as LogSessionExports;

// --- DynamicWorkerTail ---

interface DynamicWorkerTailProps {
  workerId: string;
}

export class DynamicWorkerTail extends WorkerEntrypoint<never, DynamicWorkerTailProps> {
  override async tail(events: TraceItem[]) {
    const logSessionStub = moduleExports.LogSession.getByName(this.ctx.props.workerId);

    for (const event of events) {
      const structuredEvents: StructuredDynamicWorkerEvent[] = [];
      const requestSummary = toRequestSummary(event, this.ctx.props.workerId);
      if (requestSummary) structuredEvents.push(requestSummary);
      structuredEvents.push(...toLogEvents(event, this.ctx.props.workerId));
      structuredEvents.push(...toExceptionEvents(event, this.ctx.props.workerId));

      if (structuredEvents.length > 0) {
        await logSessionStub.addLogs(toRealtimeLogEntries(structuredEvents));
      }
    }
  }
}
