// GuardMan Admin — Template Renderer Service
// Contains HTML templates that are injected into Dynamic Workers for preview rendering.
// These templates use the same CSS structure as guardman-site for pixel-perfect previews.

export function getTemplate(entityType: string): string {
  // All entity types use the same base template with different rendering logic
  return SERVICE_TEMPLATE;
}

// The main site CSS — extracted from guardman-site/app.css
// This is embedded into the Dynamic Worker preview HTML
export const GUARDMAN_SITE_CSS = `
:root {
  --color-primary-600: #1A2744;
  --color-primary-500: #1A3A5C;
  --color-accent: #3B82F6;
  --color-success: #10B981;
  --color-warning: #F59E0B;
  --color-error: #EF4444;
  --font-body: 'Inter', system-ui, -apple-system, sans-serif;
}

* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: var(--font-body); color: #1a1a1a; background: #fff; line-height: 1.6; }

.preview-badge {
  position: fixed; top: 0; left: 0; right: 0; z-index: 100;
  background: linear-gradient(90deg, #7c3aed, #2563eb); color: white;
  padding: 8px 16px; font-size: 13px; font-weight: 600; text-align: center;
}

.serp-preview {
  background: white; border: 1px solid #e5e7eb; border-radius: 8px;
  padding: 16px 20px; margin: 16px auto; max-width: 600px; font-family: Arial, sans-serif;
}
.serp-title { color: #1a0dab; font-size: 20px; line-height: 1.3; text-decoration: none; display: block; }
.serp-title:hover { text-decoration: underline; }
.serp-url { color: #006621; font-size: 14px; margin: 4px 0; }
.serp-desc { color: #545454; font-size: 14px; line-height: 1.58; }

section { padding: 60px 0; }
.container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }

.hero-section {
  background: linear-gradient(135deg, #1A2744, #1A3A5C); color: white;
  padding: 80px 0; position: relative; overflow: hidden;
}
.hero-section h1 { font-size: 3rem; font-weight: 800; margin-bottom: 16px; line-height: 1.1; }
.hero-section p { font-size: 1.25rem; opacity: 0.9; max-width: 600px; }

.features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px; }
.feature-card {
  display: flex; align-items: flex-start; gap: 12px; padding: 20px;
  background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.stats-section {
  background: linear-gradient(135deg, #1A2744, #1A3A5C); color: white;
  text-align: center; padding: 60px 0;
}
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 32px; margin-top: 32px; }
.stat-value { font-size: 2.5rem; font-weight: 800; }
.stat-label { font-size: 1rem; opacity: 0.8; margin-top: 4px; }

details { background: #f9fafb; border-radius: 12px; overflow: hidden; margin-bottom: 12px; }
details summary { padding: 20px; font-weight: 600; cursor: pointer; font-size: 1.1rem; }
details[open] summary { border-bottom: 1px solid #e5e7eb; }
details .answer { padding: 16px 20px; color: #4b5563; line-height: 1.7; }

.cta-section {
  background: linear-gradient(135deg, #dc2626, #b91c1c); color: white;
  text-align: center; padding: 80px 0;
}
.cta-section h2 { font-size: 2.5rem; font-weight: 800; margin-bottom: 16px; }
.cta-button {
  display: inline-block; background: white; color: #dc2626;
  padding: 16px 40px; border-radius: 12px; font-weight: 700; font-size: 1.1rem;
  text-decoration: none; margin-top: 24px;
}
.cta-button:hover { background: #f3f4f6; }

@media (max-width: 768px) {
  .hero-section h1 { font-size: 2rem; }
  .stats-grid { grid-template-columns: repeat(2, 1fr); }
  .stat-value { font-size: 1.75rem; }
}
`;

// Service page template — the main template for all entity types
const SERVICE_TEMPLATE = `
export default {
  async fetch(request, env) {
    const data = typeof env.DATA === 'string' ? JSON.parse(env.DATA) : (env.DATA || {});
    const s = data.sections || {};
    const meta = s.meta || {};
    const hero = s.hero || {};
    const intro = s.intro || {};
    const features = s.features || {};
    const issues = s.issues || {};
    const stats = s.stats || {};
    const faqs = s.faqs || {};
    const cta = s.cta || {};
    const coverage = s.coverage || {};

    function esc(str) {
      if (!str) return '';
      return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    const html = \`<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>\${esc(meta.title || data.entityName || 'Preview')} — GuardMan Chile</title>
  <style>\${GUARDMAN_CSS}</style>
</head>
<body>
  <div class="preview-badge">⚡ PREVIEW — \${esc(data.entityType)}/\${esc(data.entitySlug)}</div>

  <div style="max-width:1200px;margin:0 auto;padding-top:48px;">

    <!-- SERP Preview -->
    <div class="serp-preview">
      <a href="#" class="serp-title">\${esc(meta.title || data.entityName || '')}</a>
      <div class="serp-url">https://guardman.cl/\${esc(data.urlPath || '')}</div>
      <div class="serp-desc">\${esc(meta.description || '')}</div>
    </div>

    \${meta.title && meta.title.length > 60 ? '<div style="background:#fef3c7;border:1px solid #fbbf24;border-radius:8px;padding:8px 16px;margin:12px auto;max-width:600px;font-size:13px;color:#92400e;">⚠️ Title: ' + meta.title.length + '/60</div>' : ''}

    <!-- Hero -->
    <section class="hero-section" style="margin-top:16px;border-radius:16px 16px 0 0;">
      <div class="container">
        <h1>\${esc(hero.heading || data.entityName || '')}</h1>
        \${hero.subheading ? '<p>' + esc(hero.subheading) + '</p>' : ''}
      </div>
    </section>

    \${intro.paragraphs && intro.paragraphs.length ? \`
    <section style="background:white;">
      <div class="container">
        \${intro.heading ? '<h2 style="font-size:1.75rem;font-weight:700;margin-bottom:16px;">' + esc(intro.heading) + '</h2>' : ''}
        \${intro.paragraphs.map(p => '<p style="color:#4b5563;font-size:1.1rem;margin-bottom:12px;">' + esc(p) + '</p>').join('')}
      </div>
    </section>\` : ''}

    \${features.items && features.items.length ? \`
    <section style="background:#f9fafb;">
      <div class="container">
        <h2 style="text-align:center;font-size:1.75rem;font-weight:700;margin-bottom:32px;">\${esc(features.heading || 'Características')}</h2>
        <div class="features-grid">
          \${features.items.map(f => '<div class="feature-card"><span style="color:#10b981;font-size:1.2rem;">✓</span><span style="color:#374151;font-size:1rem;">' + esc(f) + '</span></div>').join('')}
        </div>
      </div>
    </section>\` : ''}

    \${issues.items && issues.items.length ? \`
    <section style="background:#fffbeb;">
      <div class="container">
        <h2 style="text-align:center;font-size:1.75rem;font-weight:700;margin-bottom:32px;color:#92400e;">\${esc(issues.heading || '¿Cuándo Necesitas Seguridad?')}</h2>
        <div class="features-grid">
          \${issues.items.map(i => '<div class="feature-card" style="border-left:4px solid #f59e0b;"><span style="color:#f59e0b;font-size:1.2rem;">⚡</span><span style="color:#374151;">' + esc(i) + '</span></div>').join('')}
        </div>
      </div>
    </section>\` : ''}

    \${stats.items && stats.items.length ? \`
    <section class="stats-section">
      <div class="container">
        <h2 style="font-size:1.75rem;font-weight:700;margin-bottom:24px;">\${esc(stats.heading || 'Números que nos Respaldan')}</h2>
        <div class="stats-grid">
          \${stats.items.map(st => '<div><div class="stat-value">' + esc(st.value || '') + '</div><div class="stat-label">' + esc(st.label || '') + '</div></div>').join('')}
        </div>
      </div>
    </section>\` : ''}

    \${faqs.items && faqs.items.length ? \`
    <section style="background:white;">
      <div class="container" style="max-width:800px;">
        <h2 style="text-align:center;font-size:1.75rem;font-weight:700;margin-bottom:32px;">\${esc(faqs.heading || 'Preguntas Frecuentes')}</h2>
        \${faqs.items.map(f => '<details><summary>' + esc(f.question || '') + '</summary><div class="answer">' + esc(f.answer || '') + '</div></details>').join('')}
      </div>
    </section>\` : ''}

    \${cta.heading ? \`
    <section class="cta-section" style="border-radius:0 0 16px 16px;">
      <div class="container">
        <h2>\${esc(cta.heading)}</h2>
        \${cta.subheading ? '<p style="font-size:1.1rem;opacity:0.9;max-width:600px;margin:0 auto;">' + esc(cta.subheading) + '</p>' : ''}
        \${cta.button ? '<a href="#" class="cta-button">' + esc(cta.button) + '</a>' : ''}
      </div>
    </section>\` : ''}

    <div style="text-align:center;padding:24px;color:#9ca3af;font-size:12px;">
      Preview generado el \${new Date().toLocaleString('es-CL')} — \${esc(data.entityType)}/\${esc(data.entitySlug)}
    </div>
  </div>
</body>
</html>\`;

    return new Response(html, { headers: { 'Content-Type': 'text/html' } });
  }
};
`;

export { SERVICE_TEMPLATE };
