// GuardMan Admin v5.2 — Modular API Router
// Delegates ALL route handling to modular route files.
// api.ts is now only: exports, Env interface, login, health, images (public), auth.

import { Agent } from 'agents';
import { AIGenerator, ContentQueue } from '../durable/ai-generator';
import { GMContentAgent } from '../agents/content-agent';
import { GMPublisherAgent } from '../agents/publisher-agent';
import { GMSerperSvc, GMSerperSqlite } from '../agents/serper-agent';
import { GMOrchestrator } from '../agents/orchestrator';
import { SEOAuditorAgent } from '../agents/seo-auditor';
import { CompetitorAnalystAgent } from '../agents/competitor-analyst';
import { SerperScanWorkflow } from '../workflows/serper-scan';
import { BulkGenerateWorkflow } from '../workflows/bulk-generate';
import { CORS_HEADERS } from '../types';

export type { Env } from '../api';
export const cors = CORS_HEADERS;

// Route modules
import { previewRoutes } from './routes/preview';
import { monitorRoutes } from './routes/monitor';
import { contentRoutes } from './routes/content';
import { seoRoutes } from './routes/seo';
import { serperRoutes } from './routes/serper';
import { agentsRoutes } from './routes/agents';
import { orchestratorRoutes } from './routes/orchestrator';
import { workflowsRoutes } from './routes/workflows';
import { aiRoutes } from './routes/ai';
import { contentExtraRoutes } from './routes/content-extra';
import { searchRoutes } from './routes/search';
import { memoryRoutes } from './routes/memory';
import { chatHistoryRoutes } from './routes/chat-history';
import { cmsRoutes } from './routes/cms';
import { mediaRoutes } from './routes/media';
import { adminRoutes } from './routes/admin';
import { brandRoutes } from './routes/brand';
import { crmRoutes } from './routes/crm';
import { intelRoutes } from './routes/intel/index';
import { cuestionarioCEORoutes } from './routes/cuestionario-ceo';
import { isPublicEndpoint, validateAuth } from './middleware/auth';
import { logRoutes } from './services/worker-tail';

interface Route {
  pattern: RegExp;
  methods: string[];
  handler: (request: Request, env: any, ctx: any, match: RegExpMatchArray) => Promise<Response | null>;
}

// Order matters: more specific patterns first, catch-all last
const allRoutes: Route[] = [
  // Specific routes first
  ...previewRoutes,
  ...monitorRoutes,
  ...contentRoutes,
  ...cmsRoutes,
  ...brandRoutes,
  ...cuestionarioCEORoutes,
  ...mediaRoutes,
  ...adminRoutes,
  ...seoRoutes,
  ...searchRoutes,
  ...memoryRoutes,
  ...chatHistoryRoutes,
  ...logRoutes,
  // Broader patterns last (these handle multiple sub-routes internally)
  ...aiRoutes,
  ...contentExtraRoutes,
  ...crmRoutes,
  ...intelRoutes,
  ...serperRoutes,
  ...agentsRoutes,
  ...orchestratorRoutes,
  ...workflowsRoutes,
];

export async function handleModularRoutes(request: Request, env: any, ctx: any): Promise<Response | null> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;

  // Auth check (skip for public endpoints)
  if (!isPublicEndpoint(path)) {
    const authError = validateAuth(request, env);
    if (authError) return authError;
  }

  // Route matching
  for (const route of allRoutes) {
    const match = path.match(route.pattern);
    if (match && route.methods.includes(method)) {
      const response = await route.handler(request, env, ctx, match);
      if (response) return response;
      // If handler returns null, continue to next route
    }
  }

  return null;
}
