// GuardMan — Section Merge Utility
// Safe merge: replace only the requested section, preserve everything else.

import type { SectionKey } from './section-validators';

/**
 * Merge a newly generated section into existing content_json.
 * Only the section specified by `key` is replaced.
 * All other sections and the SEO block are preserved untouched.
 */
export function mergeSection(existing: any, key: SectionKey, newData: any): any {
  // If no existing content, create minimal structure
  if (!existing || typeof existing !== 'object') {
    return {
      content: { [key]: newData },
      seo: {},
    };
  }

  // Ensure we have a content container
  const content = existing.content && typeof existing.content === 'object'
    ? { ...existing.content }
    : {};

  // Preserve SEO block if it exists
  const seo = existing.seo && typeof existing.seo === 'object'
    ? { ...existing.seo }
    : {};

  // Replace only the requested section
  content[key] = newData;

  return { content, seo };
}

/**
 * Extract a specific section from content_json.
 * Returns null if section doesn't exist.
 */
export function getSection(contentJson: any, key: SectionKey): any | null {
  if (!contentJson || typeof contentJson !== 'object') return null;
  const c = contentJson.content || contentJson;
  return c[key] || null;
}
