// GuardMan - AI Content Generation Service
// DeepSeek API integration with Serper context enrichment

import type { Env, GeneratedContent } from '../types';
import { LOCATION_SLUGS, ZONE_CONTEXT, SECTOR_TO_SERVICE } from '../types';

const SITE_BASE = 'https://4061deb7.guardman-site.pages.dev';

export function generateFallbackContent(entityType: string, entitySlug: string, entityName: string): GeneratedContent {
  const n = entityName;
  let sections: any;

  if (entityType === 'location') {
    sections = {
      hero: { heading: 'Seguridad Privada en ' + n, subheading: 'Empresa lider con guardias OS-10 en ' + n + '. Cobertura 24/7.', cta_text: 'Cotiza en ' + n },
      intro: { heading: n, subheading: '', paragraphs: ['En GuardMan Chile entendemos las necesidades especificas de seguridad en ' + n + '.', 'Contamos con guardias experimentados que conocen las dinamicas del sector.', 'Nuestro conocimiento del territorio nos permite identificar puntos criticos y disenar esquemas de seguridad efectivos.'] },
      coverage: { heading: 'Cobertura en ' + n, items: ['Guardias disponibles 24/7', 'Tiempo de respuesta < 30 minutos', 'Centro de monitoreo propio', 'Reportes diarios de novedades'] },
      issues: { heading: 'Problemas que solucionamos', items: ['Robos a viviendas y vehiculos', 'Acceso no autorizado a condominios', 'Necesidad de seguridad discreta pero efectiva', 'Falta de personal capacitado'] },
      stats: { heading: 'Numeros que nos respaldan', items: [{ label: 'Empresas protegidas', value: '20+' }, { label: 'Guardias en zona', value: '30+' }, { label: 'Tiempo respuesta', value: '< 30 min' }] },
      faqs: { heading: 'Preguntas Frecuentes', items: [{ question: 'Hay disponibilidad de guardias en ' + n + '?', answer: 'Si, tenemos guardias disponibles desplegados en ' + n + ' listos para comenzar el servicio.' }, { question: 'Cual es el tiempo de respuesta en ' + n + '?', answer: 'Nuestro tiempo de respuesta en ' + n + ' es inferior a 30 minutos.' }, { question: 'Que tipos de propiedades protegen?', answer: 'Protegemos empresas, condominios, residencias, obras y cualquier tipo de propiedad.' }] },
      cta: { heading: 'Protege tu propiedad en ' + n, subheading: 'Contactanos para una cotizacion personalizada.', button: 'Solicitar Cotizacion' },
      meta: { title: 'Seguridad Privada en ' + n + ' | GuardMan Chile OS-10', description: 'Contrata seguridad privada en ' + n + '. Guardias OS-10 certificados, cobertura 24/7. Cotiza gratis.' }
    };
  } else if (entityType === 'sector') {
    sections = {
      hero: { heading: 'Seguridad ' + n, subheading: 'Vigilancia para ' + n.toLowerCase() + '. Cobertura 24/7 con guardias certificados.', cta_text: 'Cotizar Seguridad' },
      intro: { heading: 'Por que elegir GuardMan para ' + n + '?', paragraphs: ['En GuardMan Chile comprendemos los desafios unicos de seguridad que enfrenta el sector ' + n.toLowerCase() + '.', 'Contamos con anos de experiencia protegiendo empresas del sector ' + n.toLowerCase() + ' en toda la Region Metropolitana.'] },
      features: { heading: 'Que incluye nuestro servicio?', items: ['Guardias certificados OS-10', 'Monitoreo 24/7 desde nuestro centro de control', 'Control de accesos y registro de visitantes', 'Rondas preventivas programadas', 'Coordinacion con Carabineros', 'Reportes diarios de novedades'] },
      issues: { heading: 'Problemas que solucionamos', items: ['Robos y hurtos', 'Acceso no autorizado', 'Vandalismo', 'Falta de control perimetral', 'Necesidad de documentar incidentes', 'Coordinacion lenta ante emergencias'] },
      stats: { heading: 'Numeros que nos respaldan', items: [{ label: 'Empresas protegidas', value: '200+' }, { label: 'Guardias activos', value: '500+' }, { label: 'Anos de experiencia', value: '8+' }, { label: 'Comunas cobertura', value: '14' }] },
      faqs: { heading: 'Preguntas Frecuentes', items: [{ question: 'Cuanto cuesta la seguridad para ' + n.toLowerCase() + '?', answer: 'El precio depende del tamano, horarios y nivel de riesgo. Ofrecemos planes personalizados.' }, { question: 'Pueden adaptar el servicio a nuestras necesidades?', answer: 'Si, disenamos soluciones a medida segun los requerimientos especificos de cada cliente.' }, { question: 'Los guardias tienen experiencia en este sector?', answer: 'Si, capacitamos constantemente a nuestro personal en los protocolos especificos de cada industria.' }] },
      cta: { heading: 'Protege tu ' + n.toLowerCase() + ' hoy', subheading: 'Solicita una cotizacion personalizada', button: 'Solicitar Cotizacion' },
      meta: { title: 'Seguridad ' + n + ' | GuardMan Chile', description: 'Seguridad privada especializada para ' + n.toLowerCase() + '. Guardias OS-10, monitoreo 24/7. Cotiza gratis.' }
    };
  } else {
    sections = {
      hero: { heading: n + ' Profesionales en Santiago | GuardMan Chile', subheading: 'Proteccion confiable con guardias certificados OS-10' },
      intro: { heading: n + ' con Excelencia', paragraphs: ['En GuardMan Chile entendemos que la seguridad no es un gasto, es una inversion en tranquilidad. Contamos con mas de 500 guardias certificados bajo la normativa OS-10.', 'Nuestra experiencia de mas de 8 anos nos permite ofrecer soluciones adaptadas a cada necesidad.'] },
      features: { heading: 'Caracteristicas de Nuestro Servicio', items: ['Guardias con certificacion OS-10 vigente', 'Control de acceso para personas y vehiculos', 'Rondas preventivas programables', 'Respuesta inmediata ante emergencias', 'Coordinacion con Carabineros', 'Comunicacion permanente con centro de monitoreo 24/7'] },
      issues: { heading: 'Senales de Que Necesitas Seguridad', items: ['Aumento de robos en tu sector', 'Dificultad para controlar accesos', 'Necesidad de vigilancia permanente', 'Falta de personal capacitado para emergencias'] },
      stats: { heading: 'Numeros que Respaldan Nuestra Trayectoria', items: [{ label: 'Anos de experiencia', value: '8+' }, { label: 'Guardias certificados OS-10', value: '500+' }] },
      faqs: { heading: 'Preguntas Frecuentes sobre ' + n, items: [{ question: 'Que documentacion deben tener los guardias?', answer: 'Todo guardia debe contar con la autorizacion OS-10 emitida por el Ministerio del Interior, junto con cedula de identidad vigente y certificado de antecedentes limpio.' }, { question: 'Cuanto cuesta contratar ' + n.toLowerCase() + '?', answer: 'El costo varia segun el tipo de servicio, jornada laboral y cantidad de guardias. Ofrecemos cotizaciones personalizadas sin compromiso.' }, { question: 'En que comunas ofrecen el servicio?', answer: 'Cubrimos 14 comunas de la Region Metropolitana. Consultanos por tu comuna.' }, { question: 'Los guardias pueden detener personas sospechosas?', answer: 'Los guardias tienen atribuciones limitadas al control y vigilancia preventiva. Ante situaciones delictivas, su rol es solicitar ayuda especializada.' }] },
      cta: { heading: 'Protege lo que Mas te Importa Hoy', subheading: 'Cotiza sin compromiso y recibe una propuesta de seguridad personalizada en menos de 24 horas', button: 'Solicitar Cotizacion Gratis' },
      meta: { title: n + ' en Santiago | GuardMan Chile OS-10', description: 'Contrata ' + n.toLowerCase() + ' certificados OS-10 en Santiago. Cobertura 24/7. Cotiza gratis hoy.' }
    };
  }

  return {
    sections,
    _meta: {
      generated_at: new Date().toISOString(),
      generated_by: 'fallback',
    }
  };
}

export async function callDeepSeekAI(
  entityType: string,
  entitySlug: string,
  entityName: string,
  env: Env,
  currentContent?: any,
  currentScore?: any,
  previousWasManual?: boolean,
  existingImageContext?: string,
  aiSearchContext?: string
): Promise<GeneratedContent> {
  if (!env.MINIMAX_API_KEY) throw new Error('AI API key not configured (MINIMAX_API_KEY env var)');

  const actualServiceSlug = entityType === 'sector' ? (SECTOR_TO_SERVICE[entitySlug] || entitySlug) : entitySlug;

  // Detect combo location
  let comboLocationSlug = '';
  let comboLocationName = '';
  let serviceSlugForQuery = actualServiceSlug;
  for (const loc of LOCATION_SLUGS) {
    if (entitySlug.endsWith('-' + loc)) {
      comboLocationSlug = loc;
      serviceSlugForQuery = entitySlug.substring(0, entitySlug.length - loc.length - 1);
      comboLocationName = loc.split('-').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
      break;
    }
  }

  // Fetch Serper context
  let topRows: any[] = [], paaRows: any[] = [], compRows: any[] = [], locRows: any[] = [], gapRows: any[] = [];
  const pureQueries: string[] = [];

  if (entityType === 'service' || entityType === 'sector') {
    const sn = entityName.toLowerCase();
    pureQueries.push(sn + ' chile', sn + ' precio', sn + ' empresas', sn + ' profesional', sn + ' os-10', sn + ' cotizar', sn + ' certificacion', sn + ' experiencia', sn + ' 24/7', sn + ' region metropolitana');
  } else if (entityType === 'combo' && comboLocationName) {
    const sn = entityName.toLowerCase().split(' en ')[0] || 'servicio';
    pureQueries.push(sn + ' ' + comboLocationName, sn + ' ' + comboLocationName + ' precio', sn + ' ' + comboLocationName + ' empresas', sn + ' ' + comboLocationName + ' profesional', sn + ' ' + comboLocationName + ' os-10', sn + ' ' + comboLocationName + ' cotizar', sn + ' 24/7 ' + comboLocationName, sn + ' ' + comboLocationName + ' guard', sn + ' ' + comboLocationName + ' vigilancia');
  } else if (entityType === 'home' || entityType === 'homepage') {
    pureQueries.push('seguridad privada santiago chile', 'guardias seguridad os-10', 'empresa seguridad privada', 'monitoreo 24/7 santiago', 'cctv vigilancia chile', 'control accesos santiago');
  }

  try {
    const [topResults, paaResults, compDomains, locQueries, contentGaps] = await Promise.all([
      env.DB.prepare(`SELECT sq.query_text, sq.location_slug, sq.service_slug, sr.domain, sr.position, sr.title, sr.snippet, ROW_NUMBER() OVER (PARTITION BY sq.id ORDER BY sr.position ASC) as rn FROM serper_queries sq JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.service_slug = ? AND sq.status = 'completed' AND sq.endpoint = 'search' AND sr.result_type = 'organic' AND sr.position <= 5 ORDER BY sq.id, sr.position ASC`).bind(serviceSlugForQuery).all().catch(() => ({ results: [] })),
      (entityType !== 'sector') ? env.DB.prepare(`SELECT sr.title as question, sr.snippet as answer_hint FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sq.service_slug = ? AND sq.status = 'completed' AND sr.result_type = 'paa' LIMIT 10`).bind(serviceSlugForQuery).all().catch(() => ({ results: [] })) : Promise.resolve({ results: [] }),
      env.DB.prepare(`SELECT domain, COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sq.service_slug = ? AND sq.status = 'completed' AND sr.site_type = 'direct_competitor' AND sr.position <= 10 GROUP BY domain ORDER BY appearances DESC LIMIT 8`).bind(serviceSlugForQuery).all().catch(() => ({ results: [] })),
      (entityType === 'location') ? env.DB.prepare(`SELECT sq.query_text, sq.service_slug, COUNT(CASE WHEN sr.site_type = 'direct_competitor' AND sr.position <= 5 THEN 1 END) as top5_competitors FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.location_slug = ? AND sq.status = 'completed' AND sq.endpoint = 'search' GROUP BY sq.id ORDER BY top5_competitors DESC LIMIT 15`).bind(entitySlug).all().catch(() => ({ results: [] }))
      : (entityType === 'combo' && comboLocationSlug) ? env.DB.prepare(`SELECT sq.query_text, sq.service_slug, COUNT(CASE WHEN sr.site_type = 'direct_competitor' AND sr.position <= 5 THEN 1 END) as top5_competitors FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id WHERE sq.location_slug = ? AND sq.status = 'completed' AND sq.endpoint = 'search' GROUP BY sq.id ORDER BY top5_competitors DESC LIMIT 15`).bind(comboLocationSlug).all().catch(() => ({ results: [] }))
      : Promise.resolve({ results: [] }),
      env.DB.prepare(`SELECT sq.query_text, sq.service_slug, sq.location_slug FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = 'own' WHERE sq.service_slug = ? AND sq.status = 'completed' AND (sr.position IS NULL OR sr.position > 5) GROUP BY sq.query_text ORDER BY sq.query_text LIMIT 15`).bind(serviceSlugForQuery).all().catch(() => ({ results: [] })),
    ]);

    topRows = (topResults.results as any[]) || [];
    paaRows = (paaResults.results as any[]) || [];
    compRows = (compDomains.results as any[]) || [];
    locRows = (locQueries.results as any[]) || [];
    gapRows = (contentGaps.results as any[]) || [];
  } catch (e) { /* continue with empty data */ }

  // Build context string
  let ctx = '';
  if (compRows.length > 0) {
    ctx += '\nCOMPETIDORES QUE DOMINAN ESTE MERCADO:\n';
    compRows.forEach(function (c: any) { ctx += '- ' + c.domain + ': ' + c.appearances + ' apariciones, pos promedio ' + c.avg_pos + '\n'; });
  }
  if (topRows.length > 0) {
    ctx += '\nTOP RESULTADOS ORGANICOS ACTUALES (escribe titulos y descripciones mejores que estos):\n';
    topRows.forEach(function (r: any) { if (r.rn <= 3) ctx += '- [' + r.domain + '] ' + r.title.substring(0, 80) + '\n  Snippet: ' + (r.snippet || '').substring(0, 120) + '\n'; });
  }
  if (paaRows.length > 0) {
    ctx += '\nPREGUNTAS REALES DE USUARIOS (reformula en voz de marca para FAQ):\n';
    paaRows.forEach(function (p: any) { ctx += '- "' + p.question + '" -> inspiration: ' + (p.answer_hint || '').substring(0, 80) + '\n'; });
  }
  if (locRows.length > 0) {
    ctx += '\nQUERIES POR UBICACION (demanda real detectada):\n';
    locRows.forEach(function (l: any) { ctx += '- "' + l.query_text + '" (top5 competidores: ' + (l.top5_competitors || 0) + ')\n'; });
  }
  if (gapRows.length > 0) {
    ctx += '\nCONTENT GAPS - QUERIES DONDE GUARDMAN NO APARECE EN TOP 5 (ESCRIBE CONTENIDO QUE POSICIONE):\n';
    gapRows.forEach(function (g: any) { ctx += '- "' + g.query_text + '"\n'; });
  }
  if (pureQueries.length > 0) {
    ctx += '\nKEYWORDS OBJETIVO (incluyelas naturalmente en headings y meta):\n';
    pureQueries.slice(0, 8).forEach(function (q: string) { ctx += '- ' + q + '\n'; });
  }
  if (currentScore && currentScore.score < 80) {
    ctx += '\nPUNTOS DE MEJORA DEL CONTENIDO ACTUAL (score: ' + currentScore.score + '/100):\n';
    const d = currentScore.details || {};
    if (d.seo < 35) ctx += '- SEO necesita mejorar: meta title/description, keywords en hero\n';
    if (d.content < 30) ctx += '- Contenido necesita mas profundidad: mas FAQs, features, issues\n';
    if (d.structure < 15) ctx += '- Estructura incompleta: agregar CTA completo y stats\n';
    if (d.keywords < 8) ctx += '- Keywords coverage baja: incluir mas terminos de Serper\n';
  }

  const serperContext = ctx;
  const systemPrompt = `Eres copywriter SEO experto para GuardMan Chile, empresa de seguridad privada chilena con 8+ anos de experiencia.

REGLAS DE IDIOMA CRITICAS (CHILENO):
- Escribe EXCLUSIVAMENTE en espanol chileno formal (ustedeo, NO voseo argentino)
- NUNCA uses: vos, tenes, podes, queres, protege, vas a, vamos a,Che, boludo, lindo, re- (como prefijo)
- NUNCA uses palabras en otro idioma: vandalism, residential, operate, stockage, склад, advisable, documentation, handle, commercial (usa: vandalismo, residencial, operar, almacenamiento, almacenaje, recomendable, documentacion, manejar, comercial)
- Usa usted/ustedes (NO vos): "su empresa", "su propiedad", "contáctenos", "solicite", "proteja"
- Terminaciones correctas: protege→proteja, cotiza→cotice, contacta→contacte
- Terminologia chilena: Carabineros (NO policia), OS-10, OTEC, cotizar, planta, departamento, condominio, estacionamiento (NO garage), peatonal, delincuencia
- Numeros: 8+ anos (NO a~os), 500+ guardias

REGLAS DE CONTENIDO:
- Todo el JSON debe tener un campo "image" en hero con formato: "/images/service-{slug}.webp"
- El CTA tambien debe tener image: "{slug}-cta.jpg"
- NO uses URLs externas (unsplash, etc) para imagenes. Solo rutas locales /images/...
- NO inventes estadisticas falsas. Usa: 8+ anos, 500+ guardias, 14 comunas, 200+ clientes

Responde SOLO con JSON valido, sin texto adicional fuera del JSON.`;
  const typeLabels: Record<string, string> = { service: 'servicio', location: 'ubicacion/comuna', sector: 'sector/industria', combo: 'combinacion servicio-ubicacion', home: 'homepage', static_page: 'pagina estatica' };
  const typeLabel = typeLabels[entityType] || entityType;

  let locationInstructions = '';
  if (entityType === 'location' || (entityType === 'combo' && comboLocationSlug)) {
    const locSlug = entityType === 'location' ? entitySlug : comboLocationSlug;
    const locName = entityType === 'location' ? entityName : comboLocationName;
    const zoneDesc = ZONE_CONTEXT[locSlug] || 'comuna de la Region Metropolitana';
    locationInstructions = '\n\nDATOS ESPECIFICOS DE UBICACION:\n- Localidad: ' + locName + '\n- Zona: ' + zoneDesc + '\n- IMPORTANTE: El contenido debe estar ENFOCADO en ' + locName + '. Incluye menciones a la zona, tiempo de respuesta local, conocimiento del territorio.\n- Keywords: "' + entityName + '" y variaciones con "en ' + locName + '"';
  }

  let prompt = '';
  if (entityType === 'home' || entityType === 'homepage') {
    prompt = `Genera contenido SEO completo para la HOMEPAGE de GuardMan Chile.

`;
    prompt += `La homepage tiene UNA estructura FIJA de secciones en JSON:
`;
    prompt += `- hero: { headline: string (H1, 40-70 chars), subheadline: string (80-150 chars), background_image: "/images/hero-home.webp", phone: "+56 9 300 000 10", badge: string, badge_image: "" }
`;
    prompt += `- nosotros: { badge: string, title: string, paragraph: string (texto largo 200+ palabras), image: "/images/nosotros_seccion.webp", image_badge: string, cta_text: string, cta_link: "/nosotros", stats: { guards: "500+", clients: "200+", locations: "14", years: "8+" }, features: [{ title: string (corto), description: string (1-2 lineas) }] (4 features) }
`;
    prompt += `- servicios: { title: string, subtitle: string, cta_text: string, cta_link: "/servicios" }
`;
    prompt += `- guardpod: { badge: string, title: string, paragraph: string (2-3 lineas), image: "/images/s4-thumbnail.webp", image_badge: string, cta_text: string, cta_link: "/guard-pod", features: [{ title: string, description: string }] (3-4 features) }
`;
    prompt += `- sectores: { title: string, subtitle: string, cta_text: string, cta_link: "/sectores" }
`;
    prompt += `- ajax: { badge: string, title: string, paragraph: string (2-3 lineas), image: "/images/Ajax-systems-header.jpg", image_badge: string, cta_text: string, cta_link: "/ajax-systems", features: [{ title: string, description: string }] (4 features) }
`;
    prompt += `- clientes: { title: string, subtitle: string, cta_text: string, cta_link: "/nosotros", items: [{ name: string, initials: string (2 chars), color: string (hex), image: "" }] } (5 clientes reales chilenos: Avanzapark, Courtyard Marriott, Kavak, Workcenter, Hamptons)
`;
    prompt += `- ubicaciones: { badge: string, title: string, subtitle: string, cta_text: string, cta_link: "/ubicaciones" }
`;
    prompt += `- cta_final: { badge: string, title: string, subtitle: string, cta1_text: string, cta1_link: "/contacto", cta2_text: string, cta2_link: "/nosotros", badge_image: "" }
`;
    prompt += `- meta: { title: string (30-60 chars), description: string (120-160 chars) }

`;
    prompt += `IMPORTANT: Usa EXACTAMENTE estas secciones y nombres de campos. NO uses "heading" usa "headline". NO uses "paragraphs" usa "paragraph" (string unico).
`;
    prompt += `El hero debe ser impactante y orientado a conversion.
`;
    prompt += `El paragraph de nosotros debe ser extenso (200+ palabras) y profesional.
`;
    prompt += `Los features de cada seccion deben tener title CORTO (3-6 palabras) y description de 1-2 lineas. NO repitas el title en la description.

`;
    prompt += `DATOS REALES (USA ESTOS EXACTOS, NO INVENTES):
`;
    prompt += `- Telefono: +56 9 300 000 10
`;
    prompt += `- Email: info@guardman.cl
`;
    prompt += `- Instagram: https://www.instagram.com/grupo_guardman
`;
    prompt += `- Address: Av. Americo Vespucio Norte 1980, Providencia, Santiago, Chile

`;
    prompt += `Responde SOLO con JSON: { "sections": { hero, nosotros, servicios, guardpod, sectores, ajax, clientes, ubicaciones, cta_final, meta } }\n\nREGLAS CRITICAS:\n- TODOS los campos string deben tener contenido REAL. NUNCA dejes ningun campo vacio ("").\n- Headlines de 40-70 caracteres, subtitles de 80-150, paragraphs extensos.\n- CADA seccion de features debe tener 3-4 items con title y description REALES.\n- NO uses placeholder. Todo el contenido debe ser original, profesional y listo para publicar.\n`;
  } else if (entityType === 'static_page' && (entitySlug === 'ajax-systems' || entitySlug === 'guard-pod')) {
    const isAjax = entitySlug === 'ajax-systems';
    const productName = isAjax ? 'Ajax Systems' : 'Guard Pod';
    prompt = `Genera contenido SEO completo para la pagina de ${productName} de GuardMan Chile (instalador oficial y partner certificado).\n\n`;
    prompt += `CONTEXTO IMPORTANTE:\n`;
    if (isAjax) {
      prompt += `- Ajax Systems es una empresa EUROPEA de sistemas de alarma. GuardMan es su INSTALADOR OFICIAL en Chile.\n`;
      prompt += `- Ajax fabrica alarmas inalambricas Grado 3. NO es un servicio de GuardMan, es un producto que GuardMan instala.\n`;
      prompt += `- Tecnologia: protocolo Jeweller (radio encriptada 2km), Wings, OS Malevich.\n`;
      prompt += `- NO menciones guardias, escoltas ni vigilancia fisica. Esto es tecnologia de alarma.\n`;
      prompt += `- NO uses estadisticas de GuardMan (guardias, comunas, clientes). Usa datos de Ajax.\n`;
    } else {
      prompt += `- Guard Pod es vigilancia autonoma CON ENERGIA SOLAR desarrollada por GuardMan (producto propio).\n`;
      prompt += `- NO es una camara. Es una torre autosuficiente con camaras PTZ, baterias, deteccion IA.\n`;
      prompt += `- Ideal para obras, eventos, terrenos sin infraestructura.\n`;
    }
    prompt += `\nESTRUCTURA JSON EXACTA:\n`;
    prompt += `{\n`;
    prompt += `  "hero": { "headline": string, "subheadline": string, "badge": string, "image": string, "cta1_text": string, "cta1_href": string, "cta2_text": string, "cta2_href": string },\n`;
    prompt += `  "stats": [{ "value": string, "label": string }] (3 items, label CORTO max 3 palabras, ej: "Certificación", "Alcance Jeweller", "Usuarios globales"),\n`;
    prompt += `  "intro": { "label": string (2-4 palabras), "title": string (40-70 chars), "image": string, "paragraphs": [string, string] },\n`;
    prompt += `  "features": [{ "title": string, "description": string }] (${isAjax ? '5-6 features tecnicas de Ajax' : '4-5 features del Guard Pod'}),\n`;
    prompt += `  "problems": [string] (5-6 problemas concretos que resuelve ${productName}),\n`;
    prompt += `  "faqs": [{ "question": string, "answer": string }] (5 preguntas reales de clientes),\n`;
    prompt += `  "cta": { "heading": string, "subheading": string, "button_text": string, "button_href": string }\n`;
    prompt += `}\n\nREGLAS:\n- Foco TOTAL en ${productName}. GuardMan solo se menciona como instalador/canal.\n- Features CONCRETOS y TECNICOS, no marketing generico.\n- Stats SOLO 3 items con labels CORTAS (max 3 palabras como "Alcance", "Bateria", etc).\n- FAQs con respuestas de 2-3 oraciones sustanciales.\n- Responde SOLO JSON valido.\n`;
  } else {
    prompt = 'Genera contenido SEO completo para el ' + typeLabel + ' "' + entityName + '" (slug: ' + entitySlug + ') de GuardMan Chile.\n\n';
    prompt += 'Secciones requeridas en JSON:\n';
    prompt += '- hero: { heading, subheading, image? }\n';
    prompt += '- intro: { heading, paragraphs: [string] } (2-3 parrafos)\n';
    prompt += '- features: { heading, items: [string] } (6+ items)\n';
    prompt += '- issues: { heading, items: [string] } (4+ items)\n';
    prompt += '- stats: { heading, items: [{ label, value }] } (3+ items con numeros realistas)\n';
    prompt += '- faqs: { heading, items: [{ question, answer }] } (4+ items con respuestas detalladas)\n';
    prompt += '- cta: { heading, subheading, button, image? }\n';
    prompt += '- meta: { title (<60 chars), description (<160 chars) }\n\n';
  }
  if (serperContext) prompt += 'CONTEXTO DE INVESTIGACION SERPER:\n' + serperContext + '\n\n';
  if (aiSearchContext) prompt += 'CONTEXTO SEMANTICO ADICIONAL (AI Search - datos historicos, knowledge, FAQs reales):\n' + aiSearchContext + '\n\n';
  if (locationInstructions) prompt += locationInstructions + '\n\n';
  if (existingImageContext) prompt += existingImageContext + '\n\n';

  // v4 Fase 7: Enrich directly from D1 when AI Search not available
  if (!aiSearchContext) {
    try {
      const d1Enrichments: string[] = [];

      // FAQs reales para este servicio
      const faqRows = await env.DB.prepare(`SELECT question, answer, source, frequency_rank FROM faqs WHERE service_slug = ? ORDER BY frequency_rank ASC LIMIT 10`).bind(serviceSlugForQuery).all().catch(() => ({ results: [] }));
      if ((faqRows.results as any[])?.length > 0) {
        const faqText = (faqRows.results as any[]).map((r: any) => `Q${r.frequency_rank}: ${r.question}\nA: ${(r.answer || '').substring(0, 150)}`).join('\n');
        d1Enrichments.push('FAQS REALES DE USUARIOS (de Google PAA - usa estas preguntas y reformula respuestas en voz GuardMan):\n' + faqText);
      }

      // Keywords priorizadas
      const kwRows = await env.DB.prepare(`SELECT keyword, intent, sds_tier, is_easy_win FROM keywords WHERE service_slug = ? AND (is_easy_win = 1 OR sds_tier = 'easy') ORDER BY priority_score DESC LIMIT 15`).bind(serviceSlugForQuery).all().catch(() => ({ results: [] }));
      if ((kwRows.results as any[])?.length > 0) {
        const kwText = (kwRows.results as any[]).map((r: any) => `- [${(r.sds_tier || '?').toUpperCase()}${r.is_easy_win ? ' EASY_WIN' : ''}] ${r.keyword} (intent: ${r.intent})`).join('\n');
        d1Enrichments.push('KEYWORDS ESTRATEGICAS (incluye las easy_win en headings y meta):\n' + kwText);
      }

      // Landmarks para location/combo
      if (entityType === 'location' || (entityType === 'combo' && comboLocationSlug)) {
        const locSlug = entityType === 'location' ? entitySlug : comboLocationSlug;
        const lmRows = await env.DB.prepare(`SELECT name, type, relevance_score FROM landmarks WHERE location_slug = ? ORDER BY relevance_score DESC LIMIT 10`).bind(locSlug).all().catch(() => ({ results: [] }));
        if ((lmRows.results as any[])?.length > 0) {
          const lmText = (lmRows.results as any[]).map((r: any) => `- ${r.name} (${r.type}, relevancia: ${r.relevance_score})`).join('\n');
          d1Enrichments.push('LANDMARKS Y PUNTOS DE INTERES EN LA ZONA (menciona algunos para contexto local):\n' + lmText);
        }
      }

      // Agent knowledge (normativas, patrones)
      const knowRows = await env.DB.prepare(`SELECT key, value, category FROM agent_knowledge WHERE category IN ('security_patterns', 'exclusion_rules', 'brand_rules') ORDER BY category`).all().catch(() => ({ results: [] }));
      if ((knowRows.results as any[])?.length > 0) {
        const knowText = (knowRows.results as any[]).map((r: any) => `[${r.category}] ${r.key}: ${(r.value || '').substring(0, 100)}`).join('\n');
        d1Enrichments.push('CONOCIMIENTO DE MARCA Y NORMATIVAS (aplica estas reglas):\n' + knowText);
      }

      if (d1Enrichments.length > 0) {
        prompt += 'DATOS D1 ENRIQUECIDOS (FAQs, keywords, landmarks, normativas):\n' + d1Enrichments.join('\n\n') + '\n\n';
      }
    } catch (e) { /* non-critical enrichment */ }
  }

  prompt += 'Contexto GuardMan: Empresa de seguridad privada lider en Chile. 8+ anos experiencia. 500+ guardias certificados OS-10. 14 comunas. Centro de monitoreo 24/7.\n';
  prompt += 'Responde SOLO con JSON: { "sections": { hero, intro, features, issues, stats, faqs, cta, meta } }';
  prompt += '\nIMPORTANTE: El campo hero.image DEBE ser una ruta local como "/images/service-' + entitySlug + '.webp". El campo cta.image DEBE ser "' + entitySlug + '-cta.jpg". NO uses URLs de unsplash ni dominios externos.';

  const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${env.MINIMAX_API_KEY}` },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: prompt }],
      max_tokens: 4096,
      temperature: 0.4
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error('DeepSeek API error: ' + response.status + ' - ' + errText.substring(0, 200));
  }

  const data = await response.json() as any;
  // DeepSeek returns OpenAI-compatible format: { choices: [{ message: { content: '...' } }] }
  let text = data.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('Empty response from DeepSeek');
  text = text.trim();
  if (text.startsWith('```')) {
    text = text.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '');
  }
  let parsed: GeneratedContent;
  try {
    parsed = JSON.parse(text) as GeneratedContent;
  } catch (parseErr) {
    console.error('[AI] JSON parse error:', (parseErr as Error).message, 'Raw text:', text.substring(0, 200));
    throw new Error('Invalid JSON from DeepSeek: ' + (parseErr as Error).message);
  }

  // Post-process: fix image URLs, remove external URLs, enforce local paths
  const sections = parsed.sections || (parsed as any);
  if (sections.hero) {
    if (!sections.hero.image || sections.hero.image.includes('unsplash') || sections.hero.image.includes('http')) {
      sections.hero.image = `/images/service-${entitySlug}.webp`;
    }
  }
  if (sections.cta) {
    if (sections.cta.image && (sections.cta.image.includes('unsplash') || sections.cta.image.includes('http'))) {
      sections.cta.image = `${entitySlug}-cta.jpg`;
    }
  }

  // Post-process: fix common foreign words in all string values
  const FOREIGN_FIXES: [RegExp, string][] = [
    [/\bvandalism\b/gi, 'vandalismo'],
    [/\bresidential\b/gi, 'residencial'],
    [/\badvisable\b/gi, 'recomendable'],
    [/\bdocumentação\b/gi, 'documentación'],
    [/\bсклад\b/gi, 'almacenaje'],
    [/\boperate\b/gi, 'operar'],
    [/\bcommercial\b/gi, 'comercial'],
    [/\bprotegé\b/gi, 'proteja'],
  ];
  function fixForeignWords(obj: any): any {
    if (typeof obj === 'string') {
      let s = obj;
      for (const [pattern, replacement] of FOREIGN_FIXES) s = s.replace(pattern, replacement);
      return s;
    }
    if (Array.isArray(obj)) return obj.map(fixForeignWords);
    if (obj && typeof obj === 'object') {
      const fixed: any = {};
      for (const [k, v] of Object.entries(obj)) fixed[k] = fixForeignWords(v);
      return fixed;
    }
    return obj;
  }
  const cleaned = fixForeignWords(parsed);

  // Extract keywords and metadata
  const extractedKeywords: string[] = [];
  const allQueries = topRows.map((r: any) => r.query_text).filter((q: string) => q);
  const uniqueQueries = [...new Set(allQueries)].slice(0, 10);
  const kwMap = new Map<string, number>();
  uniqueQueries.forEach(function (q: string) {
    q.toLowerCase().split(' ').forEach(function (word: string) {
      if (word.length > 3 && !['para', 'con', 'los', 'las', 'del', 'que', 'una', 'uno', 'unos', 'unas', 'por', 'sin', 'sur', 'norte', 'este', 'oeste'].includes(word)) {
        kwMap.set(word, (kwMap.get(word) || 0) + 1);
      }
    });
  });
  [...kwMap.entries()].sort((a: any, b: any) => b[1] - a[1]).slice(0, 5).forEach(function (e) { extractedKeywords.push(e[0]); });
  pureQueries.forEach(function (q: string) {
    q.toLowerCase().split(' ').forEach(function (word: string) {
      if (word.length > 3 && !['para', 'con', 'los', 'las', 'del', 'que', 'una', 'uno', 'unos', 'unas', 'por', 'sin', 'sur', 'norte', 'este', 'oeste', 'chile', 'precio', 'empresas', 'profesional', 'os-10', 'cotizar', 'certificacion', 'experiencia', 'region', 'metropolitana'].includes(word)) {
        if (!extractedKeywords.includes(word)) extractedKeywords.push(word);
      }
    });
  });

  parsed._meta = {
    serper_queries: uniqueQueries,
    serper_competitors: compRows.map((c: any) => c.domain),
    keywords: extractedKeywords,
    content_gaps: gapRows.map((g: any) => g.query_text),
    generated_at: new Date().toISOString(),
    generated_by: 'ai',
  };

  return cleaned;
}

// ===== SECTION-SPECIFIC GENERATION =====
// Modular approach: generate ONE section at a time with focused prompt.
// This avoids AI "forgetting" sections when asked to generate 7 at once.

const SECTION_PROMPTS: Record<string, (context: { brand?: string; slug?: string }) => string> = {
  timeline: () => `Genera la seccion TIMELINE (linea de tiempo historica) para /nosotros de GuardMan Chile.

DATOS DE LA EMPRESA:
- Nombre: GuardMan Chile SpA
- Fundacion: 2017
- Ubicacion: Santiago, Chile
- Servicio: Seguridad privada con guardias certificados OS-10
- Hitos: 2017 (fundacion), 2019 (50 clientes), 2021 (centro de monitoreo propio), 2023 (500+ guardias, 14 comunas), 2024 (Guard Pod)

FORMATO JSON:
[
  { "year": "YYYY", "title": "titulo corto (3-8 palabras)", "description": "descripcion 1-2 oraciones (40-80 palabras)" }
]

REGLAS:
- Minimo 5 eventos, maximo 7
- Anos cronologicos ascendentes
- Cada evento verosimil para empresa de seguridad chilena
- Tono: profesional, orgulloso pero modesto
- NO uses placeholders. Contenido original listo para publicar.

Responde SOLO con el array JSON.`,

  stats: () => `Genera la seccion STATS (numeros clave) para /nosotros de GuardMan Chile.

DATOS REALES:
- Guardias: 500+
- Clientes: 200+
- Anos: 8+
- Comunas: 14
- Rating: 4.8/5
- Centro monitoreo: propio 24/7

FORMATO JSON:
[
  { "value": "500+", "label": "Guardias certificados", "icon": "👮" }
]

REGLAS:
- Minimo 4 stats, maximo 6
- Valores con simbolos (+, %, /5)
- Labels cortos (2-4 palabras)
- Icons opcionales (emoji relevantes)
- Responde SOLO con el array JSON.`,

  values: () => `Genera la seccion VALUES (valores corporativos) para /nosotros de GuardMan Chile.

FORMATO JSON:
[
  { "title": "Valor (2-4 palabras)", "description": "Descripcion 1-2 oraciones" }
]

REGLAS:
- Minimo 3 valores, maximo 5
- Titulos cortos y memorables (ej: Integridad, Excelencia, Innovacion)
- Descripciones concretas y NO genericas
- Alineados con seguridad privada y cultura chilena
- Responde SOLO con el array JSON.`,

  differentiators: () => `Genera la seccion DIFFERENTIATORS para /nosotros de GuardMan Chile.

DATOS REALES:
- Guard Pod: torre solar autonoma de vigilancia (producto propio)
- Centro de monitoreo propio 24/7
- Certificacion OS-10
- 8+ anos de experiencia
- Cobertura en 14 comunas

FORMATO JSON:
[
  { "title": "Diferenciador (3-5 palabras)", "description": "Explicacion concreta 1-2 oraciones", "icon": "emoji" }
]

REGLAS:
- Minimo 4, maximo 6
- Cada diferenciador debe ser verificable
- NO uses frases genericas ("calidad", "compromiso")
- Responde SOLO con el array JSON.`,

  certifications: () => `Genera la seccion CERTIFICATIONS para /nosotros de GuardMan Chile.

DATOS REALES:
- OS-10: autorizacion de Carabineros de Chile para guardias de seguridad
- Ley 21.157: normativa chilena de seguridad privada
- Capacitacion continua: protocolos de emergencia y primeros auxilios
- Seguro de responsabilidad civil

FORMATO JSON:
[
  { "title": "Nombre certificacion", "description": "Que significa para el cliente (1-2 oraciones)" }
]

REGLAS:
- Minimo 3, maximo 5
- Descripcion orientada al cliente ("esto te protege de...")
- Responde SOLO con el array JSON.`,

  staff: () => `Genera la seccion STAFF para /nosotros de GuardMan Chile.

DATOS REALES:
- Guardias certificados OS-10
- Capacitacion continua en protocolos de seguridad
- Centro de monitoreo propio 24/7 con operadores especializados
- 8+ anos de experiencia protegiendo empresas y residencias
- Coordinacion con Carabineros

FORMATO JSON:
{
  "image": "/images/nosotros_seccion.webp",
  "traits": [
    "Caracteristica del personal (15-30 palabras)",
    ...
  ]
}

REGLAS:
- Minimo 4 traits, maximo 6
- Cada trait describe una fortaleza real del personal
- Tono: orgulloso pero profesional
- Responde SOLO con el JSON object.`,

  cta: () => `Genera la seccion CTA (call-to-action final) para /nosotros de GuardMan Chile.

FORMATO JSON:
{
  "heading": "Titulo CTA (5-10 palabras)",
  "subheading": "Subtitulo opcional (10-20 palabras)",
  "button_text": "Texto boton (2-4 palabras)",
  "button_href": "/contacto"
}

REGLAS:
- Heading orientado a accion
- Button text con verbo imperativo
- Responde SOLO con el JSON object.`
};

export async function callDeepSeekForSection(
  section: string,
  env: any,
  retryFeedback?: string
): Promise<any> {
  const promptBuilder = SECTION_PROMPTS[section];
  if (!promptBuilder) throw new Error(`No prompt for section: ${section}`);

  let prompt = promptBuilder({});

  if (retryFeedback) {
    prompt += `\n\n⚠️ Intento anterior fallo con estos errores:\n${retryFeedback}\nCorrige estos errores y genera de nuevo.`;
  }

  // Common instruction for all sections
  prompt += `\n\nIMPORTANTE: Responde SOLO con el JSON. Sin markdown, sin explicaciones, sin comillas triples. El JSON debe ser valido.`;

  const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${env.MINIMAX_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [
        { role: 'system', content: 'Eres un copywriter profesional chileno. Generas contenido original, profesional y listo para publicar. Responde SOLO con JSON valido.' },
        { role: 'user', content: prompt },
      ],
      temperature: 0.7,
      max_tokens: 2000,
    }),
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    throw new Error(`DeepSeek API error ${response.status}: ${errText.substring(0, 200)}`);
  }

  const data = await response.json() as any;
  const text = data?.choices?.[0]?.message?.content;

  if (!text) throw new Error('DeepSeek returned empty response');

  // Parse JSON from response (handle possible markdown wrapping)
  let jsonText = text.trim();
  jsonText = jsonText.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/, '').trim();

  let parsed: any;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    // Try extracting JSON object/array if wrapped in text
    const match = jsonText.match(/\[[\s\S]*\]/) || jsonText.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        parsed = JSON.parse(match[0]);
      } catch {
        throw new Error(`Failed to parse DeepSeek response for section ${section}: ${jsonText.substring(0, 200)}`);
      }
    } else {
      throw new Error(`Failed to parse DeepSeek response for section ${section}: ${jsonText.substring(0, 200)}`);
    }
  }

  return parsed;
}

