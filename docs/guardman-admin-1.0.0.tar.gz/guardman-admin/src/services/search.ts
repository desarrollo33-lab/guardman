// GuardMan v4 — AI Search Helpers
// Semantic search across 13 instances: 9 sector + 4 shared
// Hybrid search: vector + BM25 + RRF fusion

import type { Env } from '../types';

// ===== Instance Names =====
export const SECTOR_INSTANCES = [
  'sector-guardias-de-seguridad',
  'sector-cctv-videovigilancia',
  'sector-control-de-accesos',
  'sector-monitoreo-24-7',
  'sector-auditoria-seguridad',
  'sector-seguridad-industrial',
  'sector-seguridad-eventos',
  'sector-escoltas-privados',
  'sector-servicios-de-seguridad',
];

export const SHARED_INSTANCES = [
  'shared-brand-guide',
  'shared-seo-rules',
  'shared-knowledge',
  'serper-intel',
];

export const ALL_INSTANCES = [...SECTOR_INSTANCES, ...SHARED_INSTANCES];

// ===== Search Functions =====

/** Search competitor data for a service */
export async function searchCompetitors(env: Env, serviceSlug: string, locationSlug?: string) {
  if (!env.AI_SEARCH) return null;
  try {
    const instance = env.AI_SEARCH.get('serper-intel');
    const query = locationSlug
      ? `competencia ${serviceSlug} ${locationSlug} Chile seguridad`
      : `competencia ${serviceSlug} Chile seguridad`;

    return await instance.search({
      query,
      ai_search_options: {
        boost_by: [{ field: 'metadata.service', value: serviceSlug }],
        ...(locationSlug ? { filter: { field: 'metadata.location', value: locationSlug } } : {}),
      },
    });
  } catch (e) {
    console.warn('[AI Search] searchCompetitors failed:', (e as Error).message);
    return null;
  }
}

/** Search PAA (People Also Ask) questions */
export async function searchFAQs(env: Env, serviceSlug: string, locationSlug?: string) {
  if (!env.AI_SEARCH) return null;
  try {
    const instance = env.AI_SEARCH.get('serper-intel');
    return await instance.search({
      query: `preguntas frecuentes ${serviceSlug} ${locationSlug || ''} seguridad privada`,
      ai_search_options: {
        boost_by: [{ field: 'metadata.type', value: 'paa' }],
      },
    });
  } catch (e) {
    console.warn('[AI Search] searchFAQs failed:', (e as Error).message);
    return null;
  }
}

/** Search content gaps where GuardMan doesn't rank */
export async function searchContentGaps(env: Env, serviceSlug: string) {
  if (!env.AI_SEARCH) return null;
  try {
    const instance = env.AI_SEARCH.get('serper-intel');
    return await instance.search({
      query: `content gaps ${serviceSlug} donde no aparece guardman`,
      ai_search_options: {
        boost_by: [{ field: 'metadata.type', value: 'gaps' }],
      },
    });
  } catch (e) {
    console.warn('[AI Search] searchContentGaps failed:', (e as Error).message);
    return null;
  }
}

/** Search brand guide (voice, data, differentiators) */
export async function searchBrandGuide(env: Env) {
  if (!env.AI_SEARCH) return null;
  try {
    const instance = env.AI_SEARCH.get('shared-brand-guide');
    return await instance.search({
      query: 'guardman brand voice datos empresa diferenciadores',
    });
  } catch (e) {
    console.warn('[AI Search] searchBrandGuide failed:', (e as Error).message);
    return null;
  }
}

/** Search agent knowledge (OS-10, security patterns, exclusion rules) */
export async function searchKnowledge(env: Env, topic: string) {
  if (!env.AI_SEARCH) return null;
  try {
    const instance = env.AI_SEARCH.get('shared-knowledge');
    return await instance.search({ query: topic });
  } catch (e) {
    console.warn('[AI Search] searchKnowledge failed:', (e as Error).message);
    return null;
  }
}

/** Search previously generated content for a service */
export async function searchPreviousContent(env: Env, serviceSlug: string) {
  if (!env.AI_SEARCH) return null;
  try {
    const instance = env.AI_SEARCH.get(`sector-${serviceSlug}`);
    return await instance.search({
      query: `contenido generado ${serviceSlug} mejor version`,
      ai_search_options: {
        boost_by: [{ field: 'metadata.type', value: 'content-history' }],
      },
    });
  } catch (e) {
    console.warn('[AI Search] searchPreviousContent failed:', (e as Error).message);
    return null;
  }
}

/** Cross-sector search across multiple or all instances */
export async function crossSectorSearch(env: Env, query: string, instanceIds?: string[]) {
  if (!env.AI_SEARCH) return null;
  try {
    return await env.AI_SEARCH.search({
      query,
      ai_search_options: {
        instance_ids: instanceIds || undefined,
      },
    });
  } catch (e) {
    console.warn('[AI Search] crossSectorSearch failed:', (e as Error).message);
    return null;
  }
}

/** Search keywords for a service */
export async function searchKeywords(env: Env, serviceSlug: string) {
  if (!env.AI_SEARCH) return null;
  try {
    const instance = env.AI_SEARCH.get(`sector-${serviceSlug}`);
    return await instance.search({
      query: `keywords ${serviceSlug} prioridad easy win`,
      ai_search_options: {
        boost_by: [{ field: 'metadata.type', value: 'keywords' }],
      },
    });
  } catch (e) {
    console.warn('[AI Search] searchKeywords failed:', (e as Error).message);
    return null;
  }
}

/** Get service slugs from D1 */
export async function getServiceSlugs(env: Env): Promise<string[]> {
  const { results } = await env.DB.prepare('SELECT slug FROM services ORDER BY name').all();
  return (results as any[]).map((r: any) => r.slug);
}

/** Check if AI Search is available */
export function isAISearchAvailable(env: Env): boolean {
  return !!env.AI_SEARCH;
}
