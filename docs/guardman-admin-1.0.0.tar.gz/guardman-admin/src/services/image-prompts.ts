// GuardMan Admin — Image Prompts System
// Capa 1: System prompt fijo (se inyecta siempre)
// Capa 2: Prompts predefinidos (editables via KV por el admin)

export const GUARDMAN_SYSTEM_PROMPT = `STYLE GUIDE — Follow these rules exactly:

CAMERA: Canon EOS R5 full-frame mirrorless, RF 24-70mm f/2.8L lens.
LIGHTING: Natural golden hour light, soft directional shadows, warm tone (5600-6000K). No harsh midday sun. No artificial flash.
COLOR PALETTE: Navy blue #1A2744, white #FFFFFF, steel blue #5F7A96, warm gray #6C757D. Colors must be natural, not oversaturated.
LOCATION: Santiago de Chile. Corporate buildings, residential condominiums, urban streets. Andes mountains on horizon when natural.
MOOD: Professional, trustworthy, authentic. Photorealistic portfolio quality. Not stock photo, not overly perfect.
COMPOSITION: Rule of thirds, leading lines, eye-level (1.6m), negative space. No extreme angles.
AVOID: Recognizable faces, weapons, AI artifacts, third-party logos, tropical vegetation, neon colors, military postures, messy cables, text overlays, watermarks.
OUTPUT: Photorealistic, high resolution, WebP format, no text, no watermarks.`;

export interface ImagePrompt {
  id: string;
  label: string;
  category: string;
  resolution: string;
  aspect_ratio: string;
  prompt: string;
  negative: string;
}

export const DEFAULT_PROMPTS: ImagePrompt[] = [
  {
    id: 'guardpod-hero',
    label: 'Guard Pod V1 — Hero',
    category: 'guard-pod',
    resolution: '2K',
    aspect_ratio: '16:9',
    prompt: 'Wide establishing shot of a Guard Pod V1 autonomous security tower deployed at a construction site entrance in Santiago Chile. White and navy blue tower with solar panels on top, PTZ camera dome, and 4G antenna. Modern, sleek, imposing presence. Late afternoon golden hour, clear blue sky, Andes mountains faintly visible. Clean environment, professional installation.',
    negative: 'people, dark, rain, messy site, graffiti, cartoon, 3D render'
  },
  {
    id: 'guardpod-condominio',
    label: 'Guard Pod en Condominio',
    category: 'guard-pod',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Medium shot of a Guard Pod V1 installed at the entrance gate of a modern residential condominium in Las Condes Santiago. Security barrier gate in frame, well-maintained gardens. Natural afternoon light, professional suburban atmosphere.',
    negative: 'people visible faces, night, empty scene, cartoon, oversaturated'
  },
  {
    id: 'ajax-hero',
    label: 'Ajax Systems Hub — Hero Producto',
    category: 'ajax',
    resolution: '2K',
    aspect_ratio: '16:9',
    prompt: 'Close-up product photography of an Ajax Systems Hub 2 central alarm panel installed on a clean modern wall in a Santiago office. MotionCam detector, DoorProtect sensor, and KeyPad nearby. Clean white wall, subtle navy accent from GuardMan branding. Professional lighting, shallow depth of field.',
    negative: 'messy desk, visible cables, old building, dark room, people'
  },
  {
    id: 'ajax-app',
    label: 'Ajax App — Lifestyle',
    category: 'ajax',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Overhead flat lay: a modern smartphone showing a security app dashboard with arm/disarm controls. Ajax fob keychain, coffee cup, subtle GuardMan business card with navy blue branding. Warm morning light from window, clean wooden desk surface.',
    negative: 'any text other than generic UI, messy, dark, people'
  },
  {
    id: 'servicio-guardia',
    label: 'Guardia de Seguridad OS-10',
    category: 'servicios',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Professional security guard in navy blue GuardMan uniform standing at the entrance lobby of a corporate office building in Santiago Chile. OS-10 certification badge visible on chest. Guard from 45-degree angle, looking toward entrance. Clean modern lobby, glass doors, corporate atmosphere. Natural diffuse daylight.',
    negative: 'visible face details, weapons, military posture, dark, empty lobby'
  },
  {
    id: 'servicio-cctv',
    label: 'CCTV — Instalación Profesional',
    category: 'servicios',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Modern dome CCTV camera professionally installed on the ceiling of a corporate hallway in Santiago. Clean cable management, blue indicator light glowing softly. Clean white ceiling, modern office corridor.',
    negative: 'messy cables, dirty ceiling, outdated camera, people, dark'
  },
  {
    id: 'servicio-accesos',
    label: 'Control de Accesos',
    category: 'servicios',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Modern access control turnstile gate at the entrance of a Santiago office building. Card reader with blue LED, sleek stainless steel finish. Clean lobby background. Natural daylight through glass entrance. Security-focused but welcoming.',
    negative: 'people visible faces, dirty glass, old equipment, dark'
  },
  {
    id: 'nosotros-oficina',
    label: 'Oficina GuardMan — Fachada',
    category: 'nosotros',
    resolution: '2K',
    aspect_ratio: '16:9',
    prompt: 'Exterior wide shot of the GuardMan Chile office building in Providencia Santiago. Modern 3-story building with navy blue GuardMan signage. Professional landscaping around entrance. Clear blue sky, golden hour side lighting. OS-10 certification plaque visible.',
    negative: 'people visible faces, rain, dark, neighboring buildings prominent'
  },
  {
    id: 'cobertura-santiago',
    label: 'Santiago — Cobertura Urbana',
    category: 'cobertura',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Aerial-style wide view of a Santiago residential neighborhood with modern apartment buildings and tree-lined streets. Clear blue sky, distant Andes mountains on the eastern horizon. Professional urban photography style communicating comprehensive city coverage.',
    negative: 'smog, night, identifiable addresses, people, text'
  },
];

// Función helper para componer el prompt final (Capa 1 + Capa 2 + Capa 3)
export function composePrompt(promptTemplate: ImagePrompt, userInput?: string): { prompt: string; negative: string } {
  let full = `${GUARDMAN_SYSTEM_PROMPT}\n\nSCENE: ${promptTemplate.prompt}`;
  if (userInput && userInput.trim()) full += `\n\nADDITIONAL DETAILS: ${userInput.trim()}`;
  return { prompt: full, negative: promptTemplate.negative || '' };
}
