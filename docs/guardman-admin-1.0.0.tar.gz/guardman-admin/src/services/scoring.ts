import type { GeneratedContent } from '../types';

export interface ContentScore {
  score: number;
  details: {
    localRelevance: number;
    seoOptimization: number;
    contentQuality: number;
    differentiation: number;
    structure: number;
  };
  breakdown: {
    localRelevance: { points: number; max: number; notes: string[] };
    seoOptimization: { points: number; max: number; notes: string[] };
    contentQuality: { points: number; max: number; notes: string[] };
    differentiation: { points: number; max: number; notes: string[] };
    structure: { points: number; max: number; notes: string[] };
  };
  warnings: string[];
  ttr: number;
}

const LOCAL_LOCATIONS = [
  'las-condes', 'vitacura', 'lo-barnechea', 'santiago-centro', 'huechuraba',
  'quilicura', 'la-reina', 'conchali', 'pudahuel', 'renca', 'lampa',
  'la-pintana', 'los-andes', 'san-felipe',
];

// Spanish stop words to exclude from TTR analysis
const STOP_WORDS = new Set([
  'para', 'como', 'pero', 'sobre', 'entre', 'cuando', 'donde', 'puede', 'tiene',
  'otra', 'otros', 'otro', 'todas', 'todos', 'todo', 'esta', 'este', 'esto',
  'ese', 'esa', 'eso', 'aquel', 'aquella', 'aquello', 'muy', 'mas', 'menos',
  'tambien', 'siempre', 'nunca', 'antes', 'despues', 'aqui', 'alli', 'bien',
  'solo', 'sola', 'cada', 'todo', 'algun', 'alguna', 'alguno', 'varios',
  'varias', 'hasta', 'desde', 'hacia', 'mediante', 'segun', 'durante',
  'mediante', 'cual', 'cuales', 'quien', 'quienes', 'cuyo', 'cuya',
]);

export function calculateContentScore(contentJson: any, serperKeywords?: string[]): ContentScore {
  if (!contentJson) return { score: 0, details: { localRelevance: 0, seoOptimization: 0, contentQuality: 0, differentiation: 0, structure: 0 }, breakdown: buildBreakdown(), warnings: ['Contenido vacío'], ttr: 0 };

  const s = typeof contentJson === 'string' ? JSON.parse(contentJson) : contentJson;
  const sections = s.sections || s;
  const meta = s._meta || {};
  const serperQueries = meta.serper_queries || [];
  const allText = extractAllText(sections);

  const br: ContentScore['breakdown'] = {
    localRelevance: { points: 0, max: 20, notes: [] },
    seoOptimization: { points: 0, max: 25, notes: [] },
    contentQuality: { points: 0, max: 25, notes: [] },
    differentiation: { points: 0, max: 15, notes: [] },
    structure: { points: 0, max: 15, notes: [] },
  };

  const warnings: string[] = [];

  // ═══ LOCAL RELEVANCE (max 20) ═══
  const hasLocation = LOCAL_LOCATIONS.some(loc => allText.toLowerCase().includes(loc.replace(/-/g, ' ')));
  if (hasLocation) {
    br.localRelevance.points += 7;
  } else {
    br.localRelevance.notes.push('No menciona una comuna especifica');
  }

  if (/chile|santiago|region metropolitana/i.test(allText)) {
    br.localRelevance.points += 7;
  } else {
    br.localRelevance.notes.push('No menciona Chile/Santiago');
  }

  if (/guardman|grupo guardman/i.test(allText)) {
    br.localRelevance.points += 6;
  } else {
    br.localRelevance.notes.push('No menciona la marca GuardMan');
  }

  // ═══ SEO OPTIMIZATION (max 25) ═══
  const title = sections.meta?.title || '';
  const desc = sections.meta?.description || '';
  const h1 = sections.hero?.heading || '';

  if (title.length >= 30 && title.length <= 60) br.seoOptimization.points += 7;
  else if (title.length > 0) { br.seoOptimization.points += 3; br.seoOptimization.notes.push(`Title: ${title.length}/60 chars`); }
  else br.seoOptimization.notes.push('Falta meta title');

  if (desc.length >= 80 && desc.length <= 160) br.seoOptimization.points += 6;
  else if (desc.length > 0) { br.seoOptimization.points += 3; br.seoOptimization.notes.push(`Description: ${desc.length}/160 chars`); }
  else br.seoOptimization.notes.push('Falta meta description');

  // Check keyword in H1
  const keywordInH1 = serperQueries.length > 0 && h1
    ? serperQueries.some((q: string) => h1.toLowerCase().includes(q.toLowerCase().split(' ')[0]))
    : false;
  if (keywordInH1) br.seoOptimization.points += 6;
  else br.seoOptimization.notes.push('Keyword principal no en H1');

  // Keyword density
  const hasKeywordVariants = serperQueries.length > 0
    ? serperQueries.filter((q: string) => allText.toLowerCase().includes(q.toLowerCase().split(' ')[0])).length
    : 0;
  const kwDensity = serperQueries.length > 0 ? Math.min(6, Math.round((hasKeywordVariants / Math.min(serperQueries.length, 8)) * 6)) : 0;
  br.seoOptimization.points += kwDensity;

  // NEW: Check Serper keywords presence
  if (serperKeywords && serperKeywords.length > 0) {
    const coveredKeywords = serperKeywords.filter(kw =>
      allText.toLowerCase().includes(kw.toLowerCase())
    );
    const keywordCoverage = coveredKeywords.length / Math.min(serperKeywords.length, 10);
    if (keywordCoverage >= 0.3) {
      br.seoOptimization.points += 4;
    } else {
      br.seoOptimization.notes.push(`Solo ${coveredKeywords.length}/${Math.min(serperKeywords.length, 10)} keywords Serper presentes`);
    }
  }

  // ═══ CONTENT QUALITY (max 25) ═══
  const paragraphs = sections.intro?.paragraphs?.length || 0;
  if (paragraphs >= 3) br.contentQuality.points += 8;
  else if (paragraphs >= 2) { br.contentQuality.points += 5; br.contentQuality.notes.push('Solo 2 parrafos intro (recomendado 3+)'); }
  else br.contentQuality.notes.push('Intro tiene menos de 2 parrafos');

  const features = sections.features?.items?.length || 0;
  if (features >= 6) br.contentQuality.points += 6;
  else if (features >= 4) { br.contentQuality.points += 3; br.contentQuality.notes.push(`${features} features (recomendado 6+)`); }

  const issueCount = sections.issues?.items?.length || 0;
  if (issueCount >= 4) br.contentQuality.points += 6;
  else if (issueCount >= 2) { br.contentQuality.points += 3; br.contentQuality.notes.push(`${issueCount} issues (recomendado 4+)`); }

  const stats = sections.stats?.items?.length || 0;
  if (stats >= 3) br.contentQuality.points += 5;
  else br.contentQuality.notes.push('Faltan stats con datos concretos');

  // ═══ NEW: REPETITION CHECK ═══
  const words = allText.toLowerCase().split(/\s+/).filter((w: string) => w.length > 3 && !STOP_WORDS.has(w));
  const totalWords = words.length;
  const uniqueWords = new Set(words).size;
  const ttr = totalWords > 0 ? uniqueWords / totalWords : 0;

  // Check for overused words (keyword stuffing)
  const freq: Record<string, number> = {};
  for (const w of words) {
    freq[w] = (freq[w] || 0) + 1;
  }

  const overused = Object.entries(freq)
    .filter(([, count]) => count > Math.max(totalWords * 0.025, 5))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  for (const [word, count] of overused) {
    const pct = ((count / totalWords) * 100).toFixed(1);
    warnings.push(`"${word}" aparece ${count} veces (${pct}% del texto) — posible keyword stuffing`);
  }

  // Penalize low TTR
  if (ttr < 0.35) {
    warnings.push(`Type-Token Ratio: ${(ttr * 100).toFixed(1)}% — texto muy repetitivo (mínimo 35%)`);
    br.contentQuality.points = Math.max(0, br.contentQuality.points - 5);
  } else if (ttr < 0.45) {
    warnings.push(`Type-Token Ratio: ${(ttr * 100).toFixed(1)}% — diversidad léxica baja (recomendado >45%)`);
    br.contentQuality.points = Math.max(0, br.contentQuality.points - 2);
  } else if (ttr >= 0.55) {
    br.contentQuality.points += 2; // Bonus for good diversity
  }

  // ═══ DIFFERENTIATION (max 15) ═══
  const contentGaps = meta.content_gaps || [];
  const gapsCovered = contentGaps.length > 0
    ? contentGaps.filter((g: string) => allText.toLowerCase().includes(g.toLowerCase().split(' ').slice(0, 2).join(' '))).length
    : 0;
  br.differentiation.points += Math.min(8, gapsCovered * 2);

  if (meta.serper_competitors && meta.serper_competitors.length > 0) {
    br.differentiation.points += Math.min(7, 3);
  }

  // ═══ STRUCTURE (max 15) ═══
  if (sections.cta?.heading && sections.cta?.button) br.structure.points += 5;
  else br.structure.notes.push('CTA incompleto');

  if (sections.faqs?.items?.length >= 4) br.structure.points += 5;
  else if (sections.faqs?.items?.length >= 2) { br.structure.points += 2; br.structure.notes.push(`${sections.faqs?.items?.length} FAQs (recomendado 4+)`); }

  if (sections.hero?.subheading) br.structure.points += 5;
  else br.structure.notes.push('Falta hero subheading');

  // ═══ CLAMP ALL SCORES ═══
  for (const key of Object.keys(br) as (keyof typeof br)[]) {
    br[key].points = Math.max(0, Math.min(br[key].max, br[key].points));
  }

  const total = br.localRelevance.points + br.seoOptimization.points + br.contentQuality.points + br.differentiation.points + br.structure.points;

  return {
    score: total,
    details: {
      localRelevance: br.localRelevance.points,
      seoOptimization: br.seoOptimization.points,
      contentQuality: br.contentQuality.points,
      differentiation: br.differentiation.points,
      structure: br.structure.points,
    },
    breakdown: br,
    warnings,
    ttr,
  };
}

function buildBreakdown(): ContentScore['breakdown'] {
  return {
    localRelevance: { points: 0, max: 20, notes: [] },
    seoOptimization: { points: 0, max: 25, notes: [] },
    contentQuality: { points: 0, max: 25, notes: [] },
    differentiation: { points: 0, max: 15, notes: [] },
    structure: { points: 0, max: 15, notes: [] },
  };
}

function extractAllText(sections: any): string {
  const parts: string[] = [];
  if (sections.hero?.heading) parts.push(sections.hero.heading);
  if (sections.hero?.subheading) parts.push(sections.hero.subheading);
  if (sections.meta?.title) parts.push(sections.meta.title);
  if (sections.meta?.description) parts.push(sections.meta.description);
  if (sections.intro?.heading) parts.push(sections.intro.heading);
  if (sections.intro?.paragraphs) parts.push(...sections.intro.paragraphs);
  if (sections.features?.items) parts.push(...(sections.features.items as string[]));
  if (sections.issues?.items) parts.push(...(sections.issues.items as string[]));
  if (sections.cta?.heading) parts.push(sections.cta.heading);
  if (sections.cta?.subheading) parts.push(sections.cta.subheading);
  return parts.join(' ');
}
