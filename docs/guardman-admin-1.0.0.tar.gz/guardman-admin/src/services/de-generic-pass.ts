// GuardMan v5.2 — De-Generic Pass
// Layer 4 of the 4-layer quality pipeline
// Rewrites sections that sound like "generic security company" to sound like GuardMan

import type { Env } from '../types';

/**
 * Attempts to rewrite generic phrases in content using Workers AI.
 * Non-blocking: if rewrite fails for any section, keeps original.
 */
export async function deGenericPass(
  env: Env,
  contentJson: any,
  genericSections: string[],
  brandName: string,
  stats: Record<string, string> = {}
): Promise<any> {
  if (!genericSections.length) return contentJson;

  const statsStr = Object.entries(stats).map(([k, v]) => `${k}: ${v}`).join(', ');

  for (const genericPhrase of genericSections) {
    if (!genericPhrase || genericPhrase.length < 10) continue;

    try {
      const response = await (env.AI as any).run('@cf/meta/llama-3.1-8b-instruct', {
        messages: [
          {
            role: 'system',
            content: `Reescribe el siguiente texto para que sea específico para ${brandName}, empresa de seguridad privada en Santiago de Chile.
- Menciona certificación OS-10, 8+ años de experiencia, 14 comunas de cobertura
- Tono profesional, cercano, español chileno natural
- NO uses frases genéricas como "empresa líder", "amplia experiencia", "comprometidos con"
- Sé concreto: datos reales, cifras reales, certificaciones reales
- Stats disponibles: ${statsStr}
- Responde SOLO con el texto reescrito, sin explicaciones ni comillas`
          },
          {
            role: 'user',
            content: genericPhrase.substring(0, 500),
          }
        ],
        max_tokens: 300,
      });

      const rewritten = response?.response?.trim();
      if (rewritten && rewritten.length > 20) {
        // Try to replace in the content JSON
        const textStr = JSON.stringify(contentJson.sections || contentJson);
        if (textStr.includes(genericPhrase)) {
          const newTextStr = textStr.replace(genericPhrase, rewritten);
          try {
            const newSections = JSON.parse(newTextStr);
            if (contentJson.sections) {
              contentJson.sections = newSections;
            } else {
              Object.assign(contentJson, newSections);
            }
          } catch {
            // JSON parse failed after replacement — skip this section
          }
        }
      }
    } catch {
      // Non-blocking: if rewrite fails, keep original
    }
  }

  return contentJson;
}
