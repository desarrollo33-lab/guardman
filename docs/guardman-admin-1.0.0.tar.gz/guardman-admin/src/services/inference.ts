import type { Env } from '../types';
import { checkRateLimit } from './rate-limit';

export type InferenceModel =
  | 'generation'
  | 'evaluation'
  | 'chat'
  | 'fast';

const MODEL_MAP: Record<InferenceModel, string> = {
  generation: 'deepseek/deepseek-chat',
  evaluation: 'deepseek/deepseek-chat',
  chat: '@cf/meta/llama-4-scout-17b-16e-instruct',
  fast: '@cf/meta/llama-4-scout-17b-16e-instruct',
};

const CACHE_TTL: Record<InferenceModel, string> = {
  generation: '0',
  evaluation: '86400',
  chat: '300',
  fast: '60',
};

const RATE_LIMIT_CATEGORY: Record<InferenceModel, string> = {
  generation: 'generation',
  evaluation: 'evaluation',
  chat: 'chat',
  fast: 'chat',
};

export interface InferenceOptions {
  temperature?: number;
  maxTokens?: number;
  jsonMode?: boolean;
  stream?: boolean;
  metadata?: Record<string, string>;
  cacheTtl?: string;
  cacheKey?: string;
}

export async function infer(
  env: Env,
  model: InferenceModel,
  systemPrompt: string,
  userPrompt: string,
  options?: InferenceOptions
): Promise<string> {
  const rl = checkRateLimit(RATE_LIMIT_CATEGORY[model]);
  if (!rl.allowed) {
    throw new Error(`Rate limit exceeded for ${model}. Reset at ${new Date(rl.resetAt).toISOString()}`);
  }

  const { temperature = 0.4, maxTokens = 4096, jsonMode = false, metadata = {}, cacheTtl, cacheKey } = options || {};
  const modelId = MODEL_MAP[model];
  const isWorkersAI = modelId.startsWith('@cf/');

  if (isWorkersAI && env.AI) {
    try {
      const response = await env.AI.run(modelId, {
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: jsonMode ? userPrompt + '\n\nResponde SOLO con JSON valido.' : userPrompt },
        ],
        max_tokens: maxTokens,
        temperature,
      });
      let text = (response as any).response || (response as any).choices?.[0]?.message?.content || '';
      if (typeof text !== 'string') text = JSON.stringify(text);
      return cleanResponse(text);
    } catch (e) {
      console.warn(`[Inference] Workers AI failed for ${modelId}:`, (e as Error).message);
      console.warn(`[Inference] Workers AI failed for ${modelId}, no fallback available`);
    }
  }

  if (env.CLOUDFLARE_ACCOUNT_ID && env.AI_GATEWAY_TOKEN) {
    try {
      const gatewayUrl = `https://gateway.ai.cloudflare.com/v1/${env.CLOUDFLARE_ACCOUNT_ID}/guardman-gateway/anthropic/${modelId}`;
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${env.AI_GATEWAY_TOKEN}`,
        'x-api-key': env.MINIMAX_API_KEY || '',
      };

      const ttl = cacheTtl || CACHE_TTL[model];
      if (ttl !== '0') {
        headers['cf-aig-cache-ttl'] = ttl;
        if (cacheKey) headers['cf-aig-cache-key'] = cacheKey;
        else headers['cf-aig-cache-key'] = `${model}-${hashString(userPrompt.substring(0, 200))}`;
      }

      const response = await fetch(gatewayUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model: 'deepseek-chat',
          max_tokens: maxTokens,
          temperature,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: jsonMode ? userPrompt + '\n\nResponde SOLO con JSON valido.' : userPrompt },
          ],
        }),
      });

      if (response.ok) {
        const data = await response.json() as any;
        const text = data.choices?.[0]?.message?.content
          || data.content?.filter((c: any) => c.type === 'text').map((c: any) => c.text).join('')
          || '';
        return cleanResponse(text);
      }
      console.warn(`[Inference] Gateway returned ${response.status}, falling back`);
    } catch (e) {
      console.warn(`[Inference] Gateway error:`, (e as Error).message);
    }
  }

  // No inference backend available — fall back to direct DeepSeek API call
  if (!env.MINIMAX_API_KEY) throw new Error('AI API key not configured (MINIMAX_API_KEY env var) and no inference backend available');

  const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${env.MINIMAX_API_KEY}`,
    },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      max_tokens: options?.maxTokens || 4096,
      temperature: options?.temperature || 0.4,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`DeepSeek inference failed: ${response.status} - ${errText.substring(0, 200)}`);
  }

  const data = await response.json() as any;
  const text = data.choices?.[0]?.message?.content || '';
  return cleanResponse(text);
}

function cleanResponse(text: string): string {
  let cleaned = text.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '');
  }
  return cleaned;
}

function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const chr = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + chr;
    hash |= 0;
  }
  return Math.abs(hash).toString(36);
}
