// GuardMan v5.2 — Brand Context Service
// Reads brand_dna from D1 and builds structured context for AI generation
// Ensures ALL 89 keys are injected into content generation prompts

import type { Env } from '../types';

export interface BrandContext {
  identity: {
    name: string;
    legal: string;
    tagline: string;
    description: string;
    phone: string;
    email: string;
    whatsapp: string;
    web: string;
    address: string;
  };
  stats: Record<string, string>;
  voice: {
    tone: string;
    personality: string;
    audience: string;
    mandatoryMentions: string[];
    forbiddenWords: string[];
  };
  differentiators: Array<{ title: string; description: string; icon: string }>;
  certifications: string[];
  exclusions: string[];
  usps: Array<{ title: string; description: string; icon: string }>;
  social: Record<string, string>;
  hours: Record<string, string>;
}

export async function loadBrandContext(env: Env): Promise<BrandContext> {
  const { results } = await env.DB.prepare(
    'SELECT category, key, value, type FROM brand_dna ORDER BY category, key'
  ).all();

  const rows = results as any[];

  // Group by category
  const byCategory: Record<string, any[]> = {};
  for (const row of rows) {
    if (!byCategory[row.category]) byCategory[row.category] = [];
    byCategory[row.category].push(row);
  }

  // Build company identity
  const companyMap: Record<string, string> = {};
  for (const r of byCategory.company || []) {
    companyMap[r.key] = r.value;
  }

  // Build stats
  const statsMap: Record<string, string> = {};
  for (const r of byCategory.stats || []) {
    statsMap[r.key] = r.value;
  }

  // Build voice
  const voiceMap: Record<string, string> = {};
  for (const r of byCategory.voice || []) {
    voiceMap[r.key] = r.value;
  }

  // Build certifications
  const certifications: string[] = [];
  for (const r of byCategory.certifications || []) {
    certifications.push(r.value);
  }

  // Build exclusions
  const exclusions: string[] = [];
  for (const r of byCategory.exclusions || []) {
    exclusions.push(r.value);
  }

  // Build differentiators (may be JSON or plain)
  const differentiators: any[] = [];
  for (const r of byCategory.differentiators || []) {
    try {
      const parsed = JSON.parse(r.value);
      differentiators.push(parsed);
    } catch {
      differentiators.push({ title: r.key, description: r.value, icon: 'shield' });
    }
  }

  // Build USPs
  const usps: any[] = [];
  for (const r of byCategory.usps || []) {
    try {
      const parsed = JSON.parse(r.value);
      usps.push(parsed);
    } catch {
      usps.push({ title: r.key, description: r.value, icon: 'star' });
    }
  }

  // Build social
  const socialMap: Record<string, string> = {};
  for (const r of byCategory.social || []) {
    socialMap[r.key] = r.value;
  }

  // Build hours
  const hoursMap: Record<string, string> = {};
  for (const r of byCategory.hours || []) {
    hoursMap[r.key] = r.value;
  }

  // Parse mandatory mentions and forbidden words
  const mandatoryMentions = (voiceMap.mandatory_mentions || '')
    .split(',').map(s => s.trim()).filter(Boolean);
  const forbiddenWords = (voiceMap.forbidden_words || voiceMap[' forbidden_words'] || '')
    .split(',').map(s => s.trim()).filter(Boolean);

  return {
    identity: {
      name: companyMap.brand_name || companyMap.name || 'GuardMan Chile',
      legal: companyMap.legal_name || '',
      tagline: companyMap.tagline || '',
      description: companyMap.short_description || companyMap.description || '',
      phone: companyMap.phone || '+56 9 300 000 10',
      email: companyMap.email || 'info@guardman.cl',
      whatsapp: companyMap.whatsapp || '',
      web: companyMap.site_url || companyMap.website || 'https://guardman.cl',
      address: companyMap.address || 'Av. Americo Vespucio Norte 1980, Providencia, Santiago, Chile',
    },
    stats: statsMap,
    voice: {
      tone: voiceMap.tone || 'profesional y cercano',
      personality: voiceMap.personality || 'confiable, directa, no militarista',
      audience: voiceMap.audience || 'empresas y personas que buscan seguridad privada en Chile',
      mandatoryMentions,
      forbiddenWords,
    },
    differentiators,
    certifications,
    exclusions,
    usps,
    social: socialMap,
    hours: hoursMap,
  };
}

/**
 * Build the full brand context block for AI prompts
 * Injects ALL brand data — not a partial summary
 */
export function buildBrandPromptBlock(ctx: BrandContext): string {
  const parts: string[] = [];

  parts.push(`IDENTIDAD DE MARCA:
- Empresa: ${ctx.identity.name} (${ctx.identity.legal})
- Tagline: "${ctx.identity.tagline}"
- Teléfono: ${ctx.identity.phone}
- Email: ${ctx.identity.email}
- Web: ${ctx.identity.web}
- Dirección: ${ctx.identity.address}`);

  if (Object.keys(ctx.stats).length > 0) {
    parts.push(`\nESTADÍSTICAS REALES (usa estos datos, NO inventes cifras):
${Object.entries(ctx.stats).map(([k, v]) => `  • ${k}: ${v}`).join('\n')}`);
  }

  parts.push(`\nVOZ Y TONO:
- Tono: ${ctx.voice.tone}
- Personalidad: ${ctx.voice.personality}
- Audiencia: ${ctx.voice.audience}`);

  if (ctx.voice.mandatoryMentions.length > 0) {
    parts.push(`\nMENCIONES OBLIGATORIAS (debe incluir al menos 3 en el contenido):
${ctx.voice.mandatoryMentions.map(m => `  ✅ ${m}`).join('\n')}`);
  }

  if (ctx.voice.forbiddenWords.length > 0) {
    parts.push(`\n🚫 PALABRAS/FRASES PROHIBIDAS (NUNCA usar estas expresiones):
${ctx.voice.forbiddenWords.map(w => `  ❌ "${w}"`).join('\n')}`);
  }

  if (ctx.differentiators.length > 0) {
    parts.push(`\nDIFERENCIADORES (mencionar cuando sea relevante):
${ctx.differentiators.map(d => `  ⭐ ${d.title}: ${d.description}`).join('\n')}`);
  }

  if (ctx.certifications.length > 0) {
    parts.push(`\nCERTIFICACIONES (mencionar siempre):
${ctx.certifications.map(c => `  📜 ${c}`).join('\n')}`);
  }

  if (ctx.exclusions.length > 0) {
    parts.push(`\nREGLAS DE EXCLUSIÓN (NO ofrecer estos servicios):
${ctx.exclusions.map(e => `  ⚠️ ${e}`).join('\n')}`);
  }

  if (ctx.usps.length > 0) {
    parts.push(`\nPROPOSITOS ÚNICOS DE VENTA ( destacar cuando sea posible):
${ctx.usps.map(u => `  🏆 ${u.title}: ${u.description}`).join('\n')}`);
  }

  return parts.join('\n');
}
