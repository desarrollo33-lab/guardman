// GuardMan v5.3 — Content Guardrails
// Checks content quality before saving: banned patterns, generic phrases, repetition, TTR

export interface GuardrailResult {
  passed: boolean;
  violations: string[];
  warnings: string[];
  ttr: number;
}

// Patterns that must NEVER appear in content (hard block)
const BLOCKED_PATTERNS: RegExp[] = [
  /\bsolución integral\b/i,
  /\blíder indiscutible\b/i,
  /\bmejor empresa de seguridad\b/i,
  /\bseguridad 100%\b/i,
  /\bgarantía total\b/i,
  /\bimpecable servicio\b/i,
  /\binfalible\b/i,
  /\bnúmero uno\b/i,
  /\bempresa más confiable\b/i,
  /\bsin igual\b/i,
  /\bincomparable\b/i,
  /\bnúmero 1\b/i,
  // Anglocisms
  /\bcutting.?edge\b/i,
  /\bstate.?of.?the.?art\b/i,
  /\bgame.?changer\b/i,
  /\bseamlessly\b/i,
  /\bleverage\b/i,
  /\binnovative solutions?\b/i,
  /\bdisrupt\b/i,
  /\bsynergy\b/i,
  /\bworld.?class\b/i,
  /\bbest.?in.?class\b/i,
  // Common AI artifacts found in our data
  /\bEs una pregunta frecuente que recibimos\b/i,
  /\bMany empresas\b/i,
  /\breferentees\b/i,
  /\bmerchandise\b/i,
  /\bhandlear\b/i,
  /\badaptée\b/i,
  /\bconsistency\b/i,
  /\boperate\s+\d/i,
];

// Patterns that indicate generic content (flagged for review)
const GENERIC_PATTERNS: RegExp[] = [
  /\bempresa líder en seguridad\b/i,
  /\bamplia experiencia\b/i,
  /\bcomprometidos con\b/i,
  /\bbrindamos el mejor\b/i,
  /\bsoluciones a medida\b/i,
  /\bequipo de profesionales\b/i,
  /\bcalidad garantizada\b/i,
  /\bservicio de excelencia\b/i,
  /\bseguridad de primer nivel\b/i,
  /\bconfianza y tranquilidad\b/i,
  /\bgran trayectoria\b/i,
  /\bservicio personalizado\b/i,
  /\batención personalizada\b/i,
  /\bcompromiso con la excelencia\b/i,
];

// Spanish stop words excluded from TTR analysis
const STOP_WORDS = new Set([
  'para', 'como', 'pero', 'sobre', 'entre', 'cuando', 'donde', 'puede', 'tiene',
  'otra', 'otros', 'otro', 'todas', 'todos', 'todo', 'esta', 'este', 'esto',
  'ese', 'esa', 'eso', 'muy', 'mas', 'menos', 'tambien', 'siempre', 'nunca',
  'antes', 'despues', 'aqui', 'alli', 'bien', 'solo', 'sola', 'cada',
  'algun', 'alguna', 'alguno', 'varios', 'varias', 'hasta', 'desde', 'hacia',
  'segun', 'durante', 'cual', 'cuales', 'quien', 'quienes',
]);

export function checkContentGuardrails(contentJson: any): GuardrailResult {
  const sections = contentJson?.sections || contentJson;
  const allText = extractAllText(sections);

  const violations: string[] = [];
  const warnings: string[] = [];

  // 1. Check blocked patterns
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(allText)) {
      const match = allText.match(pattern);
      violations.push(`🚫 Prohibido: "${match?.[0]}"`);
    }
  }

  // 2. Check generic phrases
  for (const pattern of GENERIC_PATTERNS) {
    if (pattern.test(allText)) {
      const match = allText.match(pattern);
      warnings.push(`⚠️ Genérico: "${match?.[0]}"`);
    }
  }

  // 3. Calculate Type-Token Ratio
  const words = allText.toLowerCase().split(/\s+/).filter((w: string) => w.length > 3 && !STOP_WORDS.has(w));
  const totalWords = words.length;
  const uniqueWords = new Set(words).size;
  const ttr = totalWords > 0 ? uniqueWords / totalWords : 0;

  if (ttr < 0.35 && totalWords > 50) {
    violations.push(`Type-Token Ratio ${(ttr * 100).toFixed(1)}% es demasiado bajo (mínimo 35%)`);
  } else if (ttr < 0.45 && totalWords > 50) {
    warnings.push(`Type-Token Ratio ${(ttr * 100).toFixed(1)}% es bajo (recomendado >45%)`);
  }

  // 4. Detect keyword stuffing
  const freq: Record<string, number> = {};
  for (const w of words) {
    freq[w] = (freq[w] || 0) + 1;
  }

  const overused = Object.entries(freq)
    .filter(([, count]) => count > Math.max(totalWords * 0.025, 5))
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  for (const [word, count] of overused) {
    const pct = ((count / totalWords) * 100).toFixed(1);
    warnings.push(`"${word}" aparece ${count} veces (${pct}%) — posible keyword stuffing`);
  }

  // 5. Check overlap between sections (copy-paste detection)
  const featureText = (sections.features?.items || []).join(' ');
  const issueText = (sections.issues?.items || []).join(' ');
  if (featureText.length > 50 && issueText.length > 50) {
    const overlap = calculateTextOverlap(featureText, issueText);
    if (overlap > 0.3) {
      warnings.push(`Features e Issues comparten ${Math.round(overlap * 100)}% de contenido`);
    }
  }

  // 6. Check hero vs intro overlap
  const heroText = [sections.hero?.heading, sections.hero?.subheading].join(' ');
  const introText = (sections.intro?.paragraphs || []).join(' ');
  if (heroText.length > 20 && introText.length > 50) {
    const overlap = calculateTextOverlap(heroText, introText);
    if (overlap > 0.5) {
      warnings.push('Intro repite contenido del hero');
    }
  }

  return {
    passed: violations.length === 0,
    violations,
    warnings,
    ttr,
  };
}

function calculateTextOverlap(text1: string, text2: string): number {
  const words1 = new Set(text1.toLowerCase().split(/\s+/).filter((w: string) => w.length > 4));
  const words2 = new Set(text2.toLowerCase().split(/\s+/).filter((w: string) => w.length > 4));
  if (words1.size === 0 || words2.size === 0) return 0;

  const intersection = [...words1].filter(w => words2.has(w));
  return intersection.length / Math.min(words1.size, words2.size);
}

function extractAllText(sections: any): string {
  const parts: string[] = [];
  if (sections.hero?.heading) parts.push(sections.hero.heading);
  if (sections.hero?.subheading) parts.push(sections.hero.subheading);
  if (sections.meta?.title) parts.push(sections.meta.title);
  if (sections.meta?.description) parts.push(sections.meta.description);
  if (sections.intro?.heading) parts.push(sections.intro.heading);
  if (sections.intro?.paragraphs) parts.push(...sections.intro.paragraphs);
  if (sections.features?.items) parts.push(...(sections.features.items as string[]));
  if (sections.issues?.items) parts.push(...(sections.issues.items as string[]));
  if (sections.cta?.heading) parts.push(sections.cta.heading);
  if (sections.cta?.subheading) parts.push(sections.cta.subheading);
  return parts.join(' ');
}
