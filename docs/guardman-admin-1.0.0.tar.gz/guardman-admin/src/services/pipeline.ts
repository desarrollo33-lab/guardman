import type { Env } from '../types';

export interface PipelineExport {
  type: string;
  exportedAt: string;
  records: number;
  key: string;
}

export async function runAnalyticsPipeline(env: Env): Promise<PipelineExport[]> {
  const results: PipelineExport[] = [];
  const now = new Date().toISOString();

  const [contentStats, serperStats, publishStats, qualityStats] = await Promise.all([
    env.DB.prepare(`
      SELECT entity_type, COUNT(*) as total,
             AVG(word_count) as avg_words,
             SUM(CASE WHEN confidence_score >= 75 THEN 1 ELSE 0 END) as high_quality
      FROM content_versions cv
      WHERE cv.version = (SELECT MAX(v2.version) FROM content_versions v2 WHERE v2.entity_type = cv.entity_type AND v2.entity_slug = cv.entity_slug)
      GROUP BY entity_type
    `).all(),

    env.DB.prepare(`
      SELECT DATE(created_at) as date, COUNT(*) as queries, SUM(credits_used) as credits
      FROM serper_queries
      WHERE created_at >= datetime('now', '-30 days')
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `).all(),

    env.DB.prepare(`
      SELECT status, COUNT(*) as count,
             AVG(score) as avg_score
      FROM publish_queue
      GROUP BY status
    `).all(),

    env.DB.prepare(`
      SELECT DATE(created_at) as date, COUNT(*) as reviews,
             AVG(score) as avg_score
      FROM audit_reports
      WHERE created_at >= datetime('now', '-30 days')
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `).all(),
  ]);

  const analytics = {
    content: contentStats.results,
    serper: serperStats.results,
    publish: publishStats.results,
    quality: qualityStats.results,
    generatedAt: now,
  };

  const key = `analytics/daily-${now.split('T')[0]}.json`;
  await env.IMAGES.put(key, JSON.stringify(analytics, null, 2), {
    httpMetadata: { contentType: 'application/json' },
    customMetadata: { type: 'analytics', date: now.split('T')[0] },
  });
  results.push({ type: 'content-analytics', exportedAt: now, records: (contentStats.results as any[]).length, key });

  const coverageData = await env.DB.prepare(`
    SELECT
      s.slug as service_slug, s.name as service_name,
      (SELECT COUNT(*) FROM locations l WHERE l.status = 'active') as total_locations,
      (SELECT COUNT(*) FROM combo_content cc WHERE cc.service_slug = s.slug) as combos_with_content,
      ROUND((SELECT COUNT(*) FROM combo_content cc WHERE cc.service_slug = s.slug) * 100.0 / (SELECT COUNT(*) FROM locations l WHERE l.status = 'active'), 1) as coverage_pct
    FROM services s
    WHERE s.status = 'active'
    ORDER BY coverage_pct ASC
  `).all();

  const coverageKey = `analytics/coverage-${now.split('T')[0]}.json`;
  await env.IMAGES.put(coverageKey, JSON.stringify({
    services: coverageData.results,
    generatedAt: now,
    totalServices: (coverageData.results as any[]).length,
    overallCoverage: Math.round(
      (coverageData.results as any[]).reduce((sum: number, r: any) => sum + (r.coverage_pct || 0), 0) /
      Math.max(1, (coverageData.results as any[]).length)
    ),
  }, null, 2), {
    httpMetadata: { contentType: 'application/json' },
    customMetadata: { type: 'coverage', date: now.split('T')[0] },
  });
  results.push({ type: 'coverage-report', exportedAt: now, records: (coverageData.results as any[]).length, key: coverageKey });

  return results;
}
