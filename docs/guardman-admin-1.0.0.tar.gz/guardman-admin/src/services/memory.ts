// GuardMan v4 — Memory & Continuous Improvement
// Lessons learned, cannibalization detection, auto-improvement loop

import type { Env } from '../types';

/**
 * Check for keyword cannibalization across services
 * Returns pairs of entities that compete for the same keywords
 */
export async function detectCannibalization(env: Env): Promise<{
  total: number;
  cannibalized: Array<{
    keyword: string;
    entities: Array<{ type: string; slug: string; name: string; score: number }>;
    recommendation: string;
  }>;
}> {
  // Get all content with extracted keywords
  const { results } = await env.DB.prepare(`
    SELECT cv.entity_type, cv.entity_slug, cv.content_json, cv.word_count
    FROM content_versions cv
    WHERE cv.version = (
      SELECT MAX(v2.version) FROM content_versions v2
      WHERE v2.entity_type = cv.entity_type AND v2.entity_slug = cv.entity_slug
    )
    AND cv.content_json IS NOT NULL
  `).all();

  // Build keyword → entities map
  const kwMap = new Map<string, Array<{ type: string; slug: string; name: string; score: number }>>();

  for (const row of (results as any[])) {
    let parsed: any = {};
    try { parsed = JSON.parse(row.content_json); } catch { continue; }
    const meta = parsed._meta || {};
    const keywords: string[] = meta.keywords || [];

    // Also extract from meta title/heading
    const title = parsed.sections?.meta?.title || '';
    const h1 = parsed.sections?.hero?.heading || '';
    const allText = (title + ' ' + h1).toLowerCase();

    // Add extracted keywords
    for (const kw of keywords) {
      if (kw.length < 4) continue;
      const key = kw.toLowerCase();
      if (!kwMap.has(key)) kwMap.set(key, []);
      kwMap.get(key)!.push({
        type: row.entity_type,
        slug: row.entity_slug,
        name: row.entity_slug.replace(/-/g, ' '),
        score: 0, // will be filled if available
      });
    }

    // Add words from title/H1 as potential cannibalization
    for (const word of allText.split(/\s+/)) {
      if (word.length < 5) continue;
      if (!kwMap.has(word)) kwMap.set(word, []);
      kwMap.get(word)!.push({
        type: row.entity_type,
        slug: row.entity_slug,
        name: row.entity_slug.replace(/-/g, ' '),
        score: 0,
      });
    }
  }

  // Find keywords used by 2+ entities of same type
  const cannibalized: any[] = [];
  for (const [keyword, entities] of kwMap) {
    // Group by entity type
    const byType = new Map<string, typeof entities>();
    for (const e of entities) {
      const key = e.type;
      if (!byType.has(key)) byType.set(key, []);
      byType.get(key)!.push(e);
    }

    for (const [type, typeEntities] of byType) {
      if (typeEntities.length >= 2) {
        cannibalized.push({
          keyword,
          entities: typeEntities,
          recommendation: typeEntities.length === 2
            ? `Consolidar "${keyword}" en la entidad con mejor score o diferenciar intent`
            : `Múltiples entidades compiten por "${keyword}" — diferenciar con long-tail o consolidar`,
        });
      }
    }
  }

  return {
    total: cannibalized.length,
    cannibalized: cannibalized.slice(0, 50), // limit output
  };
}

/**
 * Get weekly improvement insights
 * Compares latest scores with previous week
 */
export async function getWeeklyInsights(env: Env): Promise<{
  period: string;
  improved: Array<{ type: string; slug: string; prevScore: number; newScore: number; delta: number }>;
  declined: Array<{ type: string; slug: string; prevScore: number; newScore: number; delta: number }>;
  newContent: number;
  autoApproved: number;
  avgScore: number;
}> {
  // Get score trends from quality_scores
  const { results } = await env.DB.prepare(`
    SELECT entity_type, entity_slug, score, created_at
    FROM quality_scores
    WHERE created_at >= datetime('now', '-7 days')
    ORDER BY created_at DESC
  `).all().catch(() => ({ results: [] }));

  const improved: any[] = [];
  const declined: any[] = [];

  // Group by entity and compare first/last score
  const entityScores = new Map<string, Array<{ score: number; date: string }>>();
  for (const row of (results as any[])) {
    const key = `${row.entity_type}|${row.entity_slug}`;
    if (!entityScores.has(key)) entityScores.set(key, []);
    entityScores.get(key)!.push({ score: row.score, date: row.created_at });
  }

  for (const [key, scores] of entityScores) {
    if (scores.length < 2) continue;
    scores.sort((a, b) => a.date.localeCompare(b.date));
    const first = scores[0];
    const last = scores[scores.length - 1];
    const delta = last.score - first.score;
    const [type, slug] = key.split('|');

    if (delta > 0) improved.push({ type, slug, prevScore: first.score, newScore: last.score, delta });
    else if (delta < 0) declined.push({ type, slug, prevScore: first.score, newScore: last.score, delta });
  }

  // Count new content and auto-approved
  const newContent = await env.DB.prepare(`
    SELECT COUNT(*) as cnt FROM content_versions
    WHERE created_at >= datetime('now', '-7 days')
    AND generated_by IN ('ai', 'ai-workflow')
  `).first().then((r: any) => r?.cnt || 0).catch(() => 0);

  const autoApproved = await env.DB.prepare(`
    SELECT COUNT(*) as cnt FROM publish_queue
    WHERE status = 'approved'
    AND created_at >= datetime('now', '-7 days')
  `).first().then((r: any) => r?.cnt || 0).catch(() => 0);

  const avgScore = await env.DB.prepare(`
    SELECT AVG(score) as avg FROM quality_scores
    WHERE created_at >= datetime('now', '-7 days')
  `).first().then((r: any) => Math.round(r?.avg || 0)).catch(() => 0);

  return {
    period: new Date(Date.now() - 7 * 86400000).toISOString().split('T')[0] + ' to ' + new Date().toISOString().split('T')[0],
    improved: improved.sort((a, b) => b.delta - a.delta).slice(0, 10),
    declined: declined.sort((a, b) => a.delta - b.delta).slice(0, 10),
    newContent,
    autoApproved,
    avgScore,
  };
}

/**
 * Save a lesson learned from content review to D1
 * Used for auto-improvement: reviewer feedback feeds future generation
 */
export async function saveLessonLearned(
  env: Env,
  entityType: string,
  entitySlug: string,
  lesson: {
    category: string;
    problem: string;
    solution: string;
    scoreBefore: number;
    scoreAfter: number;
  }
): Promise<void> {
  try {
    await env.DB.prepare(`
      INSERT INTO agent_corrections (entity_type, entity_slug, correction_type, feedback, applied, created_at)
      VALUES (?, ?, ?, ?, 0, datetime('now'))
    `).bind(
      entityType, entitySlug, lesson.category,
      JSON.stringify(lesson),
    ).run();
  } catch (e) {
    console.warn('[Memory] Could not save lesson:', (e as Error).message);
  }
}

/**
 * §1.3 — FAQ coverage tracking by combo
 * Returns coverage % per service×location combo
 */
export async function getFAQCoverage(env: Env): Promise<{
  totalCombos: number;
  covered: number;
  coverage: number;
  details: Array<{ service: string; location: string; totalFaqs: number; usedInContent: number; coverage: number }>;
}> {
  // Count total FAQs available per service
  const faqCounts = await env.DB.prepare(`
    SELECT service_slug, COUNT(*) as total FROM faqs GROUP BY service_slug
  `).all().catch(() => ({ results: [] }));

  // Count FAQs referenced in combo_content.faqs_json and content_versions
  const contentFaqs = await env.DB.prepare(`
    SELECT entity_type, entity_slug, content_json FROM content_versions cv
    WHERE cv.version = (
      SELECT MAX(v2.version) FROM content_versions v2
      WHERE v2.entity_type = cv.entity_type AND v2.entity_slug = cv.entity_slug
    )
    AND cv.content_json IS NOT NULL
  `).all().catch(() => ({ results: [] }));

  // Build coverage map
  const faqByService = new Map<string, number>();
  for (const row of (faqCounts.results as any[])) {
    faqByService.set(row.service_slug, row.total);
  }

  const details: Array<{ service: string; location: string; totalFaqs: number; usedInContent: number; coverage: number }> = [];
  let totalCombos = 0;
  let covered = 0;

  const services = await env.DB.prepare('SELECT slug FROM services').all().catch(() => ({ results: [] }));
  const locations = await env.DB.prepare('SELECT slug FROM locations').all().catch(() => ({ results: [] }));

  for (const svc of (services.results as any[])) {
    const totalFaqs = faqByService.get(svc.slug) || 0;
    if (totalFaqs === 0) continue;

    for (const loc of (locations.results as any[])) {
      totalCombos++;
      // Check if any content for this combo has FAQ section
      const comboKey = `${svc.slug}-${loc.slug}`;
      const svcContent = (contentFaqs.results as any[]).find(
        (r: any) => r.entity_slug === svc.slug || r.entity_slug === comboKey
      );

      let usedInContent = 0;
      if (svcContent?.content_json) {
        try {
          const parsed = JSON.parse(svcContent.content_json);
          const faqItems = parsed.sections?.faqs?.items || [];
          usedInContent = faqItems.length;
        } catch {}
      }

      const cov = totalFaqs > 0 ? Math.min(1, usedInContent / totalFaqs) : 0;
      if (cov > 0) covered++;
      details.push({ service: svc.slug, location: loc.slug, totalFaqs, usedInContent, coverage: Math.round(cov * 100) });
    }
  }

  return {
    totalCombos,
    covered,
    coverage: totalCombos > 0 ? Math.round((covered / totalCombos) * 100) : 0,
    details: details.filter(d => d.totalFaqs > 0).slice(0, 50),
  };
}

/**
 * §1.3 — Competitor weakness map
 * Extracts structured weaknesses/threats from competitors table
 * Returns actionable insights for prompt enrichment
 */
export async function getCompetitorWeaknessMap(env: Env): Promise<{
  services: Array<{
    service: string;
    competitors: Array<{ domain: string; weaknesses: string[]; threats: string[]; opportunities: string[] }>;
  }>;
  summary: string;
}> {
  const { results } = await env.DB.prepare(`
    SELECT domain, service_slug, weaknesses, threats, opportunities
    FROM competitors
    WHERE weaknesses IS NOT NULL OR threats IS NOT NULL OR opportunities IS NOT NULL
    ORDER BY service_slug, domain
  `).all().catch(() => ({ results: [] }));

  const byService = new Map<string, Array<{ domain: string; weaknesses: string[]; threats: string[]; opportunities: string[] }>>();

  for (const row of (results as any[])) {
    if (!byService.has(row.service_slug)) byService.set(row.service_slug, []);
    const weaknesses = typeof row.weaknesses === 'string' ? row.weaknesses.split(/[,;|]/).map((s: string) => s.trim()).filter(Boolean) : (row.weaknesses || []);
    const threats = typeof row.threats === 'string' ? row.threats.split(/[,;|]/).map((s: string) => s.trim()).filter(Boolean) : (row.threats || []);
    const opportunities = typeof row.opportunities === 'string' ? row.opportunities.split(/[,;|]/).map((s: string) => s.trim()).filter(Boolean) : (row.opportunities || []);
    byService.get(row.service_slug)!.push({ domain: row.domain, weaknesses, threats, opportunities });
  }

  const services = Array.from(byService.entries()).map(([service, competitors]) => ({ service, competitors }));

  // Build prompt-enrichment summary
  const summaryParts: string[] = [];
  for (const svc of services) {
    const allWeaknesses = svc.competitors.flatMap(c => c.weaknesses);
    const allOpportunities = svc.competitors.flatMap(c => c.opportunities);
    if (allWeaknesses.length > 0 || allOpportunities.length > 0) {
      summaryParts.push(`[${svc.service}] Debilidades competencia: ${allWeaknesses.slice(0, 3).join(', ')}. Oportunidades: ${allOpportunities.slice(0, 3).join(', ')}`);
    }
  }

  return {
    services,
    summary: summaryParts.join('\n'),
  };
}

/**
 * §1.3 — Best publish time analysis
 * Analyzes position_snapshots trends to suggest optimal publish hour
 * Stores result in agent_knowledge for prompt enrichment
 */
export async function analyzeBestPublishTime(env: Env): Promise<{
  bestHour: number;
  bestDay: string;
  confidence: number;
  hourlyBreakdown: Array<{ hour: number; avgPosition: number; samples: number }>;
}> {
  // Analyze which hours/days see best position improvements
  const { results } = await env.DB.prepare(`
    SELECT
      CAST(strftime('%H', published_at) AS INTEGER) as hour,
      AVG(position) as avg_pos,
      COUNT(*) as samples
    FROM position_snapshots
    WHERE published_at IS NOT NULL
    GROUP BY hour
    ORDER BY avg_pos ASC
  `).all().catch(() => ({ results: [] }));

  // Analyze by day of week
  const dayResults = await env.DB.prepare(`
    SELECT
      CASE CAST(strftime('%w', snapshot_date) AS INTEGER)
        WHEN 0 THEN 'domingo'
        WHEN 1 THEN 'lunes'
        WHEN 2 THEN 'martes'
        WHEN 3 THEN 'miercoles'
        WHEN 4 THEN 'jueves'
        WHEN 5 THEN 'viernes'
        WHEN 6 THEN 'sabado'
      END as day_name,
      AVG(position) as avg_pos,
      COUNT(*) as samples
    FROM position_snapshots
    GROUP BY day_name
    ORDER BY avg_pos ASC
  `).all().catch(() => ({ results: [] }));

  const hourlyBreakdown = (results as any[]).map(r => ({
    hour: r.hour,
    avgPosition: Math.round(r.avg_pos * 100) / 100,
    samples: r.samples,
  }));

  const bestRow = (results as any[])[0];
  const bestDayRow = (dayResults as any[])[0];

  const bestHour = bestRow?.hour ?? 8; // Default 8am if no data
  const bestDay = bestDayRow?.day_name ?? 'martes';
  const confidence = Math.min(1, (bestRow?.samples || 0) / 100); // Need 100 samples for full confidence

  // Store in agent_knowledge for future reference
  try {
    await env.DB.prepare(`
      INSERT INTO agent_knowledge (category, key, value, confidence, source)
      VALUES ('publish_optimization', 'best_publish_time', ?, ?, 'auto_analysis')
      ON CONFLICT(category, key) DO UPDATE SET value = excluded.value, confidence = excluded.confidence, source = excluded.source
    `).bind(
      JSON.stringify({ bestHour, bestDay, confidence, analyzedAt: new Date().toISOString() }),
      confidence
    ).run();
  } catch { /* agent_knowledge may have different schema */ }

  return { bestHour, bestDay, confidence, hourlyBreakdown };
}

/**
 * Get lessons learned for a service slug (to feed into generation prompts)
 */
export async function getRelevantLessons(env: Env, serviceSlug: string): Promise<string> {
  try {
    const { results } = await env.DB.prepare(`
      SELECT feedback, entity_type, entity_slug, created_at
      FROM agent_corrections
      WHERE (entity_slug = ? OR entity_type = 'service')
      AND correction_type = 'review_feedback'
      ORDER BY created_at DESC
      LIMIT 5
    `).bind(serviceSlug).all();

    if ((results as any[]).length === 0) return '';

    const lessons = (results as any[]).map((r: any) => {
      try {
        const parsed = JSON.parse(r.feedback);
        return `• [${parsed.category}] ${parsed.problem} → ${parsed.solution}`;
      } catch {
        return `• ${r.feedback}`;
      }
    });

    return 'LECCIONES APRENDIDAS (evita estos errores en contenido nuevo):\n' + lessons.join('\n');
  } catch {
    return '';
  }
}
