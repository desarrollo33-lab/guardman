import type { Env } from '../types';

export type D1Session = any;

export function getReadSession(db: any): D1Session {
  try {
    return db.withSession?.() || db;
  } catch {
    return db;
  }
}

export function getPrimarySession(db: any): D1Session {
  try {
    return db.withSession?.('first-primary') || db;
  } catch {
    return db;
  }
}

export function isReadOperation(path: string): boolean {
  const readPrefixes = [
    '/api/images/',
    '/api/cms/image',
    '/api/services',
    '/api/locations',
    '/api/sectors',
    '/api/content/',
    '/api/faqs',
    '/api/preview',
    '/api/export',
    '/api/seo/',
  ];
  return readPrefixes.some(p => path.startsWith(p));
}
