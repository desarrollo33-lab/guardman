// GuardMan v5.2 — Banned Pattern Scanner
// Layer 1 of the 4-layer quality pipeline
// Inspired by WorkOS AI Blog Bot's quality controls

export interface BannedPatternResult {
  passed: boolean;
  violations: string[];
  genericPhrases: string[];
}

// Patterns that must NEVER appear in content (hard block)
const BLOCKED_PATTERNS: RegExp[] = [
  /\bsolución integral\b/i,
  /\blíder indiscutible\b/i,
  /\bmejor empresa de seguridad\b/i,
  /\bseguridad 100%\b/i,
  /\bgarantía total\b/i,
  /\bimpecable servicio\b/i,
  /\binfalible\b/i,
  /\bnúmero uno\b/i,
  /\bempresa más confiable\b/i,
  /\bsin igual\b/i,
  /\bincomparable\b/i,
  /\bnúmero 1\b/i,
  // Anglocisms
  /\bcutting.?edge\b/i,
  /\bstate.?of.?the.?art\b/i,
  /\bgame.?changer\b/i,
  /\bseamlessly\b/i,
  /\bleverage\b/i,
  /\binnovative solutions?\b/i,
  /\bdisrupt\b/i,
  /\bsynergy\b/i,
  /\bworld.?class\b/i,
  /\bbest.?in.?class\b/i,
  // AI artifacts found in our generated data
  /\bEs una pregunta frecuente que recibimos\b/i,
  /\bMany empresas\b/i,
  /\breferentees\b/i,
  /\bmerchandise\b/i,
  /\bhandlear\b/i,
  /\badaptée\b/i,
  /\bconsistency\b/i,
  /\bstockage\b/i,
  // Foreign words found in regenerated content
  /\bvandalism\b/i,
  /\bresidential\b/i,
  /\badvisable\b/i,
  /\bdocumentação\b/i,
  /\bоператив\b/i,
  /\bсклад\b/i,
  /\boperate\s+\d/i,
  // Argentine Spanish (voseo)
  /\bvos\s+(tenés|podés|querés|necesitás|sabés|vivís)\b/i,
  /\bprotegé\b/i,
  /\bChe[,\s]\b/i,
  /\btenés\b/i,
  /\bpodés\b/i,
  /\bquerés\b/i,
  /\bnecesitás\b/i,
  /\bsabés\b/i,
  /\bVamos a\s+(proteger|auditar|evaluar|mejorar|cotizar)\b/i,
];

// Patterns that indicate generic content (flagged for de-generic pass)
const GENERIC_PATTERNS: RegExp[] = [
  /\bempresa líder en seguridad\b/i,
  /\bamplia experiencia\b/i,
  /\bcomprometidos con\b/i,
  /\bbrindamos el mejor\b/i,
  /\bsoluciones a medida\b/i,
  /\bequipo de profesionales\b/i,
  /\bcalidad garantizada\b/i,
  /\bservicio de excelencia\b/i,
  /\bseguridad de primer nivel\b/i,
  /\bconfianza y tranquilidad\b/i,
  /\bgran trayectoria\b/i,
  /\bservicio personalizado\b/i,
  /\batención personalizada\b/i,
  /\bcompromiso con la excelencia\b/i,
  // More generic patterns found in our data
  /\bcentro de monitoreo propio operate\b/i,
  /\bempresa líder\b/i,
  /\bsomos líderes en\b/i,
  /\bofrecemos soluciones integrales\b/i,
  /\bcon más de.*de experiencia\b/i,
];

export function scanBannedPatterns(content: string, extraForbidden: string[] = []): BannedPatternResult {
  const violations: string[] = [];
  const genericPhrases: string[] = [];

  // Check blocked patterns
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(content)) {
      const match = content.match(pattern);
      violations.push(`🚫 Prohibido: "${match?.[0]}"`);
    }
  }

  // Check extra forbidden words from brand_dna
  for (const word of extraForbidden) {
    if (word && content.toLowerCase().includes(word.toLowerCase())) {
      violations.push(`🚫 Prohibido (DNA): "${word}"`);
    }
  }

  // Check generic phrases
  for (const pattern of GENERIC_PATTERNS) {
    if (pattern.test(content)) {
      const match = content.match(pattern);
      genericPhrases.push(match?.[0] || pattern.source);
    }
  }

  return {
    passed: violations.length === 0,
    violations,
    genericPhrases,
  };
}
