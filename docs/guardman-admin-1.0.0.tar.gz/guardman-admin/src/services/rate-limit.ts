const limits = new Map<string, { count: number; resetAt: number }>();

interface RateLimitConfig {
  maxRequests: number;
  windowMs: number;
}

const DEFAULT_CONFIGS: Record<string, RateLimitConfig> = {
  generation: { maxRequests: 60, windowMs: 60000 },
  evaluation: { maxRequests: 30, windowMs: 60000 },
  serper: { maxRequests: 20, windowMs: 60000 },
  publish: { maxRequests: 10, windowMs: 60000 },
  bulk: { maxRequests: 5, windowMs: 60000 },
};

export function checkRateLimit(
  category: string,
  config?: Partial<RateLimitConfig>
): { allowed: boolean; remaining: number; resetAt: number } {
  const cfg = { ...DEFAULT_CONFIGS[category], ...config };
  if (!cfg.maxRequests || !cfg.windowMs) {
    return { allowed: true, remaining: Infinity, resetAt: 0 };
  }

  const now = Date.now();
  const entry = limits.get(category);

  if (!entry || now > entry.resetAt) {
    limits.set(category, { count: 1, resetAt: now + cfg.windowMs });
    return { allowed: true, remaining: cfg.maxRequests - 1, resetAt: now + cfg.windowMs };
  }

  if (entry.count >= cfg.maxRequests) {
    return { allowed: false, remaining: 0, resetAt: entry.resetAt };
  }

  entry.count++;
  return { allowed: true, remaining: cfg.maxRequests - entry.count, resetAt: entry.resetAt };
}

export function getRateLimitHeaders(category: string, config?: Partial<RateLimitConfig>): Record<string, string> {
  const result = checkRateLimit(category, config);
  return {
    'X-RateLimit-Remaining': String(result.remaining),
    'X-RateLimit-Reset': String(Math.ceil(result.resetAt / 1000)),
    ...(result.allowed ? {} : { 'Retry-After': String(Math.ceil((result.resetAt - Date.now()) / 1000)) }),
  };
}
