// GuardMan v5.2 — Unified Content Generation Service
// ALL content generation MUST go through this service.
// Wraps callDeepSeekAI with the 4-layer quality pipeline + brand DNA injection.
// No caller should import callDeepSeekAI directly.

import type { Env, GeneratedContent } from '../types';
import { callDeepSeekAI } from './ai';
import { loadBrandContext, buildBrandPromptBlock, type BrandContext } from './brand-context';
import { scanBannedPatterns } from './banned-patterns';
import { checkContentGuardrails } from './guardrails';
import { reviewWithWorkersAI, type QualityReview } from './quality-review';
import { deGenericPass } from './de-generic-pass';
import { calculateContentScore, type ContentScore } from './scoring';

export interface GenerationResult {
  content: GeneratedContent;
  score: number;            // Combined algorithmic + LLM score (0-100)
  algoScore: number;        // Algorithmic score
  review: QualityReview;    // LLM review result
  passed: boolean;          // All quality layers passed
  violations: string[];     // Any violations found
  genericPhrases: string[]; // Generic phrases detected
  brandContext: BrandContext | null;
}

/**
 * Generate content through the unified quality pipeline.
 * This is the ONLY way content should be generated.
 *
 * Layers:
 * 1. Brand DNA injection (89 keys → prompt)
 * 2. AI generation (DeepSeek)
 * 3. Banned patterns scan
 * 4. Guardrails check (incl. forbidden words from brand_dna)
 * 5. LLM review (Workers AI)
 * 6. De-generic pass (rewrite generic sections)
 * 7. Combined scoring
 */
export async function generateContent(
  env: Env,
  entityType: string,
  entitySlug: string,
  entityName: string,
  options?: {
    currentContent?: any;
    currentScore?: any;
    previousWasManual?: boolean;
    existingImageContext?: string;
    aiSearchContext?: string;
    skipQualityPipeline?: boolean;  // Only for fallback emergencies
  }
): Promise<GenerationResult> {
  const opts = options || {};

  // Load brand context (89 keys)
  let brandCtx: BrandContext | null = null;
  try {
    brandCtx = await loadBrandContext(env);
  } catch {
    // Non-blocking: if brand_dna fails, continue without it
  }

  // Build brand prompt block
  let brandPrompt = '';
  if (brandCtx) {
    brandPrompt = buildBrandPromptBlock(brandCtx);
  }

  // Inject brand context into aiSearchContext
  const enrichedContext = brandPrompt
    ? (opts.aiSearchContext ? brandPrompt + '\n\n' + opts.aiSearchContext : brandPrompt)
    : opts.aiSearchContext;

  // Generate with AI
  let content = await callDeepSeekAI(
    entityType, entitySlug, entityName, env,
    opts.currentContent, opts.currentScore, opts.previousWasManual,
    opts.existingImageContext, enrichedContext
  );

  if (!content) {
    // Emergency fallback
    const { generateFallbackContent } = await import('./ai');
    content = generateFallbackContent(entityType, entitySlug, entityName);
    const { score: algoScore } = calculateContentScore(content);
    return {
      content,
      score: algoScore,
      algoScore,
      review: {
        score: algoScore, seo: 0, content: 0, structure: 0, voiceAlignment: 0,
        feedback: 'Fallback content (AI generation failed)',
        suggestions: [], genericSections: [],
      },
      passed: false,
      violations: ['AI generation returned empty'],
      genericPhrases: [],
      brandCtx,
    };
  }

  // If skipQualityPipeline (emergency only), return raw
  if (opts.skipQualityPipeline) {
    const { score: algoScore } = calculateContentScore(content);
    return {
      content, score: algoScore, algoScore,
      review: { score: algoScore, seo: 0, content: 0, structure: 0, voiceAlignment: 0, feedback: 'Skipped quality pipeline', suggestions: [], genericSections: [] },
      passed: true, violations: [], genericPhrases: [], brandCtx,
    };
  }

  // --- Quality Layer 1: Banned patterns ---
  const allText = JSON.stringify(content);
  const forbiddenWords = brandCtx?.voice?.forbiddenWords || [];
  const banned = scanBannedPatterns(allText, forbiddenWords);

  // --- Quality Layer 2: Guardrails ---
  const guardResult = checkContentGuardrails(content, forbiddenWords);

  // Collect violations
  const violations: string[] = [];
  if (!banned.passed) violations.push(...banned.violations);
  if (!guardResult.passed) violations.push(...guardResult.violations);

  // --- Quality Layer 3: LLM review (Workers AI, free) ---
  let review: QualityReview;
  try {
    review = await reviewWithWorkersAI(env, content, brandCtx || {} as BrandContext, {
      type: entityType, slug: entitySlug, name: entityName,
    });
  } catch {
    review = {
      score: 50, seo: 20, content: 15, structure: 10, voiceAlignment: 5,
      feedback: 'Review fallback (Workers AI error)',
      suggestions: [], genericSections: [],
    };
  }

  // --- Quality Layer 4: De-generic pass ---
  if (review.genericSections.length > 0 && brandCtx) {
    content = await deGenericPass(env, content, review.genericSections, brandCtx.identity.name, brandCtx.stats);
  }

  // --- Combined scoring ---
  const { score: algoScore } = calculateContentScore(content);
  const finalScore = Math.round((algoScore + review.score) / 2);

  return {
    content,
    score: finalScore,
    algoScore,
    review,
    passed: violations.length === 0,
    violations,
    genericPhrases: banned.genericPhrases,
    brandCtx,
  };
}
