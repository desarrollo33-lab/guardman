// GuardMan — CMS Section Validators
// Runtime validation for AI-generated content sections
// Manual TypeScript (no Zod dependency needed for 7 schemas)

export interface ValidationResult {
  ok: boolean;
  errors: string[];
}

function fail(msg: string): ValidationResult {
  return { ok: false, errors: [msg] };
}

function pass(): ValidationResult {
  return { ok: true, errors: [] };
}

// ===== TIMELINE =====
// Array of { year, title, description }
export function validateTimeline(data: unknown): ValidationResult {
  if (!Array.isArray(data)) return fail('timeline must be an array');
  const errors: string[] = [];

  if (data.length < 4) errors.push(`timeline needs ≥4 items, got ${data.length}`);
  if (data.length > 7) errors.push(`timeline max 7 items, got ${data.length}`);

  for (let i = 0; i < data.length; i++) {
    const item = data[i] as any;
    const yr = item?.year;
    if (!yr || typeof yr !== 'string' || yr.length !== 4 || !/^\d{4}$/.test(yr))
      errors.push(`timeline[${i}].year must be YYYY, got "${yr}"`);
    if (!item?.title || item.title.length < 3)
      errors.push(`timeline[${i}].title too short (min 3 chars)`);
    if (item?.title && item.title.length > 60)
      errors.push(`timeline[${i}].title too long (max 60 chars)`);
    if (!item?.description || item.description.length < 20)
      errors.push(`timeline[${i}].description too short (min 20 chars)`);
    if (item?.description && item.description.length > 200)
      errors.push(`timeline[${i}].description too long (max 200 chars)`);
  }

  return errors.length === 0 ? pass() : { ok: false, errors };
}

// ===== STATS =====
// Array of { value, label, icon? }
export function validateStats(data: unknown): ValidationResult {
  if (!Array.isArray(data)) return fail('stats must be an array');
  const errors: string[] = [];

  if (data.length < 3) errors.push(`stats needs ≥3 items, got ${data.length}`);
  if (data.length > 6) errors.push(`stats max 6 items, got ${data.length}`);

  for (let i = 0; i < data.length; i++) {
    const item = data[i] as any;
    if (!item?.value || typeof item.value !== 'string' || item.value.length < 1)
      errors.push(`stats[${i}].value missing or empty`);
    if (item?.value && item.value.length > 20)
      errors.push(`stats[${i}].value too long (max 20 chars)`);
    if (!item?.label || typeof item.label !== 'string' || item.label.length < 3)
      errors.push(`stats[${i}].label too short (min 3 chars)`);
    if (item?.label && item.label.length > 40)
      errors.push(`stats[${i}].label too long (max 40 chars)`);
  }

  return errors.length === 0 ? pass() : { ok: false, errors };
}

// ===== VALUES =====
// Array of { title, description }
export function validateValues(data: unknown): ValidationResult {
  if (!Array.isArray(data)) return fail('values must be an array');
  const errors: string[] = [];

  if (data.length < 3) errors.push(`values needs ≥3 items, got ${data.length}`);
  if (data.length > 6) errors.push(`values max 6 items, got ${data.length}`);

  for (let i = 0; i < data.length; i++) {
    const item = data[i] as any;
    if (!item?.title || item.title.length < 3)
      errors.push(`values[${i}].title too short (min 3 chars)`);
    if (item?.title && item.title.length > 40)
      errors.push(`values[${i}].title too long (max 40 chars)`);
    if (!item?.description || item.description.length < 20)
      errors.push(`values[${i}].description too short (min 20 chars)`);
    if (item?.description && item.description.length > 150)
      errors.push(`values[${i}].description too long (max 150 chars)`);
  }

  return errors.length === 0 ? pass() : { ok: false, errors };
}

// ===== DIFFERENTIATORS =====
// Array of { title, description, icon? }
export function validateDifferentiators(data: unknown): ValidationResult {
  if (!Array.isArray(data)) return fail('differentiators must be an array');
  const errors: string[] = [];

  if (data.length < 3) errors.push(`differentiators needs ≥3 items, got ${data.length}`);
  if (data.length > 6) errors.push(`differentiators max 6 items, got ${data.length}`);

  for (let i = 0; i < data.length; i++) {
    const item = data[i] as any;
    if (!item?.title || item.title.length < 3)
      errors.push(`differentiators[${i}].title too short (min 3 chars)`);
    if (item?.title && item.title.length > 40)
      errors.push(`differentiators[${i}].title too long (max 40 chars)`);
    if (!item?.description || item.description.length < 20)
      errors.push(`differentiators[${i}].description too short (min 20 chars)`);
    if (item?.description && item.description.length > 150)
      errors.push(`differentiators[${i}].description too long (max 150 chars)`);
  }

  return errors.length === 0 ? pass() : { ok: false, errors };
}

// ===== CERTIFICATIONS =====
// Array of { title, description }
export function validateCertifications(data: unknown): ValidationResult {
  if (!Array.isArray(data)) return fail('certifications must be an array');
  const errors: string[] = [];

  if (data.length < 2) errors.push(`certifications needs ≥2 items, got ${data.length}`);
  if (data.length > 6) errors.push(`certifications max 6 items, got ${data.length}`);

  for (let i = 0; i < data.length; i++) {
    const item = data[i] as any;
    if (!item?.title || item.title.length < 3)
      errors.push(`certifications[${i}].title too short (min 3 chars)`);
    if (item?.title && item.title.length > 50)
      errors.push(`certifications[${i}].title too long (max 50 chars)`);
    if (!item?.description || item.description.length < 20)
      errors.push(`certifications[${i}].description too short (min 20 chars)`);
    if (item?.description && item.description.length > 150)
      errors.push(`certifications[${i}].description too long (max 150 chars)`);
  }

  return errors.length === 0 ? pass() : { ok: false, errors };
}

// ===== STAFF =====
// Object { image?, traits[] }
export function validateStaff(data: unknown): ValidationResult {
  if (!data || typeof data !== 'object') return fail('staff must be an object');
  const s = data as any;
  const errors: string[] = [];

  if (!Array.isArray(s.traits)) errors.push('staff.traits must be an array');
  else {
    if (s.traits.length < 3) errors.push(`staff.traits needs ≥3 items, got ${s.traits.length}`);
    if (s.traits.length > 6) errors.push(`staff.traits max 6 items, got ${s.traits.length}`);
    for (let i = 0; i < s.traits.length; i++) {
      if (typeof s.traits[i] !== 'string' || s.traits[i].length < 10)
        errors.push(`staff.traits[${i}] too short (min 10 chars)`);
      if (s.traits[i]?.length > 150)
        errors.push(`staff.traits[${i}] too long (max 150 chars)`);
    }
  }

  return errors.length === 0 ? pass() : { ok: false, errors };
}

// ===== CTA =====
// Object { heading, subheading?, button_text, button_href? }
export function validateCTA(data: unknown): ValidationResult {
  if (!data || typeof data !== 'object') return fail('cta must be an object');
  const c = data as any;
  const errors: string[] = [];

  if (!c.heading || c.heading.length < 10 || c.heading.length > 80)
    errors.push('cta.heading must be 10-80 chars');
  if (c.subheading && (c.subheading.length < 10 || c.subheading.length > 150))
    errors.push('cta.subheading must be 10-150 chars');
  if (!c.button_text || c.button_text.length < 3 || c.button_text.length > 40)
    errors.push('cta.button_text must be 3-40 chars');

  return errors.length === 0 ? pass() : { ok: false, errors };
}

// ===== VALIDATOR MAP =====
export type SectionKey = 'timeline' | 'stats' | 'values' | 'differentiators' | 'certifications' | 'staff' | 'cta';

export const SECTION_VALIDATORS: Record<SectionKey, (data: unknown) => ValidationResult> = {
  timeline: validateTimeline,
  stats: validateStats,
  values: validateValues,
  differentiators: validateDifferentiators,
  certifications: validateCertifications,
  staff: validateStaff,
  cta: validateCTA,
};

export const SECTION_LABELS: Record<SectionKey, string> = {
  timeline: 'Timeline',
  stats: 'Stats',
  values: 'Valores',
  differentiators: 'Diferenciadores',
  certifications: 'Certificaciones',
  staff: 'Staff',
  cta: 'CTA',
};
