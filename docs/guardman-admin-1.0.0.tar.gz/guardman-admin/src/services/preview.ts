// GuardMan - Content Preview Service
// Generates HTML that matches EXACTLY the guardman-site layout:
// - SectionRenderer.astro structure
// - Header.astro nav bar
// - Footer.astro footer
// - app.css brand tokens (primary-600 = #1A2744, etc.)

export interface PreviewContext {
  entityType: string;
  entitySlug: string;
  entityName: string;
  content: any;
  images?: {
    hero?: string;
    og?: string;
    gallery?: string[];
  };
  score?: number;
  scoreDetails?: {
    seoOptimization?: number;
    contentQuality?: number;
    structure?: number;
    differentiation?: number;
    localRelevance?: number;
  };
}

export function renderPreviewHTML(ctx: PreviewContext): string {
  const { entityType, entitySlug, entityName, content, images, score, scoreDetails } = ctx;
  const s = content?.sections || content || {};
  
  const meta = s.meta || {};
  const hero = s.hero || {};
  const intro = s.intro || {};
  const features = s.features || {};
  const issues = s.issues || {};
  const stats = s.stats || {};
  const faqs = s.faqs || {};
  const cta = s.cta || {};
  const process = s.process || {};
  const coverage = s.coverage || {};

  const heroImage = images?.hero || hero.image || '';
  const titleLen = (meta.title || '').length;
  const descLen = (meta.description || '').length;
  const sd = scoreDetails || {};

  const urlPath = entityType === 'service' 
    ? `/servicios/${entitySlug}`
    : entityType === 'location'
    ? `/ubicaciones/${entitySlug}`
    : entityType === 'sector'
    ? `/sectores/${entitySlug}`
    : `/servicios/${entitySlug}`;

  // Process arrays properly (features.items can be string[] or object[])
  const featuresItems = features.items || [];
  const issuesItems = issues.items || [];
  const statsItems = stats.items || [];
  const faqsItems = faqs.items || [];
  const processSteps = process.steps || process.items || [];
  const coverageItems = coverage.items || [];

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${esc(meta.title || entityName)} — GuardMan Chile</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    :root {
      --color-primary-50: #E8ECF1; --color-primary-100: #C5CED9; --color-primary-200: #8FA4BA;
      --color-primary-300: #5F7A96; --color-primary-400: #3A5572; --color-primary-500: #1A3A5C;
      --color-primary-600: #1A2744; --color-primary-700: #152038; --color-primary-800: #0F1829;
      --color-neutral-50: #F8F9FA; --color-neutral-100: #F1F3F5; --color-neutral-200: #E5E7EB;
      --color-neutral-300: #CED4DA; --color-neutral-400: #ADB5BD; --color-neutral-500: #6C757D;
      --color-neutral-600: #495057; --color-neutral-700: #343A40; --color-neutral-800: #212529;
      --color-neutral-900: #0D0D0D;
      --color-accent: #3B82F6; --color-success: #10B981; --color-warning: #F59E0B; --color-error: #EF4444;
      --font-heading: 'Inter', system-ui, sans-serif; --font-body: 'Inter', system-ui, sans-serif;
      --radius-lg: 12px; --radius-xl: 16px;
      --shadow-sm: 0 1px 2px 0 rgba(0,0,0,0.05);
      --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1);
      --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1);
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: var(--font-body); color: var(--color-neutral-900); background: var(--color-neutral-50); line-height: 1.6; }
    h1,h2,h3,h4 { font-family: var(--font-heading); }
    .container { max-width: 1200px; margin: 0 auto; padding: 0 16px; }

    /* === PREVIEW BADGE === */
    .preview-badge {
      position: fixed; top: 0; left: 0; right: 0; z-index: 100;
      background: linear-gradient(90deg, #7c3aed, #2563eb); color: white;
      padding: 8px 16px; font-size: 13px; font-weight: 600; text-align: center;
      box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }
    .preview-container { max-width: 1200px; margin: 0 auto; padding-top: 48px; }

    /* === SCORE BAR === */
    .score-bar { background: white; border: 1px solid var(--color-neutral-200); border-radius: var(--radius-lg); padding: 12px 16px; margin: 16px auto; display: flex; align-items: center; flex-wrap: wrap; gap: 12px; }
    .score-bar .score-value { font-size: 1.5rem; font-weight: 800; }
    .score-bar .score-pill { font-size: 11px; padding: 2px 8px; border-radius: 9999px; font-weight: 600; }

    /* === SERP PREVIEW === */
    .serp-preview { background: white; border: 1px solid var(--color-neutral-200); border-radius: 8px; padding: 16px 20px; margin: 12px auto; max-width: 600px; font-family: Arial, sans-serif; }
    .serp-favicon { width: 28px; height: 28px; background: var(--color-primary-600); border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; color: white; font-size: 14px; font-weight: bold; margin-right: 10px; vertical-align: middle; }
    .serp-site { color: #202124; font-size: 14px; font-weight: 500; }
    .serp-title { color: #1a0dab; font-size: 20px; line-height: 1.3; text-decoration: none; display: block; margin-top: 4px; }
    .serp-title:hover { text-decoration: underline; }
    .serp-url { color: #006621; font-size: 14px; margin-top: 2px; }
    .serp-desc { color: #545454; font-size: 14px; line-height: 1.58; margin-top: 2px; }

    /* === SEO WARNINGS === */
    .seo-warning { background: #fef3c7; border: 1px solid #fbbf24; border-radius: 8px; padding: 8px 16px; margin: 8px auto; max-width: 600px; font-size: 13px; color: #92400e; }

    /* === HEADER (matches guardman-site Header.astro) === */
    .site-header { background: white; box-shadow: var(--shadow-sm); position: sticky; top: 0; z-index: 50; }
    .site-header .container { display: flex; align-items: center; justify-content: space-between; height: 64px; }
    .site-logo { display: flex; align-items: center; gap: 8px; text-decoration: none; }
    .site-logo-icon { width: 40px; height: 40px; background: var(--color-primary-600); border-radius: 8px; display: flex; align-items: center; justify-content: center; }
    .site-logo-icon svg { width: 24px; height: 24px; color: white; }
    .site-logo-text { font-size: 1.25rem; font-weight: 700; color: var(--color-primary-600); }
    .site-header-cta { background: var(--color-primary-600); color: white; padding: 10px 20px; border-radius: 8px; font-weight: 600; font-size: 14px; text-decoration: none; }
    .site-header-cta:hover { background: var(--color-primary-700); }

    /* === HERO SECTION (matches PageHero.astro) === */
    .hero-section { position: relative; background: var(--color-primary-600); color: white; padding: 64px 0 80px; overflow: hidden; }
    ${heroImage ? `.hero-section .hero-bg { position: absolute; inset: 0; }
    .hero-section .hero-bg img { width: 100%; height: 100%; object-fit: cover; opacity: 0.3; }
    .hero-section .hero-bg .hero-overlay { position: absolute; inset: 0; background: linear-gradient(to right, rgba(15,24,41,0.95), rgba(26,58,92,0.7)); }` : ''}
    .hero-deco1 { position: absolute; top: 0; right: 0; width: 256px; height: 256px; background: rgba(26,58,92,0.2); border-radius: 50%; filter: blur(64px); transform: translate(50%, -50%); }
    .hero-deco2 { position: absolute; bottom: 0; left: 0; width: 384px; height: 384px; background: rgba(255,255,255,0.05); border-radius: 50%; filter: blur(64px); transform: translate(-50%, 50%); }
    .hero-section .container { position: relative; z-index: 10; }
    .hero-section h1 { font-size: 3rem; font-weight: 800; margin-bottom: 16px; line-height: 1.1; }
    @media (min-width: 1024px) { .hero-section h1 { font-size: 3.75rem; } }
    .hero-section .subtitle { font-size: 1.25rem; color: rgba(255,255,255,0.9); max-width: 600px; }

    /* === INTRO SECTION (matches SectionRenderer) === */
    .intro-section { padding: 48px 0; background: white; }
    .intro-section p { color: var(--color-neutral-600); font-size: 1.1rem; line-height: 1.75; margin-bottom: 16px; max-width: 768px; margin-left: auto; margin-right: auto; }

    /* === FEATURES SECTION === */
    .features-section { padding: 48px 0; background: var(--color-neutral-50); }
    .features-section h2 { font-size: 1.5rem; font-weight: 700; color: var(--color-neutral-900); margin-bottom: 24px; }
    .features-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }
    .feature-card { display: flex; align-items: flex-start; gap: 12px; background: white; border-radius: 8px; padding: 16px; box-shadow: var(--shadow-sm); transition: box-shadow 0.2s; }
    .feature-card:hover { box-shadow: var(--shadow-md); }
    .feature-card .icon { width: 20px; height: 20px; color: var(--color-success); flex-shrink: 0; margin-top: 2px; }
    .feature-card span { color: var(--color-neutral-700); }

    /* === ISSUES SECTION === */
    .issues-section { padding: 48px 0; background: #fffbeb; }
    .issues-section h2 { font-size: 1.5rem; font-weight: 700; color: var(--color-neutral-900); margin-bottom: 24px; }
    .issues-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
    .issue-card { display: flex; align-items: flex-start; gap: 12px; background: white; border: 1px solid #fde68a; border-radius: 8px; padding: 16px; }
    .issue-card .icon { width: 20px; height: 20px; color: var(--color-warning); flex-shrink: 0; margin-top: 2px; }
    .issue-card span { color: var(--color-neutral-700); font-size: 0.9rem; font-weight: 500; }

    /* === STATS SECTION === */
    .stats-section { padding: 48px 0; background: var(--color-primary-700); color: white; }
    .stats-section h2 { font-size: 1.5rem; font-weight: 700; text-align: center; margin-bottom: 32px; }
    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 32px; text-align: center; }
    .stats-grid .stat-value { font-size: 2.5rem; font-weight: 800; margin-bottom: 8px; }
    .stats-grid .stat-label { font-size: 1rem; color: rgba(255,255,255,0.8); }
    @media (max-width: 768px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }

    /* === FAQS SECTION (matches FAQList.astro) === */
    .faqs-section { padding: 48px 0; background: white; }
    .faqs-section h2 { font-size: 1.5rem; font-weight: 700; color: var(--color-neutral-900); margin-bottom: 24px; }
    .faq-list { max-width: 768px; margin: 0 auto; display: flex; flex-direction: column; gap: 16px; }
    details.faq-item { background: var(--color-neutral-50); border-radius: var(--radius-lg); overflow: hidden; }
    details.faq-item summary { display: flex; align-items: center; gap: 12px; padding: 24px; cursor: pointer; list-style: none; }
    details.faq-item summary::-webkit-details-marker { display: none; }
    details.faq-item .faq-num { width: 32px; height: 32px; background: #e8ecf1; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    details.faq-item .faq-num span { color: var(--color-primary-600); font-weight: 700; font-size: 0.875rem; }
    details.faq-item .faq-q { font-weight: 600; color: var(--color-neutral-900); flex: 1; }
    details.faq-item .faq-chevron { width: 20px; height: 20px; color: var(--color-neutral-400); flex-shrink: 0; transition: transform 0.2s; }
    details.faq-item[open] .faq-chevron { transform: rotate(180deg); }
    details.faq-item .faq-a { padding: 0 24px 24px 56px; color: var(--color-neutral-600); }

    /* === CTA SECTION (matches PageCTA.astro) === */
    .cta-section { padding: 64px 0; background: var(--color-primary-600); color: white; position: relative; overflow: hidden; }
    .cta-section .cta-deco1 { position: absolute; top: 0; right: 0; width: 256px; height: 256px; background: rgba(26,58,92,0.2); border-radius: 50%; filter: blur(64px); transform: translate(50%, -50%); }
    .cta-section .cta-deco2 { position: absolute; bottom: 0; left: 0; width: 384px; height: 384px; background: rgba(255,255,255,0.05); border-radius: 50%; filter: blur(64px); transform: translate(-50%, 50%); }
    .cta-section .container { position: relative; z-index: 10; text-align: center; max-width: 768px; }
    .cta-section h2 { font-size: 2rem; font-weight: 800; margin-bottom: 16px; }
    @media (min-width: 1024px) { .cta-section h2 { font-size: 2.5rem; } }
    .cta-section .cta-desc { font-size: 1.125rem; color: rgba(255,255,255,0.9); margin-bottom: 32px; max-width: 600px; margin-left: auto; margin-right: auto; }
    .cta-section .cta-badge { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border-radius: 9999px; font-size: 0.875rem; font-weight: 500; margin-bottom: 24px; }
    .cta-section .cta-buttons { display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; }
    .cta-section .btn-primary { background: white; color: var(--color-primary-600); padding: 16px 32px; border-radius: 8px; font-weight: 600; text-decoration: none; font-size: 1rem; }
    .cta-section .btn-primary:hover { background: var(--color-neutral-100); }
    .cta-section .btn-secondary { border: 2px solid white; color: white; padding: 14px 32px; border-radius: 8px; font-weight: 600; text-decoration: none; font-size: 1rem; background: transparent; }
    .cta-section .btn-secondary:hover { background: rgba(255,255,255,0.1); }
    .cta-section .cta-phone { margin-top: 24px; display: inline-flex; align-items: center; gap: 8px; color: rgba(255,255,255,0.9); font-weight: 500; text-decoration: none; }

    /* === FOOTER (matches Footer.astro) === */
    .site-footer { background: var(--color-neutral-800); color: white; padding: 48px 0 32px; }
    .footer-grid { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 32px; margin-bottom: 48px; }
    @media (max-width: 768px) { .footer-grid { grid-template-columns: 1fr 1fr; } }
    .footer-grid h3 { font-size: 1.125rem; font-weight: 600; margin-bottom: 16px; }
    .footer-grid a { color: var(--color-neutral-400); text-decoration: none; font-size: 0.875rem; display: block; padding: 4px 0; }
    .footer-grid a:hover { color: white; }
    .footer-bottom { border-top: 1px solid rgba(255,255,255,0.1); padding-top: 32px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; }
    .footer-bottom p { color: var(--color-neutral-400); font-size: 0.875rem; }
    .footer-bottom a { color: var(--color-neutral-400); text-decoration: none; font-size: 0.875rem; margin: 0 12px; }
    .footer-bottom a:hover { color: white; }

    /* === PROCESS SECTION === */
    .process-section { padding: 48px 0; background: white; }
    .process-section h2 { font-size: 1.5rem; font-weight: 700; color: var(--color-neutral-900); margin-bottom: 24px; }
    .process-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 24px; }
    .process-step { text-align: center; }
    .process-num { width: 56px; height: 56px; background: var(--color-primary-600); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; font-weight: 700; margin: 0 auto 16px; box-shadow: var(--shadow-lg); }
    .process-step h3 { font-weight: 600; color: var(--color-neutral-900); margin-bottom: 8px; }
    .process-step p { font-size: 0.875rem; color: var(--color-neutral-600); }

    /* === COVERAGE SECTION === */
    .coverage-section { padding: 48px 0; background: var(--color-neutral-50); }
    .coverage-section h2 { font-size: 1.5rem; font-weight: 700; color: var(--color-neutral-900); margin-bottom: 24px; text-align: center; }
    .coverage-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; }
    .coverage-item { display: flex; align-items: center; gap: 12px; background: white; border-radius: 8px; padding: 12px 16px; box-shadow: var(--shadow-sm); }
    .coverage-item .icon { color: #3B82F6; font-size: 1.2rem; }
  </style>
</head>
<body>

  <!-- Preview Badge -->
  <div class="preview-badge">⚡ PREVIEW — ${esc(entityType)}/${esc(entitySlug)}</div>

  <div class="preview-container">

    <!-- Score Bar -->
    ${score !== undefined ? `
    <div class="score-bar">
      <span style="font-size:13px;font-weight:500;color:var(--color-neutral-500);">Score:</span>
      <span class="score-value" style="color:${score >= 80 ? 'var(--color-success)' : score >= 60 ? 'var(--color-warning)' : 'var(--color-error)'}">${score}/100</span>
      <div style="width:96px;height:8px;background:var(--color-neutral-200);border-radius:9999px;overflow:hidden">
        <div style="height:100%;border-radius:9999px;width:${Math.min(100, score)}%;background:${score >= 80 ? 'var(--color-success)' : score >= 60 ? 'var(--color-warning)' : 'var(--color-error)'}"></div>
      </div>
      <span class="score-pill" style="background:#eff6ff;color:#1d4ed8">SEO: ${sd.seoOptimization || sd.seo || 0}</span>
      <span class="score-pill" style="background:#ecfdf5;color:#059669">Contenido: ${sd.contentQuality || sd.content || 0}</span>
      <span class="score-pill" style="background:#eff6ff;color:#6d28d9">Estructura: ${sd.structure || 0}</span>
      <span class="score-pill" style="background:#fffbeb;color:#b45309">Diferenciacion: ${sd.differentiation || sd.keywords || 0}</span>
    </div>` : ''}

    <!-- Google SERP Preview -->
    <div class="serp-preview">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
        <div class="serp-favicon">G</div>
        <span class="serp-site">guardman.cl</span>
      </div>
      <a href="#" class="serp-title">${esc(meta.title || entityName)}</a>
      <div class="serp-url">https://guardman.cl${esc(urlPath)}</div>
      <div class="serp-desc">${esc(meta.description || '')}</div>
    </div>

    <!-- SEO Warnings -->
    ${(titleLen > 60 || descLen > 160) ? `
    <div class="seo-warning">
      <strong>⚠️ SEO Warnings:</strong>
      ${titleLen > 60 ? `<span style="margin-left:8px;color:#dc2626">Title ${titleLen}/60</span>` : ''}
      ${descLen > 160 ? `<span style="margin-left:8px;color:#dc2626">Description ${descLen}/160</span>` : ''}
    </div>` : ''}

    <!-- Schema Markup (JSON-LD) Preview -->
    ${generateSchemaPreview(entityType, entitySlug, entityName, content, meta)}

  </div>

  <!-- === HEADER (matches guardman-site Header.astro) === -->
  <header class="site-header">
    <div class="container">
      <a href="#" class="site-logo">
        <div class="site-logo-icon">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
        </div>
        <span class="site-logo-text">GuardMan</span>
      </a>
      <a href="#" class="site-header-cta">Cotizar</a>
    </div>
  </header>

  <main>

    <!-- === HERO (matches PageHero.astro + SectionRenderer) === -->
    ${hero.heading ? `
    <section class="hero-section">
      ${heroImage ? `<div class="hero-bg"><img src="${esc(heroImage)}" alt="" width="1920" height="1080"><div class="hero-overlay"></div></div>` : ''}
      <div class="hero-deco1"></div>
      <div class="hero-deco2"></div>
      <div class="container">
        ${hero.badge ? `<div style="display:inline-block;background:rgba(255,255,255,0.2);color:white;padding:8px 16px;border-radius:9999px;font-size:0.875rem;font-weight:500;margin-bottom:24px">${esc(hero.badge)}</div>` : ''}
        <h1>${esc(hero.heading)}</h1>
        ${hero.subheading ? `<p class="subtitle">${esc(hero.subheading)}</p>` : ''}
      </div>
    </section>` : ''}

    <!-- === INTRO (matches SectionRenderer intro) === -->
    ${intro.paragraphs?.length ? `
    <section class="intro-section">
      <div class="container">
        ${intro.heading ? `<h2 style="font-size:1.75rem;font-weight:700;margin-bottom:16px;text-align:center">${esc(intro.heading)}</h2>` : ''}
        ${(intro.paragraphs as string[]).map((p: string) => `<p>${esc(p)}</p>`).join('')}
      </div>
    </section>` : ''}

    <!-- === FEATURES (matches SectionRenderer features) === -->
    ${featuresItems.length > 0 ? `
    <section class="features-section">
      <div class="container">
        <h2>${esc(features.heading || 'Características del Servicio')}</h2>
        <div class="features-grid">
          ${(featuresItems as any[]).map((f: any) => `
          <div class="feature-card">
            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
            <span>${esc(typeof f === 'string' ? f : f.text || f.name || '')}</span>
          </div>`).join('')}
        </div>
      </div>
    </section>` : ''}

    <!-- === PROCESS (matches SectionRenderer process) === -->
    ${processSteps.length > 0 ? `
    <section class="process-section">
      <div class="container">
        <h2>${esc(process.heading || 'Nuestro Proceso')}</h2>
        <div class="process-grid">
          ${(processSteps as any[]).map((step: any, i: number) => `
          <div class="process-step">
            <div class="process-num">${i + 1}</div>
            <h3>${esc(typeof step === 'string' ? step : step.step || step.title || '')}</h3>
            ${step.description ? `<p>${esc(step.description)}</p>` : ''}
          </div>`).join('')}
        </div>
      </div>
    </section>` : ''}

    <!-- === ISSUES (matches SectionRenderer issues) === -->
    ${issuesItems.length > 0 ? `
    <section class="issues-section">
      <div class="container">
        <h2>${esc(issues.heading || 'Problemas que Solucionamos')}</h2>
        <div class="issues-grid">
          ${(issuesItems as any[]).map((issue: any) => `
          <div class="issue-card">
            <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            <span>${esc(typeof issue === 'string' ? issue : issue.text || issue.title || '')}</span>
          </div>`).join('')}
        </div>
      </div>
    </section>` : ''}

    <!-- === COVERAGE === -->
    ${coverageItems.length > 0 ? `
    <section class="coverage-section">
      <div class="container">
        <h2>${esc(coverage.heading || 'Cobertura y Disponibilidad')}</h2>
        <div class="coverage-grid">
          ${(coverageItems as any[]).map((c: any) => `
          <div class="coverage-item">
            <span class="icon">📍</span>
            <span style="color:var(--color-neutral-700)">${esc(typeof c === 'string' ? c : c.name || c.text || '')}</span>
          </div>`).join('')}
        </div>
      </div>
    </section>` : ''}

    <!-- === STATS (matches SectionRenderer stats) === -->
    ${statsItems.length > 0 ? `
    <section class="stats-section">
      <div class="container">
        <h2>${esc(stats.heading || 'Números que nos Respaldan')}</h2>
        <div class="stats-grid">
          ${(statsItems as any[]).map((st: any) => `
          <div>
            <div class="stat-value">${esc(typeof st === 'string' ? st : st.value || '')}</div>
            <div class="stat-label">${esc(typeof st === 'string' ? '' : st.label || '')}</div>
          </div>`).join('')}
        </div>
      </div>
    </section>` : ''}

    <!-- === FAQS (matches FAQList.astro) === -->
    ${faqsItems.length > 0 ? `
    <section class="faqs-section">
      <div class="container">
        <h2>${esc(faqs.heading || 'Preguntas Frecuentes')}</h2>
        <div class="faq-list">
          ${(faqsItems as any[]).map((faq: any, i: number) => `
          <details class="faq-item">
            <summary>
              <div class="faq-num"><span>${i + 1}</span></div>
              <span class="faq-q">${esc(faq.question || faq)}</span>
              <svg class="faq-chevron" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
            </summary>
            <div class="faq-a">${esc(faq.answer || '')}</div>
          </details>`).join('')}
        </div>
      </div>
    </section>` : ''}

    <!-- === CTA (matches PageCTA.astro primary variant) === -->
    ${cta.heading ? `
    <section class="cta-section">
      <div class="cta-deco1"></div>
      <div class="cta-deco2"></div>
      <div class="container">
        <div class="cta-badge">
          <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
          <span>Certificación OS-10 y Ley 21.659</span>
        </div>
        <h2>${esc(cta.heading)}</h2>
        ${cta.description || cta.subheading ? `<p class="cta-desc">${esc(cta.description || cta.subheading || '')}</p>` : ''}
        <div class="cta-buttons">
          <a href="#" class="btn-primary">${esc(cta.button || 'Solicitar Cotización')}</a>
          <a href="#" class="btn-secondary">Contactar</a>
        </div>
        <a href="tel:+56930000010" class="cta-phone">
          <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
          +56 9 3000 0010
        </a>
        <span style="margin-left:16px;font-size:0.875rem;color:rgba(255,255,255,0.6)">o llama directamente</span>
      </div>
    </section>` : ''}

  </main>

  <!-- === FOOTER (matches Footer.astro) === -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div>
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
            <div style="width:40px;height:40px;background:var(--color-primary-600);border-radius:8px;display:flex;align-items:center;justify-content:center">
              <svg width="24" height="24" fill="none" stroke="white" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            </div>
            <span style="font-weight:700;font-size:1.25rem">GuardMan Chile</span>
          </div>
          <p style="color:#d4d4d4;font-size:0.875rem;margin-bottom:24px">Seguridad privada profesional en Santiago. Protegemos lo que más te importa con guardias certificados OS-10.</p>
        </div>
        <div>
          <h3>Servicios</h3>
          <a href="#">Guardias de Seguridad</a>
          <a href="#">CCTV y Videovigilancia</a>
          <a href="#">GuardPod V1</a>
          <a href="#">Monitoreo 24/7</a>
          <a href="#">Control de Accesos</a>
        </div>
        <div>
          <h3>Ubicaciones</h3>
          <a href="#">Las Condes</a>
          <a href="#">Vitacura</a>
          <a href="#">Lo Barnechea</a>
          <a href="#">Providencia</a>
          <a href="#">Santiago Centro</a>
        </div>
        <div>
          <h3>Contacto</h3>
          <a href="tel:+56930000010" style="display:flex;align-items:center;gap:12px;padding:8px 0">📞 +56 9 3000 0010</a>
          <a href="mailto:info@guardman.cl" style="display:flex;align-items:center;gap:12px;padding:8px 0">✉️ info@guardman.cl</a>
          <a href="/cotizacion" style="margin-top:16px;display:block;background:var(--color-primary-600);color:white;text-align:center;padding:12px;border-radius:8px;font-weight:600">Solicitar Cotización</a>
        </div>
      </div>
      <div class="footer-bottom">
        <div>
          <a href="#">Inicio</a>
          <a href="#">Nosotros</a>
          <a href="#">Blog</a>
          <a href="#">Contacto</a>
          <a href="#">Privacidad</a>
        </div>
        <p>© ${new Date().getFullYear()} GuardMan Chile. Todos los derechos reservados.</p>
      </div>
    </div>
  </footer>

  <div style="text-align:center;padding:24px;color:#9ca3af;font-size:12px">
    Preview generado el ${new Date().toLocaleString('es-CL')} — ${esc(entityType)}/${esc(entitySlug)}
  </div>

</body>
</html>`;
}

function esc(str: string | undefined | null): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function generateSchemaPreview(entityType: string, entitySlug: string, entityName: string, content: any, meta: any): string {
  // Build JSON-LD schema for the entity
  const schema: any = {
    '@context': 'https://schema.org',
    '@type': entityType === 'service' || entityType === 'combo' ? 'Service' : entityType === 'location' ? 'LocalBusiness' : 'WebPage',
    'name': meta?.title || entityName,
    'description': meta?.description || '',
    'url': `https://guardman.cl/${entityType === 'service' ? 'servicios' : entityType === 'location' ? 'ubicaciones' : entityType === 'sector' ? 'sectores' : 'servicios'}/${entitySlug}`,
    'provider': {
      '@type': 'Organization',
      'name': 'GuardMan Chile',
      'url': 'https://guardman.cl',
      'telephone': '+56 9 3000 0010',
    },
  };

  // Add FAQ schema if present
  const s = content?.sections || content || {};
  const faqsItems = s.faqs?.items || [];
  if (faqsItems.length > 0) {
    schema['hasOfferCatalog'] = {
      '@type': 'FAQPage',
      'mainEntity': faqsItems.map((f: any) => ({
        '@type': 'Question',
        'name': f.question || f,
        'acceptedAnswer': {
          '@type': 'Answer',
          'text': f.answer || '',
        },
      })),
    };
  }

  const schemaJson = JSON.stringify(schema, null, 2);
  const lines = schemaJson.split('\n');
  const lineCount = lines.length;
  const truncated = lineCount > 15;
  const displayLines = truncated ? [...lines.slice(0, 15), '  // ... truncated'] : lines;

  return `
    <div style="background:white;border:1px solid var(--color-neutral-200);border-radius:8px;padding:16px 20px;margin:12px auto;max-width:600px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:16px">📋</span>
        <span style="font-size:12px;font-weight:600;color:var(--color-neutral-500);text-transform:uppercase;letter-spacing:0.05em">Schema JSON-LD</span>
        <span style="margin-left:auto;font-size:11px;padding:2px 8px;border-radius:9999px;background:#eff6ff;color:#1d4ed8;font-weight:600">${lineCount} lines</span>
      </div>
      <pre style="font-size:11px;line-height:1.4;color:var(--color-neutral-700);overflow-x:auto;background:var(--color-neutral-50);padding:12px;border-radius:8px;margin:0">${displayLines.map(l => esc(l)).join('\n')}</pre>
    </div>`;
}
