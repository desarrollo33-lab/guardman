// GuardMan v3.0 — KV Cache Service
// Page-level caching for SSR. Invalidated on CMS save/regenerate.

const DEFAULT_TTL = 3600; // 1 hour

export const CACHE_TTL = {
  OVERVIEW: 300,     // 5 min
  CONTENT: 3600,     // 1 hour
  STATIC: 86400,     // 24 hours
};

export async function cachedFetch<T>(cache: any, key: string, options: { ttl: number }, fetcher: () => Promise<T>): Promise<T> {
  try {
    const cached = await cache.get(key);
    if (cached) return JSON.parse(cached);
  } catch { /* cache miss, proceed */ }
  const result = await fetcher();
  try {
    await cache.put(key, JSON.stringify(result), { expirationTtl: options.ttl });
  } catch { /* cache write failed, non-critical */ }
  return result;
}

export function getCacheKey(entityType: string, slug?: string): string {
  if (entityType === 'homepage') return 'page:homepage';
  if (slug) return `page:${entityType}:${slug}`;
  return `page:${entityType}`;
}

export async function getCache(env: any, key: string): Promise<string | null> {
  try {
    const val = await env.CACHE.get(key);
    return val || null;
  } catch {
    return null;
  }
}

export async function setCache(env: any, key: string, value: string, ttl: number = DEFAULT_TTL): Promise<void> {
  try {
    await env.CACHE.put(key, value, { expirationTtl: ttl });
  } catch {
    // Cache is optional — fail silently
  }
}

export async function invalidateCache(env: any, entityType: string, slug?: string): Promise<void> {
  try {
    // Special case: static homepage uses 'page:homepage' key
    if (entityType === 'static' && slug === 'homepage') {
      await env.CACHE.delete('page:homepage');
      return;
    }
    const key = getCacheKey(entityType, slug);
    await env.CACHE.delete(key);
    // Also invalidate homepage (it lists services/locations/sectors)
    if (entityType === 'service' || entityType === 'location' || entityType === 'sector' || entityType === 'combo' || entityType === 'homepage') {
      await env.CACHE.delete('page:homepage');
    }
  } catch {
    // Cache is optional — fail silently
  }
}

export async function flushAllCache(env: any): Promise<void> {
  try {
    // List and delete all cached pages
    const keys = await env.CACHE.list({ prefix: 'page:' });
    for (const k of keys.keys) {
      await env.CACHE.delete(k.name);
    }
    // Also flush data cache
    const dataKeys = await env.CACHE.list({ prefix: 'data:' });
    for (const k of dataKeys.keys) {
      await env.CACHE.delete(k.name);
    }
  } catch {
    // Cache is optional — fail silently
  }
}
