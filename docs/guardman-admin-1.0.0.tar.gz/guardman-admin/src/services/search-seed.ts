// GuardMan v4 — AI Search Seed Service
// Seeds all 13 AI Search instances from D1 data (~17K documents)
// Run once at setup, then incrementally update after Serper scans

import type { Env } from '../types';
import { ALL_INSTANCES, SECTOR_INSTANCES } from './search';

interface SeedResult {
  instances: string[];
  documents: number;
  errors: number;
  details: { instance: string; documents: number; error?: string }[];
}

export async function seedAllInstances(env: Env): Promise<SeedResult> {
  const result: SeedResult = { instances: [], documents: 0, errors: 0, details: [] };

  if (!env.AI_SEARCH) {
    console.warn('[SearchSeed] AI_SEARCH binding not available, skipping seed');
    return result;
  }

  // Step 1: Create all instances
  for (const instanceId of ALL_INSTANCES) {
    try {
      await env.AI_SEARCH.create({
        id: instanceId,
        index_method: { keyword: true, vector: true },
        indexing_options: { keyword_tokenizer: 'porter' },
        retrieval_options: { keyword_match_mode: 'or' },
        fusion_method: 'rrf',
      });
      result.instances.push(instanceId);
    } catch (e: any) {
      // Already exists is OK
      result.instances.push(instanceId);
    }
  }

  // Step 2: Seed shared-brand-guide (3 documents)
  const brandDocs = await seedBrandGuide(env);
  result.documents += brandDocs;
  result.details.push({ instance: 'shared-brand-guide', documents: brandDocs });

  // Step 3: Seed shared-seo-rules
  const seoDocs = await seedSEORules(env);
  result.documents += seoDocs;
  result.details.push({ instance: 'shared-seo-rules', documents: seoDocs });

  // Step 4: Seed shared-knowledge (29 rows from agent_knowledge)
  const knowledgeDocs = await seedKnowledge(env);
  result.documents += knowledgeDocs;
  result.details.push({ instance: 'shared-knowledge', documents: knowledgeDocs });

  // Step 5: Seed serper-intel (13,300 results)
  const serperDocs = await seedSerperIntel(env);
  result.documents += serperDocs;
  result.details.push({ instance: 'serper-intel', documents: serperDocs });

  // Step 6: Seed sector-{slug} instances
  const services = await env.DB.prepare('SELECT slug, name FROM services ORDER BY name').all();
  for (const svc of (services.results as any[])) {
    const sectorDocs = await seedSectorInstance(env, svc.slug);
    result.documents += sectorDocs;
    result.details.push({ instance: `sector-${svc.slug}`, documents: sectorDocs });
  }

  console.log(`[SearchSeed] Complete: ${result.instances.length} instances, ${result.documents} documents`);
  return result;
}

async function uploadDoc(env: Env, instanceId: string, docId: string, content: string, metadata: Record<string, any> = {}): Promise<boolean> {
  try {
    const instance = env.AI_SEARCH.get(instanceId);
    await instance.items.uploadAndPoll(docId, content, { metadata });
    return true;
  } catch (e) {
    console.warn(`[SearchSeed] Failed to upload ${docId} to ${instanceId}:`, (e as Error).message);
    return false;
  }
}

async function seedBrandGuide(env: Env): Promise<number> {
  let docs = 0;

  if (await uploadDoc(env, 'shared-brand-guide', 'brand-voice.md', `
# GuardMan Chile — Voz de Marca

## Personalidad
- Profesional pero cercano (tú, no usted)
- Autoridad en seguridad sin ser arrogante
- Datos concretos, no promesas vagas

## Datos de Empresa
- 8+ años de experiencia en seguridad privada Chile
- 500+ guardias certificados OS-10 activos
- 14 comunas de la Región Metropolitana
- Centro de monitoreo 24/7 propio
- Respuesta < 30 minutos en zona de cobertura

## Diferenciadores
- Certificación OS-10 vigente (no subcontratación informal)
- Tecnología propia (CCTV, monitoreo, control de accesos)
- Reportes diarios digitalizados
- Coordinación directa con Carabineros

## Reglas de Contenido
- NUNCA mentir sobre cifras
- NUNCA prometer "el mejor precio" sin contexto
- SIEMPRE mencionar OS-10 cuando hablemos de guardias
- SIEMPRE incluir CTA claro
- Evitar jerga técnica excesiva
- Usar "chileno" natural (no "seguridad privada" por "guardias")
`, { type: 'brand', version: 1 })) docs++;

  if (await uploadDoc(env, 'shared-brand-guide', 'company-data.md', `
# GuardMan Chile — Datos de Empresa

## Servicios Principales
1. Guardias de Seguridad — OS-10 certificados
2. CCTV y Videovigilancia — Monitoreo 24/7
3. Control de Accesos — Tecnología biométrica
4. Monitoreo 24/7 — Centro de control propio
5. Auditoría de Seguridad — Evaluación de riesgos
6. Seguridad Industrial — Minería, construcción, logística
7. Seguridad Eventos — Masivos, corporativos, privados
8. Escoltas Privados — Ejecutivos, traslados
9. Servicios Generales — Seguridad integral

## Cobertura Geográfica
Santiago Centro, Huechuraba, Lampa, Quilicura, La Reina, Las Condes,
Lo Barnechea, Vitacura, Conchalí, Pudahuel, Renca, La Pintana,
Los Andes, San Felipe

## Certificaciones
- OS-10 (Ministerio del Interior) — Vigente
- Registros de personal actualizados
- Coordinación con Carabineros de Chile
`, { type: 'company', version: 1 })) docs++;

  if (await uploadDoc(env, 'shared-brand-guide', 'exclusion-rules.md', `
# GuardMan Chile — Reglas de Exclusión

## NO generar contenido sobre:
- Armamento (GuardMan NO vende armas)
- Vigilancia ilegal (Solo legítima)
- Precios exactos (Solo rangos o "cotizar")
- Garantías de resultado (Ej: "100% libre de robos")
- Comparaciones directas nombrando competidores

## SIEMPRE incluir:
- CTA hacia cotización o WhatsApp
- Mención de OS-10 cuando sea relevante
- Datos de contacto o formas de comunicación
- Contexto local cuando sea contenido de comuna
`, { type: 'exclusions', version: 1 })) docs++;

  return docs;
}

async function seedSEORules(env: Env): Promise<number> {
  let docs = 0;

  if (await uploadDoc(env, 'shared-seo-rules', 'title-rules.md', `
# SEO Rules — Titles & Descriptions

## Meta Title (< 60 chars)
- Keyword principal primero
- Incluir "|" como separador de marca
- No usar emoji en titles
- Formato: "{Keyword} en {Comuna} | GuardMan Chile"

## Meta Description (< 160 chars)
- Incluir keyword principal
- Incluir CTA ("Cotiza gratis", "Solicita cotización")
- Mencionar diferenciador (OS-10, 24/7, etc.)
- No repetir el title exacto

## Estructura H1→H2→H3
- H1: Solo 1 por página, keyword principal
- H2: Secciones (intro, features, FAQs, CTA)
- H3: Sub-items dentro de features/issues
- FAQs: Schema FAQ markup con preguntas reales

## Internal Links
- Vincular servicio → comunas donde se ofrece
- Vincular comuna → servicios disponibles
- Vincular sector → servicio relacionado
`, { type: 'seo-rules', version: 1 })) docs++;

  if (await uploadDoc(env, 'shared-seo-rules', 'structure-rules.md', `
# SEO Rules — Content Structure

## Secciones Requeridas (orden)
1. Hero: H1 + subheading + CTA + imagen
2. Intro: 2-3 párrafos con keyword + contexto local
3. Features: 6+ items del servicio
4. Issues: 4+ problemas que resuelve
5. Stats: 3+ datos numéricos realistas
6. FAQs: 4+ preguntas reales (PAA de Google)
7. CTA: Heading + subheading + botón claro
8. Meta: Title (<60) + Description (<160)

## Schema Markup
- FAQPage schema para sección de FAQs
- LocalBusiness schema para páginas de comuna
- Service schema para páginas de servicio
- Review/AggregateRating si hay testimonios

## Keywords
- Incluir keywords de Serper queries naturalmente
- No keyword stuffing
- Usar variaciones sinónimas
- Priorizar "easy wins" (tier easy, low competition)
`, { type: 'structure-rules', version: 1 })) docs++;

  return docs;
}

async function seedKnowledge(env: Env): Promise<number> {
  let docs = 0;
  try {
    const { results } = await env.DB.prepare('SELECT * FROM agent_knowledge ORDER BY category, key').all();
    for (const row of (results as any[])) {
      const docId = `${row.category}/${row.key}.md`;
      const content = `# ${row.key}\n\nCategory: ${row.category}\n\n${row.value}\n\nConfidence: ${row.confidence || 'N/A'}\nSource: ${row.source || 'manual'}`;
      if (await uploadDoc(env, 'shared-knowledge', docId, content, {
        category: row.category,
        key: row.key,
        confidence: row.confidence,
      })) docs++;
    }
  } catch (e) {
    console.warn('[SearchSeed] Knowledge seed failed:', (e as Error).message);
  }
  return docs;
}

async function seedSerperIntel(env: Env): Promise<number> {
  let docs = 0;
  const services = await env.DB.prepare('SELECT slug FROM services').all();

  // Competitors top 10 per service
  for (const svc of (services.results as any[])) {
    try {
      const { results } = await env.DB.prepare(`
        SELECT sr.domain, sr.position, sr.title, sr.snippet, sq.query_text, sq.location_slug
        FROM serper_results sr
        JOIN serper_queries sq ON sr.query_id = sq.id
        WHERE sq.service_slug = ? AND sr.site_type = 'direct_competitor' AND sr.position <= 10
        ORDER BY sr.position ASC
      `).bind(svc.slug).all();

      if (results.length > 0) {
        const content = (results as any[]).map((r: any) =>
          `[${r.position}] ${r.domain} | ${r.query_text} | ${r.location_slug}\n   ${r.title}\n   ${(r.snippet || '').substring(0, 150)}`
        ).join('\n\n');
        if (await uploadDoc(env, 'serper-intel', `competitors-${svc.slug}.md`, content, {
          type: 'competitors', service: svc.slug,
        })) docs++;
      }
    } catch (e) { /* skip */ }
  }

  // PAA questions (all)
  try {
    const { results } = await env.DB.prepare(`
      SELECT sr.title as question, sr.snippet, sq.service_slug, sq.location_slug
      FROM serper_results sr
      JOIN serper_queries sq ON sr.query_id = sq.id
      WHERE sr.result_type = 'paa'
      ORDER BY sq.service_slug, sq.location_slug
    `).all();

    if (results.length > 0) {
      const content = (results as any[]).map((r: any) =>
        `Q: ${r.question} [${r.service_slug}/${r.location_slug}]\nA: ${(r.snippet || '').substring(0, 200)}`
      ).join('\n\n');
      if (await uploadDoc(env, 'serper-intel', 'paa-all.md', content, { type: 'paa' })) docs++;
    }
  } catch (e) { /* skip */ }

  // Content gaps
  try {
    const { results } = await env.DB.prepare(`
      SELECT sq.query_text, sq.service_slug, sq.location_slug,
        MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as guardman_pos
      FROM serper_queries sq
      LEFT JOIN serper_results sr ON sq.id = sr.query_id
      WHERE sq.status = 'completed' AND sq.endpoint = 'search'
      GROUP BY sq.id
      HAVING guardman_pos > 5 OR guardman_pos = 999
      ORDER BY sq.service_slug
    `).all();

    if (results.length > 0) {
      const content = (results as any[]).map((r: any) =>
        `GAP [${r.service_slug}/${r.location_slug}]: "${r.query_text}" (pos: ${r.guardman_pos === 999 ? 'N/A' : r.guardman_pos})`
      ).join('\n');
      if (await uploadDoc(env, 'serper-intel', 'content-gaps.md', content, { type: 'gaps' })) docs++;
    }
  } catch (e) { /* skip */ }

  // Organic snippets (top results for context)
  try {
    const { results } = await env.DB.prepare(`
      SELECT sq.service_slug, sq.location_slug, sq.query_text,
        sr.position, sr.domain, sr.title, sr.snippet
      FROM serper_results sr
      JOIN serper_queries sq ON sr.query_id = sq.id
      WHERE sr.result_type = 'organic' AND sr.position <= 5
      ORDER BY sq.service_slug, sr.position
    `).all();

    if (results.length > 0) {
      const content = (results as any[]).map((r: any) =>
        `[${r.service_slug}/${r.location_slug}] #${r.position} ${r.domain}: ${r.title}\n   ${(r.snippet || '').substring(0, 150)}`
      ).join('\n\n');
      if (await uploadDoc(env, 'serper-intel', 'organic-top5.md', content, { type: 'organic' })) docs++;
    }
  } catch (e) { /* skip */ }

  return docs;
}

async function seedSectorInstance(env: Env, serviceSlug: string): Promise<number> {
  const instanceId = `sector-${serviceSlug}`;
  let docs = 0;

  // Content history
  try {
    const { results } = await env.DB.prepare(`
      SELECT entity_slug, version, content_json, word_count, generated_by, created_at
      FROM content_versions
      WHERE entity_type = 'service' AND entity_slug = ?
      ORDER BY version DESC
    `).bind(serviceSlug).all();

    if (results.length > 0) {
      const content = (results as any[]).map((r: any) => {
        let parsed: any = {};
        try { parsed = JSON.parse(r.content_json); } catch {}
        const sections = parsed.sections || {};
        return `--- Version ${r.version} (${r.created_at}) ---\nWords: ${r.word_count}\nBy: ${r.generated_by}\nTitle: ${sections.meta?.title || 'N/A'}\nH1: ${sections.hero?.heading || 'N/A'}`;
      }).join('\n\n');
      if (await uploadDoc(env, instanceId, 'content-history.md', content, {
        type: 'content-history', service: serviceSlug,
      })) docs++;
    }
  } catch (e) { /* skip */ }

  // Keywords
  try {
    const { results } = await env.DB.prepare(`
      SELECT keyword, intent, sds_tier, volume_estimate, is_easy_win, priority_score
      FROM keywords WHERE service_slug = ?
      ORDER BY priority_score DESC LIMIT 100
    `).bind(serviceSlug).all();

    if (results.length > 0) {
      const content = (results as any[]).map((r: any) =>
        `[${r.sds_tier?.toUpperCase() || '?'}] ${r.keyword} (intent: ${r.intent}, easy_win: ${r.is_easy_win})`
      ).join('\n');
      if (await uploadDoc(env, instanceId, 'keywords.md', content, {
        type: 'keywords', service: serviceSlug,
      })) docs++;
    }
  } catch (e) { /* skip */ }

  // FAQs
  try {
    const { results } = await env.DB.prepare(`
      SELECT question, answer, source, frequency_rank
      FROM faqs WHERE service_slug = ?
      ORDER BY frequency_rank ASC LIMIT 50
    `).bind(serviceSlug).all();

    if (results.length > 0) {
      const content = (results as any[]).map((r: any) =>
        `Q${r.frequency_rank || '?'}: ${r.question}\nA: ${(r.answer || '(pending)').substring(0, 200)} [source: ${r.source}]`
      ).join('\n\n');
      if (await uploadDoc(env, instanceId, 'faqs.md', content, {
        type: 'faqs', service: serviceSlug,
      })) docs++;
    }
  } catch (e) { /* skip */ }

  // Landmarks
  try {
    const { results } = await env.DB.prepare(`
      SELECT l.name, l.type, l.relevance_score, loc.slug as location_slug
      FROM landmarks l
      JOIN locations loc ON l.location_slug = loc.slug
      WHERE loc.slug IN (SELECT slug FROM locations)
      ORDER BY l.relevance_score DESC
    `).all();

    if (results.length > 0) {
      const content = (results as any[]).map((r: any) =>
        `${r.name} (${r.type}) en ${r.location_slug} - relevancia: ${r.relevance_score}`
      ).join('\n');
      if (await uploadDoc(env, instanceId, 'landmarks.md', content, {
        type: 'landmarks', service: serviceSlug,
      })) docs++;
    }
  } catch (e) { /* skip */ }

  return docs;
}

/**
 * Incremental update: re-seed serper-intel after a new scan
 */
export async function updateSearchIndexFromSerper(env: Env): Promise<number> {
  if (!env.AI_SEARCH) return 0;

  // Delete old serper documents and re-upload
  let docs = 0;
  const services = await env.DB.prepare('SELECT slug FROM services').all();

  for (const svc of (services.results as any[])) {
    try {
      const instance = env.AI_SEARCH.get('serper-intel');
      // Delete old competitors doc for this service
      try { await instance.items.delete(`competitors-${svc.slug}.md`); } catch {}
    } catch {}
  }
  try { const instance = env.AI_SEARCH.get('serper-intel'); await instance.items.delete('paa-all.md'); } catch {}
  try { const instance = env.AI_SEARCH.get('serper-intel'); await instance.items.delete('content-gaps.md'); } catch {}
  try { const instance = env.AI_SEARCH.get('serper-intel'); await instance.items.delete('organic-top5.md'); } catch {}

  // Re-seed serper data
  docs += await seedSerperIntel(env);
  return docs;
}
