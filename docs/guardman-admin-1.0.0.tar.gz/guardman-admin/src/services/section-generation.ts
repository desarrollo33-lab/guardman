// GuardMan — Section Generation Service
// Generates ONE section of a static page using focused AI prompt.
// Validates, retries if needed, merges safely, and persists.

import type { SectionKey } from './section-validators';
import { SECTION_VALIDATORS } from './section-validators';
import { mergeSection, getSection } from './section-merge';
import { callDeepSeekForSection } from './ai';

interface GenerateSectionResult {
  ok: boolean;
  section: string;
  data?: any;
  error?: string;
  validated?: boolean;
  attempt?: number;
}

/**
 * Generate a single section with validation and optional retry.
 *
 * Flow:
 * 1. Call DeepSeek with focused prompt for this section
 * 2. Parse JSON response
 * 3. Validate against section schema
 * 4. If invalid and retries remain, retry with error feedback
 * 5. Merge with existing content_json
 * 6. Save to D1 (content_versions + static_page_content)
 */
export async function generateSection(
  env: any,
  slug: string,
  section: SectionKey,
  options?: {
    existingContent?: any;
    maxRetries?: number;
  }
): Promise<GenerateSectionResult> {
  const validator = SECTION_VALIDATORS[section as SectionKey];
  if (!validator) return { ok: false, section, error: `Unknown section: ${section}` };

  const maxRetries = options?.maxRetries ?? 2;
  let lastErrorFeedback = '';
  let data: any = null;
  let lastError: string | null = null;

  // Attempt generation (up to maxRetries + 1 attempts)
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      // Generate with AI
      data = await callDeepSeekForSection(section, env, lastErrorFeedback || undefined);

      // Validate against schema
      const validation = validator(data);
      if (validation.ok) {
        // Success — persist
        await persistSection(env, slug, section, data, options?.existingContent);
        return { ok: true, section, data, validated: true, attempt: attempt + 1 };
      }

      // Validation failed — prepare feedback for retry
      lastErrorFeedback = `Errores en seccion ${section}:\n${validation.errors.map(e => `- ${e}`).join('\n')}`;
      lastError = validation.errors.join('; ');
    } catch (err: any) {
      lastError = err.message;
      lastErrorFeedback = `Error tecnico: ${err.message}`;
    }

    // If this was the last attempt, don't wait
    if (attempt < maxRetries) {
      // Small delay between retries
      await new Promise(r => setTimeout(r, 1000));
    }
  }

  return { ok: false, section, error: lastError || 'Max retries exceeded' };
}

/**
 * Persist a generated section to the database.
 * Saves to both section_versions (history) and static_page_content (active).
 */
async function persistSection(
  env: any,
  slug: string,
  section: string,
  data: any,
  existingContent?: any
): Promise<void> {
  // Build the new content_json by merging with existing
  const existing = existingContent || await loadExistingContent(env, slug);
  const merged = mergeSection(existing, section as SectionKey, data);
  const contentJson = JSON.stringify(merged);

  // Save version history
  const versionResult = await env.DB.prepare(
    `SELECT COALESCE(MAX(version), 0) + 1 as next_version
     FROM section_versions
     WHERE entity_type = 'static_page' AND entity_slug = ? AND section_key = ?`
  ).bind(slug, section).first();

  const nextVersion = versionResult?.next_version || 1;

  await env.DB.prepare(
    `INSERT OR REPLACE INTO section_versions (entity_type, entity_slug, section_key, version, content_json, generated_by)
     VALUES (?, ?, ?, ?, ?, 'ai')`
  ).bind('static_page', slug, section, nextVersion, JSON.stringify(data)).run();

  // Update the main content_json
  await env.DB.prepare(
    `UPDATE static_page_content
     SET content_json = ?, updated_at = datetime('now')
     WHERE slug = ?`
  ).bind(contentJson, slug).run();

  // Also insert into content_versions for backwards compatibility
  const globalVersionResult = await env.DB.prepare(
    `SELECT COALESCE(MAX(version), 0) + 1 as next_version
     FROM content_versions
     WHERE entity_type = 'static_page' AND entity_slug = ?`
  ).bind(slug).first();

  const globalVersion = globalVersionResult?.next_version || 1;

  await env.DB.prepare(
    `INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count)
     VALUES (?, ?, ?, ?, 'ai', ?)`
  ).bind('static_page', slug, globalVersion, contentJson, contentJson.split(/\s+/).length).run();
}

/**
 * Load existing content_json from D1.
 */
async function loadExistingContent(env: any, slug: string): Promise<any> {
  const row = await env.DB.prepare(
    'SELECT content_json FROM static_page_content WHERE slug = ?'
  ).bind(slug).first();

  if (!row?.content_json) return null;

  try {
    return typeof row.content_json === 'string'
      ? JSON.parse(row.content_json)
      : row.content_json;
  } catch {
    return null;
  }
}

/**
 * Generate multiple sections in parallel with concurrency limit.
 */
export async function generateAllSections(
  env: any,
  slug: string,
  sections: SectionKey[],
  options?: {
    concurrency?: number;
    existingContent?: any;
    onProgress?: (section: string, status: 'started' | 'done' | 'failed', data?: any) => void;
  }
): Promise<{ successes: string[]; failures: { section: string; error: string }[] }> {
  const limit = options?.concurrency ?? 3;
  const existingContent = options?.existingContent || await loadExistingContent(env, slug);
  const successes: string[] = [];
  const failures: { section: string; error: string }[] = [];

  // Execute with concurrency limit
  let index = 0;
  const tasks = sections.map(s => async () => {
    options?.onProgress?.(s, 'started');
    const result = await generateSection(env, slug, s, { existingContent });
    if (result.ok) {
      successes.push(s);
      options?.onProgress?.(s, 'done', result.data);
    } else {
      failures.push({ section: s, error: result.error || 'Unknown' });
      options?.onProgress?.(s, 'failed');
    }
  });

  // Workers pattern with concurrency limit
  async function worker() {
    while (index < tasks.length) {
      const i = index++;
      await tasks[i]();
    }
  }

  await Promise.all(Array(Math.min(limit, tasks.length)).fill(null).map(() => worker()));

  return { successes, failures };
}
