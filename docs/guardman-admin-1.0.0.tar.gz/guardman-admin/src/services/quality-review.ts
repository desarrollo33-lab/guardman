// GuardMan v5.2 — Quality Review Service
// Layer 3 of the 4-layer quality pipeline
// Uses Workers AI (free via gateway) for LLM-based content review

import type { Env } from '../types';
import type { BrandContext } from './brand-context';

export interface QualityReview {
  score: number;          // 0-100
  seo: number;            // 0-45
  content: number;        // 0-40
  structure: number;      // 0-15
  voiceAlignment: number; // 0-10 (bonus)
  feedback: string;
  suggestions: string[];
  genericSections: string[];
}

export async function reviewWithWorkersAI(
  env: Env,
  contentJson: any,
  brandCtx: BrandContext,
  entityInfo: { type: string; slug: string; name: string }
): Promise<QualityReview> {
  const contentStr = JSON.stringify(contentJson, null, 2);

  // Limit context to avoid token overflow
  const truncatedContent = contentStr.substring(0, 4000);

  const statsStr = Object.entries(brandCtx.stats).map(([k, v]) => `${k}: ${v}`).join(', ');

  try {
    const response = await (env.AI as any).run('@cf/meta/llama-3.1-8b-instruct', {
      messages: [
        {
          role: 'system',
          content: `Eres un auditor experto de contenido SEO para GuardMan Chile.
Evalúa el siguiente contenido JSON para "${entityInfo.name}".

Responde SOLO con JSON válido (sin markdown, sin backticks):
{"seo":<number 0-45>,"content":<number 0-40>,"structure":<number 0-15>,"voiceAlignment":<number 0-10>,"feedback":"<resumen 1 frase>","suggestions":["<sugerencia>"],"genericSections":["<sección genérica>"]}

Criterios SEO (0-45):
- H1 entre 30-60 chars con keyword principal (15)
- Meta title 30-60 chars, meta description 80-160 chars (15)
- Keywords de Serper presentes naturalmente (15)

Criterios Contenido (0-40):
- Datos específicos reales, no genéricos (10)
- Menciona OS-10, 8+ años, 14 comunas, centro monitoreo (10)
- Features/issues concretos y específicos (10)
- Contexto local específico de la comuna (10)

Criterios Estructura (0-15):
- Secciones completas: hero, intro, features, issues, faqs, cta (5)
- FAQs >= 4 con respuestas detalladas (5)
- CTA con heading + button (5)

Voice Alignment (0-10):
- Suena como GuardMan (profesional, cercano, no militarista) (5)
- NO suena como "empresa de seguridad genérica" (5)

DATOS DE MARCA:
- Stats: ${statsStr}
- Menciones obligatorias: ${brandCtx.voice.mandatoryMentions.join(', ')}
- Prohibido: ${brandCtx.voice.forbiddenWords.join(', ')}`
        },
        {
          role: 'user',
          content: truncatedContent,
        }
      ],
      max_tokens: 500,
    });

    const text = response?.response || '';
    return parseReviewResponse(text);
  } catch (err: any) {
    // Fallback: if Workers AI fails, return neutral review
    return {
      score: 50, seo: 20, content: 15, structure: 10, voiceAlignment: 5,
      feedback: `Review fallback (AI error: ${err.message?.substring(0, 80)})`,
      suggestions: [], genericSections: [],
    };
  }
}

function parseReviewResponse(text: string): QualityReview {
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      const seo = clamp(Number(parsed.seo) || 0, 0, 45);
      const content = clamp(Number(parsed.content) || 0, 0, 40);
      const structure = clamp(Number(parsed.structure) || 0, 0, 15);
      const voice = clamp(Number(parsed.voiceAlignment) || 0, 0, 10);
      return {
        score: seo + content + structure + voice,
        seo, content, structure, voiceAlignment: voice,
        feedback: String(parsed.feedback || ''),
        suggestions: Array.isArray(parsed.suggestions) ? parsed.suggestions : [],
        genericSections: Array.isArray(parsed.genericSections) ? parsed.genericSections : [],
      };
    }
  } catch { /* parse failed */ }

  return {
    score: 50, seo: 20, content: 15, structure: 10, voiceAlignment: 5,
    feedback: 'Review parse failed, using default score',
    suggestions: [], genericSections: [],
  };
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}
