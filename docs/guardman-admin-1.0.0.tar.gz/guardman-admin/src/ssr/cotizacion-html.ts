export const COTIZACION_HTML = `<main>
<section class="hero" data-od-id="hero">
  <div class="container">
    <h1>Cotiza tu Servicio de Seguridad</h1>
    <p>Recibe una propuesta personalizada sin compromiso. Respuesta en menos de 24 horas.</p>
  </div>
</section>

<div class="trust-badges" data-od-id="trust-badges">
  <div class="container" style="display:flex;justify-content:center;gap:24px;flex-wrap:wrap">
    <div class="trust-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>Certificación OS-10 vigente</div>
    <div class="trust-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Respuesta en menos de 24h</div>
    <div class="trust-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>Cotización sin compromiso</div>
    <div class="trust-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>8+ años de experiencia</div>
  </div>
</div>

<section class="bg-neutral" data-od-id="form">
  <div class="container">
    <div class="form-card">
      <h3 style="font-size:22px;font-weight:700;margin-bottom:4px;text-align:center">Solicitar Cotización</h3>
      <p style="color:var(--muted);font-size:15px;margin-bottom:28px;text-align:center">Cuéntanos sobre tus necesidades y te enviaremos una propuesta adaptada.</p>
      <form method="POST" action="/cotizacion">
        <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off">
        <div class="form-row"><div class="form-group"><label>Nombre completo <span class="required">*</span></label><input type="text" name="nombre" required></div><div class="form-group"><label>Correo electrónico <span class="required">*</span></label><input type="email" name="email" required></div></div>
        <div class="form-row"><div class="form-group"><label>Teléfono <span class="required">*</span></label><input type="tel" name="telefono" required></div><div class="form-group"><label>Empresa (opcional)</label><input type="text" name="empresa"></div></div>
        <div class="form-row"><div class="form-group"><label>Comuna donde necesitas el servicio <span class="required">*</span></label><select name="location" required><option value="">Selecciona</option><option value="las-condes">Las Condes</option><option value="vitacura">Vitacura</option><option value="lo-barnechea">Lo Barnechea</option><option value="la-reina">La Reina</option><option value="santiago-centro">Santiago Centro</option><option value="huechuraba">Huechuraba</option><option value="quilicura">Quilicura</option><option value="lampa">Lampa</option><option value="pudahuel">Pudahuel</option><option value="conchali">Conchalí</option><option value="renca">Renca</option><option value="la-pintana">La Pintana</option><option value="los-andes">Los Andes</option><option value="san-felipe">San Felipe</option><option value="otra">Otra</option></select></div><div class="form-group"><label>Servicio de interés <span class="required">*</span></label><select name="service" required><option value="">Selecciona</option><option value="guardias-de-seguridad">Guardias de Seguridad</option><option value="cctv-videovigilancia">CCTV y Videovigilancia</option><option value="control-de-accesos">Control de Accesos</option><option value="monitoreo-24-7">Monitoreo 24/7</option><option value="escoltas-privados">Escoltas Privados</option><option value="guard-pod">Guard Pod</option><option value="seguridad-industrial">Seguridad Industrial</option><option value="seguridad-eventos">Seguridad para Eventos</option><option value="auditoria-seguridad">Auditoría de Seguridad</option><option value="asesoria">No estoy seguro — necesito asesoría</option></select></div></div>
        <div class="form-row"><div class="form-group"><label>Tipo de propiedad</label><select name="tipo_propiedad"><option value="">Selecciona</option><option value="residencial">Residencial / Condominio</option><option value="corporativo">Oficina / Corporativo</option><option value="retail">Comercio / Retail</option><option value="industrial">Bodega / Industrial</option><option value="construccion">Obra en construcción</option><option value="evento">Evento</option><option value="hotel">Hotel</option><option value="salud">Clínica / Hospital</option><option value="educacion">Colegio / Universidad</option><option value="otro">Otro</option></select></div><div class="form-group"><label>¿Cuántos guardias necesitas?</label><select name="cantidad_guardias"><option value="">Selecciona</option><option value="1-2">1-2</option><option value="3-5">3-5</option><option value="6-10">6-10</option><option value="10+">10+</option><option value="no-seguro">No estoy seguro</option></select></div></div>
        <div class="form-group"><label>Describe tu necesidad de seguridad</label><textarea name="mensaje" placeholder="Ej: Necesito 2 guardias para turno nocturno en un condominio en Las Condes..."></textarea></div>
        <div class="form-submit"><button type="submit" class="btn btn-primary">Solicitar Cotización</button></div>
      </form>
    </div>
  </div>
</section>

<div class="whatsapp-cta" data-od-id="whatsapp">
  <div class="container">
    <p style="font-size:16px;color:var(--muted);margin-bottom:16px">¿Prefieres enviar un WhatsApp?</p>
    <a href="https://wa.me/56930000010" class="btn btn-outline btn-lg" style="color:#25D366;border-color:#25D366" onmouseover="this.style.background='#25D366';this.style.color='#fff'" onmouseout="this.style.background='transparent';this.style.color='#25D366'">Escribir por WhatsApp</a>
  </div>
</div>
</main>`;
