export const PRIVACIDAD_HTML = `<main data-od-id="contenido">
  <h1>Política de Privacidad</h1>
  <div class="policy-section">
    <h2>1. Introducción</h2>
    <p>En GuardMan Seguridad Privada SpA (en adelante "GuardMan Chile"), valoramos y respetamos la privacidad de nuestros usuarios. Esta Política de Privacidad describe cómo recopilamos, utilizamos, almacenamos y protegemos su información personal cuando visita nuestro sitio web guardman.cl o utiliza nuestros servicios de seguridad privada.</p>
    <p>Al utilizar nuestro sitio web o contratar nuestros servicios, usted acepta las prácticas descritas en esta política.</p>
  </div>
  <div class="policy-section">
    <h2>2. Información que recopilamos</h2>
    <p>Podemos recopilar los siguientes tipos de información:</p>
    <ul><li><strong>Información de contacto:</strong> nombre, correo electrónico, número de teléfono, dirección.</li><li><strong>Información comercial:</strong> empresa, cargo, tipo de propiedad, necesidades de seguridad.</li><li><strong>Información técnica:</strong> dirección IP, tipo de navegador, páginas visitadas, tiempo de navegación.</li><li><strong>Información de cotización:</strong> detalles específicos sobre los servicios de seguridad solicitados.</li></ul>
  </div>
  <div class="policy-section">
    <h2>3. Cómo utilizamos su información</h2>
    <ul><li>Procesar y responder a sus solicitudes de cotización y contacto.</li><li>Prestar y mejorar nuestros servicios de seguridad privada.</li><li>Enviar comunicaciones relacionadas con los servicios contratados.</li><li>Cumplir con obligaciones legales y regulatorias aplicables en Chile.</li><li>Mejorar la experiencia de usuario en nuestro sitio web.</li></ul>
  </div>
  <div class="policy-section">
    <h2>4. Protección de datos</h2>
    <p>Implementamos medidas técnicas y organizativas para proteger su información personal contra acceso no autorizado, alteración, divulgación o destrucción. Estas medidas incluyen encriptación de datos, firewalls, y políticas de acceso restringido para nuestro personal.</p>
  </div>
  <div class="policy-section">
    <h2>5. Compartición de información</h2>
    <p>GuardMan Chile no vende, alquila ni comercializa su información personal. Solamente compartimos información en los siguientes casos:</p>
    <ul><li>Con proveedores de servicios que nos asisten en nuestras operaciones (bajo acuerdos de confidencialidad).</li><li>Cuando sea requerido por ley o por orden de autoridad competente.</li><li>Para proteger los derechos, propiedad o seguridad de GuardMan Chile, nuestros clientes o el público.</li></ul>
  </div>
  <div class="policy-section">
    <h2>6. Cookies</h2>
    <p>Utilizamos cookies y tecnologías similares para mejorar la navegación, analizar el tráfico y personalizar el contenido. Usted puede configurar su navegador para rechazar cookies, aunque esto podría afectar la funcionalidad del sitio.</p>
  </div>
  <div class="policy-section">
    <h2>7. Sus derechos</h2>
    <p>De acuerdo con la Ley 19.628 sobre Protección de la Vida Privada en Chile, usted tiene derecho a:</p>
    <ul><li>Acceder a sus datos personales.</li><li>Solicitar la corrección de datos inexactos.</li><li>Solicitar la eliminación de sus datos cuando corresponda.</li><li>Oponerse al tratamiento de sus datos para fines de marketing.</li></ul>
    <p>Para ejercer estos derechos, contáctenos a <a href="mailto:info@guardman.cl">info@guardman.cl</a>.</p>
  </div>
  <div class="policy-section">
    <h2>8. Contacto</h2>
    <p>Si tiene preguntas sobre esta Política de Privacidad, contáctenos:</p>
    <p>GuardMan Seguridad Privada SpA<br>Av. Américo Vespucio Norte 1980, Providencia<br>Santiago, Chile<br>Email: <a href="mailto:info@guardman.cl">info@guardman.cl</a><br>Teléfono: <a href="tel:+56930000010">+56 9 300 000 10</a></p>
  </div>
  <p class="last-updated">Última actualización: enero 2025</p>
</main>`;
