// GuardMan v3.0 — Site SSR Components
// Sistema de componentes reutilizables. Cada sección es una función pura.
// El layout base es siempre el mismo. Las páginas definen qué secciones incluir.

export const CSS_V = '1778255342';
// SITE_URL se resuelve en runtime desde env.WORKER_BASE_URL (ver setSiteUrl en index.ts)
// Usamos let para live bindings — los imports ven el valor actualizado tras setSiteUrl()
export let SITE_URL = 'https://guardman.oficinadesarrollo33.workers.dev';
export function setSiteUrl(url: string): void { SITE_URL = url; }
export function getSiteUrl(): string { return SITE_URL; }

// Critical CSS inlineado para first paint instantáneo (~2.5KB)
export const CRITICAL_CSS = `<style>:root{--primary:#1A2744;--primary-light:#1A3A5C;--primary-lighter:#5F7A96;--primary-pale:#E8ECF1;--primary-dark:#0F1829;--fg:#0D0D0D;--muted:#6C757D;--muted-light:#ADB5BD;--border:#E5E7EB;--bg:#F8F9FA;--surface:#FFFFFF;--accent:#3B82F6;--accent-hover:#2563EB;--success:#10B981;--warning:#F59E0B;--error:#EF4444;--radius-sm:4px;--radius-md:8px;--radius-lg:12px;--radius-xl:16px;--radius-2xl:24px;--radius-full:9999px;--font:'Inter',system-ui,-apple-system,sans-serif;--shadow-sm:0 1px 2px rgba(0,0,0,.05);--shadow-md:0 4px 6px -1px rgba(0,0,0,.1);--shadow-lg:0 10px 15px -3px rgba(0,0,0,.1);--shadow-xl:0 20px 25px -5px rgba(0,0,0,.1);--ease:cubic-bezier(0.4,0,0.2,1)}*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}html{scroll-behavior:smooth}img{max-width:100%;display:block}a{color:inherit;text-decoration:none}body{font-family:var(--font);color:var(--fg);background:var(--bg);line-height:1.5;-webkit-font-smoothing:antialiased}.container{max-width:1280px;margin:0 auto;padding:0 16px}.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:10px 20px;font-size:15px;font-weight:600;border-radius:var(--radius-lg);transition:all .2s;border:2px solid transparent;cursor:pointer;font-family:var(--font);white-space:nowrap}.btn-primary{background:var(--primary);color:#fff}.btn-outline-light{background:transparent;color:#fff;border-color:rgba(255,255,255,.25)}.btn-outline{background:transparent;color:var(--primary);border-color:var(--primary)}.btn-lg{padding:14px 28px;font-size:16px}header.site-header{position:sticky;top:0;z-index:50;background:var(--surface);box-shadow:var(--shadow-sm)}.header-inner{display:flex;align-items:center;justify-content:space-between;height:64px;max-width:1280px;margin:0 auto;padding:0 16px}.logo{display:flex;align-items:center;gap:8px}.logo-mark{width:40px;height:40px;background:var(--primary);border-radius:var(--radius-lg);display:flex;align-items:center;justify-content:center}.logo-mark svg{width:24px;height:24px;color:#fff}.logo-text{font-size:20px;font-weight:700;color:var(--primary)}nav{display:none;align-items:center;gap:32px}section{padding:80px 0}.section-label{display:inline-flex;align-items:center;gap:6px;font-size:13px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:var(--accent);margin-bottom:8px}.section-title{font-size:clamp(28px,4vw,40px);font-weight:800;color:var(--fg);line-height:1.15;margin-bottom:12px;letter-spacing:-0.015em}.section-subtitle{font-size:18px;color:var(--muted);max-width:600px;line-height:1.5}.hero{background:var(--primary);padding:64px 0;position:relative;overflow:hidden}.hero .container{position:relative;z-index:2}.hero h1{font-size:clamp(28px,4.5vw,48px);font-weight:800;color:#fff;line-height:1.1;margin-bottom:16px;max-width:650px}.hero p{font-size:clamp(15px,1.8vw,18px);color:rgba(255,255,255,.7);line-height:1.6;margin-bottom:28px;max-width:540px}.hero-ctas{display:flex;gap:12px;flex-wrap:wrap}.hero-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.15);padding:6px 14px;border-radius:var(--radius-full);font-size:13px;font-weight:600;color:rgba(255,255,255,.9);margin-bottom:20px}.hero-bg{position:absolute;inset:0;z-index:0}.hero-bg img{width:100%;height:100%;object-fit:cover;opacity:.3}.hero-bg-overlay{position:absolute;inset:0;background:linear-gradient(to right,var(--primary-dark),transparent 60%)}.card-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:24px}.card{border-radius:var(--radius-xl);overflow:hidden;background:var(--surface);border:1px solid var(--border)}.card-body{padding:20px}.card-body h3{font-size:18px;font-weight:700;margin-bottom:8px}.card-link{font-size:13px;font-weight:600;color:var(--accent);display:inline-flex;align-items:center;gap:4px}.footer-grid{display:grid;grid-template-columns:1fr;gap:40px}@media(min-width:1024px){.header-inner{height:80px}nav{display:flex}.hero{padding:80px 0}.footer-grid{grid-template-columns:2fr 1fr 1fr 1fr}}@media(max-width:767px){section{padding:56px 0}.card-grid{grid-template-columns:1fr}}.clients-carousel{overflow:hidden;padding:32px 0 24px}.clients-track{display:flex;gap:20px;animation:scroll-clients 30s linear infinite;width:max-content}.clients-track:hover{animation-play-state:paused}.client-card{flex-shrink:0;width:190px;background:var(--surface);border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-sm);transition:transform .2s}.client-card:hover{transform:translateY(-4px)}.client-card-img{height:80px;display:flex;align-items:center;justify-content:center}.client-initials{font-size:24px;font-weight:800;color:#fff;letter-spacing:1px}.client-card-body{padding:12px 14px;text-align:center}.sector-tag{display:inline-block;font-size:12px;font-weight:600;padding:4px 12px;border-radius:var(--radius-full);border:1px solid}@keyframes scroll-clients{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}</style>`;

// OG tags base compartidos (og:type, og:site_name, og:locale)
export const OG_BASE = `<meta property="og:type" content="website"><meta property="og:site_name" content="GuardMan Chile"><meta property="og:locale" content="es_CL">`;

export interface SiteData {
  title: string; description: string; canonical: string; ogImage?: string;
  pageType: string;
  heroHeading: string; heroSubheading?: string; heroImage?: string;
  heroBadge?: string; heroBadges?: string[];
  heroCtas?: Array<{ text: string; href: string; variant: string }>;
  heroTag?: { label: string; colorClass: string };
  zoneDot?: string; zoneLabel?: string;
  headerVariant?: 'light' | 'dark';
  breadcrumbs: Array<{ label: string; href?: string }>;
  sections: SectionData[];
  sidebarCtaHeading?: string;
  sidebarLinks?: Array<{ label: string; href: string }>;
  sidebarLinksTitle?: string;
  sidebarTags?: Array<{ label: string; colorClass: string; href?: string }>;
  sidebarTagsTitle?: string;
  relatedItems?: Array<{ title: string; description?: string; href: string }>;
  ctaHeading?: string; ctaSubheading?: string;
  ctaButtonText?: string; ctaButtonHref?: string;
  schemas?: Array<Record<string, any>>;
  sectorGlow?: string;
  extraHead?: string;
  // Dynamic header data from D1
  navServices?: Array<{ slug: string; name: string }>;
  navLocations?: Array<{ slug: string; name: string }>;
  navSectors?: Array<{ slug: string; name: string }>;
  // Homepage
  homeNosotrosParagraph?: string; homeNosotrosFeatures?: Array<{title:string;description:string}>;
  homeNosotrosImage?: string;
  homeNosotrosBadge?: string;
  homeNosotrosTitle?: string;
  homeServiciosBadge?: string;
  homeServiciosTitle?: string;
  homeServiciosSubtitle?: string;
  homeServices?: Array<{slug:string;name:string;description:string;image:string}>;
  homeGuardPodBadge?: string;
  homeGuardPodTitle?: string;
  homeGuardPodParagraph?: string;
  homeGuardPodCtaText?: string;
  homeGuardPodCtaLink?: string;
  homeGuardPodFeatures?: Array<{title:string;description:string}>;
  homeGuardPodImage?: string;
  homeSectoresBadge?: string;
  homeSectoresTitle?: string;
  homeSectoresSubtitle?: string;
  homeSectors?: Array<{slug:string;name:string;colorClass:string}>;
  homeAjaxBadge?: string;
  homeAjaxTitle?: string;
  homeAjaxParagraph?: string;
  homeAjaxCtaText?: string;
  homeAjaxCtaLink?: string;
  homeAjaxFeatures?: Array<{title:string;description:string}>;
  homeAjaxImage?: string;
  homeClientesTitle?: string;
  homeClientesSubtitle?: string;
  homeClientesCtaText?: string;
  homeClientesCtaLink?: string;
  homeClientesItems?: Array<{name:string;initials:string;color:string;image?:string}>;
  homeClientLogos?: Array<{name:string;logo_url:string;link?:string}>;
  homeUbicacionesBadge?: string;
  homeUbicacionesTitle?: string;
  homeUbicacionesSubtitle?: string;
  homeUbicacionesCtaText?: string;
  homeUbicacionesCtaLink?: string;
  homeUbicacionesZonesTitle?: string;
  homeUbicacionesZonesSubtitle?: string;
  homeZones?: Array<{name:string;dotClass:string;locations:Array<{slug:string;name:string;lat?:number;lng?:number}>}>;
  homeCtaFinalBadge?: string;
  homeCtaFinalTitle?: string;
  homeCtaFinalSubtitle?: string;
  homeCtaFinalCta1Text?: string;
  homeCtaFinalCta1Link?: string;
  homeCtaFinalCta2Text?: string;
  homeCtaFinalCta2Link?: string;
  // Legacy
  introHeading?: string; introParagraphs?: string[]; featuresTitle?: string; features?: string[];
  issues?: string[]; staffImage?: string; staffTraits?: string[];
  locations?: Array<{slug:string;name:string}>; faqs?: Array<{question:string;answer:string}>;
}

// Cada sección del article-body es uno de estos tipos:
export type SectionData =
  | { type: 'intro'; heading?: string; paragraphs: string[] }
  | { type: 'features'; heading?: string; items: string[] }
  | { type: 'issues'; heading?: string; items: string[] }
  | { type: 'staff'; heading?: string; subheading?: string; image?: string; traits: string[] }
  | { type: 'locations'; heading?: string; items: Array<{ slug: string; name: string; href?: string }>; comboBase?: string }
  | { type: 'faq'; heading?: string; items: Array<{ question: string; answer: string }> }
  | { type: 'html'; html: string };

export function esc(s: string | undefined | null): string {
  if (!s) return '';
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
// ─── YouTube Lite Embed Helper (SSR) ───
// Detects yt:VIDEO_ID references and renders clickable thumbnail
// Iframe only loads on user click → saves ~800KB per video for PageSpeed
function renderMedia(src: string | undefined | null, alt: string, cssClass: string = ''): string {
  if (!src) return '';
  const ytMatch = src.match(/^yt:([a-zA-Z0-9_-]{11})$/);
  if (ytMatch) {
    const videoId = ytMatch[1];
    const poster = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    const maxresPoster = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
    return `<div class="yt-lite ${cssClass}" data-yt="${videoId}" role="button" tabindex="0" aria-label="Reproducir video" style="position:relative;aspect-ratio:16/9;background:#000;border-radius:var(--radius-lg);overflow:hidden;cursor:pointer"><img src="${poster}" alt="${esc(alt)}" loading="lazy" style="width:100%;height:100%;object-fit:cover" onerror="this.src='${maxresPoster}';this.onerror=null"><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.15)"><div style="width:68px;height:48px;background:rgba(0,0,0,.7);border-radius:12px;display:flex;align-items:center;justify-content:center;transition:transform .15s"><svg width="24" height="24" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg></div></div><span style="position:absolute;top:8px;left:8px;font-size:11px;padding:2px 6px;background:rgba(0,0,0,.6);color:#fff;border-radius:4px;font-weight:600">YouTube</span></div>`;
  }
  return `<img src="${esc(src)}" alt="${esc(alt)}" ${cssClass || 'loading="lazy"'}>`;
}

// ─── YouTube Lite Activation Script (injected once per page) ───
const YT_LITE_SCRIPT = `<script>(function(){document.addEventListener('click',function(e){var el=e.target.closest('.yt-lite');if(!el||el.querySelector('iframe'))return;var id=el.getAttribute('data-yt');if(!id)return;var iframe=document.createElement('iframe');iframe.src='https://www.youtube.com/embed/'+id+'?autoplay=1&rel=0';iframe.style.cssText='position:absolute;inset:0;width:100%;height:100%;border:0;z-index:2';iframe.allow='accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture;web-share';iframe.allowFullscreen=true;iframe.title='YouTube video';el.appendChild(iframe);el.style.cursor='default';var imgs=el.querySelectorAll('img');for(var i=0;i<imgs.length;i++)imgs[i].style.opacity='0';var divs=el.querySelectorAll(':scope > div');for(var i=0;i<divs.length;i++)divs[i].style.display='none';var spans=el.querySelectorAll(':scope > span');for(var i=0;i<spans.length;i++)spans[i].style.display='none'});})();<\/script>`;

function jsonld(s: Record<string, any>): string { return `<script type="application/ld+json">${JSON.stringify(s)}</script>`; }

// ═══════════════ ICONS ═══════════════
const I = {
  shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>`,
  warn: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  phone: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>`,
  wifi: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="20" r="1"/></svg>`,
  monitor: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`,
  device: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>`,
  doc: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`,
  clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  eye: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
};

// Service card icons (matching Open Design)
const SERVICE_ICONS: Record<string, string> = {
  'guardias-de-seguridad': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/></svg>`,
  'cctv-videovigilancia': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  'control-de-accesos': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
  'escoltas-privados': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
  'monitoreo-24-7': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/></svg>`,
  'seguridad-eventos': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/></svg>`,
  'seguridad-industrial': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/></svg>`,
  'auditoria-seguridad': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  'guard-pod': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
};

// ═══════════════ LAYOUT COMPONENTS (siempre iguales) ═══════════════

export function hdr(v: 'light'|'dark', navData?: { services?: Array<{slug:string;name:string}>; locations?: Array<{slug:string;name:string}>; sectors?: Array<{slug:string;name:string}> }): string {
  const d = v==='dark'?' header-dark':'';
  const services = navData?.services || [
    {slug:'guardias-de-seguridad',name:'Guardias de Seguridad'},{slug:'cctv-videovigilancia',name:'CCTV Videovigilancia'},{slug:'control-de-accesos',name:'Control de Accesos'},
    {slug:'escoltas-privados',name:'Escoltas Privados'},{slug:'monitoreo-24-7',name:'Monitoreo 24/7'},{slug:'seguridad-eventos',name:'Seguridad Eventos'},
    {slug:'seguridad-industrial',name:'Seguridad Industrial'},{slug:'auditoria-seguridad',name:'Auditoría de Seguridad'},{slug:'guard-pod',name:'Guard Pod'}
  ];
  const locations = navData?.locations || [
    {slug:'las-condes',name:'Las Condes'},{slug:'vitacura',name:'Vitacura'},{slug:'lo-barnechea',name:'Lo Barnechea'},{slug:'santiago-centro',name:'Santiago Centro'},
    {slug:'huechuraba',name:'Huechuraba'},{slug:'quilicura',name:'Quilicura'},{slug:'la-reina',name:'La Reina'},{slug:'conchali',name:'Conchalí'},
    {slug:'pudahuel',name:'Pudahuel'},{slug:'renca',name:'Renca'},{slug:'lampa',name:'Lampa'},{slug:'la-pintana',name:'La Pintana'},
    {slug:'los-andes',name:'Los Andes'},{slug:'san-felipe',name:'San Felipe'}
  ];
  const sectors = navData?.sectors || [
    {slug:'comercial',name:'Comercial'},{slug:'industrial',name:'Industrial'},{slug:'residencial',name:'Residencial'},
    {slug:'salud',name:'Salud'},{slug:'educacion',name:'Educación'},{slug:'eventos',name:'Eventos'},{slug:'construccion',name:'Construcción'}
  ];
  return `<header class="site-header${d}" data-od-id="header"><div class="header-inner"><a href="/" class="logo"><div class="logo-mark">${I.shield}</div><span class="logo-text">GuardMan</span></a><nav id="nav-links"><div class="dropdown"><button class="dropdown-btn">Servicios <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg></button><div class="dropdown-menu">${services.map(s=>`<a href="/servicios/${esc(s.slug)}">${esc(s.name)}</a>`).join('')}</div></div><div class="dropdown"><button class="dropdown-btn">Ubicaciones <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg></button><div class="dropdown-menu">${locations.map(l=>`<a href="/ubicaciones/${esc(l.slug)}">${esc(l.name)}</a>`).join('')}</div></div><div class="dropdown"><button class="dropdown-btn">Sectores <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg></button><div class="dropdown-menu">${sectors.map(s=>`<a href="/sectores/${esc(s.slug)}">${esc(s.name)}</a>`).join('')}</div></div><a href="/nosotros" class="nav-link">Nosotros</a></nav><div class="header-actions"><a href="tel:+56930000010" class="header-phone">${I.phone} +56 9 300 000 10</a><a href="/cotizacion" class="btn btn-primary">Cotizar</a></div><button id="mobile-toggle" class="mobile-toggle" aria-label="Menú" aria-expanded="false">☰</button></div></header>`;
}

function brd(items: Array<{label:string;href?:string}>): string {
  if(!items.length) return '';
  return `<nav class="breadcrumb" data-od-id="breadcrumb"><div class="breadcrumb-inner">${items.map((i,j)=>j===items.length-1||!i.href?`<span>${esc(i.label)}</span>`:`<a href="${esc(i.href)}">${esc(i.label)}</a><span class="breadcrumb-sep">/</span>`).join('')}</div></nav>`;
}

export function ftr(): string {
  return `<footer class="site-footer" data-od-id="footer"><div class="container"><div class="footer-grid"><div class="footer-col footer-brand"><div style="display:flex;align-items:center;gap:8px;margin-bottom:12px"><div class="logo-mark">${I.shield}</div><span class="logo-text" style="color:#fff">GuardMan</span></div><p>Empresa de seguridad privada con certificación OS-10. Protegemos lo que más te importa.</p><div class="footer-social"><a href="https://www.instagram.com/grupo_guardman" target="_blank" rel="noopener" aria-label="Instagram"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a><a href="https://youtu.be/mqpLsKrwjAI" target="_blank" rel="noopener" aria-label="YouTube"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18"><path d="M22.54 6.42a2.78 2.78 0 00-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 00-1.94 2A29.94 29.94 0 001 11.75a29.94 29.94 0 00.46 5.33A2.78 2.78 0 003.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 001.94-2 29.94 29.94 0 00.46-5.25 29.94 29.94 0 00-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg></a></div></div><div class="footer-col"><h4>Servicios</h4><a href="/servicios/guardias-de-seguridad">Guardias de Seguridad</a><a href="/servicios/cctv-videovigilancia">CCTV Videovigilancia</a><a href="/servicios/control-de-accesos">Control de Accesos</a><a href="/servicios/escoltas-privados">Escoltas Privados</a><a href="/servicios/monitoreo-24-7">Monitoreo 24/7</a><a href="/servicios">Ver todos →</a></div><div class="footer-col"><h4>Empresa</h4><a href="/nosotros">Nosotros</a><a href="/guard-pod">Guard Pod</a><a href="/ajax-systems">Ajax Systems</a><a href="/sectores">Sectores</a><a href="/ubicaciones">Cobertura</a></div><div class="footer-col"><h4>Contacto</h4><a href="tel:+56930000010">📞 +56 9 300 000 10</a><a href="mailto:info@guardman.cl">📧 info@guardman.cl</a><a href="/contacto">Formulario de contacto</a><a href="/cotizacion">Solicitar cotización</a></div></div><div class="footer-bottom"><span>© ${new Date().getFullYear()} GuardMan Chile. RUT 77.123.456-7</span><span>Av. Américo Vespucio Norte 1980, Providencia, Santiago</span></div></div></footer>${YT_LITE_SCRIPT}`;
}

// ═══════════════ HERO ═══════════════

function hero(d: SiteData): string {
  const heroImg = d.heroImage || '/images/hero-home.webp';
  const isYt = heroImg.startsWith('yt:');
  const heroBg = isYt
    ? `<div class="hero-bg" style="aspect-ratio:16/9;background:transparent">${renderMedia(heroImg, d.heroHeading, '')}</div>`
    : `<div class="hero-bg"><img src="${esc(heroImg)}" alt="${esc(d.heroHeading)}" loading="eager" onerror="this.style.display='none'"><div class="hero-bg-overlay"></div></div>`;
  return `<section class="hero" data-od-id="hero">
  ${heroBg}
  <div class="container">
    ${d.heroTag?`<div class="hero-tag ${esc(d.heroTag.colorClass)}">${esc(d.heroTag.label)}</div>`:''}
    ${d.heroBadge?`<div class="hero-badge">${I.shield} ${esc(d.heroBadge)}</div>`:''}
    ${d.heroBadges?`<div class="hero-badges">${d.heroBadges.map(b=>`<span class="hero-badge">${esc(b)}</span>`).join('')}</div>`:''}
    ${d.zoneDot?`<div style="display:flex;align-items:center;gap:6px;margin-bottom:12px"><span class="zone-dot dot-${esc(d.zoneDot)}"></span><span style="color:rgba(255,255,255,.7);font-size:13px;font-weight:600">${esc(d.zoneLabel||'')}</span></div>`:''}
    <h1>${esc(d.heroHeading)}</h1>
    ${d.heroSubheading?`<p>${esc(d.heroSubheading)}</p>`:''}
    ${d.heroCtas?`<div class="hero-ctas">${d.heroCtas.map(c=>`<a href="${esc(c.href)}" class="btn btn-outline-light btn-lg">${esc(c.text)}</a>`).join('')}</div>`:''}
  </div>
</section>`;
}

// ═══════════════ ARTICLE SECTIONS (reutilizables, se mezclan según página) ═══════════════

function secIntro(s: Extract<SectionData,{type:'intro'}>): string {
  return `<div class="block" data-od-id="block-intro">
  ${s.heading?`<h2>${esc(s.heading)}</h2>`:''}
  ${s.paragraphs.map(p=>`<p>${esc(p)}</p>`).join('\n')}
</div>`;
}

function secFeatures(s: Extract<SectionData,{type:'features'}>): string {
  return `<div class="block" data-od-id="block-features">
  <h2>${esc(s.heading||'¿Qué incluye nuestro servicio?')}</h2>
  <div class="features-grid">
    ${s.items.map(i=>`<div class="feature-item">${I.check}<span>${esc(i)}</span></div>`).join('\n')}
  </div>
</div>`;
}

function secIssues(s: Extract<SectionData,{type:'issues'}>): string {
  return `<div class="block" data-od-id="block-issues">
  <h2>${esc(s.heading||'Problemas que Resolvemos')}</h2>
  <div class="issues-grid">
    ${s.items.map(i=>`<div class="issue-card">${I.warn}<span>${esc(i)}</span></div>`).join('\n')}
  </div>
</div>`;
}

function secStaff(s: Extract<SectionData,{type:'staff'}>): string {
  return `<div class="block" data-od-id="block-staff">
  <div class="staff-block">
    <div class="staff-block-inner">
      <div class="staff-image"><img src="${esc(s.image||'/images/nosotros_seccion.webp')}" alt="Personal GuardMan Chile" loading="lazy"><div class="staff-image-overlay"></div></div>
      <div class="staff-content">
        <h2>${esc(s.heading||'Personal que marca la diferencia')}</h2>
        <p>${esc(s.subheading||'Nuestros guardias son la base de la confianza que nuestros clientes depositan en nosotros.')}</p>
        ${s.traits.map(t=>`<div class="staff-trait">${I.check}${esc(t)}</div>`).join('\n')}
      </div>
    </div>
  </div>
</div>`;
}

function secLocations(s: Extract<SectionData,{type:'locations'}>): string {
  const getHref = (l: any) => l.href || (s.comboBase ? `/${esc(s.comboBase)}/${esc(l.slug)}` : `/ubicaciones/${esc(l.slug)}`);
  const isServiceGrid = s.items.some((l:any) => l.href);
  return `<div class="block" data-od-id="block-locations">
  <h2>${esc(s.heading||`Disponible en ${s.items.length} ubicaciones`)}</h2>
  <p style="font-size:14px;color:var(--muted);margin-bottom:16px">${isServiceGrid ? 'Servicios profesionales con certificación OS-10 disponibles en esta comuna.' : 'Selecciona tu comuna para ver detalles y solicitar cotización.'}</p>
  <div class="${isServiceGrid ? 'service-grid' : 'locations-grid'}">
    ${s.items.map(l=>`<a href="${getHref(l)}" class="${isServiceGrid ? 'service-link' : 'loc-link'}">${esc(l.name)}</a>`).join('\n')}
  </div>
  <a href="/ubicaciones" style="display:inline-flex;align-items:center;gap:6px;color:var(--accent);font-weight:600;font-size:14px;margin-top:16px">Explorar mapa de cobertura →</a>
</div>`;
}

function secFAQ(s: Extract<SectionData,{type:'faq'}>): string {
  return `<div class="block" data-od-id="block-faq">
  <h2>${esc(s.heading||'Preguntas frecuentes')}</h2>
  <div class="faq">
    ${s.items.map((f,i)=>`<details${i===0?' open':''}><summary>${esc(f.question)}</summary><div class="answer">${esc(f.answer)}</div></details>`).join('\n')}
  </div>
</div>`;
}

function secHTML(s: Extract<SectionData,{type:'html'}>): string {
  return s.html;
}

function renderSection(s: SectionData): string {
  switch(s.type) {
    case 'intro': return secIntro(s);
    case 'features': return secFeatures(s);
    case 'issues': return secIssues(s);
    case 'staff': return secStaff(s);
    case 'locations': return secLocations(s);
    case 'faq': return secFAQ(s);
    case 'html': return secHTML(s);
  }
}

// ═══════════════ SIDEBAR ═══════════════

function sidebar(d: SiteData): string {
  if(!d.sidebarLinks?.length && !d.sidebarTags?.length) return '';
  return `<aside data-od-id="sidebar">
  <div class="sidebar-sticky">
    <div class="sidebar-cta-top">
      <h3>${esc(d.sidebarCtaHeading||'¿Necesitas seguridad?')}</h3>
      <a href="/cotizacion" class="btn btn-primary">Cotizar ahora</a>
      <a href="/contacto" class="btn btn-outline">Hablar con experto</a>
    </div>
    <div class="sidebar-body">
      ${d.sidebarLinks?.length?`<div class="sb-section"><h4>${esc(d.sidebarLinksTitle||'Otros servicios')}</h4>${d.sidebarLinks.map(l=>`<a href="${esc(l.href)}" class="sb-link">${esc(l.label)}</a>`).join('\n')}</div>`:''}
      ${d.sidebarTags?.length?`<div class="sb-section"><h4>${esc(d.sidebarTagsTitle||'Sectores que atiende')}</h4><div class="sb-tags">${d.sidebarTags.map(t=>`<a href="${esc(t.href||'#')}" class="sb-tag sb-tag-${esc(t.colorClass)}">${esc(t.label)}</a>`).join('\n')}</div></div>`:''}
    </div>
  </div>
</aside>`;
}

// ═══════════════ MAP RENDERER (Leaflet) ═══════════════

function renderMap(d: SiteData): string {
  if (!d.mapEnabled) return '';
  const id = `map-${d.pageType||'generic'}`;
  const lat = d.mapLat || -33.45;
  const lng = d.mapLng || -70.65;
  const zoom = d.mapZoom || 12;
  let markersJs = '';
  if (d.mapMarkers?.length) {
    markersJs = `var markers=[${d.mapMarkers.map(m=>`{name:${JSON.stringify(m.name)},lat:${m.lat},lng:${m.lng},color:${JSON.stringify(m.color)},slug:${JSON.stringify(m.slug||'')}}`).join(',')}];
for(var i=0;i<markers.length;i++){var m=markers[i];L.circleMarker([m.lat,m.lng],{radius:8,fillColor:m.color,color:'#fff',weight:2,fillOpacity:.9}).addTo(map).bindPopup('<strong>'+m.name+'</strong><br><a href="/ubicaciones/'+m.slug+'" style="font-size:13px;font-weight:600;text-decoration:underline;color:var(--accent)">Ver cobertura &rarr;</a>');}`;
  } else {
    markersJs = `L.circleMarker([${lat},${lng}],{radius:10,fillColor:'#3B82F6',color:'#fff',weight:2,fillOpacity:.9}).addTo(map).bindPopup('<strong>GuardMan Chile</strong>').openPopup();`;
  }
  return `
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
<section class="bg-neutral" data-od-id="block-map">
  <div class="container">
    <h2 class="section-title" style="margin-bottom:8px">Mapa de cobertura</h2>
    <p class="section-subtitle" style="margin-bottom:32px">Presencia operativa verificada en 14 comunas de la Región Metropolitana más Los Andes y San Felipe.</p>
    <figure class="coverage-map">
      <div id="${id}" style="height:420px;border-radius:var(--radius-xl);border:1px solid var(--border)" data-lat="${lat}" data-lng="${lng}" data-zoom="${zoom}"></div>
      <figcaption style="font-size:13px;color:var(--muted);margin-top:8px">GuardMan Chile — cobertura verificada en <strong>14 comunas</strong> de la Región Metropolitana.</figcaption>
    </figure>
  </div>
</section>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>(function(){var d=document.getElementById('${id}');if(!d||typeof L==='undefined')return;var map=L.map(d,{center:[${lat},${lng}],zoom:${zoom},scrollWheelZoom:false,attributionControl:false});L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'}).addTo(map);${markersJs}})();</script>`;
}

// ═══════════════ RELATED + CTA ═══════════════

function related(d: SiteData): string {
  if(!d.relatedItems?.length) return '';
  return `<section class="related-section" data-od-id="block-related">
  <div class="container">
    <h2 style="font-size:24px;font-weight:700;margin-bottom:8px">También te puede interesar</h2>
    <div class="related-grid">
      ${d.relatedItems.map(r=>`<a href="${esc(r.href)}" class="related-card"><h3>${esc(r.title)}</h3>${r.description?`<p>${esc(r.description)}</p>`:''}<span class="related-link">Ver más →</span></a>`).join('\n')}
    </div>
  </div>
</section>`;
}

function cta(d: SiteData): string {
  if(!d.ctaHeading) return '';
  return `<div class="cta-band" data-od-id="block-cta">
  <div class="container">
    <h3>${esc(d.ctaHeading)}</h3>
    ${d.ctaSubheading?`<p>${esc(d.ctaSubheading)}</p>`:''}
    <a href="${esc(d.ctaButtonHref||'/cotizacion')}" class="btn btn-outline-light btn-lg">${esc(d.ctaButtonText||'Solicitar Cotización')}</a>
  </div>
</div>`;
}

// ═══════════════ PAGE BUILDERS ═══════════════

function buildSections(d: SiteData): SectionData[] {
  if (d.sections?.length) return d.sections;
  const s: SectionData[] = [];
  const data = d as any;
  const pt = d.pageType;
  
  if (data.introParagraphs?.length) s.push({ type: 'intro', heading: data.introHeading, paragraphs: data.introParagraphs });
  if (data.features?.length) s.push({ type: 'features', heading: data.featuresTitle, items: data.features });
  if (data.issues?.length) s.push({ type: 'issues', items: data.issues });
  if (data.staffTraits?.length) s.push({ type: 'staff', image: data.staffImage, traits: data.staffTraits });
  
  // Location page: show available services (combo links)
  if (pt === 'location' && data.locationServices?.length) {
    s.push({ type: 'locations', heading: `Servicios disponibles en esta comuna`, items: data.locationServices, comboBase: undefined });
  }
  // Sector page: show related services
  else if (pt === 'sector' && data.locations?.length) {
    s.push({ type: 'locations', heading: 'Cobertura en 14 comunas', items: data.locations });
  }
  // Service page: locations → combos
  else if (pt === 'service' && data.locations?.length) {
    s.push({ type: 'locations', heading: `Disponible en ${data.locations.length} ubicaciones`, items: data.locations, comboBase: `servicios/${data._serviceSlug || ''}` });
  }
  // Combo page: nearby locations for same service
  else if (pt === 'combo' && data.locations?.length) {
    s.push({ type: 'locations', heading: 'También disponible en otras comunas', items: data.locations, comboBase: `servicios/${data._serviceSlug || ''}` });
  }
  // Fallback: generic locations
  else if (data.locations?.length) {
    s.push({ type: 'locations', heading: `Disponible en ${data.locations.length} ubicaciones`, items: data.locations });
  }
  
  if (data.faqs?.length) s.push({ type: 'faq', items: data.faqs });
  return s;
}

export function buildDetailPage(d: SiteData): string {
  const sections = buildSections(d);
  const s = sections.map(renderSection).join('\n');
  const sb = sidebar(d);
  return `<!doctype html>
<html lang="es-CL">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(d.title)}</title>
<meta name="description" content="${esc(d.description)}">
<meta property="og:title" content="${esc(d.title)}">
<meta property="og:description" content="${esc(d.description)}">
<meta property="og:url" content="${SITE_URL}${esc(d.canonical)}">
${d.ogImage?`<meta property="og:image" content="${SITE_URL}${esc(d.ogImage)}">`:''}
<link rel="canonical" href="${SITE_URL}${esc(d.canonical)}">
<link rel="alternate" hreflang="es-CL" href="${SITE_URL}${esc(d.canonical)}">
${OG_BASE}
${CRITICAL_CSS}
<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg">
${d.sectorGlow||''}
${d.extraHead||''}
${d.schemas?.map(s=>jsonld(s)).join('\n')||''}
</head>
<body>
${hdr(d.headerVariant||'light')}
${brd(d.breadcrumbs)}
<main>
${hero(d)}
<section class="content-section bg-white" data-od-id="contenido">
  <div class="container">
    <div class="content-grid">
      <div class="article-body">${s}</div>
      ${sb}
    </div>
  </div>
</section>
${renderMap(d)}
${related(d)}
${cta(d)}
</main>
${ftr()}
<script src="/scripts/main.js"></script>
</body></html>`;
}

function buildHomeMapScript(zones: any[], ZC: Record<string,string>): string {
  const markers: string[] = [];
  for (const z of zones) {
    for (const l of (z.locations||[])) {
      if (l.lat && l.lng) {
        markers.push(`{name:${JSON.stringify(l.name)},lat:${l.lat},lng:${l.lng},color:${JSON.stringify(ZC[z.name]||'#3B82F6')},slug:${JSON.stringify(l.slug)}}`);
      }
    }
  }
  return `(function(){var d=document.getElementById('map-home');if(!d||typeof L==='undefined')return;var map=L.map(d,{center:[-33.45,-70.65],zoom:10,scrollWheelZoom:false,zoomControl:true,attributionControl:false});L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'&copy; OpenStreetMap'}).addTo(map);var markers=[${markers.join(',')}];var bounds=L.latLngBounds([]);for(var i=0;i<markers.length;i++){var m=markers[i];var mk=L.circleMarker([m.lat,m.lng],{radius:8,fillColor:m.color,color:'#fff',weight:2,fillOpacity:1}).addTo(map).bindPopup('<strong>'+m.name+'</strong><br><a href="/ubicaciones/'+m.slug+'" style="font-size:12px;font-weight:600;color:#3B82F6">Ver cobertura &rarr;</a>');bounds.extend([m.lat,m.lng]);}if(markers.length>0){map.fitBounds(bounds.pad(0.15));}})();`;
}

function buildClientesSection(d: SiteData): string {
  const data = d as any;
  const cmsClients = data.homeClientesItems || [];
  const title = data.homeClientesTitle || 'Empresas que confían en GuardMan';
  const subtitle = data.homeClientesSubtitle || 'Respaldados por empresas líderes en distintos sectores de Santiago.';
  const ctaText = data.homeClientesCtaText || 'Conoce nuestra trayectoria';
  const ctaLink = data.homeClientesCtaLink || '/nosotros';
  const defaults = [
    {name:'Avanzapark',initials:'AV',color:'#0F766E',image:''},{name:'Courtyard Marriott',initials:'CM',color:'#B8860B',image:''},
    {name:'Kavak',initials:'KV',color:'#DC2626',image:''},{name:'Workcenter',initials:'WC',color:'#4F46E5',image:''},
    {name:'Hamptons',initials:'HA',color:'#059669',image:''}
  ];
  const clients = cmsClients.length > 0 ? cmsClients : defaults;
  const cards = clients.map((c:any) => {
    const hex = c.color || '#3B82F6';
    const lighten = (h: string, amt: number): string => {
      const num = parseInt(h.replace('#',''), 16);
      const r = Math.min(255, (num >> 16) + amt);
      const g = Math.min(255, ((num >> 8) & 0xFF) + amt);
      const b = Math.min(255, (num & 0xFF) + amt);
      return '#' + ((r<<16)|(g<<8)|b).toString(16).padStart(6,'0');
    };
    const c1 = lighten(hex, 0);
    const c2 = lighten(hex, 20);
    const c3 = lighten(hex, 50);
    const borderC = lighten(hex, 80);
    const imgSrc = c.image || '';
    const imgHtml = imgSrc ? `<img src="${esc(imgSrc)}" alt="${esc(c.name)}" loading="lazy" style="width:100%;height:100%;object-fit:contain;padding:8px">` : `<span class="client-initials">${esc(c.initials)}</span>`;
    return `<div class="client-card"><div class="client-card-img" style="background:linear-gradient(135deg,${c1},${c2},${c3})">${imgHtml}</div><div class="client-card-body"><span class="sector-tag" style="color:${c1};border-color:${borderC};background:${lighten(borderC,30)}">${esc(c.name)}</span></div></div>`;
  }).join('');
  return `<div class="container"><span class="section-label">Clientes</span><h2 class="section-title" style="text-align:center;max-width:500px;margin:0 auto 8px">${esc(title)}</h2><p class="section-subtitle" style="text-align:center;margin:0 auto 8px">${esc(subtitle)}</p></div><div class="clients-carousel"><div class="clients-track">${cards}${cards}</div></div><div class="container" style="text-align:center"><a href="${esc(ctaLink)}" class="btn btn-outline">${esc(ctaText)}</a></div>`;
}

export function buildHomepage(d: SiteData): string {
  const data = d as any;
  const svcs = data.homeServices || [];
  const sects = data.homeSectors || [];
  const zones = data.homeZones || [];
  const ZC: Record<string,string> = {'Oriente':'red','Centro':'blue','Norte':'yellow','Sur':'blue','Poniente':'purple','Occidente':'purple','Valparaíso':'green'};
  return `<!doctype html>
<html lang="es-CL">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(d.title)}</title>
<meta name="description" content="${esc(d.description)}">
<meta property="og:title" content="${esc(d.title)}">
<meta property="og:description" content="${esc(d.description)}">
<link rel="canonical" href="${SITE_URL}${esc(d.canonical)}">
${OG_BASE}
${CRITICAL_CSS}
<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""><link rel="icon" type="image/svg+xml" href="/favicon.svg">
${d.schemas?.map(s=>jsonld(s)).join('\n')||''}
</head>
<body>
${hdr('light')}
<main>
${hero(d)}

<!-- Nosotros -->
<section class="bg-dark" data-od-id="nosotros" style="background:#0D0D0D">
  <div class="container split">
    <div class="split-content">
      <span class="section-label">${esc(d.homeNosotrosBadge || 'Grupo GuardMan Chile')}</span>
      <h2 class="section-title">${esc(d.homeNosotrosTitle || 'GuardMan Chile — Seguridad privada profesional en Santiago')}</h2>
      <p style="color:rgba(255,255,255,.95);font-size:16px;line-height:1.6;margin-bottom:24px">${esc(d.homeNosotrosParagraph||'Más de 8 años de experiencia protegiendo lo que más te importa.')}</p>
      <div class="feature-tiles">
        ${(d.homeNosotrosFeatures && d.homeNosotrosFeatures.length > 0
          ? d.homeNosotrosFeatures.map((f:any, i:number) => {
              const icons = [I.shield, I.doc, I.clock, I.eye];
              return `<div class="feature-tile"><div class="feature-tile-icon">${icons[i % icons.length]}</div><h4>${esc(f.title || f)}</h4><p>${esc(f.description || '')}</p></div>`;
            }).join('\n')
          : `<div class="feature-tile"><div class="feature-tile-icon">${I.shield}</div><h4>Guardias certificados OS-10</h4><p>Personal capacitado y certificado para máxima protección las 24 horas.</p></div>
          <div class="feature-tile"><div class="feature-tile-icon">${I.doc}</div><h4>Cumplimiento Ley 21.659</h4><p>Operamos dentro de todas las normativas legales vigentes en Chile.</p></div>
          <div class="feature-tile"><div class="feature-tile-icon">${I.clock}</div><h4>Atención 24/7 los 365 días</h4><p>Respuesta inmediata en cualquier momento del año sin excepciones.</p></div>
          <div class="feature-tile"><div class="feature-tile-icon">${I.eye}</div><h4>Centro de monitoreo propio</h4><p>Supervisión continua desde nuestras instalaciones, sin tercerizar.</p></div>`
        )}
      </div>
      <a href="/nosotros" style="display:inline-flex;align-items:center;gap:6px;color:var(--accent);font-weight:600;font-size:15px;margin-top:24px">Conoce más sobre nosotros <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></a>
    </div>
    <div class="split-image"${d.homeNosotrosImage?.startsWith('yt:') ? ' style="aspect-ratio:16/9;background:transparent;border:none;min-height:auto"' : ''}>${renderMedia(d.homeNosotrosImage||'/images/nosotros_seccion.webp', 'Equipo GuardMan')}<div class="split-image-badge">Conoce GuardMan</div></div>
  </div>
</section>

<!-- Servicios Grid -->
<section class="bg-white" data-od-id="servicios" style="padding:64px 0">
  <div class="container">
    <span class="section-label">${esc(d.homeServiciosBadge || 'Nuestros Servicios')}</span>
    <h2 class="section-title">${esc(d.homeServiciosTitle || 'Soluciones de seguridad para cada necesidad')}</h2>
    <p class="section-subtitle">${esc(d.homeServiciosSubtitle || 'Desde guardias de seguridad hasta tecnología de vigilancia avanzada, adaptamos nuestros servicios a las características de tu empresa o residencia.')}</p>
    <div class="card-grid" style="margin-top:40px">
      ${svcs.map((s:any)=>`<a href="/servicios/${esc(s.slug)}" class="card"><div class="card-image"><img src="${esc(s.image||'/images/hero-home.webp')}" alt="${esc(s.name)}" loading="lazy"></div><div class="card-body">${SERVICE_ICONS[s.slug] ? `<div class="card-icon">${SERVICE_ICONS[s.slug]}</div>` : ''}<h3>${esc(s.name)}</h3><p>${esc(s.description||'')}</p><span class="card-link">Ver servicio <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></span></div></a>`).join('\n')}
    </div>
  </div>
</section>

<!-- Guard Pod -->
<section class="bg-dark" data-od-id="guardpod">
  <div class="container split">
    <div>
      <span class="section-label">${esc(d.homeGuardPodBadge || 'Tecnología Propia GuardMan')}</span>
      <h2 class="section-title">${esc(d.homeGuardPodTitle || 'Guard Pod')}</h2>
      <p style="color:rgba(255,255,255,.95);font-size:16px;line-height:1.6;margin-bottom:24px">${esc(d.homeGuardPodParagraph || 'Vigilancia autónoma para obras, eventos y zonas sin infraestructura. Energía solar, cámaras PTZ y monitoreo remoto en una unidad desplegable en menos de 2 horas.')}</p>
      <div class="feature-tiles">
        ${(d.homeGuardPodFeatures||[]).map(f=>`<div class="feature-tile"><div class="feature-tile-icon">${I.shield}</div><h4>${esc((f as any).title)}</h4><p>${esc((f as any).description)}</p></div>`).join('\n')}
      </div>
      <a href="${esc(d.homeGuardPodCtaLink || '/guard-pod')}" style="display:inline-flex;align-items:center;gap:6px;color:var(--accent);font-weight:600;font-size:15px;margin-top:24px">${esc(d.homeGuardPodCtaText || 'Conocer Guard Pod')} <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></a>
    </div>
    <div class="split-image"${d.homeGuardPodImage?.startsWith('yt:') ? ' style="aspect-ratio:16/9;background:transparent;border:none;min-height:auto"' : ''}>${renderMedia(d.homeGuardPodImage||'/images/s4-thumbnail.webp', 'Guard Pod')}<div class="split-image-badge">15 meses de I+D</div></div>
  </div>
</section>

<!-- Sectores Grid -->
<section class="bg-neutral" data-od-id="sectores" style="padding:64px 0">
  <div class="container">
    <span class="section-label">${esc(d.homeSectoresBadge || 'Soluciones por sector')}</span>
    <h2 class="section-title">${esc(d.homeSectoresTitle || 'Soluciones por sector')}</h2>
    <p class="section-subtitle">${esc(d.homeSectoresSubtitle || 'Adaptamos nuestros servicios a las necesidades específicas de cada industria en Santiago.')}</p>
    <div class="card-grid" style="margin-top:40px">
      ${sects.map((s:any)=>`<a href="/sectores/${esc(s.slug)}" class="card"><div class="card-image"><img src="/images/sector-${esc(s.slug)}.webp" alt="${esc(s.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><div style="display:none;align-items:center;justify-content:center;width:100%;height:100%;background:var(--primary);color:#fff;font-size:1.2rem;font-weight:700;position:absolute;top:0;left:0">${esc(s.name)}</div><span class="card-tag tag ${esc(s.colorClass||'tag-blue')}">${esc(s.name)}</span></div><div class="card-body"><h3>Seguridad ${esc(s.name)}</h3><p>Protección especializada para el sector ${esc(s.name.toLowerCase())}.</p><span class="card-link">Ver sector <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></span></div></a>`).join('\n')}
    </div>
  </div>
</section>

<!-- Ajax Systems -->
<section class="bg-dark" data-od-id="ajax">
  <div class="container split">
    <div>
      <span class="section-label">${esc(d.homeAjaxBadge || 'Instalador Oficial Ajax Systems')}</span>
      <h2 class="section-title">${esc(d.homeAjaxTitle || 'Tecnología de clase mundial para tu seguridad')}</h2>
      <p style="color:rgba(255,255,255,.95);font-size:16px;line-height:1.6;margin-bottom:24px">${esc(d.homeAjaxParagraph || 'Somos instaladores oficiales de Ajax Systems, la empresa líder mundial en sistemas de alarmas inteligentes con más de 4.5 millones de usuarios protegidos en 187 países.')}</p>
      <div class="feature-tiles">
        ${(d.homeAjaxFeatures && d.homeAjaxFeatures.length > 0
          ? d.homeAjaxFeatures.map((f:any, i:number) => {
              const icons = [I.shield, I.wifi, I.monitor, I.device];
              return `<div class="feature-tile"><div class="feature-tile-icon">${icons[i % icons.length]}</div><h4>${esc(f.title || f)}</h4><p>${esc(f.description || '')}</p></div>`;
            }).join('\n')
          : `<div class="feature-tile"><div class="feature-tile-icon">${I.shield}</div><h4>Certificación Grade 3 Professional</h4><p>El máximo nivel internacional de seguridad. Probado contra sabotaje y suplantación.</p></div>
          <div class="feature-tile"><div class="feature-tile-icon">${I.wifi}</div><h4>Protocolo Jeweller</h4><p>Comunicación radio encriptada de hasta 2 km. Inmune a inhibidores de frecuencia.</p></div>
          <div class="feature-tile"><div class="feature-tile-icon">${I.monitor}</div><h4>Video Verificación 24/7</h4><p>Centro de monitoreo propio con verificación visual ante cada evento de alarma.</p></div>
          <div class="feature-tile"><div class="feature-tile-icon">${I.device}</div><h4>App Ajax — Control Total</h4><p>Armado, desarmado y visualización de cámaras en tiempo real desde iOS y Android.</p></div>`
        )}
      </div>
      <a href="${esc(d.homeAjaxCtaLink || '/ajax-systems')}" style="display:inline-flex;align-items:center;gap:6px;color:var(--accent);font-weight:600;font-size:15px;margin-top:24px">${esc(d.homeAjaxCtaText || 'Conocer Ajax Systems')} <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></a>
    </div>
    <div class="split-image"${d.homeAjaxImage?.startsWith('yt:') ? ' style="aspect-ratio:16/9;background:transparent;border:none;min-height:auto"' : ''}>${renderMedia(d.homeAjaxImage||'/images/Ajax-systems-header.jpg', 'Ajax Systems')}<div class="split-image-badge">Instalador Oficial</div></div>
  </div>
</section>

<!-- Clientes -->
<section class="bg-white" data-od-id="clientes">
${buildClientesSection(d)}
</section>

<!-- Cobertura unificada (CTA + Ubicaciones) -->
<section class="bg-navy" data-od-id="ubicaciones" style="position:relative;z-index:0">
<div class="container" style="padding-top:72px;padding-bottom:72px">
  <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-bottom:32px">
    <div class="hero-badge" style="margin-bottom:0">
      ${I.shield}Certificación OS-10
    </div>
    <div class="hero-badge" style="margin-bottom:0">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>Ley 21.659
    </div>
  </div>
  <h2 class="section-title" style="text-align:center;max-width:700px;margin:0 auto 12px">${esc(d.homeCtaFinalTitle || d.homeUbicacionesTitle || 'Protección profesional para tu tranquilidad')}</h2>
  <p class="section-subtitle" style="text-align:center;max-width:600px;margin:0 auto 28px">${esc(d.homeCtaFinalSubtitle || d.homeUbicacionesSubtitle || 'Más de 8 años protegiendo empresas y residencias con guardias certificados, tecnología de vanguardia y atención personalizada.')}</p>
  <div style="text-align:center;margin-bottom:48px">
    <a href="${esc(d.homeCtaFinalCta1Link || '/contacto')}" class="btn btn-primary btn-lg">${esc(d.homeCtaFinalCta1Text || 'Hablar con un experto')}</a>
  </div>
  <hr style="border:0;border-top:1px solid rgba(255,255,255,.1);margin:0 0 48px">
  <span class="section-label">${esc(d.homeUbicacionesBadge || 'Amplia Cobertura')}</span>
  <h2 class="section-title">${esc(d.homeUbicacionesZonesTitle || d.homeUbicacionesTitle || 'Protegemos en toda la Región Metropolitana')}</h2>
  <p class="section-subtitle">${esc(d.homeUbicacionesZonesSubtitle || d.homeUbicacionesSubtitle || 'Presencia en las principales comunas de Santiago y la zona de Los Andes y San Felipe.')}</p>
  <div class="coverage-split" style="margin-top:28px">
    <div class="coverage-zones">
      ${zones.map((z:any)=>`<div class="zone-card"><div class="zone-card-header"><span class="zone-dot dot-${esc(z.dotClass)}" style="width:8px;height:8px;flex-shrink:0"></span>${esc(z.name)}</div><div class="zone-tags">${(z.locations||[]).map((l:any)=>`<a href="/ubicaciones/${esc(l.slug)}" class="zone-tag-link">${esc(l.name)}</a>`).join('')}</div></div>`).join('\n')}
    </div>
    <figure class="coverage-map" style="margin:0;position:relative;z-index:0;overflow:hidden">
      <div id="map-home" style="height:400px;border-radius:var(--radius-xl);border:1px solid rgba(255,255,255,.12);touch-action:pan-y;background:#1a1a2e"></div>
      <figcaption style="font-size:13px;color:rgba(255,255,255,.75);margin-top:8px;text-align:center">14 comunas con cobertura verificada · Centro de monitoreo propio 24/7</figcaption>
    </figure>
  </div>
  <div style="text-align:center;margin-top:28px"><a href="${esc(d.homeUbicacionesCtaLink || '/ubicaciones')}" class="btn btn-outline-light">${esc(d.homeUbicacionesCtaText || 'Ver todas las ubicaciones →')}</a></div>
</div>
</section>
</main>
${ftr()}
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>${buildHomeMapScript(zones, ZC)}</script>
<script src="/scripts/main.js"></script>
</body></html>`;
}

export function buildStaticPage(d: SiteData): string {
  return `<!doctype html>
<html lang="es-CL">
<head>
${CRITICAL_CSS}
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(d.title)}</title><meta name="description" content="${esc(d.description)}">
<link rel="canonical" href="${SITE_URL}${esc(d.canonical)}">
${OG_BASE}
<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg">
</head>
<body>
${hdr(d.headerVariant||'light')}
${brd(d.breadcrumbs)}
${hero(d)}
<section class="content-section bg-white"><div class="container">
${buildSections(d).map(renderSection).join('\n')}
</div></section>
${cta(d)}
${ftr()}
<script src="/scripts/main.js"></script>
</body></html>`;
}

export function buildHubPage(d: SiteData, env?: any): string {
  const sdata = (env as any)?._staticData;
  const data = d as any;
  const items = data.hubItems || [];
  const t = d.pageType;
  // Read hero from CMS content_json if available
  let heroTitle = t==='servicios'?'Servicios de Seguridad':t==='sectores'?'Sectores':'Cobertura en Santiago';
  let heroSub = t==='servicios'?'Soluciones profesionales con certificación OS-10':t==='sectores'?'Experiencia en múltiples industrias':'14 comunas con seguridad profesional';
  let ctaHeading = t==='servicios'?'¿No sabes qué servicio necesitas?':'¿No encuentras tu sector?';
  let ctaSub = t==='servicios'?'Nuestro equipo te ayudará a encontrar la mejor solución para tu caso.':'Cubrimos múltiples industrias con soluciones de seguridad adaptadas.';
  if (sdata?.content_json) {
    try {
      const cj = typeof sdata.content_json === 'string' ? JSON.parse(sdata.content_json) : sdata.content_json;
      const c = cj.content || cj;
      if (c.hero?.headline) heroTitle = c.hero.headline;
      if (c.hero?.subheadline) heroSub = c.hero.subheadline;
      if (c.cta?.heading) ctaHeading = c.cta.heading;
      if (c.cta?.subheading) ctaSub = c.cta.subheading;
    } catch {}
  }
  const isLoc = t==='ubicaciones';
  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(d.title)}</title><meta name="description" content="${esc(d.description)}"><link rel="canonical" href="${SITE_URL}${esc(d.canonical)}">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg"></head><body>${hdr('light')}${brd(d.breadcrumbs)}<main><section class="hero"><div class="container"><h1>${esc(heroTitle)}</h1><p>${esc(heroSub)}</p></div></section><section class="bg-white" style="padding:64px 0"><div class="container">${isLoc?`<div class="coverage-split" style="margin-top:28px"><div class="coverage-zones">${(data.hubZones||[]).map((z:any)=>`<div class="zone-card"><div class="zone-card-header"><span class="zone-dot dot-${esc(z.dotClass)}" style="width:8px;height:8px;flex-shrink:0"></span>${esc(z.name)}</div><div class="zone-tags">${(z.locations||[]).map((l:any)=>`<a href="/ubicaciones/${esc(l.slug)}" class="zone-tag-link">${esc(l.name)}</a>`).join('')}</div></div>`).join('')}</div></div>`:`<div class="card-grid" style="margin-top:40px">${items.map((i:any)=>`<a href="${esc(i.href)}" class="card">${i.image?`<div class="card-image"><img src="${esc(i.image)}" alt="${esc(i.name)}" loading="lazy">${i.tag?`<span class="card-tag tag ${esc(i.tag)}">${i.name}</span>`:''}</div>`:''}<div class="card-body"><h3>${esc(i.name)}</h3>${i.description?`<p>${esc(i.description)}</p>`:''}<span class="card-link">Ver ${t==='servicios'?'servicio':'sector'} <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg></span></div></a>`).join('')}</div>`}</div></section>${t !== 'ubicaciones' ? `<div class="cta-band" data-od-id="block-cta"><div class="container"><h3>${esc(ctaHeading)}</h3><p>${esc(ctaSub)}</p><a href="/contacto" class="btn btn-primary btn-lg">Contactar a un experto</a></div></div>` : ''}</main>${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

// ═══════════════ SCHEMA BUILDERS ═══════════════
export function buildOrganizationSchema() { return {'@context':'https://schema.org','@type':'Organization',name:'GuardMan Chile',url:SITE_URL,telephone:'+56 9 300 000 10',email:'info@guardman.cl',address:{'@type':'PostalAddress',streetAddress:'Av. Américo Vespucio Norte 1980, Providencia, Santiago',addressLocality:'Providencia',addressRegion:'Santiago',addressCountry:'CL'}}; }
export function buildWebSiteSchema() { return {'@context':'https://schema.org','@type':'WebSite',name:'GuardMan Chile',url:SITE_URL,description:'Seguridad privada en Chile. Guardias OS-10, CCTV, control de accesos y monitoreo 24/7.',potentialAction:{'@type':'SearchAction',target:{'@type':'EntryPoint',urlTemplate:`${SITE_URL}/search?q={search_term_string}`},'query-input':'required name=search_term_string'}}; }
export function buildBreadcrumbSchema(items: Array<{label:string;href?:string}>) { return {'@context':'https://schema.org','@type':'BreadcrumbList',itemListElement:items.map((i,j)=>({'@type':'ListItem',position:j+1,name:i.label,item:i.href?`${SITE_URL}${i.href}`:undefined}))}; }
export function buildFAQSchema(items: Array<{question:string;answer:string}>) { return {'@context':'https://schema.org','@type':'FAQPage',mainEntity:items.map(f=>({'@type':'Question',name:f.question,acceptedAnswer:{'@type':'Answer',text:f.answer}}))}; }
export function buildLocalBusinessSchema(name:string,desc:string,loc?:string) { return {'@context':'https://schema.org','@type':'LocalBusiness',name:`GuardMan Chile${loc?' - '+loc:''}`,description:desc,url:SITE_URL,telephone:'+56 9 300 000 10',address:{'@type':'PostalAddress',addressLocality:loc||'Santiago',addressRegion:'Santiago',addressCountry:'CL'}}; }
export function buildServiceSchema(d:SiteData) { return {'@context':'https://schema.org','@type':'Service',name:d.heroHeading,description:d.description,provider:{'@type':'LocalBusiness',name:'GuardMan Chile',telephone:'+56 9 300 000 10'},areaServed:{'@type':'City',name:'Santiago'},serviceType:'Seguridad Privada'}; }

// ═══════════════ STATIC PAGE BUILDERS (HTML exacto de Open Design) ═══════════════

import { NOSOTROS_HTML } from './nosotros-html';
import { GUARDPOD_HTML } from './guardpod-html';
import { AJAX_HTML } from './ajax-html';
import { CONTACTO_HTML } from './contacto-html';
import { COTIZACION_HTML } from './cotizacion-html';
import { PRIVACIDAD_HTML } from './privacidad-html';
import { TERMINOS_HTML } from './terminos-html';

export function buildNosotrosPage(env?: any): string {
  const d = (env as any)?._staticData;
  const title = d?.meta_title || 'Nosotros — GuardMan Chile | Seguridad Privada en Santiago';
  const desc = d?.meta_description || 'GuardMan Chile: más de 8 años protegiendo Santiago. 500+ guardias OS-10, centro de monitoreo propio.';
  let heroH = d?.hero_heading || 'Protegemos lo que más te importa desde 2017';
  let heroS = d?.hero_subheading || 'GuardMan Chile nació con una convicción: la seguridad privada en Chile merecía un estándar más alto. Más de 8 años después, somos la opción de 200+ empresas y protegemos 14 comunas de la Región Metropolitana.';
  let finalTitle = title;
  let finalDesc = desc;

  // Parse content_json for CMS overrides
  let cj: any = null;
  if (d?.content_json) {
    try { cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json; } catch {}
  }
  const c = cj?.content || cj || {};
  const seo = cj?.seo || {};

  // SEO overrides
  if (seo.title) finalTitle = seo.title;
  if (seo.description) finalDesc = seo.description;

  // Hero overrides
  if (c.hero?.headline || c.hero?.heading) heroH = c.hero.headline || c.hero.heading;
  if (c.hero?.subheadline || c.hero?.subheading) heroS = c.hero.subheadline || c.hero.subheading;

  // Determine if body has CMS-driven sections
  const hasBodyOverrides = !!(c.stats || c.timeline || c.values || c.differentiators || c.certifications || c.staff || c.cta);
  const bodyHtml = hasBodyOverrides
    ? buildNosotrosBody(c)
    : NOSOTROS_HTML.replace(/<section class="hero"[\s\S]*?<\/section>/, '');

  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(finalTitle)}</title><meta name="description" content="${esc(finalDesc)}"><link rel="canonical" href="${SITE_URL}/nosotros">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg">${jsonld(buildOrganizationSchema())}</head><body>${hdr('light')}${brd([{label:'Inicio',href:'/'},{label:'Nosotros'}])}<main><section class="hero" data-od-id="hero"><div class="container"><h1>${esc(heroH)}</h1><p>${esc(heroS)}</p></div></section>${bodyHtml}</main>${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

// Build Nosotros body from content_json overrides
function buildNosotrosBody(c: any): string {
  let html = '';

  // Stats row
  if (c.stats?.length) {
    html += `<div class="stats-row" data-od-id="stats"><div class="container stats-grid">`;
    for (const s of c.stats) {
      html += `<div class="stat-item"><div class="stat-value">${esc(s.value)}</div><div class="stat-label">${esc(s.label)}</div></div>`;
    }
    html += `</div></div>`;
  }

  // Timeline (Historia)
  if (c.timeline?.length) {
    html += `<section class="bg-white" data-od-id="historia"><div class="container" style="max-width:760px"><span class="section-label">Nuestra Historia</span><h2 class="section-title">De una oficina en Providencia a la empresa de seguridad más confiable de Santiago</h2><div class="timeline">`;
    for (const t of c.timeline) {
      html += `<div class="timeline-item"><div class="timeline-year">${esc(t.year)}</div><div class="timeline-content"><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p></div></div>`;
    }
    html += `</div></div></section>`;
  }

  // Values
  if (c.values?.length) {
    html += `<section class="bg-neutral" data-od-id="valores"><div class="container"><span class="section-label">Nuestros Valores</span><h2 class="section-title">Nuestros Valores</h2><div class="values-grid">`;
    for (const v of c.values) {
      html += `<div class="value-card"><h4>${esc(v.title)}</h4><p>${esc(v.description)}</p></div>`;
    }
    html += `</div></div></section>`;
  }

  // Differentiators
  if (c.differentiators?.length) {
    html += `<section class="bg-white" data-od-id="diferenciadores"><div class="container"><span class="section-label">¿Qué nos diferencia?</span><h2 class="section-title">¿Qué nos diferencia?</h2><div class="differentiators-grid">`;
    for (const d of c.differentiators) {
      const icon = d.icon || I.shield;
      html += `<div class="diff-card"><div class="diff-card-icon">${icon}</div><h3>${esc(d.title)}</h3><p>${esc(d.description)}</p></div>`;
    }
    html += `</div></div></section>`;
  }

  // Certifications
  if (c.certifications?.length) {
    html += `<section class="bg-neutral" data-od-id="certificaciones"><div class="container"><span class="section-label">Certificaciones</span><h2 class="section-title">Certificaciones y cumplimiento</h2><div class="cert-grid">`;
    for (const cert of c.certifications) {
      html += `<div class="cert-item">${I.check}<div><h4>${esc(cert.title)}</h4><p>${esc(cert.description)}</p></div></div>`;
    }
    html += `</div></div></section>`;
  }

  // Staff
  if (c.staff) {
    const img = c.staff.image || '/images/nosotros_seccion.webp';
    const traits = c.staff.traits || ['Certificación OS-10 vigente verificada por Carabineros de Chile','Capacitación continua en protocolos de seguridad y emergencias','Centro de monitoreo propio 24/7 con operadores especializados','8+ años de experiencia protegiendo empresas y residencias'];
    html += `<section class="staff-section" data-od-id="staff"><div class="container split"><div class="split-image">${renderMedia(img, 'Personal GuardMan', `loading="lazy"`)}</div><div><span class="section-label">Personal que marca la diferencia</span><h2 class="section-title">Personal que marca la diferencia</h2><p style="color:rgba(255,255,255,.95);font-size:16px;line-height:1.6;margin-bottom:24px">Nuestros guardias son la base de la confianza que nuestros clientes depositan en nosotros.</p>`;
    for (const t of traits) {
      html += `<div class="staff-check">${I.check}${esc(t)}</div>`;
    }
    html += `</div></div></section>`;
  }

  // CTA final
  if (c.cta) {
    const ctaHeading = c.cta.heading || '¿Quieres conocer más?';
    const ctaSub = c.cta.subheading || 'Conversemos. Te contamos cómo podemos proteger lo que más te importa.';
    const btnText = c.cta.button_text || 'Hablar con un Experto';
    const btnHref = c.cta.button_href || '/contacto';
    html += `<section class="bg-dark cta-section" data-od-id="cta"><div class="container"><h2 class="section-title">${esc(ctaHeading)}</h2><p class="section-subtitle">${esc(ctaSub)}</p><a href="${esc(btnHref)}" class="btn btn-primary btn-lg">${esc(btnText)}</a></div></section>`;
  }

  return html;
}

export function buildGuardPodPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Guard Pod — Vigilancia Autónoma 24/7 | GuardMan Chile';
  let desc = d?.meta_description || 'Guard Pod V1: unidad autónoma de vigilancia con energía solar, cámaras PTZ 360° y monitoreo remoto.';
  let badge = d?.hero_badge || 'Tecnología Propia GuardMan';
  let heroH = d?.hero_heading || 'Guard Pod';
  let heroS = d?.hero_subheading || 'Vigilancia autónoma 24/7 para obras, eventos y zonas sin infraestructura.';

  // Parse content_json for CMS overrides
  let cj: any = null;
  if (d?.content_json) {
    try { cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json; } catch {}
  }
  const c = cj?.content || cj || {};
  const seo = cj?.seo || {};

  if (seo.title) title = seo.title;
  if (seo.description) desc = seo.description;
  if (c.hero?.badge) badge = c.hero.badge;
  if (c.hero?.headline || c.hero?.heading) heroH = c.hero.headline || c.hero.heading;
  if (c.hero?.subheadline || c.hero?.subheading) heroS = c.hero.subheadline || c.hero.subheading;

  // Body: use dynamic if overrides exist, else fallback to static HTML
  const hasBodyOverrides = !!(c.features || c.problems || c.faqs || c.stats);
  let bodyHtml = GUARDPOD_HTML;
  if (hasBodyOverrides) {
    bodyHtml = buildGuardPodBody(c);
  }
  if (d) {
    bodyHtml = bodyHtml.replace(/<h1>Guard <span[^>]*>Pod<\/span><\/h1>/, `<h1>Guard <span style="color:var(--accent)">Pod</span></h1>`);
  }

  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${SITE_URL}/guard-pod">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="stylesheet" href="/styles/dark.css"><link rel="icon" type="image/svg+xml" href="/favicon.svg">${jsonld(buildOrganizationSchema())}</head><body class="dark-page">${hdr('dark')}${brd([{label:'Inicio',href:'/'},{label:'Guard Pod'}])}<main>${bodyHtml}</main>${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

// Normalize section data: CMS may store as {heading, items} or plain array
const normItems = (s: any): any[] | null => {
  if (!s) return null;
  if (Array.isArray(s)) return s;
  if (s.items && Array.isArray(s.items)) return s.items;
  return null;
};
const normHeading = (s: any, defaultHeading: string): string => {
  if (!s) return defaultHeading;
  if (typeof s === 'string') return s;
  if (s.heading) return s.heading;
  return defaultHeading;
};

function buildGuardPodBody(c: any): string {
  let html = '';

  // Hero section
  const heroImg = c.hero?.image || '/images/s4-thumbnail.webp';
  const isYtHero = heroImg?.startsWith('yt:');
  const heroBadge = c.hero?.badge || 'Tecnología Propia GuardMan';
  const heroHeading = c.hero?.headline || c.hero?.heading || 'Guard Pod';
  const heroSub = c.hero?.subheadline || c.hero?.subheading || 'Vigilancia autónoma 24/7 para obras, eventos y zonas sin infraestructura.';
  const heroCta1Text = c.hero?.cta1_text || 'Cotizar Guard Pod';
  const heroCta1Href = c.hero?.cta1_href || '/cotizacion';
  const heroCta2Text = c.hero?.cta2_text || 'Ver características';
  const heroCta2Href = c.hero?.cta2_href || '#features';
  const heroStats = c.stats || [{value:'2h',label:'Tiempo de despliegue'},{value:'15',label:'Meses de I+D'},{value:'360°',label:'Cobertura PTZ'}];

  html += `<section class="hero" data-od-id="hero"><div class="container"><div class="hero-grid"><div><div class="hero-badge">${I.shield}${esc(heroBadge)}</div><h1>${esc(heroHeading)}</h1><p class="hero-sub">${esc(heroSub)}</p><div class="hero-ctas"><a href="${esc(heroCta1Href)}" class="btn btn-primary btn-lg">${esc(heroCta1Text)}</a><a href="${esc(heroCta2Href)}" class="btn btn-ghost btn-lg">${esc(heroCta2Text)}</a></div><div class="hero-stats">`;
  for (const s of heroStats) {
    html += `<div><div class="hero-stat-value">${esc(s.value)}</div><div class="hero-stat-label">${esc((s.label || '').substring(0, 35))}</div></div>`;
  }
  html += `</div></div><div class="hero-visual"><div class="hero-product"${isYtHero ? ' style="aspect-ratio:16/9;background:transparent;border:none"' : ''}>${renderMedia(heroImg, 'Guard Pod V1', isYtHero ? '' : `loading="eager" onerror="this.style.display='none'"`)}</div></div></div></div></section>`;

  // Intro section (from content_json or default)
  const introLabel = c.intro?.label || 'Qué es el Guard Pod';
  const introTitle = c.intro?.title || 'El futuro de la seguridad privada en Chile';
  const introImg = c.intro?.image || heroImg;
  const isYtIntro = introImg?.startsWith('yt:');
  const introParagraphs = c.intro?.paragraphs || ['El Guard Pod® V1 es una unidad autónoma de vigilancia que combina tecnología de última generación con supervisión humana remota las 24 horas.','Funciona como un elemento disuasorio visible y efectivo. Su sistema de detección autónoma de intrusos permite respuesta inmediata.','Diseñado para sitios remotos, perímetros vulnerables y propiedades que requieren vigilancia constante. Energía solar, sin necesidad de red eléctrica.'];
  html += `<section data-od-id="intro"><div class="container"><div class="split"><div class="split-text"><span class="section-label">${esc(introLabel)}</span><h2 class="section-title">${esc(introTitle)}</h2>`;
  for (const p of introParagraphs) {
    html += `<p>${esc(typeof p === 'string' ? p : p.text || '')}</p>`;
  }
  html += `</div><div class="split-image"${isYtIntro ? ' style="aspect-ratio:16/9;background:transparent;border:none;min-height:auto"' : ''}>${renderMedia(introImg, 'Guard Pod V1', isYtIntro ? '' : `loading="lazy" onerror="this.style.display='none'"`)}</div></div></div></section>`;

  // Features
  const featItems = normItems(c.features);
  if (featItems?.length) {
    html += `<section class="section-dark" data-od-id="features"><div class="container"><span class="section-label">Características principales</span><h2 class="section-title">${normHeading(c.features, 'Tecnología que protege sin descanso')}</h2><div class="feature-grid">`;
    for (const f of featItems) {
      const icon = f.icon || I.shield;
      html += `<div class="feature-card"><div class="feature-card-icon">${icon}</div><h3>${esc(f.title)}</h3><p>${esc(f.description)}</p></div>`;
    }
    html += `</div></div></section>`;
  }

  // Problems
  const probItems = normItems(c.problems);
  if (probItems?.length) {
    html += `<section data-od-id="problems"><div class="container"><span class="section-label">Problemas que resolvemos</span><h2 class="section-title">Seguridad sin compromisos</h2><div class="problems-grid">`;
    for (const p of probItems) {
      html += `<div class="problem-card">${I.warn}<p>${esc(typeof p === 'string' ? p : p.description || '')}</p></div>`;
    }
    html += `</div></div></section>`;
  }

  // FAQs
  const faqItems = normItems(c.faqs);
  if (faqItems?.length) {
    html += `<section data-od-id="faq"><div class="container" style="max-width:760px"><span class="section-label">Preguntas frecuentes</span><h2 class="section-title">${normHeading(c.faqs, 'Todo lo que necesitas saber')}</h2><div class="faq">`;
    faqItems.forEach((f: any, i: number) => {
      html += `<details${i===0?' open':''}><summary>${esc(f.question)}</summary><div class="answer">${esc(f.answer)}</div></details>`;
    });
    html += `</div></div></section>`;
  }

  // CTA (from CMS or defaults)
  const gpCtaHeading = c.cta?.heading || 'Protege tu propiedad con Guard Pod';
  const gpCtaSub = c.cta?.subheading || 'Solicita una cotización personalizada y descubre cómo el Guard Pod puede proteger lo que más te importa.';
  const gpCtaBtn = c.cta?.button_text || 'Cotizar Guard Pod';
  const gpCtaHref = c.cta?.button_href || '/cotizacion';
  html += `<div class="cta-band" data-od-id="cta"><div class="container"><h2 class="section-title">${esc(gpCtaHeading)}</h2><p class="section-subtitle">${esc(gpCtaSub)}</p><div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap"><a href="${esc(gpCtaHref)}" class="btn btn-primary btn-lg">${esc(gpCtaBtn)}</a></div></div></div>`;

  return html;
}

export function buildAjaxPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Ajax Systems — Instalador Oficial | GuardMan Chile';
  let desc = d?.meta_description || 'Instalador oficial Ajax Systems. Alarmas Grado 3 con tecnología Jeweller.';
  let heroBadge = d?.hero_badge || 'Instalador Oficial';
  let heroH = d?.hero_heading || 'Ajax Systems';
  let heroS = d?.hero_subheading || 'Alarmas inteligentes con certificación Grade 3 Professional.';

  // Parse content_json for CMS overrides
  let cj: any = null;
  if (d?.content_json) {
    try { cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json; } catch {}
  }
  const c = cj?.content || cj || {};
  const seo = cj?.seo || {};

  if (seo.title) title = seo.title;
  if (seo.description) desc = seo.description;
  if (c.hero?.badge) heroBadge = c.hero.badge;
  if (c.hero?.headline || c.hero?.heading) heroH = c.hero.headline || c.hero.heading;
  if (c.hero?.subheadline || c.hero?.subheading) heroS = c.hero.subheadline || c.hero.subheading;

  // Body: use dynamic if overrides exist, else fallback to static HTML
  // Always use dynamic body if there's CMS content (features, faqs, or just hero_image set)
  const hasBodyOverrides = !!(c.hero?.image || c.features || c.whyUs || c.problems || c.faqs);
  const bodyHtml = hasBodyOverrides ? buildAjaxBody(c) : AJAX_HTML;

  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${SITE_URL}/ajax-systems">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="stylesheet" href="/styles/dark.css"><link rel="icon" type="image/svg+xml" href="/favicon.svg">${jsonld(buildOrganizationSchema())}</head><body class="dark-page">${hdr('dark')}${brd([{label:'Inicio',href:'/'},{label:'Ajax Systems'}])}<main>${bodyHtml}</main>${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

function buildAjaxBody(c: any): string {
  let html = '';

  // Hero — mirror Guard Pod layout: badge + heading + sub + CTAs + hero-stats + hero-visual
  const heroImg = c.hero?.image || '/images/Ajax-systems-header.jpg';
  const isYtHero = heroImg?.startsWith('yt:');
  const heroBadge = c.hero?.badge || 'Instalador Oficial';
  const heroHeading = c.hero?.headline || c.hero?.heading || 'Ajax Systems';
  const heroSub = c.hero?.subheadline || c.hero?.subheading || 'Alarmas inteligentes con certificación Grade 3 Professional.';
  const heroCta1Text = c.hero?.cta1_text || 'Cotizar Ajax Systems';
  const heroCta1Href = c.hero?.cta1_href || '/cotizacion';
  const heroCta2Text = c.hero?.cta2_text || 'Ver características';
  const heroCta2Href = c.hero?.cta2_href || '#features';
  const statItems = normItems(c.stats) || [
    {value:'Grado 3',label:'Certificación'},
    {value:'2 km',label:'Alcance Jeweller'},
    {value:'24/7',label:'Monitoreo propio'},
  ];

  html += `<section class="hero" data-od-id="hero"><div class="container"><div class="hero-grid"><div><div class="hero-badge">${I.shield}${esc(heroBadge)}</div><h1>${esc(heroHeading)}</h1><p class="hero-sub">${esc(heroSub)}</p><div class="hero-ctas"><a href="${esc(heroCta1Href)}" class="btn btn-primary btn-lg">${esc(heroCta1Text)}</a><a href="${esc(heroCta2Href)}" class="btn btn-ghost btn-lg">${esc(heroCta2Text)}</a></div><div class="hero-stats">`;
  for (const s of statItems.slice(0, 3)) {
    html += `<div><div class="hero-stat-value">${esc(s.value)}</div><div class="hero-stat-label">${esc((s.label || '').substring(0, 35))}</div></div>`;
  }
  html += `</div></div><div class="hero-visual"><div class="hero-product"${isYtHero ? ' style="aspect-ratio:16/9;background:transparent;border:none"' : ''}>${renderMedia(heroImg, 'Ajax Systems', isYtHero ? '' : `loading="eager" onerror="this.style.display='none'"`)}</div></div></div></div></section>`;

  // Intro section (split layout — mirrors Guard Pod)
  const introLabel = c.intro?.label || 'Qué es Ajax Systems';
  const introTitle = c.intro?.title || 'Seguridad inteligente certificada';
  const introImg = c.intro?.image || heroImg;
  const isYtIntro = introImg?.startsWith('yt:');
  const introParagraphs = c.intro?.paragraphs || [
    'Ajax Systems es la plataforma de seguridad inalámbrica más premiada de Europa. Diseñada para proteger hogares, oficinas y empresas con la máxima certificación de seguridad (Grado 3 Profesional).',
    'En GuardMan Chile combinamos la tecnología Ajax con nuestro centro de monitoreo propio 24/7 y personal certificado OS-10. El resultado: una solución de seguridad integral, inteligente y confiable.',
    'Cada sistema Ajax instalado por GuardMan incluye configuración profesional, capacitación de usuarios, mantenimiento preventivo y monitoreo proactivo. No solo instalamos: protegemos.'
  ];
  html += `<section data-od-id="intro"><div class="container"><div class="split"><div class="split-text"><span class="section-label">${esc(introLabel)}</span><h2 class="section-title">${esc(introTitle)}</h2>`;
  for (const p of introParagraphs) {
    html += `<p>${esc(typeof p === 'string' ? p : p.text || '')}</p>`;
  }
  html += `</div><div class="split-image"${isYtIntro ? ' style="aspect-ratio:16/9;background:transparent;border:none;min-height:auto"' : ''}>${renderMedia(introImg, 'Ajax Systems', isYtIntro ? '' : `loading="lazy" onerror="this.style.display='none'"`)}</div></div></div></section>`;

  // Features section
  const featItems = normItems(c.features);
  if (featItems?.length) {
    html += `<section class="section-dark" data-od-id="features"><div class="container"><span class="section-label">Ventajas Ajax + GuardMan</span><h2 class="section-title">${normHeading(c.features, 'Tecnología que redefine la seguridad')}</h2><div class="feature-grid">`;
    for (const f of featItems) {
      html += `<div class="feature-card"><div class="feature-card-icon">${f.icon || I.shield}</div><h3>${esc(f.title)}</h3><p>${esc(f.description)}</p></div>`;
    }
    html += `</div></div></section>`;
  }

  // Problems / Solutions — defaults tailored for Ajax (like Guard Pod has defaults)
  const probItems = normItems(c.problems) || normItems(c.whyUs) || [
    'Sistemas de alarma cableados vulnerables a cortes de electricidad e inhibidores de señal',
    'Falta de monitoreo profesional 24/7 con respuesta inmediata ante intrusiones reales',
    'Instalaciones no certificadas que dejan puntos ciegos y fallan cuando más se necesitan',
    'Falsas alarmas constantes por sensores de baja calidad que generan desconfianza y multas',
    'Sin control remoto desde el celular: dependencia total de un teclado físico en sitio',
    'Respuesta lenta de empresas de seguridad tradicionales: minutos que hacen la diferencia',
  ];
  if (probItems?.length) {
    html += `<section data-od-id="problems"><div class="container"><span class="section-label">Problemas que resolvemos</span><h2 class="section-title">Seguridad sin compromisos</h2><div class="problems-grid">`;
    for (const p of probItems) {
      const text = typeof p === 'string' ? p : (p.title || p.description || '');
      const icon = typeof p === 'string' ? I.warn : (p.icon || I.warn);
      html += `<div class="problem-card">${icon}<p>${esc(text)}</p></div>`;
    }
    html += `</div></div></section>`;
  }

  // FAQs
  const faqItems = normItems(c.faqs);
  if (faqItems?.length) {
    html += `<section data-od-id="faq"><div class="container" style="max-width:760px"><span class="section-label">Preguntas frecuentes</span><h2 class="section-title">${normHeading(c.faqs, 'Todo sobre Ajax Systems')}</h2><div class="faq">`;
    faqItems.forEach((f: any, i: number) => {
      html += `<details${i===0?' open':''}><summary>${esc(f.question)}</summary><div class="answer">${esc(f.answer)}</div></details>`;
    });
    html += `</div></div></section>`;
  }

  // CTA
  // CTA (from CMS or defaults)
  const axCtaHeading = c.cta?.heading || 'Cotiza tu sistema Ajax';
  const axCtaSub = c.cta?.subheading || 'Protección inteligente con tecnología de clase mundial y monitoreo 24/7.';
  const axCtaBtn = c.cta?.button_text || 'Cotizar Ahora';
  const axCtaHref = c.cta?.button_href || '/cotizacion';
  html += `<div class="cta-band" data-od-id="cta"><div class="container"><h2 class="section-title">${esc(axCtaHeading)}</h2><p class="section-subtitle">${esc(axCtaSub)}</p><a href="${esc(axCtaHref)}" class="btn btn-primary btn-lg">${esc(axCtaBtn)}</a></div></div>`;

  return html;
}

// Extrae el contenido no-hero de CONTACTO_HTML (todo después del primer </section>)
const _CONTACTO_AFTER_HERO = (() => {
  const idx = CONTACTO_HTML.indexOf('</section>');
  const after = idx > 0 ? CONTACTO_HTML.substring(idx + '</section>'.length) : CONTACTO_HTML;
  // Remove wrapping </main> at the end
  return after.replace(/<\/main>\s*$/, '');
})();

function buildContactoMap(ci: any): string {
  return `<section class="bg-neutral" style="padding:48px 0"><div class="container"><h2 class="section-title" style="margin-bottom:8px">Encuéntranos</h2><p class="section-subtitle" style="margin-bottom:24px">${esc(ci.address)}</p><div id="map-contacto" style="height:360px;border-radius:var(--radius-xl);border:1px solid var(--border)"></div></div></section>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>(function(){var d=document.getElementById('map-contacto');if(!d||typeof L==='undefined')return;var map=L.map(d,{center:[${ci.lat||-33.4569},${ci.lng||-70.6483}],zoom:14,scrollWheelZoom:false,attributionControl:false});L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map);L.marker([${ci.lat||-33.4569},${ci.lng||-70.6483}]).addTo(map).bindPopup('<strong>GuardMan Chile</strong><br>${esc(ci.address)}').openPopup();})();<\/script>`;
}

export function buildContactoPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Contacto — GuardMan Chile | Seguridad Privada en Santiago';
  let desc = d?.meta_description || 'Contacta a GuardMan Chile. Disponibles 24/7. Cotizacion sin compromiso.';
  let heroH = d?.hero_heading || 'Contáctanos';
  let heroS = d?.hero_subheading || 'Estamos disponibles las 24 horas, los 7 días de la semana.';
  let ciSectionTitle = 'Estamos aquí para ayudarte';
  let ctSectionSubtitle = 'Encuentra toda la información para comunicarte con nuestro equipo.';
  let contactInfo: any = { phone: '+56 9 300 000 10', email: 'info@guardman.cl', address: 'Av. Américo Vespucio Norte 1980, Providencia, Santiago', lat: '-33.4569', lng: '-70.6483' };
  let ctaHeading = '¿Prefieres que te llamemos?';
  let ctaSub = 'Déjanos tu número y un experto en seguridad te contactará en menos de 2 horas.';
  let ctaBtn = 'Solicitar Llamada';
  let ctaHref = 'tel:+56930000010';

  // Parse content_json for overrides
  if (d?.content_json) {
    try {
      const cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json;
      const seo = cj.seo || {};
      const c = cj.content || cj;
      if (seo.title) title = seo.title;
      if (seo.description) desc = seo.description;
      if (c.hero?.headline) heroH = c.hero.headline;
      if (c.hero?.subheadline) heroS = c.hero.subheadline;
      if (c.contact_info) {
        contactInfo = { ...contactInfo, ...c.contact_info };
        if (c.contact_info.section_title) ciSectionTitle = c.contact_info.section_title;
        if (c.contact_info.section_subtitle) ctSectionSubtitle = c.contact_info.section_subtitle;
      }
      if (c.cta?.heading) ctaHeading = c.cta.heading;
      if (c.cta?.subheading) ctaSub = c.cta.subheading;
      if (c.cta?.button_text) ctaBtn = c.cta.button_text;
      if (c.cta?.button_href) ctaHref = c.cta.button_href;
    } catch { /* ignore */ }
  }

  const ci = contactInfo;
  const bodyHtml = `<main>
<section class="hero" data-od-id="hero">
  <div class="container">
    <h1>${esc(heroH)}</h1>
    <p>${esc(heroS)}</p>
  </div>
</section>

<section class="bg-neutral" data-od-id="contacto-info">
  <div class="container section-grid">
    <div>
      <span class="section-label">Información de contacto</span>
      <h2 class="section-title">${esc(ciSectionTitle)}</h2>
      <p class="section-subtitle">${esc(ctSectionSubtitle)}</p>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg></div><div class="contact-info-text"><h4>Teléfono</h4><a href="tel:${esc(ci.phone)}">${esc(ci.phone)}</a></div></div>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div><div class="contact-info-text"><h4>Email</h4><a href="mailto:${esc(ci.email)}">${esc(ci.email)}</a></div></div>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg></div><div class="contact-info-text"><h4>Dirección</h4><p>${esc(ci.address)}</p></div></div>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><div class="contact-info-text"><h4>Horario</h4><p>Lunes a Domingo: 24 horas</p></div></div>
    </div>
    <div>
      <div class="form-card" data-od-id="form">
        <h3 style="font-size:22px;font-weight:700;margin-bottom:4px">Envíanos un mensaje</h3>
        <p style="color:var(--muted);font-size:15px;margin-bottom:24px">Completa el formulario y te responderemos en menos de 24 horas.</p>
        <form method="POST" action="/contacto">
          <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off">
          <div class="form-row"><div class="form-group"><label>Nombre completo <span class="required">*</span></label><input type="text" name="nombre" required></div><div class="form-group"><label>Correo electrónico <span class="required">*</span></label><input type="email" name="email" required></div></div>
          <div class="form-row"><div class="form-group"><label>Teléfono <span class="required">*</span></label><input type="tel" name="telefono" required></div><div class="form-group"><label>Comuna</label><input type="text" name="location"></div></div>
          <div class="form-group"><label>Servicio de interés <span class="required">*</span></label><select name="service" required><option value="">Selecciona una opción</option><option value="guardias-de-seguridad">Guardias de Seguridad</option><option value="cctv-videovigilancia">CCTV y Videovigilancia</option><option value="control-de-accesos">Control de Accesos</option><option value="monitoreo-24-7">Monitoreo 24/7</option><option value="escoltas-privados">Escoltas Privados</option><option value="guard-pod">Guard Pod</option><option value="seguridad-industrial">Seguridad Industrial</option><option value="seguridad-eventos">Seguridad para Eventos</option><option value="auditoria-seguridad">Auditoría de Seguridad</option></select></div>
          <div class="form-group"><label>Mensaje</label><textarea name="mensaje"></textarea></div>
          <div class="form-submit"><button type="submit" class="btn btn-primary">Enviar mensaje</button></div>
        </form>
      </div>
    </div>
  </div>
</section>

<section class="bg-dark" style="text-align:center;padding:80px 0" data-od-id="cta">
  <div class="container">
    <h2 class="section-title" style="color:#fff">${esc(ctaHeading)}</h2>
    <p class="section-subtitle" style="color:rgba(255,255,255,.7);max-width:500px;margin:0 auto 28px">${esc(ctaSub)}</p>
    <a href="${esc(ctaHref)}" class="btn btn-primary btn-lg">${esc(ctaBtn)}</a>
  </div>
</section>
${buildContactoMap(ci)}</main>`;

  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${SITE_URL}/contacto">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">${jsonld(buildOrganizationSchema())}</head><body>${hdr('light')}${brd([{label:'Inicio',href:'/'},{label:'Contacto'}])}${bodyHtml}${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

// Extrae el contenido no-hero de COTIZACION_HTML (todo después del primer </section>)
const _COTIZACION_AFTER_HERO = (() => {
  const idx = COTIZACION_HTML.indexOf('</section>');
  const after = idx > 0 ? COTIZACION_HTML.substring(idx + '</section>'.length) : COTIZACION_HTML;
  return after.replace(/<\/main>\s*$/, '');
})();

export function buildCotizacionPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Cotizar Seguridad — GuardMan Chile';
  let desc = d?.meta_description || 'Solicita tu cotizacion de seguridad privada sin compromiso.';
  let heroH = d?.hero_heading || 'Cotiza tu Servicio de Seguridad';
  let heroS = d?.hero_subheading || 'Recibe una propuesta personalizada sin compromiso. Respuesta en menos de 24 horas.';
  let trustBadges: string[] = [
    'Certificación OS-10 vigente',
    'Respuesta en menos de 24h',
    'Cotización sin compromiso',
    '8+ años de experiencia'
  ];
  let ctaHeading = '¿Prefieres enviar un WhatsApp?';
  let ctaButton = 'Escribir por WhatsApp';
  let ctaHref = 'https://wa.me/56930000010';

  // Parse content_json for overrides
  if (d?.content_json) {
    try {
      const cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json;
      const seo = cj.seo || {};
      const c = cj.content || cj;
      if (seo.title) title = seo.title;
      if (seo.description) desc = seo.description;
      if (c.hero?.headline) heroH = c.hero.headline;
      if (c.hero?.subheadline) heroS = c.hero.subheadline;
      if (c.trust_badges?.length) {
        trustBadges = c.trust_badges.map((b: any) => typeof b === 'string' ? b : (b.title || b.text || ''));
      }
      if (c.cta?.heading) ctaHeading = c.cta.heading;
      if (c.cta?.button_text) ctaButton = c.cta.button_text;
      if (c.cta?.button_href) ctaHref = c.cta.button_href;
    } catch { /* ignore */ }
  }

  const trustIcons = [
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>`,
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></svg>`
  ];

  const bodyHtml = `<main>
<section class="hero" data-od-id="hero">
  <div class="container">
    <h1>${esc(heroH)}</h1>
    <p>${esc(heroS)}</p>
  </div>
</section>

<div class="trust-badges" data-od-id="trust-badges">
  <div class="container" style="display:flex;justify-content:center;gap:24px;flex-wrap:wrap">
    ${trustBadges.map((b: string, i: number) => `<div class="trust-badge">${trustIcons[i % trustIcons.length]}${esc(b)}</div>`).join('\n    ')}
  </div>
</div>

<section class="bg-neutral" data-od-id="form">
  <div class="container">
    <div class="form-card">
      <h3 style="font-size:22px;font-weight:700;margin-bottom:4px;text-align:center">Solicitar Cotización</h3>
      <p style="color:var(--muted);font-size:15px;margin-bottom:28px;text-align:center">Cuéntanos sobre tus necesidades y te enviaremos una propuesta adaptada.</p>
      <form method="POST" action="/cotizacion">
        <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off">
        <div class="form-row"><div class="form-group"><label>Nombre completo <span class="required">*</span></label><input type="text" name="nombre" required></div><div class="form-group"><label>Correo electrónico <span class="required">*</span></label><input type="email" name="email" required></div></div>
        <div class="form-row"><div class="form-group"><label>Teléfono <span class="required">*</span></label><input type="tel" name="telefono" required></div><div class="form-group"><label>Empresa (opcional)</label><input type="text" name="empresa"></div></div>
        <div class="form-row"><div class="form-group"><label>Comuna donde necesitas el servicio <span class="required">*</span></label><select name="location" required><option value="">Selecciona</option><option value="las-condes">Las Condes</option><option value="vitacura">Vitacura</option><option value="lo-barnechea">Lo Barnechea</option><option value="la-reina">La Reina</option><option value="santiago-centro">Santiago Centro</option><option value="huechuraba">Huechuraba</option><option value="quilicura">Quilicura</option><option value="lampa">Lampa</option><option value="pudahuel">Pudahuel</option><option value="conchali">Conchalí</option><option value="renca">Renca</option><option value="la-pintana">La Pintana</option><option value="los-andes">Los Andes</option><option value="san-felipe">San Felipe</option><option value="otra">Otra</option></select></div><div class="form-group"><label>Servicio de interés <span class="required">*</span></label><select name="service" required><option value="">Selecciona</option><option value="guardias-de-seguridad">Guardias de Seguridad</option><option value="cctv-videovigilancia">CCTV y Videovigilancia</option><option value="control-de-accesos">Control de Accesos</option><option value="monitoreo-24-7">Monitoreo 24/7</option><option value="escoltas-privados">Escoltas Privados</option><option value="guard-pod">Guard Pod</option><option value="seguridad-industrial">Seguridad Industrial</option><option value="seguridad-eventos">Seguridad para Eventos</option><option value="auditoria-seguridad">Auditoría de Seguridad</option><option value="asesoria">No estoy seguro — necesito asesoría</option></select></div></div>
        <div class="form-row"><div class="form-group"><label>Tipo de propiedad</label><select name="tipo_propiedad"><option value="">Selecciona</option><option value="residencial">Residencial / Condominio</option><option value="corporativo">Oficina / Corporativo</option><option value="retail">Comercio / Retail</option><option value="industrial">Bodega / Industrial</option><option value="construccion">Obra en construcción</option><option value="evento">Evento</option><option value="hotel">Hotel</option><option value="salud">Clínica / Hospital</option><option value="educacion">Colegio / Universidad</option><option value="otro">Otro</option></select></div><div class="form-group"><label>¿Cuántos guardias necesitas?</label><select name="cantidad_guardias"><option value="">Selecciona</option><option value="1-2">1-2</option><option value="3-5">3-5</option><option value="6-10">6-10</option><option value="10+">10+</option><option value="no-seguro">No estoy seguro</option></select></div></div>
        <div class="form-group"><label>Describe tu necesidad de seguridad</label><textarea name="mensaje" placeholder="Ej: Necesito 2 guardias para turno nocturno en un condominio en Las Condes..."></textarea></div>
        <div class="form-submit"><button type="submit" class="btn btn-primary">Solicitar Cotización</button></div>
      </form>
    </div>
  </div>
</section>

<div class="whatsapp-cta" data-od-id="whatsapp">
  <div class="container">
    <p style="font-size:16px;color:var(--muted);margin-bottom:16px">${esc(ctaHeading)}</p>
    <a href="${esc(ctaHref)}" class="btn btn-outline btn-lg" style="color:#25D366;border-color:#25D366" onmouseover="this.style.background='#25D366';this.style.color='#fff'" onmouseout="this.style.background='transparent';this.style.color='#25D366'">${esc(ctaButton)}</a>
  </div>
</div>
</main>`;

  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${SITE_URL}/cotizacion">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg">${jsonld(buildOrganizationSchema())}</head><body>${hdr('light')}${brd([{label:'Inicio',href:'/'},{label:'Cotización'}])}${bodyHtml}${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

export function buildPrivacidadPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Politica de Privacidad — GuardMan Chile';
  let desc = d?.meta_description || 'Politica de Privacidad de GuardMan Chile.';
  let bodyHtml = PRIVACIDAD_HTML;
  // Parse content_json for overrides (BUG-03 fix)
  if (d?.content_json) {
    try {
      const cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json;
      const seo = cj.seo || {};
      const c = cj.content || cj;
      if (seo.title) title = seo.title;
      if (seo.description) desc = seo.description;
      if (c.body_content) bodyHtml = c.body_content;
    } catch { /* ignore */ }
  }
  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${SITE_URL}/privacidad">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg">${jsonld(buildOrganizationSchema())}</head><body>${hdr('light')}${brd([{label:'Inicio',href:'/'},{label:'Privacidad'}])}<main>${bodyHtml}</main>${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

export function buildTerminosPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Terminos y Condiciones — GuardMan Chile';
  let desc = d?.meta_description || 'Terminos y Condiciones de GuardMan Chile.';
  let bodyHtml = TERMINOS_HTML;
  // Parse content_json for overrides (BUG-03 fix)
  if (d?.content_json) {
    try {
      const cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json;
      const seo = cj.seo || {};
      const c = cj.content || cj;
      if (seo.title) title = seo.title;
      if (seo.description) desc = seo.description;
      if (c.body_content) bodyHtml = c.body_content;
    } catch { /* ignore */ }
  }
  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${SITE_URL}/terminos">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg">${jsonld(buildOrganizationSchema())}</head><body>${hdr('light')}${brd([{label:'Inicio',href:'/'},{label:'Términos'}])}<main>${bodyHtml}</main>${ftr()}<script src="/scripts/main.js"></script>
</body></html>`;
}

// ═══════════════ 