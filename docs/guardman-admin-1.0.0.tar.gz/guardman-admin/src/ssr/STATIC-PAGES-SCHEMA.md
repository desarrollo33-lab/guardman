# Static Pages Content JSON Schema

Cada página estática guarda `content_json` en `static_page_content`. Este documento define
el formato esperado para que el CMS pueda editar y el SSR pueda renderizar.

## Principio

- Cada campo tiene un default en el HTML canónico (`*-html.ts`)
- Si `content_json` tiene el campo, se usa el override
- Si no, se usa el default del HTML importado
- El CMS envía solo los campos que el usuario modificó

---

## /nosotros

```typescript
interface NosotrosContent {
  seo: {
    title?: string;
    description?: string;
  };
  hero: {
    headline?: string;
    subheadline?: string;
  };
  stats?: Array<{
    value: string;   // "500+"
    label: string;   // "Guardias certificados OS-10 activos"
  }>;
  timeline?: Array<{
    year: string;        // "2017"
    title: string;       // "Fundación"
    description: string; // "GuardMan Chile inicia operaciones..."
  }>;
  values?: Array<{
    title: string;       // "Compromiso"
    description: string; // "Cada cliente recibe un servicio dedicado..."
  }>;
  differentiators?: Array<{
    icon?: string;       // SVG inline o nombre de icono
    title: string;
    description: string;
  }>;
  certifications?: Array<{
    title: string;
    description: string;
  }>;
  staff?: {
    image?: string;
    traits?: string[];
  };
  cta?: {
    heading?: string;
    subheading?: string;
    button_text?: string;
    button_href?: string;
  };
}
```

## /guard-pod

```typescript
interface GuardPodContent {
  seo: {
    title?: string;
    description?: string;
  };
  hero: {
    headline?: string;
    subheadline?: string;
    badge?: string;
  };
  features?: Array<{
    icon?: string;
    title: string;
    description: string;
  }>;
  problems?: Array<{
    description: string;
  }>;
  faqs?: Array<{
    question: string;
    answer: string;
  }>;
  stats?: Array<{
    value: string;
    label: string;
  }>;
}
```

## /ajax-systems

```typescript
interface AjaxContent {
  seo: { title?: string; description?: string; };
  hero: { headline?: string; subheadline?: string; badge?: string; };
  features?: Array<{ title: string; description: string; }>;
  whyUs?: Array<{ description: string; }>;
  faqs?: Array<{ question: string; answer: string; }>;
  stats?: Array<{ value: string; label: string; }>;
}
```

## /contacto

```typescript
interface ContactoContent {
  seo: { title?: string; description?: string; };
  hero: { headline?: string; subheadline?: string; };
  contact?: {
    phone?: string;
    email?: string;
    address?: string;
    hours?: string;
  };
}
```

## /cotizacion

```typescript
interface CotizacionContent {
  seo: { title?: string; description?: string; };
  hero: { headline?: string; subheadline?: string; };
  trust_badges?: Array<{
    icon?: string;
    title: string;
    description?: string;
  }>;
}
```

## /privacidad y /terminos

```typescript
interface LegalContent {
  seo: { title?: string; description?: string; };
  hero: { headline?: string; };
  body_content?: string;  // HTML del cuerpo legal
}
```
