// GuardMan v3.0 — Site Data Fetchers (ESTANDARIZADO)
// Todos los fetchers producen el mismo nivel de detalle que fetchServicePage.
// Cada página de detalle tiene: hero, intro, features, issues, staff, locations, faq, sidebar, related, cta.

import type { SiteData, SectionData } from './site-renderer';
import { buildOrganizationSchema, buildWebSiteSchema, buildFAQSchema, buildLocalBusinessSchema, buildServiceSchema } from './site-renderer';

const PHONE = '+56 9 300 000 10';

const SERVICE_NAMES: Record<string, string> = {
  'guardias-de-seguridad': 'Guardias de Seguridad', 'cctv-videovigilancia': 'CCTV Videovigilancia',
  'control-de-accesos': 'Control de Accesos', 'escoltas-privados': 'Escoltas Privados',
  'monitoreo-24-7': 'Monitoreo 24/7', 'seguridad-eventos': 'Seguridad Eventos',
  'seguridad-industrial': 'Seguridad Industrial', 'auditoria-seguridad': 'Auditoría de Seguridad',
  'guard-pod': 'Guard Pod',
};

const SECTOR_NAMES: Record<string, string> = {
  'residencial': 'Residencial', 'comercial': 'Comercial', 'industrial': 'Industrial',
  'construccion': 'Construcción', 'educacion': 'Educación', 'eventos': 'Eventos',
  'hoteleria': 'Hotelería', 'salud': 'Salud', 'automotriz': 'Automotriz',
};

const ZONE_DOTS: Record<string, string> = {
  'Oriente': 'oriente', 'Centro': 'centro', 'Norte': 'norte',
  'Sur': 'sur', 'Occidente': 'poniente', 'Poniente': 'poniente', 'Valparaíso': 'valparaiso',
};

const DEFAULT_STAFF_TRAITS = [
  'Certificación OS-10 vigente verificada por Carabineros de Chile',
  'Capacitación continua en protocolos de seguridad y emergencias',
  'Centro de monitoreo propio 24/7 con operadores especializados',
  '8+ años de experiencia protegiendo empresas y residencias',
];

function parseJson(s: string | null): any {
  if (!s) return null;
  try { return JSON.parse(s); } catch { return null; }
}

function parseIssues(raw: string | null): string[] {
  if (!raw) return [];
  if (raw.startsWith('[')) return parseJson(raw) || [];
  return raw.split(',').map((s: string) => s.trim()).filter(Boolean);
}

async function getAllLocations(env: any) {
  const { results } = await env.DB.prepare('SELECT slug, name FROM locations ORDER BY name').all();
  return (results as any[]).map(l => ({ slug: l.slug, name: l.name }));
}

async function getAllServices(env: any) {
  const { results } = await env.DB.prepare('SELECT slug, name, short_description, hero_image FROM services ORDER BY sort').all();
  return results as any[];
}

async function getAllSectors(env: any) {
  const { results } = await env.DB.prepare('SELECT slug, name, color_tag FROM sectors ORDER BY name').all();
  return results as any[];
}

// ═══════════════ HOMEPAGE ═══════════════

export async function fetchHomepage(env: any): Promise<SiteData> {
  const [services, sectors, locations] = await Promise.all([getAllServices(env), getAllSectors(env), getAllLocations(env)]);
  // Client logos — fail gracefully if table doesn't exist
  let clientLogos: Array<{name:string;logo_url:string;link?:string}> = [];
  try {
    const result = await env.DB.prepare('SELECT name, logo_url, link FROM client_logos ORDER BY sort_order').all();
    clientLogos = (result?.results || []) as Array<{name:string;logo_url:string;link?:string}>;
  } catch { /* table may not exist yet */ }
  const zonesMap: Record<string, Array<{ slug: string; name: string; lat?: number; lng?: number }>> = {};
  for (const l of (await env.DB.prepare('SELECT slug, name, zone, latitude, longitude FROM locations ORDER BY zone, name').all()).results as any[]) {
    const zone = l.zone || 'Centro';
    if (!zonesMap[zone]) zonesMap[zone] = [];
    zonesMap[zone].push({ slug: l.slug, name: l.name, lat: l.latitude ? parseFloat(l.latitude) : undefined, lng: l.longitude ? parseFloat(l.longitude) : undefined });
  }
  return {
    title: 'GuardMan Chile — Seguridad Privada en Santiago | Guardias OS-10',
    description: 'GuardMan Chile — Empresa de seguridad privada en Santiago. Guardias certificados OS-10, CCTV, control de accesos y monitoreo 24/7. 500+ guardias, 14 comunas. Cotice hoy.',
    canonical: '/', ogImage: '/images/hero-home.webp', pageType: 'homepage',
    heroHeading: 'Seguridad Privada en Santiago, Chile',
    heroSubheading: 'Protegemos lo que más te importa. Guardias certificados, tecnología de vanguardia y un centro de monitoreo propio que nunca duerme.',
    heroImage: '/images/hero-home.webp', heroBadge: 'Certificación OS-10 Vigente',
    heroCtas: [{ text: 'Solicitar Cotización', href: '/cotizacion', variant: 'primary' }, { text: 'Conoce nuestra trayectoria', href: '/nosotros', variant: 'outline-light' }],
    breadcrumbs: [],
    homeNosotrosParagraph: 'Más de 8 años de experiencia protegiendo lo que más te importa. Guardias certificados OS-10 y tecnología de vanguardia para un servicio integral y confiable.',
    homeNosotrosFeatures: [
      { title: 'Guardias certificados OS-10 vigentes', description: 'Personal capacitado y certificado para máxima protección.' },
      { title: 'Cumplimiento Ley 21.659', description: 'Operamos dentro de todas las normativas legales vigentes.' },
      { title: 'Atención 24/7 los 365 días', description: 'Respuesta inmediata en cualquier momento del año.' },
      { title: 'Centro de monitoreo propio', description: 'Supervisión continua desde nuestras instalaciones.' },
    ],
    homeNosotrosImage: '/images/nosotros_seccion.webp',
    homeServices: services.map(s => ({ slug: s.slug, name: s.name, description: s.short_description || '', image: s.hero_image || '/images/hero-home.webp' })),
    homeGuardPodFeatures: [
      { title: 'Despliegue en 2 horas', description: 'Sin necesidad de infraestructura previa.' },
      { title: 'Energía Solar', description: 'Autónomo, sin conexión a red eléctrica.' },
      { title: 'Cámaras PTZ 4K', description: 'Visión nocturna y detección inteligente.' },
      { title: 'Conectividad 4G', description: 'Opera en cualquier ubicación con cobertura.' },
    ],
    homeSectors: sectors.map(s => ({ slug: s.slug, name: s.name, colorClass: s.color_tag || 'tag-blue' })),
    homeAjaxFeatures: [{title:'Certificación Grado 3',description:'Máxima seguridad verificada por estándares internacionales'},{title:'Tecnología Jeweller de largo alcance',description:'Comunicación cifrada con alcance de hasta 2 km'},{title:'App de control total',description:'Controla alarmas, cámaras y sensores desde tu smartphone'},{title:'Monitoreo 24/7',description:'Centro de monitoreo propio que responde en tiempo real'}],
    homeClientLogos: clientLogos,
    homeZones: Object.entries(zonesMap).map(([zone, locs]) => ({ name: zone, dotClass: ZONE_DOTS[zone] || 'centro', locations: locs })),
    schemas: [buildOrganizationSchema(), buildWebSiteSchema()],
  };
}

// ═══════════════ SERVICE PAGE ═══════════════

export async function fetchServicePage(env: any, slug: string): Promise<SiteData | null> {
  const [svc, contentRow, mediaEntity, locations, allServices, allSectors] = await Promise.all([
    env.DB.prepare('SELECT * FROM services WHERE slug = ?').bind(slug).first(),
    env.DB.prepare("SELECT content_json FROM content_versions WHERE entity_type='service' AND entity_slug=? ORDER BY version DESC LIMIT 1").bind(slug).first(),
    env.DB.prepare(`SELECT m.key, m.media_type, m.youtube_id FROM media_entities me JOIN media_library m ON me.media_id = m.id WHERE me.entity_type = 'service' AND me.entity_slug = ? AND me.usage = 'hero' LIMIT 1`).bind(slug).first(),
    getAllLocations(env), getAllServices(env), getAllSectors(env),
  ]);
  if (!svc) return null;

  const s = svc as any;
  const name = s.name || SERVICE_NAMES[slug] || slug;
  const content = parseJson((contentRow as any)?.content_json);
  const sections = content?.sections || content || {};
  const meta = sections.meta || {};
  const sectorsJson = parseJson(s.sectors);

  // Resolve hero image: CMS content_json → media_entities → DB column → default
  let heroImage = sections.hero?.image || '';
  if (!heroImage && mediaEntity) {
    const me = mediaEntity as any;
    heroImage = me.youtube_id ? `yt:${me.youtube_id}` : (me.key ? `/${me.key}` : '');
  }
  if (!heroImage) heroImage = s.hero_image || '';
  if (!heroImage) heroImage = `/images/service-${slug}.webp`;

  const faqs = (sections.faqs?.items || []).length > 0
    ? sections.faqs.items.map((f: any) => ({ question: f.question || '', answer: f.answer || '' }))
    : [{ question: '¿Qué incluye el servicio?', answer: `Nuestro servicio de ${name.toLowerCase()} incluye personal certificado OS-10, monitoreo 24/7, supervisión permanente y respuesta inmediata. Todo adaptado a las necesidades específicas de cada cliente.` }, { question: '¿En qué comunas está disponible?', answer: `Cubrimos 14 comunas de la Región Metropolitana más Los Andes y San Felipe. Contáctanos para verificar disponibilidad en tu ubicación específica.` }, { question: '¿Cómo solicito una cotización?', answer: `Puedes solicitar una cotización sin compromiso a través de nuestro formulario web, llamando al ${PHONE}, o enviando un correo a info@guardman.cl.` }];

  return {
    title: meta.title || `${name} en Santiago | GuardMan Chile OS-10`,
    description: meta.description || s.short_description || `${name} certificados OS-10 en Santiago. Cotice hoy.`,
    canonical: `/servicios/${slug}`, ogImage: (heroImage.startsWith('yt:') ? '' : heroImage) || `/images/service-${slug}.webp`, pageType: 'service',
    _serviceSlug: slug,
    heroHeading: sections.hero?.heading || `${name} en Santiago`,
    heroSubheading: sections.hero?.subheading || s.short_description || '',
    heroImage,
    heroCtas: [{ text: 'Cotizar Ahora', href: `/cotizacion?service=${slug}`, variant: 'outline-light' }, { text: 'Ver cobertura', href: '/ubicaciones', variant: 'outline-light' }],
    breadcrumbs: [{ label: 'Inicio', href: '/' }, { label: 'Servicios', href: '/servicios' }, { label: name }],
    introHeading: sections.intro?.heading || `Servicio de ${name} Confiable y Profesional`,
    introParagraphs: (sections.intro?.paragraphs || []).length >= 3 ? sections.intro.paragraphs : [
      `En GuardMan Chile ofrecemos ${name.toLowerCase()} con los más altos estándares de calidad y certificación OS-10 vigente. Nuestro equipo está compuesto por profesionales altamente capacitados y con amplia experiencia en el rubro de la seguridad privada.`,
      `Contamos con presencia en 14 comunas de Santiago y regiones, lo que nos permite ofrecer cobertura completa y tiempos de respuesta óptimos. Cada servicio se adapta a las necesidades específicas de cada cliente.`,
      `Todos nuestros servicios incluyen monitoreo 24/7 desde nuestro centro de control propio, supervisión permanente y protocolos de respuesta inmediata ante cualquier incidente.`,
    ],
    features: (sections.features?.items || []).length > 0 ? sections.features.items : [
      'Personal certificado OS-10 vigente con formación continua', 'Cobertura en 14 comunas de la Región Metropolitana',
      'Monitoreo 24/7 desde centro de control propio', 'Supervisión permanente en terreno',
      'Protocolos de respuesta inmediata', 'Vehículos de reacción rápida',
      'Tecnología de comunicación encriptada', 'Reportes diarios de novedades',
    ],
    featuresTitle: sections.features?.heading || '¿Por qué elegir nuestros servicios?',
    issues: sections.issues?.items || [
      'Robos y hurtos en instalaciones', 'Accesos no autorizados', 'Falta de control en horarios no laborales',
      'Vandalismo en espacios comunes', 'Necesidad de vigilancia perimetral', 'Coordinación lenta ante emergencias',
    ],
    faqs,
    // Staff: from content_json or defaults
    staffImage: sections.staff?.image || sections.hero?.staff_image || '/images/nosotros_seccion.webp',
    staffTraits: sections.staff?.traits || DEFAULT_STAFF_TRAITS,
    locations: locations,
    // Sidebar CTA: from content_json or default
    sidebarCtaHeading: sections.sidebar?.cta_heading || '¿Necesitas este servicio?',
    sidebarLinks: allServices.filter(sv => sv.slug !== slug).slice(0, 6).map(sv => ({ label: sv.name, href: `/servicios/${sv.slug}` })),
    sidebarLinksTitle: 'Otros servicios',
    sidebarTags: (Array.isArray(sectorsJson) ? sectorsJson : []).slice(0, 5).map((sec: string) => ({ label: SECTOR_NAMES[sec] || sec, colorClass: sec, href: `/sectores/${sec}` })),
    relatedItems: allServices.filter(sv => sv.slug !== slug).slice(0, 3).map(sv => ({ title: sv.name, description: sv.short_description || `Servicio profesional de ${sv.name.toLowerCase()}`, href: `/servicios/${sv.slug}` })),
    ctaHeading: sections.cta?.heading || `Solicita tu cotización de ${name.toLowerCase()}`,
    ctaSubheading: sections.cta?.subheading || 'Evaluación gratuita sin compromiso. Respuesta en menos de 24 horas.',
    ctaButtonText: sections.cta?.button_text || 'Cotizar Ahora',
    ctaButtonHref: sections.cta?.button_href || `/cotizacion?service=${slug}`,
    schemas: [buildOrganizationSchema(), buildServiceSchema({ title: meta.title || name, description: meta.description || '', canonical: `/servicios/${slug}`, pageType: 'service', heroHeading: name, breadcrumbs: [] } as SiteData)],
  };
}

// ═══════════════ SECTOR PAGE ═══════════════

export async function fetchSectorPage(env: any, slug: string): Promise<SiteData | null> {
  const [sec, contentRow, services, locations, allSectors] = await Promise.all([
    env.DB.prepare('SELECT * FROM sectors WHERE slug = ?').bind(slug).first(),
    env.DB.prepare("SELECT content_json FROM content_versions WHERE entity_type='sector' AND entity_slug=? ORDER BY version DESC LIMIT 1").bind(slug).first(),
    getAllServices(env), getAllLocations(env), getAllSectors(env),
  ]);
  if (!sec) return null;

  const s = sec as any;
  const name = s.name || SECTOR_NAMES[slug] || slug;
  const colorTag = s.color_tag || 'tag-blue';
  const content = parseJson((contentRow as any)?.content_json);
  const sections = content?.sections || content || {};
  const meta = sections.meta || {};
  const issues = parseIssues(s.issues);

  return {
    title: meta.title || `Seguridad ${name} | GuardMan Chile`,
    description: meta.description || `Seguridad para el sector ${name.toLowerCase()}. GuardMan Chile: guardias OS-10, monitoreo 24/7. Cotización gratuita.`,
    canonical: `/sectores/${slug}`, ogImage: s.hero_image || `/images/sector-${slug}.webp`, pageType: 'sector',
    heroHeading: sections.hero?.heading || `Seguridad para el Sector ${name}`,
    heroSubheading: sections.hero?.subheading || `Soluciones especializadas de seguridad para el sector ${name.toLowerCase()} con guardias certificados OS-10 y monitoreo 24/7.`,
    heroImage: s.hero_image || `/images/sector-${slug}.webp`,
    heroTag: { label: `Sector ${name}`, colorClass: colorTag },
    heroCtas: [{ text: 'Cotizar Ahora', href: '/cotizacion', variant: 'outline-light' }],
    breadcrumbs: [{ label: 'Inicio', href: '/' }, { label: 'Sectores', href: '/sectores' }, { label: name }],
    introHeading: sections.intro?.heading || `Seguridad ${name} Profesional en Chile`,
    introParagraphs: (sections.intro?.paragraphs || []).length >= 3 ? sections.intro.paragraphs : [
      `La seguridad en el sector ${name.toLowerCase()} requiere soluciones especializadas. En GuardMan Chile entendemos las necesidades particulares de cada rubro y diseñamos planes de seguridad a medida con personal certificado OS-10.`,
      `Contamos con años de experiencia protegiendo instalaciones del sector ${name.toLowerCase()} en toda la Región Metropolitana, con protocolos actualizados según la normativa vigente.`,
      `Nuestro enfoque preventivo y nuestra capacidad de respuesta inmediata nos convierten en el aliado estratégico que tu empresa necesita para operar con tranquilidad.`,
    ],
    features: (sections.features?.items || []).length > 0 ? sections.features.items : [
      'Guardias certificados OS-10 vigentes con formación profesional continua', 'Cobertura 24/7 los 365 días del año con turnos rotativos',
      'Control de acceso y registro de visitantes', 'Rondas perimetrales programadas según necesidades del sector',
      'Monitoreo integrado con nuestro centro de operaciones 24/7', 'Coordinación directa con Carabineros y equipos de emergencia',
      'Reportes de actividad diaria y alertas en tiempo real', 'Supervisión permanente por Jefes de Turno experimentados',
    ],
    featuresTitle: sections.features?.heading || '¿Qué incluye nuestro servicio?',
    issues: issues.length > 0 ? issues : (sections.issues?.items || ['Robo de materiales y equipos', 'Accesos no autorizados', 'Vandalismo en horarios no laborales', 'Falta de control de visitantes', 'Riesgos de seguridad laboral', 'Pérdidas por hurtos internos']),
    faqs: (sections.faqs?.items || []).length > 0 ? sections.faqs.items.map((f: any) => ({ question: f.question || '', answer: f.answer || '' })) : [
      { question: `¿Cuánto cuesta la seguridad para el sector ${name.toLowerCase()}?`, answer: 'El precio varía según el tipo de instalación, la cantidad de guardias necesarios y el nivel de riesgo. Recomendamos solicitar una cotización personalizada donde evaluamos tus necesidades específicas sin compromiso.' },
      { question: '¿Qué diferencia a un guardia con certificación OS-10?', answer: 'La certificación OS-10 es un requisito legal en Chile que garantiza que el profesional ha completado formación técnica en prevención, control de acceso, primeros auxilios y normativa legal vigente.' },
      { question: '¿Puedo contratar servicios solo para horarios específicos?', answer: 'Sí, ofrecemos pautas flexibles: turnos diurnos, nocturnos, 4x4, 6x1, o cobertura 24/7 continua según las necesidades de tu instalación.' },
    ],
    staffImage: '/images/nosotros_seccion.webp', staffTraits: DEFAULT_STAFF_TRAITS,
    locations,
    sidebarCtaHeading: 'Protege tu empresa',
    sidebarLinks: services.slice(0, 6).map(sv => ({ label: sv.name, href: `/servicios/${sv.slug}` })),
    sidebarLinksTitle: 'Otros servicios',
    sidebarTags: allSectors.filter(sec => (sec as any).slug !== slug).slice(0, 5).map(sec => ({ label: (sec as any).name, colorClass: (sec as any).slug, href: `/sectores/${(sec as any).slug}` })),
    relatedItems: services.slice(0, 3).map(sv => ({ title: sv.name, description: sv.short_description || `Servicio profesional de ${sv.name.toLowerCase()}`, href: `/servicios/${sv.slug}` })),
    ctaHeading: 'Protege tu empresa hoy',
    ctaSubheading: 'Solicita una cotización personalizada. Guardias certificados OS-10, cobertura en 14 comunas.',
    ctaButtonText: 'Solicitar Cotización', ctaButtonHref: '/cotizacion',
    schemas: [buildOrganizationSchema()],
  };
}

// ═══════════════ LOCATION PAGE ═══════════════

export async function fetchLocationPage(env: any, slug: string): Promise<SiteData | null> {
  const [loc, services, locations, allSectors] = await Promise.all([
    env.DB.prepare('SELECT * FROM locations WHERE slug = ?').bind(slug).first(),
    env.DB.prepare("SELECT DISTINCT s.slug, s.name, s.short_description FROM services s JOIN combo_content cc ON cc.service_slug=s.slug WHERE cc.location_slug=?").bind(slug).all(),
    getAllLocations(env), getAllSectors(env),
  ]);
  if (!loc) return null;

  const l = loc as any;
  const name = l.name || slug;
  const zone = l.zone || 'Centro';
  const zoneDot = ZONE_DOTS[zone] || 'centro';
  const svcList = (services.results as any[]) || [];

  return {
    title: `Seguridad Privada en ${name} | GuardMan Chile`,
    description: `GuardMan Chile ofrece servicios de seguridad privada en ${name}. Guardias certificados OS-10, CCTV, control de accesos y monitoreo 24/7. Zona ${zone}. Cotice sin compromiso.`,
    canonical: `/ubicaciones/${slug}`, ogImage: l.image || `/images/location-${slug}.webp`, pageType: 'location',
    heroHeading: `Seguridad Privada en ${name}`,
    heroSubheading: `Protegemos ${name} con guardias certificados OS-10 y monitoreo 24/7. Cobertura completa en la zona ${zone}.`,
    heroImage: l.image || `/images/location-${slug}.webp`,
    zoneDot, zoneLabel: `Zona ${zone}`,
    heroCtas: [{ text: 'Cotizar Ahora', href: `/cotizacion?location=${slug}`, variant: 'outline-light' }, { text: 'Ver servicios', href: '#servicios', variant: 'outline-light' }],
    breadcrumbs: [{ label: 'Inicio', href: '/' }, { label: 'Ubicaciones', href: '/ubicaciones' }, { label: name }],
    introHeading: `Seguridad en ${name}, zona ${zone}`,
    introParagraphs: [
      `GuardMan Chile tiene presencia activa en ${name} desde hace más de 5 años, protegiendo condominios, oficinas, comercios y residencias particulares con personal altamente capacitado y certificado OS-10.`,
      `Esta comuna de la zona ${zone} presenta características específicas que requieren soluciones de seguridad adaptadas. Nuestro equipo conoce el territorio y está distribuido estratégicamente para maximizar la cobertura.`,
      `Todos nuestros guardias en ${name} cuentan con certificación OS-10 vigente, verificación de antecedentes y capacitación continua en protocolos de seguridad y emergencias.`,
    ],
    features: [
      'Guardias certificados OS-10 con verificación de antecedentes', 'Cobertura 24/7 los 365 días del año',
      'Monitoreo desde nuestro centro de control propio', 'Tiempo de respuesta optimizado para la zona',
      'Rondas preventivas programadas según perfil de riesgo', 'Coordinación directa con Carabineros',
      'Reportes diarios de novedades', 'Supervisión permanente por Jefes de Turno',
    ],
    featuresTitle: '¿Qué incluye nuestro servicio en esta comuna?',
    issues: [
      `Robos y hurtos en viviendas y comercios de ${name}`, 'Accesos no autorizados a condominios y edificios',
      'Falta de control de visitantes y proveedores', 'Vandalismo en espacios públicos y áreas comunes',
      'Necesidad de vigilancia perimetral efectiva', 'Coordinación lenta ante emergencias de seguridad',
    ],
    faqs: [
      { question: `¿Qué servicios de seguridad ofrecen en ${name}?`, answer: `En ${name} ofrecemos guardias de seguridad, CCTV, control de accesos, monitoreo 24/7 y más. Todos con certificación OS-10 vigente y adaptados a las necesidades específicas de la comuna.` },
      { question: `¿Cuál es el tiempo de respuesta en ${name}?`, answer: `Nuestro tiempo de respuesta en ${name} es de menos de 15 minutos para incidentes prioritarios. Contamos con vehículos de reacción rápida desplegados estratégicamente en la zona ${zone}.` },
      { question: `¿Los guardias tienen certificación OS-10 en ${name}?`, answer: `Sí, todos nuestros guardias desplegados en ${name} cuentan con certificación OS-10 vigente emitida por la Prefectura de Seguridad Privada de Carabineros de Chile.` },
    ],
    staffImage: '/images/nosotros_seccion.webp', staffTraits: DEFAULT_STAFF_TRAITS,
    mapEnabled: true, mapLat: parseFloat(l.latitude) || -33.45, mapLng: parseFloat(l.longitude) || -70.65, mapZoom: 14,
    locations,
    locationServices: svcList.map((s: any) => ({ slug: s.slug, name: s.name, href: `/servicios/${s.slug}/${slug}` })),
    sidebarCtaHeading: 'Protege tu propiedad',
    sidebarLinks: svcList.map(s => ({ label: s.name, href: `/servicios/${s.slug}/${slug}` })),
    sidebarLinksTitle: 'Servicios disponibles',
    sidebarTags: allSectors.slice(0, 5).map(s => ({ label: (s as any).name, colorClass: (s as any).slug, href: `/sectores/${(s as any).slug}` })),
    relatedItems: svcList.slice(0, 3).map(s => ({ title: s.name, description: `Servicio profesional disponible en ${name}`, href: `/servicios/${s.slug}/${slug}` })),
    ctaHeading: `Cotiza seguridad para ${name}`,
    ctaSubheading: 'Evaluación gratuita sin compromiso. Cubrimos toda la comuna.',
    ctaButtonText: 'Solicitar Cotización', ctaButtonHref: `/cotizacion?location=${slug}`,
    schemas: [buildOrganizationSchema(), buildLocalBusinessSchema('Seguridad Privada', `GuardMan Chile en ${name}`, name)],
  };
}

// ═══════════════ COMBO PAGE ═══════════════

export async function fetchComboPage(env: any, serviceSlug: string, locationSlug: string): Promise<SiteData | null> {
  const [combo, svc, loc, locations, services, allSectors] = await Promise.all([
    env.DB.prepare('SELECT * FROM combo_content WHERE service_slug=? AND location_slug=?').bind(serviceSlug, locationSlug).first(),
    env.DB.prepare('SELECT * FROM services WHERE slug=?').bind(serviceSlug).first(),
    env.DB.prepare('SELECT * FROM locations WHERE slug=?').bind(locationSlug).first(),
    getAllLocations(env), getAllServices(env), getAllSectors(env),
  ]);
  if (!svc || !loc) return null;

  const service = svc as any; const location = loc as any;
  const serviceName = service.name || SERVICE_NAMES[serviceSlug] || serviceSlug;
  const locationName = location.name || locationSlug;
  const zone = location.zone || 'Centro';
  const content = parseJson((combo as any)?.content_json);
  const sections = content?.sections || content || {};
  const meta = sections.meta || {};

  return {
    title: meta.title || `${serviceName} en ${locationName} | GuardMan Chile`,
    description: meta.description || `${serviceName} en ${locationName}. Guardias OS-10 certificados. Cotice hoy.`,
    canonical: `/servicios/${serviceSlug}/${locationSlug}`, pageType: 'combo',
    heroHeading: `${serviceName} en ${locationName}`,
    heroSubheading: sections.hero?.subheading || `Servicio profesional de ${serviceName.toLowerCase()} con certificación OS-10 en ${locationName}`,
    heroImage: service.hero_image || `/images/service-${serviceSlug}.webp`,
    heroBadges: [serviceName, `${locationName} · Zona ${zone}`],
    zoneDot: ZONE_DOTS[zone] || 'centro', zoneLabel: `Zona ${zone}`,
    heroCtas: [{ text: 'Cotizar Ahora', href: `/cotizacion?service=${serviceSlug}&location=${locationSlug}`, variant: 'outline-light' }],
    breadcrumbs: [{ label: 'Inicio', href: '/' }, { label: 'Servicios', href: '/servicios' }, { label: serviceName, href: `/servicios/${serviceSlug}` }, { label: locationName }],
    introHeading: `¿Por qué elegir ${serviceName} en ${locationName}?`,
    introParagraphs: (sections.intro?.paragraphs || []).length >= 3 ? sections.intro.paragraphs : [
      `${serviceName} en ${locationName} está diseñado para cubrir las necesidades específicas de esta comuna de la zona ${zone}. Nuestro equipo conoce el territorio y está preparado para responder con eficiencia.`,
      `Como empresa con certificación OS-10 y más de 8 años de experiencia, ofrecemos un servicio de seguridad adaptado a las características de ${locationName}, con tiempos de respuesta optimizados.`,
      `Todos nuestros guardias en ${locationName} cuentan con certificación OS-10 vigente, verificación de antecedentes y capacitación continua en protocolos de seguridad.`,
    ],
    features: (sections.features?.items || []).length > 0 ? sections.features.items : [
      'Personal certificado OS-10 vigente', 'Conocimiento del territorio y sus riesgos',
      'Tiempo de respuesta optimizado', 'Monitoreo 24/7 desde centro de control',
      'Vehículos de reacción rápida en la comuna', 'Protocolos adaptados a la realidad local',
      'Reportes diarios de novedades', 'Supervisión permanente en terreno',
    ],
    featuresTitle: sections.features?.heading || `Beneficios de ${serviceName} en ${locationName}`,
    issues: sections.issues?.items || [
      `Robos en viviendas y comercios de ${locationName}`, 'Accesos no autorizados en horario nocturno',
      'Falta de control de visitantes en edificios', `Vandalismo en espacios públicos de ${locationName}`,
      'Necesidad de patrullaje preventivo', 'Coordinación lenta ante emergencias',
    ],
    faqs: (sections.faqs?.items || []).length > 0 ? sections.faqs.items.map((f: any) => ({ question: f.question || '', answer: f.answer || '' })) : [
      { question: `¿Hay ${serviceName.toLowerCase()} disponibles en ${locationName}?`, answer: `Sí, GuardMan Chile cuenta con ${serviceName.toLowerCase()} certificados OS-10 disponibles en ${locationName}. Nuestro equipo está desplegado en la zona con capacidad de respuesta inmediata.` },
      { question: `¿Cuánto cuesta ${serviceName.toLowerCase()} en ${locationName}?`, answer: `El costo depende del tipo de servicio, jornada y cantidad de personal requerida. Ofrecemos cotizaciones personalizadas sin compromiso. Contáctenos para una evaluación gratuita.` },
      { question: `¿Qué zonas de ${locationName} cubren?`, answer: `Cubrimos todos los sectores de ${locationName}. Nuestro equipo está distribuido estratégicamente para maximizar la cobertura y minimizar los tiempos de respuesta en toda la comuna.` },
    ],
    staffImage: '/images/nosotros_seccion.webp', staffTraits: DEFAULT_STAFF_TRAITS,
    locations,
    sidebarCtaHeading: 'Cotiza este servicio',
    sidebarLinks: services.filter(s => s.slug !== serviceSlug).slice(0, 6).map(s => ({ label: s.name, href: `/servicios/${s.slug}/${locationSlug}` })),
    sidebarLinksTitle: 'Otros servicios en esta comuna',
    sidebarTags: allSectors.slice(0, 5).map(s => ({ label: (s as any).name, colorClass: (s as any).slug, href: `/sectores/${(s as any).slug}` })),
    relatedItems: services.filter(s => s.slug !== serviceSlug).slice(0, 3).map(s => ({ title: s.name, description: `También disponible en ${locationName}`, href: `/servicios/${s.slug}/${locationSlug}` })),
    ctaHeading: `Cotiza ${serviceName.toLowerCase()} en ${locationName}`,
    ctaSubheading: 'Evaluación gratuita sin compromiso. Cubrimos toda la comuna.',
    ctaButtonText: 'Cotizar Ahora', ctaButtonHref: `/cotizacion?service=${serviceSlug}&location=${locationSlug}`,
    schemas: [buildOrganizationSchema(), buildLocalBusinessSchema(serviceName, `${serviceName} en ${locationName}`, locationName)],
  };
}

// ═══════════════ HUB PAGES ═══════════════
export async function fetchHubPage(env: any, path: string): Promise<SiteData | null> {
  const type = path === '/servicios' ? 'servicios' : path === '/sectores' ? 'sectores' : 'ubicaciones';
  
  if (type === 'ubicaciones') {
    const { results: locs } = await env.DB.prepare('SELECT slug, name, zone, latitude, longitude FROM locations ORDER BY zone, name').all();
    const zonesMap: Record<string, Array<{slug:string;name:string}>> = {};
    const markers: Array<{name:string;lat:number;lng:number;color:string;slug:string}> = [];
    const ZD: Record<string,string> = {'Oriente':'oriente','Centro':'centro','Norte':'norte','Sur':'sur','Poniente':'poniente','Occidente':'poniente','Valparaíso':'valparaiso'};
    const ZC: Record<string,string> = {'Oriente':'#10B981','Centro':'#3B82F6','Norte':'#F59E0B','Sur':'#EF4444','Poniente':'#8B5CF6','Occidente':'#8B5CF6','Valparaíso':'#14B8A6'};
    for (const l of locs as any[]) {
      const z = l.zone || 'Centro';
      if (!zonesMap[z]) zonesMap[z] = [];
      zonesMap[z].push({ slug: l.slug, name: l.name });
      if (l.latitude && l.longitude) {
        markers.push({ name: l.name, lat: parseFloat(l.latitude), lng: parseFloat(l.longitude), color: ZC[z]||'#3B82F6', slug: l.slug });
      }
    }
    return {
      title: 'Cobertura de Seguridad en Santiago | GuardMan Chile',
      description: 'GuardMan Chile cubre 14 comunas de Santiago. Encuentra tu comuna.',
      canonical: '/ubicaciones', pageType: 'ubicaciones', heroHeading: '', breadcrumbs: [{label:'Inicio',href:'/'},{label:'Ubicaciones'}],
      hubZones: Object.entries(zonesMap).map(([z,ls]) => ({ name: z, dotClass: ZD[z]||'centro', locations: ls })),
      mapEnabled: true, mapLat: -33.45, mapLng: -70.65, mapZoom: 10, mapMarkers: markers,
    } as any;
  }

  const isSvc = type === 'servicios';
  const { results } = await env.DB.prepare(`SELECT slug, name, ${isSvc?'short_description':'description'} as desc_text, hero_image${isSvc?'':', color_tag'} FROM ${isSvc?'services':'sectors'} ORDER BY ${isSvc?'sort':'name'}`).all();
  return {
    title: isSvc ? 'Servicios de Seguridad Privada | GuardMan Chile' : 'Seguridad por Sector | GuardMan Chile',
    description: isSvc ? 'GuardMan Chile: guardias de seguridad, CCTV, control de accesos y más. Certificación OS-10. 14 comunas.' : 'Soluciones de seguridad especializadas por sector industrial.',
    canonical: `/${type}`, pageType: type, heroHeading: '',
    breadcrumbs: [{label:'Inicio',href:'/'},{label:isSvc?'Servicios':'Sectores'}],
    hubItems: (results as any[]).map((r:any) => ({
      name: r.name, description: r.desc_text || '',
      image: r.hero_image || `/images/${isSvc?'service':'sector'}-${r.slug}.webp`,
      href: `/${isSvc?'servicios':'sectores'}/${r.slug}`,
      tag: isSvc ? undefined : (r.color_tag || 'tag-blue'),
    })),
  } as any;
}


