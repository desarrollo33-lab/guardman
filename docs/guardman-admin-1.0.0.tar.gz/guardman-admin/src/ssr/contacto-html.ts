export const CONTACTO_HTML = `<main>
<section class="hero" data-od-id="hero">
  <div class="container">
    <h1>Contáctanos</h1>
    <p>Estamos disponibles las 24 horas, los 7 días de la semana. Habla con un experto en seguridad.</p>
  </div>
</section>

<section class="bg-neutral" data-od-id="contacto-info">
  <div class="container section-grid">
    <div>
      <span class="section-label">Información de contacto</span>
      <h2 class="section-title">Estamos aquí para ayudarte</h2>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg></div><div class="contact-info-text"><h4>Teléfono</h4><a href="tel:+56930000010">+56 9 300 000 10</a></div></div>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></div><div class="contact-info-text"><h4>Email</h4><a href="mailto:info@guardman.cl">info@guardman.cl</a><p style="margin-top:4px">Ventas: <a href="mailto:ventas@guardman.cl">ventas@guardman.cl</a></p></div></div>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg></div><div class="contact-info-text"><h4>Dirección</h4><p>Av. Américo Vespucio Norte 1980, Providencia, Santiago, Chile</p></div></div>
      <div class="contact-info-card"><div class="contact-info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><div class="contact-info-text"><h4>Horario</h4><p>Lunes a Domingo: 24 horas</p></div></div>
    </div>
    <div>
      <div class="form-card" data-od-id="form">
        <h3 style="font-size:22px;font-weight:700;margin-bottom:4px">Envíanos un mensaje</h3>
        <p style="color:var(--muted);font-size:15px;margin-bottom:24px">Completa el formulario y te responderemos en menos de 24 horas.</p>
        <form method="POST" action="/contacto">
          <input type="text" name="_honey" style="display:none" tabindex="-1" autocomplete="off">
          <div class="form-row"><div class="form-group"><label>Nombre completo <span class="required">*</span></label><input type="text" name="nombre" required></div><div class="form-group"><label>Correo electrónico <span class="required">*</span></label><input type="email" name="email" required></div></div>
          <div class="form-row"><div class="form-group"><label>Teléfono <span class="required">*</span></label><input type="tel" name="telefono" required></div><div class="form-group"><label>Comuna</label><input type="text" name="location"></div></div>
          <div class="form-group"><label>Servicio de interés <span class="required">*</span></label><select name="service" required><option value="">Selecciona una opción</option><option value="guardias-de-seguridad">Guardias de Seguridad</option><option value="cctv-videovigilancia">CCTV y Videovigilancia</option><option value="control-de-accesos">Control de Accesos</option><option value="monitoreo-24-7">Monitoreo 24/7</option><option value="escoltas-privados">Escoltas Privados</option><option value="guard-pod">Guard Pod</option><option value="seguridad-industrial">Seguridad Industrial</option><option value="seguridad-eventos">Seguridad para Eventos</option><option value="auditoria-seguridad">Auditoría de Seguridad</option></select></div>
          <div class="form-group"><label>Mensaje</label><textarea name="mensaje"></textarea></div>
          <div class="form-submit"><button type="submit" class="btn btn-primary">Enviar mensaje</button></div>
        </form>
      </div>
    </div>
  </div>
</section>

<section class="bg-dark" style="text-align:center;padding:80px 0" data-od-id="cta">
  <div class="container">
    <h2 class="section-title" style="color:#fff">¿Prefieres que te llamemos?</h2>
    <p class="section-subtitle" style="color:rgba(255,255,255,.7);max-width:500px;margin:0 auto 28px">Déjanos tu número y un experto en seguridad te contactará en menos de 2 horas.</p>
    <a href="tel:+56930000010" class="btn btn-primary btn-lg">Solicitar Llamada</a>
  </div>
</section>
</main>`;
