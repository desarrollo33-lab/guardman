export const NOSOTROS_HTML = `<main>
<section class="hero" data-od-id="hero">
  <div class="container">
    <h1>Protegemos lo que más te importa desde 2017</h1>
    <p>GuardMan Chile nació con una convicción: la seguridad privada en Chile merecía un estándar más alto. Más de 8 años después, somos la opción de 200+ empresas y protegemos 14 comunas de la Región Metropolitana.</p>
  </div>
</section>

<div class="stats-row" data-od-id="stats">
  <div class="container stats-grid">
    <div class="stat-item"><div class="stat-value">500+</div><div class="stat-label">Guardias certificados OS-10 activos</div></div>
    <div class="stat-item"><div class="stat-value">200+</div><div class="stat-label">Empresas que confían</div></div>
    <div class="stat-item"><div class="stat-value">14</div><div class="stat-label">Comunas cobertura RM</div></div>
    <div class="stat-item"><div class="stat-value">8+</div><div class="stat-label">Años de experiencia</div></div>
  </div>
</div>

<section class="bg-white" data-od-id="historia">
  <div class="container" style="max-width:760px">
    <span class="section-label">Nuestra Historia</span>
    <h2 class="section-title">De una oficina en Providencia a la empresa de seguridad más confiable de Santiago</h2>
    <p class="section-subtitle" style="color:var(--muted);max-width:none">Fundada en 2017, GuardMan Chile surgió al identificar una brecha crítica en el mercado chileno: empresas que ofrecían guardias de seguridad sin la formación, certificación ni respaldo que exige la ley. Decidimos hacerlo distinto.</p>
    <div class="timeline">
      <div class="timeline-item"><div class="timeline-year">2017</div><div class="timeline-content"><h3>Fundación</h3><p>GuardMan Chile inicia operaciones desde una oficina en Providencia con 12 guardias. Primer contrato: un condominio en Las Condes.</p></div></div>
      <div class="timeline-item"><div class="timeline-year">2019</div><div class="timeline-content"><h3>Academia OS-10 propia</h3><p>Abrimos nuestra academia de formación para certificar guardias con estándares que van más allá del mínimo legal. Dejamos de depender de terceros para la calidad de nuestro equipo.</p></div></div>
      <div class="timeline-item"><div class="timeline-year">2021</div><div class="timeline-content"><h3>Centro de monitoreo propio</h3><p>Inauguramos nuestro centro de monitoreo 24/7. No tercerizamos la supervisión: cada cámara, cada alarma, cada guardia es monitoreado por nuestro equipo.</p></div></div>
      <div class="timeline-item"><div class="timeline-year">2024</div><div class="timeline-content"><h3>Guard Pod V1</h3><p>Tras 15 meses de I+D, lanzamos el Guard Pod: una unidad autónoma de vigilancia con energía solar, cámaras PTZ 360° y monitoreo remoto. Tecnología 100% GuardMan.</p></div></div>
      <div class="timeline-item"><div class="timeline-year">2025</div><div class="timeline-content"><h3>500 guardias, 14 comunas</h3><p>Alcanzamos los 500 guardias activos y expandimos cobertura a 14 comunas de la RM más Los Andes y San Felipe. Nos convertimos en la opción preferida de 200+ empresas.</p></div></div>
    </div>
  </div>
</section>

<section class="bg-neutral" data-od-id="valores">
  <div class="container">
    <span class="section-label">Nuestros Valores</span>
    <h2 class="section-title">Nuestros Valores</h2>
    <div class="values-grid">
      <div class="value-card"><h4>Compromiso</h4><p>Cada cliente recibe un servicio dedicado y personalizado.</p></div>
      <div class="value-card"><h4>Profesionalismo</h4><p>Guardias certificados, equipamiento de calidad y protocolos probados.</p></div>
      <div class="value-card"><h4>Innovación</h4><p>Invertimos en tecnología propia como Guard Pod para ofrecer soluciones únicas.</p></div>
      <div class="value-card"><h4>Transparencia</h4><p>Reportes periódicos, métricas de gestión y comunicación constante.</p></div>
    </div>
  </div>
</section>

<section class="bg-white" data-od-id="diferenciadores">
  <div class="container">
    <span class="section-label">¿Qué nos diferencia?</span>
    <h2 class="section-title">¿Qué nos diferencia?</h2>
    <p class="section-subtitle" style="color:var(--muted);max-width:600px">En seguridad, los detalles marcan la diferencia entre un servicio profesional y uno que solo cumple el mínimo.</p>
    <div class="differentiators-grid">
      <div class="diff-card"><div class="diff-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div><h3>Academia OS-10 propia</h3><p>Formamos a nuestros guardias internamente. No dependemos de terceros para certificar la calidad de nuestro equipo.</p></div>
      <div class="diff-card"><div class="diff-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/></svg></div><h3>Centro de monitoreo propio</h3><p>No tercerizamos la supervisión. Cada cámara y alarma se monitorea desde nuestras instalaciones con redundancia.</p></div>
      <div class="diff-card"><div class="diff-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg></div><h3>Cobertura regional</h3><p>Presencia en 14 comunas más Los Andes y San Felipe. Escala que ningún otro operador local ofrece en la RM.</p></div>
      <div class="diff-card"><div class="diff-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></div><h3>Guard Pod V1</h3><p>Unidad autónoma de vigilancia 24/7 con 15 meses de desarrollo propio. Tecnología única en Chile.</p></div>
      <div class="diff-card"><div class="diff-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div><h3>Respuesta inmediata certificada</h3><p>Tiempos de respuesta garantizados con protocolos de coordinación directa con Carabineros.</p></div>
      <div class="diff-card"><div class="diff-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg></div><h3>Supervisión nocturna preventiva</h3><p>Monitoreo proactivo de conductas sospechosas durante turnos nocturnos.</p></div>
    </div>
  </div>
</section>

<section class="bg-neutral" data-od-id="certificaciones">
  <div class="container">
    <span class="section-label">Certificaciones</span>
    <h2 class="section-title">Certificaciones y cumplimiento</h2>
    <p class="section-subtitle" style="color:var(--muted);max-width:600px">Operamos dentro del marco legal chileno con todas las certificaciones exigidas. Tu tranquilidad empieza por la legalidad de quien te protege.</p>
    <div class="cert-grid">
      <div class="cert-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg><div><h4>Certificación OS-10 vigente</h4><p>Todo nuestro personal cuenta con curso OS-10 al día, exigido por Carabineros de Chile.</p></div></div>
      <div class="cert-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg><div><h4>Autorización Administrativa Laboral</h4><p>Contamos con la autorización de la Dirección del Trabajo para operar servicios de seguridad privada.</p></div></div>
      <div class="cert-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg><div><h4>Protocolos Carabineros</h4><p>Todos nuestros protocolos de seguridad están certificados por Carabineros de Chile.</p></div></div>
      <div class="cert-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg><div><h4>Seguro de responsabilidad civil</h4><p>Cobertura obligatoria que protege a tu empresa, nuestros guardias y terceros.</p></div></div>
      <div class="cert-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg><div><h4>Verificación de antecedentes</h4><p>Todos nuestros guardias pasan por verificación de antecedentes antes de ser asignados.</p></div></div>
      <div class="cert-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg><div><h4>Cumplimiento Ley 21.659</h4><p>Operamos estrictamente dentro de la ley chilena de seguridad privada más reciente.</p></div></div>
    </div>
  </div>
</section>

<section class="staff-section" data-od-id="staff">
  <div class="container split">
    <div class="split-image"><img src="/images/nosotros_seccion.webp" alt="Personal GuardMan" loading="lazy" onerror="this.style.display='none';this.parentElement.style.minHeight='360px'"></div>
    <div>
      <span class="section-label">Personal que marca la diferencia</span>
      <h2 class="section-title">Personal que marca la diferencia</h2>
      <p style="color:rgba(255,255,255,.85);font-size:16px;line-height:1.6;margin-bottom:24px">Nuestros guardias son la base de la confianza que nuestros clientes depositan en nosotros.</p>
      <div class="staff-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>Certificación OS-10 vigente verificada por Carabineros de Chile</div>
      <div class="staff-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>Capacitación continua en protocolos de seguridad y emergencias</div>
      <div class="staff-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>Centro de monitoreo propio 24/7 con operadores especializados</div>
      <div class="staff-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>8+ años de experiencia protegiendo empresas y residencias</div>
    </div>
  </div>
</section>

<section class="bg-dark cta-section" data-od-id="cta">
  <div class="container">
    <h2 class="section-title">¿Quieres conocer más?</h2>
    <p class="section-subtitle">Conversemos. Te contamos cómo podemos proteger lo que más te importa.</p>
    <a href="/contacto" class="btn btn-primary btn-lg">Hablar con un Experto</a>
  </div>
</section>
</main>`;
