export const GUARDPOD_HTML = `<!-- ═══════════ HERO ═══════════ -->
<section class="hero" data-od-id="hero"><div class="container"><div class="hero-grid">
<div>
  <div class="hero-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>Tecnología Propia GuardMan</div>
  <h1>Guard <span>Pod</span></h1>
  <p class="hero-sub">Vigilancia autónoma 24/7 para obras, eventos y zonas sin infraestructura. Energía solar, cámaras PTZ 360° y monitoreo remoto en una unidad desplegable en menos de 2 horas.</p>
  <div class="hero-ctas">
    <a href="/cotizacion" class="btn btn-primary btn-lg">Cotizar Guard Pod</a>
    <a href="#features" class="btn btn-ghost btn-lg">Ver características</a>
  </div>
  <div class="hero-stats">
    <div><div class="hero-stat-value">2h</div><div class="hero-stat-label">Tiempo de despliegue</div></div>
    <div><div class="hero-stat-value">15</div><div class="hero-stat-label">Meses de I+D</div></div>
    <div><div class="hero-stat-value">360°</div><div class="hero-stat-label">Cobertura PTZ</div></div>
  </div>
</div>
<div class="hero-visual">
  <div class="hero-product"><img src="/images/s4-thumbnail.webp" alt="Guard Pod V1" loading="eager" onerror="this.style.display='none'"></div>
</div>
</div></div></section>

<!-- ═══════════ INTRO ═══════════ -->
<section data-od-id="intro"><div class="container"><div class="split">
<div class="split-text">
  <span class="section-label">Qué es el Guard Pod</span>
  <h2 class="section-title">El futuro de la seguridad privada en Chile</h2>
  <p>El Guard Pod® V1 es una unidad autónoma de vigilancia que combina tecnología de última generación con supervisión humana remota las 24 horas. A diferencia de los guardias físicos tradicionales, el Guard Pod ofrece protección continua sin interrupciones por cambios de turno o descansos.</p>
  <p>Funciona como un elemento disuasorio visible y efectivo. Su sistema de detección autónoma de intrusos permite respuesta inmediata, notificando automáticamente a nuestro centro de monitoreo propio para una reacción coordinada con Carabineros.</p>
  <p>Diseñado para sitios remotos, perímetros vulnerables y propiedades que requieren vigilancia constante. Energía solar, sin necesidad de red eléctrica. Instalación rápida sin obras ni cableado complejo.</p>
</div>
<div class="split-image"><img src="/images/s4-thumbnail.webp" alt="Guard Pod V1" loading="lazy" onerror="this.style.display='none'"></div>
</div></div></section>

<!-- ═══════════ FEATURES ═══════════ -->
<section class="section-dark" data-od-id="features"><div class="container">
<span class="section-label">Características principales</span>
<h2 class="section-title">Tecnología que protege sin descanso</h2>
<div class="feature-grid">
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></div><h3>Vigilancia autónoma 24/7</h3><p>Sin necesidad de presencia física permanente. El Guard Pod nunca duerme, nunca se distrae.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg></div><h3>Detección autónoma de intrusos</h3><p>Sensores de última generación que identifican actividad sospechosa en tiempo real.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg></div><h3>Centro de monitoreo propio</h3><p>Supervisión en tiempo real desde nuestras instalaciones con redundancia y respaldo.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg></div><h3>Disuasión visible</h3><p>Elemento disuasorio que refuerza la seguridad del perímetro con presencia física visible.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg></div><h3>Energía solar autónoma</h3><p>Funciona sin red eléctrica. Sistema de respaldo de energía para operación continua.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg></div><h3>Coordinación con Carabineros</h3><p>Notificaciones inmediatas y protocolo de comunicación directa con fuerzas de orden.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg></div><h3>Instalación rápida</h3><p>Sin necesidad de obras ni cableado complejo. Listo para operar en menos de 2 horas.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg></div><h3>Supervisión nocturna preventiva</h3><p>Monitoreo proactivo de conductas sospechosas durante horarios de mayor riesgo.</p></div>
</div></div></section>

<!-- ═══════════ PROBLEMS ═══════════ -->
<section data-od-id="problems"><div class="container">
<span class="section-label">Problemas que resolvemos</span>
<h2 class="section-title">Seguridad sin compromisos</h2>
<p class="section-subtitle">El Guard Pod resuelve las brechas de seguridad más comunes en sitios remotos y propiedades vulnerables.</p>
<div class="problems-grid">
  <div class="problem-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg><p>Sitios sin vigilancia constante y vulnerables a robos y vandalismo</p></div>
  <div class="problem-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg><p>Propiedades en zonas remotas con difícil acceso para guardias físicos</p></div>
  <div class="problem-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg><p>Costos elevados de seguridad física permanente las 24 horas</p></div>
  <div class="problem-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg><p>Brechas de seguridad durante horarios nocturnos y días festivos</p></div>
  <div class="problem-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg><p>Retraso en la detección de amenazas en sitios con poco personal</p></div>
  <div class="problem-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg><p>Necesidad de cobertura en períodos donde vigilancia humana es costosa</p></div>
</div></div></section>

<!-- ═══════════ FAQ ═══════════ -->
<section data-od-id="faq"><div class="container" style="max-width:760px">
<span class="section-label">Preguntas frecuentes</span>
<h2 class="section-title">Todo lo que necesitas saber</h2>
<div class="faq">
<details open><summary>¿Qué es exactamente el Guard Pod y cómo funciona?</summary><div class="answer">El Guard Pod® V1 es una unidad autónoma de vigilancia desarrollada por GuardMan Chile. Funciona como un guardia virtual que proporciona supervisión continua 24/7 mediante sensores de detección avanzados conectados directamente con nuestro centro de monitoreo propio.</div></details>
<details><summary>¿El Guard Pod reemplaza completamente a los guardias OS-10?</summary><div class="answer">El Guard Pod no reemplaza completamente a los guardias certificados OS-10, pero complementa extraordinariamente la seguridad de tu propiedad. Es ideal para zonas donde la vigilancia física permanente es costosa o difícil de implementar.</div></details>
<details><summary>¿En qué comunas está disponible?</summary><div class="answer">El Guard Pod está disponible en las 14 comunas de cobertura de GuardMan Chile en la Región Metropolitana: Las Condes, Vitacura, Lo Barnechea, La Reina, Santiago Centro, Huechuraba, Quilicura, Lampa, Pudahuel, Conchalí, Renca, La Pintana, más Los Andes y San Felipe.</div></details>
<details><summary>¿Requiere instalación de internet o energía eléctrica?</summary><div class="answer">El Guard Pod está diseñado para ser autónomo. Cuenta con energía solar y sistemas de respaldo, por lo que puede operar en ubicaciones sin infraestructura tradicional.</div></details>
<details><summary>¿Puedo integrarlo con mis sistemas de cámaras CCTV existentes?</summary><div class="answer">Sí, el Guard Pod puede integrarse con sistemas de CCTV, alarmas y otros dispositivos de seguridad existentes. Nuestro equipo técnico evaluará su infraestructura actual para diseñar la mejor solución de integración.</div></details>
</div></div></section>

<!-- ═══════════ CTA ═══════════ -->
<div class="cta-band" data-od-id="cta"><div class="container">
<h2 class="section-title">Protege tu propiedad con Guard Pod</h2>
<p class="section-subtitle">Solicita una cotización personalizada y descubre cómo el Guard Pod puede proteger lo que más te importa con tecnología de vanguardia y supervisión 24/7.</p>
<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
  <a href="/cotizacion" class="btn btn-primary btn-lg">Cotizar Guard Pod</a>
  <a href="/nosotros" class="btn btn-ghost btn-lg">Conocer GuardMan</a>
</div></div></div>`;
