export const AJAX_HTML = `<section class="hero" data-od-id="hero"><div class="container"><div class="hero-grid">
<div>
  <div class="hero-badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>Instalador Oficial</div>
  <h1>Ajax <span>Systems</span></h1>
  <p class="hero-sub">Alarmas inteligentes con certificación Grade 3 Professional. Tecnología inalámbrica con protocolo Jeweller, verificación por video y control total desde tu smartphone.</p>
  <div class="hero-ctas">
    <a href="/cotizacion" class="btn btn-primary btn-lg">Cotizar Ajax Systems</a>
    <a href="#features" class="btn btn-ghost btn-lg">Ver características</a>
  </div>
  <div class="hero-trust">
    <div class="hero-trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>Certificación Grade 3</div>
    <div class="hero-trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>Protocolo Jeweller</div>
    <div class="hero-trust-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>4.5M+ usuarios</div>
  </div>
</div>
<div class="hero-visual">
  <div class="hero-product"><img src="/images/Ajax-systems-header.jpg" alt="Ajax Systems Hub" loading="eager" onerror="this.style.display='none'"></div>
</div>
</div></div></section>

<section data-od-id="intro"><div class="container"><div class="split">
<div class="split-text">
  <span class="section-label">Qué es Ajax Systems</span>
  <h2 class="section-title">La alarma inteligente más premiada del mundo</h2>
  <p>Ajax Systems es la empresa líder mundial en sistemas de alarmas inalámbricas profesionales. Con más de 4.5 millones de usuarios protegidos en 187 países, sus dispositivos han recibido más de 20 premios internacionales de diseño y seguridad.</p>
  <p>En GuardMan Chile somos instaladores oficiales de Ajax Systems. Esto significa que no solo vendemos los equipos: los instalamos, configuramos y mantenemos con nuestro equipo técnico certificado. Cada instalación incluye integración con nuestro centro de monitoreo propio 24/7.</p>
  <p>A diferencia de las alarmas tradicionales, Ajax no depende de cables. Su protocolo Jeweller ofrece comunicación radio encriptada de hasta 2 km de alcance, inmune a interferencias, con verificación constante de todos los dispositivos.</p>
</div>
<div class="split-image"><img src="/images/Ajax-systems-header.jpg" alt="Sistema Ajax Systems" loading="lazy" onerror="this.style.display='none'"></div>
</div></div></section>

<section class="section-dark" data-od-id="features"><div class="container">
<span class="section-label">Características principales</span>
<h2 class="section-title">Tecnología que redefine la seguridad</h2>
<div class="feature-grid">
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div><h3>Certificación Grade 3 Professional</h3><p>El máximo nivel internacional de seguridad para instalaciones residenciales y comerciales de alto riesgo. Probado contra sabotaje, enmascaramiento y suplantación.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.24-3.905 14.14 0"/></svg></div><h3>Protocolo Jeweller</h3><p>Comunicación radio encriptada de largo alcance — hasta 2 km en línea vista. Inmune a jamming, con verificación de conexión cada 12 segundos entre todos los dispositivos.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg></div><h3>Verificación por video</h3><p>Ante una alarma, nuestro centro de monitoreo recibe videoverificación en tiempo real desde las cámaras Ajax integradas. Así eliminamos falsas alarmas.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg></div><h3>App Ajax — Control Total</h3><p>Armado y desarmado, visualización de cámaras, automatizaciones y notificaciones en tiempo real desde iOS y Android. Todo en una sola app.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg></div><h3>Instalación en horas, no días</h3><p>Sin cables, sin obras. Un sistema Ajax completo se instala en menos de 4 horas. Los sensores se emparejan con un solo clic desde la app.</p></div>
  <div class="feature-card"><div class="feature-card-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg></div><h3>Monitoreo 24/7 integrado</h3><p>Tu sistema Ajax se conecta directamente a nuestro centro de monitoreo propio. Respuesta inmediata ante cualquier evento, sin intermediarios.</p></div>
</div></div></section>

<section data-od-id="why-us"><div class="container">
<span class="section-label">Por qué GuardMan + Ajax</span>
<h2 class="section-title">La combinación perfecta</h2>
<p class="section-subtitle">No solo instalamos Ajax Systems. Somos una empresa de seguridad integral que respalda cada instalación con guardias OS-10, centro de monitoreo propio y 8+ años de experiencia.</p>
<div class="why-grid">
  <div class="why-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg><h4>Instaladores oficiales</h4><p>Equipo técnico certificado por Ajax Systems para instalación y mantenimiento.</p></div>
  <div class="why-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg><h4>Monitoreo propio 24/7</h4><p>No tercerizamos la central de monitoreo. Todo se supervisa desde nuestras instalaciones.</p></div>
  <div class="why-card"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857"/></svg><h4>Guardias OS-10</h4><p>Si la alarma se activa, nuestros guardias certificados pueden responder en terreno.</p></div>
</div></div></section>

<div class="stats-row" data-od-id="stats"><div class="container"><div class="stats-grid">
  <div class="stat-item"><div class="stat-value">187</div><div class="stat-label">Países con presencia Ajax</div></div>
  <div class="stat-item"><div class="stat-value">4.5M</div><div class="stat-label">Usuarios protegidos</div></div>
  <div class="stat-item"><div class="stat-value">Grade 3</div><div class="stat-label">Máxima certificación</div></div>
  <div class="stat-item"><div class="stat-value">2 km</div><div class="stat-label">Alcance radio Jeweller</div></div>
</div></div></div>

<section data-od-id="faq"><div class="container" style="max-width:760px">
<span class="section-label">Preguntas frecuentes</span>
<h2 class="section-title">Todo sobre Ajax Systems</h2>
<div class="faq">
<details open><summary>¿Qué diferencia a Ajax de otras alarmas?</summary><div class="answer">Ajax Systems es la única alarma inalámbrica del mundo con certificación Grade 3 Professional. Su protocolo Jeweller ofrece comunicación encriptada de hasta 2 km, verificación de conexión cada 12 segundos y es inmune a inhibidores de frecuencia. Además, integra videoverificación y control total desde una sola app.</div></details>
<details><summary>¿Cuánto cuesta un sistema Ajax en Chile?</summary><div class="answer">El precio depende del tamaño de la propiedad, la cantidad de sensores necesarios y si se incluye monitoreo 24/7. En GuardMan Chile ofrecemos cotizaciones personalizadas sin compromiso. Un sistema básico para departamento parte desde configuraciones muy accesibles.</div></details>
<details><summary>¿Funciona sin internet?</summary><div class="answer">Sí. El hub Ajax se conecta por Ethernet, Wi-Fi y redes móviles 4G (con respaldo automático). Si falla una vía, el sistema conmuta a la siguiente sin interrupción. Los sensores se comunican por radio Jeweller, que no depende de internet ni electricidad.</div></details>
<details><summary>¿Puedo integrarlo con cámaras CCTV existentes?</summary><div class="answer">Sí. Ajax Systems se integra con cámaras ONVIF de cualquier fabricante y con sus propias cámaras Ajax. Nuestro equipo técnico evalúa tu infraestructura actual y configura la integración para maximizar la cobertura.</div></details>
<details><summary>¿Cuánto demora la instalación?</summary><div class="answer">Una instalación residencial típica toma entre 2 y 4 horas. Para empresas o instalaciones más grandes, puede tomar un día. No se requieren obras ni cableado: los sensores son completamente inalámbricos y se fijan con cinta 3M de alta resistencia.</div></details>
</div></div></section>

<div class="cta-band" data-od-id="cta"><div class="container">
<h2 class="section-title">Protege tu propiedad con Ajax Systems</h2>
<p class="section-subtitle">Solicita una cotización personalizada. Instalación profesional, monitoreo 24/7 y soporte técnico permanente con GuardMan Chile.</p>
<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
  <a href="/cotizacion" class="btn btn-primary btn-lg">Cotizar Ajax Systems</a>
  <a href="/contacto" class="btn btn-ghost btn-lg">Hablar con un experto</a>
</div></div></div>`;
