import { Agent } from 'agents';
import { routeAgentRequest } from 'agents';
import { AIGenerator, ContentQueue } from './durable/ai-generator';
import { GMContentAgent } from './agents/content-agent';
import { GMPublisherAgent } from './agents/publisher-agent';
import { GMSerperSvc, GMSerperSqlite } from './agents/serper-agent';
import { GMOrchestrator } from './agents/orchestrator';
import { SEOAuditorAgent } from './agents/seo-auditor';
import { CompetitorAnalystAgent } from './agents/competitor-analyst';
import { SerperScanWorkflow } from './workflows/serper-scan';
import { BulkGenerateWorkflow } from './workflows/bulk-generate';
import { ScheduledReportsWorkflow } from './workflows/scheduled-reports';
import { SEOIntelWorkflow } from './workflows/seo-intel';
import { ContentPipelineWorkflow } from './workflows/content-pipeline';
import { CORS_HEADERS } from './types';
import { handleModularRoutes } from './api/index';
import { LogSession, DynamicWorkerTail } from './api/services/log-session';
import { PreviewDataService } from './api/services/preview-data-service';
import { handleMCPRequest } from './mcp/server';
import { runAnalyticsPipeline } from './services/pipeline';

export interface Env {
  DB: D1Database;
  IMAGES: R2Bucket;
  CACHE: KVNamespace;
  AI: any;
  AI_SEARCH: any;
  AUTH_TOKEN: string;
  ADMIN_EMAIL: string;
  AI_GENERATOR: DurableObjectNamespace;
  CONTENT_AGENT: DurableObjectNamespace;
  CONTENT_QUEUE: DurableObjectNamespace;
  PUBLISHER_AGENT: DurableObjectNamespace;
  SERPER_AGENT: DurableObjectNamespace;
  SERPER_AGENT_SQLITE: DurableObjectNamespace;
  ORCHESTRATOR: DurableObjectNamespace;
  LOG_SESSION: DurableObjectNamespace;
  SEO_AUDITOR?: DurableObjectNamespace; // Sub-agent facet — no longer needs binding
  COMPETITOR_ANALYST?: DurableObjectNamespace; // Sub-agent facet — no longer needs binding
  SERPER_SCAN_WORKFLOW?: Workflow;
  BULK_GENERATE_WORKFLOW?: Workflow;
  PUBLISH_WORKFLOW?: Workflow;
  REPORTS_WORKFLOW?: Workflow;
  SEO_INTEL_WORKFLOW?: Workflow;
  CONTENT_PIPELINE_WORKFLOW?: Workflow;
  SITE_DEPLOY_WORKFLOW?: Workflow;
  LOADER?: any; // Dynamic Worker Loader (preview engine)
  MINIMAX_API_KEY?: string;
  SERPER_API_KEY?: string;
  AUTH_SECRET?: string;
  DEPLOY_HOOK_URL?: string;
  AI_GATEWAY_TOKEN?: string;
  CLOUDFLARE_ACCOUNT_ID?: string;
}

const cors = CORS_HEADERS;

export { AIGenerator, ContentQueue, GMContentAgent, GMPublisherAgent, GMSerperSvc, GMSerperSqlite, GMOrchestrator, LogSession, DynamicWorkerTail, PreviewDataService, SEOAuditorAgent, CompetitorAnalystAgent, SerperScanWorkflow, BulkGenerateWorkflow, ScheduledReportsWorkflow, SEOIntelWorkflow, ContentPipelineWorkflow, QuickWinWorkflow, RateLimiter };
import queueHandler from './queues/consumer';

// Legacy stub — kept for migration compat (v7 tag in wrangler.jsonc)
// Renamed from GuardManOrchestrator to clarify it's not the real orchestrator (that's GMOrchestrator)
export class GuardManOrchestrator extends Agent<Env, any> { initialState = {}; }

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    if (method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (path === '/health') return Response.json({ ok: true, version: '2.0.0' }, { headers: cors });
    if (path === '/') return Response.json({ ok: true, service: 'guardman-admin-api', version: '2.0.0', ui: 'https://guardman-admin.pages.dev' }, { headers: cors });

    // WebSocket /agent routing — routeAgentRequest handles /agents/* for Think DOs
    // Must be before modular routes so WebSocket upgrade reaches the DO
    const agentResponse = await routeAgentRequest(request, env, {
      onBeforeConnect: async (req, lobby) => {
        // Auth: check token from query params or Authorization header
        const url = new URL(req.url);
        const token = url.searchParams.get('token');
        const authHeader = req.headers.get('Authorization');
        const isAuthed = authHeader?.includes(env.AUTH_TOKEN) ||
          authHeader?.startsWith('Bearer admin@guardman.cl:') ||
          token?.includes(env.AUTH_TOKEN) ||
          token?.startsWith('admin@guardman.cl:');
        if (!isAuthed) {
          return new Response('Unauthorized', { status: 401 });
        }
        return req;
      },
    });
    if (agentResponse) {
      // For WebSocket upgrades (101 Switching Protocols), pass through directly
      // Adding CORS headers would break the WebSocket handshake
      if (agentResponse.status === 101) {
        return agentResponse;
      }
      // For regular HTTP responses, add CORS headers
      if (agentResponse.headers) {
        const headers = new Headers(agentResponse.headers);
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With');
        return new Response(agentResponse.body, {
          status: agentResponse.status,
          statusText: agentResponse.statusText,
          headers,
        });
      }
      return agentResponse;
    }

    // Try modular routes first (monitor, preview, etc.)
    const modularResponse = await handleModularRoutes(request, env, ctx);
    if (modularResponse) return modularResponse;

    // Note: Preview, Services, Locations, Sectors, Content CRUD are now handled by modular routes
    // (previewRoutes + contentRoutes in api/routes/)

    // Public: images (need to work in <img> tags without auth)
    if (path.startsWith('/api/images/') && method === 'GET') {
      const key = path.replace('/api/images/', '');
      const object = await env.IMAGES.get(key);
      if (!object) return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: cors });
      const headers = new Headers();
      object.writeHttpMetadata(headers);
      headers.set('etag', object.httpEtag);
      headers.set('Access-Control-Allow-Origin', '*');
      headers.set('Cache-Control', 'public, max-age=31536000');
      return new Response(object.body, { headers });
    }

    // Auth required: upload image to R2
    if (path === '/api/images/upload' && method === 'POST') {
      const auth = request.headers.get('Authorization');
      if (!auth?.includes(env.AUTH_TOKEN) && !auth?.startsWith('Bearer admin@guardman.cl:')) {
        return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
      }

      try {
        const formData = await request.formData();
        const file = formData.get('file') as File;
        const folder = formData.get('folder') as string || '';

        if (!file) {
          return Response.json({ ok: false, error: 'No file provided' }, { status: 400, headers: cors });
        }

        const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        if (!validTypes.includes(file.type)) {
          return Response.json({ ok: false, error: 'Invalid file type. Use JPEG, PNG, WebP or GIF' }, { status: 400, headers: cors });
        }

        const maxSize = 10 * 1024 * 1024; // 10MB
        if (file.size > maxSize) {
          return Response.json({ ok: false, error: 'File too large. Max 10MB' }, { status: 400, headers: cors });
        }

        const key = folder ? `${folder}/${file.name}` : file.name;
        await env.IMAGES.put(key, file);

        return Response.json({
          ok: true,
          data: {
            key,
            url: `/api/images/${key}`,
            name: file.name,
            size: file.size,
            type: file.type
          }
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // Public: CMS images proxy from GitHub
    if (path.startsWith('/api/cms/image') && method === 'GET') {
      const url = new URL(request.url);
      const imgPath = url.searchParams.get('path');
      if (!imgPath) return Response.json({ ok: false, error: 'Missing path' }, { status: 400, headers: cors });

      const githubPath = imgPath.startsWith('/') ? `public${imgPath}` : imgPath;
      const githubUrl = `https://raw.githubusercontent.com/desarrollo33-lab/guardman-site/main/${githubPath}`;

      try {
        const res = await fetch(githubUrl);
        if (!res.ok) return Response.json({ ok: false, error: 'Image not found' }, { status: 404, headers: cors });

        const imageBuffer = await res.arrayBuffer();
        const contentType = res.headers.get('content-type') || 'image/webp';
        const headers = new Headers();
        headers.set('Content-Type', contentType);
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Cache-Control', 'public, max-age=86400');
        return new Response(imageBuffer, { headers });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // Login — public, no auth required
    if (path === '/api/login' && method === 'POST') {
      const body = await request.json() as any;
      if (body.email === env.ADMIN_EMAIL && body.password === env.AUTH_TOKEN) {
        return Response.json({ ok: true, data: { token: body.email + ':' + Date.now(), user: { email: body.email } } }, { headers: cors });
      }
      return Response.json({ ok: false, error: 'Invalid credentials' }, { status: 401, headers: cors });
    }

    // Auth check — modular routes handle their own auth, this is for any remaining monolith routes
    const auth = request.headers.get('Authorization');
    if (!auth?.includes(env.AUTH_TOKEN) && !auth?.startsWith('Bearer admin@guardman.cl:')) {
      return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
    }

    // MCP Server endpoint
    if (path === '/api/mcp' && method === 'POST') {
      try {
        const body = await request.json();
        const result = await handleMCPRequest(env, body);
        return Response.json(result, { headers: cors });
      } catch (err: any) {
        return Response.json({ error: err.message }, { status: 500, headers: cors });
      }
    }

    // Analytics pipeline endpoint
    if (path === '/api/analytics/pipeline' && method === 'POST') {
      try {
        const results = await runAnalyticsPipeline(env);
        return Response.json({ ok: true, data: results }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: cors });
  },

  async queue(batch: any, env: Env): Promise<void> {
    await queueHandler.queue(batch, env);
  }
};
