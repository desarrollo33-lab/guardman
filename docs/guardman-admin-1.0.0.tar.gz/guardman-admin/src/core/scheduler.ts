// GuardMan v3.0 — CRON Scheduler
// Maneja los 5 CRON jobs semanales configurados en wrangler.jsonc.
// Lunes: Serper Scan + SEO Intel. Miércoles: Quick Wins. Viernes: Backfill. Domingo: Reporte.

import type { Env } from '../index';

export async function handleScheduledTask(event: ScheduledEvent, env: Env): Promise<void> {
  console.log(`[Scheduler] Triggered: cron=${event.cron}, time=${new Date().toISOString()}`);

  switch (event.cron) {

    // ===== LUNES 3AM UTC (Domingo 11PM Chile) — Serper Scan =====
    case "0 3 * * 1":
      if (env.SERPER_SCAN_WORKFLOW) {
        const scanId = `weekly-scan-${Date.now()}`;
        await env.SERPER_SCAN_WORKFLOW.create({
          id: scanId,
          params: { trigger: 'scheduled' },
        });
        console.log(`[Scheduler] SerperScanWorkflow created: ${scanId}`);
      }
      break;

    // ===== LUNES 5AM UTC (Lunes 1AM Chile) — SEO Intel post-scan =====
    case "0 5 * * 1":
      if (env.SEO_INTEL_WORKFLOW) {
        const intelId = `weekly-intel-${Date.now()}`;
        await env.SEO_INTEL_WORKFLOW.create({
          id: intelId,
          params: { trigger: 'post-scan' },
        });
        console.log(`[Scheduler] SEOIntelWorkflow created: ${intelId}`);
      }
      break;

    // ===== MIÉRCOLES 3AM UTC (Martes 11PM Chile) — Quick Wins =====
    case "0 3 * * 3":
      if (env.QUICK_WIN_WORKFLOW) {
        const qwId = `quickwin-${Date.now()}`;
        await env.QUICK_WIN_WORKFLOW.create({
          id: qwId,
          params: { maxItems: 15 },
        });
        console.log(`[Scheduler] QuickWinWorkflow created: ${qwId}`);
      }
      break;

    // ===== VIERNES 3AM UTC (Jueves 11PM Chile) — Backfill Gaps =====
    case "0 3 * * 5":
      if (env.SEO_CONTENT_QUEUE) {
        console.log('[Scheduler] Detecting content gaps for backfill...');
        const { results: gaps } = await env.DB.prepare(`
          SELECT s.slug as service_slug, l.slug as location_slug
          FROM services s CROSS JOIN locations l
          LEFT JOIN combo_content cc ON cc.service_slug = s.slug AND cc.location_slug = l.slug
          WHERE cc.service_slug IS NULL
        `).all();

        const gapList = gaps as any[];
        console.log(`[Scheduler] Found ${gapList.length} gaps`);

        if (gapList.length > 0) {
          // Encolar en batches de 10 para respetar rate limits
          const batchSize = 10;
          for (let i = 0; i < gapList.length; i += batchSize) {
            const batch = gapList.slice(i, i + batchSize);
            await env.SEO_CONTENT_QUEUE.sendBatch(
              batch.map(g => ({
                body: { type: 'combo', service_slug: g.service_slug, location_slug: g.location_slug },
              }))
            );
          }
          console.log(`[Scheduler] Queued ${gapList.length} gaps in ${Math.ceil(gapList.length / batchSize)} batches`);
        }
      }
      break;

    // ===== DOMINGO 7AM UTC (Domingo 3AM Chile) — Reporte Semanal =====
    case "0 7 * * 7":
      if (env.REPORTS_WORKFLOW) {
        const reportId = `weekly-report-${Date.now()}`;
        await env.REPORTS_WORKFLOW.create({
          id: reportId,
          params: { type: 'weekly' },
        });
        console.log(`[Scheduler] ReportsWorkflow created: ${reportId}`);
      }
      break;

    default:
      console.log(`[Scheduler] Unknown cron: ${event.cron}`);
  }
}
