// GuardMan - Publisher Agent v2
// Durable Object using Cloudflare Agent SDK with Fibers
// Handles drip-feed publishing, version control, R2 uploads, and deploy triggers
//
// Key improvements over v1:
// - runFiber() for durable publishing: survives DO restarts mid-publish
// - onFiberRecovered() to retry failed publishes
// - WebSocket broadcast for real-time UI updates on publish status

import { Agent } from 'agents';
import type { Env, PublishJob } from '../types';

interface PublisherAgentState {
  published: number;
  pending: number;
  failed: number;
  lastPublishAt: string | null;
  lastDeployAt: string | null;
  currentCycle: number;
}

export class GMPublisherAgent extends Agent<Env, PublisherAgentState> {
  // env is set by Agent base class but not exposed in types
  declare env: Env;

  initialState: PublisherAgentState = {
    published: 0,
    pending: 0,
    failed: 0,
    lastPublishAt: null,
    lastDeployAt: null,
    currentCycle: 0,
  };

  async onStart() {
    // Process queue every 2 hours
    await this.schedule('0 */2 * * *', 'processQueue', {});
    // Daily report at 9am UTC
    await this.schedule('0 9 * * *', 'dailyReport', {});
    console.log('[PublisherAgent] Started with fibers + scheduling');
  }

  // ===== PUBLIC RPC METHODS =====

  /**
   * Get current publisher state and queue stats
   */
  async getStatus(): Promise<PublisherAgentState & { queueStats: any }> {
    const queueStats = await this.getQueueStats();
    return { ...this.state, queueStats };
  }

  /**
   * Schedule a single page for publishing with calculated delay.
   * Uses a fiber so the wait survives DO restarts.
   */
  async schedulePublish(job: PublishJob): Promise<{ scheduled: boolean; delayMinutes: number }> {
    const pending = await this.getPendingCount();
    const delayMinutes = Math.min(pending * 15, 1440); // 15min between pages, max 24h

    // Mark as scheduled in D1
    await this.env.DB.prepare(`
      UPDATE publish_queue SET status = 'scheduled', scheduled_at = datetime('now', '+${delayMinutes} minutes')
      WHERE entity_type = ? AND entity_slug = ? AND status = 'approved'
    `).bind(job.entityType, job.entitySlug).run();

    // Run in a fiber so the wait is durable
    void this.runFiber(`publish-${job.entityType}-${job.entitySlug}-${Date.now()}`, async (ctx) => {
      ctx.stash({ job, phase: 'waiting', delayMinutes });

      // Wait the delay (this is durable — survives restarts)
      await new Promise(r => setTimeout(r, delayMinutes * 60 * 1000));

      ctx.stash({ job, phase: 'executing' });
      await this.publishPage(job);
    });

    return { scheduled: true, delayMinutes };
  }

  /**
   * Manually trigger queue processing
   */
  async triggerProcessQueue(): Promise<{ processing: number }> {
    await this.processQueue();
    const stats = await this.getQueueStats();
    return { processing: stats.approved + stats.scheduled };
  }

  /**
   * Get full publish queue with optional status filter
   */
  async fetchQueue(status?: string, limit: number = 50): Promise<any[]> {
    let sql = 'SELECT * FROM publish_queue';
    const params: any[] = [];
    if (status) { sql += ' WHERE status = ?'; params.push(status); }
    sql += ' ORDER BY score DESC, created_at ASC LIMIT ?';
    params.push(limit);
    const { results } = await this.env.DB.prepare(sql).bind(...params).all();
    return results as any[];
  }

  /**
   * Get publish history with optional filters
   */
  async getHistory(entityType?: string, entitySlug?: string, limit: number = 50): Promise<any[]> {
    let sql = 'SELECT * FROM published_versions WHERE 1=1';
    const params: any[] = [];
    if (entityType) { sql += ' AND entity_type = ?'; params.push(entityType); }
    if (entitySlug) { sql += ' AND entity_slug = ?'; params.push(entitySlug); }
    sql += ' ORDER BY published_at DESC LIMIT ?';
    params.push(limit);
    const { results } = await this.env.DB.prepare(sql).bind(...params).all();
    return results as any[];
  }

  /**
   * Rollback to a previous published version
   */
  async rollback(entityType: string, entitySlug: string, version: number): Promise<{ ok: boolean }> {
    const prev = await this.env.DB.prepare(
      'SELECT * FROM published_versions WHERE entity_type = ? AND entity_slug = ? AND version = ?'
    ).bind(entityType, entitySlug, version).first();

    if (!prev) throw new Error('Version not found');

    const job: PublishJob = {
      entityType,
      entitySlug,
      contentJson: prev.content_json as string,
      score: prev.score as number,
      version: (prev.version as number) + 1,
    };

    await this.publishPage(job);
    return { ok: true };
  }

  /**
   * Trigger a site rebuild (Astro deploy)
   */
  async rebuildSite(): Promise<{ ok: boolean; message: string }> {
    await this.triggerDeploy();
    return { ok: true, message: 'Deploy triggered' };
  }

  // ===== SCHEDULED METHODS =====

  /**
   * Process approved/scheduled items in the queue (drip-feed).
   * Max 5 pages per cycle, 5 min between publications.
   */
  async processQueue() {
    const MAX_PER_CYCLE = 5;
    this.setState({ ...this.state, currentCycle: this.state.currentCycle + 1 });

    const pending = await this.env.DB.prepare(`
      SELECT * FROM publish_queue
      WHERE status IN ('approved', 'scheduled')
        AND (scheduled_at IS NULL OR scheduled_at <= datetime('now'))
      ORDER BY score DESC, created_at ASC
      LIMIT ?
    `).bind(MAX_PER_CYCLE).all();

    const items = pending.results as any[];

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      void this.runFiber(`cycle-${this.state.currentCycle}-publish-${item.entity_type}-${item.entity_slug}`, async (ctx) => {
        const job: PublishJob = {
          entityType: item.entity_type,
          entitySlug: item.entity_slug,
          contentJson: item.content_json,
          score: item.score,
          version: item.version || 1,
        };

        ctx.stash({ job, phase: 'waiting', delay: i * 300 });
        // 5 min delay between publications within the same cycle
        if (i > 0) await new Promise(r => setTimeout(r, i * 300 * 1000));

        ctx.stash({ job, phase: 'executing' });
        await this.publishPage(job);
      });
    }

    console.log(`[PublisherAgent] Cycle ${this.state.currentCycle}: processing ${items.length} pages`);

    this.broadcast(JSON.stringify({
      type: 'queue-processing',
      data: { cycle: this.state.currentCycle, count: items.length },
    }));
  }

  /**
   * Publish a single page: upload to R2, update DB, trigger deploy
   * Includes images from media_entities table
   */
  async publishPage(job: PublishJob) {
    try {
      // 1. Mark as publishing
      await this.env.DB.prepare(`
        UPDATE publish_queue SET status = 'publishing' WHERE entity_type = ? AND entity_slug = ? AND status IN ('approved', 'scheduled')
      `).bind(job.entityType, job.entitySlug).run();

      // 2. Parse and upload content JSON to R2
      const content = JSON.parse(job.contentJson);
      
      // 3. Get images for this entity from media_entities
      let heroImage: string | null = null;
      let ogImage: string | null = null;
      let allImages: any[] = [];
      try {
        const { results: imgRows } = await this.env.DB.prepare(
          `SELECT me.usage, me.entity_type, me.entity_slug, m.key, m.alt_text, m.category
           FROM media_entities me JOIN media_library m ON me.media_id = m.id
           WHERE me.entity_type = ? AND me.entity_slug = ? ORDER BY me.sort_order`
        ).bind(job.entityType, job.entitySlug).all();
        
        for (const img of imgRows as any[]) {
          const url = `/${img.key}`;
          allImages.push({
            type: img.usage,
            url,
            key: img.key,
            alt: img.alt_text,
            category: img.category,
          });
          if (img.usage === 'hero') heroImage = url;
          if (img.usage === 'og') ogImage = url;
        }
        
        // Inject hero image into content sections
        if (heroImage && content.sections?.hero) {
          content.sections.hero.image = heroImage;
        }
      } catch { /* media_entities may not have data */ }

      // 4. Add publish metadata with images
      const jsonKey = `content/${job.entityType}/${job.entitySlug}.json`;
      content._publish = {
        entityType: job.entityType,
        entitySlug: job.entitySlug,
        version: job.version,
        score: job.score,
        publishedAt: new Date().toISOString(),
        heroImage,
        ogImage: ogImage || heroImage || null,
        allImages,
      };

      // 5. Upload to R2 with custom metadata
      await this.env.IMAGES.put(jsonKey, JSON.stringify(content, null, 2), {
        httpMetadata: { contentType: 'application/json' },
        customMetadata: {
          entityType: job.entityType,
          entitySlug: job.entitySlug,
          score: String(job.score),
          version: String(job.version),
          heroImage: heroImage || '',
          ogImage: ogImage || heroImage || '',
        },
      });

      // 6. Update master index
      await this.updateMasterIndex();

      // 7. Register published version
      await this.env.DB.prepare(`
        INSERT INTO published_versions (entity_type, entity_slug, version, content_json, score, published_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
      `).bind(job.entityType, job.entitySlug, job.version, job.contentJson, job.score).run();

      // 8. Mark as published
      await this.env.DB.prepare(`
        UPDATE publish_queue SET status = 'published', published_at = datetime('now')
        WHERE entity_type = ? AND entity_slug = ?
      `).bind(job.entityType, job.entitySlug).run();

      // 9. Update state
      this.setState({
        ...this.state,
        published: this.state.published + 1,
        lastPublishAt: new Date().toISOString(),
      });

      // 10. Notify UI via WebSocket
      this.broadcast(JSON.stringify({
        type: 'published',
        data: { entityType: job.entityType, entitySlug: job.entitySlug, score: job.score, version: job.version, heroImage, ogImage },
      }));

      // 11. Batch deploy every 5 pages
      if (this.state.published % 5 === 0) {
        await this.triggerDeploy();
      }

      console.log(`[PublisherAgent] Published ${job.entityType}/${job.entitySlug} (v${job.version}, score: ${job.score}, images: ${allImages.length})`);

    } catch (e) {
      await this.env.DB.prepare(`
        UPDATE publish_queue SET status = 'failed' WHERE entity_type = ? AND entity_slug = ?
      `).bind(job.entityType, job.entitySlug).run();

      this.setState({ ...this.state, failed: this.state.failed + 1 });

      this.broadcast(JSON.stringify({
        type: 'publish-failed',
        data: { entityType: job.entityType, entitySlug: job.entitySlug, error: String(e) },
      }));

      console.error(`[PublisherAgent] Failed: ${job.entityType}/${job.entitySlug}:`, e);
    }
  }

  /**
   * Daily report (called by cron at 9am UTC)
   */
  async dailyReport() {
    const stats = await this.getQueueStats();
    const report = {
      published: this.state.published,
      failed: this.state.failed,
      pending: stats.approved + stats.scheduled,
      lastPublishAt: this.state.lastPublishAt,
    };
    console.log(`[PublisherAgent] Daily report: ${JSON.stringify(report)}`);

    this.broadcast(JSON.stringify({
      type: 'daily-report',
      data: report,
    }));
  }

  // ===== FIBER RECOVERY =====

  async onFiberRecovered(ctx: any) {
    if (ctx.name?.startsWith('publish-') || ctx.name?.startsWith('cycle-')) {
      const snap = ctx.snapshot;
      if (snap?.phase === 'executing') {
        console.log(`[PublisherAgent] Recovering fiber ${ctx.name}: retrying publish`);
        await this.publishPage(snap.job);
      } else if (snap?.phase === 'waiting') {
        console.log(`[PublisherAgent] Recovering fiber ${ctx.name}: was waiting, re-scheduling`);
        // Re-schedule: the delay time has passed during the crash
        await this.publishPage(snap.job);
      }
    }
  }

  // ===== WEBSOCKET =====

  async onConnect(client: WebSocket) {
    const stats = await this.getQueueStats();
    client.send(JSON.stringify({ type: 'state', data: { ...this.state, queueStats: stats } }));
  }

  async onMessage(client: WebSocket, message: string) {
    try {
      const msg = JSON.parse(message);
      if (msg.type === 'getStatus') {
        const stats = await this.getQueueStats();
        client.send(JSON.stringify({ type: 'state', data: { ...this.state, queueStats: stats } }));
      } else if (msg.type === 'getQueue') {
        const queue = await this.fetchQueue(msg.status, msg.limit);
        client.send(JSON.stringify({ type: 'queue', data: queue }));
      }
    } catch { /* ignore */ }
  }

  // ===== PRIVATE HELPERS =====

  private async updateMasterIndex() {
    const { results } = await this.env.DB.prepare(`
      SELECT entity_type, entity_slug, score, published_at FROM published_versions
      WHERE published_at = (
        SELECT MAX(published_at) FROM published_versions pv2
        WHERE pv2.entity_type = published_versions.entity_type AND pv2.entity_slug = published_versions.entity_slug
      )
    `).all();

    await this.env.IMAGES.put('content/index.json', JSON.stringify(results, null, 2), {
      httpMetadata: { contentType: 'application/json' },
    });
  }

  private async triggerDeploy() {
    if (!this.env.DEPLOY_HOOK_URL) {
      console.log('[PublisherAgent] No DEPLOY_HOOK_URL configured, skipping deploy');
      return;
    }
    try {
      const resp = await fetch(this.env.DEPLOY_HOOK_URL, { method: 'POST' });
      if (resp.ok) {
        this.setState({ ...this.state, lastDeployAt: new Date().toISOString() });
        console.log('[PublisherAgent] Deploy triggered successfully');
      } else {
        console.error('[PublisherAgent] Deploy trigger failed:', resp.status);
      }
    } catch (e) {
      console.error('[PublisherAgent] Deploy trigger error:', e);
    }
  }

  private async getPendingCount(): Promise<number> {
    const result = await this.env.DB.prepare(
      "SELECT COUNT(*) as count FROM publish_queue WHERE status IN ('pending', 'approved', 'scheduled')"
    ).first();
    return (result?.count as number) || 0;
  }

  private async getQueueStats(): Promise<any> {
    const { results } = await this.env.DB.prepare(
      'SELECT status, COUNT(*) as count FROM publish_queue GROUP BY status'
    ).all();
    const stats: any = { pending: 0, approved: 0, scheduled: 0, publishing: 0, published: 0, failed: 0 };
    for (const row of results as any[]) {
      if (stats[row.status] !== undefined) stats[row.status] = row.count;
    }
    return stats;
  }
}
