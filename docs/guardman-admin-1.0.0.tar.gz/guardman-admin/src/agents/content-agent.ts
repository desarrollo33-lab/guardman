// GuardMan - Content Agent v2
// Durable Object using Cloudflare Agent SDK with Fibers
// Handles AI content generation with crash recovery, scoring, iteration, auto-approval, and image management
//
// Image pipeline:
// 1. Before generation: fetch existing hero/og from media_entities → enrich prompt
// 2. After save: ContentExplorer lets user upload via POST /api/entities/:type/:slug/images
// 3. At publish: PublishWorkflow injects hero image into content.sections.hero.image

import { Agent } from 'agents';
import type { Env, ContentJob, GeneratedContent } from '../types';
import { callDeepSeekAI, generateFallbackContent } from '../services/ai';
import { calculateContentScore } from '../services/scoring';
import { infer } from '../services/inference';
import { searchCompetitors, searchFAQs, searchContentGaps, searchBrandGuide, searchPreviousContent, searchKeywords, isAISearchAvailable } from '../services/search';
import { getCompetitorWeaknessMap, getRelevantLessons } from '../services/memory';
import { reviewContent, saveReview, saveLesson } from './content-reviewer';
import { checkContentGuardrails } from '../services/guardrails';
import { SERVICE_PROMPTS, ZONE_PROMPTS } from './service-prompts';

// ===== AI Search text extraction helper =====
function extractSearchText(result: any): string {
  if (!result) return '';
  if (typeof result === 'string') return result;
  if (result.results) {
    return (result.results as any[])
      .map((r: any) => r.text || r.snippet || r.content || (typeof r === 'string' ? r : JSON.stringify(r).substring(0, 200)))
      .filter(Boolean)
      .join('\n');
  }
  if (result.hits) {
    return (result.hits as any[])
      .map((h: any) => h.content || h.snippet || h.text || JSON.stringify(h).substring(0, 200))
      .filter(Boolean)
      .join('\n');
  }
  return JSON.stringify(result).substring(0, 1500);
}

// ===== State Shape =====
interface ContentAgentState {
  processing: boolean;
  queue: ContentJob[];
  stats: {
    generated: number;
    failed: number;
    autoApproved: number;
    totalAttempts: number;
  };
  lastRunAt: string | null;
}

// ===== Fiber Snapshot (what gets persisted between crashes) =====
interface GenerateFiberSnapshot {
  job: ContentJob;
  attempt: number;
  bestContent: GeneratedContent | null;
  bestScore: number;
  bestDetails: any;
  lastError: string | null;
}

export class GMContentAgent extends Agent<Env, ContentAgentState> {
  // env is set by Agent base class but not exposed in types
  declare env: Env;

  initialState: ContentAgentState = {
    processing: false,
    queue: [],
    stats: { generated: 0, failed: 0, autoApproved: 0, totalAttempts: 0 },
    lastRunAt: null,
  };

  // ===== LIFECYCLE =====

  async onStart() {
    // Cron: refresh stale content every Monday at 6am UTC
    await this.schedule('0 6 * * 1', 'refreshStaleContent', {});
    console.log('[ContentAgent] Started with fibers + WebSocket');
  }

  // ===== PUBLIC RPC METHODS =====

  /**
   * Generate content for a single entity with iterative refinement.
   * Uses runFiber() for durable execution — survives DO restarts.
   */
  async generateContent(job: ContentJob): Promise<{
    content: GeneratedContent;
    score: number;
    details: any;
    attempts: number;
    saved: boolean;
    savedTo: string;
    review?: any;
  }> {
    const MAX_ATTEMPTS = 3;
    const SCORE_THRESHOLD = 75;
    const AUTO_APPROVE_THRESHOLD = 85; // v4: raised from 80 to 85 with LLM review

    return new Promise((resolve, reject) => {
      void this.runFiber(`gen-${job.entityType}-${job.entitySlug}`, async (ctx) => {
        const snapshot = (ctx.snapshot || {
          job,
          attempt: 0,
          bestContent: null as GeneratedContent | null,
          bestScore: 0,
          bestDetails: {} as any,
          lastError: null as string | null,
        }) as GenerateFiberSnapshot;

        let bestContent: GeneratedContent | null = snapshot.bestContent;
        let bestScore = snapshot.bestScore;
        let bestDetails: any = snapshot.bestDetails || {};
        let bestAttempt = snapshot.attempt;
        let bestReview: any = null;

        // Get current content for comparison
        let currentScore: any = null;
        try {
          const existing = await this.getCurrentContent(job);
          if (existing) {
            currentScore = calculateContentScore(existing);
          }
        } catch { /* ignore */ }

        // Broadcast start
        this.broadcast(JSON.stringify({
          type: 'generation-started',
          data: { entityType: job.entityType, entitySlug: job.entitySlug, entityName: job.entityName, aiSearch: isAISearchAvailable(this.env) },
        }));

        // v4: Enrich job with AI Search context if available
        let aiSearchContext = '';

        // §0 — Inject brand DNA from D1 (always available, no AI Search needed)
        try {
          const { results: brandRows } = await this.env.DB.prepare(
            "SELECT category, key, value FROM brand_dna WHERE category IN ('company','stats','voice','differentiators','exclusions') ORDER BY category, key"
          ).all();
          if (brandRows && brandRows.length > 0) {
            const bc: Record<string, Record<string, string>> = {};
            for (const r of brandRows as any[]) {
              if (!bc[r.category]) bc[r.category] = {};
              bc[r.category][r.key] = r.value;
            }
            const c = bc.company || {};
            const s = bc.stats || {};
            const v = bc.voice || {};
            const d = bc.differentiators || {};
            const e = bc.exclusions || {};
            let brandCtx = `IDENTIDAD DE MARCA (ADN):\n- Empresa: ${c.brand_name || 'GuardMan Chile'} (${c.legal_name || ''})\n- Tagline: ${c.tagline || ''}\n- Estadisticas: ${s.years || '8+'} anos, ${s.guards || '500+'} guardias, ${s.clients || '200+'} clientes, ${s.locations || '14'} comunas\n- Tono: ${v.tone || 'Profesional, orientado a conversion, en espanol chileno'}\n- Audiencia: ${v.audience || ''}\n- Menciones obligatorias: ${v.mandatory_mentions || ''}\n- Palabras prohibidas: ${v['forbidden_words'] || ''}`;
            if (Object.keys(d).length) brandCtx += `\nDIFERENCIADORES:\n${Object.values(d).map(v => '- ' + v).join('\n')}`;
            if (Object.keys(e).length) brandCtx += `\nEXCLUSIONES:\n${Object.values(e).map(v => '- ' + v).join('\n')}`;
            aiSearchContext = brandCtx;
          }
        } catch (e) {
          console.warn('[ContentAgent] Brand DNA injection failed:', (e as Error).message);
        }

        if (isAISearchAvailable(this.env)) {
          try {
            const serviceSlug = job.comboServiceSlug || (job.entityType === 'service' ? job.entitySlug : (job.entityType === 'sector' ? (await this.getServiceSlugForSector(job.entitySlug)) : ''));
            if (serviceSlug) {
              const [competitors, gaps, faqs, brandGuide, previous, keywords] = await Promise.all([
                searchCompetitors(this.env, serviceSlug, job.comboLocationSlug || undefined),
                searchContentGaps(this.env, serviceSlug),
                searchFAQs(this.env, serviceSlug, job.comboLocationSlug || undefined),
                searchBrandGuide(this.env),
                searchPreviousContent(this.env, serviceSlug),
                searchKeywords(this.env, serviceSlug),
              ]);

              // Build AI Search context string from results
              const ctxParts: string[] = [];

              if (brandGuide) {
                const text = extractSearchText(brandGuide);
                if (text) ctxParts.push('MARCA Y VOZ: ' + text.substring(0, 600));
              }

              if (competitors) {
                const text = extractSearchText(competitors);
                if (text) ctxParts.push('INTELIGENCIA DE COMPETENCIA (AI Search): ' + text.substring(0, 800));
              }

              if (gaps) {
                const text = extractSearchText(gaps);
                if (text) ctxParts.push('CONTENT GAPS (AI Search): ' + text.substring(0, 500));
              }

              if (faqs) {
                const text = extractSearchText(faqs);
                if (text) ctxParts.push('FAQs REALES DE USUARIOS (AI Search): ' + text.substring(0, 800));
              }

              if (previous) {
                const text = extractSearchText(previous);
                if (text) ctxParts.push('CONTENIDO PREVIO GENERADO (para mejorar, no repetir): ' + text.substring(0, 500));
              }

              if (keywords) {
                const text = extractSearchText(keywords);
                if (text) ctxParts.push('KEYWORDS PRIORITARIAS (AI Search): ' + text.substring(0, 400));
              }

              // §7 Fase 7 — Inject competitor weakness map from D1
              try {
                const weaknessMap = await getCompetitorWeaknessMap(this.env);
                if (weaknessMap.summary) {
                  ctxParts.push('DEBILIDADES DE COMPETENCIA (explotar en contenido): ' + weaknessMap.summary.substring(0, 500));
                }
              } catch { /* non-critical */ }

              // §8 — Inject lessons learned from previous reviews
              try {
                const lessons = await getRelevantLessons(this.env, serviceSlug);
                if (lessons) {
                  ctxParts.push(lessons.substring(0, 600));
                }
              } catch { /* non-critical */ }

              aiSearchContext = ctxParts.join('\n\n');

              this.broadcast(JSON.stringify({
                type: 'ai-search-context',
                data: { serviceSlug, competitors: !!competitors, gaps: !!gaps, faqs: !!faqs, brand: !!brandGuide, previous: !!previous, keywords: !!keywords, contextLength: aiSearchContext.length },
              }));
            }
          } catch (e) {
            console.warn('[ContentAgent] AI Search context enrichment failed:', (e as Error).message);
          }
        }

        // ═══ INJECT SERVICE-SPECIFIC + ZONE-SPECIFIC PROMPTS ═══
        const servicePrompt = SERVICE_PROMPTS[serviceSlug] || '';
        const comboLocation = job.comboLocationSlug || '';
        // Look up location zone for zone prompt
        let zonePrompt = '';
        if (comboLocation) {
          try {
            const loc = await this.env.DB.prepare('SELECT zone FROM locations WHERE slug = ?').bind(comboLocation).first();
            if (loc?.zone) zonePrompt = ZONE_PROMPTS[loc.zone as string] || '';
          } catch { /* ignore */ }
        }
        if (servicePrompt || zonePrompt) {
          const specificCtx = `\n\n${servicePrompt}\n\n${zonePrompt}\n\nREGLAS DE CALIDAD:\n- Cada feature debe ser ÚNICO para este servicio. NO usar features genéricos como "Personal con certificación OS-10" en todos los servicios.\n- Las issues deben ser específicas al tipo de propiedad y zona. NO repetir "Accesos no controlados" en todas las páginas.\n- El proceso debe ser diferente según el servicio.\n- El intro debe hablar específicamente del servicio, NO de la empresa en general.\n- NUNCA repitas la misma palabra más del 2.5% del total del texto.\n- Type-Token Ratio mínimo: 45%.\n- NO uses frases genéricas como "empresa líder", "soluciones integrales", "amplia experiencia".\n- NO uses la frase "Es una pregunta frecuente que recibimos".`;
          aiSearchContext += specificCtx;
        }


        // Fetch existing images for this entity → inject into prompt context
        let existingImageContext = '';
        try {
          const { results: imgRows } = await this.env.DB.prepare(
            `SELECT me.usage, m.key, m.alt_text FROM media_entities me JOIN media_library m ON me.media_id = m.id WHERE me.entity_type = ? AND me.entity_slug = ? ORDER BY me.sort_order LIMIT 10`
          ).bind(job.entityType, job.entitySlug).all();
          const imgs = imgRows as any[];
          if (imgs.length > 0) {
            existingImageContext = '\n\nIMAGENES EXISTENTES:';
            imgs.forEach((img: any) => {
              existingImageContext += `\n- ${img.usage}: /${img.key} (alt: ${img.alt_text || 'N/A'})`;
            });
            this.broadcast(JSON.stringify({ type: 'image-context-loaded', data: { count: imgs.length } }));
          }
        } catch (e) {
          // media_entities may not have data yet
        }

        // Iterative generation loop
        for (let attempt = snapshot.attempt + 1; attempt <= MAX_ATTEMPTS; attempt++) {
          try {
            ctx.stash({
              job, attempt, bestContent, bestScore, bestDetails, lastError: null,
            } as GenerateFiberSnapshot);

            const aiContent = await callDeepSeekAI(
              job.entityType, job.entitySlug, job.entityName, this.env,
              null, currentScore, false, existingImageContext, aiSearchContext || undefined
            );

            if (!aiContent) {
              snapshot.lastError = 'No content generated';
              continue;
            }

            const guardrail = checkContentGuardrails(aiContent);
            if (!guardrail.passed) {
              console.warn(`[ContentAgent] Guardrails blocked ${job.entitySlug}: ${guardrail.violations.join(', ')}`);
              snapshot.lastError = `Guardrails: ${guardrail.violations.join(', ')}`;
              continue;
            }

            // v4: Use LLM review instead of just regex scoring
            const review = await reviewContent(this.env, aiContent, {
              type: job.entityType, slug: job.entitySlug, name: job.entityName,
            });

            const score = review.score;
            const details = {
              seo: review.seo,
              content: review.quality,
              structure: review.structure,
              keywords: review.uniqueness,
              _llmReview: true,
              feedback: review.feedback,
              suggestions: review.suggestions,
            };

            this.broadcast(JSON.stringify({
              type: 'generation-attempt',
              data: {
                entityType: job.entityType, entitySlug: job.entitySlug,
                attempt, score, details, reviewFeedback: review.feedback,
              },
            }));

            if (score > bestScore) {
              bestContent = aiContent;
              bestScore = score;
              bestAttempt = attempt;
              bestDetails = details;
              bestReview = review;
            }

            if (score >= SCORE_THRESHOLD) break;

            // Feed review feedback for next attempt
            currentScore = { score, details, feedback: review.feedback, suggestions: review.suggestions };
          } catch (err: any) {
            snapshot.lastError = err.message;
            this.broadcast(JSON.stringify({
              type: 'generation-error',
              data: { entityType: job.entityType, entitySlug: job.entitySlug, attempt, error: err.message?.substring(0, 200) },
            }));
          }
        }

        // Fallback
        if (!bestContent) {
          bestContent = generateFallbackContent(job.entityType, job.entitySlug, job.entityName);
          const { score, details } = calculateContentScore(bestContent);
          bestScore = score;
          bestDetails = details;
          bestAttempt = 0;
        }

        const finalScore = bestScore;
        const finalDetails = bestDetails;

        // Save review to audit_reports
        if (bestReview) {
          await saveReview(this.env, job.entityType, job.entitySlug, bestReview, JSON.stringify(bestContent).length);
          // Save lesson if score < 85
          if (finalScore < 85) {
            await saveLesson(this.env, job.entityType, job.entitySlug, bestReview);
          }
        }

        // Save to D1
        const { saved, savedTo } = await this.saveContent(job, bestContent, finalScore);

        // Auto-approve for publishing if score is high enough
        if (finalScore >= AUTO_APPROVE_THRESHOLD) {
          await this.approveForPublishing(job.entityType, job.entitySlug, bestContent, finalScore);
        }

        // Update stats
        this.setState({
          ...this.state,
          processing: false,
          stats: {
            ...this.state.stats,
            generated: this.state.stats.generated + (saved ? 1 : 0),
            failed: this.state.stats.failed + (saved ? 0 : 1),
            autoApproved: this.state.stats.autoApproved + (finalScore >= AUTO_APPROVE_THRESHOLD ? 1 : 0),
            totalAttempts: this.state.stats.totalAttempts + bestAttempt,
          },
          lastRunAt: new Date().toISOString(),
        });

        this.broadcast(JSON.stringify({
          type: 'generation-complete',
          data: {
            entityType: job.entityType, entitySlug: job.entitySlug, entityName: job.entityName,
            score: finalScore, details: finalDetails, attempts: bestAttempt,
            saved, savedTo, autoApproved: finalScore >= AUTO_APPROVE_THRESHOLD,
            review: bestReview,
          },
        }));

        resolve({
          content: bestContent, score: finalScore, details: finalDetails,
          attempts: bestAttempt, saved, savedTo, review: bestReview,
        });
      });
    });
  }

  /**
   * Generate content for multiple entities with staggered delays
   */
  async generateBulk(jobs: ContentJob[]): Promise<{ queued: number; jobs: ContentJob[] }> {
    for (let i = 0; i < jobs.length; i++) {
      await this.schedule(i * 60, 'processQueueJob', jobs[i]); // 60s between jobs
    }
    this.setState({
      ...this.state,
      queue: [...this.state.queue, ...jobs],
      processing: true,
    });
    return { queued: jobs.length, jobs };
  }

  /**
   * Get current agent state
   */
  async getStatus(): Promise<ContentAgentState> {
    return this.state;
  }

  // ===== FIBER RECOVERY =====

  async onFiberRecovered(ctx: any) {
    if (ctx.name?.startsWith('gen-')) {
      const snap = ctx.snapshot as GenerateFiberSnapshot | undefined;
      if (snap) {
        console.log(`[ContentAgent] Recovering fiber ${ctx.name}: attempt=${snap.attempt}, bestScore=${snap.bestScore}`);
      }
      // The fiber automatically resumes from the last stash() point
      // The for loop will continue from the next attempt
    }
  }

  // ===== SCHEDULED METHODS =====

  async processQueueJob(job: ContentJob) {
    try {
      await this.generateContent(job);
    } catch (err) {
      console.error('[ContentAgent] Queue job failed:', job.entityType, job.entitySlug, err);
    }
    const queue = this.state.queue.filter(j =>
      j.entityType !== job.entityType || j.entitySlug !== job.entitySlug
    );
    this.setState({ ...this.state, queue, processing: queue.length > 0 });
  }

  async refreshStaleContent() {
    console.log('[ContentAgent] Running stale content refresh...');
    const stale = await this.env.DB.prepare(`
      SELECT cv.entity_type, cv.entity_slug,
        CASE WHEN cv.entity_type = 'service' THEN s.name
             WHEN cv.entity_type = 'location' THEN l.name
             WHEN cv.entity_type = 'sector' THEN sec.name
        END as name
      FROM content_versions cv
      LEFT JOIN services s ON cv.entity_type = 'service' AND cv.entity_slug = s.slug
      LEFT JOIN locations l ON cv.entity_type = 'location' AND cv.entity_slug = l.slug
      LEFT JOIN sectors sec ON cv.entity_type = 'sector' AND cv.entity_slug = sec.slug
      WHERE cv.version = (SELECT MAX(version) FROM content_versions v2 WHERE v2.entity_type = cv.entity_type AND v2.entity_slug = cv.entity_slug)
        AND (cv.created_at < datetime('now', '-7 days') OR cv.word_count < 200)
    `).all();

    let count = 0;
    for (const item of (stale.results as any[])) {
      if (item.name) {
        await this.schedule(count * 120, 'processQueueJob', {
          entityType: item.entity_type,
          entitySlug: item.entity_slug,
          entityName: item.name,
        });
        count++;
      }
    }
    console.log(`[ContentAgent] Scheduled ${count} stale content refreshes`);
  }

  // ===== WEBSOCKET =====

  async onConnect(client: WebSocket) {
    client.send(JSON.stringify({ type: 'state', data: this.state }));
  }

  async onMessage(client: WebSocket, message: string) {
    try {
      const msg = JSON.parse(message);
      if (msg.type === 'getStatus') {
        client.send(JSON.stringify({ type: 'state', data: this.state }));
      }
    } catch { /* ignore invalid messages */ }
  }

  // ===== PRIVATE HELPERS =====

  private async getCurrentContent(job: ContentJob): Promise<any | null> {
    if (job.entityType === 'combo' && job.comboServiceSlug && job.comboLocationSlug) {
      const row = await this.env.DB.prepare(
        'SELECT seo_title, meta_description, h1, intro_paragraph, faqs_json, cta_text, cta_button, status, word_count FROM combo_content WHERE service_slug = ? AND location_slug = ?'
      ).bind(job.comboServiceSlug, job.comboLocationSlug).first();
      if (!row) return null;
      const sections: any = {};
      if (row.h1) sections.hero = { heading: row.h1, subheading: row.cta_text || '' };
      if (row.intro_paragraph) sections.intro = { heading: row.h1 || '', paragraphs: [row.intro_paragraph] };
      if (row.seo_title) sections.meta = { title: row.seo_title, description: row.meta_description || '' };
      if (row.faqs_json) { try { sections.faqs = { items: JSON.parse(row.faqs_json as string) }; } catch {} }
      return { sections };
    } else {
      const latest = await this.env.DB.prepare(
        'SELECT content_json, generated_by FROM content_versions WHERE entity_type = ? AND entity_slug = ? ORDER BY version DESC LIMIT 1'
      ).bind(job.entityType, job.entitySlug).first();
      if (!latest?.content_json) return null;
      return JSON.parse(latest.content_json as string);
    }
  }

  private async saveContent(job: ContentJob, content: GeneratedContent, score: number): Promise<{ saved: boolean; savedTo: string }> {
    const wordCount = JSON.stringify(content).split(/\s+/).length;
    const s = content.sections || (content as any);

    if (job.entityType === 'combo' && job.comboServiceSlug && job.comboLocationSlug) {
      await this.env.DB.prepare(
        `INSERT INTO combo_content (service_slug, location_slug, seo_title, meta_description, h1, intro_paragraph, local_context, faqs_json, cta_text, cta_button, status, word_count, generated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, datetime('now'))
         ON CONFLICT(service_slug, location_slug) DO UPDATE SET
           seo_title=excluded.seo_title, meta_description=excluded.meta_description, h1=excluded.h1,
           intro_paragraph=excluded.intro_paragraph, local_context=excluded.local_context, faqs_json=excluded.faqs_json,
           cta_text=excluded.cta_text, cta_button=excluded.cta_button, status='draft', word_count=excluded.word_count,
           generated_at=datetime('now'), updated_at=datetime('now')`
      ).bind(
        job.comboServiceSlug, job.comboLocationSlug,
        s.meta?.title || '', s.meta?.description || '',
        s.hero?.heading || '', (s.intro?.paragraphs || []).join('\n'),
        s.cta?.subheading || '',
        s.faqs?.items ? JSON.stringify(s.faqs.items) : null,
        s.cta?.heading || '', s.cta?.button || '',
        wordCount
      ).run();
      return { saved: true, savedTo: 'combo_content' };
    } else {
      const versionResult = await this.env.DB.prepare(
        'SELECT COALESCE(MAX(version), 0) + 1 as next_version FROM content_versions WHERE entity_type = ? AND entity_slug = ?'
      ).bind(job.entityType, job.entitySlug).first();
      const nextVersion = versionResult?.next_version || 1;
      await this.env.DB.prepare(
        'INSERT INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, word_count) VALUES (?, ?, ?, ?, ?, ?)'
      ).bind(job.entityType, job.entitySlug, nextVersion, JSON.stringify(content), 'ai', wordCount).run();
      return { saved: true, savedTo: 'content_versions' };
    }
  }

  private async approveForPublishing(entityType: string, entitySlug: string, content: GeneratedContent, score: number) {
    await this.env.DB.prepare(`
      INSERT INTO publish_queue (entity_type, entity_slug, content_json, score, status)
      VALUES (?, ?, ?, ?, 'approved')
    `).bind(entityType, entitySlug, JSON.stringify(content), score).run();

    this.broadcast(JSON.stringify({
      type: 'auto-approved',
      data: { entityType, entitySlug, score },
    }));
  }

  private async getServiceSlugForSector(sectorSlug: string): Promise<string> {
    const SECTOR_TO_SERVICE: Record<string, string> = {
      'comercial': 'guardias-de-seguridad',
      'construccion': 'seguridad-industrial',
      'educacion': 'guardias-de-seguridad',
      'eventos': 'seguridad-eventos',
      'industrial': 'seguridad-industrial',
      'residencial': 'guardias-de-seguridad',
      'salud': 'guardias-de-seguridad',
    };
    return SECTOR_TO_SERVICE[sectorSlug] || '';
  }


  /**
   * Get images for an entity (used by UI to preview + inject)
   */
  async getImages(entityType: string, entitySlug: string): Promise<any[]> {
    try {
      const { results } = await this.env.DB.prepare(
        `SELECT me.id, me.usage, me.entity_type, me.entity_slug, m.key, m.filename, m.alt_text, m.category, m.mime_type, m.file_size
         FROM media_entities me JOIN media_library m ON me.media_id = m.id
         WHERE me.entity_type = ? AND me.entity_slug = ? ORDER BY me.sort_order`
      ).bind(entityType, entitySlug).all();
      return results as any[];
    } catch {
      return [];
    }
  }
}
