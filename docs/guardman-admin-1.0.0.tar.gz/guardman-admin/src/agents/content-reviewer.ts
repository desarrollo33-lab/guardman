// GuardMan v4 — Content Reviewer (LLM-based evaluation)
// Replaces regex-based scoring with LLM evaluation
// Falls back to legacy scoring if LLM fails

import type { Env, GeneratedContent } from '../types';
import { infer } from '../services/inference';
import { calculateContentScore } from '../services/scoring';

export interface ReviewResult {
  score: number;
  quality: number;
  seo: number;
  structure: number;
  uniqueness: number;
  conversion: number;
  feedback: string;
  suggestions: string[];
  shouldPublish: boolean;
}

/**
 * Evaluate generated content using LLM
 */
export async function reviewContent(
  env: Env,
  content: GeneratedContent,
  entity: { type: string; slug: string; name: string }
): Promise<ReviewResult> {
  const s = content.sections || content;

  const prompt = `Evalúa este contenido SEO para "${entity.name}" (${entity.slug}):

HERO:
  H1: ${s.hero?.heading || 'MISSING'}
  Sub: ${s.hero?.subheading || 'MISSING'}

META:
  Title (${(s.meta?.title || '').length}/60): ${s.meta?.title || 'MISSING'}
  Description (${(s.meta?.description || '').length}/160): ${s.meta?.description || 'MISSING'}

INTRO: ${(s.intro?.paragraphs?.length || 0)} párrafos
FEATURES: ${(s.features?.items?.length || 0)} items
ISSUES: ${(s.issues?.items?.length || 0)} items
STATS: ${(s.stats?.items?.length || 0)} items
FAQs: ${(s.faqs?.items?.length || 0)} items
CTA: ${s.cta?.heading ? '✓' : '✗'} ${s.cta?.button || 'NO BUTTON'}

Evalúa en escala 0-100 cada dimensión:
- quality: ¿Suena natural? ¿Aporta valor real? ¿O es genérico?
- seo: ¿Title < 60 chars? ¿Description < 160? ¿Keywords en H1?
- structure: ¿Todas las secciones completas? ¿Hierarchy H1→H2→H3?
- uniqueness: ¿Se diferencia de contenido genérico? ¿Datos específicos?
- conversion: ¿CTA claro? ¿Urgencia? ¿Contacto?

Responde SOLO con JSON:
{ "score": 0-100, "quality": 0-100, "seo": 0-100, "structure": 0-100, "uniqueness": 0-100, "conversion": 0-100, "feedback": "...", "suggestions": ["...", "..."], "shouldPublish": true/false }`;

  try {
    const response = await infer(env, 'evaluation',
      'Eres un evaluador SEO experto para contenido chileno. Evalúa contenido y retorna SOLO JSON válido.',
      prompt,
      { temperature: 0.1, maxTokens: 1024, jsonMode: true }
    );

    const parsed = JSON.parse(response);
    return {
      score: Math.min(100, Math.max(0, parsed.score || 0)),
      quality: Math.min(100, Math.max(0, parsed.quality || 0)),
      seo: Math.min(100, Math.max(0, parsed.seo || 0)),
      structure: Math.min(100, Math.max(0, parsed.structure || 0)),
      uniqueness: Math.min(100, Math.max(0, parsed.uniqueness || 0)),
      conversion: Math.min(100, Math.max(0, parsed.conversion || 0)),
      feedback: parsed.feedback || '',
      suggestions: Array.isArray(parsed.suggestions) ? parsed.suggestions : [],
      shouldPublish: parsed.shouldPublish || false,
    };
  } catch (e) {
    const legacy = calculateContentScore(content);
    return {
      score: legacy.score,
      quality: legacy.details.contentQuality,
      seo: legacy.details.seoOptimization,
      structure: legacy.details.structure,
      uniqueness: legacy.details.differentiation,
      conversion: legacy.details.structure,
      feedback: 'LLM evaluation failed, using legacy scoring',
      suggestions: [],
      shouldPublish: legacy.score >= 75,
    };
  }
}

/**
 * Save review result to audit_reports table
 */
export async function saveReview(
  env: Env,
  entityType: string,
  entitySlug: string,
  review: ReviewResult,
  contentLength: number
): Promise<void> {
  try {
    await env.DB.prepare(`
      INSERT INTO audit_reports (entity_type, entity_slug, report_type, score, details_json, created_at)
      VALUES (?, ?, 'content_review', ?, ?, datetime('now'))
    `).bind(
      entityType, entitySlug, review.score,
      JSON.stringify({
        quality: review.quality,
        seo: review.seo,
        structure: review.structure,
        uniqueness: review.uniqueness,
        conversion: review.conversion,
        feedback: review.feedback,
        suggestions: review.suggestions,
        contentLength,
      })
    ).run();
  } catch (e) {
    // audit_reports table may not exist
    console.warn('[Reviewer] Could not save review:', (e as Error).message);
  }
}

/**
 * Save a lesson learned to agent_corrections
 */
export async function saveLesson(
  env: Env,
  entityType: string,
  entitySlug: string,
  review: ReviewResult
): Promise<void> {
  try {
    if (review.feedback && review.feedback.length > 10) {
      await env.DB.prepare(`
        INSERT INTO agent_corrections (entity_type, entity_slug, correction_type, feedback, applied, created_at)
        VALUES (?, ?, 'review_feedback', ?, 0, datetime('now'))
      `).bind(entityType, entitySlug, review.feedback).run();
    }
  } catch (e) {
    console.warn('[Reviewer] Could not save lesson:', (e as Error).message);
  }
}
