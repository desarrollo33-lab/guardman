// GuardMan Admin — Competitor Analyst Sub-Agent
// Item 15: Sub-agents facets — Specialized competitor research
// RPC methods callable via this.subAgent(CompetitorAnalystAgent, "main")
import { Agent } from 'agents';
import type { Env as AppEnv } from '../types/index';

type AnalystEnv = AppEnv & Record<string, unknown>;

interface CompetitorProfile {
  domain: string;
  appearances: number;
  positions: number[];
  avg_position: number;
  site_type: string;
  titles: string[];
  snippets: string[];
}

interface MarketAnalysis {
  service_slug: string;
  location_slug: string;
  total_queries: number;
  total_results: number;
  competitors: CompetitorProfile[];
  top_domains: { domain: string; count: number }[];
  content_gaps: string[];
  market_coverage: number;
  analyzed_at: string;
}

export class CompetitorAnalystAgent extends Agent<AnalystEnv> {
  declare env: AnalystEnv;
  declare ctx: any;
  initialState = {};

  async onStart() {
    await this.ctx.storage.sql.exec(`
      CREATE TABLE IF NOT EXISTS analysis_cache (
        service_slug TEXT NOT NULL,
        location_slug TEXT NOT NULL,
        result_json TEXT NOT NULL,
        analyzed_at TEXT NOT NULL,
        PRIMARY KEY (service_slug, location_slug)
      )
    `);
  }

  /**
   * Deep analysis of competitors for a service+location combo
   */
  async analyzeCompetitors(service_slug: string, location_slug: string): Promise<MarketAnalysis> {
    // Check cache
    const cached = await this.ctx.storage.sql.exec(
      `SELECT result_json FROM analysis_cache WHERE service_slug = ? AND location_slug = ?`,
      service_slug, location_slug
    ).toArray();

    if (cached.length > 0) {
      const parsed = JSON.parse(cached[0].result_json as string);
      const age = Date.now() - new Date(parsed.analyzed_at).getTime();
      if (age < 3600000) return parsed;
    }

    // Fetch all Serper data for this combo
    const queries = await this.env.DB.prepare(
      `SELECT id, query_text, credits_used FROM serper_queries WHERE service_slug = ? AND location_slug = ?`
    ).bind(service_slug, location_slug).all();

    const queryIds = queries.results.map((q: any) => q.id);
    const competitorMap = new Map<string, CompetitorProfile>();

    for (const qId of queryIds) {
      const results = await this.env.DB.prepare(
        `SELECT domain, title, snippet, position, site_type FROM serper_results WHERE query_id = ?`
      ).bind(qId).all();

      for (const r of results.results as any[]) {
        if (!r.domain) continue;
        const domain = (r.domain as string).replace(/^www\./, '');

        if (!competitorMap.has(domain)) {
          competitorMap.set(domain, { domain, appearances: 0, positions: [], avg_position: 0, site_type: r.site_type || 'unknown', titles: [], snippets: [] });
        }

        const profile = competitorMap.get(domain)!;
        profile.appearances++;
        if (r.position) profile.positions.push(r.position as number);
        if (r.title) profile.titles.push(r.title as string);
        if (r.snippet) profile.snippets.push(r.snippet as string);
      }
    }

    // Calculate averages and sort
    const competitors = Array.from(competitorMap.values())
      .map(c => ({
        ...c,
        avg_position: c.positions.length > 0 ? Math.round(c.positions.reduce((a, b) => a + b, 0) / c.positions.length * 10) / 10 : 0,
        titles: c.titles.slice(0, 5),
        snippets: c.snippets.slice(0, 3),
      }))
      .sort((a, b) => b.appearances - a.appearances)
      .slice(0, 20);

    const topDomains = competitors.slice(0, 10).map(c => ({ domain: c.domain, count: c.appearances }));
    const contentGaps = await this.identifyContentGaps(service_slug, location_slug);
    const totalResults = competitors.reduce((sum, c) => sum + c.appearances, 0);
    const marketCoverage = Math.min(100, Math.round((queryIds.length / 10) * 100));

    const analysis: MarketAnalysis = {
      service_slug, location_slug,
      total_queries: queryIds.length,
      total_results: totalResults,
      competitors,
      top_domains: topDomains,
      content_gaps: contentGaps,
      market_coverage: marketCoverage,
      analyzed_at: new Date().toISOString(),
    };

    // Cache
    await this.ctx.storage.sql.exec(
      `INSERT OR REPLACE INTO analysis_cache (service_slug, location_slug, result_json, analyzed_at) VALUES (?, ?, ?, ?)`,
      service_slug, location_slug, JSON.stringify(analysis), new Date().toISOString()
    );

    return analysis;
  }

  /**
   * Compare competitor landscape across locations for a service
   */
  async compareLocations(service_slug: string): Promise<{
    service: string;
    locations: { location: string; queries: number; top_competitor: string; coverage: number }[];
  }> {
    const locations = await this.env.DB.prepare(
      `SELECT DISTINCT location_slug, COUNT(*) as query_count FROM serper_queries WHERE service_slug = ? GROUP BY location_slug ORDER BY query_count DESC`
    ).bind(service_slug).all();

    const locationAnalysis = [];
    for (const loc of locations.results as any[]) {
      const analysis = await this.analyzeCompetitors(service_slug, loc.location_slug);
      locationAnalysis.push({
        location: loc.location_slug,
        queries: analysis.total_queries,
        top_competitor: analysis.competitors[0]?.domain || 'N/A',
        coverage: analysis.market_coverage,
      });
    }

    return { service: service_slug, locations: locationAnalysis };
  }

  /**
   * Get the strongest competitors across all services
   */
  async getTopCompetitors(limit: number = 10): Promise<{
    competitors: { domain: string; total_appearances: number; services: number; avg_position: number }[];
  }> {
    const allCache = await this.ctx.storage.sql.exec(`SELECT result_json FROM analysis_cache`).toArray();

    const domainAgg = new Map<string, { appearances: number; services: Set<string>; positions: number[] }>();

    for (const row of allCache) {
      const analysis: MarketAnalysis = JSON.parse(row.result_json as string);
      for (const comp of analysis.competitors) {
        if (!domainAgg.has(comp.domain)) {
          domainAgg.set(comp.domain, { appearances: 0, services: new Set(), positions: [] });
        }
        const agg = domainAgg.get(comp.domain)!;
        agg.appearances += comp.appearances;
        agg.services.add(analysis.service_slug);
        agg.positions.push(...comp.positions);
      }
    }

    const competitors = Array.from(domainAgg.entries())
      .map(([domain, data]) => ({
        domain,
        total_appearances: data.appearances,
        services: data.services.size,
        avg_position: data.positions.length > 0 ? Math.round(data.positions.reduce((a, b) => a + b, 0) / data.positions.length * 10) / 10 : 0,
      }))
      .sort((a, b) => b.total_appearances - a.total_appearances)
      .slice(0, limit);

    return { competitors };
  }

  /**
   * Identify content gaps for a service/location
   */
  async identifyContentGaps(service_slug: string, location_slug: string): Promise<string[]> {
    const existingContent = await this.env.DB.prepare(
      `SELECT service_slug, location_slug FROM combo_content`
    ).all();

    const existingCombos = new Set(
      existingContent.results.map((r: any) => `${r.service_slug}-${r.location_slug}`)
    );

    const allCombos = await this.env.DB.prepare(
      `SELECT s.slug as service_slug, l.slug as location_slug FROM services s CROSS JOIN locations l WHERE s.status = 'active' AND l.status = 'active'`
    ).all();

    const gaps: string[] = [];
    for (const combo of allCombos.results as any[]) {
      const key = `${combo.service_slug}-${combo.location_slug}`;
      if (!existingCombos.has(key)) gaps.push(key);
    }

    return gaps.filter(g => g.startsWith(service_slug + '-') || g.endsWith('-' + location_slug)).slice(0, 15);
  }

  /**
   * Clear analysis cache
   */
  async clearCache(service_slug?: string, location_slug?: string): Promise<{ cleared: number }> {
    if (service_slug && location_slug) {
      await this.ctx.storage.sql.exec(`DELETE FROM analysis_cache WHERE service_slug = ? AND location_slug = ?`, service_slug, location_slug);
      return { cleared: 1 };
    }
    await this.ctx.storage.sql.exec(`DELETE FROM analysis_cache`);
    return { cleared: -1 };
  }
}
