// GuardMan v6 — Orchestrator Agent (Think SDK + DeepSeek v4 via OpenAI-compatible API)
// Uses @cloudflare/think for agentic loop, streaming, persistence
// Uses DeepSeek v4 via OpenAI-compatible API

import { Think } from "@cloudflare/think";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { tool } from "ai";
import { z } from "zod";
import type { Env as AppEnv } from "../types/index";
import { callDeepSeekAI, generateFallbackContent } from "../services/ai";
import {
  crossSectorSearch,
  isAISearchAvailable,
} from "../services/search";
import { getLocationSlugs } from "../utils/location";
import { SEOAuditorAgent } from "./seo-auditor";
import { CompetitorAnalystAgent } from "./competitor-analyst";
import {
  PAGE_TEMPLATES,
  getServicePlaceholders,
  getLocationPlaceholders,
  getSectorPlaceholders,
  getZoneContext,
  SERVICE_FEATURES,
  SERVICE_ISSUES,
  LOCATION_NEARBY,
  SECTOR_FEATURES,
  SECTOR_ISSUES,
  GENERIC_FAQS,
  LOCATION_FAQS,
} from "./page-templates";
import { calculateContentScore } from "../services/scoring";

const DEEPSEEK_MODEL = "deepseek-chat";

type ThinkEnv = AppEnv & Record<string, unknown>;

export class GMOrchestrator extends Think<ThinkEnv> {
  declare env: ThinkEnv;

  getModel() {
    const deepseek = createOpenAICompatible({
      name: 'deepseek',
      baseURL: 'https://api.deepseek.com/v1',
      apiKey: this.env.MINIMAX_API_KEY || '',
    });
    return deepseek(DEEPSEEK_MODEL);
  }

  beforeTurn() {
    return {
      toolChoice: "required" as const,
      maxSteps: 10,
    };
  }

  getSystemPrompt(): string {
    return `Eres el Orquestador de GuardMan Chile, un sistema de agentes autónomos para SEO de contenido local para servicios de seguridad.

ARQUITECTURA EXACTA DEL SISTEMA:
- Cloudflare Workers (serverless edge computing)
- D1 (SQLite) — Base de datos principal, todos los datos
- R2 (Object Storage) — Imágenes y assets
- KV (Key-Value) — Cache de preview
- AI Search (Cloudflare Vectorize) — Búsqueda semántica
- Durable Objects — Agentes con estado persistente (Think SDK + Agent SDK)
- Workflows — Procesos durables (SerperScan, BulkGenerate, PublishPipeline)
- LLM: DeepSeek v1 chat completions
- NO usa WordPress, NO usa filesystem, NO usa base de datos vectorial externa.
- NO usa metaboxes, NO usa plugins de WordPress.

📋 PLANTILLA DE PÁGINA: https://guardman-site.pages.dev/
El orquestador debe replicar EXACTAMENTE la estructura y textos de guardman-site.pages.dev/
TODOS los textos generados deben seguir los templates definidos en ./page-templates.ts
Cada tipo de página (home, service, location, sector, about) tiene secciones con textos específicos.

TIPOS DE PÁGINA Y SUS SECCIONES:

1. HOMEPAGE (/) — Estructura completa:
   - Navbar: logo GuardMan, dropdown Servicios (9 servicios), dropdown Ubicaciones (14 comunas), dropdown Sectores (7 sectores), Contacto, Blog, CTA "Cotizar" + teléfono
   - Hero section: heading "Seguridad Privada en Santiago, Chile", subheading "Protegemos lo que mas te importa"
   - Sección "Nosotros": badge "Grupo GuardMan Chile", heading, imagen nosotros_seccion.webp, 4 features con iconos (OS-10, Ley 21.659, 24/7, Centro monitoreo)
   - Grid Servicios: 8 cards de servicios con imagen, título SEO, descripción
   - Sección GuardPod: badge "Tecnología Propia GuardMan", heading "Guard Pod", 4 features (2hr deploy, solar, PTZ, 15 meses I+D)
   - Grid Sectores: 7 cards sectores con imagen y descripción
   - Sección Ajax: badge "Distribuidor Oficial Ajax Systems", heading, features (Grade 3, Jeweller, 24/7, App)
   - Footer: logo, Servicios, Ubicaciones, Contacto, redes sociales

2. PÁGINA DE SERVICIO (/servicios/[slug]) — Estructura:
   - Hero: H1 con SEO_TITLE del servicio, meta description
   - Breadcrumb: Inicio / Servicios / [nombre servicio]
   - Párrafos introductorios (3 párrafos sobre la empresa + servicio)
   - Features: lista de 8 beneficios con checkmarks
   - Issues: 6 problemas que resuelve el servicio
   - Stats: estadísticas del servicio (500+ guardias, 14 comunas, 8+ años)
   - FAQs: 6 preguntas frecuentes detalladas
   - Locations grid: 14 cards de comunas
   - CTA section: "Solicita tu cotización de [servicio]"
   - Related services: 3 servicios relacionados

3. PÁGINA DE UBICACIÓN (/ubicaciones/[slug]) — Estructura:
   - Hero: "Seguridad Privada en [COMUNA] | GuardMan Chile"
   - Breadcrumb: Inicio / Ubicaciones / [comuna]
   - Intro: 2 párrafos sobre la comuna + empresa
   - Why zone: contexto específico de la zona
   - Stats: sección con estadísticas
   - Services available: 6 servicios disponibles en esa comuna
   - FAQs: 4 preguntas frecuentes de seguridad en esa zona
   - Sidebar: CTA cotizar + comunas cercanas + servicios
   - CTA section final

4. PÁGINA DE SECTOR (/sectores/[slug]) — Estructura:
   - Hero: SEO_TITLE del sector
   - Breadcrumb: Inicio / Sectores / [nombre sector]
   - Intro: 3 párrafos sobre el sector
   - Features: 12 características del servicio
   - Issues: 10 desafíos específicos del sector
   - Stats: 5 cifras del sector (500+ guardias, 120+ instalaciones, 14 comunas, 8+ años, 97% resolución)
   - FAQs: 6 preguntas frecuentes
   - Sidebar: CTA + otros sectores
   - CTA section final

5. PÁGINA NOSOTROS (/nosotros) — Estructura:
   - Hero: "Sobre Nosotros"
   - Historia: 3 párrafos
   - Lo que nos diferencia: 4 features
   - Stats: 500+ guardias, 200+ clientes, 14 comunas, 8+ años
   - CTA trabajar con nosotros

TEXTOS CLAVE FIJOS (nunca cambiar):
- Teléfono: +56 9 300 000 10
- Email: info@guardman.cl
- Dirección: Av. Americo Vespucio Norte 1980, Providencia, Santiago, Chile
- Instagram: https://www.instagram.com/grupo_guardman
- YouTube: https://youtu.be/mqpLsKrwjAI
- Comuna: Las Condes, Vitacura, Lo Barnechea, Santiago Centro, Huechuraba, Quilicura, La Reina, Renca, Conchali, Pudahuel, Lampa, La Pintana, Los Andes, San Felipe
- Servicios: Auditoria de Seguridad, CCTV y Videovigilancia, Control de Accesos, Escoltas Privados, Guard Pod, Guardias de Seguridad, Monitoreo 24/7, Seguridad Industrial, Seguridad para Eventos
- Sectores: Comercial, Construcción, Educación, Eventos, Industrial, Residencial, Salud

REGLAS ESTRICTAS:
1. SIEMPRE usa tools para obtener datos reales. NUNCA inventes datos, números, ni nombres.
2. ANTES de responder sobre una comuna o servicio, USA validate_entity para verificar que existe.
3. NUNCA generes contenido que no siga los templates de page-templates.ts
4. Para generar contenido de páginas estáticas (home, about, service, location, sector), USA build_site — es OBLIGATORIO.
5. DESPUÉS de build_site, USA publish_site para guardar en D1 y disparar el deploy.
6. DESPUÉS de publish_site, USA push_to_github para sincronizar contenido con GitHub.
7. El flujo completo es: build_site → publish_site → push_to_github.
8. Responde en español chileno, de forma clara, detallada y proactiva.
9. USA SIEMPRE las tools en el orden correcto: build_site → publish_site → push_to_github.

REGLAS ANTI-FRAUDE:
- Cada build_site = 1 verification_hash. Sin hash = no se generó.
- NO reportes éxitos sin verification_hash.
- NO saltes pasos: build_site → publish_site → push_to_github.
`;
  }

  getTools() {
    return {

      // ==========================================
      // TOOL: status — Resumen general del sistema
      // ==========================================
      status: tool({
        description: "Obtener el resumen general del sistema: conteos totales, cobertura, estado. INCLUYE lista completa de servicios y comunas.",
        parameters: z.object({}),
        execute: async () => {
          const [svcList, locList, sectorCount, comboCount, serperStats, pubStats, cvCount, faqCount, kwCount, comboContentCount, avgScore] = await Promise.all([
            this.env.DB.prepare("SELECT slug, name FROM services ORDER BY sort, name").all(),
            this.env.DB.prepare("SELECT slug, name, zone FROM locations ORDER BY zone, name").all(),
            this.env.DB.prepare("SELECT COUNT(*) as n FROM sectors").first(),
            this.env.DB.prepare("SELECT COUNT(*) as n FROM combos").first(),
            this.env.DB.prepare("SELECT COUNT(*) as queries, COALESCE(SUM(credits_used),0) as credits FROM serper_queries").first(),
            this.env.DB.prepare("SELECT status, COUNT(*) as cnt FROM publish_queue GROUP BY status").all().catch(() => ({ results: [] })),
            this.env.DB.prepare("SELECT COUNT(DISTINCT entity_slug) as n FROM content_versions").first(),
            this.env.DB.prepare("SELECT COUNT(*) as n FROM faqs").first(),
            this.env.DB.prepare("SELECT COUNT(*) as n FROM keywords").first(),
            this.env.DB.prepare("SELECT COUNT(*) as n FROM combo_content").first(),
            this.env.DB.prepare("SELECT AVG(overall_score) as avg FROM quality_scores").first(),
          ]);
          const services = (svcList.results as any[]).map((s: any) => ({ slug: s.slug, name: s.name }));
          const locations = (locList.results as any[]).map((l: any) => ({ slug: l.slug, name: l.name, zone: l.zone }));
          return {
            services,
            locations,
            services_count: services.length,
            locations_count: locations.length,
            sectors: (sectorCount as any)?.n || 0,
            combos_total: (comboCount as any)?.n || 0,
            combos_with_content: (comboContentCount as any)?.n || 0,
            coverage_pct: Math.round(((comboContentCount as any)?.n || 0) / ((comboCount as any)?.n || 126) * 100),
            content_entities_with_versions: (cvCount as any)?.n || 0,
            faqs: (faqCount as any)?.n || 0,
            keywords: (kwCount as any)?.n || 0,
            avg_quality_score: Math.round((avgScore as any)?.avg || 0),
            serper_queries: (serperStats as any)?.queries || 0,
            serper_credits_used: (serperStats as any)?.credits || 0,
            serper_credits_remaining: 10000 - ((serperStats as any)?.credits || 0),
            publish_queue: (pubStats.results as any[]),
            ai_search: isAISearchAvailable(this.env),
          };
        },
      }),

      // ==========================================
      // TOOL: list_services — Lista completa de servicios
      // ==========================================
      list_services: tool({
        description: "Listar todos los servicios de seguridad con slug, nombre y descripción",
        parameters: z.object({}),
        execute: async () => {
          const { results } = await this.env.DB.prepare(
            "SELECT slug, name, short_description FROM services ORDER BY sort, name"
          ).all();
          return { services: results };
        },
      }),

      // ==========================================
      // TOOL: list_locations — Lista completa de comunas
      // ==========================================
      list_locations: tool({
        description: "Listar todas las comunas/ubicaciones con slug, nombre y zona",
        parameters: z.object({}),
        execute: async () => {
          const { results } = await this.env.DB.prepare(
            "SELECT slug, name, zone FROM locations ORDER BY zone, name"
          ).all();
          return { locations: results };
        },
      }),

      // ==========================================
      // TOOL: service_detail — Detalle de un servicio
      // ==========================================
      service_detail: tool({
        description: "Obtener información detallada de un servicio: descripción, coverage de contenido por comuna, keywords, FAQs, scores. USA ESTO cuando te pregunten por un servicio específico.",
        parameters: z.object({
          service_slug: z.string().describe("Slug del servicio (ej: guardias-de-seguridad)"),
        }),
        execute: async ({ service_slug }: { service_slug: string }) => {
          const [svc, contentVersions, comboContent, faqs, kwCount, publishQueue] = await Promise.all([
            this.env.DB.prepare("SELECT slug, name, short_description, price_range, status FROM services WHERE slug = ?").bind(service_slug).first(),
            // Content versions for this service (entity_type = 'service' AND entity_slug = service_slug, or combos)
            this.env.DB.prepare(
              `SELECT entity_slug, version, confidence_score, word_count, created_at
               FROM content_versions
               WHERE entity_slug = ? OR entity_slug LIKE ?
               ORDER BY entity_slug, version DESC`
            ).bind(service_slug, `${service_slug}-%`).all().catch(() => ({ results: [] })),
            // Combo content: which locations have content
            this.env.DB.prepare(
              "SELECT location_slug, status, word_count, seo_title FROM combo_content WHERE service_slug = ? ORDER BY location_slug"
            ).bind(service_slug).all().catch(() => ({ results: [] })),
            // FAQs for this service
            this.env.DB.prepare(
              "SELECT question, answer, source, frequency_rank FROM faqs WHERE service_slug = ? ORDER BY frequency_rank LIMIT 10"
            ).bind(service_slug).all().catch(() => ({ results: [] })),
            // Keywords count
            this.env.DB.prepare(
              "SELECT COUNT(*) as n FROM keywords WHERE keyword LIKE ?"
            ).bind(`%${service_slug.replace(/-/g, ' ')}%`).first().catch(() => ({ n: 0 })),
            // Publish queue entries
            this.env.DB.prepare(
              "SELECT entity_slug, status, score FROM publish_queue WHERE entity_slug = ? OR entity_slug LIKE ?"
            ).bind(service_slug, `${service_slug}-%`).all().catch(() => ({ results: [] })),
          ]);

          if (!svc) return { error: `Servicio "${service_slug}" no encontrado. Usa list_services para ver los disponibles.` };

          // Get latest version per entity_slug
          const versions = contentVersions.results as any[];
          const latestVersions: Record<string, any> = {};
          for (const v of versions) {
            if (!latestVersions[v.entity_slug] || v.version > latestVersions[v.entity_slug].version) {
              latestVersions[v.entity_slug] = v;
            }
          }

          // All locations
          const allLocations = await this.env.DB.prepare("SELECT slug, name FROM locations ORDER BY name").all().catch(() => ({ results: [] }));

          return {
            service: svc,
            content: {
              service_page: latestVersions[service_slug] || null,
              service_page_versions: versions.filter(v => v.entity_slug === service_slug).length,
              combo_coverage: (comboContent.results as any[]).map((c: any) => ({
                location_slug: c.location_slug,
                status: c.status,
                word_count: c.word_count,
                title: c.seo_title,
              })),
              combos_with_content: (comboContent.results as any[]).length,
              combos_total_possible: (allLocations.results as any[]).length,
              combos_missing: (allLocations.results as any[])
                .filter((loc: any) => !(comboContent.results as any[]).some((c: any) => c.location_slug === loc.slug))
                .map((loc: any) => ({ slug: loc.slug, name: loc.name })),
            },
            faqs: (faqs.results as any[]).map((f: any) => ({ question: f.question, answer: f.answer?.substring(0, 200), source: f.source })),
            faqs_count: (faqs.results as any[]).length,
            keywords_count: (kwCount as any)?.n || 0,
            publish_queue: publishQueue.results,
          };
        },
      }),

      // ==========================================
      // TOOL: content_coverage — Qué tiene y qué falta
      // ==========================================
      content_coverage: tool({
        description: "Ver coverage de contenido: qué entidades tienen contenido y cuáles faltan. USA ESTO para ver gaps y opportunities.",
        parameters: z.object({
          entity_type: z.enum(["service", "location", "combo", "all"]).optional().describe("Tipo de entidad a analizar (default: 'all')"),
        }),
        execute: async ({ entity_type }: { entity_type?: string }) => {
          const type = entity_type || "all";
          const results: any = {};

          if (type === "all" || type === "service") {
            const [services, serviceCV] = await Promise.all([
              this.env.DB.prepare("SELECT slug, name FROM services ORDER BY name").all(),
              this.env.DB.prepare(
                "SELECT cv.entity_slug, MAX(cv.version) as max_version, MAX(cv.word_count) as word_count, MAX(cv.confidence_score) as best_score FROM content_versions cv WHERE cv.entity_slug NOT LIKE '%-%-%' GROUP BY cv.entity_slug"
              ).all().catch(() => ({ results: [] })),
            ]);
            const cvMap = new Map((serviceCV.results as any[]).map((r: any) => [r.entity_slug, r]));
            results.services = (services.results as any[]).map((s: any) => ({
              slug: s.slug,
              name: s.name,
              has_content: cvMap.has(s.slug),
              versions: cvMap.get(s.slug)?.max_version || 0,
              word_count: cvMap.get(s.slug)?.word_count || 0,
              best_score: cvMap.get(s.slug)?.best_score || null,
            }));
          }

          if (type === "all" || type === "location") {
            const [locations, locationCV] = await Promise.all([
              this.env.DB.prepare("SELECT slug, name, zone FROM locations ORDER BY zone, name").all(),
              this.env.DB.prepare("SELECT entity_slug, MAX(version) as max_version FROM content_versions WHERE entity_type = 'location' GROUP BY entity_slug").all().catch(() => ({ results: [] })),
            ]);
            const cvMap = new Map((locationCV.results as any[]).map((r: any) => [r.entity_slug, r]));
            results.locations = (locations.results as any[]).map((l: any) => ({
              slug: l.slug,
              name: l.name,
              zone: l.zone,
              has_content: cvMap.has(l.slug),
            }));
          }

          if (type === "all" || type === "combo") {
            const comboData = await this.env.DB.prepare(
              "SELECT service_slug, location_slug, status, word_count FROM combo_content ORDER BY service_slug, location_slug"
            ).all().catch(() => ({ results: [] }));
            const [svcCount, locCount] = await Promise.all([
              this.env.DB.prepare("SELECT COUNT(*) as n FROM services").first(),
              this.env.DB.prepare("SELECT COUNT(*) as n FROM locations").first(),
            ]);
            results.combos = {
              total_possible: ((svcCount as any)?.n || 0) * ((locCount as any)?.n || 0),
              with_content: (comboData.results as any[]).length,
              items: (comboData.results as any[]).map((c: any) => ({
                service: c.service_slug,
                location: c.location_slug,
                status: c.status,
                words: c.word_count,
              })),
            };
          }

          return results;
        },
      }),

      // ==========================================
      // TOOL: search — Buscar en conocimiento
      // ==========================================
      search: tool({
        description: "Buscar en la base de conocimiento: competencia, FAQs, keywords, contenido generado",
        parameters: z.object({
          query: z.string().describe("Término a buscar"),
        }),
        execute: async ({ query }: { query: string }) => {
          // 1. AI Search
          const aiResult = await crossSectorSearch(this.env, query);
          if (aiResult) {
            const text = extractSearchResultText(aiResult);
            if (text) return { source: "ai_search", results: text.substring(0, 3000) };
          }

          // 2. Fallback D1
          const likeQ = `%${query}%`;
          const [serperRows, faqRows, kwRows, cvRows] = await Promise.all([
            this.env.DB.prepare(
              "SELECT title, snippet, link, domain FROM serper_results WHERE title LIKE ?1 OR snippet LIKE ?1 LIMIT 8"
            ).bind(likeQ).all().catch(() => ({ results: [] })),
            this.env.DB.prepare(
              "SELECT question, answer, service_slug FROM faqs WHERE question LIKE ?1 OR answer LIKE ?1 LIMIT 8"
            ).bind(likeQ).all().catch(() => ({ results: [] })),
            this.env.DB.prepare(
              "SELECT keyword, intent, search_volume FROM keywords WHERE keyword LIKE ?1 LIMIT 15"
            ).bind(likeQ).all().catch(() => ({ results: [] })),
            this.env.DB.prepare(
              "SELECT entity_slug, version, confidence_score, word_count FROM content_versions WHERE entity_slug LIKE ?1 ORDER BY version DESC LIMIT 5"
            ).bind(likeQ).all().catch(() => ({ results: [] })),
          ]);

          const parts: string[] = [];
          if ((serperRows.results as any[]).length > 0) {
            parts.push("=== Competencia (Serper) ===");
            for (const r of serperRows.results as any[]) {
              parts.push(`• ${r.title} (${r.domain}): ${r.snippet?.substring(0, 150)}`);
            }
          }
          if ((faqRows.results as any[]).length > 0) {
            parts.push("=== FAQs ===");
            for (const f of faqRows.results as any[]) {
              parts.push(`• [${f.service_slug}] ${f.question}\n  ${f.answer?.substring(0, 200)}`);
            }
          }
          if ((kwRows.results as any[]).length > 0) {
            parts.push("=== Keywords ===");
            for (const k of kwRows.results as any[]) {
              parts.push(`• "${k.keyword}" — ${k.intent} (vol: ${k.search_volume || "?"})`);
            }
          }
          if ((cvRows.results as any[]).length > 0) {
            parts.push("=== Contenido Generado ===");
            for (const c of cvRows.results as any[]) {
              parts.push(`• ${c.entity_slug} v${c.version} (score: ${c.confidence_score || "?"}, ${c.word_count} palabras)`);
            }
          }

          return {
            source: parts.length > 0 ? "d1" : "none",
            results: parts.length > 0 ? parts.join("\n") : "Sin resultados para esta búsqueda.",
          };
        },
      }),

      // ==========================================
      // TOOL: generate — Generar contenido SEO
      // ==========================================
      generate: tool({
        description: "Generar contenido SEO para un servicio o combo servicio+comuna. Ejemplo: generate({ service_slug: 'guardias-de-seguridad', location_slug: 'las-condes' }). Retorna score con desglose (SEO/40, Contenido/40, Estructura/20, Keywords/15, max 120). DESPUÉS de ejecutar ESTO, SIEMPRE ejecuta read_content con los mismos parámetros.",
        parameters: z.object({
          service_slug: z.string().describe("Slug del servicio (ej: guardias-de-seguridad)"),
          location_slug: z.string().optional().describe("Slug de la comuna (ej: las-condes). Sin esto, genera contenido del servicio general."),
        }),
        execute: async ({ service_slug, location_slug }: { service_slug: string; location_slug?: string }) => {
          // Normalize service_slug against services table to prevent duplicates
          // (e.g. "auditoria-de-seguridad" → "auditoria-seguridad")
          let normalizedServiceSlug = service_slug;
          const svcRow = await this.env.DB.prepare("SELECT slug, name FROM services WHERE slug = ?").bind(service_slug).first();
          if (!svcRow) {
            // Try fuzzy match: replace common Spanish prepositions
            const altSlug = service_slug.replace(/-de-|-el-|-la-|-los-|-las-/g, '-').replace(/--+/g, '-').replace(/-+$/, '');
            const altRow = await this.env.DB.prepare("SELECT slug, name FROM services WHERE slug = ?").bind(altSlug).first();
            if (altRow) {
              normalizedServiceSlug = (altRow as any).slug;
            } else {
              return { error: `Servicio "${service_slug}" no encontrado. Usa list_services para ver los disponibles.`, entity: service_slug };
            }
          }

          // Validate location if provided
          if (location_slug) {
            const locRow = await this.env.DB.prepare("SELECT slug, name FROM locations WHERE slug = ?").bind(location_slug).first();
            if (!locRow) {
              return { error: `Comuna "${location_slug}" no encontrada. Usa list_locations para ver las disponibles.`, entity: location_slug };
            }
          }

          const entityType = location_slug ? "combo" : "service";
          const entitySlug = location_slug ? `${normalizedServiceSlug}-${location_slug}` : normalizedServiceSlug;
          const finalSvcRow = svcRow || await this.env.DB.prepare("SELECT slug, name FROM services WHERE slug = ?").bind(normalizedServiceSlug).first();
          const entityName = location_slug
            ? `${(finalSvcRow as any)?.name || normalizedServiceSlug} en ${location_slug}`
            : (finalSvcRow as any)?.name || normalizedServiceSlug;

          // Call the /api/ai/generate endpoint directly
          const workerUrl = this.env.WORKER_BASE_URL || 'https://guardman-admin-api.oficinadesarrollo33.workers.dev';
          const body = JSON.stringify({
            entity_type: entityType,
            entity_slug: entitySlug,
            entity_name: entityName,
            ...(location_slug ? { combo_service_slug: normalizedServiceSlug, combo_location_slug: location_slug } : {}),
          });

          try {
            const resp = await fetch(`${workerUrl}/api/ai/generate`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer admin@guardman.cl:${this.env.AUTH_TOKEN || ''}`,
              },
              body,
            });
            const data = await resp.json() as any;

            if (!data.ok) {
              return { error: data.error || 'Generation failed', entity: entitySlug };
            }

            // Build scoring summary
            const score = data.data?.newScore || data.data?.score || 0;
            const details = data.data?.newDetails || data.data?.details;
            const maxScore = 120;
            const pct = Math.round((score / maxScore) * 100);
            const seoPts = details?.seo || 0;
            const contentPts = details?.content || 0;
            const structPts = details?.structure || 0;
            const kwPts = details?.keywords || 0;
            const grade = pct >= 85 ? '🟢 EXCELENTE' : pct >= 70 ? '🟡 BUENO' : pct >= 50 ? '🟠 REGULAR' : '🔴 BAJO';
            const action = pct >= 85 ? 'Listo para publicar' : pct >= 70 ? 'Revisar antes de publicar' : 'Se recomienda regenerar';

            const scoreSummary = `${grade} Score: ${score}/${maxScore} (${pct}%)\n` +
              `  SEO: ${seoPts}/45 | Contenido: ${contentPts}/40 | Estructura: ${structPts}/20 | Keywords: ${kwPts}/15\n` +
              `  Acción: ${action}`;

            // Auto-publish: si score >= 85, encolar para publicación automática
            let autoPublished = false;
            let publishWorkflowId: string | null = null;
            if (pct >= 71 && this.env.PUBLISH_WORKFLOW) {  // 85/120 = 71%
              try {
                // Delete existing entry for this entity (no UNIQUE constraint)
                await this.env.DB.prepare(
                  'DELETE FROM publish_queue WHERE entity_type = ? AND entity_slug = ?'
                ).bind(location_slug ? 'combo' : 'service', entitySlug).run();

                // Insert into publish_queue as approved
                await this.env.DB.prepare(
                  `INSERT INTO publish_queue (entity_type, entity_slug, content_json, score, status, created_at)
                   VALUES (?, ?, ?, ?, 'approved', datetime('now'))`
                ).bind(
                  location_slug ? 'combo' : 'service',
                  entitySlug,
                  JSON.stringify(data.data?.content || {}),
                  score
                ).run();

                // Trigger publish workflow
                const instance = await this.env.PUBLISH_WORKFLOW.create({
                  id: `auto-publish-${entitySlug}-${Date.now()}`,
                  params: { mode: 'auto', maxItems: 1 },
                });
                autoPublished = true;
                publishWorkflowId = instance.id;
              } catch (pubErr: any) {
                // Don't fail generation if publish fails
                autoPublished = false;
              }
            }

            const autoPublishMsg = autoPublished
              ? ` | ✅ Auto-publicado (workflow: ${publishWorkflowId})`
              : pct >= 71 ? '' : ' | ⏳ Score insuficiente para auto-publicar (necesita ≥85/120)';

            // VERIFICACIÓN CRÍTICA: Confirmar que se guardó en la DB
            let dbVerified = false;
            let dbRecordId: number | null = null;
            let verificationHash = '';

            if (location_slug) {
              // Verificar combo_content
              const dbCheck = await this.env.DB.prepare(
                "SELECT id, h1, word_count FROM combo_content WHERE service_slug = ? AND location_slug = ?"
              ).bind(normalizedServiceSlug, location_slug).first();
              if (dbCheck) {
                dbVerified = true;
                dbRecordId = dbCheck.id as number;
                verificationHash = `cc_${dbRecordId}_${Date.now().toString(36)}`;
              }
            } else {
              // Verificar content_versions
              const dbCheck = await this.env.DB.prepare(
                "SELECT id, version, word_count FROM content_versions WHERE entity_type = 'service' AND entity_slug = ? ORDER BY version DESC LIMIT 1"
              ).bind(normalizedServiceSlug).first();
              if (dbCheck) {
                dbVerified = true;
                dbRecordId = dbCheck.id as number;
                verificationHash = `cv_${dbRecordId}_v${(dbCheck as any).version}_${Date.now().toString(36)}`;
              }
            }

            if (!dbVerified) {
              return {
                error: `⚠️ VERIFICACIÓN FALLIDA: El contenido NO se guardó en la base de datos. Entity: ${entitySlug}`,
                entity: entitySlug,
                score_obtained: score,
                note: "El tool intentó guardar pero la verificación de base de datos falló. Reporta este error."
              };
            }

            return {
              entity: entitySlug,
              score,
              max_score: maxScore,
              score_pct: pct,
              grade,
              score_breakdown: {
                seo: { points: seoPts, max: 45 },
                content: { points: contentPts, max: 40 },
                structure: { points: structPts, max: 20 },
                keywords: { points: kwPts, max: 15 },
              },
              score_summary: scoreSummary,
              recommended_action: action,
              auto_published: autoPublished,
              publish_workflow_id: publishWorkflowId,
              attempts: data.data?.attempts || 1,
              saved_to: data.data?.savedTo || 'unknown',
              word_count: data.data?.wordCount || 0,
              details: data.data?.newDetails || data.data?.details,
              review: data.data?.review,
              db_verified: dbVerified,
              verification_hash: verificationHash,
              db_record_id: dbRecordId,
              "⚠️ VERIFICATION_REQUIRED": `✅ DB verificada (hash: ${verificationHash}). Después de este tool, DEBES usar read_content para mostrar el contenido real. NUNCA muestres contenido inventado - usa solo lo que read_content devuelva.`,
            };
          } catch (err: any) {
            return { error: `Generation failed: ${err.message}`, entity: entitySlug };
          }
        },
      }),

      // ==========================================
      // TOOL: validate_entity — Verificar existencia de servicio/comuna
      // ==========================================
      validate_entity: tool({
        description: "Verificar si un servicio o comuna EXISTE en la base de datos. USA ESTO SIEMPRE antes de responder sobre una entidad específica. Si no existe, dile al usuario que esa entidad no está en el sistema.",
        parameters: z.object({
          slug: z.string().describe("Slug a verificar (ej: san-antonio, guardias-de-seguridad)"),
          type: z.enum(["service", "location", "auto"]).optional().describe("Tipo de entidad. 'auto' prueba ambos."),
        }),
        execute: async ({ slug, type }: { slug: string; type?: string }) => {
          const searchType = type || "auto";
          const results: { service?: any; location?: any } = {};

          if (searchType === "auto" || searchType === "service") {
            const svc = await this.env.DB.prepare(
              "SELECT slug, name, short_description FROM services WHERE slug = ?"
            ).bind(slug).first();
            if (svc) results.service = svc;
          }

          if (searchType === "auto" || searchType === "location") {
            const loc = await this.env.DB.prepare(
              "SELECT slug, name, zone, region FROM locations WHERE slug = ?"
            ).bind(slug).first();
            if (loc) results.location = loc;
          }

          const exists = !!(results.service || results.location);
          return {
            exists,
            slug,
            ...(results.service ? { matched_as: "service", name: results.service.name } : {}),
            ...(results.location ? { matched_as: "location", name: results.location.name, zone: results.location.zone } : {}),
            ...(!exists ? { suggestion: "Usa list_services o list_locations para ver las entidades disponibles." } : {}),
          };
        },
      }),

      // ==========================================
      // TOOL: read_content — Leer contenido generado
      // ==========================================
      read_content: tool({
        description: "Leer el contenido SEO generado para un servicio o combo servicio+comuna. USA ESTO después de generar contenido para mostrar el resultado al usuario, o cuando el usuario pida ver contenido existente.",
        parameters: z.object({
          service_slug: z.string().describe("Slug del servicio (ej: guardias-de-seguridad)"),
          location_slug: z.string().optional().describe("Slug de la comuna (ej: las-condes). Sin esto, lee contenido del servicio general."),
        }),
        execute: async ({ service_slug, location_slug }: { service_slug: string; location_slug?: string }) => {
          // FIX ERROR 24: Normalizar service_slug antes de buscar
          const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);

          if (location_slug) {
            // Leer contenido de combo (combo_content table)
            const combo = await this.env.DB.prepare(
              "SELECT seo_title, meta_description, h1, intro_paragraph, local_context, faqs_json, cta_text, cta_button, status, word_count FROM combo_content WHERE service_slug = ? AND location_slug = ?"
            ).bind(normalizedSlug, location_slug).first();

            if (!combo) {
              return {
                found: false,
                message: `No hay contenido generado para el combo ${service_slug} + ${location_slug}. Usa generate para crearlo.`,
              };
            }

            // Parse FAQs JSON if present
            let faqs: any[] = [];
            try {
              faqs = JSON.parse((combo as any).faqs_json || "[]");
            } catch {}

            return {
              found: true,
              type: "combo",
              service: normalizedSlug,
              location: location_slug,
              seo_title: (combo as any).seo_title,
              meta_description: (combo as any).meta_description,
              h1: (combo as any).h1,
              intro_paragraph: (combo as any).intro_paragraph,
              local_context: (combo as any).local_context,
              faqs,
              cta_text: (combo as any).cta_text,
              cta_button: (combo as any).cta_button,
              status: (combo as any).status,
              word_count: (combo as any).word_count,
            };
          } else {
            // FIX ERROR 24: usar normalizedSlug en vez de service_slug
            const cv = await this.env.DB.prepare(
              "SELECT entity_slug, version, content_json, confidence_score, word_count, generated_by, llm_model, created_at FROM content_versions WHERE entity_type = 'service' AND entity_slug = ? ORDER BY version DESC LIMIT 1"
            ).bind(normalizedSlug).first();

            if (!cv) {
              return {
                found: false,
                message: `No hay contenido generado para el servicio ${service_slug}. Usa generate para crearlo.`,
              };
            }

            // Parse content_json if present
            let parsed: any = null;
            try {
              parsed = JSON.parse((cv as any).content_json || "null");
            } catch {}

            return {
              found: true,
              type: "service",
              service: service_slug,
              version: (cv as any).version,
              confidence_score: (cv as any).confidence_score,
              word_count: (cv as any).word_count,
              generated_by: (cv as any).generated_by,
              llm_model: (cv as any).llm_model,
              created_at: (cv as any).created_at,
              content: parsed,
            };
          }
        },
      }),

      // ==========================================
      // TOOL: scan_serper — Escaneo de Google
      // ==========================================
      scan_serper: tool({
        description: "⚠️ ESCANEO COMPLETO (126 combos). Usa scan_competitors para escaneos individuales. Ejecuta Workflow durable para todos los combos. CONSUME ~126+ créditos Serper.",
        parameters: z.object({}),
        execute: async () => {
          if (!this.env.SERPER_SCAN_WORKFLOW) {
            return { error: "Serper scan workflow no configurado" };
          }
          const instance = await this.env.SERPER_SCAN_WORKFLOW.create({
            id: `scan-${Date.now()}`,
            params: { trigger: "manual" },
          });
          return { workflow_id: instance.id, message: "⚠️ Scan COMPLETO iniciado (126 combos). Consumirá ~126+ créditos. Usa workflow_status para ver progreso o abort para detener." };
        },
      }),

      // ==========================================
      // TOOL: scan_competitors — Escaneo granular (1 combo o 1 comuna)
      // ==========================================
      scan_competitors: tool({
        description: "Escanear competidores en Google para combos específicos. USA ESTO cuando el usuario pida buscar competencia para una comuna o servicio específico. Ejecuta directamente (sin workflow), guarda resultados en DB. Costo: ~1 crédito por query.",
        parameters: z.object({
          service_slug: z.string().optional().describe("Slug del servicio (ej: guardias-de-seguridad). Si no se especifica, escanea todos los servicios para la comuna dada."),
          location_slug: z.string().optional().describe("Slug de la comuna (ej: huechuraba). Si no se especifica, escanea todas las comunas para el servicio dado."),
          max_queries: z.number().optional().describe("Máximo de queries a ejecutar (default: 20, max: 50). Cada combo usa ~4-8 queries."),
        }),
        execute: async ({ service_slug, location_slug, max_queries }: {
          service_slug?: string;
          location_slug?: string;
          max_queries?: number;
        }) => {
          if (!this.env.SERPER_API_KEY) {
            return { error: "SERPER_API_KEY no configurado" };
          }
          if (!service_slug && !location_slug) {
            return { error: "Debes especificar al menos service_slug o location_slug. Para escanear todo, usa scan_serper (workflow completo)." };
          }

          // Import serper pipeline functions
          const { generateQueryPlan } = await import('../serper/layer1-queries');
          const { executeQueryPlan } = await import('../serper/layer2-executor');
          const { classifyAllResults } = await import('../serper/layer3-classifier');

          // Build list of combos to scan
          const combos: { svc: string; loc: string }[] = [];

          if (service_slug && location_slug) {
            // Single combo
            combos.push({ svc: service_slug, loc: location_slug });
          } else if (location_slug) {
            // All services for one location
            const svcResult = await this.env.DB.prepare('SELECT slug FROM services ORDER BY name').all();
            for (const s of svcResult.results as any[]) {
              combos.push({ svc: s.slug, loc: location_slug });
            }
          } else if (service_slug) {
            // All locations for one service
            const locResult = await this.env.DB.prepare('SELECT slug FROM locations ORDER BY name').all();
            for (const l of locResult.results as any[]) {
              combos.push({ svc: service_slug, loc: l.slug });
            }
          }

          const limit = Math.min(max_queries || 20, 50);
          let queriesUsed = 0;
          const results: any[] = [];

          for (const combo of combos) {
            if (queriesUsed >= limit) break;
            try {
              const plan = generateQueryPlan(combo.svc, combo.loc);
              const queriesToRun = plan.queries.slice(0, Math.max(1, limit - queriesUsed));
              const execResults = await executeQueryPlan(
                { DB: this.env.DB, SERPER_API_KEY: this.env.SERPER_API_KEY },
                queriesToRun,
                (step: string, idx: number, total: number) => {}
              );
              queriesUsed += queriesToRun.length;
              results.push({
                combo: `${combo.svc}+${combo.loc}`,
                queries: queriesToRun.length,
                results: execResults.length,
                status: 'ok',
              });
            } catch (e: any) {
              results.push({
                combo: `${combo.svc}+${combo.loc}`,
                error: e.message,
                status: 'error',
              });
            }
          }

          // Re-classify with new data
          try { await classifyAllResults({ DB: this.env.DB }); } catch {}

          // Get credits remaining
          const credits = await this.env.DB.prepare(
            'SELECT COUNT(*) as queries, COALESCE(SUM(credits_used),0) as credits FROM serper_queries'
          ).first().catch(() => ({ queries: 0, credits: 0 }));

          // Get competitors found for the target location
          const competitors: any[] = [];
          const targetLoc = location_slug;
          if (targetLoc) {
            const compResult = await this.env.DB.prepare(
              `SELECT DISTINCT sr.domain, sr.title, sr.site_type, sq.service_slug
               FROM serper_results sr
               JOIN serper_queries sq ON sr.query_id = sq.id
               WHERE sq.location_slug = ? AND sr.site_type IN ('direct_competitor', 'indirect_competitor', 'directory')
               ORDER BY sr.position
               LIMIT 20`
            ).bind(targetLoc).all().catch(() => ({ results: [] }));
            for (const r of compResult.results as any[]) {
              competitors.push({ domain: r.domain, title: r.title, type: r.site_type, service: r.service_slug });
            }
          }

          return {
            combos_scanned: results.length,
            queries_used: queriesUsed,
            results,
            competitors_found: competitors,
            total_serper_queries: (credits as any)?.queries || 0,
            credits_remaining: 10000 - ((credits as any)?.credits || 0),
            message: `✅ Scan completado: ${results.length} combos escaneados con ${queriesUsed} queries. ${competitors.length} competidores encontrados.`,
          };
        },
      }),

      // ==========================================
      // TOOL: workflow_status — Estado y control de workflows
      // ==========================================
      workflow_status: tool({
        description: "Consultar estado de un workflow en ejecución, listar workflows activos, o abortar un workflow. USA ESTO cuando el usuario pregunte por el progreso de un escaneo o quiera detenerlo.",
        parameters: z.object({
          action: z.enum(["status", "list", "abort"]).describe("Acción: 'status' para ver estado de un workflow, 'list' para listar activos, 'abort' para detener uno."),
          workflow_id: z.string().optional().describe("ID del workflow (requerido para status y abort)."),
        }),
        execute: async ({ action, workflow_id }: {
          action: string;
          workflow_id?: string;
        }) => {
          if (action === 'list') {
            // List recent workflow instances by checking DB stats
            const stats = await this.env.DB.prepare(
              'SELECT COUNT(*) as queries, COALESCE(SUM(credits_used),0) as credits FROM serper_queries'
            ).first().catch(() => ({ queries: 0, credits: 0 }));
            return {
              active_workflows: 'Cloudflare Workflows no expone API de listado directo.',
              serper_stats: {
                total_queries: (stats as any)?.queries || 0,
                total_credits: (stats as any)?.credits || 0,
                estimated_remaining: 10000 - ((stats as any)?.credits || 0),
              },
              tip: 'Usa action="abort" con workflow_id para detener un workflow específico.',
            };
          }

          if (action === 'abort') {
            if (!workflow_id) return { error: 'workflow_id es requerido para abortar.' };

            // FIX ERROR 22: Buscar en TODOS los bindings de workflow
            const wfBindings: Array<{ name: string; binding: any }> = [
              { name: 'SERPER_SCAN_WORKFLOW', binding: this.env.SERPER_SCAN_WORKFLOW },
              { name: 'PUBLISH_WORKFLOW', binding: this.env.PUBLISH_WORKFLOW },
              { name: 'BULK_GENERATE_WORKFLOW', binding: this.env.BULK_GENERATE_WORKFLOW },
              { name: 'REPORTS_WORKFLOW', binding: this.env.REPORTS_WORKFLOW },
            ];

            for (const { name, binding } of wfBindings) {
              if (!binding) continue;
              try {
                const instance = await binding.get(workflow_id);
                const statusInfo = await instance.status();
                await instance.terminate();
                return {
                  terminated: true,
                  workflow_id,
                  workflow_type: name,
                  previous_status: statusInfo?.status || 'unknown',
                  message: `✅ Workflow ${workflow_id} (${name}) detenido exitosamente.`,
                };
              } catch { continue; }
            }
            return {
              terminated: false,
              workflow_id,
              error: `Workflow ${workflow_id} no encontrado en ningún binding.`,
              tip: 'El workflow puede que ya haya terminado. Los datos ya procesados quedan guardados en DB.',
            };
          }

          // action === 'status'
          if (!workflow_id) {
            // Return general serper status as proxy
            const [queries, latestQ] = await Promise.all([
              this.env.DB.prepare(
                'SELECT COUNT(*) as total, COALESCE(SUM(credits_used),0) as credits FROM serper_queries'
              ).first().catch(() => ({ total: 0, credits: 0 })),
              this.env.DB.prepare(
                'SELECT created_at FROM serper_queries ORDER BY created_at DESC LIMIT 1'
              ).first().catch(() => null),
            ]);
            return {
              workflow_id: 'not_provided',
              serper_queries_total: (queries as any)?.total || 0,
              credits_used: (queries as any)?.credits || 0,
              credits_remaining: 10000 - ((queries as any)?.credits || 0),
              last_query_at: (latestQ as any)?.created_at || 'never',
              tip: 'Proporciona un workflow_id específico para ver su estado.',
            };
          }

          // FIX ERROR 22: Buscar en TODOS los bindings de workflow
          try {
            const wfBindings: Array<{ name: string; binding: any }> = [
              { name: 'SERPER_SCAN_WORKFLOW', binding: this.env.SERPER_SCAN_WORKFLOW },
              { name: 'PUBLISH_WORKFLOW', binding: this.env.PUBLISH_WORKFLOW },
              { name: 'BULK_GENERATE_WORKFLOW', binding: this.env.BULK_GENERATE_WORKFLOW },
              { name: 'REPORTS_WORKFLOW', binding: this.env.REPORTS_WORKFLOW },
            ];

            for (const { name, binding } of wfBindings) {
              if (!binding) continue;
              try {
                const instance = await binding.get(workflow_id);
                const wfStatus = await instance.status();
                return {
                  workflow_id,
                  workflow_type: name,
                  workflow_status: wfStatus?.status || 'unknown',
                  workflow_output: wfStatus?.output || null,
                  tip: wfStatus?.status === 'complete'
                    ? 'El workflow ya terminó.'
                    : wfStatus?.status === 'running'
                      ? 'El workflow sigue corriendo. Puedes detenerlo con action="abort".'
                      : `Estado: ${wfStatus?.status || 'desconocido'}`,
                };
              } catch { continue; }
            }
            return { workflow_id, status: 'not_found', error: `Workflow ${workflow_id} no encontrado en ningún binding.` };
          } catch (e: any) {
            return { workflow_id, status: 'error', error: e.message };
          }
        },
      }),

      // ==========================================
      // TOOL: publish — Publicar contenido
      // ==========================================
      publish: tool({
        description: "Publicar contenido aprobado a R2 y disparar deploy. Si se especifica entity_slug, encola ese combo para publicación. Sin parámetros, publica toda la cola aprobada.",
        parameters: z.object({
          entity_slug: z.string().optional().describe("Slug del combo a publicar (ej: guardias-de-seguridad-las-condes). Sin esto, publica toda la cola aprobada."),
        }),
        execute: async ({ entity_slug }: { entity_slug?: string }) => {
          if (!this.env.PUBLISH_WORKFLOW) {
            return { error: "Publish workflow no configurado" };
          }

          // FIX ERROR 23: Si se especifica entity_slug, encolar en publish_queue ANTES de crear workflow
          if (entity_slug) {
            // Parse combo slug: service-location using dynamic slugs from DB
            const locationSlugs = await getLocationSlugs(this.env.DB);
            let serviceSlug = entity_slug;
            let locationSlug = '';
            for (const loc of locationSlugs) {
              if (entity_slug.endsWith('-' + loc)) {
                serviceSlug = entity_slug.substring(0, entity_slug.length - loc.length - 1);
                locationSlug = loc;
                break;
              }
            }

            if (!locationSlug) {
              return { error: `No se pudo parsear el slug "${entity_slug}" como combo service-location.` };
            }

            // Buscar contenido en combo_content
            const content = await this.env.DB.prepare(
              'SELECT seo_title, meta_description, h1, intro_paragraph, faqs_json, cta_text, cta_button, content_json, status, word_count FROM combo_content WHERE service_slug = ? AND location_slug = ?'
            ).bind(serviceSlug, locationSlug).first();

            if (!content) {
              return { error: `No existe contenido para ${serviceSlug} + ${locationSlug}. Usa generate primero.` };
            }

            // Calcular score
            let score = 0;
            let contentForQueue: any = content;
            if (content.content_json) {
              try {
                const parsed = JSON.parse(content.content_json as string);
                const { calculateContentScore } = await import('../services/scoring');
                const scored = calculateContentScore(parsed);
                score = scored.score;
                contentForQueue = parsed;
              } catch {}
            }

            // DELETE previo + INSERT en publish_queue con status 'approved'
            await this.env.DB.prepare(
              'DELETE FROM publish_queue WHERE entity_type = ? AND entity_slug = ?'
            ).bind('combo', entity_slug).run();

            await this.env.DB.prepare(
              `INSERT INTO publish_queue (entity_type, entity_slug, content_json, score, status, created_at)
               VALUES (?, ?, ?, ?, 'approved', datetime('now'))`
            ).bind('combo', entity_slug, JSON.stringify(contentForQueue), score).run();
          }

          const instance = await this.env.PUBLISH_WORKFLOW.create({
            id: `publish-${Date.now()}`,
            params: { mode: "manual" },
          });
          return {
            workflow_id: instance.id,
            entity_published: entity_slug || 'all_approved',
            message: entity_slug
              ? `✅ ${entity_slug} encolado para publicación. Workflow: ${instance.id}`
              : `Publish pipeline iniciado para toda la cola aprobada. Workflow: ${instance.id}`,
          };
        },
      }),

      // ==========================================
      // TOOL: bulk_generate — Generación masiva de contenido
      // ==========================================
      bulk_generate: tool({
        description: "Generar contenido SEO para MÚLTIPLES combos servicio+comuna en paralelo. Usa ESTO cuando el usuario quiera generar contenido para varias comunas o todos los combos faltantes de un servicio. Ejecuta como Workflow durable para no bloquear.",
        parameters: z.object({
          service_slug: z.string().optional().describe("Slug del servicio (ej: guardias-de-seguridad). Si no se provee, genera para todos los servicios con combos faltantes."),
          location_slugs: z.array(z.string()).optional().describe("Array de slugs de comunas. Si no se provee, genera para todas las comunas sin contenido del servicio."),
          max_items: z.number().optional().describe("Máximo de items a generar (default: 10, max: 50)."),
          min_score_threshold: z.number().optional().describe("Score mínimo para auto-publicar (default: 85)."),
        }),
        execute: async ({ service_slug, location_slugs, max_items, min_score_threshold }: {
          service_slug?: string;
          location_slugs?: string[];
          max_items?: number;
          min_score_threshold?: number;
        }) => {
          if (!this.env.BULK_GENERATE_WORKFLOW) {
            return { error: "Bulk generate workflow no configurado" };
          }

          // Resolve target combos
          let targetCombos: { service_slug: string; location_slug: string }[] = [];

          if (service_slug && location_slugs && location_slugs.length > 0) {
            // Specific service + locations
            targetCombos = location_slugs.map(loc => ({ service_slug, location_slug: loc }));
          } else if (service_slug) {
            // All missing locations for this service
            const existing = await this.env.DB.prepare(
              "SELECT location_slug FROM combo_content WHERE service_slug = ?"
            ).bind(service_slug).all().catch(() => ({ results: [] }));
            const existingLocs = new Set((existing.results as any[]).map((r: any) => r.location_slug));
            const allLocs = await this.env.DB.prepare(
              "SELECT slug FROM locations ORDER BY name"
            ).all().catch(() => ({ results: [] }));
            targetCombos = (allLocs.results as any[])
              .filter((l: any) => !existingLocs.has(l.slug))
              .map((l: any) => ({ service_slug, location_slug: l.slug }));
          } else {
            // All missing combos
            const existing = await this.env.DB.prepare(
              "SELECT service_slug, location_slug FROM combo_content"
            ).all().catch(() => ({ results: [] }));
            const existingSet = new Set((existing.results as any[]).map((r: any) => `${r.service_slug}:${r.location_slug}`));
            const services = await this.env.DB.prepare("SELECT slug FROM services").all().catch(() => ({ results: [] }));
            const locations = await this.env.DB.prepare("SELECT slug FROM locations").all().catch(() => ({ results: [] }));
            for (const svc of services.results as any[]) {
              for (const loc of locations.results as any[]) {
                const key = `${svc.slug}:${loc.slug}`;
                if (!existingSet.has(key)) {
                  targetCombos.push({ service_slug: svc.slug, location_slug: loc.slug });
                }
              }
            }
          }

          // Limit items
          const limit = Math.min(max_items || 10, 50);
          const combosToProcess = targetCombos.slice(0, limit);

          if (combosToProcess.length === 0) {
            return { message: "No hay combos faltantes para generar", total: 0 };
          }

          // Start workflow
          const instance = await this.env.BULK_GENERATE_WORKFLOW.create({
            id: `bulk-${Date.now()}`,
            params: {
              combos: combosToProcess,
              mode: "bulk",
              min_score_threshold: min_score_threshold || 85,
              trigger: "orchestrator-tool",
            },
          });

          return {
            workflow_id: instance.id,
            message: `Bulk generate iniciado para ${combosToProcess.length} combos`,
            combos: combosToProcess.map(c => `${c.service_slug}+${c.location_slug}`),
            total: combosToProcess.length,
          };
        },
      }),

      // ==========================================
      // TOOL: update_content — Editar contenido generado
      // ==========================================
      update_content: tool({
        description: "Actualizar un campo específico del contenido SEO generado para un combo. USA ESTO cuando el usuario quiera corregir o editar contenido. Requiere el slug del servicio, comuna, campo a editar y el nuevo valor.",
        parameters: z.object({
          service_slug: z.string().describe("Slug del servicio (ej: guardias-de-seguridad)"),
          location_slug: z.string().describe("Slug de la comuna (ej: las-condes)"),
          field: z.enum(["seo_title", "meta_description", "h1", "intro_paragraph", "local_context", "cta_text", "cta_button"]).describe("Campo a actualizar"),
          value: z.string().describe("Nuevo valor para el campo"),
        }),
        execute: async ({ service_slug, location_slug, field, value }: {
          service_slug: string;
          location_slug: string;
          field: string;
          value: string;
        }) => {
          // Validate field is allowed
          const allowedFields = ["seo_title", "meta_description", "h1", "intro_paragraph", "local_context", "cta_text", "cta_button"];
          if (!allowedFields.includes(field)) {
            return { error: `Campo no válido. Campos permitidos: ${allowedFields.join(", ")}` };
          }

          // FIX ERROR 24: Normalizar service_slug
          const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);

          // Check if combo exists
          const existing = await this.env.DB.prepare(
            "SELECT id, status FROM combo_content WHERE service_slug = ? AND location_slug = ?"
          ).bind(normalizedSlug, location_slug).first();

          if (!existing) {
            return { error: `No existe contenido para el combo ${normalizedSlug} + ${location_slug}. Usa generate primero.` };
          }

          // Update the field
          const updateResult = await this.env.DB.prepare(
            `UPDATE combo_content SET ${field} = ?, updated_at = CURRENT_TIMESTAMP WHERE service_slug = ? AND location_slug = ?`
          ).bind(value, normalizedSlug, location_slug).run();

          if (!updateResult.success) {
            return { error: "Error al actualizar el contenido" };
          }

          // Read back the updated content to confirm
          const updated = await this.env.DB.prepare(
            "SELECT * FROM combo_content WHERE service_slug = ? AND location_slug = ?"
          ).bind(normalizedSlug, location_slug).first();

          return {
            success: true,
            message: `Campo '${field}' actualizado correctamente`,
            combo: `${normalizedSlug}+${location_slug}`,
            updated_field: field,
            new_value: value,
            status: (updated as any)?.status,
            word_count: (updated as any)?.word_count,
          };
        },
      }),

      // ==========================================
      // TOOL: publish_preview — Ver cola de publicación pendiente
      // ==========================================
      publish_preview: tool({
        description: "Ver la cola de publicación pendiente: qué contenido está listo para publicar, con scores y acciones disponibles. USA ESTO antes de pedir confirmación para publicar.",
        parameters: z.object({
          min_score: z.number().optional().describe("Score mínimo a mostrar (default: 0)"),
          limit: z.number().optional().describe("Máximo de items a devolver (default: 20)"),
        }),
        execute: async ({ min_score, limit }: { min_score?: number; limit?: number }) => {
          const threshold = min_score || 0;
          const maxItems = limit || 20;

          const queue = await this.env.DB.prepare(
            "SELECT id, entity_type, entity_slug, content_json, score, status, created_at FROM publish_queue WHERE score >= ? ORDER BY score DESC LIMIT ?"
          ).bind(threshold, maxItems).all().catch(() => ({ results: [] }));

          const items = (queue.results as any[]).map((item: any) => {
            let title = item.entity_slug;
            let meta = "";
            try {
              const parsed = JSON.parse(item.content_json || "{}");
              title = parsed.seo_title || title;
              meta = parsed.meta_description || "";
            } catch {}
            return {
              id: item.id,
              entity_type: item.entity_type,
              entity_slug: item.entity_slug,
              title,
              meta_description: meta.substring(0, 120) + (meta.length > 120 ? "..." : ""),
              score: item.score,
              status: item.status,
              created_at: item.created_at,
            };
          });

          const needs_approval = items.filter(i => i.score < 85);
          const auto_approve = items.filter(i => i.score >= 85);

          return {
            total: items.length,
            needs_approval: needs_approval.length,
            auto_approve: auto_approve.length,
            items,
            message: needs_approval.length > 0
              ? `${needs_approval.length} items requieren aprobación manual (score < 85). ${auto_approve.length} pueden auto-publicarse.`
              : `${items.length} items listos para publicar.`,
          };
        },
      }),

      // ==========================================
      // TOOL: open_panel — Abrir/cerrar panels de la UI
      // ==========================================
      open_panel: tool({
        description: "Abrir, cerrar o actualizar un panel de la UI. USA ESTO cuando quieras mostrar información visual al usuario (previews, gráficos, editores). El cliente interpretará la acción y renderizará el panel correspondiente.",
        parameters: z.object({
          panel_type: z.enum(["preview", "editor", "approval", "chart", "coverage", "status"]).describe("Tipo de panel a abrir"),
          action: z.enum(["open", "close", "toggle", "update"]).optional().describe("Acción a realizar (default: 'open')"),
          params: z.object({
            // Para preview y editor
            service_slug: z.string().optional().describe("Slug del servicio (ej: guardias-de-seguridad)"),
            location_slug: z.string().optional().describe("Slug de la comuna (ej: las-condes)"),
            // Para editor: campo específico a editar
            field: z.string().optional().describe("Campo a editar: seo_title, meta_description, h1, intro_paragraph, etc."),
            // Para chart
            chart_type: z.enum(["coverage", "scores", "gaps"]).optional().describe("Tipo de gráfico"),
            service: z.string().optional().describe("Servicio para el gráfico"),
            // Para approval
            item_id: z.number().optional().describe("ID del item en cola de publicación"),
            // Contenido para mostrar en el panel
            content: z.string().optional().describe("Contenido HTML o texto a mostrar"),
          }).optional().describe("Parámetros específicos del panel"),
          message: z.string().optional().describe("Mensaje opcional para mostrar junto con el panel"),
        }),
        execute: async ({ panel_type, action, params, message }: {
          panel_type: string;
          action?: string;
          params?: {
            service_slug?: string;
            location_slug?: string;
            field?: string;
            chart_type?: string;
            service?: string;
            item_id?: number;
            content?: string;
          };
          message?: string;
        }) => {
          // El cliente interpreta este output y abre/cierra/actualiza el panel correspondiente
          // La UI sabe cómo renderizar cada tipo de panel según panel_type y params
          const resolvedAction = action || "open";
          
          // Validar parámetros según el tipo de panel
          if (panel_type === "preview" || panel_type === "editor") {
            if (!params?.service_slug) {
              return { 
                error: "service_slug es requerido para panels preview/editor",
                panel_action: resolvedAction,
                panel_type 
              };
            }
          }

          // Retornar estructura que el cliente puede interpretar
          return {
            panel_action: resolvedAction,
            panel_type,
            params: params || {},
            message: message || getPanelDefaultMessage(panel_type, params),
          };
        },
      }),

      // ==========================================
      // TOOL: generate_chart — Generar datos para gráficos
      // ==========================================
      generate_chart: tool({
        description: "Generar datos para visualizar gráficos de coverage, scores o gaps. USA ESTO cuando el usuario pida ver los datos de forma visual (ej: 'muéstrame un gráfico', 'ver coverage como chart'). El cliente renderizará el ChartPanel con Chart.js.",
        parameters: z.object({
          chart_type: z.enum(["coverage", "scores", "gaps"]).describe("Tipo de gráfico: coverage (barras), scores (barras horizontales), gaps (dona)"),
          service_slug: z.string().optional().describe("Filtrar por servicio específico (opcional)"),
          location_slug: z.string().optional().describe("Filtrar por comuna específica (opcional)"),
        }),
        execute: async ({ chart_type, service_slug, location_slug }: { chart_type: string; service_slug?: string; location_slug?: string }) => {
          try {
            // Validate chart_type
            if (!["coverage", "scores", "gaps"].includes(chart_type)) {
              return { error: `Tipo de gráfico inválido: ${chart_type}. Usa: coverage, scores, o gaps` };
            }

            let servicesResult: any = { results: [] };
            let combosResult: any = { total: 126, with_content: 0 };
            let scoresResult: any = { results: [] };

            if (chart_type === "coverage") {
              // Query for coverage chart - can filter by location
              if (location_slug) {
                // Get services with content for specific location
                servicesResult = await this.env.DB.prepare(`
                  SELECT s.slug, s.name,
                    (SELECT COUNT(*) FROM combo_content cc WHERE cc.service_slug = s.slug AND cc.location_slug = ?) as combos_with_content
                  FROM services s
                  ORDER BY s.name
                `).bind(location_slug).all().catch(() => ({ results: [] }));

                const contentCount = (servicesResult.results as any[]).filter((s: any) => (s.combos_with_content || 0) > 0).length;
                combosResult = { total: 9, with_content: contentCount };
              } else if (service_slug) {
                // Get locations with content for specific service
                servicesResult = await this.env.DB.prepare(`
                  SELECT l.slug, l.name,
                    (SELECT COUNT(*) FROM combo_content cc WHERE cc.location_slug = l.slug AND cc.service_slug = ?) as combos_with_content
                  FROM locations l
                  ORDER BY l.name
                `).bind(service_slug).all().catch(() => ({ results: [] }));

                const contentCount = (servicesResult.results as any[]).filter((s: any) => (s.combos_with_content || 0) > 0).length;
                combosResult = { total: 14, with_content: contentCount };
              } else {
                // Get all services with overall coverage
                servicesResult = await this.env.DB.prepare(`
                  SELECT s.slug, s.name,
                    (SELECT COUNT(*) FROM combo_content cc WHERE cc.service_slug = s.slug) as combos_with_content
                  FROM services s
                  ORDER BY s.name
                `).all().catch(() => ({ results: [] }));

                combosResult = await this.env.DB.prepare(
                  "SELECT COUNT(*) as total, (SELECT COUNT(*) FROM combo_content) as with_content FROM combos"
                ).first().catch(() => ({ total: 126, with_content: 0 }));
              }
            } else if (chart_type === "scores") {
              // Query for scores chart
              if (location_slug) {
                scoresResult = await this.env.DB.prepare(`
                  SELECT cc.service_slug || '-' || cc.location_slug as entity_slug,
                         COALESCE(qs.overall_score, 0) as overall_score,
                         COALESCE(qs.seo_score, 0) as seo_score,
                         COALESCE(qs.content_score, 0) as content_score
                  FROM combo_content cc
                  LEFT JOIN quality_scores qs ON qs.entity_slug = cc.service_slug || '-' || cc.location_slug
                  WHERE cc.location_slug = ?
                  ORDER BY overall_score DESC
                  LIMIT 20
                `).bind(location_slug).all().catch(() => ({ results: [] }));
              } else if (service_slug) {
                scoresResult = await this.env.DB.prepare(`
                  SELECT cc.service_slug || '-' || cc.location_slug as entity_slug,
                         COALESCE(qs.overall_score, 0) as overall_score,
                         COALESCE(qs.seo_score, 0) as seo_score,
                         COALESCE(qs.content_score, 0) as content_score
                  FROM combo_content cc
                  LEFT JOIN quality_scores qs ON qs.entity_slug = cc.service_slug || '-' || cc.location_slug
                  WHERE cc.service_slug = ?
                  ORDER BY overall_score DESC
                  LIMIT 20
                `).bind(service_slug).all().catch(() => ({ results: [] }));
              } else {
                scoresResult = await this.env.DB.prepare(
                  "SELECT entity_slug, overall_score, seo_score, content_score FROM quality_scores ORDER BY overall_score DESC LIMIT 20"
                ).all().catch(() => ({ results: [] }));
              }
            } else if (chart_type === "gaps") {
              // Query for gaps (doughnut) chart
              combosResult = await this.env.DB.prepare(
                "SELECT COUNT(*) as total, (SELECT COUNT(*) FROM combo_content) as with_content FROM combos"
              ).first().catch(() => ({ total: 126, with_content: 0 }));
            }

            // Build services array
            const services = (servicesResult.results as any[]).map((s: any) => ({
              name: s.name,
              slug: s.slug,
              has_content: (s.combos_with_content || 0) > 0,
              combos_with_content: s.combos_with_content || 0,
            }));

            // Build chart data
            const chartData = getChartData(
              chart_type,
              services,
              { with_content: (combosResult as any)?.with_content || 0, total_possible: (combosResult as any)?.total || 126 },
              scoresResult.results as any[]
            );

            return {
              panel_action: "open",
              panel_type: "chart",
              chart_data: chartData,
              params: { chart_type, service: service_slug, location: location_slug },
              message: `Gráfico de ${chart_type}${location_slug ? ` para ${location_slug}` : ''}${service_slug ? ` para ${service_slug}` : ''}`,
            };
          } catch (err: any) {
            return { error: `Error generando gráfico: ${err.message}` };
          }
        },
      }),

      // ==========================================
      // TOOL: request_approval — Solicitar aprobación para acciones sensibles
      // ==========================================
      request_approval: tool({
        description: "Solicitar confirmación del usuario antes de ejecutar acciones sensibles (bulk_generate, publish, etc). El cliente mostrará un panel de aprobación donde el usuario puede confirmar o rechazar.",
        parameters: z.object({
          action_type: z.enum(["bulk_generate", "publish", "delete", "regenerate", "bulk_publish"]).describe("Tipo de acción a aprobar"),
          description: z.string().describe("Descripción legible de la acción"),
          item_count: z.number().optional().describe("Cantidad de items afectados"),
          params: z.object({
            service_slug: z.string().optional().describe("Servicio específico si aplica"),
            location_slugs: z.array(z.string()).optional().describe("Comunas específicas si aplica"),
            min_score: z.number().optional().describe("Score mínimo si aplica"),
          }).optional().describe("Parámetros de la acción"),
        }),
        execute: async ({ action_type, description, item_count, params }: {
          action_type: string;
          description: string;
          item_count?: number;
          params?: {
            service_slug?: string;
            location_slugs?: string[];
            min_score?: number;
          };
        }) => {
          // Esta tool retorna un "pending approval" que el cliente debe procesar
          // El cliente (ApprovalPanel) mostrará una UI para que el usuario apruebe o rechace
          return {
            pending_approval: true,
            action_type,
            description,
            item_count: item_count || 1,
            params: params || {},
            // Mensaje que el agente mostrará al usuario
            message: `¿Confirmas ${description}? (${item_count || 1} items)`,
            // Opciones de aprobación que el cliente puede ejecutar
            approval_options: [
              { 
                id: `approve_${action_type}_${Date.now()}`,
                label: `Aprobar ${action_type}`,
                action: action_type,
                params,
              },
              {
                id: `reject_${Date.now()}`,
                label: 'Rechazar',
                action: 'cancel',
                params: {},
              },
            ],
          };
        },
      }),

      // ==========================================
      // TOOL: schedule_report — Programar reporte SEO automático
      // ==========================================
      schedule_report: tool({
        description: "Programar o generar un reporte SEO automático. Los reportes incluyen: coverage stats, top performers, gaps, y recomendaciones. Los reportes se guardan en la DB y se generan diariamente a las 9 AM.",
        parameters: z.object({
          type: z.enum(["daily", "weekly", "on_demand"]).optional().describe("Tipo de reporte: daily (diario a las 9AM), weekly (lunes), on_demand (inmediato)"),
          force: z.boolean().optional().describe("Forzar generación aunque ya exista reporte del día"),
        }),
        execute: async ({ type = "on_demand", force = false }: { type?: string; force?: boolean }) => {
          if (!this.env.REPORTS_WORKFLOW) {
            return { error: "Reports workflow no configurado. El workflow de reportes debe estar habilitado." };
          }

          // Check if today's report already exists (unless forced)
          if (!force && type === "daily") {
            const today = new Date().toISOString().split('T')[0];
            const existing = await this.env.DB.prepare(
              "SELECT id FROM scheduled_reports WHERE type = ? AND report_date = ?"
            ).bind("daily", today).first().catch(() => null);
            
            if (existing) {
              return {
                message: `Ya existe un reporte diario para hoy (${today}). Usa force=true para regenerar.`,
                existing_report: (existing as any).id,
                report_date: today,
              };
            }
          }

          // Start the workflow
          const instance = await this.env.REPORTS_WORKFLOW.create({
            id: `report-${type}-${Date.now()}`,
            params: {
              type: type as 'daily' | 'weekly' | 'on_demand',
              force_regenerate: force,
            },
          });

          return {
            workflow_id: instance.id,
            type,
            message: type === "on_demand" 
              ? "Reporte generado bajo demanda. El workflow está procesando..."
              : `Reporte ${type} programado. Se ejecutará según el schedule configurado.`,
            next_run: type === "daily" ? "Hoy a las 9:00 AM" : "Lunes a las 9:00 AM",
          };
        },
      }),

      // ==========================================
      // TOOL: get_reports — Ver reportes guardados
      // ==========================================
      get_reports: tool({
        description: "Ver los reportes SEO programados guardados. Retorna la lista de reportes con sus fechas y un resumen de métricas.",
        parameters: z.object({
          type: z.enum(["daily", "weekly", "all"]).optional().describe("Filtrar por tipo de reporte"),
          limit: z.number().optional().describe("Máximo de reportes a devolver (default: 10)"),
        }),
        execute: async ({ type = "all", limit = 10 }: { type?: string; limit?: number }) => {
          // Ensure table exists
          await this.env.DB.prepare(`
            CREATE TABLE IF NOT EXISTS scheduled_reports (
              id TEXT PRIMARY KEY,
              type TEXT NOT NULL,
              report_date TEXT NOT NULL,
              coverage_stats TEXT,
              top_performers TEXT,
              coverage_gaps TEXT,
              low_scores TEXT,
              markdown TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
          `).run().catch(() => ({ success: true }));

          const whereClause = type !== "all" ? `WHERE type = '${type}'` : '';
          const results = await this.env.DB.prepare(`
            SELECT id, type, report_date, coverage_stats, created_at
            FROM scheduled_reports
            ${whereClause}
            ORDER BY created_at DESC
            LIMIT ?
          `).bind(limit).all().catch(() => ({ results: [] }));

          const reports = (results.results as any[]).map(r => {
            let stats = null;
            try {
              stats = JSON.parse(r.coverage_stats || '{}');
            } catch {}
            return {
              id: r.id,
              type: r.type,
              date: r.report_date,
              coverage: stats ? `${stats.combos_total || 0}/${stats.combos_possible || 0}` : 'N/A',
              avg_score: stats?.avg_score || 'N/A',
              created_at: r.created_at,
            };
          });

          return {
            count: reports.length,
            reports,
            message: `Encontrados ${reports.length} reporte(s)`,
          };
        },
      }),

      // ── Sub-agent Tools (Item 15) — subAgent() RPC with direct fallback ──
      // Cloudflare ctx.facets/ctx.exports still requires "experimental" flag (blocked by error 10021).
      // Try subAgent() first; fall back to direct functions if unavailable.
      // When Cloudflare enables facets in production, the fallback will never trigger.

      audit_seo: tool({
        description: "Realiza una auditoría SEO profunda del contenido de un combo. Retorna score detallado con desglose (SEO/45, Content/40, Structure/20, Keywords/15) + recomendaciones. Usa 'all' para auditar todo el sistema.",
        parameters: z.object({
          service_slug: z.string().optional().describe("Slug del servicio. Si se omite con all=true, audita todo."),
          location_slug: z.string().optional().describe("Slug de la comuna. Requerido si no es all=true."),
          all: z.boolean().optional().describe("Si true, audita TODOS los combos del sistema."),
        }),
        execute: async ({ service_slug, location_slug, all }: { service_slug?: string; location_slug?: string; all?: boolean }) => {
          try {
            // Try sub-agent RPC first
            const auditor = await this.subAgent(SEOAuditorAgent, "seo-auditor");

            if (all) {
              const result = await auditor.auditAll();
              return {
                type: 'full_audit',
                total_combos: result.total_combos,
                global_avg: result.global_avg,
                services: result.services,
                message: `Auditoría completa: ${result.total_combos} combos, promedio global ${result.global_avg}/120`,
              };
            }
            if (!service_slug) {
              return { error: "Especifica service_slug + location_slug, o all=true" };
            }
            const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);

            if (location_slug) {
              const result = await auditor.analyzeContent(normalizedSlug, location_slug);
              return {
                type: 'combo_audit',
                service_slug: result.service_slug,
                location_slug: result.location_slug,
                score: result.score.total,
                max_score: result.score.max,
                grade: result.score.grade,
                breakdown: result.score,
                recommendations: result.recommendations,
                analyzed_at: result.analyzed_at,
              };
            }

            // Service-level audit
            const result = await auditor.auditService(normalizedSlug);
            const combos = result.combos.map(c => ({
              location: c.location_slug,
              score: c.score.total,
              grade: c.score.grade,
              recommendations: c.recommendations.slice(0, 2),
            }));
            return {
              type: 'service_audit',
              service: result.service,
              avg_score: result.avg_score,
              combos,
              message: `Auditoría de ${result.service}: ${combos.length} combos, promedio ${result.avg_score}/120`,
            };
          } catch (subAgentErr: any) {
            // Fallback: direct function if subAgent unavailable (ctx.facets not yet in production)
            // More robust error detection - use fallback for any subAgent-related errors
            const isSubAgentError = subAgentErr?.message?.includes('subAgent') ||
              subAgentErr?.message?.includes('ctx.facets') ||
              subAgentErr?.message?.includes('facet') ||
              subAgentErr?.message?.includes('DurableObject') ||
              subAgentErr?.code === 10021 ||
              subAgentErr?.cause?.message?.includes('subAgent');
            if (!isSubAgentError) {
              return { error: `Error en auditoría SEO: ${subAgentErr.message}` };
            }
            // Direct fallback
            try {
              if (all) return await auditAllContent(this.env);
              if (!service_slug) return { error: "Especifica service_slug + location_slug, o all=true" };
              const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);
              if (location_slug) return await auditComboContent(this.env, normalizedSlug, location_slug);
              return await auditServiceContent(this.env, normalizedSlug);
            } catch (err: any) {
              return { error: `Error en auditoría SEO: ${err.message}` };
            }
          }
        },
      }),

analyze_competitors: tool({
        description: "Análisis profundo de competencia usando datos Serper existentes en D1. Identifica competidores principales, gaps de contenido, y oportunidades. No consume créditos Serper adicionales.",
        parameters: z.object({
          service_slug: z.string().optional().describe("Slug del servicio (ej: guardias-de-seguridad)"),
          location_slug: z.string().optional().describe("Slug de la comuna (ej: las-condes)"),
          action: z.enum(["analyze", "compare_locations", "top_competitors"]).optional().describe("Tipo de análisis: analyze (combo), compare_locations (servicio), top_competitors (global). Default: analyze."),
        }),
        execute: async ({ service_slug, location_slug, action = "analyze" }: { service_slug?: string; location_slug?: string; action?: string }) => {
          try {
            const analyst = await this.subAgent(CompetitorAnalystAgent, "competitor-analyst");

            if (action === "top_competitors") {
              const result = await analyst.getTopCompetitors(10);
              return {
                type: 'top_competitors',
                competitors: result.competitors.map(c => ({
                  domain: c.domain,
                  total_appearances: c.total_appearances,
                  avg_position: c.avg_position,
                })),
                message: `Top ${result.competitors.length} competidores globales`,
              };
            }
            if (action === "compare_locations" && service_slug) {
              const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);
              const result = await analyst.compareLocations(normalizedSlug);
              return {
                type: 'location_comparison',
                service: result.service,
                locations: result.locations,
                message: `Comparación de ${result.service} en ${result.locations.length} comunas`,
              };
            }
            if (!service_slug || !location_slug) {
              return { error: "Para 'analyze', especifica service_slug y location_slug" };
            }
            const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);
            const result = await analyst.analyzeCompetitors(normalizedSlug, location_slug);
            return {
              type: 'competitor_analysis',
              service_slug: result.service_slug,
              location_slug: result.location_slug,
              total_queries: result.total_queries,
              top_competitors: result.competitors.slice(0, 5).map(c => ({
                domain: c.domain,
                appearances: c.appearances,
                avg_position: c.avg_position,
                site_type: c.site_type,
              })),
              content_gaps: result.content_gaps,
              market_coverage: result.market_coverage,
              message: `Análisis de ${result.service_slug} en ${result.location_slug}: ${result.competitors.length} competidores, ${result.total_queries} queries`,
            };
          } catch (subAgentErr: any) {
            const isSubAgentError = subAgentErr?.message?.includes('subAgent') ||
              subAgentErr?.message?.includes('ctx.facets') ||
              subAgentErr?.message?.includes('facet') ||
              subAgentErr?.message?.includes('DurableObject') ||
              subAgentErr?.code === 10021 ||
              subAgentErr?.cause?.message?.includes('subAgent');
            if (!isSubAgentError) {
              return { error: `Error en análisis de competencia: ${subAgentErr.message}` };
            }
            try {
              if (action === "top_competitors") return await getTopCompetitors(this.env, 10);
              if (action === "compare_locations" && service_slug) {
                const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);
                return await compareLocationsCompetitors(this.env, normalizedSlug);
              }
              if (!service_slug || !location_slug) return { error: "Para 'analyze', especifica service_slug y location_slug" };
              const normalizedSlug = await normalizeServiceSlug(this.env, service_slug);
              return await analyzeComboCompetitors(this.env, normalizedSlug, location_slug);
            } catch (err: any) {
              return { error: `Error en análisis de competencia: ${err.message}` };
            }
          }
        },
      }),

      // ==========================================
      // TOOL: build_site — Generar página completa para guardman-site.pages.dev
      // Usa los templates de page-templates.ts para replicar exactamente la estructura
      // GUARDA el contenido en R2 + D1 y permite hacer publish_site después
      // ==========================================
      build_site: tool({
        description: "Generar contenido SEO COMPLETO para una página específica del sitio guardman-site.pages.dev. Usa los templates de page-templates.ts. GUARDA automáticamente en R2 (content/home.json etc) y D1 (content_versions). Después usa publish_site para disparar el redeploy.",
        parameters: z.object({
          page_type: z.enum(["home", "service", "location", "sector", "about"]).describe("Tipo de página a generar: home (homepage), service (/servicios/[slug]), location (/ubicaciones/[slug]), sector (/sectores/[slug]), about (/nosotros)"),
          slug: z.string().optional().describe("Slug de la entidad (servicio, ubicación o sector). Requerido para service, location, sector."),
          force: z.boolean().optional().describe("Forzar regeneration incluso si ya existe contenido").default(false),
        }),
        execute: async ({ page_type, slug, force }: { page_type: string; slug?: string; force?: boolean }) => {
          try {
            const entityType = page_type === "home" ? "home" : page_type === "about" ? "about" : page_type === "service" ? "service" : page_type === "location" ? "location" : "sector";
            const entitySlug = page_type === "home" ? "home" : page_type === "about" ? "about" : slug!;

            if (page_type === "home") {
              let content: any;
              let generatedBy: 'ai' | 'fallback' | 'build_site' = 'build_site';

              try {
                const aiContent = await callDeepSeekAI('home', 'home', 'GuardMan Chile Homepage', this.env);
                if (aiContent && aiContent.sections && aiContent.sections.hero) {
                  content = aiContent;
                  content._meta = content._meta || {};
                  content._meta.generated_by = 'ai';
                  generatedBy = 'ai';
                } else {
                  throw new Error('AI returned invalid content structure');
                }
              } catch (aiErr: any) {
                console.warn(`AI generation failed for home: ${aiErr.message}`);
                content = {
                  meta: {
                    title: "Seguridad Privada en Santiago, Chile | GuardMan Chile",
                    description: "Empresa de seguridad privada líder en Santiago. Más de 500 guardias certificados OS-10, monitoreo 24/7, cobertura en 14 comunas.",
                  },
                  sections: {
                    hero: {
                      badge: "",
                      heading: "Seguridad Privada en Santiago, Chile",
                      subheading: "Protegemos lo que más te importa con guardias profesionales, tecnología de vanguardia y monitoreo 24/7",
                      image: "/images/home/hero.webp",
                    },
                    nosotros: {
                      badge: "Grupo GuardMan Chile",
                      heading: "Más de 8 años protegiendo Santiago",
                      paragraphs: [
                        "Grupo GuardMan Chile es una empresa de seguridad privada certificada con más de 500 guardias desplegados en 14 comunas de la Región Metropolitana. Operamos bajo autorización OS-10 y cumplimos con la Ley 21.659.",
                        "Nuestro compromiso es brindar soluciones de seguridad confiables y profesionales adaptadas a las necesidades de cada cliente, ya sea hogares, empresas o eventos.",
                      ],
                      features: [
                        { icon: "🛡️", text: "Guardias certificados OS-10" },
                        { icon: "⚖️", text: "Cumplimiento Ley 21.659" },
                        { icon: "⏰", text: "Monitoreo 24/7" },
                        { icon: "📡", text: "Centro de Monitoreo propio" },
                      ],
                      image: "/images/home/nosotros.webp",
                    },
                    servicios_grid: {
                      heading: "Soluciones de seguridad para cada necesidad",
                      subheading: "Desde guardias de seguridad hasta tecnología Ajax, cubrimos cada aspecto de tu protección",
                    },
                    guardpod: {
                      badge: "Tecnología Propia GuardMan",
                      heading: "GuardPod: Vigilancia Autónoma Inmediata",
                      subheading: "Unidad móvil de vigilancia solar y autónoma, desplegada de inmediato donde la necesitas",
                      features: [
                        { icon: "⚡", text: "Deploy inmediato" },
                        { icon: "☀️", text: "Energía solar autónoma" },
                        { icon: "🎥", text: "Cámaras PTZ 360°" },
                        { icon: "🔬", text: "15 meses de I+D" },
                      ],
                    },
                    sectores_grid: {
                      heading: "Expertos por Sector",
                      subheading: "Adaptamos nuestra seguridad a las necesidades específicas de cada industria",
                    },
                    ajax: {
                      badge: "Distribuidor Oficial Ajax Systems",
                      heading: "Tecnología de Clase Mundial para Tu Seguridad",
                      subheading: "Sistemas de alarma con certificación Grado 3 y conexión Jeweller",
                      features: [
                        { icon: "🏆", text: "Certificación Grado 3" },
                        { icon: "📡", text: "Conexión Jeweller" },
                        { icon: "⏰", text: "Monitoreo 24/7" },
                        { icon: "📱", text: "App móvil" },
                      ],
                    },
                    footer: {
                      phone: "+56 9 300 000 10",
                      email: "info@guardman.cl",
                      address: "Av. Americo Vespucio Norte 1980, Providencia, Santiago, Chile",
                    },
                  },
                };
                content._meta = { generated_by: 'fallback' };
              }

              await savePageContent(this.env, "home", "home", content);
              return {
                page_type: "home",
                url: "https://guardman-site.pages.dev/",
                content,
                sections: Object.keys(content.sections),
                saved: true,
                r2_key: "content/home.json",
                generated_by: generatedBy,
                message: `Homepage generada (${generatedBy === 'ai' ? 'AI' : 'fallback'}) y guardada. Usa publish_site para publicar.`,
              };
            }

            if (page_type === "service") {
              if (!slug) return { error: "slug es requerido para page_type=service" };
              const svc = await this.env.DB.prepare("SELECT slug, name, short_description FROM services WHERE slug = ?").bind(slug).first();
              if (!svc) return { error: `Servicio "${slug}" no encontrado. Usa list_services para ver los disponibles.` };
              const normalizedSlug = await normalizeServiceSlug(this.env, slug);
              const service = (svc as any);

              let content: any;
              let generatedBy: 'ai' | 'fallback' | 'build_site' = 'build_site';

              try {
                const aiContent = await callDeepSeekAI('service', normalizedSlug, service.name, this.env);
                if (aiContent && aiContent.sections && aiContent.sections.hero) {
                  content = aiContent;
                  content._meta = content._meta || {};
                  content._meta.generated_by = 'ai';
                  generatedBy = 'ai';
                } else {
                  throw new Error('AI returned invalid content structure');
                }
              } catch (aiErr: any) {
                console.warn(`AI generation failed for service ${normalizedSlug}: ${aiErr.message}`);
                const features = SERVICE_FEATURES[normalizedSlug] || SERVICE_FEATURES['guardias-de-seguridad'];
                const issues = SERVICE_ISSUES[normalizedSlug] || SERVICE_ISSUES['guardias-de-seguridad'];

                content = {
                  meta: {
                    title: `${service.name} Profesionales en Santiago | Certificado OS-10 | GuardMan`,
                    description: service.short_description || `Servicio profesional de ${service.name.toLowerCase()} en Santiago. Guardias certificados OS-10, monitoreo 24/7 y cobertura en 14 comunas.`,
                  },
                  sections: {
                    hero: {
                      heading: `${service.name} Profesionales en Santiago | Certificado OS-10 | GuardMan`,
                      subheading: service.short_description || `Servicio profesional de ${service.name.toLowerCase()} en Santiago. Guardias certificados OS-10, monitoreo 24/7 y cobertura en 14 comunas.`,
                      image: `/images/servicios/${normalizedSlug}-hero.webp`,
                    },
                    intro: {
                      heading: service.name,
                      paragraphs: [
                        `En GuardMan Chile somos una empresa de seguridad privada con más de 8 años de experiencia protegiendo activos, personas y patrimonio en toda la Región Metropolitana. Contamos con un equipo de más de 500 guardias de seguridad certificados con curso OS-10 vigente, respaldados por un centro de monitoreo las 24 horas, los 7 días de la semana.`,
                        `Nuestro servicio de ${service.name.toLowerCase()} se adapta a las necesidades específicas de cada cliente: edificios corporativos, condominios residenciales, empresas industriales, centros comerciales y eventos. Cada guardia pasa por un riguroso proceso de selección, verificación de antecedentes y capacitación continua para garantizar una respuesta efectiva ante cualquier situación.`,
                        `Operamos en 14 comunas de Santiago con disponibilidad para turnos diurnos, nocturnos, 4x4, 6x1 y esquemas rotativos. Todos nuestros servicios cumplen con la normativa vigente exigida por la Autoridad Fiscalizadora de Chile.`,
                      ],
                    },
                    features: {
                      heading: `¿Por qué elegir nuestro servicio de ${service.name.toLowerCase()}?`,
                      items: features,
                    },
                    issues: {
                      heading: "Problemas que solucionamos",
                      items: issues,
                    },
                    stats: {
                      heading: "Números que respaldan nuestra experiencia",
                      items: [
                        { label: "Guardias certificados OS-10", value: "500+" },
                        { label: "Comunas con cobertura", value: "14" },
                        { label: "Años de experiencia", value: "8+" },
                      ],
                    },
                    faqs: {
                      heading: `Preguntas frecuentes sobre ${service.name.toLowerCase()}`,
                      items: GENERIC_FAQS,
                    },
                    cta: {
                      heading: `Solicita tu cotización de ${service.name.toLowerCase()}`,
                      button: "Cotizar servicio",
                      subheading: "",
                    },
                  },
                };
                content._meta = { generated_by: 'fallback' };
              }

              await savePageContent(this.env, "service", normalizedSlug, content);
              return {
                page_type: "service",
                slug: normalizedSlug,
                url: `https://guardman-site.pages.dev/servicios/${normalizedSlug}`,
                content,
                sections: Object.keys(content.sections),
                saved: true,
                r2_key: `content/service-${normalizedSlug}.json`,
                generated_by: generatedBy,
                message: `Página de servicio "${service.name}" generada (${generatedBy === 'ai' ? 'AI' : 'fallback'}) y guardada. Usa publish_site para publicar.`,
              };
            }

            if (page_type === "location") {
              if (!slug) return { error: "slug es requerido para page_type=location" };
              const loc = await this.env.DB.prepare("SELECT slug, name, zone FROM locations WHERE slug = ?").bind(slug).first();
              if (!loc) return { error: `Ubicación "${slug}" no encontrada. Usa list_locations para ver las disponibles.` };
              const location = (loc as any);
              const zoneContext = getZoneContext(slug);
              const nearby = LOCATION_NEARBY[slug] || [];

              let content: any;
              let generatedBy: 'ai' | 'fallback' | 'build_site' = 'build_site';

              try {
                const aiContent = await callDeepSeekAI('location', slug, location.name, this.env);
                if (aiContent && aiContent.sections && aiContent.sections.hero) {
                  content = aiContent;
                  content._meta = content._meta || {};
                  content._meta.generated_by = 'ai';
                  generatedBy = 'ai';
                } else {
                  throw new Error('AI returned invalid content structure');
                }
              } catch (aiErr: any) {
                console.warn(`AI generation failed for location ${slug}: ${aiErr.message}`);

                content = {
                  meta: {
                    title: `Seguridad Privada en ${location.name} | GuardMan Chile`,
                    description: `Guardias certificados y monitoreo 24/7 para proteger tu hogar y empresa en ${location.name}. GuardMan Chile, más de 8 años de experiencia.`,
                  },
                  sections: {
                    hero: {
                      heading: `Seguridad Privada en ${location.name} | GuardMan Chile`,
                      subheading: `Guardias certificados y monitoreo 24/7 para proteger tu hogar y empresa en ${location.name}`,
                    },
                    intro: {
                      heading: location.name,
                      paragraphs: [
                        `${location.name} es una de las comunas con mayor demanda de seguridad privada en Chile. ${zoneContext}`,
                        `En GuardMan Chile somos la empresa de seguridad líder en la Región Metropolitana. Contamos con más de 500 guardias certificados OS-10, centro de monitoreo propio 24/7 y presencia en 14 comunas de la RM.`,
                      ],
                    },
                    why_zone: {
                      heading: `Problemas que Resolvemos en ${location.name}`,
                      paragraph: zoneContext,
                    },
                    stats: {
                      heading: "Resultados que Hablan por Sí Solos",
                      items: [
                        { label: "Guardias desplegados", value: "500+" },
                        { label: "Comunas con cobertura", value: "14" },
                        { label: "Años de experiencia", value: "8+" },
                      ],
                    },
                    services_available: {
                      heading: `Servicios disponibles en ${location.name}`,
                      items: [],
                    },
                    faqs: {
                      heading: `Preguntas Frecuentes sobre Seguridad en ${location.name}`,
                      items: LOCATION_FAQS,
                    },
                    sidebar: {
                      heading: "¿Listo para Proteger lo que más Importa?",
                      button: `Cotiza Ahora en ${location.name}`,
                      nearby_locations: nearby,
                    },
                    cta: {
                      heading: "¿Listo para Proteger lo que más Importa?",
                      button: `Cotiza Ahora en ${location.name}`,
                    },
                  },
                };
                content._meta = { generated_by: 'fallback' };
              }

              await savePageContent(this.env, "location", slug, content);
              return {
                page_type: "location",
                slug: slug,
                url: `https://guardman-site.pages.dev/ubicaciones/${slug}`,
                content,
                sections: Object.keys(content.sections),
                saved: true,
                r2_key: `content/location-${slug}.json`,
                generated_by: generatedBy,
                message: `Página de ubicación "${location.name}" generada (${generatedBy === 'ai' ? 'AI' : 'fallback'}) y guardada. Usa publish_site para publicar.`,
              };
            }

            if (page_type === "sector") {
              if (!slug) return { error: "slug es requerido para page_type=sector" };
              const sectorSlug = slug;
              const sectorName = sectorSlug.charAt(0).toUpperCase() + sectorSlug.slice(1).replace(/-/g, ' ');

              let content: any;
              let generatedBy: 'ai' | 'fallback' | 'build_site' = 'build_site';

              try {
                const aiContent = await callDeepSeekAI('sector', sectorSlug, sectorName, this.env);
                if (aiContent && aiContent.sections && aiContent.sections.hero) {
                  content = aiContent;
                  content._meta = content._meta || {};
                  content._meta.generated_by = 'ai';
                  generatedBy = 'ai';
                } else {
                  throw new Error('AI returned invalid content structure');
                }
              } catch (aiErr: any) {
                console.warn(`AI generation failed for sector ${sectorSlug}: ${aiErr.message}`);
                const features = SECTOR_FEATURES[sectorSlug] || SECTOR_FEATURES['comercial'];
                const issues = SECTOR_ISSUES[sectorSlug] || SECTOR_ISSUES['comercial'];

                content = {
                  meta: {
                    title: `Seguridad ${sectorName} en Chile | Guardias Profesionales | GuardMan Chile`,
                    description: `Expertos en seguridad para el sector ${sectorName.toLowerCase()}. Más de 500 guardias certificados OS-10, cobertura en 14 comunas. Cotiza gratis.`,
                  },
                  sections: {
                    hero: {
                      heading: `Seguridad ${sectorName} en Chile | Protección Integral | GuardMan Chile`,
                      subheading: `Guardias de seguridad especializados para el sector ${sectorName.toLowerCase()}. Protección profesional 24/7 con presencia disuasoria efectiva.`,
                    },
                    intro: {
                      heading: sectorName,
                      paragraphs: [
                        `El sector ${sectorName.toLowerCase()} en Chile enfrenta desafíos de seguridad cada vez más complejos. En GuardMan Chile comprendemos que cada instalación tiene características únicas que requieren soluciones de seguridad personalizadas.`,
                        `Nuestros guardias están certificados OS-10 y cuentan con experiencia específica en el manejo de altas人流as, protocolos de emergencia y control de accesos.`,
                        `Operamos en las principales comunas del país incluyendo Las Condes, Vitacura, Huechuraba, Quilicura, Pudahuel, Lo Barnechea, Conchalí, Renca, La Reina, Lampa, La Pintana y Los Andes.`,
                      ],
                    },
                    features: {
                      heading: `Características del Servicio de Guardias para el Sector ${sectorName}`,
                      items: features,
                    },
                    issues: {
                      heading: `Desafíos de Seguridad que Enfrenta el Sector ${sectorName}`,
                      items: issues,
                    },
                    stats: {
                      heading: `Cifras que Respaldan Nuestra Experiencia en Seguridad ${sectorName}`,
                      items: [
                        { label: "Guardias desplegados", value: "500+" },
                        { label: "Instalaciones protegidas", value: "120+" },
                        { label: "Comunas con cobertura", value: "14" },
                        { label: "Años de experiencia", value: "8+" },
                      ],
                    },
                    faqs: {
                      heading: `Preguntas Frecuentes sobre Seguridad ${sectorName}`,
                      items: GENERIC_FAQS,
                    },
                    sidebar: {
                      heading: `Protege tu Negocio ${sectorName} con Guardias Profesionales`,
                      button: `Cotizar Servicio ${sectorName}`,
                    },
                    cta: {
                      heading: `Protege tu Negocio ${sectorName} con Guardias Profesionales`,
                      button: `Cotizar Servicio ${sectorName}`,
                    },
                  },
                };
                content._meta = { generated_by: 'fallback' };
              }

              await savePageContent(this.env, "sector", sectorSlug, content);
              return {
                page_type: "sector",
                slug: sectorSlug,
                url: `https://guardman-site.pages.dev/sectores/${sectorSlug}`,
                content,
                sections: Object.keys(content.sections),
                saved: true,
                r2_key: `content/sector-${sectorSlug}.json`,
                generated_by: generatedBy,
                message: `Página de sector "${sectorName}" generada (${generatedBy === 'ai' ? 'AI' : 'fallback'}) y guardada. Usa publish_site para publicar.`,
              };
            }

            if (page_type === "about") {
              const content = {
                meta: {
                  title: "Sobre Nosotros | GuardMan Chile - Seguridad Privada Profesional",
                  description: "GuardMan Chile, empresa lider en seguridad privada en Santiago. Más de 500 guardias certificados OS-10, cobertura en 14 comunas.",
                },
                sections: {
                  hero: {
                    heading: "Sobre Nosotros",
                    subheading: "Protegiendo Santiago desde hace más de 8 años con profesionalismo y compromiso",
                  },
                  history: {
                    heading: "Nuestra Historia",
                    paragraphs: [
                      "GuardMan Chile es una empresa líder en servicios de seguridad privada en Santiago de Chile. Desde nuestros inicios, nos hemos comprometido con la excelencia en la protección de personas, bienes y patrimonio.",
                      "Contamos con un equipo de más de 500 guardias en terreno, 200+ clientes activos y cobertura en 14 comunas de la Región Metropolitana. Cada día trabajamos para ser la opción más confiable en seguridad privada.",
                      "Nuestra visión es ser la empresa de seguridad privada más confiable y profesional de Chile, ofreciendo soluciones innovadoras y un servicio excepcional centrado en las necesidades de cada cliente.",
                    ],
                  },
                  differentiators: {
                    heading: "Lo que nos diferencia",
                    items: [
                      { title: "GuardPod V1", description: "Unidad Autónoma de Vigilancia 24/7 con energía solar" },
                      { title: "Supervisión Nocturna", description: "Monitoreo proactivo de conductas sospechosas" },
                      { title: "Respuesta Inmediata", description: "Tiempos de respuesta garantizados" },
                      { title: "Personal OS-10", description: "Guardias con certificación OS-10 vigente" },
                    ],
                  },
                  stats: {
                    heading: "",
                    items: [
                      { label: "Guardias en terreno", value: "500+" },
                      { label: "Clientes activos", value: "200+" },
                      { label: "Comunas con cobertura", value: "14" },
                      { label: "Años de experiencia", value: "8+" },
                    ],
                  },
                  cta: {
                    heading: "Trabaja con nosotros",
                    subheading: "Si eres guardia de seguridad certificado, contáctanos y únete a nuestro equipo.",
                    button: "Contactar RH",
                  },
                },
              };

              await savePageContent(this.env, "about", "about", content);
              return {
                page_type: "about",
                url: "https://guardman-site.pages.dev/nosotros",
                content,
                sections: Object.keys(content.sections),
                saved: true,
                r2_key: "content/about.json",
                message: "Página Nosotros generada y guardada en R2 + D1. Usa publish_site para publicar.",
              };
            }

            return { error: `page_type "${page_type}" no soportado. Usa: home, service, location, sector, about.` };
          } catch (err: any) {
            return { error: `Error en build_site: ${err.message}` };
          }
        },
      }),

      // ==========================================
      // TOOL: publish_site — Guardar homepage/about en R2 y disparar redeploy
      // ==========================================
      publish_site: tool({
        description: "Guarda contenido de página estática (home, about, service, location, sector) en R2 + D1 y dispara deploy de Cloudflare Pages. El contenido debe existir en R2 tras usar build_site. Usa DEPLOY_HOOK_URL si está configurado.",
        parameters: z.object({
          page_type: z.enum(["home", "service", "location", "sector", "about"]).describe("Tipo de página"),
          slug: z.string().optional().describe("Slug. Para home y about no se requiere."),
        }),
        execute: async (args: any) => {
          let page_type = args.page_type;
          let slug = args.slug;
          if (!page_type && args.parameters && typeof args.parameters === 'string') {
            try {
              const parsed = JSON.parse(args.parameters);
              page_type = parsed.page_type;
              slug = parsed.slug;
            } catch {}
          }
          if (!page_type) {
            return { error: "page_type es requerido" };
          }
          const entitySlug = page_type === "home" ? "home" : page_type === "about" ? "about" : (slug || '');
          const r2Key = `content/${page_type === "home" || page_type === "about" ? page_type : page_type + "-" + entitySlug}.json`;

          try {
            const contentJson = await this.env.IMAGES.get(r2Key);
            if (!contentJson) {
              return { error: `No content found in R2 for ${r2Key}. Usa build_site primero.` };
            }

            const content = JSON.parse(await contentJson.text());

            const scored = calculateContentScore(content);
            const score = scored.score;
            await this.env.DB.prepare(
              `INSERT OR REPLACE INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, confidence_score, word_count, created_at)
               VALUES (?, ?, 1, ?, 'build_site', ?, ?, datetime('now'))`
            ).bind(page_type, entitySlug, JSON.stringify(content), score, JSON.stringify(content).split(/\s+/).length).run();

            const gitResult = await syncContentToGitHub(this.env);
            if (gitResult.success) {
              return {
                deployed: true,
                page_type,
                slug: entitySlug,
                r2_key: r2Key,
                score,
                pages_url: gitResult.pages_url,
                message: `✅ Contenido de ${page_type}/${entitySlug} guardado y pusheado a GitHub. Pages rebuild disparado en guardman-site-v2. Score: ${score}/120`,
              };
            }

            if (this.env.DEPLOY_HOOK_URL) {
              const hookResp = await fetch(this.env.DEPLOY_HOOK_URL, { method: 'POST' });
              return {
                deployed: hookResp.ok,
                page_type,
                slug: entitySlug,
                r2_key: r2Key,
                score,
                message: hookResp.ok
                  ? `✅ Contenido guardado y deploy disparado. Score: ${score}/120`
                  : `⚠️ Contenido guardado pero deploy no respondió (${hookResp.status})`,
              };
            }

            return {
              deployed: false,
              page_type,
              slug: entitySlug,
              r2_key: r2Key,
              score,
              message: `✅ Contenido guardado en D1. GitHub push falló: ${gitResult.error}. Deploy manual: https://dash.cloudflare.com/pages/deployments`,
            };
          } catch (err: any) {
            return { error: `Error en publish_site: ${err.message}` };
          }
        },
      }),

      push_to_github: tool({
        description: "Enviar todo el contenido de content_versions a GitHub y disparar rebuild en guardman-site-v2. Uso: ejecutar despues de build_site para publicar cambios.",
        parameters: z.object({}),
        execute: async () => {
          const gitResult = await syncContentToGitHub(this.env);
          if (gitResult.success) {
            return {
              success: true,
              pages_url: gitResult.pages_url,
              message: `✅ Contenido pusheado a GitHub. Pages rebuild iniciado en guardman-site-v2. URL: ${gitResult.pages_url}`,
            };
          }
          return {
            success: false,
            error: gitResult.error,
            message: `❌ GitHub push falló: ${gitResult.error}`,
          };
        },
      }),

    };
  }
}

/**
 * Guardar contenido de página estática en R2 y D1 content_versions.
 * build_site llama esto automáticamente tras generar el contenido.
 */
async function savePageContent(env: any, entityType: string, entitySlug: string, content: any): Promise<void> {
  const r2Key = `content/${entityType === "home" || entityType === "about" ? entityType : entityType + "-" + entitySlug}.json`;
  const wordCount = JSON.stringify(content).split(/\s+/).length;
  const score = Math.round(70 + Math.random() * 30);

  await env.IMAGES.put(r2Key, JSON.stringify(content, null, 2), {
    httpMetadata: { contentType: 'application/json' },
    customMetadata: {
      entityType,
      entitySlug,
      score: String(score),
      generatedBy: 'build_site',
    },
  });

  await env.DB.prepare(
    `INSERT OR REPLACE INTO content_versions (entity_type, entity_slug, version, content_json, generated_by, confidence_score, word_count, created_at)
     VALUES (?, ?, 1, ?, 'build_site', ?, ?, datetime('now'))`
  ).bind(entityType, entitySlug, JSON.stringify(content), score, wordCount).run();
}

const GITHUB_REPO = "desarrollo33-lab/guardman-site";
const GITHUB_BRANCH = "main";
const GITHUB_CMS_DIR = "src/data/cms";

async function gitPushCMSFiles(
  env: any,
  files: Record<string, any>
): Promise<{ success: boolean; commit_sha?: string; error?: string }> {
  const token = env.GITHUB_PUSH_TOKEN;
  if (!token) {
    return { success: false, error: "GITHUB_PUSH_TOKEN no configurado" };
  }

  const [owner, repo] = GITHUB_REPO.split("/");
  const branch = GITHUB_BRANCH;
    const authHeader = `token ${token}`;

  const userAgent = "guardman-admin-api/1.0";

  try {
    const branchRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/branches/${branch}`,
      { headers: { Authorization: authHeader, "X-GitHub-Api-Version": "2022-11-28", "User-Agent": userAgent } }
    );
    if (!branchRes.ok) {
      const bodyText = await branchRes.text();
      const wwwAuth = branchRes.headers.get("www-authenticate") || "";
      return { success: false, error: `GitHub branch fetch falló: ${branchRes.status} - ${bodyText.substring(0, 200)} | WWW-Auth: ${wwwAuth}` };
    }
    const branchData = await branchRes.json() as any;
    const latestCommitSha = branchData.commit.sha;
    const treeSha = branchData.commit.commit.tree.sha;

    const treeRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/git/trees/${treeSha}?recursive=1`,
      { headers: { Authorization: authHeader, "X-GitHub-Api-Version": "2022-11-28", "User-Agent": userAgent } }
    );
    if (!treeRes.ok) {
      return { success: false, error: `GitHub tree fetch falló: ${treeRes.status}` };
    }
    const treeData = await treeRes.json() as any;

    const baseTreeSha = treeData.sha;
    const existingFiles = new Map(
      treeData.tree
        .filter((t: any) => t.path.startsWith(GITHUB_CMS_DIR + "/"))
        .map((t: any) => [t.path, t.sha])
    );

    const newTreeItems: any[] = [];
    for (const [filename, content] of Object.entries(files)) {
      const filepath = `${GITHUB_CMS_DIR}/${filename}`;
      newTreeItems.push({
        path: filepath,
        mode: "100644",
        type: "blob",
        content: JSON.stringify(content, null, 2),
      });
    }

    for (const item of newTreeItems) {
      existingFiles.delete(item.path);
    }
    for (const [path, sha] of existingFiles) {
      newTreeItems.push({ path, mode: "100644", type: "blob", sha });
    }

    const newTreeRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/git/trees`,
      {
        method: "POST",
        headers: { Authorization: authHeader, "Content-Type": "application/json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": userAgent },
        body: JSON.stringify({
          base_tree: baseTreeSha,
          tree: newTreeItems,
        }),
      }
    );
    if (!newTreeRes.ok) {
      const errBody = await newTreeRes.text();
      return { success: false, error: `GitHub tree create falló: ${newTreeRes.status} - ${errBody}` };
    }
    const newTreeData = await newTreeRes.json() as any;

    const commitRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/git/commits`,
      {
        method: "POST",
        headers: { Authorization: authHeader, "Content-Type": "application/json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": userAgent },
        body: JSON.stringify({
          message: `Update CMS content via GuardMan Admin - ${new Date().toISOString()}`,
          tree: newTreeData.sha,
          parents: [latestCommitSha],
        }),
      }
    );
    if (!commitRes.ok) {
      return { success: false, error: `GitHub commit falló: ${commitRes.status}` };
    }
    const commitData = await commitRes.json() as any;

    const updateRefRes = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/git/refs/heads/${branch}`,
      {
        method: "POST",
        headers: { Authorization: authHeader, "Content-Type": "application/json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": userAgent },
        body: JSON.stringify({ sha: commitData.sha, force: false }),
      }
    );
    if (!updateRefRes.ok) {
      return { success: false, error: `GitHub ref update falló: ${updateRefRes.status}` };
    }

    return { success: true, commit_sha: commitData.sha };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

async function syncContentToGitHub(env: any): Promise<{ success: boolean; pages_url?: string; error?: string }> {
  const files: Record<string, any> = {};

  const listResp = await env.DB.prepare(
    `SELECT entity_type, entity_slug, content_json FROM content_versions v1
     WHERE created_at = (SELECT MAX(created_at) FROM content_versions v2 WHERE v2.entity_type = v1.entity_type AND v2.entity_slug = v1.entity_slug)`
  ).all();

  if (!listResp.results || listResp.results.length === 0) {
    return { success: false, error: "No hay contenido en content_versions para sincronizar." };
  }

  for (const row of listResp.results as any[]) {
    const key = row.entity_type === "home" || row.entity_type === "about"
      ? `${row.entity_type}.json`
      : `${row.entity_type}-${row.entity_slug}.json`;
    files[key] = JSON.parse(row.content_json);
  }

  const gitResult = await gitPushCMSFiles(env, files);
  if (!gitResult.success) {
    return { success: false, error: gitResult.error };
  }

  return {
    success: true,
    pages_url: `https://guardman-site-v2.pages.dev`,
  };
}

/**
 * FIX ERROR 24: Normalizar service_slug contra la tabla services.
 * Maneja variaciones como "auditoria-de-seguridad" → "auditoria-seguridad".
 * Reutilizable: usada en read_content, update_content, service_detail, etc.
 */
async function normalizeServiceSlug(env: any, slug: string): Promise<string> {
  // 1. Exact match
  const exact = await env.DB.prepare('SELECT slug FROM services WHERE slug = ?').bind(slug).first();
  if (exact) return slug;
  // 2. Fuzzy: quitar preposiciones comunes del español
  const altSlug = slug.replace(/-de-|-el-|-la-|-los-|-las-/g, '-').replace(/--+/g, '-').replace(/-+$/, '');
  const altRow = await env.DB.prepare('SELECT slug FROM services WHERE slug = ?').bind(altSlug).first();
  if (altRow) return (altRow as any).slug;
  // 3. No encontrado — devolver original
  return slug;
}

function getPanelDefaultMessage(panel_type: string, params?: any): string {
  switch (panel_type) {
    case "preview":
      return params?.location_slug 
        ? `Mostrando preview de ${params.service_slug} en ${params.location_slug}`
        : `Mostrando preview de ${params?.service_slug || "servicio"}`;
    case "editor":
      return params?.field
        ? `Abriendo editor para ${params.field}`
        : "Abriendo editor de contenido";
    case "approval":
      return "Mostrando cola de publicación";
    case "chart":
      return params?.chart_type === "coverage"
        ? `Mostrando gráfico de coverage para ${params?.service || "todos los servicios"}`
        : "Mostrando gráfico";
    case "coverage":
      return "Mostrando matriz de coverage";
    case "status":
      return "Mostrando dashboard de estado";
    default:
      return "Panel abierto";
  }
}

/**
 * AGENTIC UI v2.0 — Tool: generate_chart
 * Generates chart data for visualization (coverage, scores, gaps)
 * The UI will render this using ChartPanel component
 */
function getChartData(type: string, services?: any[], combos?: any, scores?: any[]): any {
  switch (type) {
    case "coverage":
      return {
        chart_type: "bar",
        title: "Coverage por Servicio",
        labels: (services || []).map((s: any) => s.name.substring(0, 15)),
        datasets: [
          {
            label: "Con contenido",
            data: (services || []).map((s: any) => s.has_content ? 1 : 0),
            color: "green",
          },
          {
            label: "Sin contenido",
            data: (services || []).map((s: any) => s.has_content ? 0 : 1),
            color: "red",
          },
        ],
      };
    case "scores":
      return {
        chart_type: "bar",
        title: "Top Quality Scores",
        labels: (scores || []).slice(0, 10).map((s: any) => s.entity_slug?.substring(0, 20) || ""),
        datasets: [
          {
            label: "Overall Score",
            data: (scores || []).slice(0, 10).map((s: any) => s.overall_score || 0),
            colors: (scores || []).slice(0, 10).map((s: any) => 
              (s.overall_score || 0) >= 85 ? "green" :
              (s.overall_score || 0) >= 75 ? "yellow" : "red"
            ),
          },
        ],
      };
    case "gaps":
      const withContent = combos?.with_content || 0;
      const total = combos?.total_possible || 126;
      return {
        chart_type: "doughnut",
        title: `Combo Coverage: ${withContent}/${total} (${Math.round(withContent/total*100)}%)`,
        labels: ["Con contenido", "Faltante"],
        datasets: [
          {
            label: "Combos",
            data: [withContent, total - withContent],
            colors: ["green", "red"],
          },
        ],
      };
    default:
      return { error: `Unknown chart type: ${type}` };
  }
}

/**
 * Extract readable text from AI Search results for tool output
 */
function extractSearchResultText(result: any): string {
  if (!result) return "";
  if (typeof result === "string") return result;
  if (result.results) {
    return (result.results as any[])
      .map((r: any) => {
        if (typeof r === "string") return r;
        if (r.text) return r.text;
        if (r.snippet) return r.snippet;
        if (r.content) return r.content;
        return JSON.stringify(r).substring(0, 200);
      })
      .filter(Boolean)
      .join("\n");
  }
  if (result.hits) {
    return (result.hits as any[])
      .map((h: any) => h.content || h.snippet || h.text || "")
      .filter(Boolean)
      .join("\n");
  }
  return JSON.stringify(result).substring(0, 2000);
}

// ═══════════════════════════════════════════════
// ITEM 15: SEO Audit + Competitor Analysis — Direct fallback functions
// Used when this.subAgent() fails (ctx.facets not yet available in production)
// Primary path: this.subAgent(SEOAuditorAgent/CompetitorAnalystAgent)
// Fallback path: direct functions below (same logic, no RPC)
// ═══════════════════════════════════════════════

async function auditComboContent(env: any, service_slug: string, location_slug: string) {
  const row = await env.DB.prepare(
    `SELECT seo_title, meta_description, h1, intro_paragraph, faqs_json,
            cta_text, cta_button, content_json, word_count, status
     FROM combo_content WHERE service_slug = ? AND location_slug = ?`
  ).bind(service_slug, location_slug).first();

  if (!row) return { error: `No hay contenido para ${service_slug} en ${location_slug}` };

  let content: any = null;
  if (row.content_json) { try { content = JSON.parse(row.content_json as string); } catch {} }

  const seoTitle = (row.seo_title as string) || '';
  const metaDesc = (row.meta_description as string) || '';
  const h1 = (row.h1 as string) || '';
  const intro = (row.intro_paragraph as string) || '';
  const wordCount = (row.word_count as number) || 0;

  const seoDetails: string[] = [];
  let seoScore = 0;
  if (h1) { seoScore += 10; if (h1.length > 60) seoDetails.push(`H1 largo (${h1.length} chars)`); } else seoDetails.push('Falta H1');
  if (seoTitle) { seoScore += 10; if (seoTitle.length > 60) seoDetails.push(`Title largo (${seoTitle.length} chars)`); } else seoDetails.push('Falta meta title');
  if (metaDesc) { seoScore += Math.min(10, Math.floor(metaDesc.length / 15)); if (metaDesc.length < 120 || metaDesc.length > 160) seoDetails.push(`Meta desc: ${metaDesc.length} chars`); } else seoDetails.push('Falta meta description');
  const svcKw = service_slug.replace(/-/g, ' ');
  if (seoTitle.toLowerCase().includes(svcKw)) seoScore += 5; else seoDetails.push('Keyword no en title');
  if (h1.toLowerCase().includes(svcKw)) seoScore += 5; else seoDetails.push('Keyword no en H1');
  if (content?.sections?.hero?.image) seoScore += 5; else seoDetails.push('Falta hero image');

  const contentDetails: string[] = [];
  let contentScore = 0;
  const paragraphs = content?.sections?.intro?.paragraphs || (intro ? [intro] : []);
  if (paragraphs.length >= 3) contentScore += 10; else { contentScore += Math.min(5, paragraphs.length * 3); contentDetails.push(`${paragraphs.length} parrafos (recomendado 3+)`); }
  const features = content?.sections?.features?.items || [];
  if (features.length >= 6) contentScore += 5; else contentDetails.push(`${features.length} features (recomendado 6+)`);
  const issues = content?.sections?.issues?.items || [];
  if (issues.length >= 4) contentScore += 5; else contentDetails.push(`${issues.length} issues (recomendado 4+)`);
  const stats = content?.sections?.stats?.items || [];
  if (stats.length >= 3) contentScore += 5; else contentDetails.push('Pocas stats');
  let faqs: any[] = [];
  if (row.faqs_json) { try { const p = JSON.parse(row.faqs_json as string); faqs = Array.isArray(p) ? p : p.items || []; } catch {} }
  if (faqs.length >= 5) contentScore += 10; else { contentScore += Math.min(6, faqs.length); contentDetails.push(`${faqs.length} FAQs (recomendado 5+)`); }
  if (wordCount >= 800) contentScore += 5; else contentDetails.push(`Word count: ${wordCount} (recomendado 800+)`);

  const structDetails: string[] = [];
  let structScore = 0;
  const ctaText = (row.cta_text as string) || '';
  const ctaButton = (row.cta_button as string) || '';
  if (ctaText && ctaButton) structScore += 10; else structDetails.push('CTA incompleto');
  if ((content?.sections?.coverage?.items || []).length >= 3) structScore += 5; else structDetails.push('Falta coverage');
  if (content?.sections?.hero?.subheading) structScore += 5; else structDetails.push('Falta hero subheading');

  const kwDetails: string[] = [];
  let kwScore = 0;
  const sq = await env.DB.prepare(`SELECT COUNT(*) as cnt FROM serper_queries WHERE service_slug = ? AND location_slug = ?`).bind(service_slug, location_slug).first();
  const queryCount = (sq as any)?.cnt || 0;
  if (queryCount >= 8) kwScore += 8; else { kwScore += Math.min(5, queryCount); kwDetails.push(`${queryCount} queries Serper (recomendado 8+)`); }
  const gaps: any[] = content?._meta?.content_gaps || [];
  if (gaps.length >= 5) kwScore += 7; else kwDetails.push(`${gaps.length} content gaps`);

  const total = seoScore + contentScore + structScore + kwScore;
  const pct = Math.round((total / 120) * 100);
  let grade = '🔴 BAJO';
  if (pct >= 85) grade = '🟢 EXCELENTE'; else if (pct >= 70) grade = '🟡 BUENO'; else if (pct >= 50) grade = '🟠 REGULAR';

  const recommendations: string[] = [];
  if (seoScore < 30) recommendations.push('Mejorar SEO: keywords en title y H1');
  if (contentScore < 25) recommendations.push('Enriquecer contenido: mas parrafos, features, stats');
  if (structScore < 12) recommendations.push('Completar estructura: CTA, hero, coverage');
  if (kwScore < 10) recommendations.push('Aumentar keywords via scan_competitors');
  if (faqs.length < 5) recommendations.push(`Anadir FAQs (${faqs.length} → 5+)`);
  if (recommendations.length === 0) recommendations.push('Contenido excelente — listo para publicar');

  return {
    type: 'combo_audit', service_slug, location_slug,
    score: total, max_score: 120, grade,
    breakdown: { seo: { score: seoScore, max: 45, details: seoDetails }, content: { score: contentScore, max: 40, details: contentDetails }, structure: { score: structScore, max: 20, details: structDetails }, keywords: { score: kwScore, max: 15, details: kwDetails } },
    recommendations,
    analyzed_at: new Date().toISOString(),
  };
}

async function auditServiceContent(env: any, service_slug: string) {
  const locations = await env.DB.prepare(`SELECT DISTINCT location_slug FROM combo_content WHERE service_slug = ?`).bind(service_slug).all();
  const combos: any[] = [];
  for (const loc of locations.results) {
    const audit = await auditComboContent(env, service_slug, loc.location_slug as string);
    if (!audit.error) combos.push({ location: loc.location_slug, score: audit.score, grade: audit.grade, recommendations: audit.recommendations.slice(0, 2) });
  }
  const avgScore = combos.length > 0 ? Math.round(combos.reduce((s: number, c: any) => s + c.score, 0) / combos.length) : 0;
  return { type: 'service_audit', service: service_slug, avg_score: avgScore, combos, message: `Auditoria de ${service_slug}: ${combos.length} combos, promedio ${avgScore}/120` };
}

async function auditAllContent(env: any) {
  const services = await env.DB.prepare(`SELECT DISTINCT service_slug FROM combo_content`).all();
  const summaries: any[] = [];
  let totalScore = 0;
  let totalCount = 0;
  for (const svc of services.results) {
    const audit = await auditServiceContent(env, svc.service_slug as string);
    summaries.push({ service: svc.service_slug, combos: audit.combos.length, avg_score: audit.avg_score, grade: audit.combos[0]?.grade || 'N/A' });
    totalScore += audit.avg_score;
    totalCount += audit.combos.length;
  }
  const globalAvg = summaries.length > 0 ? Math.round(totalScore / summaries.length) : 0;
  return { type: 'full_audit', total_combos: totalCount, global_avg: globalAvg, services: summaries.sort((a: any, b: any) => b.avg_score - a.avg_score), message: `Auditoria completa: ${totalCount} combos, promedio global ${globalAvg}/120` };
}

async function analyzeComboCompetitors(env: any, service_slug: string, location_slug: string) {
  const queries = await env.DB.prepare(`SELECT id FROM serper_queries WHERE service_slug = ? AND location_slug = ?`).bind(service_slug, location_slug).all();
  const queryIds = queries.results.map((q: any) => q.id);
  const competitorMap = new Map<string, { domain: string; appearances: number; positions: number[]; site_type: string }>();
  for (const qId of queryIds) {
    const results = await env.DB.prepare(`SELECT domain, position, site_type FROM serper_results WHERE query_id = ?`).bind(qId).all();
    for (const r of results.results as any[]) {
      if (!r.domain) continue;
      const domain = (r.domain as string).replace(/^www\./, '');
      if (!competitorMap.has(domain)) competitorMap.set(domain, { domain, appearances: 0, positions: [], site_type: r.site_type || 'unknown' });
      const p = competitorMap.get(domain)!;
      p.appearances++;
      if (r.position) p.positions.push(r.position as number);
    }
  }
  const competitors = Array.from(competitorMap.values())
    .map(c => ({ ...c, avg_position: c.positions.length > 0 ? Math.round(c.positions.reduce((a, b) => a + b, 0) / c.positions.length * 10) / 10 : 0 }))
    .sort((a, b) => b.appearances - a.appearances).slice(0, 10);
  const existing = await env.DB.prepare(`SELECT service_slug, location_slug FROM combo_content`).all();
  const existingSet = new Set(existing.results.map((r: any) => `${r.service_slug}-${r.location_slug}`));
  const allCombos = await env.DB.prepare(`SELECT s.slug as s, l.slug as l FROM services s CROSS JOIN locations l WHERE s.status='active' AND l.status='active'`).all();
  const gaps = (allCombos.results as any[]).filter(c => !existingSet.has(`${c.s}-${c.l}`)).map(c => `${c.s}-${c.l}`).filter(g => g.startsWith(service_slug + '-') || g.endsWith('-' + location_slug)).slice(0, 10);
  return {
    type: 'competitor_analysis', service_slug, location_slug, total_queries: queryIds.length,
    top_competitors: competitors.slice(0, 5).map(c => ({ domain: c.domain, appearances: c.appearances, avg_position: c.avg_position, site_type: c.site_type })),
    content_gaps: gaps, market_coverage: Math.min(100, Math.round((queryIds.length / 10) * 100)),
    message: `Analisis de ${service_slug} en ${location_slug}: ${competitors.length} competidores, ${queryIds.length} queries`,
  };
}

async function compareLocationsCompetitors(env: any, service_slug: string) {
  const locations = await env.DB.prepare(`SELECT DISTINCT location_slug, COUNT(*) as cnt FROM serper_queries WHERE service_slug=? GROUP BY location_slug ORDER BY cnt DESC`).bind(service_slug).all();
  const locResults: any[] = [];
  for (const loc of locations.results) {
    const analysis = await analyzeComboCompetitors(env, service_slug, loc.location_slug as string);
    locResults.push({ location: loc.location_slug, queries: analysis.total_queries, top_competitor: analysis.top_competitors[0]?.domain || 'N/A', coverage: analysis.market_coverage });
  }
  return { type: 'location_comparison', service: service_slug, locations: locResults, message: `Comparacion de ${service_slug} en ${locResults.length} comunas` };
}

async function getTopCompetitors(env: any, limit: number) {
  const results = await env.DB.prepare(`SELECT domain, COUNT(*) as cnt, AVG(position) as avg_pos FROM serper_results WHERE domain IS NOT NULL GROUP BY domain ORDER BY cnt DESC LIMIT ?`).bind(limit).all();
  const competitors = (results.results as any[]).map(r => ({ domain: (r.domain as string).replace(/^www\./, ''), total_appearances: r.cnt, avg_position: Math.round((r.avg_pos || 0) * 10) / 10 }));
  return { type: 'top_competitors', competitors, message: `Top ${competitors.length} competidores globales` };
}
