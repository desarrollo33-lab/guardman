// GuardMan Admin — Page Templates
//Replica EXACTAMENTE la estructura de guardman-site.pages.dev
//Todos los textos, secciones y estructura de página

export interface PageTemplate {
  type: 'home' | 'service' | 'location' | 'sector' | 'about' | 'contact';
  sections: SectionTemplate[];
}

export interface SectionTemplate {
  id: string;
  type: 'hero' | 'intro' | 'features' | 'issues' | 'stats' | 'faqs' | 'cta' | 'staff' | 'locations-grid' | 'services-grid' | 'sectors-grid' | 'testimonials' | 'coverage' | 'why-zone' | 'nearby-locations' | 'sidebar';
  heading?: string;
  subheading?: string;
  badge?: string;
  paragraph?: string;
  paragraphs?: string[];
  items?: Array<{ label: string; value: string } | { icon?: string; title: string; description: string } | string>;
  ctaText?: string;
  ctaButton?: string;
  image?: string;
  imageAlt?: string;
  colorBg?: string;
  colorText?: string;
  colorAccent?: string;
  relatedServices?: string[];
  relatedSectors?: string[];
  nearbyLocations?: string[];
  serviceSlug?: string;
  locationSlug?: string;
}

// ============================================================
// TEMPLATES POR TIPO DE PÁGINA
// ============================================================

export const PAGE_TEMPLATES: Record<string, PageTemplate> = {

  // ============================================================
  // HOMEPAGE — /
  // ============================================================
  HOME: {
    type: 'home',
    sections: [
      {
        id: 'hero',
        type: 'hero',
        heading: 'Seguridad Privada en Santiago, Chile',
        subheading: 'Protegemos lo que mas te importa',
        image: '/images/hero-home.webp',
        imageAlt: 'GuardMan Chile - Seguridad Privada',
      },
      {
        id: 'nosotros-section',
        type: 'intro',
        badge: 'Grupo GuardMan Chile',
        heading: 'GuardMan Chile - Seguridad privada profesional en Santiago',
        paragraphs: [
          'Mas de 8 años de experiencia protegiendo lo que más te importa. Guardias certificados OS-10 y tecnología de vanguardia para un servicio integral y confiable.',
        ],
        image: '/images/nosotros_seccion.webp',
        imageAlt: 'Equipo GuardMan Chile - Seguridad privada profesional',
        items: [
          { icon: 'shield-check', title: 'Guardias certificados OS-10 vigentes', description: 'Personal capacitado y certificado para maxima proteccion.' },
          { icon: 'file-check', title: 'Cumplimiento Ley 21.659', description: 'Operamos dentro de todas las normativas legales vigentes.' },
          { icon: 'clock', title: 'Atencion 24/7 los 365 dias', description: 'Respuesta inmediata en cualquier momento del ano.' },
          { icon: 'eye', title: 'Centro de monitoreo propio', description: 'Supervision continua desde nuestras instalaciones.' },
        ],
        ctaText: 'Conoce mas sobre nosotros',
        ctaButton: 'https://guardman.cl/nosotros',
      },
      {
        id: 'servicios-grid',
        type: 'services-grid',
        heading: 'Soluciones de seguridad para cada necesidad',
        subheading: 'Desde guardias de seguridad hasta tecnología de vigilancia avanzada, adaptamos nuestros servicios a las características de tu empresa o residencia.',
        serviceLinks: [
          { slug: 'auditoria-seguridad', name: 'Auditoría de Seguridad', image: '/images/service-auditoria-seguridad.webp', title: 'Auditoría de Seguridad Profesional en Santiago | GuardMan Chile', description: 'Evaluación integral de vulnerabilidades para empresas, edificios y condominios. Identificamos puntos débiles y diseñamos soluciones a medida con respaldo de 8+ años de experiencia.' },
          { slug: 'cctv-videovigilancia', name: 'CCTV y Videovigilancia', image: '/images/service-cctv-videovigilancia.webp', title: 'CCTV y Videovigilancia en Santiago | Seguridad Profesional', description: 'Monitoreo 24/7 con guardias OS-10 certificados. Protege tu empresa o hogar con 8 años de experiencia.' },
          { slug: 'control-de-accesos', name: 'Control de Accesos', image: '/images/service-control-de-accesos.webp', title: 'Control de Accesos con Guardias Certificados OS-10 | GuardMan Chile', description: 'Seguridad 24/7 con guardias profesionales y monitoreo propio en toda la Región Metropolitana' },
          { slug: 'escoltas-privados', name: 'Escoltas Privados', image: '/images/service-escoltos-privados.webp', title: 'Escoltas Privados en Chile: Protección Personal y Ejecutiva', description: 'GuardMan Chile ofrece escoltas privados certificados OS-10 con experiencia verificada. Seguridad profesional para empresas, ejecutivos y familias en Santiago y 14 comunas.' },
          { slug: 'guardias-de-seguridad', name: 'Guardias de Seguridad', image: '/images/service-guardias-de-seguridad.webp', title: 'Guardias de Seguridad Profesionales en Santiago | Certificado OS-10', description: 'Más de 8 años protegiendo empresas, condominios y edificios en la Región Metropolitana. 500+ guardias certificados OS-10, monitoreo 24/7 y cobertura en 14 comunas.' },
          { slug: 'monitoreo-24-7', name: 'Monitoreo 24/7', image: '/images/service-monitoreo-24-7.webp', title: 'Monitoreo 24/7: Protección Ininterrumpida para tu Negocio', description: 'Centro de vigilancia propio con respuesta inmediata ante cualquier emergencia, los 365 días del año.' },
          { slug: 'seguridad-industrial', name: 'Seguridad Industrial', image: '/images/service-seguridad-industrial.webp', title: 'Seguridad Industrial en Chile | Expertos en Protección de Instalaciones', description: 'Protege tu planta, bodega o faena con guardias certificados OS-10 y monitoreo 24/7' },
          { slug: 'seguridad-eventos', name: 'Seguridad para Eventos', image: '/images/service-seguridad-eventos.webp', title: 'Seguridad para Eventos en Chile | GuardMan Chile', description: 'Protección profesional para eventos corporativos, masivos y privados' },
        ],
        ctaText: 'Ver todos los servicios',
        ctaButton: 'https://guardman.cl/servicios',
      },
      {
        id: 'guardpod-section',
        type: 'intro',
        badge: 'Tecnología Propia GuardMan',
        heading: 'Guard Pod',
        paragraphs: [
          'Vigilancia autónoma para obras, eventos y zonas sin infraestructura. Energía solar, cámaras PTZ y monitoreo remoto en una unidad desplegable en menos de 2 horas.',
        ],
        image: '/images/s4-thumbnail.webp',
        imageAlt: 'Guard Pod - unidad de vigilancia autónoma con panel solar y cámaras PTZ',
        items: [
          { icon: 'zap', title: 'Despliegue en menos de 2 horas', description: 'Unidad autónoma lista para operar inmediatamente en cualquier ubicación.' },
          { icon: 'sun', title: 'Energia solar, funciona sin red electrica', description: 'Sistema energetico independiente ideal para zonas remotas.' },
          { icon: 'video', title: 'Camaras PTZ 360° con vision nocturna', description: 'Cobertura total y grabacion las 24 horas del dia.' },
          { icon: 'cpu', title: '15 meses de desarrollo propio', description: 'Tecnologia 100% diseñada y fabricada por GuardMan Chile.' },
        ],
        ctaText: 'Conocer Guard Pod',
        ctaButton: 'https://guardman.cl/servicios/guard-pod',
      },
      {
        id: 'sectores-grid',
        type: 'sectors-grid',
        heading: 'Soluciones por sector',
        subheading: 'Adaptamos nuestros servicios a las necesidades especificas de cada industria en Santiago',
        sectorLinks: [
          { slug: 'comercial', name: 'Comercial', image: '/images/s4-thumbnail.webp', title: 'Guardias de Seguridad Comercial en Chile | Protección Integral para tu Negocio', description: 'Más de 500 guardias certificados OS-10 desplegados en centros comerciales, malls y retail en toda la Región Metropolitana y zonas extremas. Protección profesional 24/7 con presencia disuasoria efectiva.' },
          { slug: 'construccion', name: 'Construcción', image: '/images/sector-industrial.webp', title: 'Seguridad para la Construcción en Chile: Protege tu Obra y tu Inversión', description: 'Guardias certificados OS-10, monitoreo 24/7 y soluciones integrales para empresas constructoras. Más de 8 años protegiendo faenas en todo Chile.' },
          { slug: 'educacion', name: 'Educación', image: '/images/hero-home.webp', title: 'Seguridad Profesional para Instituciones Educacionales en Chile', description: 'Guardias certificados OS-10 con experiencia en el sector educación. Protección integral para colegios, universidades, academias y centros de formación. Cotiza ahora.' },
          { slug: 'eventos', name: 'Eventos', image: '/images/s4-thumbnail.webp', title: 'Seguridad para Eventos en Chile | Guardias Profesionales OS-10', description: 'Protege tu evento con guardias certificados, cobertura nacional y experiencia comprobada. Cotiza ahora y asegura el éxito de tu celebración.' },
          { slug: 'industrial', name: 'Industrial', image: '/images/sector-industrial.webp', title: 'Seguridad Industrial en Chile: Protección Integral para Tu Empresa', description: 'Guardias certificados OS-10, monitoreo 24/7 y cobertura en 14 comunas. Más de 8 años protegiendo instalaciones industriales en toda la Región Metropolitana y zona central.' },
          { slug: 'residencial', name: 'Residencial', image: '/images/sector-residencial.webp', title: 'Guardias de Seguridad Residencial en Chile | Protección Profesional para tu Hogar', description: 'Guardias certificados OS-10 con experiencia comprobada. Protección 24/7 para condominos, casas y comunidades residenciales en toda la Región Metropolitana.' },
          { slug: 'salud', name: 'Salud', image: '/images/nosotros_seccion.webp', title: 'Guardias de Seguridad para Clínicas y Hospitales en Chile', description: 'Protección especializada para el sector salud. Guardias certificados OS-10, cobertura 24/7 y protocolos adaptados a instalaciones médicas.' },
        ],
        ctaText: 'Ver todos los sectores',
        ctaButton: 'https://guardman.cl/sectores',
      },
      {
        id: 'ajax-section',
        type: 'intro',
        badge: 'Distribuidor Oficial Ajax Systems',
        heading: 'Tecnologia de clase mundial para tu seguridad',
        paragraphs: [
          'Somos distribuidores oficiales de Ajax Systems, la empresa lider mundial en sistemas de alarmas inteligentes con mas de 4.5 millones de usuarios protegidos en 187 paises.',
        ],
        image: '/images/Ajax-systems-header.jpg',
        imageAlt: 'Sistema de alarma Ajax Systems con hub central y sensores conectados',
        items: [
          { icon: 'shield', title: 'Certificacion Grade 3 Professional', description: 'El maximo nivel internacional de seguridad para instalaciones residenciales y comerciales de alto riesgo.' },
          { icon: 'wifi', title: 'Protocolo Jeweller', description: 'Comunicacion radio encriptada de largo alcance (hasta 2km), inmune a jamming, con verificacion constante del sistema.' },
          { icon: 'eye', title: 'Monitoreo y Video Verificacion 24/7', description: 'Centro de monitoreo propio con verificacion visual de alarmas en tiempo real y respuesta inmediata.' },
          { icon: 'smartphone', title: 'App Ajax - Control Total', description: 'Armado, cámaras, automatización y notificaciones en tiempo real desde tu smartphone iOS y Android.' },
        ],
        ctaText: 'Conocer Ajax Systems',
        ctaButton: 'https://guardman.cl/contacto',
      },
    ],
  },

  // ============================================================
  // PÁGINA DE SERVICIO — /servicios/[slug]
  // ============================================================
  SERVICE: {
    type: 'service',
    sections: [
      {
        id: 'hero',
        type: 'hero',
        heading: '{SEO_TITLE}', // "Guardias de Seguridad Profesionales en Santiago | Certificado OS-10 | GuardMan"
        subheading: '{META_DESCRIPTION}', // "Más de 8 años protegiendo empresas, condominios y edificios..."
        image: '/images/servicios/{SERVICE_SLUG}-hero.webp',
        imageAlt: '{SEO_TITLE}',
        serviceSlug: '{SERVICE_SLUG}',
      },
      {
        id: 'breadcrumb',
        type: 'intro',
        paragraphs: [],
      },
      {
        id: 'intro',
        type: 'intro',
        paragraphs: [
          '{INTRO_PARAGRAPH_1}',
          '{INTRO_PARAGRAPH_2}',
          '{INTRO_PARAGRAPH_3}',
        ],
      },
      {
        id: 'features',
        type: 'features',
        heading: '¿Por qué elegir nuestro servicio de guardias de seguridad?',
        items: '{FEATURES_LIST}',
      },
      {
        id: 'issues',
        type: 'issues',
        heading: 'Problemas que solucionamos con nuestros guardias',
        items: '{ISSUES_LIST}',
      },
      {
        id: 'faqs',
        type: 'faqs',
        heading: 'Preguntas frecuentes sobre nuestros guardias de seguridad',
        items: '{FAQ_ITEMS}',
      },
      {
        id: 'locations-grid',
        type: 'locations-grid',
        heading: 'Disponible en estas ubicaciones',
        items: '{LOCATIONS_LIST}',
      },
      {
        id: 'cta-section',
        type: 'cta',
        heading: 'Solicita tu cotización de guardias de seguridad',
        ctaText: 'Cotizar servicio',
        ctaButton: '/cotizacion',
      },
      {
        id: 'related-services',
        type: 'services-grid',
        heading: 'También te puede interesar',
        items: '{RELATED_SERVICES}',
      },
    ],
  },

  // ============================================================
  // PÁGINA DE UBICACIÓN — /ubicaciones/[slug]
  // ============================================================
  LOCATION: {
    type: 'location',
    sections: [
      {
        id: 'hero',
        type: 'hero',
        heading: 'Seguridad Privada en {LOCATION_NAME} | GuardMan Chile',
        subheading: '{META_DESCRIPTION}',
      },
      {
        id: 'breadcrumb',
        type: 'intro',
        paragraphs: [],
      },
      {
        id: 'intro',
        type: 'intro',
        paragraphs: [
          '{INTRO_PARAGRAPH_1}',
          '{INTRO_PARAGRAPH_2}',
        ],
      },
      {
        id: 'why-zone',
        type: 'why-zone',
        heading: 'Problemas que Resolvemos en {LOCATION_NAME}',
        paragraph: '{ZONE_CONTEXT}',
      },
      {
        id: 'services-available',
        type: 'services-grid',
        heading: 'Servicios disponibles en {LOCATION_NAME}',
        items: '{SERVICES_FOR_LOCATION}',
      },
      {
        id: 'faqs',
        type: 'faqs',
        heading: 'Preguntas Frecuentes sobre Seguridad en {LOCATION_NAME}',
        items: '{FAQ_ITEMS}',
      },
      {
        id: 'sidebar',
        type: 'sidebar',
        heading: '¿Listo para Proteger lo que más Importa?',
        ctaText: 'Cotiza Ahora en {LOCATION_NAME}',
        ctaButton: '/cotizacion',
        nearbyLocations: '{NEARBY_LOCATIONS}',
        servicesInLocation: '{SERVICES_IN_LOCATION}',
      },
      {
        id: 'cta-section',
        type: 'cta',
        heading: '¿Listo para Proteger lo que más Importa?',
        ctaText: 'Cotiza Ahora en {LOCATION_NAME}',
        ctaButton: '/cotizacion',
      },
    ],
  },

  // ============================================================
  // PÁGINA DE SECTOR — /sectores/[slug]
  // ============================================================
  SECTOR: {
    type: 'sector',
    sections: [
      {
        id: 'hero',
        type: 'hero',
        heading: '{SEO_TITLE}',
        subheading: '{META_DESCRIPTION}',
        image: '/images/{SECTOR_SLUG}-sector.webp',
        imageAlt: '{SEO_TITLE}',
      },
      {
        id: 'breadcrumb',
        type: 'intro',
        paragraphs: [],
      },
      {
        id: 'intro',
        type: 'intro',
        paragraphs: [
          '{INTRO_PARAGRAPH_1}',
          '{INTRO_PARAGRAPH_2}',
          '{INTRO_PARAGRAPH_3}',
        ],
      },
      {
        id: 'features',
        type: 'features',
        heading: 'Características del Servicio de Guardias para el Sector {SECTOR_NAME}',
        items: '{FEATURES_LIST}',
      },
      {
        id: 'issues',
        type: 'issues',
        heading: 'Desafíos de Seguridad que Enfrenta el Sector {SECTOR_NAME}',
        items: '{ISSUES_LIST}',
      },
      {
        id: 'faqs',
        type: 'faqs',
        heading: 'Preguntas Frecuentes sobre Seguridad {SECTOR_NAME}',
        items: '{FAQ_ITEMS}',
      },
      {
        id: 'sidebar',
        type: 'sidebar',
        heading: 'Protege tu Negocio {SECTOR_NAME} con Guardias Profesionales Certificados',
        ctaText: 'Cotizar Servicio {SECTOR_NAME}',
        ctaButton: '/cotizacion',
        otherSectors: '{OTHER_SECTORS}',
      },
      {
        id: 'cta-section',
        type: 'cta',
        heading: 'Protege tu Negocio {SECTOR_NAME} con Guardias Profesionales Certificados',
        ctaText: 'Cotizar Servicio {SECTOR_NAME}',
        ctaButton: '/cotizacion',
      },
    ],
  },

  // ============================================================
  // PÁGINA NOSOTROS — /nosotros
  // ============================================================
  ABOUT: {
    type: 'about',
    sections: [
      {
        id: 'hero',
        type: 'hero',
        heading: 'Sobre Nosotros',
        subheading: 'Protegiendo Santiago desde hace más de 8 años con profesionalismo y compromiso',
      },
      {
        id: 'history',
        type: 'intro',
        heading: 'Nuestra Historia',
        paragraphs: [
          'GuardMan Chile es una empresa lider en servicios de seguridad privada en Santiago de Chile.',
          'Contamos con un equipo de mas de 500+ guardias en terreno, 200+ clientes activos y cobertura en 14 comunas de la Region Metropolitana.',
          'Nuestra vision es ser la empresa de seguridad privada mas confiable y profesional de Chile, ofreciendo soluciones innovadoras y un servicio excepcional.',
        ],
      },
      {
        id: 'differentiators',
        type: 'features',
        heading: 'Lo que nos diferencia',
        items: [
          { title: 'GuardPod V1', description: 'Unidad Autonoma de Vigilancia 24/7' },
          { title: 'Supervision Nocturna', description: 'Monitoreo proactivo de conductas sospechosas' },
          { title: 'Respuesta Inmediata', description: 'Tiempos de respuesta garantizados' },
          { title: 'Personal OS-10', description: 'Guardias con certificacion OS-10 vigente' },
        ],
      },
      {
        id: 'cta',
        type: 'cta',
        heading: 'Trabaja con nosotros',
        subheading: 'Si eres guardia de seguridad certificado, contactanos y unete a nuestro equipo.',
        ctaText: 'Contactar RH',
        ctaButton: '/contacto',
      },
    ],
  },

  // ============================================================
  // FOOTER (común a todas las páginas)
  // ============================================================
  FOOTER: {
    type: 'home',
    sections: [
      {
        id: 'footer-brand',
        type: 'intro',
        heading: 'GuardMan Chile',
        paragraphs: [
          'Seguridad privada profesional en Santiago. Protegemos lo que más te importa con guardias certificados OS-10.',
        ],
      },
      {
        id: 'footer-services',
        type: 'features',
        heading: 'Servicios',
        items: [
          'Guardias de Seguridad',
          'CCTV y Videovigilancia',
          'Control de Accesos',
          'Escoltas Privados',
          'Monitoreo 24/7',
          'Seguridad para Eventos',
        ],
      },
      {
        id: 'footer-locations',
        type: 'features',
        heading: 'Ubicaciones',
        items: [
          'Las Condes',
          'Vitacura',
          'Lo Barnechea',
          'Santiago Centro',
          'Huechuraba',
          'Quilicura',
        ],
      },
      {
        id: 'footer-contact',
        type: 'cta',
        heading: 'Contacto',
        ctaText: 'Solicitar Cotización',
        ctaButton: '/cotizacion',
      },
    ],
  },
};

// ============================================================
// HELPERS: Generar placeholders para cada tipo de entidad
// ============================================================

export function getServicePlaceholders(service: { slug: string; name: string; short_description?: string }, locationSlug?: string): Record<string, string> {
  const baseService = service.name.toLowerCase().replace(/\s+/g, ' ').trim();

  return {
    SERVICE_SLUG: service.slug,
    SERVICE_NAME: service.name,
    SEO_TITLE: `${service.name} Profesionales en Santiago | Certificado OS-10 | GuardMan`,
    META_DESCRIPTION: service.short_description || `Servicio profesional de ${service.name.toLowerCase()} en Santiago. Guardias certificados OS-10, monitoreo 24/7 y cobertura en 14 comunas.`,
    LOCATION_SLUG: locationSlug || '',
    LOCATION_NAME: locationSlug ? locationSlug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') : '',
    INTRO_PARAGRAPH_1: `En GuardMan Chile somos una empresa de seguridad privada con más de 8 años de experiencia protegiendo activos, personas y patrimonio en toda la Región Metropolitana. Contamos con un equipo de más de 500 guardias de seguridad certificados con curso OS-10 vigente, respaldados por un centro de monitoreo las 24 horas, los 7 días de la semana.`,
    INTRO_PARAGRAPH_2: `Nuestro servicio de guardias de seguridad se adapta a las necesidades específicas de cada cliente: edificios corporativos, condominios residenciales, empresas industriales, centros comerciales y eventos. Cada guardia pasa por un riguroso proceso de selección, verificación de antecedentes y capacitación continua para garantizar una respuesta efectiva ante cualquier situación.`,
    INTRO_PARAGRAPH_3: `Operamos en 14 comunas de Santiago con disponibilidad para turnos diurnos, nocturnos, 4x4, 6x1 y esquemas rotativos. Todos nuestros servicios cumplen con la normativa vigente exigida por la Autoridad Fiscalizadora de Chile.`,
    FEATURES_LIST: 'FEATURES:8 items con checkmarks',
    ISSUES_LIST: 'ISSUES:6 items con problema/solución',
    STATS_LIST: 'STATS:500+ guardias, 14 comunas, 8+ años',
    FAQ_ITEMS: 'FAQS:6 preguntas frecuentes con respuestas detalladas',
    LOCATIONS_LIST: 'LOCATIONS:14 comunas como cards',
    RELATED_SERVICES: 'RELATED:3 servicios relacionados',
  };
}

export function getLocationPlaceholders(location: { slug: string; name: string; zone?: string }): Record<string, string> {
  return {
    LOCATION_SLUG: location.slug,
    LOCATION_NAME: location.name,
    ZONE_NAME: location.zone || '',
    SEO_TITLE: `Seguridad Privada en ${location.name} | GuardMan Chile`,
    META_DESCRIPTION: `Guardias certificados y monitoreo 24/7 para proteger tu hogar y empresa en ${location.name}`,
    ZONE_CONTEXT: getZoneContext(location.slug),
    INTRO_PARAGRAPH_1: `${location.name} es una de las comunas con mayor demanda de seguridad privada en Chile. ${getZoneContext(location.slug)}`,
    INTRO_PARAGRAPH_2: `En GuardMan Chile somos la empresa de seguridad líder en la Región Metropolitana. Contamos con más de 500 guardias certificados OS-10, centro de monitoreo propio 24/7 y presencia en 14 comunas de la RM. Nuestra experiencia de más de 8 años nos avala.`,
    FAQ_ITEMS: 'FAQS:4 preguntas frecuentes sobre seguridad en esta zona',
    NEARBY_LOCATIONS: 'NEARBY:3 comunas cercanas',
    SERVICES_IN_LOCATION: 'SERVICES:6 servicios disponibles',
    STATS_LIST: 'STATS: stats vacío (sin datos en página ubicación)',
  };
}

export function getSectorPlaceholders(sector: { slug: string; name: string }): Record<string, string> {
  return {
    SECTOR_SLUG: sector.slug,
    SECTOR_NAME: sector.name,
    SEO_TITLE: `Guardias de Seguridad ${sector.name} en Chile | Protección Integral para tu Negocio | GuardMan Chile`,
    META_DESCRIPTION: `Más de 500 guardias certificados OS-10 desplegados en centros comerciales, malls y retail en toda la Región Metropolitana y zonas extremas. Protección profesional 24/7 con presencia disuasoria efectiva.`,
    INTRO_PARAGRAPH_1: `El sector ${sector.name.toLowerCase()} en Chile enfrenta desafíos de seguridad cada vez más complejos. Desde robos en tiendas hasta situaciones de emergencia, la presencia de guardias de seguridad especializados se ha convertido en una necesidad estratégica para proteger activos, personal y clientes. En GuardMan Chile comprendemos que cada instalación tiene características únicas que requieren soluciones de seguridad personalizadas.`,
    INTRO_PARAGRAPH_2: `Nuestros guardias de seguridad ${sector.name.toLowerCase()} están certificados OS-10 y cuentan con experiencia específica en el manejo de altas人流as, protocolos de emergencia y control de accesos. La presencia visible de personal capacitado no solo disuade potenciales incidentes, sino que genera un ambiente de confianza tanto para tus colaboradores como para tus clientes.`,
    INTRO_PARAGRAPH_3: `Operamos en las principales comunas del país incluyendo Las Condes, Vitacura, Huechuraba, Quilicura, Pudahuel, Lo Barnechea, Conchalí, Renca, La Reina, Lampa, La Pintana y Los Andes.`,
    FEATURES_LIST: 'FEATURES:12 items específicos del sector',
    ISSUES_LIST: 'ISSUES:10 problemas específicos del sector',
    STATS_LIST: 'STATS:500+ guardias, 120+ instalaciones, 14 comunas, 8+ años, 97% resolución',
    FAQ_ITEMS: 'FAQS:6 preguntas frecuentes',
    OTHER_SECTORS: 'OTHER:6 sectores restantes',
  };
}

export function getZoneContext(slug: string): string {
  const contexts: Record<string, string> = {
    'las-condes': 'Las Condes es una de las comunas con mayor demanda de seguridad privada en Chile. Con zonas comerciales como Parque Arauco y Costanera Center, y un tejido empresarial denso, contar con un servicio de vigilancia profesional marca la diferencia entre la tranquilidad y la preocupación.',
    'vitacura': 'Vitacura se caracteriza por ser una zona residencial de alto valor y embajadas. Las necesidades más comunes incluyen control de accesos residencial, escoltas VIP y monitoreo perimetral.',
    'huechuraba': 'Huechuraba alberga centros comerciales como Mall Costanera Center y empresas de diversos sectores. Requiere vigilancia especializada para zonas de alto flujo.',
    'santiago-centro': 'Santiago Centro es el corazón comercial y turístico de la ciudad. Alta concentración de oficinas, comercios y espacios públicos que requieren vigilancia permanente.',
    'quilicura': 'Quilicura es una zona industrial y logística en constante crecimiento. Ideal para deployments de Guard Pod en obras y centros logísticos.',
    'pudahuel': 'Pudahuel, cercano al aeropuerto, combina zonas residenciales e industriales. Requieren guardias con experiencia en control de accesos y gestión de emergencias.',
    'renca': 'Renca es un sector en desarrollo con mezcla de áreas residenciales e industriales. Los servicios de vigilancia adaptados son esenciales para la seguridad local.',
    'conchali': 'Conchalí combina zonas residenciales y comerciales. Necesita guardias con capacidad de control de accesos y vigilancia preventiva.',
    'la-reina': 'La Reina es un sector residencial tranquilo y familiar. Los servicios de vigilancia residencial y escoltas privados son los más demandados.',
    'lo-barnechea': 'Lo Barnechea combina áreas residenciales de lujo con propiedades rurales. Ideal para servicios de escoltas y seguridad residencial de alto nivel.',
    'lampa': 'Lampa es una zona de expansión con parques industriales. El Guard Pod es especialmente útil aquí por la falta de infraestructura.',
    'la-pintana': 'La Pintana es predominantemente residencial. Los guardias de seguridad comunitaria y control de accesos son los servicios más solicitados.',
    'los-andes': 'Los Andes es una ciudad estratégica en la región de Valparaíso. Ofrecemos cobertura completa con guardias certificados para toda el área urbana.',
    'san-felipe': 'San Felipe es un centro comercial y residencial en la región de Valparaíso. Nuestros servicios incluyen guardias OS-10 y monitoreo 24/7.',
  };
  return contexts[slug] || `${slug} es una zona de la Región Metropolitana con necesidades específicas de seguridad.`;
}

export const SERVICE_FEATURES: Record<string, string[]> = {
  'guardias-de-seguridad': [
    'Guardias certificados con curso OS-10 vigente y antecedentes verificables',
    'Centro de monitoreo 24/7 con conexión en tiempo real a las instalaciones',
    'Turnos flexibles: 4x4, 6x1, 5x2, fijo día, fijo noche y rotativos',
    'Cobertura en 14 comunas de la Región Metropolitana de Santiago',
    'Supervisión permanente y reportes de actividad diarios',
    'Coordinación con Carabineros y PDI ante emergencias',
    'Rondas preventivas y control de accesos rigurosas',
    'Respuesta inmediata ante incidentes las 24 horas',
  ],
  'cctv-videovigilancia': [
    'Cámaras de alta resolución con visión nocturna',
    'Monitoreo remoto 24/7 desde nuestro centro de control',
    'Grabación en nube con respaldo de 30 días',
    'Detección de movimiento y alertas en tiempo real',
    'Integración con sistemas de alarma y control de accesos',
    'Acceso remoto desde smartphone y escritorio',
    'Análisis de video con inteligencia artificial',
    'Instalación profesional y mantenimiento incluido',
  ],
};

export const SERVICE_ISSUES: Record<string, string[]> = {
  'guardias-de-seguridad': [
    'Robos y hurtos en zonas residenciales y condominios sin vigilancia',
    'Falta de control en el ingreso de visitantes y vehículos no autorizados',
    'Sustracción de mercadería en bodegas y centros logísticos',
    'Incidentes de violencia en eventos y espacios comerciales',
    'Ausencia de registro de eventos y personas en edificios corporativos',
    'Vulnerabilidad ante encerronas y robos en el exterior de instalaciones',
  ],
};

export const LOCATION_NEARBY: Record<string, string[]> = {
  'las-condes': ['la-reina', 'lo-barnechea', 'vitacura'],
  'vitacura': ['las-condes', 'lo-barnechea', 'santiago-centro'],
  'huechuraba': ['quilicura', 'conchali', 'renca'],
  'santiago-centro': ['conchali', 'renca', 'la-reina'],
  'quilicura': ['huechuraba', 'lampa', 'renca'],
  'pudahuel': ['la-pintana', 'conchali', 'renca'],
};

export const SECTOR_FEATURES: Record<string, string[]> = {
  'comercial': [
    'Guardias certificados OS-10 con capacitación vigente según normativa chilena',
    'Control de accesos profesional con registro de visitantes, proveedores y personal',
    'Rondas preventivas programadas y aleatorias en perimetros y áreas comunes',
    'Monitoreo y coordinación con centro de operaciones 24/7 las 365 días del año',
    'Protocolos de emergencia adaptados a normativa OS10 y Carabineros',
    'Supervisión permanente con Jefes de Turno en cada instalación comercial',
    'Reportes diarios de novedades y KPIs de gestión de seguridad',
    'Integración con sistemas de CCTV y alarmas para respuesta integral',
    'Manejo de conflictos y situaciones de alta demanda con protocolos especializados',
    'Cobertura flexible para temporadas altas, eventos promocionales y liquidaciones',
    'Presencia disuasoria visible que reduce intentos de robo y vandalismo',
    'Comunicación inmediata con autoridades en casos de emergencia',
  ],
};

export const SECTOR_ISSUES: Record<string, string[]> = {
  'comercial': [
    'Robos en modalidad oportunista (hurtos menores y flagrantes) que afectan la rentabilidad del retail',
    'Ingresos no autorizados a áreas restringidas como bodegas, cajas y sectores de carga',
    'Situaciones de violencia entre clientes o hacia personal de ventas',
    'Vandalismo en espacios comunes, estacionamientos y fachadas comerciales',
    'Pérdida de mercadería durante horarios de alta afluencia por fallas en control',
    'Emergencias médicas o evacuaciones que requieren respuesta rápida y organizada',
    'Protestas o actividades que puedan afectar la operación normal del comercio',
    'Suplantación de identidad o uso indebido de credenciales de acceso',
    'Actividades sospechosas previo a robos de mayor escala (reconocimiento)',
    'Gestión de protocolos en eventos masivos o lanzamientos promocionales',
  ],
};

export const GENERIC_FAQS = [
  {
    question: '¿Qué tipo de turnos ofrecen para guardias de seguridad?',
    answer: 'Ofrecemos turnos diurnos, nocturnos, 4x4 (4 días trabajados, 4 libres), 6x1 (6 días trabajados, 1 libre), 5x2 y esquemas rotativos. El esquema se adapta a las necesidades de seguridad de cada cliente y normativa laboral vigente.',
  },
  {
    question: '¿Cuánto tiempo toma implementar el servicio de guardias?',
    answer: 'En GuardMan Chile podemos iniciar el servicio de guardias de seguridad en un plazo de 24 a 72 horas hábiles tras aprobar la cotización. Para proyectos de mayor envergadura, el tiempo de implementación se coordina según la complejidad operativa.',
  },
  {
    question: '¿Los guardias cuentan con curso OS-10 vigente?',
    answer: 'Sí. Todos nuestros guardias poseen certificación OS-10 vigente, requisito legal obligatorio para trabajar en seguridad privada en Chile. Realizamos verificaciones periódicas y renovación de certificaciones para cada miembro del equipo.',
  },
  {
    question: '¿En qué comunas de Santiago ofrecen cobertura?',
    answer: 'Cubrimos 14 comunas de la Región Metropolitana, incluyendo Las Condes, Vitacura, Lo Barnechea, Providencia, Santiago Centro, Huechuraba, Quilicura, Renca, La Reina, Maipú, Puente Alto, entre otras. Consultanos por tu comuna.',
  },
  {
    question: '¿Cómo se determina el precio del servicio de guardias?',
    answer: 'El costo depende de la cantidad de guardias, tipo de turno, horario de operación, nivel de riesgo de la instalación y servicios complementarios requeridos como monitoreo o registración de eventos. Solicita una cotización personalizada sin compromiso.',
  },
  {
    question: '¿Ofrecen contratos flexibles sin permanencia mínima?',
    answer: 'Sí. Tenemos planes desde 3 meses de compromiso con renovaciones mensuales, hasta contratos anuales con condiciones preferenciales. El cliente elige el esquema que mejor se ajuste a su operación y presupuesto.',
  },
];

export const LOCATION_FAQS = [
  {
    question: `¿Cuánto cuesta un servicio de seguridad en esta zona?`,
    answer: 'Los costos varían según la comuna, tipo de instalación, turnos requeridos y jornada de trabajo. En GuardMan Chile ofrecemos cotizaciones personalizadas sin compromiso. Contáctanos para recibir una propuesta adaptée a tus necesidades.',
  },
  {
    question: `¿Tienen guardias disponibles para esta comuna?`,
    answer: 'Sí, operamos en las 14 comunas de la Región Metropolitana. Consulta disponibilidad específica para tu dirección y te asignaremos el equipo más cercano.',
  },
  {
    question: `¿Qué servicios de seguridad son más populares en esta zona?`,
    answer: 'Los servicios más solicitados en esta zona incluyen guardias de seguridad, monitoreo 24/7 y control de accesos. Para zonas residenciales, también ofrecemos escoltas privados.',
  },
  {
    question: `¿Cómo funciona el monitoreo 24/7 en esta zona?`,
    answer: 'Nuestro centro de monitoreo opera las 24 horas desde nuestras instalaciones, supervisando todas las ubicaciones en tiempo real. Ante cualquier alerta, Dispatchamos la respuesta más cercana.',
  },
];
