// GuardMan Admin — SEO Auditor Sub-Agent
// Item 15: Sub-agents facets — Specialized SEO analysis
// RPC methods callable via this.subAgent(SEOAuditorAgent, "main")
import { Agent } from 'agents';
import type { Env as AppEnv } from '../types/index';

type AuditorEnv = AppEnv & Record<string, unknown>;

interface ScoreBreakdown {
  total: number;
  max: number;
  grade: string;
  seo: { score: number; max: number; details: string[] };
  content: { score: number; max: number; details: string[] };
  structure: { score: number; max: number; details: string[] };
  keywords: { score: number; max: number; details: string[] };
}

interface AuditResult {
  service_slug: string;
  location_slug: string;
  score: ScoreBreakdown;
  recommendations: string[];
  analyzed_at: string;
}

export class SEOAuditorAgent extends Agent<AuditorEnv> {
  declare env: AuditorEnv;
  declare ctx: any;
  initialState = {};

  async onStart() {
    await this.ctx.storage.sql.exec(`
      CREATE TABLE IF NOT EXISTS audit_cache (
        service_slug TEXT NOT NULL,
        location_slug TEXT NOT NULL,
        result_json TEXT NOT NULL,
        analyzed_at TEXT NOT NULL,
        PRIMARY KEY (service_slug, location_slug)
      )
    `);
  }

  /**
   * Analyze SEO quality of a combo's content
   * Returns detailed scoring breakdown + recommendations
   */
  async analyzeContent(service_slug: string, location_slug: string): Promise<AuditResult> {
    // Check local cache first
    const cached = await this.ctx.storage.sql.exec(
      `SELECT result_json FROM audit_cache WHERE service_slug = ? AND location_slug = ?`,
      service_slug, location_slug
    ).toArray();

    if (cached.length > 0) {
      const parsed = JSON.parse(cached[0].result_json as string);
      const age = Date.now() - new Date(parsed.analyzed_at).getTime();
      if (age < 3600000) return parsed;
    }

    // Fetch content from D1
    const row = await this.env.DB.prepare(
      `SELECT seo_title, meta_description, h1, intro_paragraph, faqs_json,
              cta_text, cta_button, local_context, content_json, word_count, status
       FROM combo_content WHERE service_slug = ? AND location_slug = ?`
    ).bind(service_slug, location_slug).first();

    if (!row) {
      return {
        service_slug, location_slug,
        score: { total: 0, max: 120, grade: '🔴 SIN CONTENIDO', seo: { score: 0, max: 45, details: ['No existe contenido'] }, content: { score: 0, max: 40, details: ['No existe contenido'] }, structure: { score: 0, max: 20, details: ['No existe contenido'] }, keywords: { score: 0, max: 15, details: ['No existe contenido'] } },
        recommendations: ['Generar contenido primero usando generate tool'],
        analyzed_at: new Date().toISOString(),
      };
    }

    // Parse content
    let content: any = null;
    if (row.content_json) {
      try { content = JSON.parse(row.content_json as string); } catch {}
    }

    const seoTitle = (row.seo_title as string) || '';
    const metaDesc = (row.meta_description as string) || '';
    const h1 = (row.h1 as string) || '';
    const intro = (row.intro_paragraph as string) || '';
    const wordCount = (row.word_count as number) || 0;

    // ── SEO Score (max 45) ──────────────────
    const seoDetails: string[] = [];
    let seoScore = 0;

    if (h1) { seoScore += 10; if (h1.length > 60) seoDetails.push(`H1 largo (${h1.length} chars) — recomendado < 60`); }
    else seoDetails.push('Falta H1');

    if (seoTitle) { seoScore += 10; if (seoTitle.length > 60) seoDetails.push(`Meta title largo (${seoTitle.length} chars)`); }
    else seoDetails.push('Falta meta title');

    if (metaDesc) {
      const descScore = Math.min(10, Math.floor(metaDesc.length / 15));
      seoScore += descScore;
      if (metaDesc.length < 120) seoDetails.push(`Meta description corta (${metaDesc.length} chars)`);
      if (metaDesc.length > 160) seoDetails.push(`Meta description larga (${metaDesc.length} chars)`);
    } else seoDetails.push('Falta meta description');

    const serviceKw = service_slug.replace(/-/g, ' ');
    const locationKw = location_slug.replace(/-/g, ' ');
    if (seoTitle.toLowerCase().includes(serviceKw) && seoTitle.toLowerCase().includes(locationKw)) seoScore += 5;
    else seoDetails.push('Keywords no en meta title');
    if (h1.toLowerCase().includes(serviceKw)) seoScore += 5;
    else seoDetails.push('Service keyword no en H1');

    if (content?.sections?.hero?.image) seoScore += 5;
    else seoDetails.push('Falta hero image');

    // ── Content Score (max 40) ──────────────
    const contentDetails: string[] = [];
    let contentScore = 0;

    const paragraphs: any[] = content?.sections?.intro?.paragraphs || (intro ? [intro] : []);
    if (paragraphs.length >= 3) contentScore += 10;
    else if (paragraphs.length >= 2) { contentScore += 5; contentDetails.push('Solo 2 párrafos — recomendado 3+'); }
    else contentDetails.push(`Intro tiene ${paragraphs.length} párrafo(s)`);

    const features: any[] = content?.sections?.features?.items || [];
    if (features.length >= 6) contentScore += 5;
    else { contentScore += Math.min(3, features.length); contentDetails.push(`${features.length} features — recomendado 6+`); }

    const issues: any[] = content?.sections?.issues?.items || [];
    if (issues.length >= 4) contentScore += 5;
    else { contentScore += Math.min(3, issues.length); contentDetails.push(`${issues.length} issues — recomendado 4+`); }

    const stats: any[] = content?.sections?.stats?.items || [];
    if (stats.length >= 3) contentScore += 5;
    else contentDetails.push('Pocas stats — recomendado 3+');

    let faqs: any[] = [];
    if (row.faqs_json) { try { const parsed = JSON.parse(row.faqs_json as string); faqs = Array.isArray(parsed) ? parsed : parsed.items || []; } catch {} }
    if (faqs.length >= 5) contentScore += 10;
    else { contentScore += Math.min(6, faqs.length); contentDetails.push(`${faqs.length} FAQs — recomendado 5+`); }

    if (wordCount >= 800) contentScore += 5;
    else { contentScore += wordCount >= 500 ? 3 : 0; contentDetails.push(`Word count: ${wordCount} — recomendado 800+`); }

    // ── Structure Score (max 20) ────────────
    const structDetails: string[] = [];
    let structScore = 0;

    const ctaText = (row.cta_text as string) || '';
    const ctaButton = (row.cta_button as string) || '';
    if (ctaText && ctaButton) structScore += 10;
    else if (ctaText || ctaButton) { structScore += 5; structDetails.push('CTA incompleto'); }
    else structDetails.push('Falta CTA');

    if ((content?.sections?.coverage?.items || []).length >= 3) structScore += 5;
    else structDetails.push('Falta coverage');

    if (content?.sections?.hero?.subheading) structScore += 5;
    else structDetails.push('Falta hero subheading');

    // ── Keywords Score (max 15) ─────────────
    const kwDetails: string[] = [];
    let kwScore = 0;

    const serperQueries = await this.env.DB.prepare(
      `SELECT query_text FROM serper_queries WHERE service_slug = ? AND location_slug = ? LIMIT 10`
    ).bind(service_slug, location_slug).all();
    const queryCount = serperQueries.results?.length || 0;
    if (queryCount >= 8) kwScore += 8;
    else { kwScore += Math.min(5, queryCount); kwDetails.push(`${queryCount} queries Serper — recomendado 8+`); }

    const gaps: any[] = content?._meta?.content_gaps || [];
    if (gaps.length >= 5) kwScore += 7;
    else { kwScore += Math.min(4, gaps.length); kwDetails.push(`${gaps.length} content gaps`); }

    // ── Aggregate ───────────────────────────
    const total = seoScore + contentScore + structScore + kwScore;
    const pct = Math.round((total / 120) * 100);
    let grade = '🔴 BAJO';
    if (pct >= 85) grade = '🟢 EXCELENTE';
    else if (pct >= 70) grade = '🟡 BUENO';
    else if (pct >= 50) grade = '🟠 REGULAR';

    const recommendations: string[] = [];
    if (seoScore < 30) recommendations.push('Mejorar SEO: keywords en title y H1');
    if (contentScore < 25) recommendations.push('Enriquecer contenido: más párrafos, features, stats');
    if (structScore < 12) recommendations.push('Completar estructura: CTA, hero subheading, coverage');
    if (kwScore < 10) recommendations.push('Aumentar keywords via scan_competitors');
    if (wordCount < 500) recommendations.push(`Aumentar word count (${wordCount} → 800+)`);
    if (faqs.length < 5) recommendations.push(`Añadir más FAQs (${faqs.length} → 5+)`);
    if (recommendations.length === 0) recommendations.push('Contenido en excelente estado — listo para publicar');

    const result: AuditResult = {
      service_slug, location_slug,
      score: { total, max: 120, grade, seo: { score: seoScore, max: 45, details: seoDetails }, content: { score: contentScore, max: 40, details: contentDetails }, structure: { score: structScore, max: 20, details: structDetails }, keywords: { score: kwScore, max: 15, details: kwDetails } },
      recommendations,
      analyzed_at: new Date().toISOString(),
    };

    await this.ctx.storage.sql.exec(
      `INSERT OR REPLACE INTO audit_cache (service_slug, location_slug, result_json, analyzed_at) VALUES (?, ?, ?, ?)`,
      service_slug, location_slug, JSON.stringify(result), new Date().toISOString()
    );

    return result;
  }

  /**
   * Batch audit all combos for a given service
   */
  async auditService(service_slug: string): Promise<{ service: string; combos: AuditResult[]; avg_score: number }> {
    const locations = await this.env.DB.prepare(
      `SELECT DISTINCT l.slug FROM locations l INNER JOIN combo_content cc ON cc.location_slug = l.slug WHERE cc.service_slug = ?`
    ).bind(service_slug).all();

    const combos: AuditResult[] = [];
    for (const loc of locations.results) {
      combos.push(await this.analyzeContent(service_slug, loc.slug as string));
    }

    const avgScore = combos.length > 0 ? Math.round(combos.reduce((s, c) => s + c.score.total, 0) / combos.length) : 0;
    return { service: service_slug, combos, avg_score: avgScore };
  }

  /**
   * Full audit of all content in the system
   */
  async auditAll(): Promise<{ services: { service: string; combos: number; avg_score: number; grade: string }[]; global_avg: number; total_combos: number }> {
    const services = await this.env.DB.prepare(`SELECT DISTINCT service_slug FROM combo_content`).all();

    const summaries = [];
    let totalScore = 0;
    let totalCount = 0;

    for (const svc of services.results) {
      const audit = await this.auditService(svc.service_slug as string);
      summaries.push({ service: svc.service_slug as string, combos: audit.combos.length, avg_score: audit.avg_score, grade: audit.combos[0]?.score.grade || 'N/A' });
      totalScore += audit.avg_score;
      totalCount += audit.combos.length;
    }

    return { services: summaries.sort((a, b) => b.avg_score - a.avg_score), global_avg: totalCount > 0 ? Math.round(totalScore / summaries.length) : 0, total_combos: totalCount };
  }

  /**
   * Clear audit cache
   */
  async clearCache(service_slug?: string, location_slug?: string): Promise<{ cleared: number }> {
    if (service_slug && location_slug) {
      await this.ctx.storage.sql.exec(`DELETE FROM audit_cache WHERE service_slug = ? AND location_slug = ?`, service_slug, location_slug);
      return { cleared: 1 };
    }
    await this.ctx.storage.sql.exec(`DELETE FROM audit_cache`);
    return { cleared: -1 };
  }
}
