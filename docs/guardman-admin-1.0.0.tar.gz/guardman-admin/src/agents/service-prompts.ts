// GuardMan v5.3 — Service-specific prompts for content generation
// Each service gets a unique context that produces differentiated content

export const SERVICE_PROMPTS: Record<string, string> = {
  'guardias-de-seguridad': `
SERVICIO: Guardias de Seguridad Presenciales
ENFOQUE: Personal físico uniformado, vigilancia humana, control de accesos, rondas perimetrales.
DIFERENCIADOR vs competencia: Centro de monitoreo propio (no tercerizado), certificación OS-10 interna, supervisores de campo en cada zona.
NO MENCIONAR: cámaras, CCTV, tecnología, videovigilancia, escoltas, auditoría (eso es otro servicio).
PALABRAS CLAVE OBLIGATORIAS: guardia, vigilancia, portería, ronda, turno, OS-10, presencia disuasoria, uniformado.
FEATURES ÚNICOS (usar estos, NO los genéricos):
- Guardias fijos en portería con control de ingreso vehicular y peatonal
- Rondines perimetrales programados y aleatorios según mapa de riesgo
- Turnos rotativos 4x4, 6x1 o 5x2 con relevo garantizado
- Supervisión de campo con inspectores dedicados por zona
- Reporte diario de novedades y libro de guardia digitalizado
- Coordinación directa con Carabineros y servicios de emergencia
- Verificación de antecedentes y evaluación psicológica del personal
- Relevo inmediato ante ausencias (backup de guardias disponibles)
ISSUES ESPECÍFICOS (NO usar "Accesos no controlados" genérico):
- Ingreso de personas no autorizadas a edificios y condominios sin verificación de identidad
- Robo de especies en bodegas y estacionamientos por falta de vigilancia presencial
- Incidentes nocturnos sin respuesta inmediata por ausencia de guardias en sitio
- Falta de registro de visitantes y control de llaves maestras
- Conflictos vecinales y situaciones de violencia sin personal capacitado para mediar
- Ausencia de protocolos de evacuación y emergencia en edificios residenciales`,

  'cctv-videovigilancia': `
SERVICIO: CCTV y Videovigilancia
ENFOQUE: Cámaras IP, grabación, almacenamiento, acceso remoto, analítica de video.
DIFERENCIADOR vs competencia: Diseño personalizado post-auditoría, integración con centro de monitoreo propio, acceso app móvil.
NO MENCIONAR: guardias físicos, rondas, portería, escoltas, auditoría (otros servicios).
PALABRAS CLAVE OBLIGATORIAS: cámara, CCTV, videovigilancia, grabación, remoto, monitoreo, resolución, cobertura, imagen, lente.
FEATURES ÚNICOS:
- Diseño de cobertura cámaras con análisis de puntos ciegos y overlapeo
- Cámaras IP de alta resolución (4K) con visión nocturna infrarroja
- Almacenamiento en la nube con retención configurable de 30 a 90 días
- Acceso remoto desde smartphone con app dedicada y notificaciones push
- Analítica de video: detección de movimiento, línea virtual, objetos abandonados
- Integración con centro de monitoreo para verificación en tiempo real
- Instalación profesional con certificación eléctrica y cableado estructurado
- Mantenimiento preventivo trimestral con limpieza de lentes y ajuste de ángulos
ISSUES ESPECÍFICOS:
- Zonas sin cobertura visual (puntos ciegos) en estacionamientos y pasillos
- Sistemas de cámaras obsoletos con baja resolución que impiden identificación
- Falta de acceso remoto para verificar instalaciones fuera de horario laboral
- Grabaciones insuficientes que no cubren el período necesario para investigaciones
- Cámaras desalineadas o con imagen borrosa sin mantenimiento periódico`,

  'control-de-accesos': `
SERVICIO: Control de Accesos
ENFOQUE: Biométricos, RFID, torniquetes, portones automáticos, registro digital de visitas.
DIFERENCIADOR vs competencia: Integración total con CCTV y monitoreo centralizado, sistema de alertas en tiempo real.
NO MENCIONAR: guardias de seguridad física, videovigilancia, escoltas, auditoría (otros servicios).
PALABRAS CLAVE OBLIGATORIAS: acceso, biométrico, RFID, registro, visitante, autorización, perímetro, ingreso, credencial, torniquete.
FEATURES ÚNICOS:
- Lectores biométricos de huella dactilar y reconocimiento facial para alta seguridad
- Tarjetas RFID de proximidad con tecnología MIFARE y anticolisión
- Portones automáticos con sensor antipinzamiento y batería de respaldo
- Registro digital de visitantes con foto, documento y motivo de visita
- Torniquetes de acceso peatonal con conteo de flujo y anti-passback
- Integración con sistemas CCTV para registro visual de cada ingreso
- Panel de administración web con reportes de accesos y horarios
- Control de acceso vehicular con lectores de patentes (LPR)
ISSUES ESPECÍFICOS:
- Ingreso de personas no identificadas por accesos sin control automatizado
- Pérdida de llaves o copias no autorizadas que comprometen la seguridad
- Sin registro de quién entra y sale del edificio en cada momento
- Torniquetes y portones averiados que permiten paso libre
- Falta de restricción horaria para empleados y proveedores fuera de turno`,

  'escoltas-privados': `
SERVICIO: Escoltas Privados
ENFOQUE: Protección ejecutiva, traslados de alto valor, evaluación de riesgos, conducción evasiva.
DIFERENCIADOR vs competencia: Personal con formación en protección ejecutiva internacional, coordinación con Carabineros.
NO MENCIONAR: guardias fijos, CCTV, control de accesos, monitoreo remoto (otros servicios).
PALABRAS CLAVE OBLIGATORIAS: escolta, protección ejecutiva, traslado, ruta, riesgo, VIP, diplomático, valor, escolta armado, convoy.
FEATURES ÚNICOS:
- Escoltas con formación en protección ejecutiva certificada internacionalmente
- Evaluación de riesgos y planificación de rutas seguras antes de cada traslado
- Vehículos blindados disponibles para traslados de alto riesgo
- Coordinación con Carabineros para escoltas de alto perfil
- Protocolo de conducción evasiva y técnicas de contra-vigilancia
- Protección en eventos corporativos, viajes de negocio y residencias temporales
- Disponibilidad 24/7 con tiempo de respuesta inferior a 60 minutos
- Informes de seguridad post-servicio con incidencias y recomendaciones
ISSUES ESPECÍFICOS:
- Ejecutivos y directivos sin protección durante traslados y viajes de negocio
- Traslados de valores y mercadería sin escolta que resultan en asaltos
- Eventos corporativos sin plan de seguridad para VIPs y autoridades
- Amenazas a familias de alto perfil sin protocolo de protección personalizado
- Falta de evaluación de riesgos antes de visitas a zonas peligrosas`,

  'monitoreo-24-7': `
SERVICIO: Monitoreo 24/7
ENFOQUE: Centro de control, operadores certificados, verificación de alarmas, coordinación con Carabineros.
DIFERENCIADOR vs competencia: Centro de monitoreo PROPIO (no tercerizado), operadores dedicados por cliente.
NO MENCIONAR: guardias físicos en terreno, cámaras, control de accesos biométrico (otros servicios).
PALABRAS CLAVE OBLIGATORIAS: monitoreo, centro de control, operador, alarma, respuesta, 24/7, verificación, coordinación, alerta, despacho.
FEATURES ÚNICOS:
- Centro de monitoreo propio operado por GuardMan (no tercerizado)
- Operadores certificados asignados por cliente con conocimiento de la instalación
- Verificación visual de alarmas antes de despachar respuesta (evita falsas alarmas)
- Coordinación directa con Carabineros y bomberos con protocolos establecidos
- Monitoreo de alarmas de intrusión, incendio, pánico y emergencia médica
- Reportes mensuales de actividad con métricas de tiempo de respuesta
- Aplicación móvil con alertas push en tiempo real para el cliente
- Protocolo de escalamiento: operador → supervisor → Carabineros en 3 niveles
ISSUES ESPECÍFICOS:
- Alarmas que suenan sin que nadie las verifique, generando desconfianza en el sistema
- Intrusiones detectadas demasiado tarde por falta de monitoreo permanente
- Falsas alarmas repetidas que generan multas municipales y desconfianza
- Sistema de cámaras sin operador que supervise en horarios nocturnos
- Falta de coordinación con Carabineros cuando se detectan intrusos en la propiedad`,

  'seguridad-eventos': `
SERVICIO: Seguridad para Eventos
ENFOQUE: Control de masas, protección VIP, planes de evacuación, logística de seguridad.
DIFERENCIADOR vs competencia: Planos de seguridad con aforo, personal entrenado en control de masas.
NO MENCIONAR: guardias fijos en portería, monitoreo remoto 24/7, auditoría (otros servicios).
PALABRAS CLAVE OBLIGATORIAS: evento, aforo, evacuación, multitud, VIP, recinto, logística, protocolo, masivo, contingencia.
FEATURES ÚNICOS:
- Plan de seguridad personalizado con mapa de riesgo y puntos de control
- Control de aforo con sistemas de conteo y validación de entradas
- Protocolos de evacuación diseñados específicamente para el recinto
- Personal entrenado en manejo de multitudes y primeros auxilios
- Protección VIP con escoltas dedicados para invitados especiales
- Coordinación con municipalidad, Carabineros y servicios de emergencia
- Barreras físicas y señalización de emergencia proporcionadas por GuardMan
- Supervisor de seguridad dedicado durante todo el evento con radio comunicación
ISSUES ESPECÍFICOS:
- Eventos masivos sin control de aforo que generan riesgo de avalancha
- Accesos no controlados que permiten ingreso de personas sin entrada
- Ausencia de plan de evacuación en caso de emergencia o sismo
- Incidentes de violencia sin personal capacitado para contener la situación
- Falta de protección para artistas, expositores o autoridades presentes`,

  'seguridad-industrial': `
SERVICIO: Seguridad Industrial
ENFOQUE: Vigilancia perimetral, control vehicular, protección de mercadería, fábricas y bodegas.
DIFERENCIADOR vs competencia: Guard Pod para perímetros extensos, protocolos específicos para cadenas productivas.
NO MENCIONAR: eventos, escoltas VIP, residencial (otros servicios/sectores).
PALABRAS CLAVE OBLIGATORIAS: industrial, perímetro, bodega, fábrica, maquinaria, carga, logístico, naviero, cadena, productivo.
FEATURES ÚNICOS:
- Vigilancia perimetral 24/7 con guardias y tecnología combinada
- Control de ingreso vehicular con verificación de patentes y manifiesto de carga
- Inspección de salida de mercadería con cruce contra órdenes de despacho
- Protocolos de seguridad para maquinaria pesada y zonas de riesgo
- Guard Pod para perímetros extensos sin necesidad de tendido eléctrico
- Rondas nocturnas con registro GPS y checkpoints electrónicos
- Coordinación con seguros para cumplimiento de pólizas de protección
- Mapa de riesgo industrial con identificación de zonas críticas
ISSUES ESPECÍFICOS:
- Robo de materiales y materias primas en horarios nocturnos y fines de semana
- Ingreso de vehículos no autorizados por accesos perimetrales sin control
- Extracción de mercadería sin documento de despacho que genera pérdidas millonarias
- Falta de protocolos de seguridad para manipulación de maquinaria pesada
- Siniestros sin cobertura de seguros por ausencia de medidas de seguridad auditables`,

  'auditoria-seguridad': `
SERVICIO: Auditoría de Seguridad
ENFOQUE: Diagnóstico profesional, informe de vulnerabilidades, recomendaciones priorizadas.
DIFERENCIADOR vs competencia: Servicio gratuito y sin compromiso, informe técnico con fotografías, seguimiento post-auditoría.
NO MENCIONAR: venta directa de guardias, cámaras, monitoreo (enfoque en diagnóstico objetivo).
PALABRAS CLAVE OBLIGATORIAS: auditoría, diagnóstico, vulnerabilidad, evaluación, informe, recomendación, riesgo, prevención, hallazgo, inspección.
FEATURES ÚNICOS:
- Visita presencial sin costo con inspección completa de la instalación
- Informe técnico con fotografías de hallazgos y nivel de riesgo por punto
- Recomendaciones priorizadas: inmediatas, corto plazo y mediano plazo
- Evaluación de perímetro, accesos, iluminación, cámaras y protocolos existentes
- Benchmarking con estándares de seguridad de la industria
- Cotización opcional de soluciones sin obligación de compra
- Seguimiento post-auditoría a 30 y 90 días para verificar implementaciones
- Informe compatible con requisitos de compañías de seguros
ISSUES ESPECÍFICOS:
- Desconocimiento del estado real de seguridad de la propiedad o empresa
- Inversiones en seguridad sin criterio técnico que no resuelven las vulnerabilidades reales
- Sistemas de cámaras con puntos ciegos o fallas de cobertura no detectadas
- Protocolos de seguridad desactualizados o inexistentes ante nuevas amenazas
- Incidentes de robos repetidos sin haber identificado las causas raíz`,

  'guard-pod': `
SERVICIO: Guard Pod (Unidad Autónoma de Vigilancia)
ENFOQUE: Unidad solar, cámaras PTZ 360°, visión nocturna, 4G, despliegue en 2 horas.
DIFERENCIADOR vs competencia: Diseñado y fabricado en Chile, 15 meses de I+D, no requiere infraestructura eléctrica.
NO MENCIONAR: guardias humanos, turnos, personal físico (es un producto tecnológico autónomo).
PALABRAS CLAVE OBLIGATORIAS: Guard Pod, autónomo, solar, PTZ, 360°, 4G, despliegue, vigilancia remota, móvil, portátil.
FEATURES ÚNICOS:
- Energía solar con panel integrado: 0 consumo eléctrico, 0 cableado requerido
- Cámara PTZ 360° con zoom 30x y visión nocturna hasta 200 metros
- Conectividad 4G LTE con transmisión en tiempo real al centro de monitoreo
- Audio bidireccional para disuasión remota y comunicación con intrusos
- Sensores de movimiento perimetral con alertas diferenciales (humano vs animal)
- Iluminación LED activada por movimiento con efecto disuasorio
- Despliegue en menos de 2 horas sin obra civil ni permisos especiales
- Batería con 72 horas de autonomía sin sol para días nublados
ISSUES ESPECÍFICOS:
- Perímetros extensos sin vigilancia nocturna por costo de guardias permanentes
- Obras en construcción sin energía eléctrica que necesitan vigilancia temporal
- Bodegas y terrenos abandonados vulnerables a intrusión fuera de horario laboral
- Propiedades rurales o industriales sin infraestructura para cámaras convencionales
- Necesidad de vigilancia temporal para eventos o emergencias sin inversión en infraestructura`,
};

export const ZONE_PROMPTS: Record<string, string> = {
  'Oriente': `
ZONA ORIENTE (Las Condes, Vitacura, Lo Barnechea, La Reina):
- Perfil: Residencias de alto nivel, embajadas, centros corporativos Sanhattan.
- Problemas típicos: Robo de vehículos de lujo, ingreso no autorizado a edificios inteligentes, vandalismo en áreas verdes de condominios.
- Tono: Discreto, profesional, orientado a ejecutivos y familias de alto poder adquisitivo.
- Mencionar: Torres corporativas, condominios premium, centros financieros, embajadas.`,

  'Centro': `
ZONA CENTRO (Santiago Centro):
- Perfil: Alto flujo peatonal, comercio tradicional, oficinas gubernamentales, turismo.
- Problemas típicos: Hurto en locales comerciales, carterismo en zonas de alta afluencia, acceso no controlado a edificios públicos.
- Tono: Eficiente, orientado a control de flujos, protección patrimonial.
- Mencionar: Paseo Ahumada, Plaza de Armas, La Alameda, Barrio Lastarria, GAM.`,

  'Norte': `
ZONA NORTE (Huechuraba, Quilicura, Renca, Conchalí, Lampa):
- Perfil: Zona industrial, bodegas, centros logísticos, urbanizaciones nuevas.
- Problemas típicos: Robo de materiales, intrusión perimetral en bodegas, accidentes laborales.
- Tono: Operativo, orientado a seguridad industrial, control vehicular.
- Mencionar: Parques industriales, centros logísticos, bodegas, naves industriales.`,

  'Sur': `
ZONA SUR (La Pintana, Puente Alto):
- Perfil: Zona residencial en crecimiento, comercio local, comunidades.
- Problemas típicos: Delincuencia en pasajes sin vigilancia, robo de especies, microtráfico.
- Tono: Cercano, comunitario, preventivo, accesible.
- Mencionar: Poblaciones, pasajes, comunidades, vecindarios, ferias libres.`,

  'Poniente': `
ZONA PONIENTE (Pudahuel):
- Perfil: Zona mixta industrial-residencial, cercanía al aeropuerto, centros logísticos.
- Problemas típicos: Robo de carga, intrusión en bodegas, inseguridad en poblaciones.
- Tono: Práctico, orientado a resultados, combinando industrial y residencial.
- Mencionar: Aeropuerto, centros logísticos, bodegas, urbanizaciones nuevas.`,

  'Valpo': `
ZONA VALPO (Los Andes, San Felipe):
- Perfil: Ciudades del interior de la V Región, agricultura, industria vitivinícola, turismo.
- Problemas típicos: Robo de cosechas y equipamiento agrícola, intrusión en bodegas vinícolas.
- Tono: Regional, conocedor del territorio, orientado a la comunidad local.
- Mencionar: Viñedos, bodegas, termas, agricultura, turismo de adventure.`,
};
