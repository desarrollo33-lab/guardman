// GuardMan - Serper Agent
// Durable Object using Cloudflare Agent SDK
// Wraps the 3-layer Serper pipeline with durable execution (fibers)
// and scheduled scans

import { Agent } from 'agents';
import type { Env } from '../types';
import { generateQueryPlan, generateAllPlans, getAllServiceSlugs, getAllLocationSlugs } from '../serper/layer1-queries';
import { executeQueryPlan } from '../serper/layer2-executor';
import { classifyAllResults, getClassificationStats } from '../serper/layer3-classifier';
import type { ExecutionResult, ClassificationStats } from '../serper/types';

interface SerperAgentState {
  totalQueries: number;
  totalCreditsUsed: number;
  lastScanAt: string | null;
  scanning: boolean;
  scanProgress: {
    completed: number;
    total: number;
    currentService: string | null;
    currentLocation: string | null;
  } | null;
}

export class GMSerperSvc extends Agent<Env, SerperAgentState> {
  // env is set by Agent base class but not exposed in types
  declare env: Env;

  initialState: SerperAgentState = {
    totalQueries: 0,
    totalCreditsUsed: 0,
    lastScanAt: null,
    scanning: false,
    scanProgress: null,
  };

  async onStart() {
    // Full scan every Sunday at 3am UTC
    await this.schedule('0 3 * * 0', 'fullScan', {});
    console.log('[SerperAgent] Started, scheduled weekly full scan');
  }

  // ===== PUBLIC RPC METHODS =====

  /**
   * Execute pipeline for a single service × location combo
   */
  async scanCombo(serviceSlug: string, locationSlug: string): Promise<{
    results: ExecutionResult[];
    stats: ClassificationStats;
  }> {
    const plan = generateQueryPlan(serviceSlug, locationSlug);
    const results = await executeQueryPlan(this.env, plan.queries);
    const stats = await classifyAllResults(this.env);

    this.setState({
      ...this.state,
      totalQueries: this.state.totalQueries + results.filter(r => r.status === 'completed').length,
      totalCreditsUsed: this.state.totalCreditsUsed + results.reduce((s, r) => s + r.credits_used, 0),
      lastScanAt: new Date().toISOString(),
    });

    return { results, stats };
  }

  /**
   * Full pipeline for all combos — runs inside a fiber for durability
   */
  async fullScan(): Promise<{ totalQueries: number; totalCredits: number }> {
    return new Promise((resolve, reject) => {
      void this.runFiber('full-scan', async (ctx) => {
        this.setState({ ...this.state, scanning: true, scanProgress: { completed: 0, total: 0, currentService: null, currentLocation: null } });

        const serviceSlugs = getAllServiceSlugs();
        const locationSlugs = getAllLocationSlugs();
        const allPlans = generateAllPlans(serviceSlugs, locationSlugs);

        let totalQueries = 0;
        let totalCredits = 0;
        let completed = 0;
        const total = allPlans.length;

        this.setState({ ...this.state, scanProgress: { completed: 0, total, currentService: null, currentLocation: null } });

        for (const plan of allPlans) {
          // Checkpoint after each combo
          ctx.stash({ completed, total, totalQueries, totalCredits, currentService: plan.service_slug, currentLocation: plan.location_slug });

          this.setState({
            ...this.state,
            scanProgress: { completed, total, currentService: plan.service_name, currentLocation: plan.location_name },
          });

          try {
            const results = await executeQueryPlan(this.env, plan.queries);
            totalQueries += results.filter(r => r.status === 'completed').length;
            totalCredits += results.reduce((s, r) => s + r.credits_used, 0);

            // Broadcast progress via WebSocket
            this.broadcast(JSON.stringify({
              type: 'scan-progress',
              data: {
                service: plan.service_name,
                location: plan.location_name,
                completed: completed + 1,
                total,
                queries: results.length,
                credits: results.reduce((s, r) => s + r.credits_used, 0),
                errors: results.filter(r => r.status === 'failed').length,
              },
            }));
          } catch (e) {
            console.error(`[SerperAgent] Error scanning ${plan.service_slug}/${plan.location_slug}:`, e);
          }
          completed++;
        }

        // Final classification of all results
        await classifyAllResults(this.env);

        this.setState({
          ...this.state,
          totalQueries: this.state.totalQueries + totalQueries,
          totalCreditsUsed: this.state.totalCreditsUsed + totalCredits,
          lastScanAt: new Date().toISOString(),
          scanning: false,
          scanProgress: { completed: total, total, currentService: null, currentLocation: null },
        });

        this.broadcast(JSON.stringify({
          type: 'scan-complete',
          data: { totalQueries, totalCredits, totalCombos: total },
        }));

        resolve({ totalQueries, totalCredits });
      });
    });
  }

  /**
   * Get research context for the Content Agent
   * Returns competitor data, content gaps, queries, and PAA questions
   */
  async getResearchContext(serviceSlug: string, locationSlug?: string): Promise<{
    topCompetitors: any[];
    contentGaps: any[];
    serperQueries: any[];
    paaQuestions: any[];
  }> {
    const [compResults, gapResults, queryResults, paaResults] = await Promise.all([
      this.env.DB.prepare(
        `SELECT domain, COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos
         FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id
         WHERE sq.service_slug = ? AND sr.site_type = 'direct_competitor' AND sr.position <= 10
         GROUP BY domain ORDER BY appearances DESC LIMIT 8`
      ).bind(serviceSlug).all().catch(() => ({ results: [] })),
      this.env.DB.prepare(
        `SELECT sq.query_text FROM serper_queries sq
         LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = 'own'
         WHERE sq.service_slug = ? AND sq.status = 'completed' AND (sr.position IS NULL OR sr.position > 5)
         GROUP BY sq.query_text LIMIT 15`
      ).bind(serviceSlug).all().catch(() => ({ results: [] })),
      this.env.DB.prepare(
        `SELECT DISTINCT query_text FROM serper_queries WHERE service_slug = ? AND status = 'completed' LIMIT 10`
      ).bind(serviceSlug).all().catch(() => ({ results: [] })),
      this.env.DB.prepare(
        `SELECT DISTINCT sr.title as question FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id
         WHERE sq.service_slug = ? AND sr.result_type = 'paa' LIMIT 10`
      ).bind(serviceSlug).all().catch(() => ({ results: [] })),
    ]);

    return {
      topCompetitors: (compResults.results as any[]) || [],
      contentGaps: (gapResults.results as any[]) || [],
      serperQueries: (queryResults.results as any[]) || [],
      paaQuestions: (paaResults.results as any[]) || [],
    };
  }

  /**
   * Get current agent state
   */
  async getStatus(): Promise<SerperAgentState> {
    return this.state;
  }

  /**
   * Get classification stats (read-only, no writes)
   */
  async getStats(): Promise<ClassificationStats> {
    return getClassificationStats(this.env);
  }

  // ===== SCHEDULED METHODS =====

  /**
   * Full scan triggered by cron (Sunday 3am)
   */
  async fullScanCron() {
    console.log('[SerperAgent] Running scheduled full scan...');
    await this.fullScan();
  }

  // ===== FIBER RECOVERY =====

  async onFiberRecovered(ctx: any) {
    if (ctx.name === 'full-scan' && ctx.snapshot) {
      const snap = ctx.snapshot;
      console.log(`[SerperAgent] Recovering full scan: ${snap.completed}/${snap.total} combos done, last was ${snap.currentService}/${snap.currentLocation}`);
      // The fiber automatically resumes from the last stash point
      // The loop will continue from the next combo
    }
  }

  // ===== WEBSOCKET =====

  async onConnect(client: WebSocket) {
    client.send(JSON.stringify({ type: 'state', data: this.state }));
  }

  async onMessage(client: WebSocket, message: string) {
    try {
      const msg = JSON.parse(message);
      if (msg.type === 'getStatus') {
        client.send(JSON.stringify({ type: 'state', data: this.state }));
      } else if (msg.type === 'getStats') {
        const stats = await this.getStats();
        client.send(JSON.stringify({ type: 'stats', data: stats }));
      }
    } catch { /* ignore invalid messages */ }
  }
}

// ===== SQLite-backed Serper Agent =====
// This is a complete copy of the Serper Agent functionality,
// but as a new class that was created with new_sqlite_classes migration.
// The Agent SDK base class requires SQLite storage for fibers, scheduling, etc.

export class GMSerperSqlite extends Agent<Env, SerperAgentState> {
  declare env: Env;

  initialState: SerperAgentState = {
    totalQueries: 0,
    totalCreditsUsed: 0,
    lastScanAt: null,
    scanning: false,
    scanProgress: null,
  };

  async onStart() {
    await this.schedule('0 3 * * 0', 'fullScan', {});
    this.sql`CREATE TABLE IF NOT EXISTS serper_cache (
      service TEXT,
      location TEXT,
      data JSON,
      updated_at TEXT,
      PRIMARY KEY (service, location)
    )`;
    console.log('[SerperAgent] Started with SQLite + serper_cache, scheduled weekly full scan');
  }

  async syncSerperCache() {
    const data = await this.env.DB.prepare(
      'SELECT service_slug, location_slug, JSON_GROUP_ARRAY(JSON(title, snippet, link, position)) as data FROM serper_results GROUP BY service_slug, location_slug'
    ).all();
    for (const row of data.results as any[]) {
      this.sql`INSERT OR REPLACE INTO serper_cache (service, location, data, updated_at) VALUES (${row.service_slug}, ${row.location_slug}, ${row.data}, CURRENT_TIMESTAMP)`;
    }
  }

  getCachedSerper(service: string, location: string) {
    return this.sql`SELECT data FROM serper_cache WHERE service = ${service} AND location = ${location}`;
  }

  async scanCombo(serviceSlug: string, locationSlug: string) {
    const plan = generateQueryPlan(serviceSlug, locationSlug);
    const results = await executeQueryPlan(this.env, plan.queries);
    const stats = await classifyAllResults(this.env);
    this.setState({
      ...this.state,
      totalQueries: this.state.totalQueries + results.filter(r => r.status === 'completed').length,
      totalCreditsUsed: this.state.totalCreditsUsed + results.reduce((s, r) => s + r.credits_used, 0),
      lastScanAt: new Date().toISOString(),
    });
    return { results, stats };
  }

  async fullScan(): Promise<{ totalQueries: number; totalCredits: number }> {
    return new Promise((resolve, reject) => {
      void this.runFiber('full-scan', async (ctx) => {
        this.setState({ ...this.state, scanning: true, scanProgress: { completed: 0, total: 0, currentService: null, currentLocation: null } });
        const serviceSlugs = getAllServiceSlugs();
        const locationSlugs = getAllLocationSlugs();
        const allPlans = generateAllPlans(serviceSlugs, locationSlugs);
        let totalQueries = 0;
        let totalCredits = 0;
        let completed = 0;
        const total = allPlans.length;
        for (const plan of allPlans) {
          ctx.stash({ completed, total, totalQueries, totalCredits });
          this.setState({ ...this.state, scanProgress: { completed, total, currentService: plan.service_name, currentLocation: plan.location_name } });
          try {
            const results = await executeQueryPlan(this.env, plan.queries);
            totalQueries += results.filter(r => r.status === 'completed').length;
            totalCredits += results.reduce((s, r) => s + r.credits_used, 0);
            this.broadcast(JSON.stringify({ type: 'scan-progress', data: { service: plan.service_name, location: plan.location_name, completed: completed + 1, total, queries: results.length } }));
          } catch (e) {
            console.error(`[SerperAgent] Error: ${plan.service_slug}/${plan.location_slug}:`, e);
          }
          completed++;
        }
        await classifyAllResults(this.env);
        this.setState({ ...this.state, totalQueries: this.state.totalQueries + totalQueries, totalCreditsUsed: this.state.totalCreditsUsed + totalCredits, lastScanAt: new Date().toISOString(), scanning: false, scanProgress: { completed: total, total, currentService: null, currentLocation: null } });
        resolve({ totalQueries, totalCredits });
      });
    });
  }

  async getResearchContext(serviceSlug: string, locationSlug?: string) {
    const [compResults, gapResults, queryResults, paaResults] = await Promise.all([
      this.env.DB.prepare('SELECT domain, COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sq.service_slug = ? AND sr.site_type = \'direct_competitor\' AND sr.position <= 10 GROUP BY domain ORDER BY appearances DESC LIMIT 8').bind(serviceSlug).all().catch(() => ({ results: [] })),
      this.env.DB.prepare('SELECT sq.query_text FROM serper_queries sq LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = \'own\' WHERE sq.service_slug = ? AND sq.status = \'completed\' AND (sr.position IS NULL OR sr.position > 5) GROUP BY sq.query_text LIMIT 15').bind(serviceSlug).all().catch(() => ({ results: [] })),
      this.env.DB.prepare('SELECT DISTINCT query_text FROM serper_queries WHERE service_slug = ? AND status = \'completed\' LIMIT 10').bind(serviceSlug).all().catch(() => ({ results: [] })),
      this.env.DB.prepare('SELECT DISTINCT sr.title as question FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id WHERE sq.service_slug = ? AND sr.result_type = \'paa\' LIMIT 10').bind(serviceSlug).all().catch(() => ({ results: [] })),
    ]);
    return {
      topCompetitors: (compResults.results as any[]) || [],
      contentGaps: (gapResults.results as any[]) || [],
      serperQueries: (queryResults.results as any[]) || [],
      paaQuestions: (paaResults.results as any[]) || [],
    };
  }

  async getStatus(): Promise<SerperAgentState> { return this.state; }
  async getStats() { return getClassificationStats(this.env); }

  async onFiberRecovered(ctx: any) {
    if (ctx.name === 'full-scan') console.log(`[SerperAgent] Recovering full scan: ${JSON.stringify(ctx.snapshot)}`);
  }

  async onConnect(client: WebSocket) {
    client.send(JSON.stringify({ type: 'state', data: this.state }));
  }

  async onMessage(client: WebSocket, message: string) {
    try {
      const msg = JSON.parse(message);
      if (msg.type === 'getStatus') client.send(JSON.stringify({ type: 'state', data: this.state }));
    } catch {}
  }
}
