// GuardMan v5.2 — SEO Intel Workflow
// Analyzes existing Serper data (ZERO API cost) and produces actionable intelligence
// Chains from SerperScanWorkflow or triggered manually
// Output: intel_snapshots row + upserted intel_competitors + content_proposals

import { WorkflowEntrypoint, WorkflowStep, WorkflowEvent } from 'cloudflare:workers';
import type { Env, PositionSummary, CompetitorProfile, ContentGap, KeywordIntelligence, ContentProposal, IntelSnapshotSummary } from '../types';

interface SEOIntelParams {
  trigger: 'manual' | 'post-scan';
}

export class SEOIntelWorkflow extends WorkflowEntrypoint<Env, SEOIntelParams> {
  async run(event: WorkflowEvent<SEOIntelParams>, step: WorkflowStep) {
    const { trigger } = event.payload;

    // Step 1: Aggregate positions for all combos
    const positionMap: PositionSummary[] = await step.do('aggregate-positions', async () => {
      const { results } = await this.env.DB.prepare(`
        SELECT
          sq.service_slug,
          sq.location_slug,
          COUNT(DISTINCT sq.id) as total_queries,
          COUNT(DISTINCT CASE WHEN sr.site_type = 'own' THEN sq.id END) as own_queries,
          MIN(CASE WHEN sr.site_type = 'own' THEN sr.position ELSE 999 END) as best_own_pos,
          AVG(CASE WHEN sr.site_type = 'own' THEN sr.position END) as avg_own_pos,
          COUNT(DISTINCT CASE WHEN sr.site_type = 'direct_competitor' THEN sr.domain END) as direct_comp,
          COUNT(DISTINCT CASE WHEN sr.site_type = 'indirect_competitor' THEN sr.domain END) as indirect_comp,
          COUNT(DISTINCT CASE WHEN sr.site_type = 'directory' THEN sr.domain END) as dirs,
          SUM(CASE WHEN sr.site_type = 'own' AND sr.position <= 3 THEN 1 ELSE 0 END) as top3,
          SUM(CASE WHEN sr.site_type = 'own' AND sr.position <= 10 THEN 1 ELSE 0 END) as top10
        FROM serper_queries sq
        LEFT JOIN serper_results sr ON sq.id = sr.query_id
        WHERE sq.status = 'completed'
        GROUP BY sq.service_slug, sq.location_slug
      `).all();

      return (results as any[]).map(r => ({
        serviceSlug: r.service_slug,
        locationSlug: r.location_slug,
        totalQueries: r.total_queries || 0,
        ownQueries: r.own_queries || 0,
        hasOwnPresence: (r.own_queries || 0) > 0,
        bestOwnPosition: r.best_own_pos || 999,
        avgOwnPosition: r.avg_own_pos ? Math.round(r.avg_own_pos * 10) / 10 : null,
        directCompetitors: r.direct_comp || 0,
        indirectCompetitors: r.indirect_comp || 0,
        directories: r.dirs || 0,
        top3Own: r.top3 || 0,
        top10Own: r.top10 || 0,
        competitionDensity: (r.direct_comp || 0) + (r.indirect_comp || 0) + (r.dirs || 0),
      }));
    });

    // Step 2: Profile competitors from serper_results
    const competitorProfiles: CompetitorProfile[] = await step.do('profile-competitors', {
      retries: { limit: 2, delay: '5 seconds' },
    }, async () => {
      const { results } = await this.env.DB.prepare(`
        SELECT
          sr.domain,
          sr.site_type,
          COUNT(DISTINCT sq.service_slug) as services,
          COUNT(DISTINCT sq.location_slug) as locations,
          COUNT(*) as appearances,
          ROUND(AVG(sr.position), 1) as avg_pos,
          MIN(sr.position) as best_pos
        FROM serper_results sr
        JOIN serper_queries sq ON sr.query_id = sq.id
        WHERE sr.site_type IN ('direct_competitor', 'indirect_competitor')
        GROUP BY sr.domain, sr.site_type
        ORDER BY appearances DESC
      `).all();

      const profiles: CompetitorProfile[] = [];

      for (const r of (results as any[])) {
        // Fetch titles/snippets separately for this domain
        let text = '';
        try {
          const { results: snippets } = await this.env.DB.prepare(`
            SELECT DISTINCT sr.title, sr.snippet FROM serper_results sr
            JOIN serper_queries sq ON sr.query_id = sq.id
            WHERE sr.domain = ? AND sr.site_type = ?
            LIMIT 10
          `).bind(r.domain, r.site_type).all();
          text = (snippets as any[]).map(s => `${s.title || ''} ${s.snippet || ''}`).join(' ').toLowerCase();
        } catch { /* non-critical */ }

        // Detect weaknesses
        const weaknesses: string[] = [];
        if (!text.includes('os-10')) weaknesses.push('No menciona certificación OS-10');
        if (!text.includes('24/7')) weaknesses.push('No menciona cobertura 24/7');
        if (!text.includes('cotizar') && !text.includes('cotización')) weaknesses.push('Sin CTA de cotización');
        if (text.includes('mejor precio') || text.includes('barato')) weaknesses.push('Estrategia de precios bajos');

        // Detect strengths
        const strengths: string[] = [];
        if (text.includes('os-10')) strengths.push('Menciona OS-10');
        if (text.includes('24/7')) strengths.push('Presencia 24/7');
        if (text.includes('cotizar') || text.includes('cotización')) strengths.push('CTA cotización');
        if (text.includes('certificado') || text.includes('certificación')) strengths.push('Destaca certificaciones');

        // Threat level
        let threatLevel: CompetitorProfile['threatLevel'] = 'low';
        if ((r.appearances || 0) > 50 && (r.avg_pos || 999) <= 4) threatLevel = 'critical';
        else if ((r.appearances || 0) > 20) threatLevel = 'high';
        else if ((r.appearances || 0) > 5) threatLevel = 'medium';

        // Pricing strategy
        let pricingStrategy: CompetitorProfile['pricingStrategy'] = 'unknown';
        if (text.includes('mejor precio') || text.includes('económico') || text.includes('barato')) pricingStrategy = 'low_cost';
        else if (text.includes('premium') || text.includes('exclusivo')) pricingStrategy = 'premium';
        else if (text.includes('precio') || text.includes('$') || text.includes('cotizar')) pricingStrategy = 'visible';

        profiles.push({
          domain: r.domain,
          type: r.site_type,
          services: r.services || 0,
          locations: r.locations || 0,
          appearances: r.appearances || 0,
          avgPosition: r.avg_pos || 0,
          bestPosition: r.best_pos || 0,
          strengths,
          weaknesses,
          threatLevel,
          pricingStrategy,
        });

        // Upsert to intel_competitors
        try {
          await this.env.DB.prepare(`
            INSERT INTO intel_competitors (domain, site_type, appearances, avg_position, best_position,
              services_count, locations_count, threat_level, pricing_strategy, strengths, weaknesses, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
            ON CONFLICT(domain) DO UPDATE SET
              appearances = excluded.appearances,
              avg_position = excluded.avg_position,
              best_position = excluded.best_position,
              services_count = excluded.services_count,
              locations_count = excluded.locations_count,
              threat_level = excluded.threat_level,
              pricing_strategy = excluded.pricing_strategy,
              strengths = excluded.strengths,
              weaknesses = excluded.weaknesses,
              updated_at = datetime('now')
          `).bind(
            r.domain, r.site_type, r.appearances || 0, r.avg_pos || 0, r.best_pos || 0,
            r.services || 0, r.locations || 0, threatLevel, pricingStrategy,
            JSON.stringify(strengths), JSON.stringify(weaknesses)
          ).run();
        } catch {
          // intel_competitors may not have all columns — non-critical
        }
      }

      return profiles;
    });

    // Step 3: Find content gaps (combos with demand but no presence)
    const contentGaps: ContentGap[] = await step.do('find-content-gaps', async () => {
      const { results } = await this.env.DB.prepare(`
        SELECT
          sq.service_slug,
          sq.location_slug,
          COUNT(DISTINCT sq.query_text) as search_demand,
          COUNT(DISTINCT sr.id) as total_results,
          COUNT(DISTINCT CASE WHEN sr.site_type = 'direct_competitor' THEN sr.domain END) +
            COUNT(DISTINCT CASE WHEN sr.site_type = 'indirect_competitor' THEN sr.domain END) as competitors
        FROM serper_queries sq
        LEFT JOIN serper_results sr ON sq.id = sr.query_id
        WHERE sq.status = 'completed'
        GROUP BY sq.service_slug, sq.location_slug
        ORDER BY search_demand DESC
      `).all();

      const gaps: ContentGap[] = [];

      for (const r of (results as any[])) {
        // Check existing content
        let contentStatus: string | null = null;
        let wordCount = 0;
        let contentVersion = 0;
        let contentScore: number | null = null;

        // Fetch sample queries for this combo
        let sampleQueries = '';
        try {
          const { results: qr } = await this.env.DB.prepare(
            "SELECT DISTINCT query_text FROM serper_queries WHERE service_slug = ? AND location_slug = ? AND status = 'completed' LIMIT 5"
          ).bind(r.service_slug, r.location_slug).all();
          sampleQueries = (qr as any[]).map(q => q.query_text).join(' | ');
        } catch { /* non-critical */ }

        try {
          const existing = await this.env.DB.prepare(
            'SELECT status, word_count, version, score FROM combo_content WHERE service_slug = ? AND location_slug = ?'
          ).bind(r.service_slug, r.location_slug).first();

          if (existing) {
            contentStatus = (existing as any).status;
            wordCount = (existing as any).word_count || 0;
            contentVersion = (existing as any).version || 0;
            contentScore = (existing as any).score || null;
          }
        } catch { /* combo_content may not have score column */ }

        // Check publish queue
        try {
          const published = await this.env.DB.prepare(
            "SELECT status FROM publish_queue WHERE entity_slug = ? AND status = 'published'"
          ).bind(`${r.service_slug}-${r.location_slug}`).first();
          if (published) contentStatus = 'published';
        } catch { /* non-critical */ }

        const demand = r.search_demand || 0;
        const comp = r.competitors || 0;
        const priority = demand * (comp + 1);

        let action: ContentGap['action'] = 'generate_new';
        if (contentStatus === 'published') action = 'publish_existing';
        else if (contentStatus === 'draft' || contentStatus === 'approved') action = 'review_draft';

        gaps.push({
          serviceSlug: r.service_slug,
          locationSlug: r.location_slug,
          searchDemand: demand,
          totalResults: r.total_results || 0,
          competitors: comp,
          sampleQueries,
          contentStatus,
          wordCount,
          contentVersion,
          contentScore,
          priority,
          action,
        });
      }

      return gaps;
    });

    // Step 4: Extract keyword intelligence
    const keywordIntel: KeywordIntelligence = await step.do('extract-keyword-intelligence', async () => {
      // Total unique queries
      const totalRow = await this.env.DB.prepare(
        "SELECT COUNT(DISTINCT query_text) as total FROM serper_queries WHERE status = 'completed'"
      ).first();
      const totalUniqueQueries = (totalRow as any)?.total || 0;

      // Top patterns (bigrams)
      const { results: queryRows } = await this.env.DB.prepare(
        "SELECT query_text FROM serper_queries WHERE status = 'completed'"
      ).all();

      const bigramMap = new Map<string, number>();
      for (const row of (queryRows as any[])) {
        const words = (row.query_text || '').toLowerCase().split(/\s+/).filter(w => w.length > 3);
        for (let i = 0; i < words.length - 1; i++) {
          const bigram = `${words[i]} ${words[i + 1]}`;
          bigramMap.set(bigram, (bigramMap.get(bigram) || 0) + 1);
        }
      }
      const topPatterns = [...bigramMap.entries()]
        .filter(([, freq]) => freq >= 3)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 20)
        .map(([pattern, frequency]) => ({ pattern, frequency }));

      // Quick wins: queries where GuardMan is between positions 4-15
      const { results: quickWinRows } = await this.env.DB.prepare(`
        SELECT sq.query_text, sr.position, sq.service_slug, sq.location_slug
        FROM serper_results sr
        JOIN serper_queries sq ON sr.query_id = sq.id
        WHERE sr.site_type = 'own' AND sr.position BETWEEN 4 AND 15
        ORDER BY sr.position ASC
        LIMIT 30
      `).all();

      const quickWinQueries = (quickWinRows as any[]).map(r => ({
        query: r.query_text,
        position: r.position,
        service: r.service_slug,
        location: r.location_slug,
      }));

      // Zero presence queries
      const zeroRow = await this.env.DB.prepare(`
        SELECT COUNT(DISTINCT sq.id) as cnt
        FROM serper_queries sq
        LEFT JOIN serper_results sr ON sq.id = sr.query_id AND sr.site_type = 'own'
        WHERE sq.status = 'completed' AND sr.id IS NULL
      `).first();
      const queriesWithZeroPresence = (zeroRow as any)?.cnt || 0;

      // Top 3 and Top 10
      const top3Row = await this.env.DB.prepare(`
        SELECT COUNT(DISTINCT sq.id) as cnt FROM serper_queries sq
        JOIN serper_results sr ON sq.id = sr.query_id
        WHERE sq.status = 'completed' AND sr.site_type = 'own' AND sr.position <= 3
      `).first();
      const top10Row = await this.env.DB.prepare(`
        SELECT COUNT(DISTINCT sq.id) as cnt FROM serper_queries sq
        JOIN serper_results sr ON sq.id = sr.query_id
        WHERE sq.status = 'completed' AND sr.site_type = 'own' AND sr.position <= 10
      `).first();

      return {
        totalUniqueQueries,
        topPatterns,
        quickWinQueries,
        queriesWithZeroPresence,
        queriesInTop3: (top3Row as any)?.cnt || 0,
        queriesInTop10: (top10Row as any)?.cnt || 0,
      };
    });

    // Step 5: Generate content proposals
    const proposals: ContentProposal[] = await step.do('generate-proposals', async () => {
      const result: ContentProposal[] = [];

      // URGENT: top 10 gaps with NO content, sorted by priority
      const urgent = contentGaps
        .filter(g => !g.contentStatus || g.contentStatus === null)
        .sort((a, b) => b.priority - a.priority)
        .slice(0, 10);

      for (const gap of urgent) {
        // Find top competitors for this combo
        const topComps = competitorProfiles
          .filter(c => {
            // Check if this competitor appears in this combo's results
            return true; // We'll use the general competitor data
          })
          .slice(0, 5)
          .map(c => c.domain);

        const compWeaknesses = competitorProfiles
          .filter(c => topComps.includes(c.domain))
          .flatMap(c => c.weaknesses)
          .filter((v, i, a) => a.indexOf(v) === i)
          .slice(0, 5);

        result.push({
          serviceSlug: gap.serviceSlug,
          locationSlug: gap.locationSlug,
          priority: 'urgent',
          reason: `${gap.searchDemand} queries, ${gap.competitors} competidores, sin contenido propio`,
          topCompetitors: topComps,
          competitorWeaknesses: compWeaknesses,
          targetKeywords: gap.sampleQueries.split(' | ').slice(0, 5),
          demandScore: gap.priority,
          action: 'generate_new',
        });
      }

      // IMPORTANT: drafts with low score
      const important = contentGaps
        .filter(g => g.contentStatus === 'draft' && (g.contentScore || 0) < 80)
        .sort((a, b) => (a.contentScore || 0) - (b.contentScore || 0))
        .slice(0, 5);

      for (const gap of important) {
        const topComps = competitorProfiles.slice(0, 3).map(c => c.domain);
        const compWeaknesses = competitorProfiles
          .filter(c => topComps.includes(c.domain))
          .flatMap(c => c.weaknesses)
          .filter((v, i, a) => a.indexOf(v) === i)
          .slice(0, 5);

        result.push({
          serviceSlug: gap.serviceSlug,
          locationSlug: gap.locationSlug,
          priority: 'important',
          reason: `Draft con score ${g.contentScore || 'N/A'}, necesita mejora`,
          topCompetitors: topComps,
          competitorWeaknesses: compWeaknesses,
          targetKeywords: gap.sampleQueries.split(' | ').slice(0, 5),
          demandScore: gap.priority,
          action: 'review_draft',
        });
      }

      return result;
    });

    // Step 6: Save snapshot to D1
    const snapshotId = await step.do('save-snapshot', async () => {
      const id = `intel-${Date.now()}-${trigger}`;

      const summary: IntelSnapshotSummary = {
        totalCombosAnalyzed: positionMap.length,
        combosWithPresence: positionMap.filter(p => p.hasOwnPresence).length,
        combosWithoutPresence: positionMap.filter(p => !p.hasOwnPresence).length,
        totalCompetitors: competitorProfiles.length,
        criticalCompetitors: competitorProfiles.filter(c => c.threatLevel === 'critical').length,
        contentGapsCount: contentGaps.length,
        gapsWithNoContent: contentGaps.filter(g => !g.contentStatus).length,
        gapsDraftOnly: contentGaps.filter(g => g.contentStatus === 'draft').length,
        urgentProposals: proposals.filter(p => p.priority === 'urgent').length,
      };

      await this.env.DB.prepare(`
        INSERT INTO intel_snapshots (id, trigger_type, position_map, competitor_profiles,
          content_gaps, keyword_intelligence, content_proposals, summary)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        id,
        trigger,
        JSON.stringify(positionMap.slice(0, 50)), // Limit to top 50
        JSON.stringify(competitorProfiles),
        JSON.stringify(contentGaps.slice(0, 50)),
        JSON.stringify(keywordIntel),
        JSON.stringify(proposals),
        JSON.stringify(summary)
      ).run();

      return id;
    });

    return {
      snapshot_id: snapshotId,
      trigger,
      summary: {
        combosAnalyzed: positionMap.length,
        competitorsProfiled: competitorProfiles.length,
        contentGapsFound: contentGaps.filter(g => !g.contentStatus).length,
        proposalsGenerated: proposals.length,
        keywordsAnalyzed: keywordIntel.totalUniqueQueries,
        quickWins: keywordIntel.quickWinQueries.length,
      },
      proposals_count: proposals.length,
    };
  }
}
