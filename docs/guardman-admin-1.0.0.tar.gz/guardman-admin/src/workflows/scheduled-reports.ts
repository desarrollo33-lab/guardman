// GuardMan v1 — Scheduled Reports Workflow
// Generates daily/weekly SEO reports with coverage, scores, and trends
// Runs on cron schedule: daily at 9 AM and weekly on Mondays

import { WorkflowEntrypoint, WorkflowStep, WorkflowEvent } from 'cloudflare:workers';
import type { Env } from '../types';

interface ScheduledReportParams {
  type: 'daily' | 'weekly' | 'on_demand';
  recipient_email?: string;
  force_regenerate?: boolean;
}

export class ScheduledReportsWorkflow extends WorkflowEntrypoint<Env, ScheduledReportParams> {
  async run(event: WorkflowEvent<ScheduledReportParams>, step: WorkflowStep) {
    const { type = 'daily', recipient_email = 'admin@guardman.cl', force_regenerate = false } = event.payload;
    const reportDate = new Date().toISOString().split('T')[0];
    const reportId = `report-${type}-${reportDate}-${Date.now()}`;

    // Step 1: Gather coverage stats
    const coverageStats = await step.do('gather-coverage-stats', async () => {
      const [services, locations, combos, comboContent, qualityScores, publishQueue] = await Promise.all([
        this.env.DB.prepare('SELECT COUNT(*) as n FROM services').first(),
        this.env.DB.prepare('SELECT COUNT(*) as n FROM locations').first(),
        this.env.DB.prepare('SELECT COUNT(*) as n FROM combos').first(),
        this.env.DB.prepare('SELECT COUNT(*) as n FROM combo_content').first(),
        this.env.DB.prepare('SELECT COUNT(*) as n, AVG(overall_score) as avg_score FROM quality_scores').first(),
        this.env.DB.prepare('SELECT COUNT(*) as n FROM publish_queue WHERE status = ?').bind('approved').first(),
      ]);

      return {
        services: (services as any)?.n || 0,
        locations: (locations as any)?.n || 0,
        combos_total: (comboContent as any)?.n || 0,
        combos_possible: ((services as any)?.n || 0) * ((locations as any)?.n || 0),
        quality_scores: (qualityScores as any)?.n || 0,
        avg_score: Math.round((qualityScores as any)?.avg_score || 0),
        publish_queue: (publishQueue as any)?.n || 0,
      };
    });

    // Step 2: Get top performers and gaps
    const topPerformers = await step.do('get-top-performers', async () => {
      const results = await this.env.DB.prepare(`
        SELECT entity_slug, overall_score, seo_score, content_score 
        FROM quality_scores 
        ORDER BY overall_score DESC 
        LIMIT 5
      `).all().catch(() => ({ results: [] }));
      return results.results;
    });

    const coverageGaps = await step.do('get-coverage-gaps', async () => {
      const results = await this.env.DB.prepare(`
        SELECT s.slug, s.name, 
               (SELECT COUNT(*) FROM combo_content cc WHERE cc.service_slug = s.slug) as combos_with_content,
               (SELECT COUNT(*) FROM locations) as total_locations
        FROM services s
        ORDER BY combos_with_content ASC
        LIMIT 5
      `).all().catch(() => ({ results: [] }));
      return results.results;
    });

    // Step 3: Get low-scoring content needing regeneration
    const lowScores = await step.do('get-low-scores', async () => {
      const results = await this.env.DB.prepare(`
        SELECT entity_slug, overall_score 
        FROM quality_scores 
        WHERE overall_score < 75
        ORDER BY overall_score ASC
        LIMIT 10
      `).all().catch(() => ({ results: [] }));
      return results.results;
    });

    // Step 4: Generate markdown report
    const reportMarkdown = await step.do('generate-report', async () => {
      const coveragePct = coverageStats.combos_possible > 0 
        ? Math.round((coverageStats.combos_total / coverageStats.combos_possible) * 100) 
        : 0;

      return `# 📊 Reporte SEO GuardMan — ${type === 'daily' ? 'Diario' : 'Semanal'}

**Fecha:** ${reportDate}
**ID:** ${reportId}

## 📈 Resumen General

| Métrica | Valor |
|---------|-------|
| Servicios | ${coverageStats.services} |
| Comunas | ${coverageStats.locations} |
| Contenido Generado | ${coverageStats.combos_total} |
| Coverage | ${coveragePct}% |
| Scores Calculados | ${coverageStats.quality_scores} |
| Score Promedio | ${coverageStats.avg_score} |
| Pendientes de Publicar | ${coverageStats.publish_queue} |

## 🏆 Top Performers

${topPerformers.length > 0 ? topPerformers.map((s: any) => 
  `- **${s.entity_slug}**: SEO ${s.seo_score}/100, Contenido ${s.content_score}/100`
).join('\n') : '- Sin datos aún'}

## 📉 Contenido con Low Score (< 75)

${lowScores.length > 0 ? lowScores.map((s: any) => 
  `- **${s.entity_slug}**: ${s.overall_score}/100 ⚠️`
).join('\n') : '- Todo el contenido tiene score ≥ 75'}

## 🎯 Gaps de Coverage (Servicios con menos contenido)

${coverageGaps.length > 0 ? coverageGaps.map((s: any) => {
  const pct = s.total_locations > 0 ? Math.round((s.combos_with_content / s.total_locations) * 100) : 0;
  return `- **${s.name}**: ${s.combos_with_content}/${s.total_locations} comunas (${pct}%)`;
}).join('\n') : '- Todos los servicios tienen coverage completo'}

## 💡 Recomendaciones

${lowScores.length > 0 ? `⚠️ **Regenerar ${lowScores.length} contenido(s) con score bajo**` : '✅ **Todo el contenido tiene score aceptable**'}

${coveragePct < 50 ? `📝 **Generar más contenido** — Coverage está bajo (${coveragePct}%)` : '✅ **Coverage saludable**'}

---
*Reporte generado automáticamente por GuardMan Admin*
`;
    });

    // Step 5: Save report to DB
    const savedReport = await step.do('save-report', async () => {
      await this.env.DB.prepare(`
        CREATE TABLE IF NOT EXISTS scheduled_reports (
          id TEXT PRIMARY KEY,
          type TEXT NOT NULL,
          report_date TEXT NOT NULL,
          coverage_stats TEXT NOT NULL,
          top_performers TEXT,
          coverage_gaps TEXT,
          low_scores TEXT,
          markdown TEXT,
          created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
      `).run().catch(() => ({ success: true }));

      await this.env.DB.prepare(`
        INSERT INTO scheduled_reports (id, type, report_date, coverage_stats, top_performers, coverage_gaps, low_scores, markdown)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        reportId,
        type,
        reportDate,
        JSON.stringify(coverageStats),
        JSON.stringify(topPerformers),
        JSON.stringify(coverageGaps),
        JSON.stringify(lowScores),
        reportMarkdown
      ).run();

      return { id: reportId, saved: true };
    });

    // Step 6: Optionally send notification (placeholder)
    if (recipient_email) {
      await step.do('notify-recipient', async () => {
        // In production, integrate with email service (Resend, SendGrid, etc.)
        console.log(`[ScheduledReports] Would send report to ${recipient_email}: ${reportId}`);
        return { notified: recipient_email, reportId };
      });
    }

    return {
      reportId,
      type,
      date: reportDate,
      coverage: coverageStats,
      markdown: reportMarkdown,
      saved: savedReport.saved,
    };
  }
}
