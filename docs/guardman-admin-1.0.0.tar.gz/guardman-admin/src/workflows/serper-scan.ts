// GuardMan v4 — Serper Scan Workflow
// Durable pipeline for scanning 120 combos via Google Serper
// Survives restarts, 50K concurrent instances

import { WorkflowEntrypoint, WorkflowStep, WorkflowEvent } from 'cloudflare:workers';
import type { Env } from '../types';
import { generateQueryPlan } from '../serper/index';
import { executeQueryPlan } from '../serper/layer2-executor';
import { classifyAllResults } from '../serper/layer3-classifier';
import { updateSearchIndexFromSerper } from '../services/search-seed';

interface SerperScanParams {
  trigger: 'manual' | 'scheduled';
  serviceSlugs?: string[];
  locationSlugs?: string[];
}

export class SerperScanWorkflow extends WorkflowEntrypoint<Env, SerperScanParams> {
  async run(event: WorkflowEvent<SerperScanParams>, step: WorkflowStep) {
    const params = event.payload;

    // Step 1: Get combos to scan
    const combos = await step.do('get-combos', async () => {
      const services = params.serviceSlugs?.length
        ? params.serviceSlugs.map(s => ({ slug: s }))
        : (await this.env.DB.prepare('SELECT slug FROM services ORDER BY name').all()).results as any[];

      const locations = params.locationSlugs?.length
        ? params.locationSlugs.map(l => ({ slug: l }))
        : (await this.env.DB.prepare('SELECT slug FROM locations ORDER BY name').all()).results as any[];

      return services.flatMap((svc: any) =>
        locations.map((loc: any) => ({ service: svc.slug, location: loc.slug }))
      );
    });

    // Step 2: Scan in batches with parallel execution + idempotency
    const BATCH_SIZE = 5;
    const allResults: any[] = [];

    for (let i = 0; i < combos.length; i += BATCH_SIZE) {
      const batch = combos.slice(i, i + BATCH_SIZE);
      const batchResult = await step.do(`scan-batch-${i}`, async () => {
        const results = [];
        const batchPromises = batch.map(async (combo) => {
          // Idempotency check: skip if already scanned today
          const date = new Date().toISOString().split('T')[0];
          const existing = await this.env.DB.prepare(`
            SELECT sq.id FROM serper_queries sq
            JOIN serper_results sr ON sq.id = sr.query_id
            WHERE sq.service_slug = ? AND sq.location_slug = ?
            AND date(sq.created_at) = ? AND sr.result_type = 'organic'
            LIMIT 1
          `).bind(combo.service, combo.location, date).first();

          if (existing) {
            console.log(`[SerperScan] ${combo.service}/${combo.location}: already scanned today, skipping`);
            return { combo, status: 'skipped', reason: 'already_scanned' };
          }

          try {
            const plan = generateQueryPlan(combo.service, combo.location);
            const execResults = await executeQueryPlan(
              { DB: this.env.DB, SERPER_API_KEY: this.env.SERPER_API_KEY },
              plan.queries,
              (stepName, idx, total) => console.log(`[SerperScan] ${combo.service}/${combo.location}: ${idx + 1}/${total} ${stepName}`)
            );
            return { combo, results: execResults, status: 'completed' };
          } catch (e) {
            return { combo, error: String(e), status: 'failed' };
          }
        });

        // Execute batch in parallel
        const batchResults = await Promise.all(batchPromises);
        results.push(...batchResults);

        return results;
      });
      allResults.push(...batchResult);

      // Durable rate limiting between batches
      if (i + BATCH_SIZE < combos.length) {
        await step.sleep(`rate-limit-batch-${i}`, '2 seconds');
      }
    }

    // Step 3: Classify all results
    const classification = await step.do('classify-all', async () => {
      return await classifyAllResults({ DB: this.env.DB });
    });

    // Step 4: Update AI Search index
    const searchUpdated = await step.do('update-search-index', async () => {
      return await updateSearchIndexFromSerper(this.env);
    });

    // Step 5: Create position snapshot
    const snapshot = await step.do('create-snapshot', async () => {
      const date = new Date().toISOString().split('T')[0];
      await this.env.DB.prepare('DELETE FROM position_snapshots WHERE snapshot_date = ?').bind(date).run();

      const { results } = await this.env.DB.prepare(
        `SELECT sq.service_slug, sq.location_slug, sq.query_text, sr.position, sr.domain, sr.site_type, sr.title
         FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id
         WHERE sr.site_type IN ('own', 'direct_competitor')
         ORDER BY sr.position`
      ).all();

      const batch = (results as any[]).map(r =>
        this.env.DB.prepare(
          'INSERT INTO position_snapshots (snapshot_date, service_slug, location_slug, domain, position, site_type, query_text, title) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(date, r.service_slug, r.location_slug, r.domain, r.position, r.site_type, r.query_text, r.title)
      );

      if (batch.length > 0) await this.env.DB.batch(batch);
      return { date, records: batch.length };
    });

    // Step 6: Chain to SEO Intel Workflow (analyzes results at zero API cost)
    const chained = await step.do('chain-seo-intel', async () => {
      if (this.env.SEO_INTEL_WORKFLOW) {
        const instance = await this.env.SEO_INTEL_WORKFLOW.create({
          id: `post-scan-${Date.now()}`,
          params: { trigger: 'post-scan' },
        });
        return { chained: true, instanceId: instance.id };
      }
      return { chained: false };
    });

    return {
      totalCombos: combos.length,
      completed: allResults.filter(r => r.status === 'completed').length,
      failed: allResults.filter(r => r.status === 'failed').length,
      classification,
      searchUpdated,
      snapshot,
      chained,
    };
  }
}
