// GuardMan v3.0 — Quick Win Workflow (A10)
// Detecta queries donde GuardMan está en posición 4-15 (fácil de subir)
// y genera/mejora contenido automáticamente para esos combos.
// Se ejecuta vía CRON los miércoles o manualmente.

import { WorkflowEntrypoint, WorkflowStep, WorkflowEvent } from 'cloudflare:workers';
import type { Env } from '../types';

interface QuickWinParams {
  maxItems?: number;
  minPosition?: number;
  maxPosition?: number;
}

export class QuickWinWorkflow extends WorkflowEntrypoint<Env, QuickWinParams> {
  async run(event: WorkflowEvent<QuickWinParams>, step: WorkflowStep) {
    const { maxItems = 15, minPosition = 4, maxPosition = 15 } = event.payload;

    console.log(`[QuickWin] Scanning positions ${minPosition}-${maxPosition}, max ${maxItems} items`);

    // Step 1: Encontrar quick wins
    const quickWins = await step.do('find-quick-wins', async () => {
      const { results } = await this.env.DB.prepare(`
        SELECT
          sq.service_slug,
          sq.location_slug,
          sq.query_text,
          sr.position,
          CASE WHEN cc.service_slug IS NOT NULL THEN 1 ELSE 0 END as has_content,
          COALESCE(cc.word_count, 0) as word_count,
          COALESCE(cc.status, 'none') as content_status
        FROM serper_results sr
        JOIN serper_queries sq ON sr.query_id = sq.id
        LEFT JOIN combo_content cc
          ON cc.service_slug = sq.service_slug
          AND cc.location_slug = sq.location_slug
        WHERE sr.site_type = 'own'
          AND sr.position BETWEEN ? AND ?
          AND sq.status = 'completed'
        ORDER BY sr.position ASC
        LIMIT ?
      `).bind(minPosition, maxPosition, maxItems).all();

      return (results as any[]).map(r => ({
        service_slug: r.service_slug,
        location_slug: r.location_slug,
        query: r.query_text,
        position: r.position,
        has_content: r.has_content === 1,
        word_count: r.word_count || 0,
        content_status: r.content_status,
      }));
    });

    console.log(`[QuickWin] Found ${quickWins.length} opportunities`);

    // Step 2: Para cada quick win, generar contenido si es necesario
    let processed = 0;
    let skipped = 0;
    let failed = 0;

    for (const qw of quickWins) {
      // Saltar si ya tiene buen contenido (>500 palabras, status='published')
      if (qw.has_content && qw.word_count > 500 && qw.content_status === 'published') {
        skipped++;
        continue;
      }

      // Si tiene contenido pero es corto o draft, regenerar
      const needsRegen = qw.has_content && (qw.word_count <= 500 || qw.content_status === 'draft');
      const isNew = !qw.has_content;

      try {
        await step.do(
          `gen-${qw.service_slug}-${qw.location_slug}`,
          { retries: { limit: 1, delay: '30 seconds' }, timeout: '3 minutes' },
          async () => {
            if (this.env.CONTENT_PIPELINE_WORKFLOW) {
              await this.env.CONTENT_PIPELINE_WORKFLOW.create({
                id: `quickwin-${qw.service_slug}-${qw.location_slug}-${Date.now()}`,
                params: {
                  combos: [{ service_slug: qw.service_slug, location_slug: qw.location_slug }],
                  mode: 'auto',
                  autoApproveThreshold: 85,
                },
              });
            }
            processed++;
          }
        );
      } catch (err: any) {
        console.error(`[QuickWin] Failed ${qw.service_slug}/${qw.location_slug}: ${err.message}`);
        failed++;
      }
    }

    const result = {
      quickWinsFound: quickWins.length,
      processed,
      skipped,
      failed,
      topOpportunities: quickWins.slice(0, 5).map(q => ({
        combo: `${q.service_slug}/${q.location_slug}`,
        position: `#${q.position}`,
        query: q.query,
        action: q.has_content && q.word_count <= 500 ? 'regenerate' : q.has_content ? 'improve' : 'generate_new',
      })),
    };

    console.log(`[QuickWin] Complete: ${JSON.stringify(result)}`);
    return result;
  }
}
