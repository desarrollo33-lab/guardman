// GuardMan v5.2 — Content Pipeline Workflow
// Multi-pass quality pipeline: Banned Patterns → Guardrails → LLM Review → De-Generic
// Full brand DNA injection (89 keys) into every generation
// Chains to SiteDeployWorkflow for approved content

import { WorkflowEntrypoint, WorkflowStep, WorkflowEvent } from 'cloudflare:workers';
import type { Env } from '../types';
import { loadBrandContext, buildBrandPromptBlock } from '../services/brand-context';
import { scanBannedPatterns } from '../services/banned-patterns';
import { checkContentGuardrails } from '../services/guardrails';
import { reviewWithWorkersAI } from '../services/quality-review';
import { deGenericPass } from '../services/de-generic-pass';
import { callDeepSeekAI } from '../services/ai';
import { calculateContentScore } from '../services/scoring';

interface ContentPipelineParams {
  combos: Array<{ service_slug: string; location_slug: string }>;
  mode: 'auto' | 'manual';
  autoApproveThreshold?: number;
}

interface ComboResult {
  combo: { service_slug: string; location_slug: string };
  status: 'generated' | 'auto-approved' | 'pending-approval' | 'needs-retry' | 'failed';
  score: number;
  review?: any;
  reason?: string;
}

export class ContentPipelineWorkflow extends WorkflowEntrypoint<Env, ContentPipelineParams> {
  async run(event: WorkflowEvent<ContentPipelineParams>, step: WorkflowStep) {
    const { combos, mode, autoApproveThreshold = 90 } = event.payload;
    const results: ComboResult[] = [];

    // Preload brand context once (all 89 keys)
    const brandCtx = await step.do('load-brand-context', async () => {
      return await loadBrandContext(this.env);
    });

    // Process each combo with durable steps
    for (let i = 0; i < combos.length; i++) {
      const combo = combos[i];

      const result = await step.do(`gen-${combo.service_slug}-${combo.location_slug}`, {
        retries: { limit: 1, delay: '30 seconds' },
        timeout: '5 minutes',
      }, async () => {
        return await this.processCombo(combo, brandCtx, mode, autoApproveThreshold);
      });

      results.push(result);

      // Durable rate limiting: pause every 3 combos
      if (results.length % 3 === 0 && results.length < combos.length) {
        await step.sleep(`rate-limit-${results.length}`, '15 seconds');
      }
    }

    // Save lessons learned
    await step.do('save-lessons', async () => {
      for (const r of results) {
        if (r.score > 0) {
          try {
            await this.env.DB.prepare(`
              INSERT INTO content_lessons (entity_type, entity_slug, score, feedback, improvements)
              VALUES (?, ?, ?, ?, ?)
            `).bind(
              'combo',
              `${r.combo.service_slug}-${r.combo.location_slug}`,
              r.score,
              JSON.stringify(r.review || {}),
              JSON.stringify(r.review?.suggestions || [])
            ).run();
          } catch { /* non-critical */ }
        }
      }
    });

    // Chain deploy if items approved
    const approved = results.filter(r => r.status === 'auto-approved');
    if (approved.length > 0 && this.env.SITE_DEPLOY_WORKFLOW) {
      await step.do('chain-deploy', async () => {
        const instance = await this.env.SITE_DEPLOY_WORKFLOW.create({
          id: `deploy-${Date.now()}`,
          params: { mode: 'auto' },
        });
        return { deployWorkflowId: instance.id };
      });
    }

    return {
      total: combos.length,
      generated: results.filter(r => ['generated', 'auto-approved', 'pending-approval'].includes(r.status)).length,
      failed: results.filter(r => r.status === 'failed').length,
      autoApproved: results.filter(r => r.status === 'auto-approved').length,
      results,
    };
  }

  private async processCombo(
    combo: { service_slug: string; location_slug: string },
    brandCtx: any,
    mode: string,
    threshold: number
  ): Promise<ComboResult> {
    const entitySlug = `${combo.service_slug}-${combo.location_slug}`;

    // 1. Gather Serper context for this combo
    let serperCtx = '';
    try {
      const { results: topResults } = await this.env.DB.prepare(`
        SELECT sq.query_text, sr.domain, sr.position, sr.title, sr.snippet
        FROM serper_queries sq
        JOIN serper_results sr ON sq.id = sr.query_id
        WHERE sq.service_slug = ? AND sq.location_slug = ? AND sq.status = 'completed'
        AND sr.result_type = 'organic' AND sr.position <= 10
        ORDER BY sr.position ASC
        LIMIT 20
      `).bind(combo.service_slug, combo.location_slug).all();

      if ((topResults as any[]).length > 0) {
        serperCtx = 'TOP RESULTADOS:\n';
        for (const r of (topResults as any[]).slice(0, 5)) {
          serperCtx += `- [${r.domain}] ${r.title}\n  ${r.snippet || ''}\n`;
        }
      }
    } catch { /* non-critical */ }

    // 2. Gather previous content history (lessons)
    let historyPrompt = '';
    try {
      const lesson = await this.env.DB.prepare(
        'SELECT score, improvements FROM content_lessons WHERE entity_type = ? AND entity_slug = ? ORDER BY created_at DESC LIMIT 1'
      ).bind('combo', entitySlug).first();

      if (lesson) {
        historyPrompt = `\nLECCIONES DE GENERACIÓN ANTERIOR (score: ${(lesson as any).score}):\n${(lesson as any).improvements || ''}\n`;
      }
    } catch { /* non-critical */ }

    // 3. Generate with AI using brand context
    let content: any = null;
    try {
      content = await callDeepSeekAI(
        'combo',
        entitySlug,
        `${combo.service_slug} en ${combo.location_slug}`,
        this.env,
        undefined,
        undefined,
        false,
        '',
        serperCtx + historyPrompt
      );
    } catch (err: any) {
      return { combo, status: 'failed', score: 0, reason: `AI generation failed: ${err.message?.substring(0, 100)}` };
    }

    if (!content) {
      return { combo, status: 'failed', score: 0, reason: 'AI generation returned empty' };
    }

    // 4. Quality Layer 1: Banned patterns scan
    const allText = JSON.stringify(content);
    const banned = scanBannedPatterns(allText, brandCtx.voice.forbiddenWords);
    if (!banned.passed) {
      return { combo, status: 'failed', score: 0, reason: `Banned patterns: ${banned.violations.slice(0, 3).join('; ')}` };
    }

    // 5. Quality Layer 2: Guardrails (existing)
    const guardResult = checkContentGuardrails(content);
    if (!guardResult.passed) {
      return { combo, status: 'failed', score: 0, reason: `Guardrails: ${guardResult.violations.slice(0, 3).join('; ')}` };
    }

    // 6. Quality Layer 3: LLM review via Workers AI
    const review = await reviewWithWorkersAI(this.env, content, brandCtx, {
      type: 'combo', slug: entitySlug,
      name: `${combo.service_slug} en ${combo.location_slug}`,
    });

    // 7. Quality Layer 4: De-generic pass (if generic sections detected)
    if (review.genericSections.length > 0) {
      content = await deGenericPass(this.env, content, review.genericSections, brandCtx.identity.name, brandCtx.stats);
    }

    // 8. Calculate final score (combine algorithmic + LLM)
    const { score: algoScore } = calculateContentScore(content);
    const finalScore = Math.round((algoScore + review.score) / 2);

    // 9. Save content to combo_content
    try {
      await this.env.DB.prepare(`
        INSERT INTO combo_content (service_slug, location_slug, content_json, h1, seo_title, meta_description,
          intro_paragraph, word_count, status, generated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'draft', datetime('now'))
        ON CONFLICT(service_slug, location_slug) DO UPDATE SET
          content_json = excluded.content_json,
          h1 = excluded.h1,
          seo_title = excluded.seo_title,
          meta_description = excluded.meta_description,
          intro_paragraph = excluded.intro_paragraph,
          word_count = excluded.word_count,
          status = 'draft',
          generated_at = datetime('now')
      `).bind(
        combo.service_slug,
        combo.location_slug,
        JSON.stringify(content),
        content.sections?.hero?.heading || '',
        content.sections?.meta?.title || '',
        content.sections?.meta?.description || '',
        (content.sections?.intro?.paragraphs || []).join(' ').substring(0, 300),
        allText.split(/\s+/).length
      ).run();

      // Create content version
      try {
        await this.env.DB.prepare(`
          INSERT INTO content_versions (entity_type, entity_slug, version, content_json, score, created_at)
          VALUES ('combo', ?, 
            COALESCE((SELECT MAX(version) FROM content_versions cv WHERE cv.entity_type = 'combo' AND cv.entity_slug = ?), 0) + 1,
            ?, ?, datetime('now'))
        `).bind(entitySlug, entitySlug, JSON.stringify(content), finalScore).run();
      } catch { /* content_versions may not exist — non-critical */ }
    } catch (err: any) {
      return { combo, status: 'failed', score: finalScore, reason: `Save failed: ${err.message?.substring(0, 100)}` };
    }

    // 10. Decide approval status
    if (finalScore >= threshold) {
      // Auto-approve: add to publish queue
      try {
        await this.env.DB.prepare(`
          INSERT INTO publish_queue (entity_type, entity_slug, content_json, score, status, version, created_at)
          VALUES ('combo', ?, ?, ?, 'approved', 1, datetime('now'))
          ON CONFLICT(entity_type, entity_slug) DO UPDATE SET
            content_json = excluded.content_json,
            score = excluded.score,
            status = 'approved',
            created_at = datetime('now')
        `).bind(entitySlug, JSON.stringify(content), finalScore).run();
      } catch { /* non-critical */ }

      return { combo, status: 'auto-approved', score: finalScore, review };
    }

    if (finalScore >= 75) {
      return { combo, status: 'pending-approval', score: finalScore, review };
    }

    return { combo, status: 'needs-retry', score: finalScore, review };
  }
}
