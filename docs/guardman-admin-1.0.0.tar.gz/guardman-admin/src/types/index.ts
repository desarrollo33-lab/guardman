// GuardMan Admin - Shared Types

export interface Env {
  DB: D1Database;
  IMAGES: R2Bucket;
  CACHE: KVNamespace;
  ASSETS: Fetcher;
  AI: any;
  AI_SEARCH: any;
  AUTH_TOKEN: string;
  ADMIN_EMAIL: string;
  CONTENT_AGENT: DurableObjectNamespace;
  PUBLISHER_AGENT: DurableObjectNamespace;
  SERPER_AGENT_SQLITE: DurableObjectNamespace;
  ORCHESTRATOR: DurableObjectNamespace;
  LOG_SESSION: DurableObjectNamespace;
  RATE_LIMITER: DurableObjectNamespace;
  SEO_CONTENT_QUEUE?: Queue<unknown>;
  SERPER_SCAN_WORKFLOW?: Workflow;
  BULK_GENERATE_WORKFLOW?: Workflow;
  SEO_INTEL_WORKFLOW?: Workflow;
  CONTENT_PIPELINE_WORKFLOW?: Workflow;
  REPORTS_WORKFLOW?: Workflow;
  QUICK_WIN_WORKFLOW?: Workflow;
  MINIMAX_API_KEY?: string;
  SERPER_API_KEY?: string;
  AUTH_SECRET?: string;
  DEPLOY_HOOK_URL?: string;
  AI_GATEWAY_TOKEN?: string;
  CLOUDFLARE_ACCOUNT_ID?: string;
  GITHUB_PUSH_TOKEN?: string;
  CF_API_TOKEN?: string;
  FAL_API_KEY: string;
}

export interface ContentJob {
  entityType: 'service' | 'location' | 'sector' | 'combo';
  entitySlug: string;
  entityName: string;
  comboServiceSlug?: string;
  comboLocationSlug?: string;
  attempt?: number;
}

export interface ContentScore {
  score: number;
  details: {
    localRelevance: number;
    seoOptimization: number;
    contentQuality: number;
    differentiation: number;
    structure: number;
  };
  breakdown?: {
    localRelevance: { points: number; max: number; notes: string[] };
    seoOptimization: { points: number; max: number; notes: string[] };
    contentQuality: { points: number; max: number; notes: string[] };
    differentiation: { points: number; max: number; notes: string[] };
    structure: { points: number; max: number; notes: string[] };
  };
}

export interface PublishJob {
  entityType: string;
  entitySlug: string;
  contentJson: string;
  score: number;
  version: number;
}

export interface GeneratedContent {
  sections: {
    hero?: { heading: string; subheading?: string; image?: string; cta_text?: string };
    intro?: { heading: string; subheading?: string; paragraphs: string[] };
    features?: { heading: string; items: string[] };
    issues?: { heading: string; items: string[] };
    stats?: { heading: string; items: Array<{ label: string; value: string }> };
    faqs?: { heading: string; items: Array<{ question: string; answer: string }> };
    cta?: { heading: string; subheading?: string; button: string; image?: string };
    coverage?: { heading: string; items: string[] };
    meta?: { title: string; description: string };
  };
  _meta?: {
    serper_queries?: string[];
    serper_competitors?: string[];
    keywords?: string[];
    content_gaps?: string[];
    generated_at?: string;
    generated_by?: 'ai' | 'fallback' | 'build_site';
  };
}

export const ADMIN_ORIGIN = 'https://guardman-admin.pages.dev';

export const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export const LOCATION_SLUGS = [
  'santiago-centro', 'huechuraba', 'lampa', 'quilicura', 'la-reina',
  'las-condes', 'lo-barnechea', 'vitacura', 'conchali', 'pudahuel',
  'renca', 'la-pintana', 'los-andes', 'san-felipe'
];

export const ZONE_CONTEXT: Record<string, string> = {
  'las-condes': 'sector oriente premium de Santiago, oficinas corporativas, residencias de lujo y embajadas',
  'vitacura': 'sector oriente premium, casas de alto valor y clinicas privadas',
  'santiago-centro': 'centro de Santiago, area comercial y turistica con alta concentracion de oficinas',
  'huechuraba': 'sector norte de Santiago, centros comerciales y empresas',
  'la-reina': 'sector oriente residencial, tranquilo y familiar',
  'lo-barnechea': 'sector oriente, areas residenciales y propriedades rurales',
  'conchali': 'sector poniente de Santiago, area residencial y comercial',
  'pudahuel': 'sector poniente, cercano al aeropuerto y zonas industriales',
  'renca': 'sector poniente, area industrial y residencial',
  'quilicura': 'sector norte, zona industrial y centros logisticos',
  'lampa': 'sector norte, area de expansion y parques industriales',
  'la-pintana': 'sector sur de Santiago, area predominantemente residencial',
  'los-andes': 'ciudad en la region de Valparaiso, area urbana y turistica',
  'san-felipe': 'ciudad en la region de Valparaiso, area comercial y residencial'
};

// === fal.ai Types (Fase 0 — Media Editor v3) ===

export interface FalGenerateRequest {
  prompt: string;
  model: string;
  image_size?: string;
  num_images?: number;
  seed?: number;
  image_url?: string;
  strength?: number;
  negative_prompt?: string;
  enable_safety_checker?: boolean;
}

export interface FalQueuedRequest {
  falRequestId: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  model: string;
  prompt: string;
  seed?: number;
  images?: Array<{ url: string; width: number; height: number }>;
  error?: string;
  created_at: number;
}

export const SECTOR_TO_SERVICE: Record<string, string> = {
  'comercial': 'guardias-de-seguridad',
  'construccion': 'seguridad-industrial',
  'educacion': 'guardias-de-seguridad',
  'eventos': 'seguridad-eventos',
  'industrial': 'seguridad-industrial',
  'residencial': 'guardias-de-seguridad',
  'salud': 'guardias-de-seguridad',
};

// === Workflow v2.0 Types ===

export interface PositionSummary {
  serviceSlug: string;
  locationSlug: string;
  totalQueries: number;
  ownQueries: number;
  hasOwnPresence: boolean;
  bestOwnPosition: number;
  avgOwnPosition: number | null;
  directCompetitors: number;
  indirectCompetitors: number;
  directories: number;
  top3Own: number;
  top10Own: number;
  competitionDensity: number;
}

export interface CompetitorProfile {
  domain: string;
  type: string;
  services: number;
  locations: number;
  appearances: number;
  avgPosition: number;
  bestPosition: number;
  strengths: string[];
  weaknesses: string[];
  threatLevel: 'critical' | 'high' | 'medium' | 'low';
  pricingStrategy: 'low_cost' | 'premium' | 'visible' | 'unknown';
}

export interface ContentGap {
  serviceSlug: string;
  locationSlug: string;
  searchDemand: number;
  totalResults: number;
  competitors: number;
  sampleQueries: string;
  contentStatus: string | null;
  wordCount: number;
  contentVersion: number;
  contentScore: number | null;
  priority: number;
  action: 'generate_new' | 'review_draft' | 'publish_existing';
}

export interface KeywordIntelligence {
  totalUniqueQueries: number;
  topPatterns: Array<{ pattern: string; frequency: number }>;
  quickWinQueries: Array<{ query: string; position: number; service: string; location: string }>;
  queriesWithZeroPresence: number;
  queriesInTop3: number;
  queriesInTop10: number;
}

export interface ContentProposal {
  serviceSlug: string;
  locationSlug: string;
  priority: 'urgent' | 'important' | 'improvement';
  reason: string;
  topCompetitors: string[];
  competitorWeaknesses: string[];
  targetKeywords: string[];
  demandScore: number;
  action: 'generate_new' | 'review_draft' | 'regenerate';
}

export interface IntelSnapshotSummary {
  totalCombosAnalyzed: number;
  combosWithPresence: number;
  combosWithoutPresence: number;
  totalCompetitors: number;
  criticalCompetitors: number;
  contentGapsCount: number;
  gapsWithNoContent: number;
  gapsDraftOnly: number;
  urgentProposals: number;
}
