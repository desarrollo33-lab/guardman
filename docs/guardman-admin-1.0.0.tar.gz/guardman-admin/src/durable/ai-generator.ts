/**
 * AIGenerator Durable Object
 * Manages AI content generation jobs with persistent state
 */

export class AIGenerator {
  private state: DurableObjectState;
  private env: any;

  constructor(state: DurableObjectState, env: any) {
    this.state = state;
    this.env = env;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === '/stream') {
      return this.handleWebSocket(request);
    }

    if (url.pathname === '/status') {
      return this.handleStatus(request);
    }

    if (request.method === 'POST') {
      return this.handleGenerate(request);
    }

    return new Response('Not found', { status: 404 });
  }

  private async handleWebSocket(request: Request): Promise<Response> {
    const upgradeHeader = request.headers.get('Upgrade');
    if (upgradeHeader !== 'websocket') {
      return new Response('Expected websocket', { status: 400 });
    }

    const [client, server] = Object.values(new WebSocketPair());
    
    this.state.acceptWebSocket(server);

    // Send current status immediately
    const jobs = await this.state.storage.list({ prefix: 'job:' });
    server.send(JSON.stringify({
      type: 'init',
      activeJobs: Array.from(jobs.entries()).map(([key, value]) => ({
        id: key.replace('job:', ''),
        ...value
      }))
    }));

    return new Response(null, {
      status: 101,
      webSocket: client
    });
  }

  async webSocketMessage(ws: WebSocket, message: string): Promise<void> {
    const data = JSON.parse(message);

    if (data.type === 'generate') {
      await this.generateWithStreaming(ws, data.params);
    }

    if (data.type === 'cancel') {
      await this.state.storage.put(`job:${data.jobId}:status`, 'cancelled');
      ws.send(JSON.stringify({ type: 'cancelled', jobId: data.jobId }));
    }
  }

  private async handleGenerate(request: Request): Promise<Response> {
    const body = await request.json();
    const { entityType, entitySlug, prompt } = body;

    const jobId = `${entityType}:${entitySlug}:${Date.now()}`;
    
    // Store job state
    await this.state.storage.put(`job:${jobId}`, {
      status: 'queued',
      entityType,
      entitySlug,
      createdAt: Date.now(),
      progress: 0
    });

    // Start generation in background
    this.state.waitUntil(this.processGeneration(jobId, prompt));

    return Response.json({
      ok: true,
      jobId,
      status: 'queued'
    });
  }

  private async handleStatus(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const jobId = url.searchParams.get('jobId');

    if (!jobId) {
      // Return all jobs
      const jobs = await this.state.storage.list({ prefix: 'job:' });
      return Response.json({
        jobs: Array.from(jobs.entries()).map(([key, value]) => ({
          id: key.replace('job:', ''),
          ...value
        }))
      });
    }

    const job = await this.state.storage.get(`job:${jobId}`);
    return Response.json({ job: job || null });
  }

  private async processGeneration(jobId: string, prompt: string): Promise<void> {
    // Update status to generating
    await this.state.storage.put(`job:${jobId}:status`, 'generating');
    await this.state.storage.put(`job:${jobId}:startedAt`, Date.now());

    try {
      // Call DeepSeek with streaming
      const stream = await this.callDeepSeek(prompt);
      
      let fullContent = '';
      let chunkCount = 0;

      const reader = stream.getReader();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = new TextDecoder().decode(value);
        fullContent += chunk;
        chunkCount++;

        // Update progress every 5 chunks
        if (chunkCount % 5 === 0) {
          await this.state.storage.put(`job:${jobId}:progress`, {
            chunks: chunkCount,
            tokens: fullContent.length
          });
        }

        // Broadcast to all connected WebSockets
        for (const ws of this.state.getWebSockets()) {
          ws.send(JSON.stringify({
            type: 'progress',
            jobId,
            chunk,
            totalTokens: fullContent.length
          }));
        }
      }

      // Parse and store final result
      const parsed = this.parseContent(fullContent);
      
      await this.state.storage.put(`job:${jobId}`, {
        status: 'completed',
        content: parsed,
        completedAt: Date.now()
      });

      // Notify completion
      for (const ws of this.state.getWebSockets()) {
        ws.send(JSON.stringify({
          type: 'completed',
          jobId,
          content: parsed
        }));
      }

    } catch (error) {
      await this.state.storage.put(`job:${jobId}`, {
        status: 'error',
        error: error.message,
        failedAt: Date.now()
      });

      for (const ws of this.state.getWebSockets()) {
        ws.send(JSON.stringify({
          type: 'error',
          jobId,
          error: error.message
        }));
      }
    }
  }

  private async callDeepSeek(prompt: string): Promise<ReadableStream> {
    const apiKey = this.env.MINIMAX_API_KEY;
    if (!apiKey) {
      throw new Error('API key not configured in environment');
    }

    const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          { role: 'system', content: 'Eres copywriter SEO para GuardMan Chile.' },
          { role: 'user', content: prompt }
        ],
        max_tokens: 2500,
        temperature: 0.4,
        stream: true
      })
    });

    if (!response.ok) {
      throw new Error(`DeepSeek API error: ${response.status}`);
    }

    return response.body!;
  }

  private parseContent(raw: string): any {
    // Clean and parse JSON
    let content = raw.trim();
    content = content.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/gi, '').trim();
    
    try {
      return JSON.parse(content);
    } catch (e) {
      // Try to extract valid JSON
      const lastBrace = content.lastIndexOf('}');
      if (lastBrace > 0) {
        try {
          return JSON.parse(content.substring(0, lastBrace + 1));
        } catch (e2) {
          return { error: 'Failed to parse', raw: content.substring(0, 500) };
        }
      }
      return { error: 'Failed to parse', raw: content.substring(0, 500) };
    }
  }
}

/**
 * ContentQueue Durable Object
 * Manages queue of content operations
 */
export class ContentQueue {
  private state: DurableObjectState;

  constructor(state: DurableObjectState, env: any) {
    this.state = state;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);

    if (request.method === 'POST' && url.pathname === '/enqueue') {
      const body = await request.json();
      await this.enqueue(body);
      return Response.json({ ok: true, queued: true });
    }

    if (request.method === 'GET' && url.pathname === '/next') {
      const job = await this.dequeue();
      return Response.json({ ok: true, job });
    }

    if (request.method === 'GET' && url.pathname === '/status') {
      const queue = await this.state.storage.list({ prefix: 'queue:' });
      return Response.json({
        queueLength: queue.size,
        jobs: Array.from(queue.values())
      });
    }

    return new Response('Not found', { status: 404 });
  }

  private async enqueue(job: any): Promise<void> {
    const id = `queue:${Date.now()}:${Math.random().toString(36).slice(2)}`;
    await this.state.storage.put(id, {
      ...job,
      enqueuedAt: Date.now(),
      status: 'pending'
    });
  }

  private async dequeue(): Promise<any | null> {
    const queue = await this.state.storage.list({ prefix: 'queue:' });
    const entries = Array.from(queue.entries());
    
    if (entries.length === 0) return null;

    // Get oldest job
    const [id, job] = entries.sort((a: any, b: any) => 
      (a[1].enqueuedAt || 0) - (b[1].enqueuedAt || 0)
    )[0];

    // Mark as processing
    await this.state.storage.put(id, {
      ...job,
      status: 'processing',
      startedAt: Date.now()
    });

    return { id, ...job };
  }
}
