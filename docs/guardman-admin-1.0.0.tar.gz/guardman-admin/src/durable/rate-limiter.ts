// GuardMan v3.0 — Rate Limiter Durable Object
// Controla el rate limiting para endpoints críticos.
// Basado en sliding window. Sin dependencias externas.

import { DurableObject } from 'cloudflare:workers';

interface RateLimitConfig {
  maxRequests: number;
  windowMs: number;
}

const DEFAULT_CONFIGS: Record<string, RateLimitConfig> = {
  'ai:generate': { maxRequests: 10, windowMs: 60000 },      // 10/min
  'cms:save': { maxRequests: 60, windowMs: 60000 },          // 60/min
  'lead:capture': { maxRequests: 30, windowMs: 60000 },      // 30/min
  'serper:scan': { maxRequests: 5, windowMs: 60000 },        // 5/min
};

export class RateLimiter extends DurableObject {
  private requests: Map<string, number[]> = new Map();

  async checkLimit(key: string, maxRequests?: number, windowMs?: number): Promise<boolean> {
    const config = DEFAULT_CONFIGS[key] || { maxRequests: maxRequests || 30, windowMs: windowMs || 60000 };
    const now = Date.now();

    let timestamps = this.requests.get(key) || [];
    // Limpiar timestamps fuera de la ventana
    timestamps = timestamps.filter(t => now - t < config.windowMs);

    if (timestamps.length >= config.maxRequests) {
      this.requests.set(key, timestamps); // Guardar estado actualizado
      return false;
    }

    timestamps.push(now);
    this.requests.set(key, timestamps);
    return true;
  }

  async getStats(key: string): Promise<{ remaining: number; resetMs: number; limit: number }> {
    const config = DEFAULT_CONFIGS[key] || { maxRequests: 30, windowMs: 60000 };
    const now = Date.now();
    let timestamps = this.requests.get(key) || [];
    timestamps = timestamps.filter(t => now - t < config.windowMs);

    const remaining = Math.max(0, config.maxRequests - timestamps.length);
    const oldestInWindow = timestamps.length > 0 ? Math.min(...timestamps) : now;
    const resetMs = Math.max(0, (oldestInWindow + config.windowMs) - now);

    return { remaining, resetMs, limit: config.maxRequests };
  }

  async reset(key: string): Promise<void> {
    this.requests.delete(key);
  }
}
