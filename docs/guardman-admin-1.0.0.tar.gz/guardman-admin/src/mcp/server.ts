import type { Env } from '../types';

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: Record<string, any>;
}

export interface MCPResult {
  content: Array<{ type: 'text'; text: string }>;
  isError?: boolean;
}

const TOOLS: MCPTool[] = [
  {
    name: 'list_services',
    description: 'List all security services available in GuardMan CMS',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'list_locations',
    description: 'List all comunas/locations covered by GuardMan',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'get_content',
    description: 'Get generated SEO content for a service or combo',
    inputSchema: {
      type: 'object',
      properties: {
        service_slug: { type: 'string', description: 'Service slug' },
        location_slug: { type: 'string', description: 'Location slug (optional)' },
      },
      required: ['service_slug'],
    },
  },
  {
    name: 'get_coverage',
    description: 'Get content coverage stats for all services',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'get_quality_scores',
    description: 'Get quality scores and audit results',
    inputSchema: {
      type: 'object',
      properties: {
        limit: { type: 'number', description: 'Max results (default 10)' },
      },
    },
  },
  {
    name: 'get_competitors',
    description: 'Get competitor analysis for a service',
    inputSchema: {
      type: 'object',
      properties: {
        service_slug: { type: 'string', description: 'Service slug' },
        location_slug: { type: 'string', description: 'Location slug (optional)' },
      },
      required: ['service_slug'],
    },
  },
];

export async function handleMCPRequest(env: Env, body: any): Promise<any> {
  if (body.method === 'tools/list') {
    return { tools: TOOLS };
  }

  if (body.method === 'tools/call') {
    const toolName = body.params?.name;
    const args = body.params?.arguments || {};

    switch (toolName) {
      case 'list_services': {
        const { results } = await env.DB.prepare('SELECT slug, name, short_description FROM services ORDER BY sort, name').all();
        return mcpResult(JSON.stringify(results, null, 2));
      }
      case 'list_locations': {
        const { results } = await env.DB.prepare('SELECT slug, name, zone FROM locations ORDER BY zone, name').all();
        return mcpResult(JSON.stringify(results, null, 2));
      }
      case 'get_content': {
        if (args.location_slug) {
          const row = await env.DB.prepare(
            'SELECT service_slug, location_slug, seo_title, meta_description, h1, intro_paragraph, faqs_json, status, word_count, score FROM combo_content WHERE service_slug = ? AND location_slug = ?'
          ).bind(args.service_slug, args.location_slug).first();
          return mcpResult(JSON.stringify(row || { error: 'Not found' }, null, 2));
        }
        const cv = await env.DB.prepare(
          "SELECT entity_slug, version, content_json, confidence_score, word_count FROM content_versions WHERE entity_type = 'service' AND entity_slug = ? ORDER BY version DESC LIMIT 1"
        ).bind(args.service_slug).first();
        return mcpResult(JSON.stringify(cv || { error: 'Not found' }, null, 2));
      }
      case 'get_coverage': {
        const { results } = await env.DB.prepare(`
          SELECT s.slug, s.name,
            (SELECT COUNT(*) FROM combo_content cc WHERE cc.service_slug = s.slug) as combos,
            (SELECT COUNT(*) FROM locations) as total_locations
          FROM services s ORDER BY s.name
        `).all();
        return mcpResult(JSON.stringify(results, null, 2));
      }
      case 'get_quality_scores': {
        const limit = args.limit || 10;
        const { results } = await env.DB.prepare(
          'SELECT entity_type, entity_slug, score, details_json, created_at FROM audit_reports ORDER BY created_at DESC LIMIT ?'
        ).bind(limit).all();
        return mcpResult(JSON.stringify(results, null, 2));
      }
      case 'get_competitors': {
        const { results } = await env.DB.prepare(
          `SELECT domain, COUNT(*) as appearances, ROUND(AVG(position),1) as avg_pos
           FROM serper_results sr JOIN serper_queries sq ON sr.query_id = sq.id
           WHERE sq.service_slug = ? AND sr.site_type = 'direct_competitor'
           ${args.location_slug ? 'AND sq.location_slug = ?' : ''}
           GROUP BY domain ORDER BY appearances DESC LIMIT 10`
        ).bind(args.location_slug ? [args.service_slug, args.location_slug] : [args.service_slug]).all();
        return mcpResult(JSON.stringify(results, null, 2));
      }
      default:
        return mcpResult(`Unknown tool: ${toolName}`, true);
    }
  }

  return { error: 'Unknown MCP method' };
}

function mcpResult(text: string, isError = false): MCPResult {
  return { content: [{ type: 'text', text }], isError };
}
