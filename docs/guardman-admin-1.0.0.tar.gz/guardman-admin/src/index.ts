// GuardMan v3.0 — Workers Native Unified Router
// Un Worker. Un deploy. Un dominio. Datos directos desde D1.
//
// Sirve: API (/api/*) + Admin SPA (/admin/*) + Assets estáticos + SSR público
// Reemplaza 3 deployments separados (Pages + Pages + Worker) por 1 solo.
import { Agent, routeAgentRequest } from 'agents';
import { GMContentAgent } from './agents/content-agent';
import { GMPublisherAgent } from './agents/publisher-agent';
import { GMSerperSqlite } from './agents/serper-agent';
import { GMOrchestrator } from './agents/orchestrator';
import { SEOAuditorAgent } from './agents/seo-auditor';
import { CompetitorAnalystAgent } from './agents/competitor-analyst';
import { SerperScanWorkflow } from './workflows/serper-scan';
import { BulkGenerateWorkflow } from './workflows/bulk-generate';
import { SEOIntelWorkflow } from './workflows/seo-intel';
import { ContentPipelineWorkflow } from './workflows/content-pipeline';
import { ScheduledReportsWorkflow } from './workflows/scheduled-reports';
import { QuickWinWorkflow } from './workflows/quick-win';
import { CORS_HEADERS, Env } from './types';
import { handleModularRoutes } from './api/index';
import { handleScheduledTask } from './core/scheduler';
import { LogSession } from './api/services/log-session';
import { PreviewDataService } from './api/services/preview-data-service';
import { handleMCPRequest } from './mcp/server';
import { RateLimiter } from './durable/rate-limiter';
import queueHandler from './queues/consumer';
import { buildHomepage, buildDetailPage, buildStaticPage, buildHubPage, buildNosotrosPage, buildGuardPodPage, buildAjaxPage, buildContactoPage, buildCotizacionPage, buildPrivacidadPage, buildTerminosPage, hdr, ftr, esc, setSiteUrl, CSS_V, SITE_URL, CRITICAL_CSS, OG_BASE } from './ssr/site-renderer';
import { fetchHomepage, fetchServicePage, fetchSectorPage, fetchLocationPage, fetchComboPage, fetchHubPage } from './ssr/site-data';
import { getCacheKey, getCache, setCache } from './services/cache';

const cors = CORS_HEADERS;

// === EXPORT PARA WRANGLER (Durable Objects + Workflows) ===
export {
  GMContentAgent, GMPublisherAgent, GMSerperSqlite, GMOrchestrator,
  LogSession, PreviewDataService, SEOAuditorAgent, CompetitorAnalystAgent,
  SerperScanWorkflow, BulkGenerateWorkflow, SEOIntelWorkflow,
  ContentPipelineWorkflow, ScheduledReportsWorkflow, QuickWinWorkflow,
  RateLimiter,
};

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    // Inicializar SITE_URL desde env (P0: dominio correcto)
    setSiteUrl(env.WORKER_BASE_URL || 'https://guardman.oficinadesarrollo33.workers.dev');
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // ===== 1. CORS Preflight =====
    if (method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }

    // ===== 2. Health Check =====
    if (path === '/health') {
      return Response.json({ ok: true, version: '3.0.0-workers-native' }, { headers: cors });
    }

    // ===== 2b. Debug: ver content_json de homepage (solo auth) =====
    if (path === '/health/homepage-debug') {
      const authHdr = request.headers.get('Authorization') || '';
      const token = new URL(request.url).searchParams.get('token');
      const isAuthed = authHdr === `Bearer ${env.AUTH_TOKEN}` || token === env.AUTH_TOKEN;
      if (!isAuthed) {
        return new Response('Unauthorized', { status: 401 });
      }
      try {
        const row = await env.DB.prepare('SELECT hero_heading, hero_image, meta_title, content_json FROM static_page_content WHERE slug=?').bind('homepage').first();
        const cj = row?.content_json;
        let parsed: any = null;
        if (cj) {
          try { parsed = typeof cj === 'string' ? JSON.parse(cj) : cj; } catch { parsed = { error: 'parse failed', raw: String(cj).substring(0, 200) }; }
        }
        return Response.json({
          ok: true,
          row: { hero_image: (row as any)?.hero_image, hero_heading: (row as any)?.hero_heading, meta_title: (row as any)?.meta_title },
          content_json_parsed: parsed ? {
            has_seo: !!parsed.seo,
            has_content: !!parsed.content,
            hero_bg_image: parsed.content?.hero?.background_image || parsed.content?.hero?.image || parsed.hero?.background_image || null,
            nosotros_image: parsed.content?.nosotros?.image || null,
            guardpod_image: parsed.content?.guardpod?.image || null,
            guardpod_title: parsed.content?.guardpod?.title || null,
          } : null,
          content_json_raw_len: cj ? String(cj).length : 0,
        }, { headers: cors });
      } catch (err: any) {
        return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
      }
    }

    // ===== 3. API Routes (/api/*) — sin cambios =====
    if (path.startsWith('/api/')) {
      // Agent WebSocket routing (antes de rutas HTTP)
      if (path.startsWith('/api/agents/')) {
        const agentResponse = await routeAgentRequest(request, env, {
          onBeforeConnect: async (req, _lobby) => {
            const token = new URL(req.url).searchParams.get('token');
            const authHeader = req.headers.get('Authorization');
            const isAuthed = authHeader === `Bearer ${env.AUTH_TOKEN}` || token === env.AUTH_TOKEN;
            if (!isAuthed) return new Response('Unauthorized', { status: 401 });
            return req;
          },
        });
        if (agentResponse) return agentResponse;
      }

      // API HTTP routes
      const apiResponse = await handleModularRoutes(request, env, ctx);
      if (apiResponse) return apiResponse;

      // Image proxy (public)
      if (path.startsWith('/api/images/') && method === 'GET') {
        const key = path.replace('/api/images/', '');
        const object = await env.IMAGES.get(key);
        if (!object) return Response.json({ ok: false, error: 'Not found' }, { status: 404, headers: cors });
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('etag', object.httpEtag);
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Cache-Control', 'public, max-age=31536000');
        fixImageContentType(headers, key);
        return new Response(object.body, { headers });
      }

      // Login (public)
      if (path === '/api/login' && method === 'POST') {
        const body = await request.json() as any;
        if (body.email === env.ADMIN_EMAIL && body.password === env.AUTH_TOKEN) {
          return Response.json({
            ok: true,
            data: { token: body.email + ':' + Date.now(), user: { email: body.email } }
          }, { headers: cors });
        }
        return Response.json({ ok: false, error: 'Invalid credentials' }, { status: 401, headers: cors });
      }

      // MCP Server
      if (path === '/api/mcp' && method === 'POST') {
        const body = await request.json();
        const result = await handleMCPRequest(env, body);
        return Response.json(result, { headers: cors });
      }

      return Response.json({ ok: false, error: 'API route not found' }, { status: 404, headers: cors });
    }

    // ===== 4. Admin SPA (/admin/*) — Workers Assets con cache correcto =====
    if (path.startsWith('/admin')) {
      // Redirect /admin sin trailing slash a /admin/
      if (path === '/admin') {
        return Response.redirect(url.origin + '/admin/', 301);
      }
      const assetRes = await env.ASSETS.fetch(request);
      // Cache: HTML no-cache, assets con hash long-term
      const isHtml = path === '/admin/' || path.endsWith('.html');
      const isAsset = /\.(js|css|png|jpg|webp|svg|ico)$/.test(path);
      const headers = new Headers(assetRes.headers);
      if (isHtml) {
        headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      } else if (isAsset) {
        headers.set('Cache-Control', 'public, max-age=31536000, immutable');
      }
      return new Response(assetRes.body, { status: assetRes.status, headers });
    }

    // ===== 4b. robots.txt =====
    if (path === '/robots.txt') {
      const robots = `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Sitemap: ${SITE_URL}/sitemap.xml`;
      return new Response(robots, { headers: { 'Content-Type': 'text/plain', 'Cache-Control': 'public, max-age=86400' } });
    }

    // ===== 4c. Sitemap =====
    if (path === '/sitemap.xml') {
      return handleSitemap(env);
    }

    // ===== 5. Images from R2 =====
    // R2 media serving: images, videos, thumbnails
    if (path.startsWith('/images/') || path.startsWith('/videos/') || path.startsWith('/thumbnails/')) {
      const key = path.substring(1); // e.g. "images/hero-home.webp", "videos/yt-XZsDWxHdgP4", "thumbnails/yt-XZsDWxHdgP4.jpg"
      const object = await env.IMAGES.get(key);
      if (object) {
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('etag', object.httpEtag);
        headers.set('Cache-Control', 'public, max-age=31536000, immutable');
        headers.set('Access-Control-Allow-Origin', '*');
        fixImageContentType(headers, key);
        return new Response(object.body, { headers });
      }
      // Fallback to ASSETS if not in R2
      return env.ASSETS.fetch(request);
    }

    // ===== 5b. Formularios POST (antes de assets para correcto orden lógico) =====
    if ((path === '/contacto' || path === '/cotizacion') && method === 'POST') {
      return handleQuoteForm(request, env, ctx);
    }

    // ===== 5c. Cuestionario de ADN — Rodrigo Mora (CEO) =====
    // Sirve el HTML desde ASSETS sin pasar por el SSR
    if (path === '/cuestionario-ceo-rodrigo' || path === '/cuestionario-ceo-rodrigo.html') {
      const assetRes = await env.ASSETS.fetch(new URL('/cuestionario-ceo-rodrigo.html', url.origin));
      if (assetRes.ok) {
        const headers = new Headers(assetRes.headers);
        headers.set('Cache-Control', 'no-cache, no-store, must-revalidate');
        headers.set('Content-Type', 'text/html; charset=utf-8');
        return new Response(assetRes.body, { status: 200, headers });
      }
    }

    // ===== 5c. Site Assets =====
    if (path.match(/\.(css|js|woff2?|svg|png|jpg|jpeg|webp|ico|txt)$/i) || path.startsWith('/fonts/') || path.startsWith('/styles/')) {
      return env.ASSETS.fetch(request);
    }

    // ===== 6. SSR — Sitio Público con diseño Open Design =====
    return renderSitePage(request, env, ctx);
  },

  // ===== CRON Triggers =====
  async scheduled(event: ScheduledEvent, env: Env, ctx: ExecutionContext) {
    await handleScheduledTask(event, env);
  },

  // ===== Queue Consumer =====
  async queue(batch: MessageBatch, env: Env) {
    await queueHandler.queue(batch, env);
  },
};

// ===================================================================
// FORMULARIO DE COTIZACIÓN (C4 + C5)
// Captura leads directo en D1. Sin Formspree. Sin APIs externas.
// ===================================================================
async function handleQuoteForm(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
  try {
    const formData = await request.formData();

    // Honeypot anti-spam
    if (formData.get('_honey')) {
      return Response.redirect(new URL('/gracias', request.url).href, 302);
    }

    const url = new URL(request.url);

    // Enriquecer con Serper data (async, no bloquea respuesta)
    const { enrichLeadWithIntel } = await import('./api/routes/intel/helpers');

    const slug = 'ld-' + Date.now().toString(36);
    const result = await env.DB.prepare(`
      INSERT INTO intel_leads (slug, status, source, contact_name, contact_email, contact_phone,
        company_name, service_slug, location_slug, message,
        utm_source, utm_medium, utm_campaign, landing_page, ip_hash)
      VALUES (?, 'new', 'web', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      slug,
      formData.get('nombre') || 'Sin nombre',
      formData.get('email') || null,
      formData.get('telefono') || null,
      formData.get('empresa') || null,
      url.searchParams.get('service') || formData.get('service') || null,
      url.searchParams.get('location') || formData.get('location') || null,
      formData.get('mensaje') || null,
      url.searchParams.get('utm_source') || 'direct',
      url.searchParams.get('utm_medium') || 'organic',
      url.searchParams.get('utm_campaign') || null,
      request.headers.get('Referer') || url.pathname,
      request.headers.get('CF-Connecting-IP') || null,
    ).run();

    // Enriquecer async
    const leadId = result.meta.last_row_id as number;
    ctx.waitUntil(
      enrichLeadWithIntel(
        env,
        url.searchParams.get('service') || (formData.get('service') as string) || null,
        url.searchParams.get('location') || (formData.get('location') as string) || null,
        leadId,
      )
    );

    return Response.redirect(new URL('/gracias', request.url).href, 302);
  } catch (err: any) {
    return new Response(
      `<html><body style="font-family:sans-serif;padding:40px;text-align:center">
        <h1>Error al enviar</h1><p>${err.message}</p>
        <a href="/contacto">Volver</a><script src="/scripts/main.js"></script>
</body></html>`,
      { status: 500, headers: { 'Content-Type': 'text/html' } }
    );
  }
}

// ===================================================================
// SITEMAP DINÁMICO (siempre actualizado desde D1)
// ===================================================================
async function handleSitemap(env: Env): Promise<Response> {
  try {
    const [services, locations, combos, sectors] = await Promise.all([
      env.DB.prepare('SELECT slug FROM services ORDER BY name').all(),
      env.DB.prepare('SELECT slug FROM locations ORDER BY name').all(),
      env.DB.prepare("SELECT service_slug, location_slug FROM combo_content WHERE status='published' OR status='draft'").all(),
      env.DB.prepare('SELECT slug FROM sectors ORDER BY name').all(),
    ]);

    const urls: string[] = [
      `  <url><loc>${SITE_URL}/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>`,
      `  <url><loc>${SITE_URL}/servicios</loc><changefreq>weekly</changefreq><priority>0.9</priority></url>`,
      `  <url><loc>${SITE_URL}/ubicaciones</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>`,
      `  <url><loc>${SITE_URL}/sectores</loc><changefreq>weekly</changefreq><priority>0.7</priority></url>`,
      `  <url><loc>${SITE_URL}/nosotros</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>`,
      `  <url><loc>${SITE_URL}/contacto</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>`,
      `  <url><loc>${SITE_URL}/cotizacion</loc><changefreq>monthly</changefreq><priority>0.6</priority></url>`,

      `  <url><loc>${SITE_URL}/gracias</loc><changefreq>never</changefreq><priority>0.1</priority></url>`,
    ];

    for (const s of services.results as any[]) {
      urls.push(`  <url><loc>${SITE_URL}/servicios/${s.slug}</loc><changefreq>weekly</changefreq><priority>0.9</priority></url>`);
    }

    for (const l of locations.results as any[]) {
      urls.push(`  <url><loc>${SITE_URL}/ubicaciones/${l.slug}</loc><changefreq>weekly</changefreq><priority>0.7</priority></url>`);
    }

    for (const sec of sectors.results as any[]) {
      urls.push(`  <url><loc>${SITE_URL}/sectores/${sec.slug}</loc><changefreq>weekly</changefreq><priority>0.6</priority></url>`);
    }

    for (const c of combos.results as any[]) {
      urls.push(`  <url><loc>${SITE_URL}/servicios/${c.service_slug}/${c.location_slug}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>`);
    }



    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.join('\n')}
</urlset>`;

    return new Response(xml, {
      headers: {
        'Content-Type': 'application/xml; charset=utf-8',
        'Cache-Control': 'public, max-age=3600, s-maxage=3600',
      },
    });
  } catch (err: any) {
    return new Response(`<error>${err.message}</error>`, { status: 500 });
  }
}

// ===================================================================
// SSR — SITIO PÚBLICO CON DISEÑO OPEN DESIGN
// ===================================================================
async function getStaticPageData(env: Env, slug: string): Promise<any> {
  try {
    const row = await env.DB.prepare('SELECT * FROM static_page_content WHERE slug=?').bind(slug).first();
    return row || null;
  } catch { return null; }
}

// Normalizar URLs de imagen: absoluta → relativa para SSR
function normStaticImg(url: string | null | undefined): string | undefined {
  if (!url) return undefined;
  try { return new URL(url).pathname; } catch { return url.startsWith('/') ? url : '/' + url; }
}

// Fix MIME type for R2 objects
function fixImageContentType(headers: Headers, key: string): void {
  const ct = headers.get('Content-Type') || '';
  if (ct === 'application/octet-stream' || !ct) {
    if (key.endsWith('.webp')) headers.set('Content-Type', 'image/webp');
    else if (key.endsWith('.jpg') || key.endsWith('.jpeg')) headers.set('Content-Type', 'image/jpeg');
    else if (key.endsWith('.png')) headers.set('Content-Type', 'image/png');
    else if (key.endsWith('.svg')) headers.set('Content-Type', 'image/svg+xml');
    else if (key.endsWith('.gif')) headers.set('Content-Type', 'image/gif');
    else if (key.endsWith('.mp4')) headers.set('Content-Type', 'video/mp4');
    else if (key.endsWith('.webm')) headers.set('Content-Type', 'video/webm');
  }
}

async function renderSitePage(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/\/+/g, '/');

  try {
    // Try KV cache first (ARCH-01)
    let cacheKey = '';
    if (path === '/') cacheKey = 'page:homepage';
    else if (path.match(/^\/servicios\/[^/]+\/[^/]+$/)) {
      const parts = path.split('/');
      cacheKey = getCacheKey('combo', `${parts[2]}/${parts[3]}`);
    } else if (path.startsWith('/servicios/')) cacheKey = getCacheKey('service', path.split('/')[2]);
    else if (path.startsWith('/ubicaciones/')) cacheKey = getCacheKey('location', path.split('/')[2]);
    else if (path.startsWith('/sectores/')) cacheKey = getCacheKey('sector', path.split('/')[2]);
    else if (path === '/servicios' || path === '/sectores' || path === '/ubicaciones') cacheKey = getCacheKey('static', 'hub-' + path.replace('/', ''));
    else if (path === '/nosotros' || path === '/guard-pod' || path === '/ajax-systems' || path === '/contacto' || path === '/cotizacion' || path === '/privacidad' || path === '/terminos') cacheKey = getCacheKey('static', path.replace('/', ''));


    if (cacheKey) {
      const cachedHtml = await getCache(env, cacheKey);
      if (cachedHtml) {
        console.log('[SSR][cache] HIT for', cacheKey);
        return new Response(cachedHtml, {
          headers: {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'public, max-age=3600, s-maxage=86400',
            'CDN-Cache-Control': 'public, max-age=86400',
            'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; img-src 'self' data: https://guardman.oficinadesarrollo33.workers.dev https://staticmap.openstreetmap.de https://*.tile.openstreetmap.org https://img.youtube.com https://*.ytimg.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-src https://www.youtube.com; frame-ancestors 'none';",
            'X-Cache': 'HIT',
          },
        });
      }
    }

    let data = null;
    let html = '';
    const cacheHeader = 'public, max-age=3600, s-maxage=86400';

    // Homepage — from D1 like static pages
    if (path === '/') {
      const staticData = await getStaticPageData(env, 'homepage');
      data = await fetchHomepage(env);
      if (data) {
        // Override hero/meta from D1 columns
        if (staticData) {
          data.heroHeading = staticData.hero_heading || data.heroHeading;
          data.heroSubheading = staticData.hero_subheading || data.heroSubheading;
          data.heroBadge = staticData.hero_badge || data.heroBadge;
          data.title = staticData.meta_title || data.title;
          data.description = staticData.meta_description || data.description;
          data.heroImage = normStaticImg(staticData.hero_image) || data.heroImage;
        }
        // Override sections from content_json (CMS editor data)
        if (staticData?.content_json) {
          try {
            const cj = typeof staticData.content_json === 'string'
              ? JSON.parse(staticData.content_json) : staticData.content_json;
            const c = cj.content || cj;
            const seo = cj.seo || {};
            // Helper: normalizar URLs de imagen (absoluta → relativa)
            const normImg = (url: string | undefined | null): string | undefined => {
              if (!url) return undefined;
              try {
                const u = new URL(url);
                return u.pathname;
              } catch {
                return url.startsWith('/') ? url : '/' + url;
              }
            };
            // SEO overrides
            if (seo.title) data.title = seo.title;
            if (seo.description) data.description = seo.description;
            // Hero
            const h = c.hero || {};
            if (h.headline) data.heroHeading = h.headline;
            if (h.subheadline) data.heroSubheading = h.subheadline;
            if (h.badge) data.heroBadge = h.badge;
            const heroImg = normImg(h.background_image || h.image);
            if (heroImg) data.heroImage = heroImg;
            // CTAs override
            if (h.ctas?.length) data.heroCtas = h.ctas.map((cta: any) => ({
              text: cta.text || cta.label || '',
              href: cta.href || cta.link || '#',
              variant: cta.variant || 'outline-light',
            }));
            // Nosotros
            const n = c.nosotros || {};
            if (n.paragraph) data.homeNosotrosParagraph = n.paragraph;
            const nosotrosImg = normImg(n.image);
            if (nosotrosImg) data.homeNosotrosImage = nosotrosImg;
            if (n.features?.length) data.homeNosotrosFeatures = n.features.map((f: any) => ({
              title: typeof f === 'string' ? f : f.title || '',
              description: typeof f === 'string' ? '' : f.description || '',
            }));
            if (n.badge) data.homeNosotrosBadge = n.badge;
            if (n.title) data.homeNosotrosTitle = n.title;
            // Servicios
            const sv = c.servicios || {};
            if (sv.badge) data.homeServiciosBadge = sv.badge;
            if (sv.title) data.homeServiciosTitle = sv.title;
            if (sv.subtitle) data.homeServiciosSubtitle = sv.subtitle;
            // GuardPod
            const gp = c.guardpod || {};
            if (gp.badge) data.homeGuardPodBadge = gp.badge;
            if (gp.title) data.homeGuardPodTitle = gp.title;
            if (gp.paragraph) data.homeGuardPodParagraph = gp.paragraph;
            if (gp.cta_text) data.homeGuardPodCtaText = gp.cta_text;
            if (gp.cta_link) data.homeGuardPodCtaLink = gp.cta_link;
            if (gp.features?.length) data.homeGuardPodFeatures = gp.features.map((f: any) => ({
              title: typeof f === 'string' ? f : f.title || '',
              description: typeof f === 'string' ? '' : f.description || '',
            }));
            const gpImg = normImg(gp.image);
            if (gpImg) data.homeGuardPodImage = gpImg;
            // Sectores
            const sc = c.sectores || {};
            if (sc.badge) data.homeSectoresBadge = sc.badge;
            if (sc.title) data.homeSectoresTitle = sc.title;
            if (sc.subtitle) data.homeSectoresSubtitle = sc.subtitle;
            // Ajax
            const ax = c.ajax || {};
            if (ax.badge) data.homeAjaxBadge = ax.badge;
            if (ax.title) data.homeAjaxTitle = ax.title;
            if (ax.paragraph) data.homeAjaxParagraph = ax.paragraph;
            if (ax.cta_text) data.homeAjaxCtaText = ax.cta_text;
            if (ax.cta_link) data.homeAjaxCtaLink = ax.cta_link;
            if (ax.features?.length) data.homeAjaxFeatures = ax.features.map((f: any) => ({
              title: typeof f === 'string' ? f : f.title || f.text || '',
              description: typeof f === 'string' ? '' : f.description || '',
            }));
            const axImg = normImg(ax.image);
            if (axImg) data.homeAjaxImage = axImg;
            // Ubicaciones
            const ub = c.ubicaciones || {};
            if (ub.badge) data.homeUbicacionesBadge = ub.badge;
            if (ub.title) data.homeUbicacionesTitle = ub.title;
            if (ub.subtitle) data.homeUbicacionesSubtitle = ub.subtitle;
            if (ub.cta_text) data.homeUbicacionesCtaText = ub.cta_text;
            if (ub.cta_link) data.homeUbicacionesCtaLink = ub.cta_link;
            // CTA Final
            const cf = c.cta_final || {};
            if (cf.badge) data.homeCtaFinalBadge = cf.badge;
            if (cf.title) data.homeCtaFinalTitle = cf.title;
            if (cf.subtitle) data.homeCtaFinalSubtitle = cf.subtitle;
            if (cf.cta1_text) data.homeCtaFinalCta1Text = cf.cta1_text;
            if (cf.cta1_link) data.homeCtaFinalCta1Link = cf.cta1_link;
            if (cf.cta2_text) data.homeCtaFinalCta2Text = cf.cta2_text;
            if (cf.cta2_link) data.homeCtaFinalCta2Link = cf.cta2_link;
            // Clientes
            const cl = c.clientes || {};
            if (cl.items?.length) data.homeClientesItems = cl.items.map((item: any) => ({
              name: item.name || '',
              initials: (item.initials || '').substring(0, 2).toUpperCase(),
              color: item.color || '#3B82F6',
              image: normImg(item.image) || ''
            }));
            if (cl.title) data.homeClientesTitle = cl.title;
            if (cl.subtitle) data.homeClientesSubtitle = cl.subtitle;
            if (cl.cta_text) data.homeClientesCtaText = cl.cta_text;
            if (cl.cta_link) data.homeClientesCtaLink = cl.cta_link;
            // DEBUG: log final image values
            console.log('[SSR][homepage-images] heroImage=', data.heroImage, 'nosotrosImage=', data.homeNosotrosImage, 'guardPodImage=', data.homeGuardPodImage);
          } catch { /* ignore parse errors, use defaults */ }
        }
        html = buildHomepage(data);
      }
    }
    // Combo: /servicios/{svc}/{loc}
    else if (path.match(/^\/servicios\/[^/]+\/[^/]+$/)) {
      const parts = path.split('/');
      data = await fetchComboPage(env, parts[2], parts[3]);
      if (data) html = buildDetailPage(data);
    }
    // Servicio: /servicios/{slug}
    else if (path.startsWith('/servicios/')) {
      const slug = path.split('/')[2];
      data = await fetchServicePage(env, slug);
      if (data) html = buildDetailPage(data);
    }
    // Ubicación: /ubicaciones/{slug}
    else if (path.match(/^\/ubicaciones\/[^/]+$/)) {
      const slug = path.split('/')[2];
      data = await fetchLocationPage(env, slug);
      if (data) html = buildDetailPage(data);
    }
    // Sector: /sectores/{slug}
    else if (path.match(/^\/sectores\/[^/]+$/)) {
      const slug = path.split('/')[2];
      data = await fetchSectorPage(env, slug);
      if (data) html = buildDetailPage(data);
    }
    // Gracias (post-form submission)
    else if (path === '/gracias') {
      const staticData = await getStaticPageData(env, 'gracias');
      html = buildGraciasPage(staticData);
    }

    // Hub: /servicios, /sectores, /ubicaciones
    else if (path === '/servicios' || path === '/sectores' || path === '/ubicaciones') {
      data = await fetchHubPage(env, path);
      if (data) {
        const hubSlug = 'hub-' + path.replace('/', '');
        const staticData = await getStaticPageData(env, hubSlug);
        html = buildHubPage(data, { _staticData: staticData });
      }
    }
    // Páginas estáticas con builders que leen de D1
    else {
      const staticPages: Record<string, string> = {
        '/nosotros': 'nosotros', '/guard-pod': 'guard-pod', '/ajax-systems': 'ajax-systems',
        '/contacto': 'contacto', '/cotizacion': 'cotizacion',
        '/privacidad': 'privacidad', '/terminos': 'terminos',
      };
      const slug = staticPages[path];
      if (slug) {
        const staticData = await getStaticPageData(env, slug);
        const builders: Record<string, (env?: any) => string> = {
          'nosotros': buildNosotrosPage, 'guard-pod': buildGuardPodPage,
          'ajax-systems': buildAjaxPage, 'contacto': buildContactoPage,
          'cotizacion': buildCotizacionPage, 'privacidad': buildPrivacidadPage,
          'terminos': buildTerminosPage,
        };
        const builder = builders[slug];
        if (builder) {
          html = builder({ _staticData: staticData });
        }
      }
    }

    if (html) {
      // Store in KV cache for future requests (ARCH-01)
      if (cacheKey) {
        ctx.waitUntil(setCache(env, cacheKey, html, 3600));
      }
      return new Response(html, {
        headers: {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': 'public, max-age=3600, s-maxage=86400',
          'CDN-Cache-Control': 'public, max-age=3600',
          'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; img-src 'self' data: https://guardman.oficinadesarrollo33.workers.dev https://staticmap.openstreetmap.de https://*.tile.openstreetmap.org https://img.youtube.com https://*.ytimg.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-src https://www.youtube.com; frame-ancestors 'none';",
          'X-Cache': 'MISS',
        },
      });
    }

    // 404
    return new Response(build404Page(), {
      status: 404,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; img-src 'self' data: https: https://img.youtube.com https://*.ytimg.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-src https://www.youtube.com; frame-ancestors 'none';",
      },
    });
  } catch (err: any) {
    console.error('[SSR] Page render error:', err.message);
    return new Response(build500Page(err.message), {
      status: 500,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; img-src 'self' data: https: https://img.youtube.com https://*.ytimg.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-src https://www.youtube.com; frame-ancestors 'none';",
      },
    });
  }
}

// ===================================================================
// HELPER BUILDERS (gracias, 500, 404)
// ===================================================================

function buildGraciasPage(staticData?: any): string {
  let title = '¡Gracias! — GuardMan Chile';
  let desc = 'Hemos recibido tu solicitud. Te contactaremos pronto.';
  let heroH = '¡Gracias por tu solicitud!';
  let heroS = 'Hemos recibido tu mensaje. Un experto en seguridad se comunicará contigo en menos de 24 horas.';
  if (staticData?.content_json) {
    try {
      const cj = typeof staticData.content_json === 'string' ? JSON.parse(staticData.content_json) : staticData.content_json;
      const seo = cj.seo || {};
      const c = cj.content || cj;
      if (seo.title) title = seo.title;
      if (seo.description) desc = seo.description;
      if (c.hero?.headline) heroH = c.hero.headline;
      if (c.hero?.subheadline) heroS = c.hero.subheadline;
    } catch {}
  }
  if (staticData?.meta_title) title = staticData.meta_title;
  if (staticData?.meta_description) desc = staticData.meta_description;
  if (staticData?.hero_heading) heroH = staticData.hero_heading;
  if (staticData?.hero_subheading) heroS = staticData.hero_subheading;
  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(desc)}"><link rel="canonical" href="${SITE_URL}/gracias">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg"></head><body>
${hdr('light')}
<main>
<section class="hero" style="background:var(--primary);padding:80px 0;text-align:center"><div class="container"><div style="font-size:3.5rem;margin-bottom:16px">✅</div><h1 style="color:#fff;font-size:2.5rem;font-weight:800">${esc(heroH)}</h1><p style="color:rgba(255,255,255,.85);font-size:1.15rem;max-width:550px;margin:12px auto 0">${esc(heroS)}</p></div></section>
<section class="bg-white" style="padding:64px 0"><div class="container" style="max-width:700px;text-align:center"><div style="background:var(--neutral);border-radius:var(--radius-xl);padding:40px 32px;margin-bottom:32px"><h2 style="font-size:1.25rem;font-weight:700;margin-bottom:16px">¿Qué sigue?</h2><div style="text-align:left;max-width:400px;margin:0 auto"><div style="display:flex;gap:12px;align-items:flex-start;margin-bottom:16px"><span style="background:var(--primary);color:#fff;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;flex-shrink:0">1</span><p style="margin:0;font-size:15px">Revisamos tu solicitud y la asignamos al especialista adecuado.</p></div><div style="display:flex;gap:12px;align-items:flex-start;margin-bottom:16px"><span style="background:var(--primary);color:#fff;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;flex-shrink:0">2</span><p style="margin:0;font-size:15px">Te contactamos por teléfono o email en menos de 24 horas.</p></div><div style="display:flex;gap:12px;align-items:flex-start"><span style="background:var(--primary);color:#fff;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;flex-shrink:0">3</span><p style="margin:0;font-size:15px">Recibes una cotización personalizada sin compromiso.</p></div></div></div><div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap"><a href="/" class="btn btn-primary">Volver al inicio</a><a href="/cotizacion" class="btn btn-outline">Solicitar otra cotización</a></div></div></section>
</main>
${ftr()}

<script src="/scripts/main.js"></script>
</body></html>`;
}

function build500Page(errorMsg?: string): string {
  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Error del Servidor — GuardMan Chile</title><meta name="description" content="Error interno del servidor. Estamos trabajando para resolverlo.">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg"></head><body>
${hdr('light')}
<main>
<section class="hero" style="background:var(--primary);padding:80px 0;text-align:center"><div class="container"><div style="font-size:3.5rem;margin-bottom:16px">⚠️</div><h1 style="color:#fff;font-size:2.2rem;font-weight:800">Error interno del servidor</h1><p style="color:rgba(255,255,255,.8);font-size:1.1rem;max-width:500px;margin:16px auto 0">Estamos experimentando problemas técnicos. Nuestro equipo ya está trabajando para resolverlo. Por favor, intenta de nuevo en unos minutos.</p><div style="margin-top:28px;display:flex;gap:12px;justify-content:center"><a href="/" class="btn btn-outline-light btn-lg">Volver al inicio</a><a href="/contacto" class="btn btn-primary btn-lg">Contactar soporte</a></div></div></section>
</main>
${ftr()}

<script src="/scripts/main.js"></script>
</body></html>`;
}

function build404Page(): string {
  return `<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>404 — Página no encontrada | GuardMan Chile</title><meta name="description" content="La página que buscas no existe.">${OG_BASE}${CRITICAL_CSS}<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}"><link rel="icon" type="image/svg+xml" href="/favicon.svg"></head><body>
${hdr('light')}
<main>
<section class="hero"><div class="container" style="text-align:center;padding:80px 0"><h1 style="font-size:2.5rem;font-weight:800">404 — Página no encontrada</h1><p style="color:rgba(255,255,255,.8);font-size:1.1rem;margin-top:12px">La página que buscas no existe o fue movida.</p><div style="margin-top:28px;display:flex;gap:12px;justify-content:center"><a href="/" class="btn btn-outline-light btn-lg">Volver al inicio</a><a href="/contacto" class="btn btn-primary btn-lg">Contactar</a></div></div></section>
</main>
${ftr()}

<script src="/scripts/main.js"></script>
</body></html>`;
}
