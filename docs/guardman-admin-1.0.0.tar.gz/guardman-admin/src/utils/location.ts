// GuardMan - Location Slugs Helper
// Centraliza la obtención de slugs de comunas desde la DB
// Evita hardcodear arrays en múltiples lugares

const LOCATION_SLUGS_FALLBACK = [
  'santiago-centro', 'huechuraba', 'lampa', 'quilicura', 'la-reina',
  'las-condes', 'lo-barnechea', 'vitacura', 'conchali', 'pudahuel',
  'renca', 'la-pintana', 'los-andes', 'san-felipe',
];

let cachedSlugs: string[] | null = null;

export async function getLocationSlugs(db: any): Promise<string[]> {
  if (cachedSlugs) return cachedSlugs;
  try {
    const result = await db.prepare('SELECT slug FROM locations ORDER BY sort, name').all();
    if (result.results && (result.results as any[]).length > 0) {
      cachedSlugs = (result.results as any[]).map((r: any) => r.slug);
      return cachedSlugs;
    }
  } catch {}
  return LOCATION_SLUGS_FALLBACK;
}

export function parseComboSlug(slug: string, locationSlugs: string[]): { serviceSlug: string; locationSlug: string } {
  for (const loc of locationSlugs) {
    if (slug.endsWith('-' + loc)) {
      return {
        serviceSlug: slug.substring(0, slug.length - loc.length - 1),
        locationSlug: loc,
      };
    }
  }
  return { serviceSlug: slug, locationSlug: '' };
}
