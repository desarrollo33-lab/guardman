# Plan CRM Comercial — GuardMan Admin

> **Fecha:** 2026-05-09
> **Estado:** Plan aprobado — listo para implementación
> **Principio fundamental:** El CRM es para **vendedores**, no para equipos de SEO

---

# PARTE 1: CONTEXTO COMPLETO

## 1.1 Qué es este proyecto

GuardMan es una empresa de seguridad privada en Chile (guardias, CCTV, monitoreo, control de accesos). Este repositorio es su **panel de administración** que incluye:

- **CMS** (editor de contenido del sitio web)
- **SSR** (renderizado del sitio público)
- **CRM** (gestión de leads y clientes) ← **este plan se enfoca aquí**
- **Intel Hub** (inteligencia de mercado basada en Serper/SEO)
- **Chat con IA** (agent framework de Cloudflare)
- **Media Library** (biblioteca de imágenes en R2)
- **Brand ADN** (identidad corporativa)

## 1.2 Arquitectura técnica (código real)

```
guardman-admin/
├── src/                          ← Backend (Cloudflare Worker)
│   ├── index.ts                  ← Router principal: API + SSR + Assets
│   ├── api/
│   │   ├── index.ts              ← Router modular (delega a routes/)
│   │   ├── routes/
│   │   │   ├── intel/            ← Intel + CRM (MEZCLADOS — problema)
│   │   │   │   ├── index.ts      ← Router de todas las rutas /api/intel/*
│   │   │   │   ├── crm.ts        ← Leads, clients, proposals, pipeline
│   │   │   │   ├── dashboard.ts  ← Dashboard unificado (SEO + CRM)
│   │   │   │   ├── helpers.ts    ← enrichLeadWithIntel (Serper)
│   │   │   │   ├── competitors.ts
│   │   │   │   ├── seo.ts
│   │   │   │   ├── reports.ts
│   │   │   │   ├── market.ts
│   │   │   │   └── crud.ts       ← CRUD genérico (serper_results, opportunities)
│   │   │   ├── cms.ts
│   │   │   ├── ai.ts
│   │   │   └── ...
│   │   └── services/
│   ├── agents/                    ← Durable Objects (AI agents)
│   ├── workflows/                 ← Cloudflare Workflows
│   ├── services/                  ← Servicios auxiliares
│   ├── ssr/                       ← Renderizado sitio público
│   ├── types/index.ts             ← Interfaces TypeScript compartidas
│   └── queues/                    ← Queue consumer
│
├── guardman-admin-ui/            ← Frontend (React SPA en /admin)
│   └── src/
│       ├── App.tsx                ← Router de vistas principales
│       ├── main.tsx               ← Entry point
│       ├── hooks/
│       │   ├── useApi.ts          ← Fetch wrapper con auth token
│       │   └── useWebSocket.ts
│       └── components/
│           ├── Layout/
│           │   ├── AppLayout.tsx  ← Shell con sidebar + topbar
│           │   └── Sidebar.tsx    ← Navegación: CMS, ADN, CRM, Intel, Media
│           ├── CRM/               ← COMPONENTES CRM ACTUALES
│           │   ├── CRMPage.tsx
│           │   ├── CRMDashboard.tsx
│           │   ├── CRMPipeline.tsx
│           │   ├── ClientListView.tsx
│           │   └── LeadDetail.tsx
│           ├── Intel/
│           ├── CMS/
│           ├── Chat/
│           └── Media/
│
├── public/                        ← Assets estáticos
│   ├── admin/                     ← Build del admin UI
│   └── styles/
│
├── sql/
│   └── migrations/intel-tables.sql ← Schema DB (leads, clients, etc.)
│
├── wrangler.jsonc                 ← Config Cloudflare
└── package.json
```

## 1.3 Stack técnico

| Capa | Tecnología |
|---|---|
| Runtime | Cloudflare Workers (un solo deploy) |
| DB | Cloudflare D1 (SQLite) |
| Storage | R2 (imágenes), KV (cache) |
| Frontend | React 19 + TypeScript + Vite + TailwindCSS 4 |
| IA | AI SDK + Cloudflare Agents (Durable Objects) |
| Search | Serper API (Google search results) |
| Estilos | CSS custom properties + Tailwind utility classes |

## 1.4 Patrón de autenticación

```typescript
// Todas las rutas API usan Bearer token
const token = localStorage.getItem('gm_token');
const headers = { 'Authorization': `Bearer ${token}` };

// Login: POST /api/login con email + password → devuelve token
// Token se guarda en localStorage
```

## 1.5 Patrón de uso de useApi

```typescript
// hook/useApi.ts expone una función `api()` que:
// 1. Agrega automáticamente el Authorization header
// 2. Parsea JSON de la respuesta
// 3. Lanza error si response.ok === false

const { api, loading } = useApi();
const data = await api('/api/intel/leads'); // → JSON parsed
```

---

# PARTE 2: DIAGNÓSTICO DEL CRM ACTUAL

## 2.1 Qué funciona (basado en código real)

### Backend: `src/api/routes/intel/crm.ts`

| Función | Endpoint | Estado |
|---|---|---|
| `handleListLeads` | `GET /api/intel/leads` | ✅ Filtra por status, service, location, search |
| `handleCreateLead` | `POST /api/intel/leads` | ✅ Campos completos + auto-enrich Serper |
| `handleGetLead` | `GET /api/intel/leads/:id` | ✅ Devuelve lead + interactions + proposals + intel |
| `handleUpdateLead` | `PUT /api/intel/leads/:id` | ✅ Update parcial de campos permitidos |
| `handleLeadCapture` | `POST /api/intel/leads/capture` | ✅ Lead público desde formulario web |
| `handleCreateInteraction` | `POST /api/intel/leads/:id/interactions` | ✅ Call/email/whatsapp/visit/note |
| `handleCreateProposal` | `POST /api/intel/leads/:id/proposals` | ✅ Con pricing + competitor ref |
| `handleListClients` | `GET /api/intel/clients` | ✅ Con conteo de servicios activos |
| `handleGetClient` | `GET /api/intel/clients/:id` | ✅ Client + services + interactions |
| `handleCreateClient` | `POST /api/intel/clients` | ✅ Con servicios y lead linking |
| `handleUpdateClient` | `PUT /api/intel/clients/:id` | ✅ Update parcial |
| `handlePipeline` | `GET /api/intel/pipeline` | ✅ Agrupa por stage con weighted value |

### Frontend: `guardman-admin-ui/src/components/CRM/`

| Componente | Líneas | Qué hace |
|---|---|---|
| `CRMPage.tsx` | ~65 | Tabs: pipeline, dashboard, clients. LeadDetail view |
| `CRMDashboard.tsx` | ~140 | KPIs, funnel, leads recientes, actividad |
| `CRMPipeline.tsx` | ~180 | Kanban 6 columnas, NewLeadModal, botones ← → |
| `LeadDetail.tsx` | ~300 | Info contacto, intel Serper, proposals, interactions |
| `ClientListView.tsx` | ~95 | Tabla simple de clientes |

### DB Schema: `sql/migrations/intel-tables.sql`

Tablas relevantes para CRM:
- `intel_leads` — Leads con status, contacto, servicio, valor estimado, probabilidad
- `intel_interactions` — Llamadas, emails, notas, visitas con outcome
- `intel_proposals` — Cotizaciones con monthly, setup, discount, validity
- `intel_clients` — Clientes activos con contrato, MRR, servicios
- `intel_client_services` — Servicios por cliente con precio unitario

## 2.2 Problemas identificados

### P1: CRM mezclado con Intel SEO
Todo está bajo `/api/intel/`. Las URLs contienen "intel" cuando deberían ser "crm":
```
GET /api/intel/leads        → debería ser /api/crm/leads
GET /api/intel/pipeline     → debería ser /api/crm/pipeline
GET /api/intel/clients      → debería ser /api/crm/clients
GET /api/intel/dashboard    → devuelve datos SEO + CRM mezclados
```

### P2: LeadDetail enfocado en SEO, no en ventas
El componente `LeadDetail.tsx` muestra:
- Panel "🧠 Intel de Mercado" con opportunity score, competitor density, guardman_position
- Competidores de Serper con positions y snippets
- Content gaps (queries sin presencia)

**Un vendedor necesita ver:**
- Último contacto y próximo follow-up
- Historial completo de conversaciones
- Estado de propuestas enviadas
- Notas del vendedor

### P3: ClientDetailView no existe
- Backend: `GET /api/intel/clients/:id` devuelve client + services + interactions ✅
- Frontend: `ClientListView.tsx` solo muestra tabla. **No hay link a detalle.** ❌
- Resultado: un vendedor no puede ver la ficha completa de un cliente.

### P4: No hay conversión lead → cliente
- Backend: `handleCreateClient` acepta `lead_id` y marca el lead como 'won' ✅
- Frontend: **No hay botón ni flujo para convertir.** ❌

### P5: Propuestas sin utilidad comercial real
- `NewProposalModal` en LeadDetail: 5 inputs numéricos (monthly, setup, discount, valid_until, notes)
- Sin template, sin PDF, sin items de servicio, sin preview

### P6: Dashboard mezclado
- `handleIntelDashboard` en `dashboard.ts` devuelve lead stats + client stats + market stats (SEO)
- No separa datos de ventas de datos de mercado

### P7: No hay sistema de tareas
- `intel_interactions` tiene campo `next_action` como texto libre
- No hay tabla de tareas con fechas, prioridades, estados

### P8: Pipeline sin drag & drop
- `CRMPipeline.tsx` usa botones ← → que aparecen en hover
- Funcional pero poco intuitivo

## 2.3 Lo que NO tocar

| Módulo | Razón |
|---|---|
| Intel Hub completo | Funciona para su propósito (SEO). Solo hay que separarlo del CRM |
| CMS Editor | Completo y funcional |
| Chat con IA | Funciona con agents framework. Se extenderá después |
| SSR público | No tiene relación con CRM |
| Media Library | Funcional |
| Brand ADN | Funcional |

---

# PARTE 3: VISIÓN DEL CRM COMERCIAL

## 3.1 Usuario objetivo

**Vendedor de GuardMan** — no técnico, no SEO. Usa el CRM diariamente para:
1. Ver qué leads nuevos llegaron
2. Contactar prospectos
3. Hacer follow-ups
4. Enviar cotizaciones
5. Convertir leads en clientes
6. Gestionar clientes existentes

## 3.2 Estructura propuesta

```
CRM (/admin → vista 'crm')
├── 📊 Dashboard
│   ├── KPIs comerciales (leads activos, won este mes, MRR, pipeline $)
│   ├── Follow-ups pendientes hoy
│   ├── Leads nuevos sin contactar
│   └── Actividad reciente
│
├── 📋 Pipeline (Kanban)
│   ├── 6 etapas: Nuevo → Contactado → Calificado → Propuesta → Ganado → Perdido
│   ├── Drag & drop para mover entre etapas
│   ├── Valor estimado en cada card
│   ├── Fecha de próximo follow-up visible
│   └── Click en card → LeadDetail
│
├── 👤 Contactos
│   ├── Lista con búsqueda (nombre, empresa, email, teléfono)
│   ├── Filtros: estado, servicio, ubicación
│   ├── Vista detalle completa ← NUEVO
│   │   ├── Ficha: nombre, empresa, RUT, email, teléfono
│   │   ├── Servicio solicitado (qué busca)
│   │   ├── Timeline de interacciones (centro del detalle)
│   │   ├── Propuestas enviadas
│   │   ├── Si es cliente: servicios contratados, contrato, MRR
│   │   └── Acciones: cambiar status, agregar interacción, crear propuesta
│   ├── Formulario crear contacto manual
│   └── Botón "Convertir a Cliente" (solo leads won)
│
├── 📄 Cotizaciones
│   ├── Lista de todas las propuestas
│   ├── Estados: draft, sent, accepted, rejected, expired
│   └── Generador con template (HTML imprimible/PDF)
│
└── 📞 Mi día
    ├── Tareas con fecha límite
    ├── Follow-ups pendientes
    └── Recordatorios
```

## 3.3 Separación CRM / Intel

### Rutas API

```
ACTUAL (mezclado):              PROPUESTO (separado):
/api/intel/leads                /api/crm/leads
/api/intel/leads/:id            /api/crm/leads/:id
/api/intel/pipeline             /api/crm/pipeline
/api/intel/clients              /api/crm/clients
/api/intel/dashboard            /api/crm/dashboard        ← solo datos comerciales
                                /api/intel/dashboard       ← solo datos SEO/mercado
                                /api/crm/tasks             ← NUEVO
                                /api/crm/proposals         ← NUEVO: lista global
```

### Estructura de archivos backend

```
src/api/routes/
├── crm/                         ← NUEVA carpeta
│   ├── index.ts                 ← Router /api/crm/*
│   ├── dashboard.ts             ← Solo KPIs comerciales
│   ├── leads.ts                 ← Mover de intel/crm.ts
│   ├── clients.ts               ← Mover de intel/crm.ts
│   ├── proposals.ts             ← Mover de intel/crm.ts + mejoras
│   ├── tasks.ts                 ← NUEVO
│   └── pipeline.ts              ← Mover de intel/crm.ts
│
├── intel/                       ← Se limpia
│   ├── index.ts                 ← Actualizar imports
│   ├── dashboard.ts             ← Solo datos SEO/mercado
│   ├── competitors.ts
│   ├── seo.ts
│   ├── reports.ts
│   ├── market.ts
│   ├── crud.ts                  ← Mantener (opportunities, serper-results)
│   └── helpers.ts               ← enrichLeadWithIntel (se mantiene)
```

### Estructura de archivos frontend

```
guardman-admin-ui/src/components/CRM/
├── CRMPage.tsx                  ← Actualizar tabs
├── CRMDashboard.tsx             ← Reemplazar con vista comercial pura
├── CRMPipeline.tsx              ← Mejorar con drag & drop
├── ClientListView.tsx           ← Agregar link a detalle
├── ClientDetailView.tsx         ← NUEVO (~250 líneas)
├── LeadDetail.tsx               ← Reescribir: quitar SEO, enfocar en ventas
├── ProposalListView.tsx         ← NUEVO
├── ProposalBuilder.tsx          ← NUEVO (template comercial)
├── ActivityView.tsx             ← NUEVO (Mi día + tareas)
└── shared/                      ← NUEVO (componentes reutilizables)
    ├── StatusBadge.tsx
    ├── fmt.ts
    └── EmptyState.tsx
```

---


---

# PARTE 4: PLAN DE IMPLEMENTACIÓN

## Reglas para el asistente de código

1. **Siempre leer el archivo completo antes de editarlo** — nunca asumir contenido
2. **Cada fase debe compilar** — no romper el build entre fases
3. **Mantener compatibilidad** — las rutas viejas `/api/intel/leads` deben seguir funcionando durante la transicion
4. **Seguir el patron de estilos existente** — usar las mismas clases CSS (`bg-[#1A2744]/60`, `border-white/5`, etc.)
5. **Seguir el patron de useApi** — usar `const { api } = useApi()` para todas las llamadas
6. **No modificar modulos no relacionados** — si toca Intel, CMS, Chat, SSR: NO tocar
7. **Comentar cada cambio con el numero de fase**
8. **TypeScript strict** — no usar `any` si se puede evitar
9. **Cada componente debe ser exportado nombradamente**
10. **Validar que las imports son correctas**

---

## CRM-0: Separar CRM de Intel en backend (1-2 sesiones)

**Objetivo:** Rutas `/api/crm/*` independientes de `/api/intel/*`. Los endpoints de CRM se mueven a una carpeta dedicada, manteniendo compatibilidad con las rutas viejas como aliases.

**Dependencias:** Ninguna (primera fase)

### Paso CRM-0.1: Crear estructura de carpetas

**Nueva carpeta:** `src/api/routes/crm/`

```
src/api/routes/crm/
├── index.ts                 ← Router /api/crm/*
├── dashboard.ts             ← Solo KPIs comerciales
├── leads.ts                 ← Mover de intel/crm.ts
├── clients.ts               ← Mover de intel/crm.ts
├── proposals.ts             ← Mover de intel/crm.ts
├── tasks.ts                 ← NUEVO
├── visits.ts                ← NUEVO (visitas tecnicas)
└── pipeline.ts              ← Mover de intel/crm.ts
```

### Paso CRM-0.2: Mover funciones

De `intel/crm.ts` redistribuir:

| Funcion | Archivo destino |
|---|---|
| `handleLeadCapture` | `crm/leads.ts` |
| `handleListLeads` | `crm/leads.ts` |
| `handleCreateLead` | `crm/leads.ts` |
| `handleGetLead` | `crm/leads.ts` |
| `handleUpdateLead` | `crm/leads.ts` |
| `handleListInteractions` | `crm/leads.ts` |
| `handleCreateInteraction` | `crm/leads.ts` |
| `handleListClients` | `crm/clients.ts` |
| `handleGetClient` | `crm/clients.ts` |
| `handleCreateClient` | `crm/clients.ts` |
| `handleUpdateClient` | `crm/clients.ts` |
| `handleListProposals` | `crm/proposals.ts` |
| `handleCreateProposal` | `crm/proposals.ts` |
| `handlePipeline` | `crm/pipeline.ts` |

Cada archivo importa helpers y cors:
```typescript
import { cors } from '../../../index';
import { enrichLeadWithIntel } from '../intel/helpers';
```

### Paso CRM-0.3: Crear `crm/index.ts`

```typescript
// src/api/routes/crm/index.ts
// FASE CRM-0: Router independiente para endpoints comerciales

import { cors } from '../../../index';
import { handleListLeads, handleCreateLead, handleGetLead, handleUpdateLead, handleLeadCapture, handleListInteractions, handleCreateInteraction } from './leads';
import { handleListClients, handleGetClient, handleCreateClient, handleUpdateClient } from './clients';
import { handleListProposals, handleCreateProposal } from './proposals';
import { handlePipeline } from './pipeline';

export const crmRoutes = [
  {
    pattern: /^\/api\/crm\//,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    handler: async (request: Request, env: any, ctx: any) => {
      const url = new URL(request.url);
      const path = url.pathname;
      const method = request.method;

      // LEADS
      if (path === '/api/crm/leads/capture' && method === 'POST') return await handleLeadCapture(request, env);
      if (path === '/api/crm/leads' && method === 'GET') return await handleListLeads(url, env);
      if (path === '/api/crm/leads' && method === 'POST') return await handleCreateLead(request, env);

      const leadIdMatch = path.match(/^\/api\/crm\/leads\/(\d+)$/);
      if (leadIdMatch && method === 'GET') return await handleGetLead(parseInt(leadIdMatch[1]), env);
      if (leadIdMatch && method === 'PUT') return await handleUpdateLead(parseInt(leadIdMatch[1]), request, env);

      // INTERACTIONS
      const interactMatch = path.match(/^\/api\/crm\/leads\/(\d+)\/interactions$/);
      if (interactMatch && method === 'GET') return await handleListInteractions(parseInt(interactMatch[1]), env);
      if (interactMatch && method === 'POST') return await handleCreateInteraction(parseInt(interactMatch[1]), request, env);

      // PROPOSALS
      const proposalMatch = path.match(/^\/api\/crm\/leads\/(\d+)\/proposals$/);
      if (proposalMatch && method === 'GET') return await handleListProposals(parseInt(proposalMatch[1]), env);
      if (proposalMatch && method === 'POST') return await handleCreateProposal(parseInt(proposalMatch[1]), request, env);

      // CLIENTS
      if (path === '/api/crm/clients' && method === 'GET') return await handleListClients(url, env);
      if (path === '/api/crm/clients' && method === 'POST') return await handleCreateClient(request, env);

      const clientIdMatch = path.match(/^\/api\/crm\/clients\/(\d+)$/);
      if (clientIdMatch && method === 'GET') return await handleGetClient(parseInt(clientIdMatch[1]), env);
      if (clientIdMatch && method === 'PUT') return await handleUpdateClient(parseInt(clientIdMatch[1]), request, env);

      // PIPELINE
      if (path === '/api/crm/pipeline' && method === 'GET') return await handlePipeline(env);

      return null;
    },
  },
];
```

### Paso CRM-0.4: Registrar en el router principal

**Archivo:** `src/api/index.ts`

Agregar import y spread en `allRoutes`, **antes** de intelRoutes:
```typescript
import { crmRoutes } from './routes/crm';

const allRoutes: Route[] = [
  // ... existente ...
  ...crmRoutes,    // ← NUEVO — antes de intelRoutes
  ...intelRoutes,
  // ... existente ...
];
```

### Paso CRM-0.5: Mantener compatibilidad (aliases)

En `intel/index.ts`, mantener las rutas viejas como redelegate a los handlers de CRM. Mantener `/api/intel/leads/capture` intacto (formularios web publicos).

### Paso CRM-0.6: Crear CRM Dashboard puro (sin SEO)

**Archivo nuevo:** `src/api/routes/crm/dashboard.ts`

Devuelve: leads por estado, clientes activos, pipeline ponderado, tasa de conversion, leads recientes, interacciones recientes, follow-ups vencidos, leads sin contactar > 4 horas, leads congelados (7 dias sin actividad), renovaciones proximas 60 dias.

### Verificacion CRM-0

1. `npx wrangler dev` — `/api/crm/leads` funciona, `/api/intel/leads` sigue funcionando
2. Dashboard nuevo devuelve solo datos comerciales
3. Formulario web `/api/intel/leads/capture` sigue capturando leads
4. Build sin errores

---

## CRM-1: Pipeline reestructurado + Cualificacion + Motivo Perdida + SLA visual (1-2 sesiones)

**Objetivo:** El pipeline refleja la realidad de la venta de seguridad. 6 etapas reales, campos de cualificacion obligatorios, motivo de perdida obligatorio, alertas SLA visuales.

**Dependencias:** CRM-0

### Paso CRM-1.1: Migracion D1 — nuevos campos

**Archivo SQL:** `sql/migrations/crm-commercial.sql`

```sql
ALTER TABLE intel_leads ADD COLUMN facility_type TEXT;
ALTER TABLE intel_leads ADD COLUMN facility_sqm INTEGER;
ALTER TABLE intel_leads ADD COLUMN has_current_security INTEGER DEFAULT 0;
ALTER TABLE intel_leads ADD COLUMN current_competitor TEXT;
ALTER TABLE intel_leads ADD COLUMN current_contract_end TEXT;
ALTER TABLE intel_leads ADD COLUMN shifts_needed INTEGER;
ALTER TABLE intel_leads ADD COLUMN armed_service INTEGER DEFAULT 0;
ALTER TABLE intel_leads ADD COLUMN no_contact_attempts INTEGER DEFAULT 0;
ALTER TABLE intel_leads ADD COLUMN loss_reason TEXT;
ALTER TABLE intel_leads ADD COLUMN loss_competitor TEXT;
ALTER TABLE intel_leads ADD COLUMN loss_price_ref REAL;
ALTER TABLE intel_leads ADD COLUMN last_activity_at TEXT;
ALTER TABLE intel_leads ADD COLUMN frozen_flag INTEGER DEFAULT 0;

CREATE TABLE IF NOT EXISTS intel_contact_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES intel_leads(id),
  attempt_number INTEGER,
  attempted_at TEXT DEFAULT (datetime('now')),
  result TEXT
);

CREATE INDEX IF NOT EXISTS idx_leads_status ON intel_leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_last_activity ON intel_leads(last_activity_at);
CREATE INDEX IF NOT EXISTS idx_leads_frozen ON intel_leads(frozen_flag);
```

### Paso CRM-1.2: Actualizar STAGES

**Archivo:** `guardman-admin-ui/src/components/CRM/CRMPipeline.tsx`

```typescript
const STAGES = [
  { id: 'new',              label: '🆕 Nuevo',              color: 'border-blue-500/30' },
  { id: 'contacted',         label: '📞 Contactado',          color: 'border-yellow-500/30' },
  { id: 'visit_scheduled',   label: '🏢 Visita Tecnica',      color: 'border-orange-500/30' },
  { id: 'proposal_sent',     label: '📋 Cotizacion Enviada',  color: 'border-purple-500/30' },
  { id: 'negotiation',       label: '🤝 Negociacion',         color: 'border-cyan-500/30' },
  { id: 'won',               label: '✅ Ganado',              color: 'border-green-500/30' },
  { id: 'lost',              label: '❌ Perdido',             color: 'border-red-500/30' },
] as const;
```

### Paso CRM-1.3: SLA visual en cards

Agregar a cada LeadCard:
- Dias desde ultima actividad (`last_activity_at`)
- Fondo rojo si >7 dias sin actividad
- Badge "No contesta" con contador (1/3, 2/3, 3/3)

### Paso CRM-1.4: Motivo de perdida obligatorio

**Backend:** En `handleUpdateLead` de `crm/leads.ts`:
```typescript
if (body.status === 'lost' && !body.loss_reason) {
  return Response.json({ ok: false, error: 'Debe seleccionar un motivo de perdida' }, { status: 400 });
}
```

**Frontend:** Modal obligatorio al mover a "Perdido" con:
- Dropdown: Precio / Competencia / Plazo / Postergado / No contactable / No califica
- Input: "¿Quien gano?" (competencia)
- Input: "Precio referencia ($)"

### Paso CRM-1.5: Campos de cualificacion en LeadDetail

Seccion "Cualificacion Comercial" entre Contacto y Servicio:
- Tipo de recinto (dropdown)
- Metros cuadrados
- ¿Tiene seguridad actual? (Sí/No)
- ¿Con quien? (competencia)
- ¿Cuando vence contrato? (fecha)
- ¿Cuantos turnos? (1, 2, 3, 4)
- ¿Armado o desarmado?

### Verificacion CRM-1

1. Pipeline muestra 7 columnas
2. Cards con fondo rojo si >7 dias sin actividad
3. Mover a "Perdido" → modal obligatorio
4. Seccion de cualificacion visible en leads nuevos
5. Build sin errores

---

## CRM-2: Visita Tecnica con checklist (1-2 sesiones)

**Objetivo:** Sin visita tecnica completa, no se puede avanzar a "Cotizacion Enviada". El CRM fuerza al vendedor a capturar datos operativos reales.

**Dependencias:** CRM-0, CRM-1 (etapa `visit_scheduled`)

### Paso CRM-2.1: Migracion D1 — tabla de visitas

Agregar a `sql/migrations/crm-commercial.sql`:

```sql
CREATE TABLE IF NOT EXISTS intel_visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES intel_leads(id),
  visit_date TEXT NOT NULL,
  facility_type TEXT,
  facility_sqm INTEGER,
  num_access_points INTEGER,
  has_current_security INTEGER DEFAULT 0,
  current_competitor TEXT,
  current_contract_end TEXT,
  shifts_needed INTEGER,
  armed_service INTEGER DEFAULT 0,
  risks_noted TEXT,
  notes TEXT,
  photos_count INTEGER DEFAULT 0,
  completed_at TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS intel_visit_photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  visit_id INTEGER REFERENCES intel_visits(id),
  r2_key TEXT NOT NULL,
  caption TEXT,
  photo_order INTEGER,
  created_at TEXT DEFAULT (datetime('now'))
);
```

### Paso CRM-2.2: Backend endpoints

**Archivo nuevo:** `src/api/routes/crm/visits.ts`

- `GET /api/crm/visits/:leadId` — obtener visita de un lead
- `POST /api/crm/visits` — crear o actualizar visita
- `POST /api/crm/visits/:visitId/photos` — subir foto a R2

**Regla de bloqueo:** En `handleUpdateLead`, si `status === 'proposal_sent'`, verificar que existe visita completada:
```typescript
if (body.status === 'proposal_sent') {
  const visit = await env.DB.prepare(
    'SELECT id FROM intel_visits WHERE lead_id = ? AND completed_at IS NOT NULL'
  ).bind(leadId).first();
  if (!visit) return Response.json({ ok: false, error: 'Debe completar la visita tecnica antes de enviar cotizacion' }, { status: 400 });
}
```

### Paso CRM-2.3: Frontend — VisitChecklist.tsx

**Archivo nuevo:** `guardman-admin-ui/src/components/CRM/VisitChecklist.tsx`

Checklist con campos obligatorios (tipo recinto + turnos), upload de fotos a R2, y boton "Completar Visita y Avanzar" que automaticamente mueve el lead a `proposal_sent`.

### Paso CRM-2.4: Integrar en LeadDetail

```typescript
{lead.status === 'visit_scheduled' && (
  <VisitChecklist leadId={leadId} onComplete={() => {
    api(`/api/crm/leads/${leadId}`, {
      method: 'PUT',
      body: JSON.stringify({ status: 'proposal_sent', last_activity_at: new Date().toISOString() }),
    });
    api(`/api/crm/leads/${leadId}`).then(setData);
  }} />
)}
```

### Verificacion CRM-2

1. Lead en "Visita Tecnica" muestra checklist
2. Campos minimos obligatorios
3. Subir fotos funciona (R2)
4. Completar visita → avanza a "Cotizacion Enviada"
5. Sin visita completada → bloquea avance
6. Build sin errores

---

## CRM-3: "Mi Dia" como homepage (1 sesion)

**Objetivo:** El vendedor abre el CRM y ve que hacer HOY. 5 bloques ordenados por prioridad.

**Dependencias:** CRM-0, CRM-1, CRM-2

### Paso CRM-3.1: Backend — metricas de Mi Dia

Agregar a `crm/dashboard.ts`:
- Leads sin contactar > 4 horas
- Follow-ups vencidos
- Visitas de hoy
- Cotizaciones a 48+ hrs sin seguimiento
- Leads congelados (7 dias sin actividad)
- Reintentos "No Contesta" programados
- Renovaciones proximas 60 dias

### Paso CRM-3.2: Crear CRMMiDia.tsx

**Archivo nuevo:** `guardman-admin-ui/src/components/CRM/CRMMiDia.tsx`

5 bloques:
1. **🔴 URGENTE** — Leads >4 hrs sin contactar + follow-ups vencidos
2. **📞 REINTENTAR** — "No contesta" programados para hoy
3. **🏢 VISITAS** — Evaluaciones agendadas hoy
4. **📋 SEGUIMIENTO** — Cotizaciones enviadas a 48+ hrs
5. **⚠️ CONGELADOS** — 7+ dias sin actividad

Cada item clickable → abre LeadDetail.

### Paso CRM-3.3: "Mi Dia" como tab por defecto

**Archivo:** `guardman-admin-ui/src/components/CRM/CRMPage.tsx`

```typescript
type CRMTab = 'miDia' | 'pipeline' | 'proposals' | 'clients' | 'dashboard';
const TABS = [
  { id: 'miDia', label: '📞 Mi dia' },
  { id: 'pipeline', label: 'Pipeline' },
  { id: 'proposals', label: 'Cotizaciones' },
  { id: 'clients', label: 'Clientes' },
  { id: 'dashboard', label: 'Dashboard' },
];
const [tab, setTab] = useState<CRMTab>('miDia'); // default = Mi Dia
```

### Verificacion CRM-3

1. CRM abre en "Mi Dia" por defecto
2. 5 bloques aparecen con datos correctos
3. Click → abre LeadDetail
4. Build sin errores

---

## CRM-4: Cotizacion tecnica + PDF + versionado (2 sesiones)

**Objetivo:** Cotizaciones con desglose por tipo de servicio, campos obligatorios (SLA, vigencia, ajuste anual), y versionado para negociaciones.

**Dependencias:** CRM-0, CRM-1, CRM-2

### Paso CRM-4.1: Migracion D1 — items de cotizacion

Agregar a `sql/migrations/crm-commercial.sql`:

```sql
CREATE TABLE IF NOT EXISTS intel_proposal_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  proposal_id INTEGER REFERENCES intel_proposals(id),
  service_type TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  total REAL NOT NULL,
  details TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

ALTER TABLE intel_proposals ADD COLUMN contract_period_months INTEGER;
ALTER TABLE intel_proposals ADD COLUMN payment_terms TEXT;
ALTER TABLE intel_proposals ADD COLUMN annual_adjustment TEXT;
ALTER TABLE intel_proposals ADD COLUMN sla_response_minutes INTEGER;
ALTER TABLE intel_proposals ADD COLUMN version INTEGER DEFAULT 1;
ALTER TABLE intel_proposals ADD COLUMN parent_proposal_id INTEGER;
ALTER TABLE intel_proposals ADD COLUMN executive_notes TEXT;
```

### Paso CRM-4.2: ProposalBuilder.tsx

**Archivo nuevo:** `guardman-admin-ui/src/components/CRM/ProposalBuilder.tsx`

Formulario con:
- Botones para agregar items por tipo: Guardias, CCTV, Accesos, Monitoreo, GuardPod, Ajax
- Cada item: cantidad, precio unitario, total automatico
- Detalles por tipo (ej: guardias → tipo uniforme, supervisor incluido)
- Condiciones comerciales: periodo minimo, forma de pago, ajuste anual, SLA, validez
- Total mensual calculado
- Boton "Guardar Borrador" y "Previsualizar"

### Paso CRM-4.3: ProposalPreview.tsx

**Archivo nuevo:** `guardman-admin-ui/src/components/CRM/ProposalPreview.tsx`

Template HTML imprimible con:
1. Membrete legal (logo, RUT, direccion, giro OS-10)
2. Datos del cliente
3. N° Cotizacion correlativo (COT-2025-0042)
4. Resumen Ejecutivo
5. Tabla de items (Servicio, Cantidad, Precio Unit., Total)
6. Inversion total mensual
7. SLA Garantizado
8. Condiciones Comerciales
9. Vigencia y espacio para firmas

Ctrl+P → guardar como PDF.

### Paso CRM-4.4: Versionado

Al crear propuesta, si el lead ya tiene propuestas:
- `version = max_version + 1`
- `parent_proposal_id` = id de la version anterior
- En UI: "Esta sera la version 2"

### Verificacion CRM-4

1. ProposalBuilder genera HTML con formato profesional
2. Ctrl+P → PDF con membrete legal
3. Versionado funciona (V1, V2, V3)
4. Build sin errores

---

## CRM-5: ClientDetailView + Conversion + Renovacion (1 sesion)

**Objetivo:** Ficha completa de cliente, conversion lead→cliente con contrato, alertas de renovacion a 60 dias.

**Dependencias:** CRM-0, CRM-4

### Paso CRM-5.1: ClientDetailView.tsx

Ficha de empresa, contacto principal, servicios contratados, contrato (inicio, fin, tipo, valor), alerta de renovacion si `contract_end` ≤ 60 dias.

### Paso CRM-5.2: ConvertToClientModal.tsx

Al convertir lead ganado, exige: fecha inicio, servicios, valor mensual, duracion contrato, supervisor operativo. Si no llena → no se puede convertir.

### Paso CRM-5.3: Alertas de renovacion

En dashboard: consultar clientes con `contract_end` en proximos 60 dias. En Mi Dia: bloque "🔄 RENOVACIONES PROXIMAS 60 DIAS".

### Verificacion CRM-5

1. Click en cliente → ficha completa
2. Lead won → "Convertir a Cliente" → exige contrato
3. Renovacion a 60 dias → aparece en Mi Dia
4. Build sin errores

---

## CRM-6: Dashboard comercial + ProposalListView (1 sesion)

**Objetivo:** Dashboard orientado a ventas con numeros grandes. Lista global de cotizaciones.

**Dependencias:** CRM-0, CRM-3, CRM-4

### Paso CRM-6.1: Reescribir CRMDashboard.tsx

KPIs: Nuevos este mes, Pipeline Activo, Pipeline $, Ganados este mes, Ingresos Mensuales Contratados (NO "MRR"). Sin graficos complejos.

### Paso CRM-6.2: ProposalListView.tsx

Lista global con filtro por estado, totales, click para preview PDF, boton "Duplicar como V2".

### Verificacion CRM-6

1. Dashboard solo KPIs comerciales
2. "Ingresos Mensuales Contratados"
3. ProposalListView con filtros
4. Build sin errores

---

# PARTE 5: REFERENCIA RAPIDA

## Pipeline de 6 etapas

```
🆕 Nuevo → 📞 Contactado → 🏢 Visita Tecnica → 📋 Cotizacion Enviada → 🤝 Negociacion → ✅ Ganado / ❌ Perdido
```

## SLA por etapa

| Etapa | SLA | Alerta |
|---|---|---|
| Nuevo | 4 horas habiles | Rojo si no contactado |
| Contactado | 48 horas (agendar visita) | Naranja |
| Visita Tecnica | Mismo dia (checklist) | Sin checklist → no avanza |
| Cotizacion Enviada | 48 hrs (seguimiento) | Naranja → Reintento dia 5, 10, 15 |
| Negociacion | 48 hrs (actividad) | Rojo si 7 dias sin actividad |
| Ganado | 24 horas (convertir) | Bloquea sin ficha de contrato |
| Perdido | Inmediato (motivo obligatorio) | No se puede dejar en blanco |

**Regla de oro:** 7 dias sin actividad → lead parpadea rojo.

## Motivos de perdida (obligatorio)

Precio / Competencia / Plazo / Postergado / No contactable / No califica

## Endpoints API

```
GET    /api/crm/dashboard                   → KPIs + Mi Dia data
GET    /api/crm/leads                       → Lista de leads
POST   /api/crm/leads                       → Crear lead
GET    /api/crm/leads/:id                   → Lead + interactions + proposals + visits
PUT    /api/crm/leads/:id                   → Update (con validaciones SLA)
POST   /api/crm/leads/:id/interactions      → Nueva interaccion
POST   /api/crm/leads/:id/proposals         → Nueva propuesta (con items)
GET    /api/crm/clients                     → Lista de clientes
GET    /api/crm/clients/:id                 → Cliente + services + interactions
POST   /api/crm/clients                     → Crear cliente
PUT    /api/crm/clients/:id                 → Update cliente
GET    /api/crm/pipeline                    → Pipeline por stage
GET    /api/crm/proposals                   → Todas las propuestas
GET    /api/crm/visits/:leadId              → Visita tecnica
POST   /api/crm/visits                      → Guardar visita
POST   /api/crm/visits/:visitId/photos      → Subir foto de visita
GET    /api/crm/tasks                       → Lista de tareas
POST   /api/crm/tasks                       → Crear tarea
PUT    /api/crm/tasks/:id                   → Update tarea

# Compatibilidad
POST   /api/intel/leads/capture             → Lead web (mantener)
GET    /api/intel/dashboard                 → Dashboard SEO (mantener)
```

## Comandos utiles

```bash
cd guardman-admin-ui && npx vite build
npx wrangler deploy
npx wrangler dev
npx wrangler d1 execute guardman-seo --remote --file=sql/migrations/crm-commercial.sql
```

---

# PARTE 6: CRONOLOGIA DE FASES

```
CRM-0 → Separar CRM de Intel en backend            (1-2 sesiones)
CRM-1 → Pipeline 6 etapas + cualificacion + perdida (1-2 sesiones)
CRM-2 → Visita Tecnica con checklist + fotos        (1-2 sesiones)
CRM-3 → "Mi Dia" como homepage                      (1 sesion)
CRM-4 → Cotizacion tecnica + PDF + versionado       (2 sesiones)
CRM-5 → ClientDetailView + conversion + renovacion  (1 sesion)
CRM-6 → Dashboard limpio + ProposalListView         (1 sesion)

Total estimado: 8-11 sesiones
```

**Dependencias:**
- CRM-0 es prerrequisito de todo
- CRM-1 depende de CRM-0
- CRM-2 depende de CRM-0 + CRM-1
- CRM-3 depende de CRM-0 + CRM-1 + CRM-2
- CRM-4 depende de CRM-0 + CRM-2
- CRM-5 depende de CRM-0 + CRM-4
- CRM-6 depende de CRM-0 + CRM-3 + CRM-4

**Paralelizables despues de CRM-0:**
- CRM-1 y CRM-4 pueden avanzar en paralelo
- CRM-5 y CRM-6 pueden avanzar en paralelo cuando CRM-4 este listo

---

# PARTE 7: CHECKLIST DE VALIDACION FINAL

### Pipeline y ventas
- [ ] Pipeline muestra 7 columnas (incluyendo Ganado/Perdido)
- [ ] Cards muestran dias sin actividad
- [ ] Lead >7 dias sin actividad → fondo rojo
- [ ] "No contesta" muestra contador de intentos
- [ ] Mover a "Perdido" exige motivo obligatorio
- [ ] Competencia que gano se registra al perder

### Cualificacion y Visita Tecnica
- [ ] Campos de cualificacion visibles en leads nuevos
- [ ] Lead en "Visita Tecnica" muestra checklist obligatorio
- [ ] Checklist exige: tipo recinto + turnos necesarios
- [ ] Fotos de visita se suben a R2
- [ ] Sin visita completada → no puede avanzar a "Cotizacion Enviada"

### "Mi Dia"
- [ ] CRM abre en "Mi Dia" por defecto
- [ ] Bloque 🔴 URGENTE: leads >4 hrs + follow-ups vencidos
- [ ] Bloque 📞 REINTENTAR: "No contesta" programados
- [ ] Bloque 🏢 VISITAS: evaluaciones de hoy
- [ ] Bloque 📋 SEGUIMIENTO: cotizaciones a 48+ hrs
- [ ] Bloque ⚠️ CONGELADOS: 7+ dias sin actividad
- [ ] Click en item → abre LeadDetail

### Cotizaciones
- [ ] ProposalBuilder permite items por tipo de servicio
- [ ] Preview genera HTML con membrete legal (RUT, OS-10)
- [ ] Ctrl+P guarda como PDF profesional
- [ ] Campos obligatorios: periodo, pago, ajuste, SLA, vigencia
- [ ] Versionado funciona (V1, V2, V3)
- [ ] ProposalListView con filtros

### Clientes
- [ ] Click en cliente → ClientDetailView completa
- [ ] Lead won → "Convertir a Cliente"
- [ ] Conversion exige: fecha inicio, servicios, valor, duracion, supervisor
- [ ] Contrato a 60 dias → alerta en "Mi Dia"

### Dashboard
- [ ] KPIs: Nuevos, Pipeline, Pipeline $, Ganados, Ingresos Mensuales
- [ ] Sin datos SEO
- [ ] "Ingresos Mensuales Contratados" (NO "MRR")
- [ ] Renovaciones 60 dias visibles

### Backend y compatibilidad
- [ ] Rutas `/api/crm/*` funcionan
- [ ] `/api/intel/leads/capture` sigue funcionando
- [ ] Aliases de compatibilidad funcionan
- [ ] Intel Hub funciona con rutas propias
- [ ] Build sin errores
- [ ] `wrangler deploy` exitoso
