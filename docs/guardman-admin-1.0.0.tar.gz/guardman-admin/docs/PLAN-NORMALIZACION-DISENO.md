# GuardMan Admin — Plan de Normalización de Diseño
## Análisis exhaustivo Open Design vs Sitio Público vs CMS Admin

**Fecha:** 2026-05-08  
**Estado:** Pendiente de ejecución

---

## DIAGNÓSTICO GENERAL

### Problema raíz
El sitio público tiene un **déficit de ~35 clases CSS** que se usan en las plantillas HTML pero NO existen en `site.css`. Esto causa que secciones enteras se vean sin formato, sin layout, o con textos invisibles. Adicionalmente, el dark theme se coló dentro de `site.css` (ya corregido parcialmente) y hay páginas que no incluyen `main.js` (menú móvil roto).

### Fuentes de verdad
1. **Open Design** (`cf058157`) — Diseño canónico: HTML + CSS + JSON de contenido
2. **CMS Admin** — Fuente de datos dinámicos (content_json, D1)
3. **SSR Workers** — Renderizado server-side que mezcla ambos

### Regla de oro
> **Open Design define el HTML/CSS canónico. El CMS define el contenido dinámico. El SSR debe respetar ambos sin inventar estilos inline ni colores hardcoded.**

---

## FASE 1 — CSS: Completar clases faltantes en site.css

### 1.1 Clases faltantes para páginas Light (nosotros, ubicaciones, servicios, sectores, combos)

| Clase | Usada en | Propósito | Estado |
|-------|----------|-----------|--------|
| `.stats-row` | nosotros, ubicaciones | Fondo oscuro stats | ❌ Falta |
| `.stats-grid` | nosotros, ubicaciones | Grid 4 columnas stats | ❌ Falta |
| `.stat-item` | nosotros, ubicaciones | Item stat individual | ❌ Falta |
| `.stat-value` | nosotros, ubicaciones | Número grande | ❌ Falta |
| `.stat-label` | nosotros, ubicaciones | Label bajo número | ❌ Falta |
| `.staff-section` | nosotros | Fondo oscuro sección staff | ❌ Falta |
| `.staff-check` | nosotros | Checklist staff | ❌ Falta |
| `.timeline-content` | nosotros | Contenido timeline item | ❌ Falta |
| `.values-grid` | nosotros | Grid 4 columnas valores | ❌ Falta |
| `.value-card` | nosotros | Card de valor | ❌ Falta |
| `.differentiators-grid` | nosotros | Grid 3 columnas difs | ❌ Falta |
| `.diff-card` | nosotros | Card diferenciador | ❌ Falta |
| `.diff-card-icon` | nosotros | Icono card dif | ❌ Falta |
| `.cert-grid` | nosotros | Grid certificaciones | ❌ Falta |
| `.trust-badge` | cotización | Badge de confianza | ❌ Falta |
| `.trust-badges` | cotización | Contenedor badges | ❌ Falta |
| `.whatsapp-cta` | cotización | Botón WhatsApp | ❌ Falta |

**Fuente canónica:** `nosotros.html` de Open Design tiene los estilos inline en `<style>`. Trasladar a `site.css`.

### 1.2 Clases faltantes para páginas Dark (guard-pod, ajax-systems)

Estas clases SÍ existen en `dark.css` pero hay que verificar que se cargue correctamente:

| Clase | Archivo fuente | Estado |
|-------|---------------|--------|
| `.hero-grid` | dark.css | ✅ En dark.css |
| `.hero-sub` | dark.css | ✅ En dark.css |
| `.hero-visual` | dark.css | ✅ En dark.css |
| `.hero-product` | dark.css | ✅ En dark.css |
| `.hero-stats` | dark.css | ✅ En dark.css |
| `.hero-stat-value/label` | dark.css | ✅ En dark.css |
| `.hero-trust` | dark.css | ✅ En dark.css |
| `.hero-trust-item` | dark.css | ✅ En dark.css |
| `.feature-grid` | dark.css | ✅ En dark.css |
| `.feature-card` | dark.css | ✅ En dark.css |
| `.feature-card-icon` | dark.css | ✅ En dark.css |
| `.problems-grid` | dark.css | ✅ En dark.css |
| `.problem-card` | dark.css | ✅ En dark.css |
| `.why-grid` | dark.css | ✅ En dark.css |
| `.why-card` | dark.css | ✅ En dark.css |
| `.section-dark` | dark.css | ✅ En dark.css |
| `.split-text` | dark.css | ✅ En dark.css |

**Acción:** Verificar que `buildGuardPodPage()` y `buildAjaxPage()` incluyan `<link rel="stylesheet" href="/styles/dark.css">`. ✅ Ya lo hacen.

### 1.3 Eliminar estilos inline y colores hardcoded del SSR

**Problema:** El `buildHomepage()` en `site-renderer.ts` tiene colores hardcoded como `style="color:#111827"` y `style="color:#6b7280"` en vez de usar clases CSS.

**Archivos afectados:**
- `src/ssr/site-renderer.ts` — `buildHomepage()`, `buildHubPage()`, helper pages en `index.ts`
- Principio: usar `var(--fg)`, `var(--muted)`, o clases como `.bg-white .section-title` en vez de colores inline

---

## FASE 2 — Página por página: Normalización vs Open Design

### 2.1 Homepage (`/`)

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero | Hero con imagen de fondo, badge, CTAs | ✅ OK | — |
| Sección Nosotros | Split con imagen + features-list | ✅ OK | Eliminar `style="color:..."` inline |
| Sección Servicios | Card grid con imágenes | ✅ OK | Eliminar `style="color:..."` inline |
| Sección Guard Pod | Split dark con feature-tiles | ✅ OK | Eliminar `style="color:..."` inline |
| Sección Sectores | Card grid con tags de color | ✅ OK | Eliminar `style="color:..."` inline |
| Sección Ajax | Split dark con checklist | ✅ OK | — |
| Sección Ubicaciones | Navy con coverage-split + mapa | ⚠️ Parcial | Falta mapa interactivo (usar static map o Leaflet) |
| Sección Clientes | Logos con grayscale | ✅ OK | — |
| CTA Final | CTA con badge OS-10 | ✅ OK | Eliminar `style="color:..."` inline |

### 2.2 `/nosotros` — Página estática

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero | Hero navy sin imagen | ✅ OK | — |
| Stats row | 4 stats (500+, 200+, 14, 8+) | ❌ SIN CSS | Agregar `.stats-row` y family a site.css |
| Historia + Timeline | Timeline vertical con años | ❌ CSS parcial | Completar `.timeline-content`, verificar `.timeline` |
| Valores | Grid 4 columnas | ❌ SIN CSS | Agregar `.values-grid`, `.value-card` |
| Diferenciadores | Grid 3 cols con iconos | ❌ SIN CSS | Agregar `.differentiators-grid`, `.diff-card`, `.diff-card-icon` |
| Certificaciones | Grid 3 cols con checks | ❌ SIN CSS | Agregar `.cert-grid` |
| Staff section | Split oscuro con checklist | ❌ SIN CSS | Agregar `.staff-section`, `.staff-check` |
| CTA | CTA oscuro | ✅ OK | — |

### 2.3 `/ubicaciones` — Hub

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero | Hero navy | ⚠️ Hero simple | Agregar stats row |
| Stats row | 4 stats (14, 6, 500+, 24/7) | ❌ No existe | Agregar stats |
| Zona cards | Cards por zona con dots | ⚠️ Simplificado | Open Design usa `.zone-card-grid` con descripciones |
| Mapa Leaflet | Mapa interactivo con markers | ❌ No existe | Agregar Leaflet o static map con markers |
| CTA | "¿No encuentras tu comuna?" | ❌ No existe | Agregar |

### 2.4 `/ubicaciones/{slug}` — Detalle ubicación

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero con badge zona | Badge con zone-dot + CTA | ✅ OK | — |
| Mapa Leaflet | Mapa centrado en la comuna | ❌ No existe | Agregar Leaflet inline |
| Service grid | Grid 2x3 de servicios | ✅ OK | — |
| Issues grid | Grid 3 cols problemas | ✅ OK | — |
| Staff block | Bloque oscuro con imagen | ✅ OK | — |
| FAQ | Accordion | ✅ OK | — |
| Sidebar | CTA + links + tags | ✅ OK | — |
| Related | Cards relacionadas | ✅ OK | — |

### 2.5 `/servicios` — Hub

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero + stats | Hero con badge + 4 stats | ❌ Hero sin stats | Agregar stats row |
| Filter bar | Chips de filtrado por sector | ❌ No existe | Agregar filter bar JS |
| Card grid | Cards con imágenes | ✅ OK | — |

### 2.6 `/servicios/{slug}` — Detalle servicio

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero con badge | Badge + 2 CTAs | ✅ OK | — |
| Intro | 2-3 párrafos | ✅ OK | — |
| Mapa | No aplica | — | — |
| Features | Grid 2 cols con checks | ✅ OK | — |
| Issues | Grid 3 cols | ✅ OK | — |
| Staff | Bloque oscuro | ✅ OK | — |
| Locations | Grid de comunas | ✅ OK | — |
| FAQ | Accordion | ✅ OK | — |
| Sidebar | CTA + links + tags | ✅ OK | — |

### 2.7 `/sectores` — Hub

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero + stats | Hero con stats | ❌ Hero sin stats | Agregar |
| Card grid | Cards con tags de color | ✅ OK | — |

### 2.8 `/sectores/{slug}` — Detalle sector

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero con tag color | Tag de sector | ✅ OK | — |
| Contenido | Intro + features + issues | ✅ OK | — |
| Sidebar | CTA + links + tags | ✅ OK | — |

### 2.9 `/guard-pod` — Página dark

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Header dark | Header con blur | ✅ OK | — |
| Hero con product | Hero-grid con imagen producto | ✅ OK | Verificar que dark.css carga |
| Features | Feature-grid cards | ✅ OK | — |
| Problems | Problems-grid | ✅ OK | — |
| Stats | Stats inline | ✅ OK | — |
| FAQ | FAQ dark | ✅ OK | — |
| Split | Split con imagen | ✅ OK | — |
| CTA band | CTA con glow | ✅ OK | — |
| Footer dark | Footer oscuro | ✅ OK | — |

### 2.10 `/ajax-systems` — Página dark

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero con trust | Trust items | ✅ OK | — |
| Feature grid | Cards con iconos | ✅ OK | — |
| Why grid | Por qué elegir | ✅ OK | — |
| Stats | Stats row | ✅ OK | — |
| FAQ | FAQ dark | ✅ OK | — |
| Split | Split con imagen | ✅ OK | — |
| CTA band | CTA con glow | ✅ OK | — |

### 2.11 `/contacto` — Página estática

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero | Hero navy | ✅ OK | — |
| Section grid | 2 cols: formulario + info | ✅ OK | Verificar estilos form |
| Contact cards | Cards con iconos | ✅ OK | — |
| Mapa | Mapa ubicación oficina | ❌ No existe | Agregar mapa Leaflet |

### 2.12 `/cotizacion` — Página estática

| Elemento | Open Design | Estado actual | Fix |
|----------|-------------|---------------|-----|
| Hero | Hero navy | ✅ OK | — |
| Trust badges | 4 badges de confianza | ❌ SIN CSS | Agregar `.trust-badge`, `.trust-badges` |
| Formulario | Formulario cotización | ✅ OK | — |
| WhatsApp CTA | Botón WhatsApp flotante | ❌ SIN CSS | Agregar `.whatsapp-cta` |

### 2.13 Páginas legales (`/privacidad`, `/terminos`)

| Elemento | Estado actual | Fix |
|----------|---------------|-----|
| Contenido | ✅ OK | — |
| Estilos | ✅ OK (usa shared.css) | — |

---

## FASE 3 — JavaScript: Menú móvil + Leaflet

### 3.1 Menú móvil (`main.js`)

**Problema:** `main.js` existe en `/public/scripts/main.js` pero **NINGUNA página lo incluye**. El header renderiza un botón `☰` que no hace nada.

**Acción:**
- Agregar `<script src="/scripts/main.js"></script>` antes de `</body>` en TODOS los builders:
  - `buildDetailPage()`
  - `buildHomepage()`
  - `buildHubPage()`
  - `buildNosotrosPage()`, `buildGuardPodPage()`, `buildAjaxPage()`
  - `buildContactoPage()`, `buildCotizacionPage()`
  - `buildPrivacidadPage()`, `buildTerminosPage()`
  - `buildBlogListing()`, `buildBlogPost()`
  - `buildGraciasPage()`, `build404Page()`, `build500Page()`

### 3.2 Estilos del menú móvil abierto

**Problema:** `main.js` hace `nav.classList.toggle('open')` pero no hay CSS para `nav.open`.

**Acción:** Agregar a `site.css`:
```css
nav.open {
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 64px;
  left: 0;
  right: 0;
  bottom: 0;
  background: var(--surface);
  z-index: 40;
  padding: 24px 16px;
  gap: 8px;
  overflow-y: auto;
}
nav.open .dropdown-menu {
  position: static;
  opacity: 1;
  visibility: visible;
  box-shadow: none;
  margin-top: 4px;
}
nav.open .nav-link {
  padding: 12px 0;
  font-size: 18px;
}
```

### 3.3 Mapas Leaflet (ubicaciones + ubicacion + contacto)

**Acción:**
- En `/ubicaciones`: agregar mapa con markers de todas las comunas (copiar JS de Open Design `ubicaciones.html`)
- En `/ubicaciones/{slug}`: agregar mapa centrado en la comuna (copiar JS de Open Design `ubicacion.html`)
- En `/contacto`: agregar mapa de la oficina central
- Cargar Leaflet CSS+JS desde CDN: `<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">` y `<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js">`
- Fallback: `<noscript>` con static map image

---

## FASE 4 — Estructura: Eliminar código duplicado y normalizar

### 4.1 Headers inline en index.ts

**Problema:** Las páginas `buildGraciasPage()`, `buildBlogListing()`, `buildBlogPost()`, `build404Page()`, `build500Page()` en `index.ts` tienen el header **hardcodeado inline** sin usar `hdr()` del renderer. Esto significa:
- No tienen menú dropdown (Servicios, Ubicaciones, Sectores)
- No cargan datos de nav desde D1
- No son consistentes con el resto

**Acción:** Mover estas páginas al sistema de renderizado de `site-renderer.ts` o al menos usar `hdr('light')` + `ftr()`.

### 4.2 Cache bust consistente

**Problema:** El timestamp `?v=` está hardcodeado en 12 lugares de `site-renderer.ts` y en `index.ts`.

**Acción:** Extraer a una constante `const CSS_V = '1778225742'` y usarla en todos los builders.

### 4.3 URLs canónicas

**Problema:** Todas las URLs canónicas usan `https://guardman.cl` pero el dominio real es `guardman.oficinadesarrollo33.workers.dev`.

**Acción:** Extraer `SITE_URL` como variable de entorno o constante y usarla en todos los builders.

---

## FASE 5 — CSS: Refinar y documentar

### 5.1 Estructura final de CSS

```
site.css (277 líneas — light theme)
  ├── @font-face (Inter)
  ├── :root tokens
  ├── Reset
  ├── Buttons
  ├── Header (light)
  ├── Header Dark (.header-dark)
  ├── Breadcrumb
  ├── Section labels/titles
  ├── Hero
  ├── Zone dots + Sector tags
  ├── Content grid (detalle)
  ├── Features grid
  ├── Issues grid
  ├── Service grid
  ├── Staff block
  ├── Locations grid
  ├── FAQ
  ├── Sidebar
  ├── Related
  ├── CTA band
  ├── Footer
  ├── Card grid (hubs)
  ├── Tags + Filter bar
  ├── Background variants
  ├── Split layout
  ├── Forms (contacto/cotización)
  ├── Contact info cards
  ├── Homepage sections
  │   ├── Features list
  │   ├── Feature tiles
  │   ├── Checklist
  │   ├── Clients
  │   ├── Coverage split
  │   ├── Zone cards
  │   └── CTA final
  ├── Nosotros sections     ← AGREGAR
  │   ├── Stats row/grid
  │   ├── Timeline
  │   ├── Values grid
  │   ├── Differentiators
  │   ├── Certificaciones
  │   └── Staff section
  ├── Cotización sections   ← AGREGAR
  │   ├── Trust badges
  │   └── WhatsApp CTA
  ├── Mobile nav            ← AGREGAR
  └── Responsive

dark.css (archivo separado — solo guard-pod y ajax)
  ├── Dark theme overrides
  ├── Hero dark
  ├── Feature cards dark
  ├── Problems dark
  ├── FAQ dark
  ├── Stats dark
  ├── CTA dark
  ├── Footer dark
  └── Section dark utility
```

### 5.2 Regla de colores

**Principio:** NUNCA usar colores inline (`style="color:#111827"`). Siempre usar variables CSS o clases.

| Contexto | Variable/Clase | Valor |
|----------|---------------|-------|
| Texto principal (light) | `var(--fg)` | `#0D0D0D` |
| Texto secundario (light) | `var(--muted)` | `#6C757D` |
| Título en fondo blanco | `var(--fg)` | `#0D0D0D` |
| Título en fondo oscuro | `#fff` | — |
| Texto en fondo oscuro | `rgba(255,255,255,.85)` | — |
| Subtítulo en fondo oscuro | `rgba(255,255,255,.6)` | — |

---

## ORDEN DE EJECUCIÓN

### Sprint 1 — CSS + Mobile (impacto inmediato)
1. ✅ ~~Eliminar dark theme de site.css~~ (HECHO)
2. Agregar ~17 clases CSS faltantes para nosotros/cotización
3. Agregar CSS para menú móvil `nav.open`
4. Agregar `<script src="/scripts/main.js">` en todos los builders
5. Deploy y verificar

### Sprint 2 — Mapas + Hub pages
6. Agregar Leaflet en `/ubicaciones` (mapa general con markers)
7. Agregar Leaflet en `/ubicaciones/{slug}` (mapa por comuna)
8. Agregar Leaflet en `/contacto` (mapa oficina)
9. Agregar stats rows en hubs (`/servicios`, `/ubicaciones`, `/sectores`)
10. Deploy y verificar

### Sprint 3 — Cleanup + Normalización
11. Eliminar todos los `style="color:#..."` inline del SSR
12. Mover páginas inline de `index.ts` a usar `hdr()` + `ftr()`
13. Extraer CSS_V y SITE_URL como constantes
14. Normalizar URLs canónicas
15. Deploy y verificar

### Sprint 4 — Verificación final
16. Verificar cada página vs Open Design visualmente
17. Test responsive mobile
18. Test menú móvil en todas las páginas
19. Test formularios contacto/cotización
20. Performance check (Lighthouse)

---

## ARCHIVOS A MODIFICAR

| Archivo | Fase | Cambios |
|---------|------|---------|
| `public/styles/site.css` | 1 | Agregar ~17 clases + mobile nav |
| `public/scripts/main.js` | 1 | Ya existe, solo agregar a HTML |
| `src/ssr/site-renderer.ts` | 1,3 | Agregar `<script>`, eliminar inline styles, extraer constantes |
| `src/index.ts` | 2,3 | Mover páginas inline, agregar Leaflet, agregar main.js |
| `src/ssr/site-data.ts` | 2 | Agregar coordenadas para mapas |
| `src/ssr/nosotros-html.ts` | 1 | Verificar clases usadas |
| `src/ssr/guardpod-html.ts` | 1 | Verificar dark.css carga |
| `src/ssr/ajax-html.ts` | 1 | Verificar dark.css carga |
| `src/ssr/contacto-html.ts` | 2 | Agregar mapa |
| `src/ssr/cotizacion-html.ts` | 1 | Agregar trust badges CSS |

---

## NOTAS CMS

El CMS Admin (`/admin`) NO necesita cambios en este plan. El CMS:
- Define la estructura `content_json` que el SSR consume
- Tiene su propio sistema de rutas (React SPA)
- Los cambios de CSS/HTML del sitio público no afectan al admin
- El CMS ya tiene el modelo correcto de datos (hero, nosotros, guardpod, ajax, etc.)

**Sin embargo**, si en el futuro se agregan secciones al CMS (ej: stats editables, timeline editable, certificaciones editables), los builders SSR deberán actualizarse para leer esos campos de `content_json`.
