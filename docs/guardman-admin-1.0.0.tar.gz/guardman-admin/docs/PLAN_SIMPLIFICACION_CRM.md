# Plan de Simplificación del CRM — GuardMan Admin

**Fecha:** 2026-06-04
**Versión:** 1.0
**Contexto:** El CRM actual tiene 16 archivos (~3,000 LOC) con features orientadas a un equipo de ventas enterprise. GuardMan tiene un equipo comercial de 1-3 personas. Se necesita solo lo esencial.

---

## 1. Diagnóstico del CRM Actual

### 1.1 Arquitectura Actual

```
guardman-admin-ui/src/components/CRM/
├── CRMPage.tsx              Tabs: Mi Día, Pipeline, Cotizaciones, Clientes, Dashboard
├── CRMDashboard.tsx         KPIs + embudo + leads recientes + actividad
├── CRMPipeline.tsx          Kanban con columnas por etapa
├── CRMMiDia.tsx             Agenda diaria del vendedor
├── LeadDetail.tsx           Ficha completa de lead + tabs internos
├── ClientListView.tsx       Lista de clientes con filtros
├── ClientDetailView.tsx     Ficha de cliente
├── ConvertToClientModal.tsx Modal para convertir lead → cliente
├── ProposalBuilder.tsx      Formulario de cotización
├── ProposalListView.tsx     Lista de cotizaciones
├── VisitChecklist.tsx       Checklist de visita técnica
├── MockDataLoader.tsx       Carga datos de prueba (demo mode)
├── CRMDashboard.test.tsx
├── CRMPage.test.tsx
├── CRMPipeline.test.tsx
├── MockDataLoader.test.tsx

hooks/
├── useApi.ts                Hook base con auth
├── useRealApi.ts            Hook con fetch al Worker
├── useMockApi.ts            Hook con datos mock (demo mode)

mocks/
└── crm-data.ts              800 LOC de datos mock para demo
```

### 1.2 Tablas D1 del CRM

```sql
crm_leads        — leads con status, datos de contacto, empresa, valor estimado
crm_clients      — clientes activos, revenue, fechas de contrato
crm_proposals    — cotizaciones vinculadas a leads
crm_tasks        — tareas (seguimiento, llamadas, visitas)
crm_visits       — visitas técnicas con checklist y fotos
crm_interactions — historial de interacciones (llamadas, emails, reuniones)
```

### 1.3 Problemas Identificados

| Problema | Gravedad | Descripción |
|----------|----------|-------------|
| **Sobrecarga de features** | 🔴 Alto | Tasks, visits, interactions son 3 tablas para tracking que un equipo pequeño hace en WhatsApp/Excel |
| **Doble entrada de datos** | 🔴 Alto | ConvertToClientModal duplica datos del lead. Misma info en dos lugares. |
| **Mi Día aislado** | 🟡 Medio | La agenda diaria es una vista separada que no comparte datos con Dashboard |
| **MockDataLoader visible** | 🟡 Medio | El botón de cargar datos mock está en producción, no solo en dev |
| **Kanban sin bordes de color** | 🟡 Medio | Las columnas del pipeline no tienen diferenciación visual por etapa (gap auditoría v13) |
| **Hooks triplicados** | 🟡 Medio | `useApi`, `useRealApi`, `useMockApi` → un solo hook con switch bastaría |
| **Código muerto** | 🟢 Bajo | `PipelineBar.tsx` en Shared/ y UI/ nunca se usa |

---

## 2. CRM Simplificado — Diseño Propuesto

### 2.1 Principios de Diseño

1. **Una sola pantalla para la operación diaria** — El vendedor abre el CRM y ve todo lo que necesita
2. **Pipeline es el centro** — El Kanban es la vista principal. De ahí se hace todo.
3. **Menos tablas, más objetos** — Tasks y visits son arrays dentro del lead, no tablas separadas
4. **Sin modales innecesarios** — Cambiar status es un dropdown, no un modal
5. **Demo mode invisible** — Solo para desarrollo, no en UI de producción

### 2.2 Vistas Finales (6 componentes)

```
src/components/admin/crm/
├── CRMDashboard.astro        Dashboard + agenda diaria fusionados
├── CRMPipeline.tsx           Kanban interactivo (isla React)
├── LeadDetail.tsx            Ficha de lead con visitas y cotizaciones embebidas
├── ClientList.tsx            Lista simple de clientes
├── ClientDetail.tsx          Ficha de cliente
└── ProposalBuilder.tsx       Formulario de cotización

~1,200 LOC total (-60% vs actual)
```

### 2.3 CRMDashboard — Vista Principal

**Lo que muestra:**
```
┌──────────────────────────────────────────────────────────────┐
│ 💼 CRM — GuardMan Chile          📅 Miércoles 4 de junio     │
├──────────┬──────────┬──────────┬──────────┬─────────────────┤
│ 🆕 Nuevos│ 📞 Contact│ 💼 Pipe $│ 🏆 Ganados│ 💰 Revenue/mes  │
│    12    │     8    │ $4.2M   │     3    │    $1.8M        │
├──────────┴──────────┴──────────┴──────────┴─────────────────┤
│                                                              │
│ 📋 HOY                                         [Ver Pipeline]│
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ 09:00  Llamar a Juan Pérez — Seguridad Residencial       │ │
│ │ 11:00  Visita técnica — Comercial Las Condes             │ │
│ │ 14:00  Enviar cotización — Bodegas San Bernardo          │ │
│ │ 16:00  Seguimiento — Restaurant Providencia              │ │
│ └──────────────────────────────────────────────────────────┘ │
│                                                              │
│ 🆕 Leads Recientes                          [Ver Pipeline]   │
│ ┌──────────────────────────────────────────────────────────┐ │
│ │ María González — Guardias OS-10 — Las Condes — $350K     │ │
│ │ Empresa ABC — CCTV — Santiago Centro — $1.2M             │ │
│ │ Carlos Ruiz — Control Accesos — Vitacura — consulta      │ │
│ └──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

**Fuente de datos:** `GET /api/crm/dashboard` (igual que ahora) + tasks del día filtradas.

### 2.4 CRMPipeline — Kanban

**Columnas:**
```
NUEVO → CONTACTADO → VISITA TÉCNICA → COTIZACIÓN → NEGOCIACIÓN → GANADO
                                                                    ↘ PERDIDO
```

**Cada columna tiene:**
- Color de borde superior distintivo (gap de auditoría corregido):
  - Nuevo: `border-t-blue-500`
  - Contactado: `border-t-yellow-500`
  - Visita Técnica: `border-t-orange-500`
  - Cotización: `border-t-purple-500`
  - Negociación: `border-t-cyan-500`
  - Ganado: `border-t-green-500`
  - Perdido: `border-t-red-500`
- Contador de leads
- Suma de valores estimados

**Cada card de lead muestra:**
- Nombre del contacto
- Empresa (si existe)
- Servicio + Ubicación
- Valor estimado
- Fecha de última interacción
- Badge de dificultad (fácil/medio/difícil)

**Acciones en la card:**
- Click → abre LeadDetail
- Drag & drop → cambia de etapa
- Botón rápido: llamar, email, WhatsApp (si configurado)

### 2.5 LeadDetail — Ficha de Lead

**Secciones colapsables:**
```
┌─────────────────────────────────────────────────────┐
│ ← Volver            Lead #42 — Juan Pérez           │
│                      [Nuevo ▼]  [⚡ Acción rápida]  │
├─────────────────────────────────────────────────────┤
│                                                      │
│ 📋 DATOS DE CONTACTO                                 │
│ Nombre: Juan Pérez                                   │
│ Email: juan@example.com     Tel: +56 9 1234 5678     │
│ Empresa: Constructora XYZ                            │
│                                                      │
│ 🎯 SERVICIO SOLICITADO                               │
│ Guardias de Seguridad en Las Condes                  │
│ Valor estimado: $350.000/mes                         │
│ Fuente: Formulario web                              │
│                                                      │
│ 📝 HISTORIAL                                         │
│ 2026-06-03 — Llamada — Interesado, pide cotización   │
│ 2026-06-02 — Email — Info enviada                    │
│ 2026-06-01 — Web — Formulario de contacto            │
│                                                      │
│ 🏢 VISITA TÉCNICA                                    │
│ [Programada: 5 junio 10:00]                         │
│ Checklist: □ Evaluar perímetro  □ Contar accesos     │
│            □ Medir mts lineales  □ Fotos fachada     │
│                                                      │
│ 📄 COTIZACIONES                                      │
│ Cotización #12 — $350.000/mes — Pendiente            │
│ [+ Nueva cotización]                                 │
│                                                      │
│ ✅ TAREAS                                            │
│ ☐ Llamar para confirmar visita — 4 junio            │
│ ☐ Enviar brochure — 3 junio                         │
│ [+ Agregar tarea]                                    │
└─────────────────────────────────────────────────────┘
```

**Cambio de etapa:** Dropdown con opciones. Al seleccionar "Ganado", se crea automáticamente el cliente (sin modal ConvertToClient).

### 2.6 ClientList — Lista de Clientes

**Vista simple:**
```
┌──────────────────────────────────────────────────────┐
│ 🏢 Clientes                      [🔍 Buscar] [+Nuevo]│
├──────────────────────────────────────────────────────┤
│ Cliente          │ Servicio        │ Revenue/mes │   │
│ Constructora XYZ │ Guardias OS-10  │ $350.000    │ ✅ │
│ Comercial ABC    │ CCTV 24/7       │ $1.200.000  │ ✅ │
│ Residencial 123  │ Control Accesos │ $180.000    │ ⚠️ │
└──────────────────────────────────────────────────────┘
```

Columnas: nombre, servicio contratado, revenue mensual, estado (activo, en renovación, cancelado).

### 2.7 ClientDetail — Ficha de Cliente

**Secciones:**
- Datos de la empresa
- Servicios contratados (historial)
- Revenue mensual + total anual
- Fechas de contrato (inicio, renovación)
- Documentos (contrato, facturas — links a R2)
- Contactos asociados

### 2.8 ProposalBuilder — Cotización

**Formulario simple:**
- Lead asociado (autoseleccionado si viene de LeadDetail)
- Servicios incluidos (checkboxes de los 9 servicios)
- Ubicación(es)
- Cantidad de guardias
- Tipo de jornada (diurno, nocturno, 24/7, 4x4, 6x1)
- Valor mensual estimado
- Validez de la cotización (30, 60, 90 días)
- Notas internas
- Estado (borrador, enviada, aceptada, rechazada)

**Salida:** La cotización se guarda en D1. No se genera PDF (por ahora). Si se necesita, se puede agregar después.

---

## 3. API Backend — Cambios

### 3.1 Endpoints que se Mantienen

```
GET    /api/crm/dashboard
GET    /api/crm/leads
POST   /api/crm/leads
GET    /api/crm/leads/:id
PUT    /api/crm/leads/:id
GET    /api/crm/clients
POST   /api/crm/clients
GET    /api/crm/clients/:id
PUT    /api/crm/clients/:id
GET    /api/crm/pipeline
GET    /api/crm/proposals
POST   /api/crm/leads/:id/proposals
```

### 3.2 Endpoints que se Fusionan/Eliminan

| Endpoint actual | Acción |
|-----------------|--------|
| `GET /api/crm/leads/:id/interactions` | → Incluido en `GET /api/crm/leads/:id` |
| `POST /api/crm/leads/:id/interactions` | → Incluido en `PUT /api/crm/leads/:id` |
| `GET /api/crm/tasks` | → Incluido en `GET /api/crm/leads/:id` |
| `POST /api/crm/tasks` | → Incluido en `PUT /api/crm/leads/:id` |
| `PUT /api/crm/tasks/:id` | → Incluido en `PUT /api/crm/leads/:id` |
| `GET /api/crm/visits/:leadId` | → Incluido en `GET /api/crm/leads/:id` |
| `POST /api/crm/visits` | → Incluido en `PUT /api/crm/leads/:id` |
| `POST /api/crm/visits/:id/photos` | → `POST /api/crm/leads/:id/photos` |
| `POST /api/crm/leads/capture` | ❌ Eliminar (duplicado de `/api/intel/leads/capture`) |

### 3.3 Cambios en D1

**Tablas que se mantienen:**
- `crm_leads` — agregar columnas JSON: `tasks`, `visit`
- `crm_clients` — sin cambios
- `crm_proposals` — sin cambios

**Tablas que se eliminan (o se dejan pero no se usan):**
- `crm_tasks` — los datos migran a `crm_leads.tasks` (JSON array)
- `crm_visits` — los datos migran a `crm_leads.visit` (JSON object)
- `crm_interactions` — se mantiene como historial, pero la UI accede vía lead detail

**Migración de datos (opcional, Fase 4):**
```sql
-- No es necesario migrar datos existentes si son pocos.
-- Si hay datos valiosos, script puntual en Fase 4.
```

---

## 4. Plan de Ejecución (Dentro de Fase 3)

### Paso 3.3.1 — API Backend (1 sesión)
- Agregar columnas `tasks` y `visit` como JSON a `crm_leads`
- Modificar `PUT /api/crm/leads/:id` para aceptar tasks y visit
- Incluir tasks/visit/interactions en `GET /api/crm/leads/:id`
- Marcar endpoints obsoletos como deprecated (no eliminar aún)

### Paso 3.3.2 — Componentes Astro (2 sesiones)
- `CRMDashboard.astro` — Astro puro, fetch al cargar
- `CRMPipeline.tsx` — Isla React con drag & drop
- `LeadDetail.tsx` — Isla React con secciones colapsables
- `ClientList.tsx` — Isla React con tabla simple
- `ClientDetail.tsx` — Isla React
- `ProposalBuilder.tsx` — Isla React con formulario

### Paso 3.3.3 — Integración y Testing (1 sesión)
- Conectar todos los componentes al backend
- Flujo completo: crear lead → pipeline → cotización → cliente
- Demo mode para desarrollo (datos mock inline, sin MockDataLoader UI)

---

## 5. Validación con Usuario (Rodrigo - CEO)

**Preguntas a validar antes de implementar:**
1. ¿Usas la vista "Mi Día" o prefieres todo en el Dashboard?
2. ¿Las visitas técnicas tienen checklist o es más informal?
3. ¿Las cotizaciones necesitan PDF o con el valor en pantalla basta?
4. ¿Necesitas tasks separadas o el historial de interacciones es suficiente?
5. ¿Qué métricas del dashboard son las que realmente miras?
6. ¿Hay algo del CRM actual que uses todos los días y no está en esta propuesta?

---

## Resumen

| Métrica | Actual | Propuesto | Cambio |
|---------|--------|-----------|--------|
| Archivos | 16 | 6 | -62% |
| LOC | ~3,000 | ~1,200 | -60% |
| Tablas D1 | 6 | 3 (+2 deprecated) | -50% |
| Endpoints API | 21 | 12 | -43% |
| Vistas/Tabs | 5 | 4 (Dashboard+Pipeline+Clientes+Cotizaciones) | -20% |
| Hooks | 3 | 1 | -67% |
