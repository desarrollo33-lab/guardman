# GuardMan Admin — Plan de Implementación: Media Editor (v2.0 corregido)
## Fase 0 a Fase 3 — Con todos los fixes de la auditoría técnica

**Fecha:** 2026-05-09 (v2.0 post-auditoría)  
**Visión:** `docs/VISION-MEDIA-EDITOR.md` (v3.0 Final)  
**Proyecto:** `C:\Users\56930\OneDrive\Escritorio\guardman-admin`  
**Producción:** `https://guardman.oficinadesarrollo33.workers.dev`

---

## RESUMEN DE CORRECCIONES APLICADAS

| # | Problema reportado | Fix aplicado |
|---|-------------------|-------------|
| 1 | Migración D1 en Fase 1, pero save-to-r2 en Fase 0 → SQL error | **T1.4 movida a Fase 0 (como T0.2b)** |
| 2 | `model.replace('/image-to-image', '')` rompe status de img2img | **Status endpoint usa `model` original sin modificar** |
| 3 | Feature flag sin endpoint para leerlo | **Nuevo `GET /api/media/feature-flag/:key` en Fase 1 (media.ts)** |
| 3b | `adminRoutes` no importado en modular router | **T1.5b — importar `adminRoutes` en `src/api/index.ts`** |
| 4 | `FAL_API_KEY` en vars (texto plano commiteable) | **Usar `wrangler secret put FAL_API_KEY` exclusivamente** |
| 5 | `negative_prompt` no se envía a fal.ai | **Agregado al `falBody` del generate endpoint + tipo** |
| 6 | `FAL_API_KEY` no en `Env` interface → `any` | **Agregado a `types/index.ts`** |
| 7 | `seed` hardcodeado a 0 en save-to-r2 | **Persistido en KV record + leído en save-to-r2** |
| 8 | Content-type JPEG con extensión `.webp` forzada | **Extensión derivada del content-type real** |
| 9 | `waitForCompletion` no cancelable | **Agregado `AbortSignal` + cancelación en cleanup** |
| 10 | Polling infinito sin timeout | **Agregado `maxAttempts=40` (120s máximo)** |
| 11 | Orden de rutas en mediaRoutes no especificado | **Documentado: insertar ANTES de `^\/api\/media\/(\d+)$`** |
| 12 | `generateAsync` soporta `num_images>1` pero save-to-r2 solo 1 | **Documentado: llamar `saveToR2` N veces con `image_index` 0..N-1** |
| 13 | `gm_fal_key` huérfana en localStorage | **Agregado cleanup en T0.6** |
| 14 | Sin rate limiting en endpoints `/fal/*` | **Agregado KV counter en Fase 1** |
| 15 | Fase 2 demasiado grande para 2-3 sesiones | **Spliteada en Fase 2A (grid/preview/picker) y 2B (AI tools)** |
| 16 | Imports huérfanos post-eliminación legacy | **Agregado T2B.7 — verificación y cleanup de imports** |

---

## CONTEXTO DEL PROYECTO

### Arquitectura
- **Runtime:** Cloudflare Workers (TypeScript, `src/index.ts`)
- **DB:** D1 (`guardman-seo`, 65 tablas)
- **Storage:** R2 (`guardman-images`) + KV (`CACHE` namespace)
- **Admin UI:** React 19 + Vite + TailwindCSS (`guardman-admin-ui/`)
- **AI:** fal.ai via REST API (proxy desde el Worker. `FAL_API_KEY` via `wrangler secret put`)

### Archivos que se modificarán

| Archivo | Fase | Tipo de cambio |
|---------|------|---------------|
| `src/types/index.ts` | 0 | Tipos `FalGenerateRequest`, `FalQueuedRequest`, `FAL_API_KEY` en Env |
| `sql/media-editor.sql` | 0 | Migración D1 (5 columnas nuevas) |
| `src/api/routes/media.ts` | 0, 1 | +5 endpoints fal/prompts, rate limiting |
| `src/api/index.ts` | 1 | Agregar import de adminRoutes |
| `guardman-admin-ui/src/lib/falai.ts` | 0 | Reescribir — async, AbortSignal, sin key mgmt |
| `src/services/image-prompts.ts` | 1 | **NUEVO** — system prompt + seed |
| `guardman-admin-ui/src/components/Media/MediaEditor.tsx` | 2A, 2B | **NUEVO** — componente unificado |
| `guardman-admin-ui/src/components/Media/ImagePicker.tsx` | 2B | **ELIMINAR** (reemplazado) |
| `guardman-admin-ui/src/components/Media/MediaLibrary.tsx` | 2B | **ELIMINAR** (reemplazado) |
| `guardman-admin-ui/src/components/Media/LiteYouTube.tsx` | — | **NO SE ELIMINA** — CMSPage lo usa para YouTube previews |
| `guardman-admin-ui/src/components/Layout/Sidebar.tsx` | 2A | Referencia a MediaEditor |
| `guardman-admin-ui/src/components/CMS/CMSPage.tsx` | 2A | Usar MediaEditor en modo picker |
| `guardman-admin-ui/src/App.tsx` | 2A | Feature flag + routing |

### Estado inicial de Git
- Working tree: **limpio** (todo commiteado)
- Último commit: `a354479` — "rediseño sección Nosotros en homepage"

---

## FASE 0: PATRÓN ASÍNCRONO + SEGURIDAD + MIGRACIÓN D1
### Objetivo: Resolver el timeout del Worker, sentar la base de datos. Sin esto, nada más funciona.

### T0.1 — FAL_API_KEY como secret del Worker

**NO tocar `wrangler.jsonc` para esto.** Usar secrets de Cloudflare:

```bash
wrangler secret put FAL_API_KEY
# Pegar la key cuando pregunte
```

**Verificación:** `wrangler secret list` → debe mostrar `FAL_API_KEY`.

---

### T0.2a — Tipos para fal requests + Env

**Archivo:** `src/types/index.ts`

Agregar `FAL_API_KEY` al interface `Env`:

```typescript
export interface Env {
  // ... existente ...
  FAL_API_KEY: string;  // ← NUEVO
}
```

Agregar al final del archivo los tipos de fal:

```typescript
export interface FalGenerateRequest {
  prompt: string;
  model: string;
  image_size?: string;
  num_images?: number;
  seed?: number;
  image_url?: string;
  strength?: number;
  negative_prompt?: string;
  enable_safety_checker?: boolean;
}

export interface FalQueuedRequest {
  falRequestId: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  model: string;
  prompt: string;
  seed?: number;
  images?: Array<{ url: string; width: number; height: number }>;
  error?: string;
  created_at: number;
}
```

---

### T0.2b — Migración D1

**Archivo:** `sql/media-editor.sql` (NUEVO)

```sql
-- GuardMan Admin — Media Editor D1 Migration
-- Fase 0: Columnas para metadata de IA en media_library
-- DEBE ejecutarse ANTES de T0.5 (save-to-r2)

ALTER TABLE media_library ADD COLUMN prompt_used TEXT;
ALTER TABLE media_library ADD COLUMN generation_model TEXT;
ALTER TABLE media_library ADD COLUMN generation_seed INTEGER;
ALTER TABLE media_library ADD COLUMN generation_time_ms INTEGER;
ALTER TABLE media_library ADD COLUMN fal_request_id TEXT;
```

Ejecutar inmediatamente:
```bash
npx wrangler d1 execute guardman-seo --remote --file=sql/media-editor.sql
```

---

### T0.3 — POST /api/media/fal/generate (async)

**Archivo:** `src/api/routes/media.ts`

**IMPORTANTE:** Las rutas nuevas de `/fal/*` deben insertarse **ANTES** de la ruta `^\/api\/media\/(\d+)$` (que captura IDs numéricos). Insertar después de la ruta `^\/api\/media\/youtube$` y antes de las rutas con `(\d+)`.

```typescript
// POST /api/media/fal/generate — Async proxy to fal.ai
{
  pattern: /^\/api\/media\/fal\/generate$/,
  methods: ['POST'],
  handler: async (req, env, ctx) => {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '');
    if (!token || token !== env.AUTH_TOKEN) {
      return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
    }

    try {
      const body = await req.json() as any;
      const { prompt, model, image_size, num_images, seed, image_url, strength, negative_prompt } = body;
      if (!prompt || !model) {
        return Response.json({ ok: false, error: 'Missing prompt or model' }, { status: 400, headers: cors });
      }

      const falBody: any = {
        prompt,
        image_size: image_size || 'landscape_4_3',
        num_images: num_images || 1,
        enable_safety_checker: true,
      };
      if (seed !== undefined) falBody.seed = seed;
      if (negative_prompt) falBody.negative_prompt = negative_prompt;
      if (image_url) { falBody.image_url = image_url; falBody.strength = strength || 0.75; }

      const falRes = await fetch(`https://fal.run/${model}`, {
        method: 'POST',
        headers: {
          'Authorization': `Key ${env.FAL_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(falBody),
      });

      if (!falRes.ok) {
        const errText = await falRes.text();
        let friendlyError = 'Error al generar la imagen.';
        if (errText.includes('NSFW') || errText.includes('safety')) {
          friendlyError = 'La imagen fue rechazada por el filtro de seguridad. Intenta con un prompt diferente.';
        } else if (errText.includes('rate limit')) {
          friendlyError = 'Límite de generaciones alcanzado. Intenta de nuevo en unos minutos.';
        }
        return Response.json({ ok: false, error: friendlyError }, { status: 500, headers: cors });
      }

      const falData = await falRes.json() as any;

      // If immediate response (Schnell, ESRGAN, BiRefNet)
      if (falData.images && falData.images.length > 0) {
        const requestId = crypto.randomUUID();
        const record: any = {
          falRequestId: falData.request_id || requestId,
          status: 'completed',
          model,
          prompt,
          seed: seed ?? null,
          images: falData.images,
          created_at: Date.now(),
        };
        await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
        return Response.json({ ok: true, request_id: requestId, status: 'completed', images: falData.images }, { headers: cors });
      }

      // Async response (Flux Pro) — poll later
      if (falData.request_id) {
        const requestId = crypto.randomUUID();
        const record: any = {
          falRequestId: falData.request_id,
          status: 'queued',
          model,
          prompt,
          seed: seed ?? null,
          created_at: Date.now(),
        };
        await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
        return Response.json({ ok: true, request_id: requestId, status: 'queued' }, { headers: cors });
      }

      return Response.json({ ok: false, error: 'No request_id from fal.ai' }, { status: 500, headers: cors });
    } catch (err: any) {
      return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
    }
  }
},
```

---

### T0.4 — GET /api/media/fal/status/:request_id

**Archivo:** `src/api/routes/media.ts`

**CORREGIDO:** Ya no hace `model.replace('/image-to-image', '')`. Usa `model` original para el status check.

```typescript
// GET /api/media/fal/status/:request_id
{
  pattern: /^\/api\/media\/fal\/status\/([a-zA-Z0-9-]+)$/,
  methods: ['GET'],
  handler: async (req, env, ctx, match) => {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '');
    if (!token || token !== env.AUTH_TOKEN) {
      return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
    }

    const requestId = match[1];

    try {
      // Check KV cache first
      const cached = await env.CACHE.get(`fal:req:${requestId}`);
      if (cached) {
        const record = JSON.parse(cached);
        if (record.status === 'completed' || record.status === 'failed') {
          return Response.json({ ok: true, ...record }, { headers: cors });
        }
      }

      // Not in cache or still processing — poll fal.ai
      const record = cached ? JSON.parse(cached) : null;
      if (!record) {
        return Response.json({ ok: false, error: 'Request not found' }, { status: 404, headers: cors });
      }

      // Usar el modelo original tal cual (sin strippear /image-to-image)
      const statusRes = await fetch(
        `https://fal.run/${record.model}/requests/${record.falRequestId}/status`,
        { headers: { 'Authorization': `Key ${env.FAL_API_KEY}` } }
      );

      if (!statusRes.ok) {
        record.status = 'failed';
        record.error = `Status check failed: ${statusRes.status}`;
        await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
        return Response.json({ ok: true, status: 'failed', error: record.error }, { headers: cors });
      }

      const statusData = await statusRes.json() as any;

      if (statusData.status === 'COMPLETED') {
        record.status = 'completed';
        record.images = statusData.images || [];
        await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
        return Response.json({ ok: true, request_id: requestId, status: 'completed', images: record.images }, { headers: cors });
      }

      if (statusData.status === 'FAILED') {
        record.status = 'failed';
        record.error = statusData.error || 'Generation failed';
        await env.CACHE.put(`fal:req:${requestId}`, JSON.stringify(record), { expirationTtl: 600 });
        return Response.json({ ok: true, status: 'failed', error: record.error }, { headers: cors });
      }

      // Still processing
      return Response.json({ ok: true, request_id: requestId, status: 'processing' }, { headers: cors });
    } catch (err: any) {
      return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
    }
  }
},
```

---

### T0.5 — POST /api/media/fal/save-to-r2 (server-side)

**Archivo:** `src/api/routes/media.ts`

**CORREGIDO:** 
- Seed leído del KV record (no hardcodeado a 0)
- Extensión del archivo derivada del content-type real (no forzada a .webp)

```typescript
// POST /api/media/fal/save-to-r2 — Worker descarga de fal.ai y sube a R2
{
  pattern: /^\/api\/media\/fal\/save-to-r2$/,
  methods: ['POST'],
  handler: async (req, env, ctx) => {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '');
    if (!token || token !== env.AUTH_TOKEN) {
      return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
    }

    try {
      const body = await req.json() as any;
      const { request_id, image_index = 0, filename, category, alt_text, tags } = body;
      if (!request_id || !filename) {
        return Response.json({ ok: false, error: 'Missing request_id or filename' }, { status: 400, headers: cors });
      }

      // Get image URL from KV
      const cached = await env.CACHE.get(`fal:req:${request_id}`);
      if (!cached) {
        return Response.json({ ok: false, error: 'Request not found (expired?)' }, { status: 404, headers: cors });
      }
      const record = JSON.parse(cached);
      if (record.status !== 'completed' || !record.images || !record.images[image_index]) {
        return Response.json({ ok: false, error: 'Image not available yet' }, { status: 400, headers: cors });
      }

      const imgUrl = record.images[image_index].url;

      // Download image from fal.ai
      const imgRes = await fetch(imgUrl);
      if (!imgRes.ok) {
        return Response.json({ ok: false, error: 'Failed to download generated image' }, { status: 500, headers: cors });
      }
      const blob = await imgRes.arrayBuffer();
      const contentType = imgRes.headers.get('Content-Type') || 'image/jpeg';

      // Derive extension from actual content-type (not forced to .webp)
      const extMap: Record<string, string> = {
        'image/jpeg': '.jpg',
        'image/png': '.png',
        'image/webp': '.webp',
        'image/gif': '.gif',
      };
      const ext = extMap[contentType] || '.jpg';

      // Generate R2 key
      const safeName = filename.replace(/[^a-z0-9-]/gi, '-').substring(0, 60);
      const key = `images/media/${Date.now()}-${safeName}${ext}`;

      // Upload to R2
      await env.IMAGES.put(key, blob, {
        httpMetadata: { contentType },
      });

      // Register in D1 (seed leído del KV record, no hardcodeado)
      const result = await env.DB.prepare(`
        INSERT INTO media_library (key, filename, alt_text, category, mime_type, file_size, media_type, tags, prompt_used, generation_model, generation_seed, generation_time_ms, fal_request_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'image', ?, ?, ?, ?, ?, ?, datetime('now'))
      `).bind(
        key,
        filename,
        alt_text || '',
        category || 'ai-generated',
        contentType,
        blob.byteLength,
        tags ? JSON.stringify(tags) : '["ai-generated","fal-ai"]',
        record.prompt || '',
        record.model || '',
        record.seed ?? null,
        Date.now() - record.created_at,
        record.falRequestId || '',
      ).run();

      const id = result.meta.last_row_id as number;

      return Response.json({
        ok: true,
        data: { id, key, url: `/${key}` }
      }, { headers: cors });
    } catch (err: any) {
      return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
    }
  }
},
```

**NOTA IMPORTANTE:** `generateAsync` soporta `num_images: 4` para generar múltiples variantes en una sola request. Pero `save-to-r2` solo guarda UNA imagen a la vez (la del índice `image_index`). Para guardar las 4 variantes, el frontend debe llamar `saveToR2` 4 veces con `image_index: 0, 1, 2, 3`. Esto es por diseño — cada imagen guardada es un registro independiente en `media_library`.

---

### T0.6 — Reescribir falai.ts

**Archivo:** `guardman-admin-ui/src/lib/falai.ts`

**CORREGIDO:** `waitForCompletion` con `AbortSignal` cancelable + `maxAttempts` (40 intentos, 120s máximo). Limpia `gm_fal_key` del localStorage viejo.

Reemplazar TODO el contenido por:

```typescript
// GuardMan Admin — fal.ai client (v3 simplificado)
// Ya no maneja API keys — el Worker proxy a fal.ai via /api/media/fal/*
// Soporta cancelación via AbortSignal + timeout

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

// Cleanup old localStorage key (ya no se usa)
if (typeof localStorage !== 'undefined') {
  try { localStorage.removeItem('gm_fal_key'); } catch {}
}

function authHeaders(): Record<string, string> {
  const token = typeof localStorage !== 'undefined' ? (localStorage.getItem('gm_token') || '') : '';
  return {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
}

export interface FalImageResult {
  url: string;
  width: number;
  height: number;
}

interface GenerateResponse {
  ok: boolean;
  request_id?: string;
  status?: string;
  images?: FalImageResult[];
  error?: string;
}

interface StatusResponse {
  ok: boolean;
  request_id?: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  images?: FalImageResult[];
  error?: string;
}

export interface GenerateParams {
  prompt: string;
  model: string;
  image_size?: string;
  num_images?: number;
  seed?: number;
  image_url?: string;
  strength?: number;
  negative_prompt?: string;
}

/**
 * Inicia generación asíncrona. Devuelve request_id inmediatamente.
 */
export async function generateAsync(params: GenerateParams): Promise<{ request_id: string; status: string }> {
  const res = await fetch(`${API_BASE}/api/media/fal/generate`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(params),
  });
  const data: GenerateResponse = await res.json();
  if (!data.ok) throw new Error(data.error || 'Generation failed');
  return { request_id: data.request_id!, status: data.status! };
}

/**
 * Consulta el estado de una generación.
 */
export async function pollStatus(requestId: string): Promise<StatusResponse> {
  const res = await fetch(`${API_BASE}/api/media/fal/status/${requestId}`, {
    headers: authHeaders(),
  });
  const data: StatusResponse = await res.json();
  if (!data.ok) throw new Error(data.error || 'Status check failed');
  return data;
}

/**
 * Poll hasta completar o fallar. Cancelable via AbortSignal.
 * @param signal - AbortSignal para cancelar (ej: al desmontar el componente)
 * @param intervalMs - intervalo entre polls (default 3000ms)
 * @param maxAttempts - máximo de intentos antes de timeout (default 40 = 120s)
 */
export async function waitForCompletion(
  requestId: string,
  signal?: AbortSignal,
  intervalMs = 3000,
  maxAttempts = 40
): Promise<FalImageResult[]> {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

    const status = await pollStatus(requestId);

    if (status.status === 'completed' && status.images) return status.images;
    if (status.status === 'failed') throw new Error(status.error || 'Generation failed');

    // Esperar con abort support
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(resolve, intervalMs);
      if (signal) {
        const onAbort = () => { clearTimeout(timer); reject(new DOMException('Aborted', 'AbortError')); };
        signal.addEventListener('abort', onAbort, { once: true });
      }
    });
  }
  throw new Error('Generation timed out after ' + (maxAttempts * intervalMs / 1000) + 's');
}

/**
 * Generar y esperar (conveniencia). Cancelable via AbortSignal.
 */
export async function generateAndWait(
  params: GenerateParams,
  signal?: AbortSignal,
  pollIntervalMs = 3000
): Promise<FalImageResult[]> {
  const { request_id } = await generateAsync(params);
  return waitForCompletion(request_id, signal, pollIntervalMs);
}

/**
 * Guardar imagen generada en R2 (server-side download).
 * Si generateAsync usó num_images > 1, llamar esta función N veces con image_index 0..N-1.
 */
export async function saveToR2(params: {
  request_id: string;
  image_index?: number;
  filename: string;
  category?: string;
  alt_text?: string;
  tags?: string[];
}): Promise<{ id: number; key: string; url: string }> {
  const res = await fetch(`${API_BASE}/api/media/fal/save-to-r2`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(params),
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || 'Save failed');
  return data.data;
}
```

---

### T0.7 — Verificación Fase 0

```bash
# 1. Verificar migración D1
npx wrangler d1 execute guardman-seo --remote --command "SELECT prompt_used, generation_model FROM media_library LIMIT 1"

# 2. Build check (verifica que FAL_API_KEY está en Env)
npx wrangler deploy --dry-run

# 3. Deploy
npx wrangler deploy

# 4. Test generate endpoint (Schnell — respuesta inmediata)
curl -X POST https://guardman.oficinadesarrollo33.workers.dev/api/media/fal/generate \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"prompt":"A blue shield logo on navy background","model":"fal-ai/flux/schnell","image_size":"square_hd","num_images":1}'

# Debería devolver: { ok: true, request_id: "...", status: "completed", images: [...] }

# 5. Test save-to-r2 con el request_id del paso anterior
curl -X POST https://guardman.oficinadesarrollo33.workers.dev/api/media/fal/save-to-r2 \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"request_id":"REQUEST_ID_AQUI","filename":"test-generation","category":"ai-generated"}'

# 6. Commit
git add -A && git commit -m "feat(media): async fal.ai proxy + D1 migration + Worker-side R2 upload (Fase 0)"
```

---

## FASE 1: INFRAESTRUCTURA + STYLE GUIDE + FEATURE FLAG
### Objetivo: Sistema de prompts, feature flag con endpoint, rate limiting.

### T1.1 — Crear image-prompts.ts

**Archivo:** `src/services/image-prompts.ts` (NUEVO)

```typescript
// GuardMan Admin — Image Prompts System
// Capa 1: System prompt fijo (se inyecta siempre)
// Capa 2: Prompts predefinidos (editables via KV por el admin)

export const GUARDMAN_SYSTEM_PROMPT = `STYLE GUIDE — Follow these rules exactly:

CAMERA: Canon EOS R5 full-frame mirrorless, RF 24-70mm f/2.8L lens.
LIGHTING: Natural golden hour light, soft directional shadows, warm tone (5600-6000K). No harsh midday sun. No artificial flash.
COLOR PALETTE: Navy blue #1A2744, white #FFFFFF, steel blue #5F7A96, warm gray #6C757D. Colors must be natural, not oversaturated.
LOCATION: Santiago de Chile. Corporate buildings, residential condominiums, urban streets. Andes mountains on horizon when natural.
MOOD: Professional, trustworthy, authentic. Photorealistic portfolio quality. Not stock photo, not overly perfect.
COMPOSITION: Rule of thirds, leading lines, eye-level (1.6m), negative space. No extreme angles.
AVOID: Recognizable faces, weapons, AI artifacts, third-party logos, tropical vegetation, neon colors, military postures, messy cables, text overlays, watermarks.
OUTPUT: Photorealistic, high resolution, WebP format, no text, no watermarks.`;

export interface ImagePrompt {
  id: string;
  label: string;
  category: string;
  resolution: string;
  aspect_ratio: string;
  prompt: string;
  negative: string;
}

export const DEFAULT_PROMPTS: ImagePrompt[] = [
  {
    id: 'guardpod-hero',
    label: 'Guard Pod V1 — Hero',
    category: 'guard-pod',
    resolution: '2K',
    aspect_ratio: '16:9',
    prompt: 'Wide establishing shot of a Guard Pod V1 autonomous security tower deployed at a construction site entrance in Santiago Chile. White and navy blue tower with solar panels on top, PTZ camera dome, and 4G antenna. Modern, sleek, imposing presence. Late afternoon golden hour, clear blue sky, Andes mountains faintly visible. Clean environment, professional installation.',
    negative: 'people, dark, rain, messy site, graffiti, cartoon, 3D render'
  },
  {
    id: 'guardpod-condominio',
    label: 'Guard Pod en Condominio',
    category: 'guard-pod',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Medium shot of a Guard Pod V1 installed at the entrance gate of a modern residential condominium in Las Condes Santiago. Security barrier gate in frame, well-maintained gardens. Natural afternoon light, professional suburban atmosphere.',
    negative: 'people visible faces, night, empty scene, cartoon, oversaturated'
  },
  {
    id: 'ajax-hero',
    label: 'Ajax Systems Hub — Hero Producto',
    category: 'ajax',
    resolution: '2K',
    aspect_ratio: '16:9',
    prompt: 'Close-up product photography of an Ajax Systems Hub 2 central alarm panel installed on a clean modern wall in a Santiago office. MotionCam detector, DoorProtect sensor, and KeyPad nearby. Clean white wall, subtle navy accent from GuardMan branding. Professional lighting, shallow depth of field.',
    negative: 'messy desk, visible cables, old building, dark room, people'
  },
  {
    id: 'ajax-app',
    label: 'Ajax App — Lifestyle',
    category: 'ajax',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Overhead flat lay: a modern smartphone showing a security app dashboard with arm/disarm controls. Ajax fob keychain, coffee cup, subtle GuardMan business card with navy blue branding. Warm morning light from window, clean wooden desk surface.',
    negative: 'any text other than generic UI, messy, dark, people'
  },
  {
    id: 'servicio-guardia',
    label: 'Guardia de Seguridad OS-10',
    category: 'servicios',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Professional security guard in navy blue GuardMan uniform standing at the entrance lobby of a corporate office building in Santiago Chile. OS-10 certification badge visible on chest. Guard from 45-degree angle, looking toward entrance. Clean modern lobby, glass doors, corporate atmosphere. Natural diffuse daylight.',
    negative: 'visible face details, weapons, military posture, dark, empty lobby'
  },
  {
    id: 'servicio-cctv',
    label: 'CCTV — Instalación Profesional',
    category: 'servicios',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Modern dome CCTV camera professionally installed on the ceiling of a corporate hallway in Santiago. Clean cable management, blue indicator light glowing softly. Clean white ceiling, modern office corridor.',
    negative: 'messy cables, dirty ceiling, outdated camera, people, dark'
  },
  {
    id: 'servicio-accesos',
    label: 'Control de Accesos',
    category: 'servicios',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Modern access control turnstile gate at the entrance of a Santiago office building. Card reader with blue LED, sleek stainless steel finish. Clean lobby background. Natural daylight through glass entrance. Security-focused but welcoming.',
    negative: 'people visible faces, dirty glass, old equipment, dark'
  },
  {
    id: 'nosotros-oficina',
    label: 'Oficina GuardMan — Fachada',
    category: 'nosotros',
    resolution: '2K',
    aspect_ratio: '16:9',
    prompt: 'Exterior wide shot of the GuardMan Chile office building in Providencia Santiago. Modern 3-story building with navy blue GuardMan signage. Professional landscaping around entrance. Clear blue sky, golden hour side lighting. OS-10 certification plaque visible.',
    negative: 'people visible faces, rain, dark, neighboring buildings prominent'
  },
  {
    id: 'cobertura-santiago',
    label: 'Santiago — Cobertura Urbana',
    category: 'cobertura',
    resolution: '1K',
    aspect_ratio: '4:3',
    prompt: 'Aerial-style wide view of a Santiago residential neighborhood with modern apartment buildings and tree-lined streets. Clear blue sky, distant Andes mountains on the eastern horizon. Professional urban photography style communicating comprehensive city coverage.',
    negative: 'smog, night, identifiable addresses, people, text'
  },
];

// Función helper para componer el prompt final (Capa 1 + Capa 2 + Capa 3)
export function composePrompt(promptTemplate: ImagePrompt, userInput?: string): { prompt: string; negative: string } {
  let full = `${GUARDMAN_SYSTEM_PROMPT}\n\nSCENE: ${promptTemplate.prompt}`;
  if (userInput && userInput.trim()) full += `\n\nADDITIONAL DETAILS: ${userInput.trim()}`;
  return { prompt: full, negative: promptTemplate.negative || '' };
}
```

---

### T1.2 — GET /api/media/prompts

**Archivo:** `src/api/routes/media.ts`

```typescript
// GET /api/media/prompts
{
  pattern: /^\/api\/media\/prompts$/,
  methods: ['GET'],
  handler: async (req, env, ctx) => {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '');
    if (!token || token !== env.AUTH_TOKEN) {
      return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
    }

    try {
      // Try KV first, fallback to code defaults
      const cached = await env.CACHE.get('prompts:all');
      if (cached) {
        return Response.json({ ok: true, data: JSON.parse(cached) }, { headers: cors });
      }

      const { DEFAULT_PROMPTS } = await import('../../services/image-prompts');
      return Response.json({ ok: true, data: DEFAULT_PROMPTS }, { headers: cors });
    } catch (err: any) {
      return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
    }
  }
},
```

---

### T1.3 — PUT /api/media/prompts

```typescript
// PUT /api/media/prompts
{
  pattern: /^\/api\/media\/prompts$/,
  methods: ['PUT'],
  handler: async (req, env, ctx) => {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '');
    if (!token || token !== env.AUTH_TOKEN) {
      return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
    }

    try {
      const body = await req.json() as any;
      const { prompts } = body;
      if (!prompts || !Array.isArray(prompts)) {
        return Response.json({ ok: false, error: 'Missing prompts array' }, { status: 400, headers: cors });
      }

      await env.CACHE.put('prompts:all', JSON.stringify(prompts));
      return Response.json({ ok: true }, { headers: cors });
    } catch (err: any) {
      return Response.json({ ok: false, error: err.message }, { status: 500, headers: cors });
    }
  }
},
```

---

### T1.4 — Rate limiting en endpoints /fal/*

**Archivo:** `src/api/routes/media.ts`

Agregar al inicio de cada handler de `/fal/*` (generate, status, save-to-r2) un check de rate limit usando KV:

```typescript
// Rate limit helper (agregar al inicio de cada handler fal/):
async function checkFalRateLimit(env: any): Promise<boolean> {
  const key = 'fal:ratelimit:' + new Date().toISOString().slice(0, 13); // por hora
  const count = parseInt((await env.CACHE.get(key)) || '0');
  if (count >= 50) return false; // 50 req/hora máximo
  await env.CACHE.put(key, String(count + 1), { expirationTtl: 3600 });
  return true;
}

// Uso en el handler:
// if (!(await checkFalRateLimit(env))) {
//   return Response.json({ ok: false, error: 'Límite de generaciones por hora alcanzado' }, { status: 429, headers: cors });
// }
```

---

### T1.5 — GET /api/media/feature-flag/:key (NUEVO)

**Archivo:** `src/api/routes/media.ts`

Agregar endpoint para leer feature flags desde el frontend.
**NOTA:** Se agrega en media.ts (no admin.ts) porque `adminRoutes` no está importado en el modular router (`src/api/index.ts`). Ver T1.5b para importar adminRoutes.

```typescript
// GET /api/media/feature-flag/:key
{
  pattern: /^\/api\/media\/feature-flag\/([a-zA-Z0-9:-]+)$/,
  methods: ['GET'],
  handler: async (req, env, ctx, match) => {
    const token = req.headers.get('Authorization')?.replace('Bearer ', '');
    if (!token || token !== env.AUTH_TOKEN) {
      return Response.json({ ok: false, error: 'Unauthorized' }, { status: 401, headers: cors });
    }

    try {
      const flagKey = match[1];
      const raw = await env.CACHE.get(`feature:${flagKey}`);
      if (!raw) return Response.json({ ok: true, enabled: false }, { headers: cors });
      const parsed = JSON.parse(raw);
      return Response.json({ ok: true, enabled: parsed.enabled === true }, { headers: cors });
    } catch {
      return Response.json({ ok: true, enabled: false }, { headers: cors });
    }
  }
},
```

---

### T1.5b — Importar adminRoutes en modular router

**Archivo:** `src/api/index.ts`

**Problema descubierto en análisis forense:** `adminRoutes` está definido en `src/api/routes/admin.ts` pero **NUNCA se importa** en `src/api/index.ts`. Esto significa que TODOS los endpoints de admin existentes (`/api/admin/backfill-content`, `/api/admin/check-duplicates`, `/api/admin/regenerate-faqs`, `/api/admin/regenerate-faqs-batch`, `/api/admin/status`) están **muertos** — no responden a ninguna request.

**Fix:** Agregar import y spread:

```typescript
// Al final de los imports de routes (antes de isPublicEndpoint):
import { adminRoutes } from './routes/admin';

// En el array allRoutes, después de mediaRoutes:
const allRoutes: Route[] = [
  // ... existente ...
  ...mediaRoutes,
  ...adminRoutes,   // ← NUEVO — activa todos los endpoints de admin
  // ... existente ...
];
```

**Verificación:**
```bash
curl https://guardman.oficinadesarrollo33.workers.dev/api/admin/status \
  -H "Authorization: Bearer TOKEN"
# Debe devolver JSON con datos del sistema, no 404
```

---

### T1.6 — Feature flag KV

```bash
# Inicialmente desactivado
npx wrangler kv key put "feature:media-editor-v3" '{"enabled":false}' --namespace-id 2090314bf4ca45318fabaa2fd4ef8ff5 --remote
```

---

### T1.7 — Verificación Fase 1

```bash
# 1. Build check
npx wrangler deploy --dry-run

# 2. Deploy
npx wrangler deploy

# 3. Test prompts API
curl https://guardman.oficinadesarrollo33.workers.dev/api/media/prompts \
  -H "Authorization: Bearer TOKEN"

# 4. Test feature flag endpoint
curl https://guardman.oficinadesarrollo33.workers.dev/api/media/feature-flag/media-editor-v3 \
  -H "Authorization: Bearer TOKEN"
# Debe devolver: { ok: true, enabled: false }

# 5. Test admin routes (T1.5b) — ahora deben funcionar
curl https://guardman.oficinadesarrollo33.workers.dev/api/admin/status \
  -H "Authorization: Bearer TOKEN"
# Debe devolver datos del sistema (antes estaba muerto)

# 6. Commit
git add -A && git commit -m "feat(media): image prompts system + feature flag endpoint + rate limiting (Fase 1)"
```

---

## FASE 2A: MEDIA EDITOR — GRID + PREVIEW + PICKER
### Objetivo: Layout base, grid de medios, preview, SEO, modo picker. Sin AI tools todavía.

### T2A.1 — Crear MediaEditor.tsx (estructura base)

**Archivo:** `guardman-admin-ui/src/components/Media/MediaEditor.tsx` (NUEVO)

```tsx
import { useState, useEffect, useCallback, useRef } from 'react';
import { useApi } from '../../hooks/useApi';

interface MediaEditorProps {
  mode: 'full' | 'picker';
  currentImage?: string;
  onSelect?: (path: string) => void;
  onClose?: () => void;
}

export function MediaEditor({ mode, currentImage, onSelect, onClose }: MediaEditorProps) {
  const { api } = useApi();
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<MediaItem | null>(null);
  const [category, setCategory] = useState('');
  const [search, setSearch] = useState('');
  const [mediaFilter, setMediaFilter] = useState<'all' | 'image' | 'video'>('all');
  const [uploading, setUploading] = useState(false);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [showYoutubeInput, setShowYoutubeInput] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'seo'>('info');

  // SEO edit state
  const [editAlt, setEditAlt] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [editCaption, setEditCaption] = useState('');
  const [editTags, setEditTags] = useState<string[]>([]);

  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // Load items
  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (category) params.set('category', category);
      if (search) params.set('q', search);
      params.set('limit', '200');
      const data = await api<MediaItem[]>(`/api/media?${params}`);
      let filtered = data || [];
      if (mediaFilter !== 'all') filtered = filtered.filter(i => i.media_type === mediaFilter);
      setItems(filtered);
    } catch {} finally { setLoading(false); }
  }, [category, search, mediaFilter, api]);

  useEffect(() => { loadItems(); }, [loadItems]);

  // ... resto de la implementación del grid y preview ...

  // En modo picker: renderizar como modal overlay
  if (mode === 'picker') {
    if (!onSelect || !onClose) return null;
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
        <div className="bg-gray-900 rounded-xl w-full max-w-4xl max-h-[85vh] flex flex-col border border-gray-700" onClick={e => e.stopPropagation()}>
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700">
            <h3 className="text-lg font-bold text-white">📷 Seleccionar imagen</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-white text-xl">✕</button>
          </div>
          {/* Grid solo */}
          <div className="flex-1 overflow-y-auto p-4">
            {/* Grid de thumbnails — selección rápida */}
          </div>
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-700">
            <span className="text-sm text-gray-400">{items.length} medios</span>
            <div className="flex gap-2">
              <button onClick={onClose} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white">Cancelar</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Modo full: layout 3 paneles (grid | preview | vacío para Fase 2B)
  return (
    <div className="flex h-full bg-gray-900 text-white">
      {/* Panel Grid */}
      <div className="w-80 flex flex-col overflow-hidden border-r border-gray-700 shrink-0">
        {/* ... grid con filtros, upload, YouTube ... */}
      </div>
      {/* Panel Preview */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* ... preview + tabs info/seo ... */}
      </div>
    </div>
  );
}
```

### T2A.2 — Migrar Grid desde MediaLibrary

Filtros de categoría, media type, search bar, upload buttons (imagen, video, YouTube), grid 3-columnas, stats footer.

### T2A.3 — Migrar Preview desde MediaLibrary

Preview imagen/video/YouTube, metadata (filename, ruta, tamaño, tipo, dimensiones), asignaciones (entity_type + slug + usage), SEO tab (alt, title, caption, tags, score ring).

### T2A.4 — Actualizar Sidebar y App

**Archivo:** `Sidebar.tsx` — cambiar "Biblioteca de Medios" para abrir `MediaEditor mode="full"`.

**Archivo:** `App.tsx` — leer feature flag y usar MediaEditor condicionalmente.

Cambios concretos en App.tsx:

```typescript
// 1. Cambiar import:
// ANTES:
import { MediaLibrary } from './components/Media/MediaLibrary';
// DESPUÉS:
import { MediaEditor } from './components/Media/MediaEditor';
import { getToken } from './hooks/useApi';

// 2. Agregar state para feature flag (dentro de App, junto a currentView):
const [useNewMediaEditor, setUseNewMediaEditor] = useState(false);

// 3. Agregar efecto para leer feature flag:
useEffect(() => {
  const token = getToken();
  if (!token) return;
  fetch('https://guardman.oficinadesarrollo33.workers.dev/api/media/feature-flag/media-editor-v3', {
    headers: { 'Authorization': `Bearer ${token}` }
  }).then(r => r.json()).then(d => setUseNewMediaEditor(d?.enabled === true)).catch(() => {});
}, []);

// 4. Cambiar render del media view:
// ANTES:
{currentView === 'media' ? <MediaLibrary /> : currentView === 'adn' ? ...}
// DESPUÉS:
{currentView === 'media' ? (
  useNewMediaEditor ? <MediaEditor mode="full" /> : <MediaLibrary />
) : currentView === 'adn' ? ...}
```

**Kill switch:** Si algo falla en producción, revertir el feature flag:
```bash
npx wrangler kv key put "feature:media-editor-v3" '{"enabled":false}' --namespace-id 2090314bf4ca45318fabaa2fd4ef8ff5 --remote
```
El admin vuelve instantáneamente al MediaLibrary legacy (al refrescar).

### T2A.5 — Build + Deploy

```bash
cd guardman-admin-ui && npm run build
cp -r guardman-admin-ui/dist/assets/* ../public/admin/assets/
cp guardman-admin-ui/dist/index.html ../public/admin/index.html
cd .. && npx wrangler deploy
```

### T2A.6 — Activar feature flag y verificar

```bash
npx wrangler kv key put "feature:media-editor-v3" '{"enabled":true}' --namespace-id 2090314bf4ca45318fabaa2fd4ef8ff5 --remote
```

Verificar que el admin carga con el nuevo MediaEditor.

---

## FASE 2B: MEDIA EDITOR — AI TOOLS + REEMPLAZO LEGACY
### Objetivo: Agregar sistema 3-capas, herramientas IA, batch, y eliminar componentes viejos.

### T2B.1 — Panel AI: Generar (3-capas)

Agregar al `MediaEditor.tsx`:

- Dropdown de categoría → filtra prompts
- Dropdown de prompt predefinido
- Textarea de texto libre
- Preview colapsable del prompt compuesto
- Selector de modelo (Flux Schnell / Flux Pro)
- Selector de resolución
- Botón "Generar" y "Generar 4 variantes"
- Polling con `AbortController` (cancelar al cambiar de tab o desmontar)
- Grid de resultados (variantes)
- Botón "Usar y subir" → `saveToR2()`
- Si `num_images > 1`, llamar `saveToR2` para cada `image_index`

### T2B.2 — Panel AI: Herramientas sobre imagen

- Variante (img2img): strength slider + prompt adicional
- Remover fondo (BiRefNet)
- Upscale 2x (ESRGAN)

### T2B.3 — Panel AI: Batch

- Seleccionar categoría
- Checkboxes de prompts
- Concurrency limit 3
- Progress bar
- "Subir todos los completados"

### T2B.4 — Lightbox comparador

Modal con grid 2×2 para comparar variantes en grande.

### T2B.5 — Slider antes/después

Barra arrastrable para comparar original vs generada.

### T2B.6 — Historial de generaciones

Lista colapsable con últimas 20 generaciones. Estado local (useRef, se pierde al refrescar — aceptable para MVP).

### T2B.7 — Limpiar imports huérfanos

```bash
# Buscar imports de ImagePicker y MediaLibrary (NO LiteYouTube — se mantiene)
grep -rn "ImagePicker\|MediaLibrary" guardman-admin-ui/src/ --include="*.tsx" --include="*.ts"

# Debe devolver 0 resultados. Si alguno queda, actualizar ese archivo.
```

**Nota:** No buscamos `LiteYouTube` porque se mantiene — CMSPage lo usa para YouTube previews.

### T2B.8 — Actualizar CMSPage: reemplazar ImagePicker por MediaEditor picker

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

Cambios concretos:

```typescript
// 1. Cambiar imports:
// ANTES (línea 4-5):
import { ImagePicker } from '../Media/ImagePicker';
import { LiteYouTube } from '../Media/LiteYouTube';
// DESPUÉS:
import { MediaEditor } from '../Media/MediaEditor';
import { LiteYouTube } from '../Media/LiteYouTube'; // ← SE MANTIENE (ver nota abajo)

// 2. En componente ImageField, reemplazar ImagePicker:
// ANTES (dentro de ImageField, ~línea 207):
<ImagePicker open={pickerOpen} currentImage={value} onSelect={onChange} onClose={() => setPickerOpen(false)} />
// DESPUÉS:
{pickerOpen && (
  <MediaEditor
    mode="picker"
    currentImage={value}
    onSelect={(path: string) => { onChange(path); setPickerOpen(false); }}
    onClose={() => setPickerOpen(false)}
  />
)}
```

**IMPORTANTE — LiteYouTube NO se elimina todavía:**
CMSPage.tsx usa `LiteYouTube` en el componente `ImageField` (línea ~195) para previsualizar videos de YouTube referenciados como `yt:VIDEO_ID`. Este componente es independiente de MediaEditor y MediaLibrary. **NO incluir LiteYouTube.tsx en la eliminación de T2B.9.** Se evaluará eliminarlo en una refactorización futura de CMSPage.

### T2B.9 — Eliminar archivos legacy

Solo después de confirmar que T2B.7 devuelve 0 resultados:

```bash
rm guardman-admin-ui/src/components/Media/ImagePicker.tsx
rm guardman-admin-ui/src/components/Media/MediaLibrary.tsx
```

**NO eliminar `LiteYouTube.tsx`** — CMSPage.tsx lo usa en `ImageField` para previsualizar videos de YouTube (`yt:VIDEO_ID`). Se mantendrá hasta una refactorización futura de CMSPage.

---

### T2B.10 — Build + Deploy + Verificar

```bash
cd guardman-admin-ui && npm run build && cd ..
cp -r guardman-admin-ui/dist/assets/* public/admin/assets/
cp guardman-admin-ui/dist/index.html public/admin/index.html
npx wrangler deploy
```

Verificar flujo completo:
1. MediaEditor mode="full" desde sidebar → grid + preview + AI tools
2. MediaEditor mode="picker" desde CMS → modal de selección rápida
3. Generar imagen → polling → preview → guardar en R2 → seleccionar en CMS
4. Feature flag kill switch: desactivar → refrescar → MediaLibrary vuelve

---

## FASE 3: BATCH + CONTENIDO REAL
### Objetivo: Generar y asignar todas las imágenes del sitio.

### T3.1 — Mapeo aspect_ratio → image_size de fal.ai

**IMPORTANTE:** Los prompts en `image-prompts.ts` usan `aspect_ratio: '16:9'` pero fal.ai espera `image_size: 'landscape_16_9'`. El MediaEditor debe traducir:

```typescript
function aspectRatioToImageSize(ratio: string): string {
  const map: Record<string, string> = {
    '16:9': 'landscape_16_9',
    '4:3': 'landscape_4_3',
    '1:1': 'square_hd',
    '3:2': 'landscape_3_2',
    '2:3': 'portrait_4_3',
  };
  return map[ratio] || 'landscape_4_3';
}
```

---

### T3.2 — Checklist de generación (18 imágenes)

```
GUARD POD (4):
[ ] guardpod-hero — Hero wide, sitio construcción, 2K 16:9
[ ] guardpod-condominio — Entrada condominio, 1K 4:3

AJAX SYSTEMS (4):
[ ] ajax-hero — Hub 2 + sensores, 2K 16:9
[ ] ajax-app — Flat lay app, 1K 4:3

SERVICIOS (8):
[ ] servicio-guardia — Guardia OS-10 lobby, 1K 4:3
[ ] servicio-cctv — Cámara domo techo, 1K 4:3
[ ] servicio-accesos — Torniquete, 1K 4:3

NOSOTROS (1):
[ ] nosotros-oficina — Fachada Providencia, 2K 16:9

COBERTURA (1):
[ ] cobertura-santiago — Vista aérea, 1K 4:3
```

### T3.3 — Generar con batch

Usar el panel Batch del MediaEditor. Concurrency 3, Flux Pro para imágenes finales.

### T3.4 — Asignar a entidades D1

```sql
INSERT INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES (?, 'service', 'guard-pod', 'hero');
UPDATE services SET hero_image = '/images/media/xxx.webp' WHERE slug = 'guard-pod';
```

### T3.5 — Verificación visual

```bash
for path in / /servicios /servicios/guardias-de-seguridad /ubicaciones /nosotros /guard-pod /ajax-systems /contacto /cotizacion; do
  echo "$path: $(curl -sI https://guardman.oficinadesarrollo33.workers.dev$path | head -1)"
done
```

---

## RESUMEN DE FASES (CORREGIDO)

| Fase | Tareas | Archivos clave | Tiempo |
|------|--------|---------------|--------|
| **Fase 0** | 0.1 → 0.7 (secret, tipos, migración D1, 3 endpoints, falai.ts) | `types/index.ts`, `media.ts`, `falai.ts`, `sql/media-editor.sql` | 1 sesión |
| **Fase 1** | 1.1 → 1.7 (image-prompts, prompts API, feature flag endpoint, rate limiting) | `image-prompts.ts`, `media.ts`, `src/api/index.ts`, KV | 1 sesión |
| **Fase 2A** | 2A.1 → 2A.6 (grid + preview + picker + Sidebar/App) | `MediaEditor.tsx`, `Sidebar.tsx`, `App.tsx` | 1-2 sesiones |
| **Fase 2B** | 2B.1 → 2B.10 (AI tools + batch + eliminar ImagePicker + MediaLibrary) | `MediaEditor.tsx`, eliminar 2 archivos | 2 sesiones |
| **Fase 3** | 3.1 → 3.4 (batch real + asignaciones D1) | Ningún código nuevo, solo uso del editor | 1 sesión |
| **TOTAL** | | | **6-7 sesiones** |

---

## CHECKLIST MAESTRO

### Fase 0: Async + Seguridad + Migración
- [ ] T0.1 — `wrangler secret put FAL_API_KEY`
- [ ] T0.2a — Tipos + `FAL_API_KEY` en Env (`types/index.ts`)
- [ ] T0.2b — Migración D1 (`sql/media-editor.sql`)
- [ ] T0.3 — `POST /api/media/fal/generate` (async proxy, con `negative_prompt`, con `seed`)
- [ ] T0.4 — `GET /api/media/fal/status/:id` (sin strippear `/image-to-image`)
- [ ] T0.5 — `POST /api/media/fal/save-to-r2` (seed del KV, extensión del content-type)
- [ ] T0.6 — Reescribir `falai.ts` (AbortSignal, maxAttempts, cleanup localStorage)
- [ ] T0.7 — Verificación: build, deploy, test generate + save
- [ ] T0.8 — Commit Fase 0

### Fase 1: Infraestructura + Style Guide
- [ ] T1.1 — Crear `src/services/image-prompts.ts`
- [ ] T1.2 — `GET /api/media/prompts`
- [ ] T1.3 — `PUT /api/media/prompts`
- [ ] T1.4 — Rate limiting en endpoints `/fal/*`
- [ ] T1.5 — `GET /api/media/feature-flag/:key` (en media.ts)
- [ ] T1.5b — Importar `adminRoutes` en `src/api/index.ts`
- [ ] T1.6 — Feature flag KV (`feature:media-editor-v3`)
- [ ] T1.7 — Verificación: build, deploy, test endpoints
- [ ] T1.8 — Commit Fase 1

### Fase 2A: Grid + Preview + Picker
- [ ] T2A.1 — Layout base `MediaEditor.tsx` (full + picker modes)
- [ ] T2A.2 — Panel Grid (filtros, search, upload, YouTube)
- [ ] T2A.3 — Panel Preview (imagen/video, metadata, asignaciones, SEO)
- [ ] T2A.4 — Actualizar `Sidebar.tsx` y `App.tsx` (feature flag)
- [ ] T2A.5 — Build Admin UI + copy assets
- [ ] T2A.6 — Activar feature flag + verificar en producción
- [ ] T2A.7 — Commit Fase 2A

### Fase 2B: AI Tools + Eliminar Legacy
- [ ] T2B.1 — Panel AI: Generar (3-capas, polling con AbortController)
- [ ] T2B.2 — Panel AI: Herramientas (variante, upscale, remove bg)
- [ ] T2B.3 — Panel AI: Batch (concurrency 3, progress bar)
- [ ] T2B.4 — Lightbox comparador 2×2
- [ ] T2B.5 — Slider antes/después
- [ ] T2B.6 — Historial de generaciones (últimas 20, local state)
- [ ] T2B.7 — `grep` imports huérfanos de legacy → limpiar
- [ ] T2B.8 — Actualizar `CMSPage.tsx` (picker mode)
- [ ] T2B.9 — Eliminar `ImagePicker.tsx`, `MediaLibrary.tsx` (NO LiteYouTube)
- [ ] T2B.10 — Build Admin UI + deploy + flush cache
- [ ] T2B.11 — Verificación: flujo completo generar → guardar → usar en CMS
- [ ] T2B.12 — Commit Fase 2B

### Fase 3: Batch + Contenido Real
- [ ] T3.1 — Generar imágenes Guard Pod (2-4)
- [ ] T3.2 — Generar imágenes Ajax (2-4)
- [ ] T3.3 — Generar imágenes Servicios (3+)
- [ ] T3.4 — Generar imagen Nosotros (1)
- [ ] T3.5 — Generar imagen Cobertura (1)
- [ ] T3.6 — Asignar a `media_entities` + actualizar `hero_image` en D1
- [ ] T3.7 — Actualizar `content_json` para servicios con fallback
- [ ] T3.8 — Verificación visual en todas las páginas
- [ ] T3.9 — Commit Fase 3
- [ ] T3.10 — **Desactivar componentes legacy definitivamente** (ya validados)
