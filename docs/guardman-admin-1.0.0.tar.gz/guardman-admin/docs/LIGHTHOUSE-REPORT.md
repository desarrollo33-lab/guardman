# Lighthouse Audit — GuardMan Chile

**Fecha:** 2026-05-09  
**URL base:** https://guardman.oficinadesarrollo33.workers.dev  
**Estrategia:** Desktop (Chrome headless, Lighthouse CLI v12)  
**Nota:** PageSpeed Insights API rate-limited → usado Lighthouse CLI local.

---

## Scores Generales

| Página | Performance | Accessibility | SEO | Best Practices |
|--------|-------------|---------------|-----|----------------|
| `/` (homepage) | **94** | **94** | 100 | 100 |
| `/servicios/guardias-de-seguridad` | **100** | **90** | 100 | 100 |
| `/ubicaciones/las-condes` | **98** | **96** | 100 | 100 |
| `/nosotros` | **100** | **92** | 100 | 100 |
| `/guard-pod` (dark) | **92** | **90** | 100 | 100 |
| `/contacto` | **100** | **88** | 100 | **92** |

---

## Core Web Vitals (Homepage)

| Métrica | Valor | Objetivo | Estado |
|---------|-------|----------|--------|
| **LCP** | 1,437 ms | < 2,500 ms | ✅ Bueno |
| **FCP** | 743 ms | < 1,800 ms | ✅ Bueno |
| **TTFB** | 879 ms | < 800 ms | ⚠️ Necesita mejora |
| **TBT** | 0 ms | < 200 ms | ✅ Perfecto |
| **CLS** | 0.005 | < 0.1 | ✅ Perfecto |

### Core Web Vitals por página

| Página | LCP | FCP | TTFB | CLS |
|--------|-----|-----|------|-----|
| `/` | 1,437 ms | 743 ms | 879 ms | 0.005 |
| `/servicios/guardias-de-seguridad` | 402 ms | 322 ms | 268 ms | 0.001 |
| `/ubicaciones/las-condes` | 975 ms | 849 ms | 55 ms | 0.001 |
| `/nosotros` | 425 ms | 425 ms | 419 ms | 0.002 |
| `/guard-pod` | 1,610 ms | 1,050 ms | 448 ms | 0.002 |
| `/contacto` | 606 ms | — | — | — |

---

## Problemas Críticos Encontrados

### Performance

| # | Problema | Impacto | Páginas afectadas |
|---|---------|---------|-------------------|
| 1 | **TTFB elevado en homepage** (879 ms) | -6 puntos perf | `/` |
| 2 | **Render-blocking requests** — CSS/JS externos bloquean pintado | 110–590 ms ahorro | `/`, `/guard-pod`, `/ubicaciones`, `/nosotros`, `/contacto` |
| 3 | **LCP alto en GuardPod** (1,610 ms) — dark.css + imagen split | -8 puntos perf | `/guard-pod` |
| 4 | **Unused JavaScript** — Leaflet JS en homepage (24 KB no usado si no hay mapa visible) | Bajo | `/` |
| 5 | **Console errors** en `/contacto` — Leaflet JS genera errores | -8 puntos BP | `/contacto` |

### SEO

> **Score 100 en todas las páginas.** Cero problemas detectados.

| Auditoría | Resultado |
|-----------|-----------|
| document-title | ✅ |
| meta-description | ✅ |
| canonical | ✅ |
| hreflang | ✅ |
| robots.txt | ✅ |
| viewport | ✅ |
| structured-data | ✅ |

### Accessibility

| # | Problema | Score | Páginas afectadas |
|---|---------|-------|-------------------|
| 1 | **Color contrast insuficiente** | 0 | `/`, `/servicios`, `/nosotros`, `/guard-pod` |
| 2 | **Heading order incorrecto** (h1 → h3 sin h2, o niveles salteados) | 0 | Todas (6/6) |
| 3 | **Falta `<main>` landmark** | 0 | `/servicios`, `/ubicaciones`, `/guard-pod` |
| 4 | **Form labels ausentes** (`<select>` sin label) | 0 | `/contacto` |
| 5 | **Accessibility tree mal formado** (Leaflet DOM) | 0 | `/contacto` |

### Best Practices

| # | Problema | Páginas afectadas |
|---|---------|-------------------|
| 1 | **Console errors** — Leaflet JS | `/contacto` |
| 2 | **Inspector issues** — Chrome DevTools | `/contacto` |

---

## Recomendaciones Priorizadas

| # | Recomendación | Impacto estimado | Dificultad | Archivo(s) |
|---|--------------|-----------------|------------|------------|
| 1 | Reducir **TTFB homepage**: cachear HTML de homepage en KV con TTL más largo, o servir desde Cache API sin bloquear | +6 puntos perf | **Baja** | `src/index.ts` |
| 2 | Corregir **heading order**: revisar todas las páginas para que h1→h2→h3 no salteen niveles (hero badge usa h1 y luego no hay h2 antes de h3 en feature tiles) | A11y +10 puntos | **Media** | `src/ssr/site-renderer.ts` |
| 3 | Agregar **`<main>` landmark** en páginas sin él (servicio detalle, ubicación, GuardPod) | A11y +5 puntos | **Baja** | `src/ssr/site-renderer.ts` |
| 4 | Mejorar **color contrast**: aumentar opacidad de texto rgba(255,255,255,.85) → `.95` en fondos oscuros | A11y +5–10 puntos | **Baja** | `src/ssr/site-renderer.ts` |
| 5 | **Preload/async Leaflet**: solo cargar CSS/JS de Leaflet si la página tiene mapa visible | +2–3 puntos perf | **Media** | `src/ssr/site-renderer.ts` |
| 6 | **Form labels en contacto**: asociar `<label>` a `<select>` correctamente con `for`/`id` | A11y +2 puntos | **Baja** | `src/ssr/contacto-html.ts` |

---

## Detalle por Página

### `/` — Homepage

| Auditoría fallida | Severidad | Fix sugerido |
|-------------------|-----------|-------------|
| server-response-time | 🔴 TTFB 879 ms | Cachear homepage en KV/CF Cache con TTL 24h |
| color-contrast | 🔴 | Aumentar opacidad de texto overlay a `.95` o usar `#E5E5E5` |
| heading-order | 🔴 | Revisar jerarquía: badges, section titles, feature tiles |
| render-blocking-insight | 🟡 190 ms | Mover Leaflet CSS/JS a carga condicional |
| unused-javascript | 🟡 24 KB | Leaflet JS cargado innecesariamente al final de la página |

### `/servicios/guardias-de-seguridad`

| Auditoría fallida | Severidad | Fix sugerido |
|-------------------|-----------|-------------|
| color-contrast | 🔴 | Mismo fix que homepage |
| heading-order | 🔴 | Revisar `buildDetailPage` |
| landmark-one-main | 🔴 | Agregar `<main>` alrededor del contenido |

### `/ubicaciones/las-condes`

| Auditoría fallida | Severidad | Fix sugerido |
|-------------------|-----------|-------------|
| heading-order | 🔴 | Revisar `buildDetailPage` |
| landmark-one-main | 🔴 | Agregar `<main>` |
| render-blocking-insight | 🟡 270 ms | Leaflet scripts cargados sync |

### `/nosotros`

| Auditoría fallida | Severidad | Fix sugerido |
|-------------------|-----------|-------------|
| color-contrast | 🔴 | Texto sobre bg-dark (#0D0D0D) |
| heading-order | 🔴 | Revisar `buildNosotrosPage` |
| render-blocking-insight | 🟡 110 ms | CSS residual |

### `/guard-pod` (dark)

| Auditoría fallida | Severidad | Fix sugerido |
|-------------------|-----------|-------------|
| color-contrast | 🔴 | Dark theme — texto gris sobre fondo negro |
| heading-order | 🔴 | Revisar `buildGuardPodPage` |
| landmark-one-main | 🔴 | Agregar `<main>` |
| render-blocking-insight | 🟡 590 ms | `dark.css` cargado sync; considerar inline o preload |
| lcp-discovery-insight | 🟡 | Imagen split podría cargarse con `fetchpriority="high"` |

### `/contacto`

| Auditoría fallida | Severidad | Fix sugerido |
|-------------------|-----------|-------------|
| heading-order | 🔴 | Revisar `buildContactoPage` |
| label | 🔴 | `<select name="service">` sin `<label>` asociado |
| select-name | 🔴 | `id`/`for` faltante en selects del form |
| errors-in-console | 🔴 | Leaflet JS lanza errores al inicializar en headless |
| inspector-issues | 🔴 | DOM issues detectados por Chrome DevTools |
| agent-accessibility-tree | 🔴 | Árbol de accesibilidad roto (Leaflet) |
| forced-reflow-insight | 🟡 | Leaflet forzando reflow al inicializar mapa |
| render-blocking-insight | 🟡 | Leaflet CSS/JS bloqueantes |

---

## Archivos JSON crudos

Guardados en `docs/`:
- `lighthouse-homepage-mobile.json` — Homepage (desktop preset)
- `lighthouse-servicio.json` — Servicio detalle
- `lighthouse-ubicacion.json` — Ubicación detalle
- `lighthouse-nosotros.json` — Nosotros
- `lighthouse-guardpod.json` — Guard Pod (dark)
- `lighthouse-contacto.json` — Contacto

---

## Resumen

**Puntuación promedio:** Performance 97 / Accessibility 92 / SEO 100 / Best Practices 99

El sitio está en excelente estado. Los problemas son menores y de bajo esfuerzo:
- **TTFB** en homepage (único problema de performance real) → cache más agresivo
- **A11y**: heading order, `<main>` landmark, color contrast, form labels → fixes puntuales en templates
- **Leaflet** afecta contacto (console errors, reflow, accessibility tree)
- **SEO**: perfecto en todas las páginas (100/100)
- **Best Practices**: 100 excepto contacto (Leaflet console errors)

No hay problemas estructurales ni de arquitectura. El SSR en el edge con critical CSS inline está funcionando muy bien.
