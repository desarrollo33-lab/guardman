# Arquitectura Post-Migración — GuardMan Admin en Astro

**Fecha:** 2026-06-04
**Versión:** 1.0

---

## 1. Diagrama de Arquitectura

```
┌─────────────────────────────────────────────────────────────────────┐
│                        INTERNET (usuarios)                          │
└──────────────┬──────────────────────────────────┬───────────────────┘
               │                                  │
               ▼                                  ▼
┌──────────────────────────────┐   ┌──────────────────────────────────┐
│   Cloudflare Pages           │   │   Cloudflare Worker               │
│   (Astro SSR + Admin SPA)    │   │   (API REST + Agents + WF)        │
│                              │   │                                   │
│  ┌────────────────────────┐  │   │  POST /api/login                 │
│  │ Sitio Público (Astro)  │  │   │  /api/cms/*      — CMS CRUD      │
│  │ • /                    │  │   │  /api/crm/*      — CRM Pipeline  │
│  │ • /servicios/*         │  │   │  /api/intel/*    — Intel Hub     │
│  │ • /ubicaciones/*       │  │   │  /api/media/*    — Media Library │
│  │ • /sectores/*          │◄─┼───┼──│  /api/brand/*    — Brand DNA   │
│  │ • /nosotros            │  │   │  /api/agents/*   — WS DurableObj │
│  │ • /contacto            │  │   │  /api/ai/*       — AI Generation │
│  │ • ...                  │  │   │  /api/mcp        — MCP Server    │
│  │                        │  │   │  /api/images/*   — R2 Proxy      │
│  │ SSR con fetch al       │  │   │  /api/search/*   — AI Search     │
│  │ Worker API             │  │   │  /api/memory/*   — Agent Memory  │
│  └────────────────────────┘  │   │  /api/workflows/*— Manual Trigger│
│                              │   │  /health                         │
│  ┌────────────────────────┐  │   │                                   │
│  │ Admin Panel (Astro)    │  │   │  Durable Objects:                │
│  │ • /admin (CMS)         │  │   │  • ContentAgent                  │
│  │ • /admin/crm           │  │   │  • PublisherAgent                │
│  │ • /admin/media         │◄─┼───┼──│  • SerperAgent                  │
│  │ • /admin/intel         │  │   │  • Orchestrator                  │
│  │ • /admin/brand         │  │   │  • SEOAuditorAgent               │
│  │ • /admin/chat          │  │   │  • CompetitorAnalystAgent        │
│  │                        │  │   │  • LogSession                    │
│  │ Islas React para:     │  │   │  • RateLimiter                    │
│  │ Monaco Editor, Kanban, │  │   │                                   │
│  │ WebSocket Chat, Media  │  │   │  Workflows:                      │
│  │ Editor                  │  │   │  • SerperScanWorkflow            │
│  └────────────────────────┘  │   │  • BulkGenerateWorkflow          │
│                              │   │  • ScheduledReportsWorkflow      │
│  CSS: Tailwind v4           │   │  • SEOIntelWorkflow               │
│  Fuente: Inter (Google)     │   │  • ContentPipelineWorkflow        │
└──────────────────────────────┘   │  • QuickWinWorkflow               │
                                   │                                   │
                                   │  Cron Triggers (5 semanales):     │
                                   │  • Lunes 3AM — Serper Scan        │
                                   │  • Lunes 5AM — SEO Intel          │
                                   │  • Miérc 3AM — Quick Wins         │
                                   │  • Viern 3AM — Backfill Gaps      │
                                   │  • Dom 7AM   — Weekly Report      │
                                   │                                   │
                                   │  Queues: SEO_CONTENT_QUEUE        │
                                   └──────────────┬────────────────────┘
                                                  │
                    ┌─────────────────────────────┼─────────────────────┐
                    │                             │                     │
                    ▼                             ▼                     ▼
            ┌──────────┐                 ┌──────────────┐      ┌──────────────┐
            │ D1       │                 │ R2           │      │ KV           │
            │ guardman-│                 │ guardman-    │      │ CACHE        │
            │ seo      │                 │ images       │      │              │
            └──────────┘                 └──────────────┘      └──────────────┘
```

---

## 2. Flujo de Datos

### 2.1 Sitio Público (lectura)

```
Usuario → Astro SSR → fetch(/api/cms/content) → Worker → D1 → JSON → Astro render → HTML → Usuario
                                                             ↑
                                                        KV Cache (opcional)
```

**Cache strategy:**
- Astro SSR con `Cache-Control: public, max-age=3600, s-maxage=86400`
- CDN (Cloudflare) cachea HTML por 1 hora
- Al guardar contenido en CMS, se invalida cache vía `ctx.waitUntil(invalidateCache(...))`
- Opcional: ISR (Incremental Static Regeneration) con Astro + Cloudflare KV

### 2.2 Admin Panel (lectura/escritura)

```
Usuario → Astro SSR (layout) → Isla React (hidratada en cliente) → fetch(/api/...) → Worker → D1/R2 → JSON → React state → UI
```

**Auth flow:**
```
Login Form (Astro/React) → POST /api/login → Worker valida → Token JWT/simple → localStorage
Todas las requests → Authorization: Bearer <token> → Worker middleware → D1/KV/DO
```

### 2.3 WebSocket (Chat + Agentes)

```
Usuario → Isla React ChatView → PartySocket → wss://...workers.dev/api/agents/chat → DurableObject → AI SDK → Workers AI
```

- PartySocket se mantiene como dependencia del lado cliente
- La isla React se monta con `client:only="react"` (solo browser)

---

## 3. Estructura de Archivos del Proyecto Astro

```
guardman-astro/
├── astro.config.mjs              # Config: cloudflare adapter, react, tailwind
├── tsconfig.json
├── package.json
├── wrangler.jsonc                # Config de Cloudflare Pages
│
├── public/
│   ├── favicon.svg
│   ├── robots.txt
│   ├── fonts/
│   │   └── inter-*.woff2
│   └── cuestionario-ceo-rodrigo.html
│
├── src/
│   ├── env.d.ts                  # Tipos de entorno
│   │
│   ├── styles/
│   │   └── global.css            # Tailwind v4 @import + @theme tokens
│   │
│   ├── lib/
│   │   ├── api.ts                # Cliente HTTP para el Worker API
│   │   ├── auth.ts               # Auth helpers (token, login, logout)
│   │   └── constants.ts          # SITE_URL, PHONE, SERVICE_NAMES, etc.
│   │
│   ├── layouts/
│   │   ├── BaseLayout.astro      # HTML shell + SEO meta + header + footer
│   │   ├── AdminLayout.astro     # Admin shell + sidebar + topbar
│   │   └── DarkLayout.astro      # Variante dark (Guard Pod, Ajax)
│   │
│   ├── components/
│   │   ├── SEO.astro             # Meta tags + OG + JSON-LD schemas
│   │   ├── Header.astro          # Navegación pública
│   │   ├── Footer.astro          # Footer público
│   │   ├── Hero.astro            # Hero section reutilizable
│   │   ├── CTASection.astro      # Call-to-action section
│   │   ├── FAQ.astro             # FAQ accordion
│   │   ├── FeatureList.astro     # Grid de features
│   │   ├── LocationMap.astro     # Mapa Leaflet/OSM
│   │   ├── Button.astro          # Button component
│   │   ├── Badge.astro           # Badge/tag component
│   │   ├── Card.astro            # Card component
│   │   │
│   │   └── admin/
│   │       ├── Sidebar.astro     # Sidebar de admin
│   │       ├── Topbar.astro      # Topbar de admin
│   │       ├── LoginForm.tsx     # Login (React island)
│   │       ├── CMSPage.tsx       # CMS Editor (React island)
│   │       ├── SEOPanel.tsx      # SEO Panel (React island)
│   │       ├── MonacoEditor.tsx  # Monaco wrapper (React island)
│   │       ├── PreviewFrame.tsx  # Preview iframe (React island)
│   │       ├── ChatView.tsx      # Chat WebSocket (React island)
│   │       ├── ADNPage.tsx       # Brand DNA (React island)
│   │       ├── MediaEditor.tsx   # Media editor (React island)
│   │       │
│   │       └── crm/
│   │           ├── CRMDashboard.astro  # Dashboard (Astro puro)
│   │           ├── CRMPipeline.tsx     # Kanban (React island)
│   │           ├── LeadDetail.tsx      # Lead ficha (React island)
│   │           ├── ClientList.tsx      # Clientes (React island)
│   │           ├── ClientDetail.tsx    # Cliente ficha (React island)
│   │           └── ProposalBuilder.tsx # Cotización (React island)
│   │
│   └── pages/
│       ├── index.astro                   # Homepage
│       ├── nosotros.astro                # Nosotros
│       ├── guard-pod.astro               # Guard Pod (dark)
│       ├── ajax-systems.astro            # Ajax Systems (dark)
│       ├── contacto.astro                # Contacto + form
│       ├── cotizacion.astro              # Cotización + form
│       ├── privacidad.astro              # Privacidad
│       ├── terminos.astro                # Términos
│       ├── gracias.astro                 # Gracias post-form
│       ├── 404.astro                     # 404
│       ├── 500.astro                     # 500
│       ├── sitemap.xml.ts                # Sitemap dinámico
│       ├── robots.txt.ts                 # Robots.txt
│       │
│       ├── servicios/
│       │   ├── index.astro               # Hub de servicios
│       │   ├── [slug].astro              # Detalle servicio
│       │   └── [service]/[location].astro # Combo servicio+ubicación
│       │
│       ├── ubicaciones/
│       │   ├── index.astro               # Hub de ubicaciones + mapa
│       │   └── [slug].astro              # Detalle ubicación
│       │
│       ├── sectores/
│       │   ├── index.astro               # Hub de sectores
│       │   └── [slug].astro              # Detalle sector
│       │
│       └── admin/
│           ├── index.astro               # CMS (default admin view)
│           ├── crm.astro                  # CRM Pipeline
│           ├── media.astro               # Media Editor
│           ├── intel.astro               # Intel Hub
│           ├── brand.astro               # Brand DNA
│           └── chat.astro                # Chat con agentes
│
└── worker/                                # (opcional, si se unifica)
    └── ... (código del Worker actual, recortado)
```

---

## 4. Decisiones de Arquitectura

### 4.1 ¿Por qué separar Astro del Worker?

**Ventajas:**
- Separación clara de responsabilidades: frontend vs API
- Astro puede deployarse a Pages (gratis, CDN global)
- El Worker sigue funcionando aunque Astro esté en build
- Escalado independiente

**Desventajas:**
- CORS entre Pages y Worker (se resuelve con headers)
- 2 deployments en lugar de 1
- Latencia extra por el fetch (mínima, mismo datacenter CF)

### 4.2 ¿Por qué islas React y no SPA completo?

**Ventajas:**
- Las páginas simples (dashboard, listas, formularios) son Astro puro → 0KB JS
- Solo los componentes interactivos (Kanban, Monaco, Chat, Media Editor) cargan React
- Mejor performance: menos JS enviado al cliente
- SEO nativo en páginas públicas

**Desventajas:**
- El admin tiene "flickering" al navegar entre páginas (MPA vs SPA)
- Cada isla React es un mini-bundle independiente
- Estado compartido entre islas requiere soluciones (nanostores, context, URL params)

### 4.3 ¿Qué se mantiene como React?

| Componente | Razón para mantener React |
|-----------|--------------------------|
| **MonacoEditor** | Solo funciona en browser, necesita DOM real |
| **CRMPipeline (Kanban)** | Drag & drop, estado complejo de columnas |
| **LeadDetail** | Múltiples tabs, formularios anidados, estado local |
| **ChatView** | WebSocket en tiempo real, streaming de mensajes |
| **MediaEditor** | Estado complejo con useReducer, subida de archivos |
| **ADNPage** | Formulario dinámico con muchos campos |
| **SEOPanel** | Panel lateral con cálculos en tiempo real |
| **CMSPage** | Editor integrado con Monaco, preview, regeneración |
| **PreviewFrame** | Iframe dinámico con postMessage |

### 4.4 ¿Qué se hace en Astro puro?

| Componente | Razón para Astro puro |
|-----------|----------------------|
| **Header, Footer, Sidebar, Topbar** | Estáticos, solo navegación |
| **CRMDashboard** | Datos fetch + render, sin interactividad compleja |
| **Hero, FAQ, FeatureList, CTA** | Componentes de presentación |
| **Todas las páginas públicas** | SSR con datos de API, HTML semántico |
| **Páginas de admin (routing)** | Solo layout + slot para isla React |
| **LoginForm** | Formulario simple con fetch |

---

## 5. Plan de Caché

### 5.1 Páginas Públicas

```
Tipo: SSR con CDN cache
Cache-Control: public, max-age=3600, s-maxage=86400
Invalación: Al guardar contenido en CMS → POST /api/cms/rebuild → flush KV
```

### 5.2 API Responses

```
Tipo: CDN cache para GETs públicos
/api/cms/content → Cache-Control: public, max-age=300
/api/cms/list → Cache-Control: public, max-age=300
/api/images/* → Cache-Control: public, max-age=31536000, immutable
```

### 5.3 Admin

```
Tipo: No-cache (siempre fresco)
Cache-Control: no-cache, no-store, must-revalidate
```

---

## 6. Dependencias Finales

### 6.1 Proyecto Astro (nuevo)

```json
{
  "dependencies": {
    "@astrojs/cloudflare": "^x",
    "@astrojs/react": "^x",
    "@tailwindcss/vite": "^4",
    "tailwindcss": "^4",
    "astro": "^5",
    "react": "^19",
    "react-dom": "^19",
    "@monaco-editor/react": "^4",
    "partysocket": "^1",
    "@ai-sdk/react": "^3",
    "@cloudflare/ai-chat": "^0.4",
    "lucide-react": "^1",
    "clsx": "^2",
    "marked": "^18"
  },
  "devDependencies": {
    "@types/react": "^19",
    "@types/react-dom": "^19",
    "typescript": "^5",
    "wrangler": "^4"
  }
}
```

### 6.2 Worker (recortado)

```json
{
  "dependencies": {
    "@ai-sdk/anthropic": "^3",
    "@ai-sdk/openai-compatible": "^2",
    "@cloudflare/ai-chat": "^0.4",
    "@cloudflare/workers-types": "^4",
    "agents": "^0.11",
    "ai": "^6",
    "workers-ai-provider": "^3"
  }
  // Se eliminan: react, react-dom, lucide-react, memfs
}
```

---

## 7. Preguntas Abiertas para la Fase 2

1. **Cloudflare Pages vs Worker unified:** ¿Probamos Pages primero y si hay problemas de CORS/latencia migramos a Worker unified?
2. **Astro v5 vs v4:** ¿Qué versión de Astro está disponible al momento de implementar?
3. **View Transitions:** ¿Usamos View Transitions de Astro para navegación más suave en el admin?
4. **Persistent state:** ¿Nanostores para compartir estado entre islas React (ej: auth token, lead seleccionado)?
5. **ISR:** ¿Vale la pena implementar Incremental Static Regeneration con KV para páginas públicas muy visitadas?
