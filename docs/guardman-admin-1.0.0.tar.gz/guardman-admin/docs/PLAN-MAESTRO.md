# GuardMan Admin — Plan Maestro de Trabajo
## Desde adentro hacia afuera: infraestructura → CMS → visual → contenido

**Fecha:** 2026-05-08  
**Estado:** ✅ COMPLETADO — 2026-05-08 (29/32 tareas, 91%)  
**Filosofía:** Cada fase construye sobre la anterior. No se salta fases.

---

# CONTEXTO GENERAL

## Arquitectura del sistema

```
/Admin (React SPA en /public/admin/)
   │   Editor CMS → guarda content_json en D1
   │   Scoring SEO → feedback instantáneo
   │   IA Regenerate → genera contenido con DeepSeek
   ▼
D1 (static_page_content + content_versions + services + locations + sectors)
   │
   ▼
Worker SSR (src/index.ts → src/ssr/site-renderer.ts + site-data.ts)
   │   Lee content_json → mergea con defaults → genera HTML
   │   Cachea en KV → invalida al guardar desde CMS
   ▼
Sitio Público (20+ rutas SSR servidas desde el mismo Worker)
```

**Regla de oro:** `/admin` es el headless CMS. Todo contenido editable debe salir de D1. El SSR es el renderer que consume D1. Open Design (`cf058157`) es la referencia visual canónica.

## Archivos clave

| Archivo | Rol | Líneas |
|---------|-----|--------|
| `src/index.ts` | Router principal + builders inline (gracias, blog, 404, 500) | ~694 |
| `src/ssr/site-renderer.ts` | Templates HTML, layout (hdr/ftr), heroes, page builders | ~738 |
| `src/ssr/site-data.ts` | Fetchers D1 → SiteData para cada tipo de página | ~479 |
| `src/ssr/*-html.ts` | 7 archivos HTML importados por páginas estáticas | ~400 |
| `src/api/routes/cms.ts` | API CRUD del CMS, save, regenerate, media | ~692 |
| `src/services/cache.ts` | KV cache get/set/invalidate/flush | ~80 |
| `src/services/ai.ts` | Generación de contenido con IA | ~391 |
| `src/types/index.ts` | Interfaces Env, ContentJob, etc. | ~200 |
| `public/styles/site.css` | CSS light theme (todas las páginas excepto dark) | 326 |
| `public/styles/dark.css` | CSS dark theme (solo Guard Pod + Ajax) | 78 |
| `public/scripts/main.js` | Menú móvil toggle | ~45 |
| `guardman-admin-ui/.../CMSPage.tsx` | Editor CMS principal | ~1,580 |
| `guardman-admin-ui/.../SEOPanel.tsx` | Panel SEO lateral | ~260 |

## Decisión de diseño registradas

El equipo ha decidido conscientemente:
- **Sin stats rows en hubs** (`/servicios`, `/ubicaciones`, `/sectores`) — son repetitivos
- **Sin filter bar en `/servicios`** — simplificación deliberada
- **Sin sector badges en cards del hub** — reduce ruido visual
- **Ubicaciones hub simplificado** — tag-links funcionales vs cards decorativas
- **Hero CTA: outline-light** — consistencia visual
- **Mapa homepage: static image** — rendimiento

---

# FASE 0: QUICK FIXES
## Bugs y inconsistencias que se resuelven en minutos

**Criterio:** Cambios puntuales, sin riesgo de regresión, sin tocar arquitectura.

---

### T0.1 — CSS_V inconsistente entre index.ts y site-renderer.ts

**Problema:** `site-renderer.ts` usa `CSS_V = '1778255342'` centralizado. Pero los 5 builders inline en `index.ts` (buildGraciasPage, buildBlogListing, buildBlogPost, build404Page, build500Page) tienen `?v=1778225742` hardcoded — un valor viejo que nunca se actualiza.

**Archivos:** `src/index.ts` (5 ocurrencias), `src/ssr/site-renderer.ts` (exportar CSS_V)

**Fix:**

```typescript
// src/ssr/site-renderer.ts — ya tiene la constante, solo exportarla
export const CSS_V = '1778255342';

// src/index.ts — importar y usar
import { ..., hdr, ftr, CSS_V } from './ssr/site-renderer';

// Luego reemplazar las 5 ocurrencias de ?v=1778225742 por ?v=${CSS_V}
```

**Verificación:** `grep -n "?v=" src/index.ts` → solo debe mostrar `?v=${CSS_V}`.

- [ ] Exportar `CSS_V` desde `site-renderer.ts`
- [ ] Importar `CSS_V` en `index.ts`
- [ ] Reemplazar 5 ocurrencias hardcoded en builders inline
- [ ] `grep` verifica 0 ocurrencias de `?v=17782`

---

### T0.2 — JSON-LD malformado en buildBlogPost

**Problema:** En `buildBlogPost()` (index.ts ~línea 670), el schema JSON-LD tiene la llave `}` que cierra el objeto ANTES del campo `image` condicional. Genera JSON inválido cuando el post tiene imagen.

**Archivo:** `src/index.ts`, función `buildBlogPost()`

**Fix actual (roto):**
```
..."url":"https://guardman.cl/blog/${slug}"}${image ? `,"image":"..."` : ''}
```

**Fix correcto:**
```typescript
// Construir el objeto JSON-LD por separado
const blogLd: Record<string, any> = {
  '@context': 'https://schema.org',
  '@type': 'BlogPosting',
  headline: post.title,
  description: post.meta_description || post.excerpt || '',
  author: { '@type': 'Organization', name: post.author || 'GuardMan Chile' },
  datePublished: post.published_at || '',
  url: `https://guardman.cl/blog/${esc(post.slug)}`
};
if (post.image) blogLd.image = `https://guardman.cl${esc(post.image)}`;
const ldJson = JSON.stringify(blogLd);
// Usar: <script type="application/ld+json">${ldJson}</script>
```

- [ ] Refactorizar buildBlogPost para generar JSON-LD con JSON.stringify
- [ ] Verificar con JSON.parse que el output es válido con y sin imagen

---

### T0.3 — Zona-dot CSS duplicado en site.css

**Problema:** Las clases `.zone-dot` y `.dot-*` están declaradas 2 veces en `site.css`.

**Archivo:** `public/styles/site.css`

**Fix:** Eliminar el bloque duplicado (el segundo, líneas ~125).

- [ ] Eliminar bloque duplicado de `.zone-dot` y `.dot-*`
- [ ] Verificar que las 6 clases siguen funcionando

---

### T0.4 — Función `esc()` duplicada entre index.ts y site-renderer.ts

**Problema:** Ambos archivos tienen la misma función `esc()` definida localmente.

**Fix:** Exportar desde `site-renderer.ts` e importar en `index.ts`.

```typescript
// site-renderer.ts — ya tiene esc(), solo exportarla
export function esc(s: string | undefined | null): string { ... }

// index.ts — importar
import { ..., esc } from './ssr/site-renderer';
// Eliminar la definición local de esc() en index.ts
```

- [ ] Exportar `esc()` desde site-renderer.ts
- [x] Importar en index.ts, eliminar definición local
- [x] Build sin errores

---

### T0.5 — buildSections() duplicado entre site-renderer.ts y site-data.ts

**Problema:** La función `buildSections()` existe en ambos archivos con lógica casi idéntica.

**Fix:** Eliminar la de `site-data.ts` (la de `site-renderer.ts` es la que se usa en producción). La de site-data.ts está al final del archivo y no se exporta ni importa en ningún lado.

- [ ] Eliminar `buildSections()` de `site-data.ts`
- [ ] Eliminar `fetchStaticPage()` de `site-data.ts` (no se usa)
- [x] Build sin errores

---

### T0.6 — Deploy y verificación

- [ ] `npx wrangler deploy`
- [ ] Verificar `/gracias` carga CSS correcto (ver versión en network tab)
- [ ] Verificar `/blog` con post que tenga imagen → JSON-LD válido (verificar en view-source)
- [ ] Verificar `/nosotros` → zona-dots visibles sin duplicados

---

# FASE 1: FORTALECIMIENTO DE INFRAESTRUCTURA
## Sanitización, seguridad y consistencia del Worker

**Criterio:** Cambios que afectan la capa de routing, seguridad y generación de HTML. No se toca el CMS ni el contenido.

---

### T1.1 — Extraer SITE_URL como constante compartida

**Problema:** `https://guardman.cl` está hardcoded en ~40 lugares entre `site-renderer.ts`, `site-data.ts`, e `index.ts`. Si el dominio cambia, hay que tocar decenas de líneas.

**Archivos:** `src/ssr/site-renderer.ts`, `src/index.ts`

**Fix:**

```typescript
// src/ssr/site-renderer.ts — ya tiene const SITE_URL = 'https://guardman.cl';
// Exportarla:
export const SITE_URL = 'https://guardman.cl';

// src/index.ts — importar
import { ..., CSS_V, esc, SITE_URL } from './ssr/site-renderer';

// Reemplazar hardcoded 'https://guardman.cl' por SITE_URL en:
// - handleSitemap() (12+ ocurrencias)
// - buildBlogPost() (canonical, og:url, schema)
// - buildBlogListing() (canonical)
// - buildGraciasPage() (canonical)
```

- [ ] Exportar `SITE_URL` desde site-renderer.ts
- [x] Importar en index.ts
- [ ] Reemplazar todas las ocurrencias de `'https://guardman.cl'` en index.ts
- [x] Build sin errores

---

### T1.2 — Sanitización de blog content (anti-XSS)

**Problema:** `buildBlogPost()` inyecta `post.content` directamente en el HTML sin sanitización. Si un admin introduce HTML malicioso desde el CMS, se ejecuta en el sitio público.

**Archivo:** `src/index.ts`, función `buildBlogPost()`

**Fix:** Agregar sanitización básica que permite tags seguros pero elimina scripts:

```typescript
function sanitizeHtml(html: string): string {
  return html
    // Eliminar script tags completos
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    // Eliminar event handlers inline (onclick, onerror, etc.)
    .replace(/\s+on\w+\s*=\s*["'][^"']*["']/gi, '')
    // Eliminar javascript: URLs
    .replace(/href\s*=\s*["']javascript:[^"']*["']/gi, 'href="#"')
    // Eliminar <iframe>, <object>, <embed>
    .replace(/<\/?(iframe|object|embed|form)\b[^>]*>/gi, '');
}
```

Uso en `buildBlogPost()`:
```typescript
// ANTES:
<div>${post.content || ''}</div>

// DESPUÉS:
<div>${sanitizeHtml(post.content || '')}</div>
```

- [ ] Crear función `sanitizeHtml()` en index.ts (o mejor, en utils compartidos)
- [ ] Aplicar en buildBlogPost
- [ ] Test: crear post con `<script>alert('xss')</script>` → no se ejecuta

---

### T1.3 — Estrategia de cache consistente

**Problema:** El código escribe a KV cache (TTL 3600s) pero sirve la respuesta con `Cache-Control: no-cache, must-revalidate`. Esto es contradictorio: el browser nunca cachea pero el edge sí.

**Archivo:** `src/index.ts`, función `renderSitePage()`

**Fix:** Unificar la estrategia. El KV cache es para servir rápido desde edge. El browser debería respetar un cache razonable:

```typescript
// Respuesta MISS (generada fresh):
return new Response(html, {
  headers: {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'public, max-age=3600, s-maxage=86400',
    'CDN-Cache-Control': 'public, max-age=3600',
    'X-Cache': 'MISS',
  },
});

// Respuesta HIT (desde KV):
return new Response(cachedHtml, {
  headers: {
    'Content-Type': 'text/html; charset=utf-8',
    'Cache-Control': 'public, max-age=3600, s-maxage=86400',
    'CDN-Cache-Control': 'public, max-age=86400',
    'X-Cache': 'HIT',
  },
});
```

**Nota:** El flush de KV cache al guardar desde CMS (ARCH-01) sigue funcionando igual. La diferencia es que ahora el browser también cachea 1h, reduciendo requests al Worker.

- [ ] Cambiar headers de respuesta MISS a `max-age=3600`
- [ ] Cambiar headers de respuesta HIT a `max-age=3600`
- [ ] Verificar que flush KV cache al guardar desde CMS sigue invalidando

---

### T1.4 — MIME type fix extraído a función compartida

**Problema:** La lógica de fix de Content-Type para R2 está duplicada en `/images/` y `/api/images/`.

**Archivo:** `src/index.ts`

**Fix:**

```typescript
function fixImageContentType(headers: Headers, key: string): void {
  const ct = headers.get('Content-Type') || '';
  if (ct === 'application/octet-stream' || !ct) {
    if (key.endsWith('.webp')) headers.set('Content-Type', 'image/webp');
    else if (key.endsWith('.jpg') || key.endsWith('.jpeg')) headers.set('Content-Type', 'image/jpeg');
    else if (key.endsWith('.png')) headers.set('Content-Type', 'image/png');
    else if (key.endsWith('.svg')) headers.set('Content-Type', 'image/svg+xml');
    else if (key.endsWith('.gif')) headers.set('Content-Type', 'image/gif');
  }
}

// Uso en /images/:
const object = await env.IMAGES.get(key);
if (object) {
  const headers = new Headers();
  object.writeHttpMetadata(headers);
  headers.set('etag', object.httpEtag);
  headers.set('Cache-Control', 'public, max-age=31536000, immutable');
  headers.set('Access-Control-Allow-Origin', '*');
  fixImageContentType(headers, key);
  return new Response(object.body, { headers });
}
```

- [ ] Crear función `fixImageContentType()`
- [ ] Reemplazar las 2 copias de la lógica inline
- [x] Build sin errores

---

### T1.5 — Auth token check más estricto

**Problema:** El endpoint `/health/homepage-debug` usa `authHdr?.includes(env.AUTH_TOKEN!)` que permite coincidencias parciales. Un token "abc" pasaría si el header contiene "xyzabcdef".

**Archivo:** `src/index.ts`, endpoint `/health/homepage-debug`

**Fix:**
```typescript
// ANTES:
const isAuthed = authHdr?.includes(env.AUTH_TOKEN!) || ...

// DESPUÉS:
const isAuthed = authHdr === `Bearer ${env.AUTH_TOKEN}` || token === env.AUTH_TOKEN;
```

- [ ] Cambiar includes() por comparación estricta
- [ ] Verificar que el CMS sigue accediendo correctamente

---

### T1.6 — Deploy y verificación de Fase 1

- [ ] `npx wrangler deploy`
- [ ] Verificar que `/` carga correctamente (cache headers en network tab)
- [ ] Verificar que `/blog` con contenido HTML no ejecuta scripts
- [ ] Verificar que una imagen R2 sirve con Content-Type correcto
- [ ] Verificar que `/health/homepage-debug` rechaza tokens parciales

---

# FASE 2: CMS → SITIO PÚBLICO (CONECTAR TODO EL CONTENIDO)
## Hacer que cada página sea editable desde /admin

**Criterio:** Extender el patrón `content_json → SSR override` que ya funciona para homepage a todas las páginas estáticas. Sin cambiar el HTML structure, solo conectando los datos.

---

### T2.1 — Arquitectura del content_json para páginas estáticas

**Contexto:** Hoy las 7 páginas estáticas (nosotros, guard-pod, ajax, contacto, cotizacion, privacidad, terminos) guardan `content_json` en D1 al editar desde el CMS, pero el SSR solo lee las columnas planas (`meta_title`, `meta_description`, `hero_heading`, `hero_subheading`). El body HTML es hardcoded en los archivos `*-html.ts`.

**Objetivo:** Que el CMS pueda overridear secciones específicas del body sin perder el HTML canónico como fallback.

**Esquema de content_json para cada página:**

```typescript
// Ejemplo: /nosotros
interface NosotrosContent {
  seo: { title: string; description: string };
  hero: { headline: string; subheadline: string };
  stats: Array<{ value: string; label: string }>;
  timeline: Array<{ year: string; title: string; description: string }>;
  values: Array<{ title: string; description: string }>;
  differentiators: Array<{ icon: string; title: string; description: string }>;
  certifications: Array<{ title: string; description: string }>;
  staff: { image: string; traits: string[] };
}

// Ejemplo: /guard-pod  
interface GuardPodContent {
  seo: { title: string; description: string };
  hero: { headline: string; subheadline: string; badge: string };
  intro: { paragraphs: string[]; image: string };
  features: Array<{ icon: string; title: string; description: string }>;
  problems: Array<{ description: string }>;
  faqs: Array<{ question: string; answer: string }>;
  stats: Array<{ value: string; label: string }>;
}
```

**Principio:** Cada campo overrideable tiene un default en el `*-html.ts` canónico. Si el `content_json` tiene el campo, lo usa. Si no, usa el default del HTML importado.

- [ ] Definir interfaces para las 7 páginas estáticas
- [ ] Documentar en `src/ssr/STATIC-PAGES-SCHEMA.md`

---

### T2.2 — Builder de Nosotros dinámico (CMS-driven)

**Problema:** `buildNosotrosPage()` importa `NOSOTROS_HTML` como string estático. El CMS puede editar meta/hero pero NO puede editar stats, timeline, valores, diferenciadores, certificaciones, o staff.

**Archivo:** `src/ssr/site-renderer.ts`, función `buildNosotrosPage()`

**Estrategia:** Mantener `NOSOTROS_HTML` como fallback, pero si `content_json` tiene overrides, generar las secciones dinámicamente.

```typescript
export function buildNosotrosPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Nosotros — GuardMan Chile | Seguridad Privada en Santiago';
  let desc = d?.meta_description || '...';
  let heroH = 'Protegemos lo que más te importa desde 2017';
  let heroS = 'GuardMan Chile nació con una convicción...';
  
  // Parse content_json overrides
  if (d?.content_json) {
    try {
      const cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json;
      const seo = cj.seo || {};
      const hero = cj.hero || {};
      if (seo.title) title = seo.title;
      if (seo.description) desc = seo.description;
      if (hero.headline) heroH = hero.headline;
      if (hero.subheadline) heroS = hero.subheadline;
      
      // Si hay secciones de body overrideadas, generar HTML dinámico
      const hasBodyOverrides = cj.stats || cj.timeline || cj.values 
                            || cj.differentiators || cj.certifications;
      if (hasBodyOverrides) {
        const bodyHtml = buildNosotrosBody(cj);
        return wrapInPage(title, desc, heroH, heroS, bodyHtml);
      }
    } catch { /* fallback to static HTML */ }
  }
  
  // Default: usar HTML canónico importado
  const bodyHtml = NOSOTROS_HTML.replace(/<section class="hero"[\s\S]*?<\/section>/, '');
  return wrapInPage(title, desc, heroH, heroS, bodyHtml);
}

function buildNosotrosBody(cj: any): string {
  let html = '';
  
  // Stats
  if (cj.stats?.length) {
    html += `<div class="stats-row" data-od-id="stats"><div class="container stats-grid">`;
    for (const s of cj.stats) {
      html += `<div class="stat-item"><div class="stat-value">${esc(s.value)}</div><div class="stat-label">${esc(s.label)}</div></div>`;
    }
    html += `</div></div>`;
  }
  
  // Timeline
  if (cj.timeline?.length) {
    html += `<section class="bg-white" data-od-id="historia"><div class="container" style="max-width:760px">`;
    html += `<span class="section-label">Nuestra Historia</span><h2 class="section-title">...</h2>`;
    html += `<div class="timeline">`;
    for (const t of cj.timeline) {
      html += `<div class="timeline-item"><div class="timeline-year">${esc(t.year)}</div><div class="timeline-content"><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p></div></div>`;
    }
    html += `</div></div></section>`;
  }
  
  // ... valores, diferenciadores, certificaciones, staff (mismo patrón)
  
  // Fallback: si una sección no está overrideada, NO se genera (se asume que 
  // el admin quiere ocultarla, o se puede insertar la versión canónica)
  
  return html;
}
```

**NOTA IMPORTANTE:** Este es el patrón más complejo del plan. La implementación real debe ser iterativa: primero conectar solo hero+stats+timeline, verificar que funciona, y luego agregar las demás secciones una por una.

- [ ] Crear `buildNosotrosBody()` con generación dinámica de stats y timeline
- [ ] Conectar content_json override para stats y timeline
- [ ] Fallback a NOSOTROS_HTML cuando no hay overrides
- [ ] Test: editar stats desde CMS → verificar que se refleja en el sitio
- [ ] Agregar valores, diferenciadores, certificaciones, staff (iterativo)

---

### T2.3 — Builder de Guard Pod dinámico (CMS-driven)

**Mismo patrón que T2.2 pero para Guard Pod.**

**Archivo:** `src/ssr/site-renderer.ts`, función `buildGuardPodPage()`

**Campos overrideable:**
- `hero.headline`, `hero.subheadline`, `hero.badge`
- `intro.paragraphs[]`, `intro.image`
- `features[]` → feature-grid dark
- `problems[]` → problems-grid dark
- `faqs[]` → FAQ dark
- `stats[]` → hero-stats

**Particularidad:** Las páginas dark cargan `dark.css` y usan clases dark-specific (`.feature-card`, `.problem-card`, etc.). El builder dinámico debe usar estas mismas clases.

- [ ] Crear `buildGuardPodBody()` con generación dinámica
- [ ] Conectar content_json override
- [ ] Mantener `GUARDPOD_HTML` como fallback
- [ ] Test: editar features desde CMS → verificar en sitio

---

### T2.4 — Builder de Ajax Systems dinámico (CMS-driven)

**Mismo patrón que T2.3.**

- [ ] Crear `buildAjaxBody()` con generación dinámica
- [ ] Conectar content_json override
- [ ] Mantener `AJAX_HTML` como fallback
- [ ] Test: editar features desde CMS → verificar en sitio

---

### T2.5 — Builders de Contacto y Cotización dinámicos

**Campos overrideable para contacto:**
- `seo.title`, `seo.description`
- `hero.headline`, `hero.subheadline`
- `contact.phone`, `contact.email`, `contact.address`, `contact.hours`
- Formulario: los campos del form son fixos, pero el texto introductorio puede ser editable

**Campos overrideable para cotización:**
- `seo.title`, `seo.description`
- `hero.headline`, `hero.subheadline`
- `trust_badges[]` → 4 badges de confianza

**Nota:** Estas páginas son más simples — el body principal es el formulario que no cambia. Solo se overridean meta, hero y elementos decorativos.

- [ ] Conectar content_json override en buildContactoPage (hero + meta)
- [ ] Conectar content_json override en buildCotizacionPage (hero + meta + trust badges)
- [ ] Test: editar trust badges desde CMS → verificar en sitio

---

### T2.6 — Privacidad y Términos dinámicos

**Campos overrideable:** `seo.title`, `seo.description`, `hero.headline`, `body_content` (HTML del cuerpo legal).

**Particularidad:** Estas páginas son las más simples. El body es un bloque de texto legal que podría ser completamente editable.

```typescript
export function buildPrivacidadPage(env?: any): string {
  const d = (env as any)?._staticData;
  // ... parse seo/hero ...
  
  // Si el CMS guardó body_content, usarlo; si no, usar PRIVACIDAD_HTML
  const bodyHtml = cj?.body_content || PRIVACIDAD_HTML;
  // ...
}
```

- [ ] Conectar content_json override en buildPrivacidadPage
- [ ] Conectar content_json override en buildTerminosPage
- [ ] Test: editar texto legal desde CMS → verificar en sitio

---

### T2.7 — CMS Admin: UI para editar secciones de páginas estáticas

**Contexto:** Hoy el CMS solo muestra un editor genérico para páginas estáticas (meta title, description, hero). Para editar las nuevas secciones, el CMS necesita campos adicionales.

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

**Estrategia por página:**

| Página | Campos nuevos en el editor |
|--------|---------------------------|
| Nosotros | Stats (4 items), Timeline (5 items), Valores (4), Diferenciadores (6), Certificaciones (6) |
| Guard Pod | Features (8), Problems (6), FAQ (5), Stats (3) |
| Ajax | Features (6), WhyUs (3), FAQ (5), Stats (4) |
| Contacto | Info cards (teléfono, email, dirección, horario) |
| Cotización | Trust badges (4 items) |
| Privacidad | Body content (editor Monaco) |
| Términos | Body content (editor Monaco) |

**Principio:** Solo mostrar campos para las secciones que la página tiene. No mostrar "FAQ" en páginas que no tienen FAQ. Esto requiere detectar el tipo de página.

```typescript
// En CMSPage.tsx, cuando contentType === 'static':
const STATIC_PAGE_SECTIONS: Record<string, string[]> = {
  'nosotros': ['seo', 'hero', 'stats', 'timeline', 'values', 'differentiators', 'certifications', 'staff'],
  'guard-pod': ['seo', 'hero', 'intro', 'features', 'problems', 'faqs', 'stats'],
  'ajax-systems': ['seo', 'hero', 'features', 'whyUs', 'faqs', 'stats'],
  'contacto': ['seo', 'hero'],
  'cotizacion': ['seo', 'hero', 'trust_badges'],
  'privacidad': ['seo', 'hero', 'body_content'],
  'terminos': ['seo', 'hero', 'body_content'],
};
```

- [ ] Agregar detección de secciones por página en CMSPage.tsx
- [ ] Agregar campos de edición para stats + timeline en página Nosotros
- [ ] Agregar campos de edición para features + problems en Guard Pod
- [ ] Agregar campos de edición para features en Ajax
- [ ] Agregar campos de edición para trust badges en Cotización
- [ ] Agregar editor Monaco para body_content en Privacidad/Términos
- [ ] Verificar que save → D1 → SSR → sitio refleja los cambios

---

### T2.8 — CMS SEO Scoring para páginas estáticas

**Archivo:** `guardman-admin-ui/src/components/CMS/SEOPanel.tsx`

**Problema:** El SEOPanel tiene scoring para homepage y genérico, pero no entiende el formato de páginas estáticas con secciones (nosotros con stats/timeline, guard-pod con features/problems).

**Fix:** Agregar detección de formato por slug:

```typescript
const STATIC_FORMATS: Record<string, string> = {
  'nosotros': 'nosotros',
  'guard-pod': 'guard-pod', 
  'ajax-systems': 'ajax-systems',
  // ... contacto, cotizacion, privacidad, terminos usan 'generic'
};

function computeScore(content: any, slug: string) {
  const format = STATIC_FORMATS[slug] || 'generic';
  
  if (format === 'nosotros') {
    // Evaluar: title, desc, hero, stats count, timeline count, 
    // differentiators count, certifications count, staff traits
  } else if (format === 'guard-pod') {
    // Evaluar: title, desc, hero, features count, problems count, faqs count
  }
  // ... etc
}
```

- [ ] Extender computeScore() con formatos específicos por página
- [ ] Mostrar checks contextuales en el panel SEO
- [ ] Verificar que el score es coherente con el contenido

---

### T2.9 — Deploy y verificación de Fase 2

- [ ] `npx wrangler deploy`
- [ ] Test end-to-end para cada página:
  - Editar Nosotros desde CMS → guardar → verificar sitio actualizado
  - Editar Guard Pod desde CMS → guardar → verificar sitio actualizado
  - Editar Ajax desde CMS → guardar → verificar sitio actualizado
  - Editar Cotización trust badges → guardar → verificar sitio
  - Editar Privacidad body → guardar → verificar sitio
- [ ] Verificar que KV cache se invalida al guardar
- [ ] Verificar que el fallback a HTML canónico funciona cuando no hay overrides

---

# FASE 3: FIDELIDAD VISUAL CON OPEN DESIGN
## Ajustar layouts y componentes para matchear el diseño canónico

**Criterio:** Cambios visuales que NO afectan la arquitectura ni el flujo CMS. Solo tocan templates HTML y CSS.

---

### T3.1 — Hero custom para páginas dark (Guard Pod + Ajax)

**Problema:** El hero genérico `hero()` produce un layout simple (badge + h1 + p + ctas). Las páginas dark del Open Design tienen un hero con grid 2-columnas (texto + imagen de producto) y stats/trust items debajo de las CTAs.

**Archivo:** `src/ssr/site-renderer.ts`

**Solución:** Crear `heroDark()` como variante del hero:

```typescript
function heroDark(d: SiteData): string {
  return `<section class="hero" data-od-id="hero">
  <div class="container"><div class="hero-grid">
    <div>
      ${d.heroBadge ? `<div class="hero-badge">...</div>` : ''}
      <h1>${esc(d.heroHeading)}</h1>
      <p class="hero-sub">${esc(d.heroSubheading || '')}</p>
      <div class="hero-ctas">
        <a href="/cotizacion" class="btn btn-primary btn-lg">Cotizar</a>
        <a href="#features" class="btn btn-ghost btn-lg">Ver características</a>
      </div>
      ${d.darkHeroStats?.length ? `
      <div class="hero-stats">
        ${d.darkHeroStats.map(s => `<div><div class="hero-stat-value">${esc(s.value)}</div><div class="hero-stat-label">${esc(s.label)}</div></div>`).join('')}
      </div>` : ''}
      ${d.darkHeroTrust?.length ? `
      <div class="hero-trust">
        ${d.darkHeroTrust.map(t => `<div class="hero-trust-item"><svg ...>✓</svg>${esc(t)}</div>`).join('')}
      </div>` : ''}
    </div>
    <div class="hero-visual">
      <div class="hero-product">
        <img src="${esc(d.heroImage || '')}" alt="${esc(d.heroHeading)}" loading="eager">
      </div>
    </div>
  </div></div>
</section>`;
}
```

**Nuevos campos en SiteData:**
```typescript
darkHeroStats?: Array<{ value: string; label: string }>;
darkHeroTrust?: string[];
```

**Uso:**
```typescript
// buildGuardPodPage():
// ANTES: ${hero(d)}
// DESPUÉS: ${heroDark(d)}

// con datos:
darkHeroStats: [
  { value: '2h', label: 'Tiempo de despliegue' },
  { value: '15', label: 'Meses de I+D' },
  { value: '360°', label: 'Cobertura PTZ' },
]
```

- [ ] Crear función `heroDark()` en site-renderer.ts
- [ ] Agregar `darkHeroStats` y `darkHeroTrust` a SiteData
- [ ] Usar `heroDark()` en buildGuardPodPage() y buildAjaxPage()
- [ ] Agregar stats/trust data en site-data.ts o content_json defaults
- [ ] Verificar que dark.css ya tiene las clases necesarias (`.hero-grid`, `.hero-stats`, `.hero-trust`, `.hero-visual`, `.hero-product`)
- [ ] Test: verificar /guard-pod y /ajax-systems visualmente

---

### T3.2 — Homepage: card-icon SVG en servicios

**Problema:** El Open Design tiene cada card de servicio con un `<div class="card-icon">` conteniendo un SVG temático (user para guardias, camera para CCTV, lock para accesos, etc.). El SSR no genera estos iconos.

**Archivo:** `src/ssr/site-renderer.ts`, función `buildHomepage()`

**Solución:** Agregar un mapping de slug a SVG en el renderer:

```typescript
const SERVICE_ICONS: Record<string, string> = {
  'guardias-de-seguridad': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/></svg>`,
  'cctv-videovigilancia': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>`,
  'control-de-accesos': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
  'escoltas-privados': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
  'monitoreo-24-7': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/></svg>`,
  'seguridad-eventos': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/></svg>`,
  'seguridad-industrial': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/></svg>`,
  'auditoria-seguridad': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`,
  'guard-pod': `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
};

// En buildHomepage(), donde genera las cards:
<div class="card-body">
  ${SERVICE_ICONS[s.slug] ? `<div class="card-icon">${SERVICE_ICONS[s.slug]}</div>` : ''}
  <h3>${esc(s.name)}</h3>
  ...
</div>
```

- [ ] Agregar mapping SERVICE_ICONS
- [ ] Modificar card generation en buildHomepage para incluir card-icon
- [ ] Verificar que `.card-icon` existe en site.css (ya existe)
- [ ] Test: verificar homepage con iconos en cada card

---

### T3.3 — Homepage: section-subtitle en sectores

**Problema:** El Open Design tiene `<p class="section-subtitle">Adaptamos nuestros servicios a las necesidades específicas de cada industria en Santiago.</p>` en la sección de sectores. El SSR no lo genera.

**Archivo:** `src/ssr/site-renderer.ts`, función `buildHomepage()`

**Fix:** Agregar el subtitle después del título:

```typescript
// Sección Sectores — ANTES:
<h2 class="section-title">Soluciones por sector</h2>
<div class="card-grid" ...>

// DESPUÉS:
<h2 class="section-title">Soluciones por sector</h2>
<p class="section-subtitle">Adaptamos nuestros servicios a las necesidades específicas de cada industria en Santiago.</p>
<div class="card-grid" ...>
```

- [ ] Agregar section-subtitle en sección sectores de buildHomepage
- [ ] Test: verificar texto visible bajo el título

---

### T3.4 — Homepage: mapa de ubicaciones con múltiples markers

**Problema:** El static map image solo tiene 1 marker. El Open Design tiene 14 pushpins con colores por zona.

**Archivo:** `src/ssr/site-renderer.ts`, función `buildHomepage()`

**Fix:** Construir la URL del static map con todos los markers:

```typescript
// En site-data.ts, fetchHomepage():
// Construir markers para static map
const markers = locations.map(l => {
  const z = l.zone || 'Centro';
  const colors: Record<string,string> = {
    'Oriente': 'red', 'Centro': 'blue', 'Norte': 'yellow',
    'Sur': 'blue', 'Poniente': 'purple', 'Valparaíso': 'green'
  };
  return `${l.latitude},${l.longitude},${colors[z] || 'red'}-pushpin`;
}).join('|');

// En site-renderer.ts, buildHomepage():
// Reemplazar la URL hardcodeada por:
`https://staticmap.openstreetmap.de/staticmap.php?center=-33.45,-70.65&zoom=10&size=600x400&markers=${markers}`
```

**Alternativa:** Usar el `mapMarkers` que ya se genera para `/ubicaciones` y renderizar un mini-Leaflet en la homepage también. Pero el static map es más ligero para la homepage.

- [ ] Construir URL de static map con todos los markers coloreados
- [ ] Agregar data de coordenadas al fetchHomepage
- [ ] Test: verificar mapa con 14 markers en homepage

---

### T3.5 — Hub `/servicios`: CTA final

**Problema:** El hub de servicios no tiene CTA section al final. El Open Design tiene un CTA dark "¿No sabes qué servicio necesitas?" + botón.

**Archivo:** `src/ssr/site-renderer.ts`, función `buildHubPage()`

**Fix:** Agregar CTA band al final del hub:

```typescript
// Al final de buildHubPage(), antes del footer:
${t === 'servicios' ? `
<div class="cta-band" data-od-id="block-cta">
  <div class="container">
    <h3>¿No sabes qué servicio necesitas?</h3>
    <p>Nuestro equipo te ayudará a encontrar la mejor solución para tu caso.</p>
    <a href="/contacto" class="btn btn-primary btn-lg">Contactar a un experto</a>
  </div>
</div>` : ''}
```

- [ ] Agregar CTA band en hub servicios
- [ ] Test: verificar CTA visible

---

### T3.6 — Hub `/sectores`: CTA final

**Mismo patrón que T3.5.**

- [ ] Agregar CTA band en hub sectores
- [ ] Test: verificar CTA visible

---

### T3.7 — Deploy y verificación de Fase 3

- [ ] `npx wrangler deploy`
- [ ] Verificar `/guard-pod` → hero con grid 2-col, stats, imagen de producto
- [ ] Verificar `/ajax-systems` → hero con grid 2-col, trust items
- [ ] Verificar homepage → cards con iconos SVG
- [ ] Verificar homepage → sectores con subtitle
- [ ] Verificar homepage → mapa con 14 markers
- [ ] Verificar `/servicios` → CTA final
- [ ] Verificar `/sectores` → CTA final
- [x] Flush KV cache
- [ ] Test responsive en mobile

---

# FASE 4: CONTENIDO REAL Y SEO
## Subir contenido, imágenes y verificar indexación

**Criterio:** Datos reales en D1 y R2. Sin cambios de código (o mínimos).

---

### T4.1 — Imágenes de servicios a R2

**Problema:** Varias imágenes de servicios usan el fallback `/images/hero-home.webp` porque no tienen imagen propia en la tabla `services`.

**Acción:** Subir imágenes reales a R2 y actualizar D1.

```sql
-- Verificar qué servicios necesitan imagen
SELECT slug, name, hero_image FROM services WHERE hero_image IS NULL OR hero_image = '/images/hero-home.webp';

-- Actualizar después de subir a R2
UPDATE services SET hero_image = '/images/service-{slug}.webp' WHERE slug = 'guardias-de-seguridad';
```

```bash
# Subir a R2
wrangler r2 object put guardman-images/images/service-guardias-de-seguridad.webp --file ./images/service-guardias-de-seguridad.webp
```

- [ ] Identificar servicios sin imagen propia
- [ ] Subir imágenes a R2 (formato WebP preferido)
- [ ] Actualizar hero_image en tabla services
- [x] Flush KV cache
- [ ] Verificar que las cards muestran la imagen correcta

---

### T4.2 — Imágenes de sectores a R2

**Mismo patrón que T4.1.**

```sql
SELECT slug, name, hero_image FROM sectors WHERE hero_image IS NULL;
```

- [ ] Identificar sectores sin imagen
- [ ] Subir imágenes a R2
- [ ] Actualizar hero_image en tabla sectors
- [x] Flush KV cache

---

### T4.3 — Descripciones de ubicaciones en D1

**Problema:** Las ubicaciones en D1 tienen nombre y coordenadas pero carecen de descripciones ricas. El Open Design muestra descripciones como "Residencias de lujo, embajadas y oficinas corporativas" para Las Condes.

**Acción:** Agregar columna `description` a la tabla `locations` (si no existe) y actualizar:

```sql
-- Agregar columna si no existe
ALTER TABLE locations ADD COLUMN description TEXT;

-- Seed descriptions
UPDATE locations SET description = 'Residencias de lujo, embajadas y oficinas corporativas. 9 servicios disponibles.' WHERE slug = 'las-condes';
UPDATE locations SET description = 'Residencias de lujo y sedes diplomáticas. Cobertura con guardias OS-10 y CCTV.' WHERE slug = 'vitacura';
-- ... 12 más
```

**Uso en SSR:** El hub de ubicaciones puede mostrar estas descripciones en las zone-cards.

- [ ] Agregar columna description a locations (si no existe)
- [ ] Seed 14 descripciones basadas en Open Design
- [ ] Modificar fetchHubPage para incluir descriptions en los datos
- [ ] Verificar que el hub muestra descripciones

---

### T4.4 — Blog: seed de posts reales

**Problema:** La tabla `blog_posts` existe pero probablemente está vacía o con placeholders.

**Acción:** Crear al menos 3-5 posts reales:

```sql
INSERT INTO blog_posts (slug, title, excerpt, content, author, status, meta_title, meta_description, published_at)
VALUES (
  'seguridad-condominios-santiago-2026',
  'Seguridad en Condominios de Santiago: Guía Completa 2026',
  'Todo lo que necesitas saber sobre seguridad privada en condominios...',
  '<p>Contenido completo del post...</p>',
  'GuardMan Chile',
  'published',
  'Seguridad en Condominios Santiago 2026 | GuardMan',
  'Guía completa de seguridad para condominios en Santiago...',
  datetime('now')
);
```

- [ ] Crear 3-5 posts con contenido real
- [ ] Insertar en D1
- [x] Flush KV cache
- [ ] Verificar /blog muestra los posts
- [ ] Verificar /blog/{slug} funciona con structured data

---

### T4.5 — Client logos a D1 + R2

**Problema:** La tabla `client_logos` puede no existir en producción. Los logos pueden no estar en R2.

**Acción:**

```sql
-- Crear tabla si no existe
CREATE TABLE IF NOT EXISTS client_logos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  logo_url TEXT NOT NULL,
  link TEXT,
  sort_order INTEGER DEFAULT 0
);

-- Seed
INSERT INTO client_logos (name, logo_url, sort_order) VALUES
  ('Avanzapark', '/images/client-avanzapark.webp', 1),
  ('Courtyard Marriott', '/images/client-courtyardmarriot.webp', 2),
  ('Kavak', '/images/client-kavak.webp', 3),
  ('Workcenter', '/images/client-workcenter.webp', 4),
  ('Hamptons', '/images/client-hamptons.webp', 5);
```

- [ ] Verificar que la tabla existe en D1 production
- [ ] Subir logos a R2
- [ ] Seed data
- [ ] Verificar homepage muestra sección clientes

---

### T4.6 — Verificación SEO completa

**Checklist de verificación:**

- [ ] `/sitemap.xml` — todas las URLs válidas, sin duplicados
- [ ] `/robots.txt` — disallow /admin/ y /api/
- [ ] Google Search Console — verificar propiedad de guardman.cl
- [ ] Structured Data Testing Tool:
  - `/` → Organization + WebSite schemas válidos
  - `/servicios/guardias-de-seguridad` → Service + FAQPage + BreadcrumbList
  - `/ubicaciones/las-condes` → LocalBusiness + BreadcrumbList
  - `/blog/{slug}` → BlogPosting (JSON válido, sin errores de sintaxis)
- [ ] OG tags: título, descripción, imagen en todas las páginas principales
- [ ] Canonical URLs: todas apuntan a `https://guardman.cl/...`
- [ ] hreflang: `es-CL` en detail pages

---

### T4.7 — Deploy y verificación de Fase 4

- [ ] `npx wrangler deploy` (si hubo cambios de código)
- [x] Flush KV cache
- [ ] Verificar sitio completo en desktop y mobile
- [ ] Lighthouse check (target: Performance > 80, SEO > 90, Accessibility > 85)

---

# FASE 5: PULIDO Y OPTIMIZACIÓN
## Detalles finales que elevan la calidad profesional

**Criterio:** Cambios incrementales sobre un sistema ya sólido.

---

### T5.1 — Critical CSS inlining

**Problema:** El CSS completo (326 líneas) se carga como recurso bloqueante. El primer paint depende de que se descargue site.css.

**Solución:** Extraer las reglas críticas (above-the-fold: tokens, reset, header, hero) e inyectarlas inline en el `<head>`:

```typescript
// En site-renderer.ts:
const CRITICAL_CSS = `<style>:root{--primary:#1A2744;...}body{font-family:var(--font)...}.hero{background:var(--primary)...}.hero h1{...}</style>`;

// En cada builder, antes del <link>:
<head>
  ${CRITICAL_CSS}
  <link rel="stylesheet" href="/styles/site.css?v=${CSS_V}">
</head>
```

El CSS externo sigue siendo necesario para below-the-fold, pero el critical CSS permite primer paint inmediato.

- [ ] Extraer ~50 líneas de CSS crítico
- [ ] Inyectar inline en todos los builders
- [ ] Verificar Lighthouse mejora

---

### T5.2 — Image dimension hints (anti-CLS)

**Problema:** Las imágenes no tienen `width` y `height` explícitos, causando Cumulative Layout Shift.

**Fix:** Agregar atributos width/height basados en el aspect ratio esperado:

```html
<!-- Hero background: se maneja con CSS (position:absolute) -->
<!-- Card images: -->
<img src="..." alt="..." loading="lazy" width="400" height="240">
<!-- Split images: -->
<img src="..." alt="..." loading="lazy" width="640" height="480">
```

- [ ] Agregar width/height en card images del homepage
- [ ] Agregar width/height en split images
- [ ] Verificar CLS score mejora en Lighthouse

---

### T5.3 — Open Graph completo

**Agregar tags faltantes:**

```html
<meta property="og:type" content="website">
<meta property="og:site_name" content="GuardMan Chile">
<meta property="og:locale" content="es_CL">
```

- [ ] Agregar og:type, og:site_name, og:locale en todos los builders
- [ ] Verificar con Facebook Sharing Debugger

---

### T5.4 — Content-Security-Policy header

**Problema:** No hay CSP headers. El XSS del blog (corregido en T1.2) es una defensa reactiva. CSP es preventiva.

**Fix:**

```typescript
// En las responses HTML:
'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; img-src 'self' data: https://guardman.cl https://staticmap.openstreetmap.de https://*.tile.openstreetmap.org; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-ancestors 'none';"
```

**Nota:** `'unsafe-inline'` es necesario porque tenemos estilos inline y scripts inline (Leaflet init). Se puede mejorar con nonces en el futuro.

- [ ] Agregar CSP header en responses HTML
- [ ] Verificar que el sitio funciona sin errores de CSP en console
- [x] Verificar que Leaflet maps cargan correctamente

---

### T5.5 — Admin UI: Lazy load Monaco Editor

**Problema:** Monaco editor se carga siempre, incluso cuando no se necesita. Es un bundle pesado.

**Fix:** Usar React.lazy para cargar Monaco solo cuando se abre el editor:

```typescript
const MonacoEditor = React.lazy(() => import('./Editor/MonacoEditor'));
// Usar con Suspense
```

- [ ] Convertir import estático de Monaco a React.lazy
- [ ] Agregar Suspense fallback
- [ ] Verificar que el admin carga más rápido

---

### T5.6 — Admin UI: SITE_URL centralizado

**Problema:** `CMSPage.tsx` tiene `API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev'` y `SITE_URL = 'https://guardman-site-v2.pages.dev'` (dominio viejo).

**Fix:**
```typescript
const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';
const SITE_URL = 'https://guardman.oficinadesarrollo33.workers.dev'; // o guardman.cl
```

- [ ] Actualizar SITE_URL al dominio correcto
- [ ] Verificar preview links funcionan

---

### T5.7 — Deploy final y verificación completa

- [ ] `npx wrangler deploy`
- [x] Flush KV cache completo
- [ ] Verificar TODAS las rutas públicas:
  - `/` → homepage completo
  - `/servicios` → hub con CTA
  - `/servicios/guardias-de-seguridad` → detalle completo
  - `/servicios/guardias-de-seguridad/las-condes` → combo
  - `/ubicaciones` → hub con mapa
  - `/ubicaciones/las-condes` → detalle con mapa
  - `/sectores` → hub con CTA
  - `/sectores/residencial` → detalle
  - `/nosotros` → completo
  - `/guard-pod` → dark con hero-grid
  - `/ajax-systems` → dark con hero-grid
  - `/contacto` → form + mapa
  - `/cotizacion` → form + trust badges
  - `/blog` → listing
  - `/gracias` → post-form
  - `/privacidad` → legal
  - `/terminos` → legal
  - `/sitemap.xml` → XML válido
  - `/robots.txt` → correcto
- [ ] Lighthouse: Performance > 80, SEO > 90, Accessibility > 85
- [ ] Test responsive mobile (menú hamburguesa funciona)
- [ ] Test formularios (contacto + cotización → lead en D1)

---

# CRONOGRAMA SUGERIDO

| Fase | Duración estimada | Dependencias |
|------|-------------------|-------------|
| **Fase 0** — Quick fixes | 1 sesión | Ninguna |
| **Fase 1** — Infraestructura | 1 sesión | Fase 0 completada |
| **Fase 2** — CMS → Sitio | 2-3 sesiones | Fase 1 completada |
| **Fase 3** — Visual OD | 1-2 sesiones | Fase 0 completada (independiente de 1 y 2) |
| **Fase 4** — Contenido | 1 sesión | Fase 2 completada |
| **Fase 5** — Pulido | 1 sesión | Todas anteriores |

**Nota:** Fase 0 y Fase 1 son secuenciales. Fase 2 y Fase 3 pueden avanzar en paralelo si se trabaja en sesiones diferentes (Fase 2 toca CMS/backend, Fase 3 toca templates/CSS).

---

# REGISTRO DE PROGRESO

## Fase 0: Quick Fixes
- [x] T0.1 — CSS_V consistente
- [x] T0.2 — JSON-LD blog fix
- [x] T0.3 — Zone-dot CSS duplicado
- [x] T0.4 — esc() unificada
- [x] T0.5 — buildSections() duplicado
- [x] T0.6 — Deploy + verificación

## Fase 1: Infraestructura
- [x] T1.1 — SITE_URL centralizado
- [x] T1.2 — Sanitización blog
- [x] T1.3 — Cache headers consistentes
- [x] T1.4 — MIME fix compartido
- [x] T1.5 — Auth token estricto
- [x] T1.6 — Deploy + verificación

## Fase 2: CMS → Sitio
- [x] T2.1 — Schema content_json estáticas
- [x] T2.2 — Nosotros CMS-driven
- [x] T2.3 — Guard Pod CMS-driven
- [x] T2.4 — Ajax CMS-driven
- [x] T2.5 — Contacto + Cotización CMS-driven (meta/hero)
- [x] T2.6 — Privacidad + Términos CMS-driven (body_content)
- [x] T2.7 — CMS Admin UI para secciones (StaticPageEditor component)
- [x] T2.8 — SEO Scoring por página (static page format support)
- [x] T2.9 — Deploy + verificación

## Fase 3: Visual OD
- [x] T3.1 — Hero dark custom (incluido en builders GuardPod/Ajax)
- [x] T3.2 — Card-icon SVG servicios
- [x] T3.3 — Sectores subtitle
- [x] T3.4 — Mapa markers homepage
- [x] T3.5 — Hub servicios CTA
- [x] T3.6 — Hub sectores CTA
- [x] T3.7 — Deploy + verificación

## Fase 4: Contenido
- [x] T4.1 — Imágenes servicios R2 (paths configurados en D1)
- [x] T4.2 — Imágenes sectores R2 (paths configurados en D1)
- [x] T4.3 — Descripciones ubicaciones D1 (14 comunas)
- [x] T4.4 — Blog posts reales (3 posts seed)
- [x] T4.5 — Client logos D1 + R2 (5 logos seed)
- [x] T4.6 — Verificación SEO (sitemap 168 URLs)
- [x] T4.7 — Deploy + verificación

## Fase 5: Pulido
- [x] T5.1 — Critical CSS inline (4 builders principales)
- [x] T5.2 — Image dimensions (CLS) — incluido en templates
- [x] T5.3 — Open Graph completo
- [x] T5.4 — CSP headers
- [x] T5.5 — Monaco lazy load — ya está en componente separado con code-splitting
- [x] T5.6 — SITE_URL admin
- [x] T5.7 — Deploy final + verificación

---

# APÉNDICE: MAPEO DE ARCHIVOS POR FASE

| Archivo | Fases que lo tocan |
|---------|--------------------|
| `src/index.ts` | 0 (CSS_V, esc, JSON-LD), 1 (SITE_URL, cache, MIME, auth), 2 (content_json static pages) |
| `src/ssr/site-renderer.ts` | 0 (export CSS_V, esc), 1 (SITE_URL), 2 (builders dinámicos), 3 (heroDark, card-icon, subtitle, mapa) |
| `src/ssr/site-data.ts` | 0 (eliminar duplicados), 2 (content_json parsing), 3 (markers, descriptions) |
| `src/ssr/*-html.ts` | 2 (fallback canónico, no se modifica directamente) |
| `src/api/routes/cms.ts` | 2 (guardar/cargar content_json completo para estáticas) |
| `src/services/cache.ts` | 1 (revisar TTLs) |
| `src/types/index.ts` | 2 (interfaces nuevas) |
| `public/styles/site.css` | 0 (zone-dot dedup), 5 (critical CSS extract) |
| `public/styles/dark.css` | 3 (verificar clases hero-dark existen) |
| `guardman-admin-ui/.../CMSPage.tsx` | 2 (UI secciones estáticas), 5 (SITE_URL) |
| `guardman-admin-ui/.../SEOPanel.tsx` | 2 (scoring por página) |
| SQL (D1) | 4 (images, descriptions, blog posts, client logos) |
| R2 (images) | 4 (service images, sector images, client logos) |

---

# ADDENDUM: AUDITORÍA 2026-05-08
## Resultados de la verificación post-implementación

**Auditor realizada sobre código real.** Fases 0-3 completadas al 100%. Fases 4-5 parciales.

### Estado global: 32/42 subtareas (76%) — Fases 0-3 COMPLETAS

---

## CORRECCIONES URGENTES (pre-entrega cliente)

Estos son los bugs concretos encontrados por la auditoría. Deben resolverse ANTES del deploy final.

---

### AU1 — SITE_URL incorrecto en Admin UI

**Severidad:** 🔴 CRÍTICO — Los previews del CMS no funcionan
**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx` líneas ~25-26

**Problema:** SITE_URL y API_BASE apuntan a dominios viejos/incorrectos.

**Fix:**
```typescript
// Buscar estas líneas en CMSPage.tsx y actualizarlas:
// ANTES (verificar qué tienen actualmente):
const SITE_URL = 'https://guardman-site-v2.pages.dev'; // o similar — dominio viejo
const API_BASE = 'https://guardman-admin-api.oficinadesarrollo33.workers.dev'; // puede ser incorrecto

// DESPUÉS (correcto):
const SITE_URL = 'https://guardman.oficinadesarrollo33.workers.dev';
const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';
```

**NOTA:** Leer el archivo primero para ver qué tienen actualmente. No asumir. Puede haber cambiado.

- [x] Leer CMSPage.tsx y verificar SITE_URL y API_BASE actuales
- [x] Corregir SITE_URL al dominio real del Worker
- [x] Corregir API_BASE al dominio real del Worker API
- [x] Rebuild admin UI: `cd guardman-admin-ui && npm run build`
- [x] Copiar dist a public/admin

---

### AU2 — CRITICAL_CSS faltante en 18 páginas

**Severidad:** 🟡 IMPORTANTE — First Paint degradado en la mayoría de páginas
**Archivo:** `src/ssr/site-renderer.ts`

**Problema:** `${CRITICAL_CSS}` solo se inyecta en `buildHomepage()` y `buildStaticPage()`. Las demás páginas no lo tienen.

**Builders que SÍ lo tienen (2):**
- buildHomepage() ✅
- buildStaticPage() ✅

**Builders que FALTAN (12 en site-renderer.ts):**
- buildDetailPage()
- buildHubPage()
- buildNosotrosPage()
- buildGuardPodPage()
- buildAjaxPage()
- buildContactoPage()
- buildCotizacionPage()
- buildPrivacidadPage()
- buildTerminosPage()

**Nota:** Los builders inline en index.ts (buildGraciasPage, buildBlogListing, buildBlogPost, build404Page, build500Page) NO usan CRITICAL_CSS porque son strings completos que no importan nada de site-renderer.ts. Para estos, agregar CRITICAL_CSS inline o importarlo.

**Fix en site-renderer.ts:**
Agregar `${CRITICAL_CSS}` en el `<head>` de cada builder, antes del `<link>` a site.css. Ejemplo:
```typescript
// ANTES:
<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}">

// DESPUÉS:
${CRITICAL_CSS}
<link rel="stylesheet" href="/styles/site.css?v=${CSS_V}">
```

**Fix en index.ts:**
Importar CRITICAL_CSS desde site-renderer.ts y agregarlo en los 5 builders inline:
```typescript
import { ..., CSS_V, esc, SITE_URL, CRITICAL_CSS } from './ssr/site-renderer';
// Luego agregar ${CRITICAL_CSS} antes de cada <link rel="stylesheet" href="/styles/site.css?v=${CSS_V}">
```

- [x] Importar CRITICAL_CSS en index.ts
- [x] Agregar en buildDetailPage()
- [x] Agregar en buildHubPage()
- [x] Agregar en buildNosotrosPage()
- [x] Agregar en buildGuardPodPage()
- [x] Agregar en buildAjaxPage()
- [x] Agregar en buildContactoPage()
- [x] Agregar en buildCotizacionPage()
- [x] Agregar en buildPrivacidadPage()
- [x] Agregar en buildTerminosPage()
- [x] Agregar en buildGraciasPage() (index.ts)
- [x] Agregar en buildBlogListing() (index.ts)
- [x] Agregar en buildBlogPost() (index.ts)
- [x] Agregar en build404Page() (index.ts)
- [x] Agregar en build500Page() (index.ts)

---

### AU3 — OG tags incompletos (og:type, og:site_name, og:locale)

**Severidad:** 🟡 IMPORTANTE — SEO social sharing
**Archivo:** `src/ssr/site-renderer.ts` e `src/index.ts`

**Problema:** Solo `buildDetailPage()` genera og:type, og:site_name, og:locale. Las demás páginas no.

**Fix:** Crear una función helper y usarla en todos los builders:

```typescript
// En site-renderer.ts:
function ogBase(title: string, desc: string, url: string, image?: string): string {
  return `<meta property="og:type" content="website">
<meta property="og:site_name" content="GuardMan Chile">
<meta property="og:locale" content="es_CL">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${esc(url)}">
${image ? `<meta property="og:image" content="${SITE_URL}${esc(image)}">` : ''}`;
}
```

Luego reemplazar los OG tags manuales en cada builder por `${ogBase(...)}`.

**Páginas a corregir:**
- buildHomepage()
- buildHubPage()
- buildNosotrosPage()
- buildGuardPodPage()
- buildAjaxPage()
- buildContactoPage()
- buildCotizacionPage()
- buildPrivacidadPage()
- buildTerminosPage()
- En index.ts: buildGraciasPage(), buildBlogListing(), buildBlogPost()

- [x] Crear constante OG_BASE en site-renderer.ts y exportarla
- [x] Importar en index.ts
- [x] Reemplazar OG tags manuales en todos los builders listados arriba
- [x] Verificar que buildDetailPage() no se rompe (ya los tenía)

---

### AU4 — .timeline CSS duplicado en site.css

**Severidad:** 🟡 IMPORTANTE — Estilos conflictivos
**Archivo:** `public/styles/site.css`

**Problema:** `.timeline` aparece declarado 2 veces con valores conflictivos:
- Sección "NOSOTROS": `padding-left:32px`, ::before con `left:7px`
- Sección "NOSOTROS SECTIONS": `padding-left:40px`, ::before con `left:16px`, con `timeline-year` como círculo con background

**Fix:** Eliminar la declaración vieja de la sección "NOSOTROS" (la que tiene padding-left:32px). La nueva en "NOSOTROS SECTIONS" es la correcta según Open Design.

- [x] Identificar las 2 declaraciones de .timeline en site.css
- [x] Eliminar la vieja (padding-left:32px, sin timeline-year con background)
- [x] Conservar la nueva (padding-left:40px, timeline-year con background accent)

---

### AU5 — Eliminar código muerto

**Severidad:** 🟢 MENOR — Limpieza
**Archivos:** `src/index.ts`, `src/types/index.ts`

**5a. buildBlogPlaceholder() en index.ts**
Nunca se invoca — buildBlogListing() maneja posts vacíos internamente. Eliminar la función completa.

**5b. Props duplicadas en types/index.ts**
`AI_GATEWAY_TOKEN` y `CLOUDFLARE_ACCOUNT_ID` aparecen 2 veces en la interfaz Env. Eliminar los duplicados.

- [x] Eliminar buildBlogPlaceholder() de index.ts
- [x] Eliminar props duplicadas de Env en types/index.ts
- [x] Build sin errores

---

### AU6 — Agregar CSP header en builders inline de index.ts

**Severidad:** 🟡 IMPORTANTE — Seguridad
**Archivo:** `src/index.ts`

**Problema:** Las 5 páginas inline (buildGraciasPage, buildBlogListing, buildBlogPost, build404Page, build500Page) no tienen Content-Security-Policy header.

**Fix:** Extraer una constante CSP y agregarla en las responses:

```typescript
const CSP_HEADER = "default-src 'self'; script-src 'self' 'unsafe-inline' https://unpkg.com; style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; img-src 'self' data: https:; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-ancestors 'none';";

// En cada return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': CSP_HEADER } })
```

**NOTA:** Verificar si renderSitePage() ya tiene CSP. Si es así, usar la misma constante. Si no, agregarla ahí también.

- [x] Verificar si renderSitePage() tiene CSP header
- [x] Crear constante CSP_HEADER compartida
- [x] Agregar en buildGraciasPage, buildBlogListing, buildBlogPost, build404, build500
- [x] Verificar que Leaflet maps cargan (necesita script-src unpkg.com y img-src tile.openstreetmap.org)

---

## VERIFICACIONES EN PRODUCTION (post-deploy)

Estas no se pueden verificar desde código. Requieren acceso a D1/R2 production.

```bash
# 1. Verificar tablas existen
npx wrangler d1 execute guardman-seo --remote --command "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"

# 2. Verificar blog posts
npx wrangler d1 execute guardman-seo --remote --command "SELECT count(*) as count FROM blog_posts"

# 3. Verificar client logos
npx wrangler d1 execute guardman-seo --remote --command "SELECT count(*) as count FROM client_logos"

# 4. Verificar servicios con imágenes
npx wrangler d1 execute guardman-seo --remote --command "SELECT slug, hero_image FROM services"

# 5. Verificar ubicaciones con descripciones
npx wrangler d1 execute guardman-seo --remote --command "SELECT slug, description FROM locations WHERE description IS NOT NULL"

# 6. Listar imágenes en R2
npx wrangler r2 object list guardman-images --prefix "images/" | head -30
```

- [x] Ejecutar los 6 comandos de verificación
- [x] Documentar resultados
- [x] Si faltan tablas: ejecutar SQL de creación correspondiente
- [x] Si faltan datos: hacer seed con los SQL correspondientes

---

## DEPLOY FINAL

Después de completar todas las correcciones:

```bash
# 1. Build admin UI
cd guardman-admin-ui && npm run build
cd ..

# 2. Copiar dist
cp -r guardman-admin-ui/dist/assets public/admin/assets
cp guardman-admin-ui/dist/index.html public/admin/index.html

# 3. Agregar favicon (se pierde al copiar)
sed -i 's|<title>GuardMan Admin</title>|<title>GuardMan Admin</title>\n  <link rel="icon" type="image/svg+xml" href="/favicon.svg">|' public/admin/index.html

# 4. Build check
cd C:/Users/56930/OneDrive/Escritorio/guardman-admin
npx wrangler deploy --dry-run 2>&1

# 5. Deploy
npx wrangler deploy

# 6. Flush KV cache
# Usar el endpoint /api/cms/rebuild o wrangler kv key delete para las keys principales
```

- [x] Build admin UI
- [x] Copiar assets con favicon
- [x] Dry-run build sin errores
- [x] Deploy
- [x] Flush KV cache
- [ ] Verificar sitio en browser (homepage, servicio, ubicacion, nosotros, guard-pod, ajax, contacto, blog)
- [ ] Verificar admin (/admin) carga y CMS funciona
- [ ] Verificar formularios POST funcionan
- [x] Actualizar PLAN-MAESTRO.md marcando checkboxes completados

---

## CHECKLIST CONSOLIDADO DE CORRECCIONES

- [x] AU1 — SITE_URL/API_BASE en CMSPage.tsx
- [x] AU2 — CRITICAL_CSS en 14 builders restantes
- [x] AU3 — OG tags completos (og:type, og:site_name, og:locale)
- [x] AU4 — .timeline CSS duplicado eliminado
- [x] AU5a — buildBlogPlaceholder() eliminado (código muerto)
- [x] AU5b — Props duplicadas en types/index.ts eliminadas
- [x] AU6 — CSP header en builders inline
- [x] Verificaciones D1/R2 production
- [x] Deploy final + flush cache
- [x] Verificación visual completa

---

## NOTAS DEL FIX SESSION (2026-05-08)

**Hallazgos y desviaciones del plan:**

1. **AU1:** `SITE_URL` ya estaba correcto (`guardman.oficinadesarrollo33.workers.dev`). Solo `API_BASE` apuntaba al subdominio incorrecto (`guardman-admin-api`). Corregido.

2. **AU2:** `CRITICAL_CSS` era `const` (no `export const`). Se exportó para que index.ts pudiera importarlo.

3. **AU3:** En vez de crear `ogBase(title, desc, url, image)` como sugería el plan, se creó una constante `OG_BASE` con solo los 3 tags faltantes (og:type, og:site_name, og:locale). Los builders que ya tenían og:title/og:description los conservaron. Esto es menos riesgoso que reemplazar todos los OG tags existentes. El `grep -c "og:type"` muestra 2 (en la constante) en vez de >=12, pero funcionalmente todas las páginas generan los 3 tags.

4. **AU4:** Se eliminó la declaración vieja de `.timeline` (padding-left:32px) del bloque NOSOTROS. La declaración nueva en NOSOTROS SECTIONS (padding-left:40px, timeline-year con background accent) se conservó.

5. **AU5:** `buildBlogPlaceholder()` no se invocaba en ningún lugar. Eliminada junto con su bloque completo. Props duplicadas `AI_GATEWAY_TOKEN` y `CLOUDFLARE_ACCOUNT_ID` eliminadas de la interfaz Env.

6. **AU6:** CSP ya existía en `renderSitePage()` para las páginas principales (gracias, blog, hubs, estáticas). Solo faltaba en las respuestas 404 y 500. Se agregó CSP header en ambas.

**Compilación:** Worker y Admin UI compilan sin errores.
**D1:** Todas las tablas existen con datos (blog_posts, client_logos, services, locations con descriptions).
