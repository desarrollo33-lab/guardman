# GuardMan Admin — Plan de Trabajo Integral
## Fecha: 2026-05-07 | Estado: Análisis completo del código fuente

---

# PARTE 1: INVENTARIO DEL PROYECTO

## 1.1 Arquitectura General

```
guardman-admin/
├── src/                          # Backend (Cloudflare Worker)
│   ├── index.ts                  # Router principal (509 líneas) — SSR + API + Forms + Sitemap
│   ├── api/                      # API modular
│   │   ├── index.ts              # Router API con auth middleware
│   │   ├── middleware/auth.ts    # Auth (token estático)
│   │   └── routes/               # 15+ módulos de rutas
│   │       ├── cms.ts            # CMS CRUD + regenerate + save (613 líneas)
│   │       ├── intel/            # Inteligencia competitiva + CRM
│   │       └── ...
│   ├── services/                 # Lógica de negocio
│   │   ├── ai.ts                 # Generación AI con DeepSeek (391 líneas)
│   │   ├── content-generation.ts # Pipeline de calidad 7 capas
│   │   ├── scoring.ts            # Scoring algorítmico (236 líneas)
│   │   └── ...
│   ├── ssr/                      # Server-Side Rendering
│   │   ├── site-renderer.ts      # Templates HTML + builders (541 líneas)
│   │   ├── site-data.ts          # Fetchers D1 → SiteData (466 líneas)
│   │   ├── contacto-html.ts      # Formulario contacto (POST real)
│   │   ├── cotizacion-html.ts    # Formulario cotización (POST real)
│   │   ├── *-html.ts             # 7 páginas estáticas HTML
│   │   └── renderer.ts           # LEGACY — NO importado
│   └── types/index.ts            # Tipos compartidos
├── guardman-admin-ui/            # Frontend (React + Vite SPA)
│   └── src/components/
│       ├── CMS/
│       │   ├── CMSPage.tsx       # Editor CMS principal (1522 líneas)
│       │   └── SEOPanel.tsx      # Panel SEO lateral (257 líneas)
│       └── ...
├── public/                       # Assets estáticos servidos por Worker
│   ├── admin/                    # SPA compilado (se pierde favicon al rebuild)
│   ├── styles/                   # CSS del sitio público
│   ├── images/                   # → proxy a R2
│   └── favicon.ico, favicon.svg
├── sql/                          # Schema D1 + seeds
├── scripts/                      # Build scripts Python/JS
└── docs/                         # Documentación de sesiones
```

**Stack:** Cloudflare Workers + D1 + R2 + KV + AI Gateway + DeepSeek API + React SPA
**Deploy:** `wrangler deploy` directo. Sin CI/CD. Sin GitHub.
**Líneas de código totales:** ~34,600 líneas TS/TSX

## 1.2 Entidades del Sistema

| Entidad | Tabla D1 | Páginas SSR | CMS Editor |
|---------|----------|-------------|------------|
| Services (9) | `services` | `/servicios/{slug}` | ✅ Genérico |
| Locations (14) | `locations` | `/ubicaciones/{slug}` | ✅ Genérico |
| Sectors (9) | `sectors` | `/sectores/{slug}` | ✅ Genérico |
| Combos (126) | `combo_content` | `/servicios/{svc}/{loc}` | ✅ Genérico |
| Homepage | `static_page_content` | `/` | ✅ Editor propio |
| Static pages (7) | `static_page_content` | `/nosotros`, etc. | ⚠️ Solo meta/hero |
| Hub pages | derivadas | `/servicios`, `/ubicaciones`, `/sectores` | ❌ Sin editor |
| Blog | — | `/blog` (placeholder) | ❌ No existe |
| Leads | `intel_leads` | Forms POST → `/gracias` | CRM separado |

---

# PARTE 2: BUGS IDENTIFICADOS

## 🔴 CRÍTICOS (impacto en producción)

### BUG-01: Duplicación de manejo de sitemap
**Archivo:** `src/index.ts` líneas ~70 y ~100
**Problema:** El bloque `// ===== 4b. Sitemap =====` aparece DOS veces en el router. El segundo (línea ~100) nunca se ejecuta porque el primero (línea ~70) captura `/sitemap.xml` antes. Esto es código muerto pero confuso.
```typescript
// Primera aparición (funcional)
if (path === '/sitemap.xml') {
  return handleSitemap(env);
}
// ... más rutas ...
// Segunda aparición (nunca se ejecuta)
if (path === '/sitemap.xml') {
  return handleSitemap(env);
}
```
**Fix:** Eliminar el segundo bloque duplicado.

### BUG-02: Rutas de forms POST con orden incorrecto
**Archivo:** `src/index.ts`
**Problema:** Los forms POST (`/contacto`, `/cotizacion`) se manejan DESPUÉS del asset matching (`path.match(/\.(css|js|...)$/i)`). Si bien es improbable que colisionen, el orden lógico debería ser: forms antes que assets estáticos.
**Fix:** Mover bloque de forms POST antes del bloque de assets.

### BUG-03: `content_json` de static pages (no homepage) nunca se usa para SSR
**Archivo:** `src/ssr/site-renderer.ts` (buildNosotrosPage, buildAjaxPage, etc.)
**Problema:** Las páginas estáticas (nosotros, guard-pod, ajax-systems, contacto, cotización, privacidad, terminos) tienen `content_json` en D1 y el editor permite editar hero/meta, PERO el renderizado SSR solo lee las columnas planas (`hero_heading`, `hero_subheading`, `meta_title`, `meta_description`). El contenido del body (textos de secciones) jamás se refleja en el sitio público.
**Impacto:** Si un usuario edita contenido de Nosotros en el CMS, los cambios NO se ven en el sitio.
**Fix:** Cada builder de página estática debe leer `content_json` y overridear los textos del template HTML.

### BUG-04: Homepage se queda en "Cargando..." si `loadHomepage()` falla silenciosamente
**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`
**Problema:** Si la API devuelve un error inesperado (ej: JSON parse error, error de red), `setLoadingContent(false)` se ejecuta, pero `setHomeLoaded(true)` solo se ejecuta al final de `loadHomepage()`. Si la API response es `data.ok === false` pero sin error, `homeLoaded` se queda `false` y el UI muestra "Cargando homepage..." para siempre.
```typescript
if (data.ok && data.content) {
  // ... happy path
} else {
  setMessage({ type: 'error', text: data.error || 'Error cargando homepage' });
  setContent(null);
  // homeLoaded nunca se setea a true si hubo error!
}
```
**Fix:** Agregar `setHomeLoaded(true)` en el path de error también.

### BUG-05: Guardado de homepage no actualiza `content_json` en D1
**Archivo:** `src/api/routes/cms.ts` — save handler
**Problema:** Cuando `saveHomepage()` envía `path: 'static/homepage.json'`, el handler lo guarda en `content_versions` con `entity_type='page'`, NO en `static_page_content` donde el SSR lo lee. La ruta `static/` con `parts[0] === 'static'` se maneja después y solo se ejecuta si NO es homepage.
```typescript
if (path === 'homepage.json') {
  // Guarda en content_versions (entity_type='page')
  // PERO NO guarda en static_page_content
  // → SSR no ve los cambios!
}
```
**Impacto:** Guardar homepage desde el CMS no actualiza el sitio público. El override de `content_json` en `renderSitePage()` lee de `static_page_content`, no de `content_versions`.
**Fix:** El save de homepage debe escribir AMBAS tablas: `content_versions` Y `static_page_content`.

### BUG-06: API de imágenes usa dominio incorrecto
**Archivo:** `src/api/routes/cms.ts` — `/api/cms/image`
**Problema:** Proxy de imágenes apunta a `github.com/desarrollo33-lab/guardman-site/main/...`. Pero el proyecto ya NO usa GitHub (eliminado en sesión parte 1). Las imágenes están en R2. Este endpoint está roto.
**Fix:** Redirigir a R2 (`/images/...`) o eliminar el endpoint.

### BUG-07: Auth débil — token estático sin expiración
**Archivo:** `src/api/middleware/auth.ts`
**Problema:** El token de auth es `admin@guardman.cl:{timestamp}` que nunca expira. Cualquier token histórico funciona para siempre. No hay refresh, no hay logout real.
**Fix:** Implementar tokens con expiración (JWT o timestamp + TTL).

## 🟡 MEDIOS (funcionalidad degradada)

### BUG-08: Homepage `heroCtas` hardcodeados en template
**Archivo:** `src/ssr/site-renderer.ts` — `buildHomepage()`
**Problema:** El template de homepage renderiza CTAs hardcodeados:
```typescript
heroCtas: [{ text: 'Solicitar Cotización', href: '/cotizacion', variant: 'primary' }, ...]
```
Pero el CMS editor no tiene campos para editar estos CTAs. El hero del homepage siempre muestra los mismos botones sin importar lo que se guarde.
**Fix:** Agregar campos CTA al editor del homepage y overridearlos desde `content_json`.

### BUG-09: Guard Pod y Ajax features con formatos inconsistentes
**Archivo:** `src/ssr/site-renderer.ts` — `buildHomepage()`
**Problema:** Guard Pod features usan formato `{title, description}` (correcto), pero Ajax features usa `string[]`:
```typescript
// GuardPod — correcto
homeGuardPodFeatures: Array<{title:string;description:string}>
// Ajax — inconsistente
homeAjaxFeatures: string[]
```
Pero el CMS editor genera Ajax features como `[{title, description}]`. El override en `src/index.ts` mapea:
```typescript
homeAjaxFeatures = ax.features.map(f => typeof f === 'string' ? f : f.title || f.text || '')
```
Pierde las descriptions de Ajax.
**Fix:** Unificar `homeAjaxFeatures` a `Array<{title:string;description:string}>` como Guard Pod.

### BUG-10: `getEntityType()` devuelve `'home'` para regenerate pero `'static_page'` para load
**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`
**Problema:** `getEntityType()` devuelve `'home'` cuando `contentType === 'static' && slug === 'homepage'`, pero `loadHomepage()` hardcodea `type=static_page` en la URL. Y `regenerateContent()` usa `getEntityType()` que devuelve `'home'`. Esto funciona por coincidencia (el backend maneja ambos), pero es confuso.
**Fix:** Unificar el type para homepage.

### BUG-11: Scoring en backend no se usa en el UI
**Archivo:** `src/api/routes/cms.ts` — regenerate handler
**Problema:** El endpoint `/api/cms/regenerate` devuelve `qualityPipeline.score`, `violations`, `genericPhrases`, `review`, pero `CMSPage.tsx` ignora todo esto. Solo usa `data.improved`.
**Fix:** Mostrar al menos el score y warnings del pipeline en el UI.

### BUG-12: Mobile nav sin JavaScript
**Archivo:** `src/ssr/site-renderer.ts` — `hdr()`
**Problema:** El botón hamburger `☰` no tiene onclick ni hay JS para el menú móvil. En mobile, la navegación es inaccesible.
**Fix:** Agregar JS inline para toggle del menú móvil.

### BUG-13: Sector images inexistentes en R2
**Archivo:** `src/ssr/site-renderer.ts` — homepage sectores grid
**Problema:** Las imágenes de sectores usan `/images/sector-${slug}.webp` pero la mayoría no existen en R2. El `onerror` las oculta, resultando en cards sin imagen.
**Fix:** Crear imágenes placeholder por sector o usar un fallback genérico con el nombre del sector.

### BUG-14: `window.MAIN_SCRIPT` y `main.js` sin usar efectivamente
**Archivo:** `public/scripts/main.js`
**Problema:** Existe un `main.js` que probablemente se creó para interactividad, pero no se incluye en ningún template HTML. Los únicos elementos interactivos son los dropdowns del nav y el hamburger, que no funcionan sin JS.
**Fix:** Incluir `main.js` en los templates con la lógica de dropdowns y hamburger.

### BUG-15: `buildNosotrosPage()` reemplaza hero incorrectamente
**Archivo:** `src/ssr/site-renderer.ts`
**Problema:** Usa regex para eliminar el hero del HTML importado:
```typescript
NOSOTROS_HTML.replace(/<section class="hero"[\s\S]*?<\/section>/, '')
```
Esto es frágil — si el HTML cambia ligeramente, el regex falla. Además, construye un hero nuevo por fuera del HTML importado, duplicando potencialmente contenido.
**Fix:** Los archivos *-html.ts no deberían incluir su propio hero si el builder lo genera.

### BUG-16: Cotización form no usa todos los campos declarados
**Archivo:** `src/index.ts` — `handleQuoteForm()`
**Problema:** El handler INSERT incluye `empresa` y otros campos, pero el HTML de cotización podría no enviar todos los campos. Si el HTML no tiene `name="empresa"`, el campo queda null silenciosamente.
**Fix:** Verificar que todos los campos del form HTML coincidan con los del handler.

### BUG-17: Typos en meta descriptions hardcodeadas
**Archivo:** `src/ssr/site-renderer.ts` — `buildAjaxPage()`
**Problema:** La meta description hardcodeada dice "tecnologia Jeweller" sin acento, mientras la versión correcta con acento está en la variable `desc`.
**Fix:** Usar la variable `desc` en vez de hardcodear.

## 🟢 MENORES (calidad de código)

### BUG-18: `renderer.ts` legacy sin uso
**Archivo:** `src/ssr/renderer.ts`
**Problema:** Existe un renderer legacy de 658 líneas que NO se importa en `src/index.ts`. Solo `data.ts` importa tipos de él. Es código muerto.
**Fix:** Eliminar el archivo o migrar los tipos.

### BUG-19: Favicon del admin se pierde al rebuild
**Archivo:** `public/admin/index.html`
**Problema:** Cada `npm run build` + copia sobrescribe `index.html` sin el favicon. Se corrige manualmente con `sed`. Debería estar en el template de Vite.
**Fix:** Modificar `guardman-admin-ui/index.html` para incluir el favicon link.

### BUG-20: Env interface duplicada
**Archivos:** `src/index.ts` y `src/types/index.ts`
**Problema:** La interfaz `Env` está definida en ambos archivos con campos diferentes. `src/index.ts` tiene más bindings que `src/types/index.ts`. Esto puede causar confusiones de tipos.
**Fix:** Unificar en un solo lugar (idealmente `src/types/index.ts`) y re-exportar.

### BUG-21: `homeGuardPodTitle` en SiteData pero nunca se usa
**Archivo:** `src/ssr/site-data.ts`
**Problema:** `fetchHomepage` setea `homeGuardPodTitle` pero no está en la interfaz `SiteData` ni se usa en el template.
**Fix:** Eliminar o agregar a la interfaz.

### BUG-22: CSS `dark.css` duplicado en header
**Archivo:** `src/ssr/site-renderer.ts` — `buildGuardPodPage()` y `buildAjaxPage()`
**Problema:** Ambos incluyen:
```html
<link rel="stylesheet" href="/styles/dark.css">
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
```
El favicon link está duplicado (ya está antes en el head). Y `dark.css` se incluye doble.
**Fix:** Limpiar duplicados en el `<head>`.

### BUG-23: `SITE_URL` apunta a dominio viejo
**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`
**Problema:** `const SITE_URL = 'https://guardman-site-v2.pages.dev'` — el dominio correcto ahora es `https://guardman.cl`.
**Fix:** Actualizar a `https://guardman.cl`.

### BUG-24: Tipos de `homeNosotrosFeatures` inconsistentes
**Archivos:** `site-data.ts` vs `site-renderer.ts`
**Problema:** En `site-data.ts`, los features por defecto tienen `{icon, title, description}` pero en `SiteData` la interfaz dice `{title, description}`. El icon se ignora.
**Fix:** Quitar el campo `icon` de los defaults o agregarlo a la interfaz.

---

# PARTE 3: ISSUES ARQUITECTÓNICOS

## ARCH-01: No hay sistema de caché para páginas SSR
**Problema:** Cada request a una página SSR ejecuta múltiples queries D1. Para el homepage: `getStaticPageData()` + `fetchHomepage()` (que hace 3 queries paralelas). Para páginas de detalle: 4-5 queries.
**Impacto:** Latencia innecesaria y consumo de D1 read units.
**Solución:** Implementar caché en KV con TTL de 1 hora. Invalidar cuando se guarda desde el CMS.

## ARCH-02: Sistema de imágenes sin gestión coherente
**Problema:** Las imágenes están en 3 lugares:
1. R2 (bucket `guardman-images`) — servidas via `/images/`
2. Assets estáticos (`public/`) — servidas por Worker Assets
3. GitHub (proxy roto) — ya no funciona

No hay inventario de qué imágenes existen ni validación de que las rutas del CMS existan en R2.
**Solución:** Crear un índice de imágenes disponibles en R2. Validar rutas al guardar.

## ARCH-03: Editor CMS sin control de versiones visible
**Problema:** `content_versions` guarda versiones incrementales, pero el CMS no muestra historial ni permite revertir. Solo muestra la última versión.
**Solución:** Agregar selector de versión y diff viewer.

## ARCH-04: Sin manejo de errores para usuarios
**Problema:** Cuando D1 falla o está offline, el sitio muestra `Error: <mensaje técnico>`. No hay página 500 friendly.
**Solución:** Crear una página 500 genérica y catchear errores graceful.

## ARCH-05: Sistema de publicaciones desconectado
**Problema:** "Publicar Sitio" en el CMS intenta hacer deploy de Cloudflare Pages (`guardman-site-v2`), pero el proyecto ya no usa Pages. El sitio se sirve directamente desde el Worker. El botón "Publicar" no hace nada útil.
**Solución:** Eliminar el deploy a Pages o rediseñar como "flush caché + purge CDN".

## ARCH-06: Sin robots.txt
**Problema:** No existe `/robots.txt`. Los crawlers no tienen instrucciones de crawling.
**Solución:** Agregar ruta `/robots.txt` en el router.

## ARCH-07: HTML inline en TypeScript — difícil de mantener
**Problema:** `buildGraciasPage()`, `buildBlogPlaceholder()`, `build404Page()` son templates HTML de 30-50 líneas inline en TypeScript. Cualquier cambio de diseño requiere modificar strings TS.
**Solución:** Mover a archivos HTML separados (como los `*-html.ts`) o implementar un sistema de templates.

## ARCH-08: Nav dropdowns hardcodeados
**Problema:** `hdr()` tiene los links del menú hardcodeados. Si se agrega/elimina un servicio o ubicación, hay que modificar el código.
**Solución:** Leer servicios/ubicaciones desde D1 o generarlos dinámicamente.

## ARCH-09: Sin canonical URLs relativas vs absolutas
**Problema:** Los canonical URLs son relativos (`/servicios/guardias-de-seguridad`) pero Google recomienda absolutas. Aunque el template genera `href="https://guardman.cl${canonical}"`, el sitemap usa URLs absolutas correctamente.
**Estado:** Correcto en templates. Verificar consistencia.

## ARCH-10: Sin Open Graph images dinámicas
**Problema:** Solo el `buildDetailPage` genera `og:image`. Las páginas estáticas y homepage no tienen OG image consistente. Los shares en redes sociales se verán sin imagen.
**Solución:** Agregar OG images por defecto para todas las páginas.

---

# PARTE 4: MEJORAS DE SEO

## SEO-01: Schema markup incompleto
**Problema:** Solo las páginas de detalle (service, combo) tienen Schema.org markup. Homepage solo tiene Organization. Faltan:
- `WebSite` schema en homepage
- `BreadcrumbList` en todas las páginas
- `LocalBusiness` en páginas de ubicación
- `Service` en páginas de servicio
**Prioridad:** Alta — impacto directo en rich snippets.

## SEO-02: Sin heading hierarchy consistente
**Problema:** En el homepage, todas las secciones usan `<h2>` sin `<h3>` para sub-elementos. Los features titles no tienen heading tags. Google espera jerarquía H1→H2→H3.
**Prioridad:** Media.

## SEO-03: Alt texts genéricos en imágenes
**Problema:** Las imágenes del homepage usan alt texts genéricos como "Guard Pod", "Ajax Systems". Deberían ser descriptivos para SEO de imágenes.
**Prioridad:** Baja.

## SEO-04: Sin hreflang para regiones
**Problema:** Solo hay `hreflang="es-CL"`. Si en el futuro se expanden a otros países hispanohablantes, necesitarán hreflang completo.
**Prioridad:** Baja (futuro).

## SEO-05: Performance — sin lazy loading consistente
**Problema:** Las imágenes del hero usan `loading="eager"` (correcto), pero las de servicios/sectores usan `loading="lazy"`. Sin embargo, no hay `fetchpriority="high"` en la imagen hero ni preload.
**Prioridad:** Media — Core Web Vitals.

---

# PARTE 5: PLAN DE TRABAJO DETALLADO

## Fase 1: Bugs Críticos (Prioridad Inmediata)
**Estimación:** 4-6 horas
**Objetivo:** Estabilizar producción

### Tarea 1.1: Fix BUG-05 — Homepage save escribe D1 correcto
```
Archivo: src/api/routes/cms.ts
Qué hacer:
  1. En el handler de save, cuando path === 'static/homepage.json':
     - Además de guardar en content_versions, guardar en static_page_content
     - Escribir content_json, hero_heading, hero_subheading, hero_badge, hero_image, meta_title, meta_description
  2. Test: guardar homepage desde CMS → verificar que SSR refleja cambios

Estimación: 30 min
```

### Tarea 1.2: Fix BUG-03 — Static pages leen content_json
```
Archivos: src/ssr/site-renderer.ts, src/index.ts
Qué hacer:
  1. En renderSitePage(), para páginas estáticas, parsear content_json y overridear textos del template
  2. Modificar cada builder (buildNosotrosPage, etc.) para aceptar un data object con overrides
  3. Agregar campos editables al CMS para cada página estática (no solo meta/hero)

Estimación: 2-3 horas (6 páginas × 20 min c/u + editor)
```

### Tarea 1.3: Fix BUG-04 — Homepage loading state
```
Archivo: guardman-admin-ui/src/components/CMS/CMSPage.tsx
Qué hacer:
  1. En loadHomepage(), agregar setHomeLoaded(true) en TODOS los paths (error incluido)
  2. Agregar timeout de 10s que muestre error si no carga

Estimación: 15 min
```

### Tarea 1.4: Fix BUG-01 + BUG-02 — Router cleanup
```
Archivo: src/index.ts
Qué hacer:
  1. Eliminar sitemap duplicado
  2. Reordenar: forms POST antes de assets estáticos
  3. Reordenar: sitemap antes de SSR (está en posición correcta, verificar)

Estimación: 15 min
```

### Tarea 1.5: Fix BUG-06 — Image proxy roto
```
Archivo: src/api/routes/cms.ts
Qué hacer:
  1. Eliminar endpoint /api/cms/image o redirigir a /images/{path} (R2 proxy)
  2. Verificar que ImageField en CMS usa el endpoint correcto

Estimación: 15 min
```

### Tarea 1.6: Fix BUG-12 + BUG-14 — Mobile nav funcional
```
Archivos: src/ssr/site-renderer.ts, public/scripts/main.js
Qué hacer:
  1. Agregar <script src="/scripts/main.js"> al footer de ftr()
  2. En main.js: toggle mobile menu, toggle dropdowns, FAQ accordion enhancement
  3. Agregar ARIA labels para accesibilidad

Estimación: 1 hora
```

---

## Fase 2: Bugs Medios (Prioridad Alta)
**Estimación:** 3-4 horas
**Objetivo:** Mejorar experiencia de usuario y consistencia

### Tarea 2.1: Fix BUG-09 — Ajax features formato consistente
```
Archivos: src/ssr/site-renderer.ts, src/index.ts, guardman-admin-ui/src/components/CMS/CMSPage.tsx
Qué hacer:
  1. Cambiar homeAjaxFeatures de string[] a Array<{title:string,description:string}> en SiteData
  2. Actualizar fetchHomepage defaults
  3. Actualizar el template de Ajax en buildHomepage
  4. Actualizar el override en src/index.ts
  5. Actualizar calcBackendScore y SEOPanel

Estimación: 45 min
```

### Tarea 2.2: Fix BUG-08 — CTAs editables en homepage
```
Archivos: guardman-admin-ui/src/components/CMS/CMSPage.tsx, src/ssr/site-renderer.ts, src/index.ts
Qué hacer:
  1. Agregar campos CTA al editor del homepage (hero section)
  2. Overridear heroCtas desde content_json en src/index.ts
  3. Template ya soporta heroCtas dinámicos

Estimación: 30 min
```

### Tarea 2.3: Fix BUG-11 — Mostrar quality pipeline en UI
```
Archivo: guardman-admin-ui/src/components/CMS/CMSPage.tsx
Qué hacer:
  1. Capturar qualityPipeline de la respuesta de regenerate
  2. Mostrar score del pipeline, violations, genericPhrases en SEOPanel
  3. Agregar badges visuales (passed/failed)

Estimación: 30 min
```

### Tarea 2.4: Fix BUG-23 + BUG-17 + BUG-22 — Cleanup menores
```
Qué hacer:
  1. Actualizar SITE_URL a https://guardman.cl
  2. Corregir typos en meta descriptions
  3. Eliminar duplicados de favicon y dark.css en heads
  4. Actualizar API_BASE a dominio correcto

Estimación: 20 min
```

### Tarea 2.5: Fix BUG-13 — Sector images fallback
```
Archivos: src/ssr/site-renderer.ts, src/index.ts
Qué hacer:
  1. Verificar qué sector images existen en R2
  2. Para los que no existen, usar un fallback genérico con overlay del nombre del sector
  3. Alternativa: crear un endpoint que genere imágenes placeholder con el nombre

Estimación: 30 min
```

---

## Fase 3: Mejoras Arquitectónicas
**Estimación:** 8-12 horas
**Objetivo:** Escalabilidad y mantenibilidad

### Tarea 3.1: ARCH-01 — Sistema de caché KV
```
Archivos: src/index.ts (nuevo: src/services/cache.ts)
Qué hacer:
  1. Crear servicio de caché con KV:
     - getKey('homepage'), getKey('service', slug), etc.
     - set() con TTL configurable (default: 3600s)
     - invalidate(entityType, slug) — llamar al guardar
  2. En renderSitePage(), cachear respuestas HTML completas
  3. En CMS save/regenerate, invalidar caché relevante
  4. Cache headers: CDN-Cache-Control para Cloudflare edge

Esquema de keys:
  page:homepage        → HTML string
  page:service:{slug}  → HTML string
  page:sector:{slug}   → HTML string
  page:location:{slug} → HTML string
  page:combo:{svc}/{loc} → HTML string
  data:homepage        → SiteData JSON

Estimación: 3 horas
```

### Tarea 3.2: ARCH-06 — robots.txt
```
Archivo: src/index.ts
Qué hacer:
  1. Agregar ruta /robots.txt
  2. Generar dinámicamente:
     User-agent: *
     Allow: /
     Disallow: /admin/
     Disallow: /api/
     Sitemap: https://guardman.cl/sitemap.xml

Estimación: 15 min
```

### Tarea 3.3: ARCH-05 — Publicar Sitio = Flush caché
```
Archivos: src/api/routes/cms.ts, guardman-admin-ui/src/components/CMS/CMSPage.tsx
Qué hacer:
  1. Cambiar /api/cms/rebuild para:
     - Flush KV caché
     - Zone purge via CF API
  2. Actualizar UI del botón "Publicar"
  3. Eliminar referencia a Pages deploy

Estimación: 1 hora
```

### Tarea 3.4: ARCH-04 — Página 500 friendly
```
Archivo: src/index.ts
Qué hacer:
  1. Crear build500Page() con diseño del sitio
  2. Wrappear renderSitePage en try/catch que muestre 500 page
  3. Loggear error a D1 o console

Estimación: 30 min
```

### Tarea 3.5: ARCH-07 — Templates HTML separados
```
Archivos: src/ssr/gracias-html.ts, src/ssr/blog-html.ts, src/ssr/error404-html.ts
Qué hacer:
  1. Mover HTML inline a archivos separados como los demás
  2. Importar y usar en index.ts

Estimación: 30 min
```

### Tarea 3.6: ARCH-08 — Nav dinámico desde D1
```
Archivos: src/ssr/site-renderer.ts, src/ssr/site-data.ts, src/index.ts
Qué hacer:
  1. Modificar hdr() para aceptar navServices, navLocations, navSectors como params
  2. Fetch nav data en renderSitePage (con caché KV)
  3. Pasar al renderer

Estimación: 1.5 horas
```

### Tarea 3.7: ARCH-02 — Índice de imágenes R2
```
Archivos: src/api/routes/media.ts, guardman-admin-ui/src/components/Media/ImagePicker.tsx
Qué hacer:
  1. Endpoint /api/media/list que liste todas las keys en R2
  2. Cachear la lista en KV (TTL 5 min)
  3. ImagePicker usa esta lista (ya existe, verificar que funciona)
  4. Validar al guardar CMS que las rutas de imagen existan en R2

Estimación: 2 horas
```

---

## Fase 4: Mejoras SEO
**Estimación:** 4-6 horas
**Objetivo:** Posicionamiento orgánico

### Tarea 4.1: SEO-01 — Schema markup completo
```
Archivos: src/ssr/site-renderer.ts, src/ssr/site-data.ts
Qué hacer:
  1. Homepage: agregar WebSite + SearchAction schema
  2. Todas las páginas: agregar BreadcrumbList schema
  3. Location pages: agregar LocalBusiness schema con geo coords
  4. Service pages: agregar Service schema con areaServed
  5. Agregar __init__ schema de Organization en todas las páginas

Estimación: 2 horas
```

### Tarea 4.2: SEO-05 — Performance optimization
```
Archivos: src/ssr/site-renderer.ts
Qué hacer:
  1. Agregar fetchpriority="high" a hero image
  2. Agregar <link rel="preload"> para hero image y CSS crítico
  3. Agregar width/height a todas las imágenes (CLS prevention)
  4. Agregar font-display: swap para Inter

Estimación: 1 hora
```

### Tarea 4.3: SEO-02 — Heading hierarchy
```
Archivo: src/ssr/site-renderer.ts
Qué hacer:
  1. En homepage features, usar <h3> para feature titles
  2. En sectores grid, usar <h3> para sector names
  3. En ubicaciones, usar <h3> para zone names
  4. Verificar que H1 solo aparece una vez por página

Estimación: 45 min
```

### Tarea 4.4: ARCH-10 — OG Images
```
Archivos: src/ssr/site-renderer.ts, src/index.ts
Qué hacer:
  1. Crear og:image por defecto para el sitio
  2. Agregar og:image a homepage
  3. Agregar og:image a páginas estáticas
  4. Para service/combo/sector/location, usar hero_image como og:image

Estimación: 30 min
```

---

## Fase 5: Limpieza de Código
**Estimación:** 2-3 horas
**Objetivo:** Reducir deuda técnica

### Tarea 5.1: Eliminar código legacy
```
Qué hacer:
  1. Eliminar src/ssr/renderer.ts (660 líneas) — no se importa
  2. Eliminar src/services/auth.ts::legacyAuthCheck (no se usa)
  3. Eliminar public/admin/index.html hardcoded favicon (fix en Vite template)
  4. Eliminar scripts/ legacy (build-static-pages.py, fix-cms.py, update-builders.py)
  5. Eliminar sql/ duplicados (faqs-batch-*.sql pueden consolidarse)

Estimación: 1 hora
```

### Tarea 5.2: Unificar interfaces
```
Archivos: src/index.ts, src/types/index.ts
Qué hacer:
  1. Mover Env de src/index.ts a src/types/index.ts (completo)
  2. Re-exportar desde src/index.ts
  3. Eliminar GeneratedContent duplicado si existe

Estimación: 30 min
```

### Tarea 5.3: Fix BUG-19 — Favicon en Vite template
```
Archivo: guardman-admin-ui/index.html
Qué hacer:
  1. Agregar <link rel="icon" type="image/svg+xml" href="/favicon.svg"> al template
  2. Eliminar el sed del proceso de deploy

Estimación: 5 min
```

### Tarea 5.4: Eliminar variables no usadas
```
Archivos: src/ssr/site-renderer.ts, src/ssr/site-data.ts
Qué hacer:
  1. homeGuardPodTitle (definido pero no en interfaz)
  2. homeNosotrosFeatures con icon (campo no en interfaz)
  3. Verificar con TypeScript strict mode

Estimación: 20 min
```

---

## Fase 6: Features Nuevas (Post-estabilización)
**Estimación:** Variable
**Objetivo:** Cerrar gaps funcionales

### Tarea 6.1: Blog completo (Issue #2 del doc original)
```
Qué hacer:
  1. Crear tabla blog_posts en D1 (title, slug, content, excerpt, image, published_at, author)
  2. Crear blog post editor en CMS
  3. Crear blog listing page SSR con paginación
  4. Crear blog post detail page SSR
  5. Agregar /blog/{slug} al sitemap
  6. Agregar schema BlogPosting

Estimación: 8-10 horas
Dependencia: Fase 1 y 2 completadas
```

### Tarea 6.2: Client logos section (Issue #3)
```
Qué hacer:
  1. Decidir ubicación en homepage
  2. Crear tabla client_logos en D1 (name, logo_url, link)
  3. Agregar sección al homepage template
  4. Agregar editor en CMS

Estimación: 3-4 horas
```

### Tarea 6.3: Historial de versiones CMS (ARCH-03)
```
Qué hacer:
  1. Endpoint /api/cms/versions?type=X&slug=Y
  2. UI de selector de versión
  3. Diff viewer (comparar versiones)
  4. Botón "Restaurar esta versión"

Estimación: 6-8 horas
```

### Tarea 6.4: Auth con JWT (BUG-07)
```
Qué hacer:
  1. Implementar JWT con expiración (24h)
  2. Refresh token endpoint
  3. Logout (invalidar token en KV)
  4. Login UI mejorado

Estimación: 4-5 horas
```

---

# PARTE 6: PRIORIZACIÓN Y CRONOGRAMA

## Sprint 1 (Inmediato — Estabilizar) — 4-6 horas

| # | Tarea | Estimación | Impacto |
|---|-------|------------|----------|
| 1 | BUG-05: Homepage save → D1 correcto | 30 min | 🔴 Crítico |
| 2 | BUG-01+02: Router cleanup | 15 min | 🔴 Crítico |
| 3 | BUG-04: Homepage loading state | 15 min | 🔴 Crítico |
| 4 | BUG-06: Image proxy | 15 min | 🔴 Crítico |
| 5 | BUG-03: Static pages content_json | 2-3 h | 🟡 Medio-Alto |
| 6 | BUG-12+14: Mobile nav | 1 h | 🟡 Medio |

## Sprint 2 (Corto plazo — Consistencia) — 3-4 horas

| # | Tarea | Estimación | Impacto |
|---|-------|------------|----------|
| 7 | BUG-09: Ajax features formato | 45 min | 🟡 Medio |
| 8 | BUG-08: CTAs editables homepage | 30 min | 🟡 Medio |
| 9 | BUG-11: Quality pipeline en UI | 30 min | 🟡 Medio |
| 10 | BUG-23+17+22: Cleanup menores | 20 min | 🟢 Menor |
| 11 | BUG-13: Sector images fallback | 30 min | 🟡 Medio |

## Sprint 3 (Medio plazo — Arquitectura) — 8-12 horas

| # | Tarea | Estimación | Impacto |
|---|-------|------------|----------|
| 12 | ARCH-01: Caché KV | 3 h | 🔴 Alto |
| 13 | ARCH-06: robots.txt | 15 min | 🟡 Medio |
| 14 | ARCH-05: Publicar = Flush | 1 h | 🟡 Medio |
| 15 | ARCH-04: Página 500 | 30 min | 🟡 Medio |
| 16 | ARCH-07: Templates separados | 30 min | 🟢 Menor |
| 17 | ARCH-08: Nav dinámico | 1.5 h | 🟡 Medio |
| 18 | ARCH-02: Índice imágenes R2 | 2 h | 🟡 Medio |

## Sprint 4 (SEO) — 4-6 horas

| # | Tarea | Estimación | Impacto |
|---|-------|------------|----------|
| 19 | SEO-01: Schema markup | 2 h | 🔴 Alto |
| 20 | SEO-05: Performance | 1 h | 🟡 Medio |
| 21 | SEO-02: Heading hierarchy | 45 min | 🟡 Medio |
| 22 | ARCH-10: OG Images | 30 min | 🟡 Medio |

## Sprint 5 (Limpieza) — 2-3 horas

| # | Tarea | Estimación | Impacto |
|---|-------|------------|----------|
| 23 | Eliminar renderer.ts legacy | 15 min | 🟢 Menor |
| 24 | Unificar Env interfaces | 30 min | 🟢 Menor |
| 25 | Fix favicon Vite template | 5 min | 🟢 Menor |
| 26 | Eliminar variables no usadas | 20 min | 🟢 Menor |
| 27 | Eliminar scripts legacy | 15 min | 🟢 Menor |

---

# PARTE 7: RESUMEN DE MÉTRICAS

## Bugs por severidad
- 🔴 Críticos: 7 (BUG-01 a BUG-07)
- 🟡 Medios: 10 (BUG-08 a BUG-17)
- 🟢 Menores: 7 (BUG-18 a BUG-24)
- **Total: 24 bugs**

## Issues arquitectónicos
- **10 issues** identificados (ARCH-01 a ARCH-10)

## Mejoras SEO
- **5 mejoras** identificadas (SEO-01 a SEO-05)

## Esfuerzo total estimado
| Categoría | Estimación |
|-----------|------------|
| Bugs Críticos | 4-6 horas |
| Bugs Medios | 3-4 horas |
| Arquitectura | 8-12 horas |
| SEO | 4-6 horas |
| Limpieza | 2-3 horas |
| Features nuevas | 21-27 horas |
| **Total (sin features)** | **21-31 horas** |
| **Total (con features)** | **42-58 horas** |

## Archivos más afectados (por número de bugs)
1. `src/index.ts` — 6 bugs
2. `src/ssr/site-renderer.ts` — 5 bugs
3. `guardman-admin-ui/src/components/CMS/CMSPage.tsx` — 4 bugs
4. `src/api/routes/cms.ts` — 3 bugs
5. `src/ssr/site-data.ts` — 2 bugs

---

# APÉNDICE A: Checklist Pre-Deploy

Antes de cada deploy, verificar:

- [ ] `npm run build` del admin UI sin errores
- [ ] Copiar dist a public/admin/
- [ ] Agregar favicon al admin index.html
- [ ] `wrangler deploy` sin errores
- [ ] Homepage carga correctamente
- [ ] Una página de servicio carga
- [ ] Una página de ubicación carga
- [ ] Formulario /contacto POST → 302 → /gracias
- [ ] Formulario /cotizacion POST → 302 → /gracias
- [ ] Admin CMS carga homepage
- [ ] Admin CMS guarda homepage
- [ ] Admin CMS lista servicios
- [ ] Sitemap.xml generado
- [ ] /health responde OK

# APÉNDICE B: Tabla de Rutas SSR

| Ruta | Pattern | Data Source | Builder |
|------|---------|-------------|---------|
| `/` | Exact | D1 static_page_content + services/sectors/locations | buildHomepage() |
| `/servicios/{slug}` | `/servicios/[^/]+` | D1 services + content_versions | buildDetailPage() |
| `/ubicaciones/{slug}` | `/ubicaciones/[^/]+` | D1 locations + combo_content | buildDetailPage() |
| `/sectores/{slug}` | `/sectores/[^/]+` | D1 sectors + content_versions | buildDetailPage() |
| `/servicios/{svc}/{loc}` | 2 segments | D1 combo_content | buildDetailPage() |
| `/servicios` | Exact | D1 services | buildHubPage() |
| `/ubicaciones` | Exact | D1 locations | buildHubPage() |
| `/sectores` | Exact | D1 sectors | buildHubPage() |
| `/nosotros` | Exact | D1 static_page_content | buildNosotrosPage() |
| `/guard-pod` | Exact | D1 static_page_content | buildGuardPodPage() |
| `/ajax-systems` | Exact | D1 static_page_content | buildAjaxPage() |
| `/contacto` | Exact | D1 static_page_content | buildContactoPage() |
| `/cotizacion` | Exact | D1 static_page_content | buildCotizacionPage() |
| `/privacidad` | Exact | D1 static_page_content | buildPrivacidadPage() |
| `/terminos` | Exact | D1 static_page_content | buildTerminosPage() |
| `/gracias` | Exact | Static | buildGraciasPage() |
| `/blog` | Exact | Static | buildBlogPlaceholder() |
| `/sitemap.xml` | Exact | D1 queries | handleSitemap() |

# APÉNDICE C: Mapa de Tablas D1

```
services — 9 rows (slug, name, short_description, hero_image, sectors, sort)
locations — 14 rows (slug, name, zone, image)
sectors — 9 rows (slug, name, color_tag, hero_image, issues)
combo_content — 126 rows (service_slug, location_slug, content_json, status)
static_page_content — 8 rows (slug, hero_heading, hero_subheading, hero_badge, hero_image, meta_title, meta_description, content_json)
content_versions — N rows (entity_type, entity_slug, version, content_json, generated_by, word_count)
intel_leads — N rows (slug, status, source, contact_name, contact_email, etc.)
brand_dna — 89+ rows (category, key, value)
serper_queries — N rows (query_text, service_slug, location_slug, status, endpoint)
serper_results — N rows (query_id, position, domain, title, snippet, result_type)
faqs — N rows (service_slug, question, answer, source, frequency_rank)
keywords — N rows (keyword, service_slug, intent, sds_tier, is_easy_win)
landmarks — N rows (location_slug, name, type, relevance_score)
agent_knowledge — N rows (category, key, value)
```

---

*Documento generado el 2026-05-07 por análisis exhaustivo del código fuente.*
*Proyecto: guardman-admin — ~34,600 líneas TS/TSX*
