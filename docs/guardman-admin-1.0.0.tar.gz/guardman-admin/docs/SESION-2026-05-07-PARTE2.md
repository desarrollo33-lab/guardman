# Sesión 2026-05-07 (Parte 2) — CMS Homepage Editor, SEO Scoring, Formularios y SSR

## Resumen

Continuación de la sesión de consolidación. Se resolvió el bug de regeneración de contenido del homepage en el CMS, se conectó el editor del CMS con el sitio público, se arreglaron los scorers SEO, y se aseguró que el contenido editado se refleje en el sitio.

**Versión final deployada:** `c83ae603-b50e-4fea-9ff2-d21ca9792661`

---

## 1. Bug: Regenerate del Homepage daba 400 (Bad Request)

### Problema

Al hacer click en "Regenerar con IA" en el editor del Homepage, el backend respondía `400: Missing type or slug`.

### Causa raíz

En `CMSPage.tsx`, el mapeo `TYPE_LABELS` no tenía entrada para `contentType = 'static'`:

```typescript
// ANTES — sin 'static'
const TYPE_LABELS = {
  services: 'service',
  locations: 'location',
  sectors: 'sector',
  combos: 'combo'
};
```

Cuando el usuario estaba en la tab "Páginas" (static), `TYPE_LABELS['static']` era `undefined`, y el endpoint `/api/cms/regenerate` rechazaba con `Missing type or slug`.

### Fix

Se reemplazó el acceso directo a `TYPE_LABELS[contentType]` por una función `getEntityType()` que distingue homepage de otras páginas estáticas:

```typescript
const getEntityType = () => {
  if (contentType === 'static' && selectedItem?.slug === 'homepage') return 'home';
  if (contentType === 'static') return 'static_page';
  return TYPE_LABELS[contentType];
};
```

Esto es importante porque el backend usa `type: 'home'` para generar con el prompt específico de homepage (con secciones como nosotros, guardpod, ajax) en vez del prompt genérico (intro, features, issues, faqs).

**Archivos:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

---

## 2. Bug: Regenerar Homepage no llenaba los campos del editor

### Problema

La regeneración con IA respondía OK, pero los campos del editor del homepage (Nosotros, Guard Pod, Ajax, etc.) quedaban vacíos. Solo se llenaban Hero y SEO.

### Causa raíz (3 problemas encadenados)

#### 2.1 El prompt de la AI usaba nombres de campo diferentes al editor

El prompt en `src/services/ai.ts` para `type: 'home'` pedía:
```
hero: { badge, heading, subheading, image }
nosotros: { badge, heading, paragraphs: [string], features: [{icon, text}], image }
guardpod: { badge, heading, subheading, features: [{icon, text}] }
```

Pero el editor del homepage usa:
```
hero: { headline, subheadline, background_image, phone, badge_image }
nosotros: { badge, title, paragraph, image, cta_text, features: [{title, description}] }
guardpod: { badge, title, paragraph, image, cta_text, features: [{title, description}] }
```

**Fix:** Se reescribió el prompt AI para `type: 'home'` para generar exactamente los nombres de campo que el editor espera:

```
hero: { headline, subheadline, background_image, phone, badge, badge_image }
nosotros: { badge, title, paragraph, image, image_badge, cta_text, cta_link, stats, features: [{title, description}] }
servicios: { title, subtitle, cta_text, cta_link }
guardpod: { badge, title, paragraph, image, image_badge, cta_text, cta_link, features: [{title, description}] }
...
```

**Archivo:** `src/services/ai.ts`

#### 2.2 El mapper no convertía correctamente la respuesta AI al formato del editor

La función `mapAIToHomepageEditor` estaba diseñada para el formato viejo del prompt (con `heading`, `paragraphs`, `icon/text`). No manejaba el formato nuevo (`headline`, `paragraph`, `title/description`).

**Fix:** Se reescribió completamente el mapper para mapear 1:1 la respuesta de la AI al formato del editor, con fallbacks para ambos formatos de nombres:

```typescript
const mapAIToHomepageEditor = (sections: any): any => {
  const h = sections.hero || {};
  const n = sections.nosotros || {};
  const gp = sections.guardpod || {};
  // ...
  return {
    hero: {
      headline: h.headline || h.heading || '',
      subheadline: h.subheadline || h.subheading || '',
      // ...
    },
    nosotros: {
      paragraph: n.paragraph || (Array.isArray(n.paragraphs) ? n.paragraphs.join('\n\n') : ''),
      features: (n.features || []).map(f => ({
        title: typeof f === 'string' ? f : f.title || f.text || '',
        description: typeof f === 'string' ? '' : f.description || '',
      })),
      // ...
    },
    // ... guardpod, ajax, cta_final, etc.
  };
};
```

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

#### 2.3 El `regenerateContent` hacía merge genérico sin usar el mapper

El código original era:
```typescript
content: { ...content.content, ...improved }
```

Esto mergeaba el formato AI (`hero.heading`, `intro.paragraphs`) directamente en el formato del editor (`hero.headline`, `nosotros.paragraph`), resultando en campos vacíos.

**Fix:** Se agregó detección de homepage para usar el mapper:
```typescript
const mappedContent = (contentType === 'static' && selectedItem?.slug === 'homepage')
  ? mapAIToHomepageEditor(improved)
  : { ...content.content, ...improved };
```

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

---

## 3. Bug: SEOPanel mostraba score 12/100 para Homepage con contenido completo

### Problema

Después de regenerar el homepage con contenido completo (nosotros con párrafo largo, features, guardpod, ajax), el panel SEO lateral mostraba score 12 y checks como "Intro: ✗", "Features: 0", "FAQs: 0", "Palabras: 0".

### Causa raíz

El componente `SEOPanel.tsx` era un **componente separado** con su propio scoring hardcodeado para formato genérico (`intro.paragraphs`, `features.items`, `faqs.items`, `cta.heading`). No sabía del formato homepage (`nosotros.paragraph`, `guardpod.features`, `ajax.features`, `cta_final.title`).

Además, buscaba `hero.heading` (genérico) en vez de `hero.headline` (homepage), así que ni siquiera detectaba el hero.

### Fix

Se reescribió completamente `SEOPanel.tsx` con una función `computeScore()` que:

1. **Detecta automáticamente** el formato: `isHomepage = !!(sections.nosotros || sections.servicios || sections.guardpod)`
2. **Homepage scoring** evalúa: Title, Description, Hero (headline + background_image), Nosotros (paragraph + features), Guard Pod (paragraph + features), Ajax Systems (paragraph + features), CTA Final (title + subtitle), Ubicaciones (title)
3. **Generic scoring** evalúa: Title, Description, Hero, Intro, Features, FAQs, CTA (como antes)
4. Genera una lista dinámica de `checks` con labels contextuales (ej: "Nosotros" en vez de "Intro", "Guard Pod" en vez de "FAQs")
5. Muestra "(Homepage)" en el header de Calidad cuando corresponde

**Archivo:** `guardman-admin-ui/src/components/CMS/SEOPanel.tsx` (rewrite completo)

---

## 4. Bug: `allText is not defined` — Crash en páginas estáticas

### Problema

Al seleccionar cualquier página en la tab "Páginas" (Nosotros, Ajax, etc.), el admin crasheaba con error `allText is not defined`. Al seleccionar Homepage, se quedaba en "Cargando homepage..." indefinidamente.

### Causa raíz

En `calcBackendScore()` dentro de `CMSPage.tsx`, la variable `allText` estaba declarada con `const` dentro de los bloques `if (isHomepage) { ... } else { ... }`, pero el código de TTR check (Type-Token Ratio) y foreign word check estaba **fuera del bloque** y no podía verla:

```typescript
if (isHomepage) {
  const allText = [...]; // solo existe aquí
} else {
  const allText = [...]; // solo existe aquí
}
// TTR check — allText no existe aquí → ReferenceError
const meaningfulWords = allText.toLowerCase().split(/\s+/)...;
```

### Fix

Se declaró `allText` y `words` con `let` antes del `if/else`:

```typescript
let allText = '';
let words = 0;

if (isHomepage) {
  allText = [...].join(' ');
  words = allText.split(/\s+/).filter(Boolean).length;
} else {
  allText = [...].join(' ');
  words = allText.split(/\s+/).filter(Boolean).length;
}
// TTR check — allText ahora es visible
```

**Por qué Homepage se quedaba cargando:** `loadHomepage()` llama `setSeoScore(calcBackendScore(data.content))`. Si `calcBackendScore` crashea, la excepción no capturada hace que `setLoadingContent(false)` nunca se ejecute, y el UI queda en estado "Cargando...".

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

---

## 5. Formularios POST real + Leads en D1

### Problema

Los formularios de `/contacto` y `/cotizacion` usaban `onsubmit="event.preventDefault();alert('Mensaje enviado.')"` — nunca enviaban datos al servidor. Los leads no se guardaban en D1.

### Fix

**contacto-html.ts:**
- `<form>` ahora tiene `method="POST" action="/contacto"`
- Todos los inputs tienen `name` attributes
- Honeypot anti-spam `_honey` (hidden field)
- Selects de servicio usan slugs (`value="guardias-de-seguridad"` en vez de `value="Guardias de Seguridad"`)
- Select de comuna con `name="location"`

**cotizacion-html.ts:**
- Mismo patrón con `method="POST" action="/cotizacion"`
- Campos adicionales: `empresa`, `tipo_propiedad`, `cantidad_guardias`
- Todos los selects con slugs como values

**Verificación end-to-end:**
```
curl POST /contacto → 302 → /gracias
curl POST /cotizacion → 302 → /gracias
D1 intel_leads: lead guardado con service_slug + location_slug ✅
```

**Archivos:** `src/ssr/contacto-html.ts`, `src/ssr/cotizacion-html.ts`

---

## 6. Página `/gracias` SSR

### Problema

El redirect post-formulario iba a `/gracias` pero no existía la ruta SSR. El usuario veía un 404 después de enviar un formulario.

### Fix

Se creó `buildGraciasPage()` en `src/index.ts` con:
- Hero con checkmark verde y título "¡Gracias por tu solicitud!"
- Sección "¿Qué sigue?" con 3 pasos numerados (revisión, contacto, cotización)
- CTAs: "Volver al inicio" y "Solicitar otra cotización"
- Header/footer/nav completos
- Agregada al sitemap con `changefreq=never` y `priority=0.1`

**Archivo:** `src/index.ts`

---

## 7. CMS → Sitio Público: Override del Homepage desde content_json

### Problema

El CMS editor guardaba toda la estructura del homepage en `static_page_content.content_json` (nosotros paragraph, guardpod features, ajax features, etc.), pero el sitio público (`src/index.ts`) solo leía 5 campos planos de la tabla (`hero_heading`, `hero_subheading`, `hero_badge`, `meta_title`, `meta_description`). Los textos editados en el CMS no se reflejaban en el sitio.

### Arquitectura del problema

```
CMS Editor → guarda en D1:
  static_page_content.content_json = {
    seo: { title, description },
    content: {
      hero: { headline, subheadline, background_image },
      nosotros: { paragraph, features },
      guardpod: { paragraph, features, image },
      ajax: { paragraph, features, image },
      cta_final: { title, subtitle }
    }
  }

Sitio público leía:
  static_page_content.hero_heading  → solo esto
  static_page_content.hero_subheading
  static_page_content.hero_badge
  static_page_content.meta_title
  static_page_content.meta_description
```

### Fix

#### 7.1 Backend: `GET /api/cms/content` ahora devuelve content_json completo

Cuando `content_json` existe y tiene el formato del editor (tiene keys `seo` o `content`), se parsea y devuelve completo. Si no, se mantiene el formato minimal desde columnas.

```typescript
if (sp.content_json) {
  const parsed = JSON.parse(sp.content_json);
  if (parsed.seo || parsed.content) {
    return Response.json({ ok: true, content: {
      seo: parsed.seo || {...},
      content: parsed.content || {},
      meta: parsed.meta || {...}
    }});
  }
}
```

**Archivo:** `src/api/routes/cms.ts`

#### 7.2 Frontend: `loadHomepage` mergea con defaults para todas las secciones

Si el backend devuelve solo `hero` (formato viejo), el frontend completa las secciones faltantes con defaults:

```typescript
if (loaded.content && !loaded.content.nosotros) {
  loaded.content = {
    hero: { headline, subheadline, background_image, ... },
    nosotros: { badge, title, paragraph, ... defaults },
    guardpod: { ... defaults },
    ajax: { ... defaults },
    cta_final: { ... defaults },
    ...loaded.content,  // override con lo que sí tiene
  };
}
```

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

#### 7.3 Frontend: `saveHomepage` ahora envía la estructura completa

Antes solo enviaba campos planos. Ahora envía todo:

```typescript
const fullContent = {
  seo: content.seo,
  content: content.content,
  meta: content.meta,
  hero_heading: content.content?.hero?.headline || '',
  // ... flat fields para backwards compat
};
```

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

#### 7.4 SSR: Homepage lee content_json y overridea los datos del template

Se agregó código en `src/index.ts` que parsea `content_json` y overridea los campos del `SiteData`:

```typescript
if (staticData?.content_json) {
  const cj = JSON.parse(staticData.content_json);
  const c = cj.content || cj;
  
  // Hero
  if (c.hero?.headline) data.heroHeading = c.hero.headline;
  if (c.hero?.subheadline) data.heroSubheading = c.hero.subheadline;
  
  // Nosotros
  if (c.nosotros?.paragraph) data.homeNosotrosParagraph = c.nosotros.paragraph;
  if (c.nosotros?.features) data.homeNosotrosFeatures = c.nosotros.features;
  
  // GuardPod
  if (c.guardpod?.features) data.homeGuardPodFeatures = c.guardpod.features;
  
  // Ajax
  if (c.ajax?.features) data.homeAjaxFeatures = c.ajax.features;
}
```

**Archivo:** `src/index.ts`

#### 7.5 Renderer: Imágenes de Guard Pod y Ajax ahora son dinámicas

Antes estaban hardcodeadas:
```typescript
// ANTES
<img src="/images/s4-thumbnail.webp" alt="Guard Pod">
<img src="/images/Ajax-systems-header.jpg" alt="Ajax Systems">
```

Ahora usan variables del SiteData:
```typescript
// DESPUÉS
<img src="${esc(d.homeGuardPodImage||'/images/s4-thumbnail.webp')}" alt="Guard Pod">
<img src="${esc(d.homeAjaxImage||'/images/Ajax-systems-header.jpg')}" alt="Ajax Systems">
```

Se agregaron `homeGuardPodImage` y `homeAjaxImage` a la interfaz `SiteData` y se propagan desde el content_json override.

**Archivos:** `src/ssr/site-renderer.ts` (interfaz + template), `src/index.ts` (override)

#### 7.6 Filtro de imágenes inválidas de la AI

La AI generaba rutas de imagen que no existen en R2 (como `/images/service-homepage.webp`, `/images/name.webp`). Se agregaron filtros:

```typescript
if (h.background_image && !h.background_image.includes('/name.') 
    && h.background_image !== '/images/service-homepage.webp') 
  data.heroImage = h.background_image;
```

**Archivo:** `src/index.ts`

---

## 8. Favicon y Admin UI

### favicon.ico

Se generó un favicon.ico de 16x16px programáticamente con el escudo azul de GuardMan sobre fondo oscuro (#1a1a2e). Compatible con navegadores legacy.

**Archivo:** `public/favicon.ico` (1142 bytes)

### Admin UI favicon

Se agregó `<link rel="icon" type="image/svg+xml" href="/favicon.svg">` al `index.html` del admin SPA. Este cambio se pierde cada vez que se hace `npm run build` y se copia el dist, así que se agrega automáticamente en el script de deploy.

**Archivo:** `public/admin/index.html`

---

## 9. Scorer SEO unificado (calcBackendScore)

### Problema

`calcBackendScore()` en `CMSPage.tsx` solo entendía formato genérico (`intro.paragraphs`, `features.items`, `faqs.items`). Para el homepage, no encontraba nada y daba puntaje bajo.

### Fix

Se bifurcó el scoring:

```typescript
const isHomepage = !!(sections.nosotros || sections.servicios || sections.guardpod || sections.cta_final);

if (isHomepage) {
  // Evaluar: nosotros paragraph, nosotros features, guardpod paragraph, guardpod features,
  // ajax paragraph, ajax features, cta_final title/subtitle, ubicaciones title, servicios title
} else {
  // Evaluar: intro paragraphs, features items, issues items, faqs items, cta heading/button
}
```

**Máximo score homepage:** ~100 pts (Title 12 + Desc 12 + Hero 10 + Nosotros paragraph 10 + Nosotros features 8 + GuardPod 10 + Ajax 10 + CTA Final 8 + Ubicaciones 3 + Servicios 3 + Words 8 + bonuses)

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

---

## 10. Archivos Modificados — Resumen Completo

| Archivo | Tipo | Cambios |
|---|---|---|
| `src/index.ts` | Backend | Rutas `/gracias`, `/blog` (builder functions), override homepage desde `content_json`, imágenes dinámicas |
| `src/api/routes/cms.ts` | Backend | Load homepage: parse `content_json` completo, fallback a columnas |
| `src/services/ai.ts` | Backend | Prompt AI para `type: 'home'` reescrito con nombres de campo del editor |
| `src/ssr/site-renderer.ts` | Backend | Interfaz `SiteData` con `homeGuardPodImage`, `homeAjaxImage`; templates con imágenes dinámicas |
| `src/ssr/contacto-html.ts` | Backend | Formulario POST real con `name` attrs, honeypot, slugs |
| `src/ssr/cotizacion-html.ts` | Backend | Formulario POST real con `name` attrs, honeypot, slugs |
| `public/favicon.ico` | Asset | Generado 16x16px |
| `public/admin/index.html` | Asset | Agregado favicon link |
| `guardman-admin-ui/.../CMSPage.tsx` | Frontend | `getEntityType()`, `mapAIToHomepageEditor()`, `loadHomepage` con defaults, `saveHomepage` completo, `calcBackendScore` bifurcado, `allText` fix |
| `guardman-admin-ui/.../SEOPanel.tsx` | Frontend | Rewrite completo con `computeScore()` que detecta homepage vs genérico |

---

## 11. Issues Pendientes

| # | Issue | Prioridad | Detalle |
|---|---|---|---|
| 1 | **Sector images son placeholders** | Media | comercial, construcción, educación, eventos, salud usan imágenes de otros sectores. Se necesitan imágenes reales del cliente |
| 2 | **Blog es placeholder** | Baja | Muestra "Próximamente". Necesita tabla en D1, SSR template, editor en Admin |
| 3 | **Client logos en R2 pero no mostrados** | Baja | CSS listo (`.clients-row`, `.client-logo`). Logos en R2 (avanzapark, marriott, etc.). Falta decisión de diseño sobre ubicación |
| 4 | **AI genera rutas de imagen inválidas** | Media | La AI genera paths como `/images/service-homepage.webp` que no existen. Se filtró `service-homepage` pero podrían aparecer otros. Solución real: AI prompt debería solo usar imágenes que ya existen en R2 |
| 5 | **Imágenes de servicios en homepage** | Media | El grid de servicios usa `s.hero_image` de la tabla `services`. Si el servicio no tiene imagen en D1, usa `/images/hero-home.webp` como fallback. Varias podrían ser placeholders |
| 6 | **`renderer.ts` legacy sin usar** | Baja | `src/ssr/renderer.ts` existe pero no se importa en `src/index.ts`. Solo `data.ts` importa tipos de él. Se puede eliminar |
| 7 | **Admin UI: favicon se pierde al rebuild** | Baja | Cada `npm run build` + copy sobrescribe `public/admin/index.html` sin el favicon. Se agrega manualmente con sed. Debería estar en el template de Vite |
| 8 | **`content_json` de static pages (no homepage)** | Media | Las páginas estáticas (nosotros, contacto, etc.) tienen `content_json` pero no se lee para renderizar el sitio. Solo se leen las columnas planas. Para editar el contenido de esas páginas desde el CMS, falta conectar el override |
| 9 | **SEO scoring en backend (`/api/cms/regenerate`)** | Baja | El backend devuelve `qualityPipeline.score` pero no se usa en el UI. Solo se muestra el score del frontend (`calcBackendScore` y `SEOPanel`) |

---

## 12. Flujo de Deploy

```bash
# 1. Build admin UI
cd guardman-admin-ui && npm run build

# 2. Copiar al public (limpio)
cd .. 
rm -rf public/admin/assets
cp -r guardman-admin-ui/dist/assets public/admin/assets
cp guardman-admin-ui/dist/index.html public/admin/index.html

# 3. Agregar favicon al admin (se pierde en el copy)
sed -i 's|<title>GuardMan Admin</title>|<title>GuardMan Admin</title>\n  <link rel="icon" type="image/svg+xml" href="/favicon.svg">|' public/admin/index.html

# 4. Deploy Worker
npx wrangler deploy
```

Todo en un único `wrangler deploy`. Sin CI/CD. Sin GitHub. Directo a Cloudflare.

---

## 13. Verificación Final

```
Todas las rutas públicas: 200 ✓
Formularios POST: → D1 leads → /gracias 302 ✓
CMS Editor Homepage: load/save/regenerate ✓
SEO Score: coherente con contenido ✓
Sitemap: incluye /gracias ✓
Favicon: .svg + .ico ✓
Admin UI: favicon ✓
CMS → Sitio Público: textos se reflejan ✓
CMS → Sitio Público: imágenes dinámicas (Guard Pod, Ajax) ✓
```
