# GuardMan Admin — Visión: Media Editor (v3.0 — Final)
## De "Biblioteca de Medios" a "Editor de Medios" potenciado por fal.ai
### Inspirado en la metodología fullstack-seo + validado por auditoría técnica

**Fecha:** 2026-05-09 (v3.0 final, post-auditoría)  
**Estado:** Visión validada y consensuada  
**Siguiente paso:** Plan de implementación → `docs/PLAN-MEDIA-EDITOR.md`

---

## 0. FILOSOFÍA: LA TÉCNICA DE LAS 3 CAPAS

La metodología fullstack-seo demostró que la clave para imágenes de marca consistentes con IA no está en prompts sueltos, sino en un **sistema de 3 capas** que se encadenan:

```
┌─────────────────────────────────────────────┐
│ CAPA 1: STYLE GUIDE (system prompt fijo)    │  ← Se inyecta SIEMPRE, automático
│ Cámara, lente, iluminación, paleta, reglas  │
├─────────────────────────────────────────────┤
│ CAPA 2: CATEGORÍA (prompt predefinido)      │  ← Admin selecciona de dropdown
│ Tipo de shot, encuadre, escena específica   │     EDITABLE desde el admin (KV)
├─────────────────────────────────────────────┤
│ CAPA 3: USUARIO (texto libre opcional)      │  ← Admin personaliza
│ Detalles extra, ajustes, contexto adicional │
└─────────────────────────────────────────────┘
```

**Ejemplo concreto:**
- Capa 1 (automática): "Canon EOS R5, 24-70mm f/2.8, golden hour, navy tones (#1A2744), Santiago, photorealistic"
- Capa 2 (seleccionada): "Professional security guard in GuardMan uniform at office building entrance, OS-10 badge"
- Capa 3 (usuario): "con edificio Costanera Center de fondo"

El prompt final enviado a fal.ai: `[CAPA 1] [CAPA 2] [CAPA 3]`

---

## 1. ANÁLISIS DEL ESTADO ACTUAL

### 1.1 Qué ya existe

| Componente | Archivo | Líneas | Funcionalidad |
|-----------|---------|--------|--------------|
| Cliente fal.ai | `guardman-admin-ui/src/lib/falai.ts` | 164 | `generateImage()`, `transformImage()`, `uploadRemoteImage()`, key en localStorage |
| ImagePicker | `src/components/Media/ImagePicker.tsx` | 315 | Modal con tabs: Imágenes / Videos / Generar IA |
| MediaLibrary | `src/components/Media/MediaLibrary.tsx` | 770 | Panel 3-columnas con tabs Info/IA/SEO, asignaciones |
| LiteYouTube | `src/components/Media/LiteYouTube.tsx` | 85 | YouTube embed lazy-load |
| API Backend | `src/api/routes/media.ts` | 458 | CRUD media_library, media_entities, upload, YouTube |

### 1.2 Capacidades actuales fal.ai

```typescript
// Implementado:
generateImage(prompt, model)       // Text → Image (Flux Schnell / Flux Pro)
transformImage(prompt, url, model) // Image → Image
uploadRemoteImage(url, name, cat)  // Download from fal.ai → upload to R2 (browser-side)
```

### 1.3 Carencias

| Carencia | Impacto | Severidad |
|----------|---------|-----------|
| API key en localStorage | Inseguro, expuesto al cliente | 🔴 |
| Proxy síncrono inexistente | Flux Pro (30s) mata el Worker por timeout | 🔴 |
| 3 componentes separados con lógica duplicada | Mantenimiento difícil, UX inconsistente | 🟡 |
| Sin system prompt de marca | Imágenes sin coherencia visual | 🟡 |
| Sin prompts predefinidos por categoría | Cada generación arranca de cero | 🟡 |
| Sin variaciones por lote | No se puede comparar opciones | 🟡 |
| Sin imágenes reales de Guard Pod | Páginas usan fallback genérico | 🟡 |

---

## 2. INVESTIGACIÓN: CAPACIDADES DE fal.ai

### 2.1 Modelos priorizados para GuardMan

| Modelo | Endpoint | Uso | Tiempo | Costo aprox/imagen |
|--------|----------|-----|--------|-------------------|
| **Flux Schnell** | `fal-ai/flux/schnell` | Text→Image rápido, borradores | 2-5s | ~$0.001 |
| **Flux Pro v2** | `fal-ai/flux-pro/v2` | Text→Image calidad final | 10-30s | ~$0.004 |
| **Flux Pro img2img** | `fal-ai/flux-pro/v2/image-to-image` | Variaciones de imagen | 15-40s | ~$0.005 |
| **Flux.1 Fill** | `fal-ai/flux-lora/fill` | Inpainting (reemplazar área) | 10-20s | ~$0.003 |
| **Real-ESRGAN** | `fal-ai/real-esrgan` | Upscaling 2x/4x | 3-8s | ~$0.001 |
| **BiRefNet** | `fal-ai/birefnet` | Background removal | 2-5s | ~$0.001 |

### 2.2 Autenticación

```
Authorization: Key {FAL_API_KEY}
Content-Type: application/json
```

**Decisión:** `FAL_API_KEY` vive en `wrangler.jsonc` vars (secrets). El Worker proxy a fal.ai — el frontend **nunca** ve la key.

### 2.3 Rate limits y costos

| Plan | Requests/día | Costo mensual | Recomendado para |
|------|-------------|---------------|-----------------|
| Gratuito | 10 | $0 | Pruebas iniciales |
| Hobby | 250 | $10/mes | Desarrollo + contenido inicial |
| **Pro** | **1000** | **$30/mes** | **Producción con batch generation** |

**Estimación de costos para contenido completo del sitio (~120 imágenes):**
- Flux Schnell: ~$0.12 (borradores)
- Flux Pro: ~$0.48 (imágenes finales)
- Con iteraciones (3 rounds por prompt): ~$1.50 total
- Plan recomendado: **Hobby** ($10/mes) para uso normal. Subir a Pro si se hace batch pesado.

---

## 3. ARQUITECTURA: PATRÓN ASÍNCRONO (showstopper resuelto)

### 3.1 El problema

Workers tiene 30s hard limit (15s en plan free). Flux Pro puede tardar 30s+. Un proxy síncrono `POST → esperar 30s → responder` **muere con 504**.

### 3.2 La solución

```
┌──────────┐   POST /api/media/fal/generate   ┌─────────┐   POST fal.run (async)  ┌──────────┐
│  Admin   │ ────────────────────────────────▶ │ Worker  │ ──────────────────────▶ │ fal.ai   │
│ Browser  │ ◀──── { request_id, queued } ─── │         │ ◀─── { request_id } ─── │          │
│          │                                   │         │                          │          │
│          │   GET /status/:id (cada 2-3s)    │         │   GET /status/:id       │          │
│          │ ────────────────────────────────▶ │         │ ──────────────────────▶ │          │
│          │ ◀──── { status, images? } ────── │         │ ◀─── { COMPLETED } ──── │          │
│          │                                   │         │                          │          │
│          │   POST /fal/save-to-r2            │         │                          │          │
│          │ ────────────────────────────────▶ │         │   download + R2 upload  │          │
│          │ ◀──── { id, key, url } ───────── │         │                          │          │
└──────────┘                                   └─────────┘                          └──────────┘
```

**Flujo:**
1. Admin hace click "Generar" → `POST /api/media/fal/generate { prompt, model, ... }`
2. Worker envía la request a fal.ai y recibe `{ request_id }` inmediatamente (<1s)
3. Worker guarda `request_id` en KV con TTL 10min y devuelve `{ request_id, status: "queued" }`
4. Frontend hace **polling cada 3s** a `GET /api/media/fal/status/:request_id`
5. Worker consulta status a fal.ai → devuelve `{ status: "processing" | "completed", images?: [...] }`
6. Cuando `completed`, el admin ve la preview
7. Admin click "Guardar" → `POST /api/media/fal/save-to-r2 { request_id, filename, category, ... }`
8. Worker descarga la imagen desde fal.ai y la sube a R2 → registra en D1 → devuelve `{ id, key, url }`

**KV schema:**
```
Key: fal:req:{request_id}
Value: { falRequestId, status, model, prompt, created_at, images?: [...] }
TTL: 600 (10 minutos)
```

---

## 4. GUARDMAN IMAGE STYLE GUIDE

> Capa 1 fija. Se inyecta automáticamente en toda generación. Vive en `src/services/image-prompts.ts`.

### 4.1 Cámara & Lente

- **Cámara:** Canon EOS R5 (full-frame mirrorless)
- **Lente:** Canon RF 24-70mm f/2.8L IS USM

**Focal length por tipo de shot:**

| Shot Type | Focal Length | Uso |
|-----------|-------------|-----|
| Wide / Hero | 24-28mm | Fachadas, panorámicas Santiago, Guard Pod en sitio |
| Medio / Servicio | 35-50mm | Guardias en puesto, equipos CCTV, instalaciones |
| Close-up / Producto | 60-70mm | Detalle de equipos Ajax, badge OS-10, tecnología |
| Retrato / Staff | 50-70mm | Fotos de equipo, guardias (sin rostros reconocibles) |

### 4.2 Exposición

- **Hero/Wide:** f/4 - f/5.6 (escena completa en foco), ISO 100-200
- **Detalle:** f/2.8 (shallow depth of field), ISO 100-400
- **Interiores:** f/2.8 - f/4, ISO 400-800
- **Velocidad:** 1/250+ para congelar movimiento

### 4.3 Iluminación

- **Principal:** Golden hour (amanecer/atardecer), sombras suaves direccionales
- **Tono:** Cálido (balance de blancos ~5600-6000K)
- **Alternativa:** Bright overcast para shots de detalle (luz difusa uniforme)
- **Nocturno:** Blue hour + luces cálidas de edificios (CCTV, monitoreo 24/7, Guard Pod nocturno)
- **EVITAR:** Sol directo de mediodía, flash artificial, HDR exagerado

### 4.4 Paleta de Colores

| Color | Uso | Hex |
|-------|-----|-----|
| Navy primary | Uniformes, branding, fondos corporativos | `#1A2744` |
| Navy light | Acentos, elementos secundarios | `#1A3A5C` |
| White | Espacios negativos, textos sobre navy | `#FFFFFF` |
| Steel blue | Elementos UI, iconos, badges | `#5F7A96` |
| Warm gray | Fondos neutros, superficies | `#6C757D` |
| Accent blue | CTAs, links, elementos interactivos | `#3B82F6` |
| Success green | Checks, certificaciones, badges OS-10 | `#10B981` |

**Tratamiento:** Natural, true-to-life. Navy profundo pero no negro. Verdes moderados (Santiago semiárido). Cielo chileno claro pero no sobresaturado.

### 4.5 Mood & Atmósfera

- **Profesional:** Calidad portfolio, no snapshots casuales
- **Confiable:** Transmitir seguridad, experiencia, seriedad
- **Chileno:** Entorno reconocible de Santiago (edificios, calles, luz)
- **Aspiracional:** Seguridad de alto nivel, tecnología de punta
- **Auténtico:** Nada que parezca montado, stock photo, o excesivamente perfecto

### 4.6 Setting & Entorno

- **Ubicación:** Santiago de Chile, Región Metropolitana
- **Entornos:** Oficinas corporativas (Providencia, Las Condes), condominios residenciales, sitios industriales/construcción, calles urbanas
- **Arquitectura:** Chilena contemporánea — edificios vidriados, condominios con accesos controlados, barrios residenciales
- **Cordillera:** Los Andes como fondo en wide shots cuando sea natural (no forzado)
- **Clima:** Mayormente soleado (~280 días/año). Algunos shots con cielo parcialmente nublado para variedad
- **Vegetación:** Mediterránea semiárida — palmeras, plátanos orientales, aromos, pasto moderado

### 4.7 Composición

1. **Rule of thirds:** Puntos focales en intersecciones
2. **Leading lines:** Caminos, pasillos, rejas, líneas arquitectónicas
3. **Foreground interest:** Elemento en primer plano para profundidad
4. **Horizonte:** Tercio inferior (énfasis edificios/cielo) o superior (énfasis terreno/instalación)
5. **Negative space:** Dejar respirar. No saturar.
6. **Eye level:** Altura de ojo humano (1.6m). Evitar ángulos extremos.

### 4.8 Lo que NUNCA debe aparecer

- **Rostros reconocibles:** Personas de espaldas, perfil lejano, o con DoF que difumine el rostro
- **Armas visibles:** Guardias en Chile no portan armas. Evitar cualquier representación de armamento.
- **Look "AI obvious":** Artefactos, manos deformes, texto ilegible, geometría imposible
- **Aspecto stock photo:** Escenas genéricas, sonrisas exageradas, iluminación de estudio
- **Brands de terceros:** Sin logos de otras empresas, marcas de vehículos
- **Vegetación tropical:** Santiago es clima mediterráneo semiárido
- **Textos o watermarks:** Imágenes limpias
- **Colores neón:** Sin saturaciones artificiales, sin HDR exagerado
- **Postura militar/agresiva:** Guardias profesionales y accesibles, no intimidantes
- **Desorden:** Sin cables sueltos, basura, equipos sucios

---

## 5. SISTEMA DE 3 CAPAS: IMPLEMENTACIÓN

### 5.1 Capa 1: System Prompt (fijo, automático)

```typescript
// src/services/image-prompts.ts
export const GUARDMAN_SYSTEM_PROMPT = `STYLE GUIDE — Follow these rules exactly:

CAMERA: Canon EOS R5 full-frame mirrorless, RF 24-70mm f/2.8L lens.
LIGHTING: Natural golden hour light, soft directional shadows, warm tone (5600-6000K). No harsh midday sun. No artificial flash.
COLOR PALETTE: Navy blue #1A2744, white #FFFFFF, steel blue #5F7A96, warm gray #6C757D. Colors must be natural, not oversaturated.
LOCATION: Santiago de Chile. Corporate buildings, residential condominiums, urban streets. Andes mountains on horizon when natural.
MOOD: Professional, trustworthy, authentic. Photorealistic portfolio quality. Not stock photo, not overly perfect.
COMPOSITION: Rule of thirds, leading lines, eye-level (1.6m), negative space. No extreme angles.
AVOID: Recognizable faces, weapons, AI artifacts, third-party logos, tropical vegetation, neon colors, military postures, messy cables, text overlays, watermarks.
OUTPUT: Photorealistic, high resolution, WebP format, no text, no watermarks.`;
```

### 5.2 Capa 2: Prompts editables (KV-backed)

Los prompts de categoría se almacenan en KV (no hardcodeados) para permitir iteración sin deploy. El admin puede editarlos desde la UI.

**API:**
```
GET  /api/media/prompts → devuelve todos los prompts con categorías
PUT  /api/media/prompts → actualiza un prompt específico { id, prompt, negative, ... }
```

**Valores iniciales (seed):**

```yaml
guardpod-hero:
  label: "Guard Pod V1 — Hero"
  resolution: 2K
  aspect_ratio: 16:9
  prompt: >
    Wide establishing shot of a Guard Pod V1 autonomous security tower
    deployed at a construction site entrance in Santiago Chile.
    White and navy blue tower with solar panels on top, PTZ camera dome,
    and 4G antenna. Modern, sleek, imposing presence.
    Late afternoon golden hour, clear blue sky, Andes mountains faintly visible.
    The tower is the hero subject, filling 60% of frame.
    Clean environment, professional installation.
  negative: >
    people, dark, rain, messy site, graffiti, cartoon, 3D render

guardpod-condominio:
  label: "Guard Pod en Condominio"
  resolution: 1K
  aspect_ratio: 4:3
  prompt: >
    Medium shot of a Guard Pod V1 installed at the entrance gate of a
    modern residential condominium in Las Condes Santiago.
    Security barrier gate in frame, well-maintained gardens.
    The tower stands next to the guard booth, complementing it.
    Natural afternoon light, professional suburban atmosphere.
  negative: >
    people visible, night, empty scene, cartoon, oversaturated

ajax-hero:
  label: "Ajax Systems Hub — Hero Producto"
  resolution: 2K
  aspect_ratio: 16:9
  prompt: >
    Close-up product photography of an Ajax Systems Hub 2 central alarm panel
    installed on a clean modern wall in a Santiago office.
    Next to it: Ajax MotionCam detector, DoorProtect sensor, and KeyPad.
    Clean white wall background, subtle navy accent (#1A2744) from GuardMan branding.
    Professional lighting, shallow depth of field isolating the products.
  negative: >
    messy desk, visible cables, old building, dark room, people

ajax-app:
  label: "Ajax App — Lifestyle"
  resolution: 1K
  aspect_ratio: 4:3
  prompt: >
    Overhead flat lay: a modern smartphone showing the Ajax Security app
    dashboard with arm/disarm controls. Next to phone: Ajax fob keychain,
    coffee cup, and a GuardMan business card with navy blue branding.
    Warm morning light from window, clean wooden desk surface.
  negative: >
    any text other than Ajax UI, messy, dark, people

servicio-guardia:
  label: "Guardia de Seguridad OS-10"
  resolution: 1K
  aspect_ratio: 4:3
  prompt: >
    Professional security guard in navy blue GuardMan uniform standing
    at the entrance lobby of a corporate office building in Santiago Chile.
    OS-10 certification badge visible on chest.
    Guard seen from 45-degree angle, looking toward entrance.
    Clean modern lobby, glass doors, corporate atmosphere.
    Natural diffuse daylight, welcoming but professional mood.
  negative: >
    visible face details, weapons, military posture, dark, empty lobby

servicio-cctv:
  label: "CCTV — Instalación Profesional"
  resolution: 1K
  aspect_ratio: 4:3
  prompt: >
    Modern dome CCTV camera professionally installed on the ceiling
    of a corporate hallway in Santiago.
    Clean cable management, blue indicator light glowing softly.
    Clean white ceiling, modern office corridor.
    Professional security installation aesthetic.
  negative: >
    messy cables, dirty ceiling, outdated camera, people, dark

servicio-accesos:
  label: "Control de Accesos"
  resolution: 1K
  aspect_ratio: 4:3
  prompt: >
    Modern access control turnstile gate at the entrance of a Santiago
    office building. Card reader with blue LED, sleek stainless steel finish.
    Clean lobby background, professional atmosphere.
    Natural daylight through glass entrance.
    Security-focused but welcoming.
  negative: >
    people visible faces, dirty glass, old equipment, dark

nosotros-oficina:
  label: "Oficina GuardMan — Fachada"
  resolution: 2K
  aspect_ratio: 16:9
  prompt: >
    Exterior wide shot of the GuardMan Chile office building in
    Providencia Santiago. Modern 3-story building with navy blue
    GuardMan signage. Professional landscaping around entrance.
    Clear blue sky, golden hour side lighting.
    OS-10 certification plaque visible near entrance.
  negative: >
    people visible faces, neighboring buildings prominent, rain, dark

cobertura-santiago:
  label: "Santiago — Cobertura Urbana"
  resolution: 1K
  aspect_ratio: 4:3
  prompt: >
    Aerial-style wide view of a Santiago residential neighborhood
    (Providencia area) with modern apartment buildings and tree-lined streets.
    Clear blue sky, distant Andes mountains on the eastern horizon.
    Professional urban photography style, communicating comprehensive coverage.
  negative: >
    smog, night, identifiable addresses, people, text
```

### 5.3 Capa 3: Input libre del usuario

Textarea donde el admin agrega detalles. Se concatena al final del prompt compuesto.

---

## 6. VISIÓN: MEDIA EDITOR UNIFICADO

### 6.1 Layout

```
┌──────────────────────────────────────────────────────────────┐
│ 🖼 Media Editor                                               │
│                                                              │
│ ┌──────────┐  ┌──────────────────┐  ┌─────────────────────┐ │
│ │  GRID    │  │    PREVIEW       │  │   AI TOOLS          │ │
│ │          │  │                  │  │                      │ │
│ │ [img][ ] │  │ ┌──────────────┐ │  │ 🎨 GENERAR          │ │
│ │ [img][ ] │  │ │              │ │  │ ┌─────────────────┐ │ │
│ │ [img][ ] │  │ │   Preview    │ │  │ │ Categoría  [▼] │ │ │
│ │          │  │ │   Image      │ │  │ │ Prompt     [▼] │ │ │
│ │ Search   │  │ │              │ │  │ │ Texto libre [ ] │ │ │
│ │ Filter   │  │ └──────────────┘ │  │ │ Modelo      [▼] │ │ │
│ │ Upload   │  │                  │  │ │ Resolución  [▼] │ │ │
│ │ YT Link  │  │ [Info] [IA] [SEO]│  │ │ [🎨 Generar]    │ │ │
│ │          │  │                  │  │ └─────────────────┘ │ │
│ │          │  │ Lightbox: 4 vars │  │                      │ │
│ │          │  │ Slider: antes/   │  │ 🔄 VARIAR (I→I)     │ │
│ │          │  │ después          │  │ 🧹 Remover fondo    │ │
│ │          │  │                  │  │ ⬆ Mejorar calidad   │ │
│ └──────────┘  └──────────────────┘  │ 📋 Batch generate   │ │
│                                     │ 📜 Historial (20)   │ │
│                                     └─────────────────────┘ │
└──────────────────────────────────────────────────────────────┘
```

### 6.2 Flujos principales

#### Flujo A: Generar con sistema de 3 capas
```
1. Admin abre Media Editor → panel "AI Tools" → tab "Generar"
2. Capa 1 (automática): system prompt se inyecta sin mostrarse
3. Capa 2: Selecciona categoría → dropdown filtra prompts disponibles
4. Capa 3: Texto libre opcional
5. Preview del prompt compuesto en área colapsable (transparencia)
6. Selecciona modelo y resolución
7. Click "Generar" → spinner con "Iniciando..." → "Generando... (X segundos)"
8. Preview aparece cuando fal.ai completa
9. Botones: "Usar y subir" | "Generar variantes" | "Regenerar con mismo prompt"
```

#### Flujo B: Batch de una categoría
```
1. Panel AI Tools → tab "Batch"
2. Seleccionar categoría: "Servicios" | "Guard Pod" | "Ajax" | "Ubicaciones"
3. Click "Generar todas" → se encolan en frontend con concurrency limit (3 a la vez)
4. Progress bar: "5/8 completados"
5. Grid de resultados con previews
6. Admin marca checkboxes en los ganadores → "Subir seleccionados"
7. Worker descarga y guarda cada imagen en R2 (server-side)
```

#### Flujo C: Editar imagen existente
```
1. Admin selecciona imagen del grid → se activa panel IA sobre imagen
2. Herramientas disponibles:
   - "Generar variante" → Flux img2img, strength slider 0.1-0.9
   - "Remover fondo" → BiRefNet
   - "Mejorar calidad" → Real-ESRGAN 2x
3. Slider antes/después para comparar con original
```

### 6.3 UI Components

| Componente | Descripción |
|-----------|-------------|
| Lightbox comparador | Grid 2×2 para ver 4 variantes lado a lado en grande, click para seleccionar |
| Slider antes/después | Barra vertical arrastrable que revela imagen original vs generada |
| Prompt preview | Área colapsable mostrando el prompt compuesto final antes de enviar |
| Historial de generaciones | Últimas 20 generaciones con thumbnail + prompt + timestamp (KV, no R2) |
| Progress tracker | Barra de progreso para batch con "X/Y completados" |

---

## 7. ENDPOINTS API

### 7.1 Nuevos endpoints

```
POST /api/media/fal/generate
  Auth: Bearer {session_token}
  Body: { prompt, model, aspect_ratio, num_images, seed? }
  Response: { request_id, status: "queued" }

GET /api/media/fal/status/:request_id
  Auth: Bearer {session_token}
  Response: { status: "queued" | "processing" | "completed" | "failed",
              images?: [{ url, width, height }],
              error?: string }

POST /api/media/fal/save-to-r2
  Auth: Bearer {session_token}
  Body: { request_id, image_index, filename, category, alt_text, tags }
  Response: { id, key, url }

GET /api/media/prompts
  Auth: Bearer {session_token}
  Response: { categories: [...], prompts: [{ id, label, category, resolution, aspect_ratio, prompt, negative }] }

PUT /api/media/prompts
  Auth: Bearer {session_token}
  Body: { id, prompt?, negative?, label?, resolution?, aspect_ratio? }
  Response: { ok: true }
```

### 7.2 Endpoints existentes (conservados)

```
GET    /api/media              → Listar medios (con filtros)
POST   /api/media/upload       → Subir archivo a R2
GET    /api/media/:id          → Detalle de un medio
PUT    /api/media/:id          → Actualizar metadata SEO
DELETE /api/media/:id          → Eliminar medio
POST   /api/media/:id/assign   → Asignar a entidad
POST   /api/media/:id/unassign → Desasignar
POST   /api/media/youtube      → Agregar YouTube
```

---

## 8. MODELO DE DATOS

### 8.1 Nuevas columnas en media_library

```sql
ALTER TABLE media_library ADD COLUMN prompt_used TEXT;
ALTER TABLE media_library ADD COLUMN generation_model TEXT;
ALTER TABLE media_library ADD COLUMN generation_seed INTEGER;
ALTER TABLE media_library ADD COLUMN generation_time_ms INTEGER;
ALTER TABLE media_library ADD COLUMN fal_request_id TEXT;
```

### 8.2 KV schema

```
Key: fal:req:{request_id}
Value: {
  falRequestId: string,
  status: "queued" | "processing" | "completed" | "failed",
  model: string,
  prompt: string,
  images?: [{ url: string, width: number, height: number }],
  error?: string,
  created_at: number
}
TTL: 600
```

```
Key: prompts:{category}
Value: [{ id, label, resolution, aspect_ratio, prompt, negative }]
No TTL (persistente)
```

### 8.3 Feature flag

```
Key: feature:media-editor-v3
Value: { enabled: true }
No TTL
```

El `Sidebar.tsx` y `App.tsx` leen este flag. Si `enabled: false`, cargan los componentes viejos.

---

## 9. ROADMAP DE IMPLEMENTACIÓN

### Fase 0: Async Pattern + Seguridad (1 sesión) 🔴
**Objetivo:** Resolver el showstopper del Worker timeout y sentar la base para todo.

| # | Tarea | Descripción | Dificultad |
|---|-------|-------------|------------|
| 0.1 | `FAL_API_KEY` en secrets | Agregar `FAL_API_KEY` a `wrangler.jsonc` vars | Baja |
| 0.2 | `POST /api/media/fal/generate` | Endpoint async: inicia request a fal.ai, guarda en KV, responde con `request_id` | Media |
| 0.3 | `GET /api/media/fal/status/:request_id` | Polling: consulta status a fal.ai via KV + fal.run, devuelve imágenes si completó | Media |
| 0.4 | `POST /api/media/fal/save-to-r2` | Worker descarga imagen de fal.ai y la sube a R2, registra en D1 | Media |
| 0.5 | Auth middleware en `/api/media/fal/*` | Verificar `Bearer {session_token}` en cada endpoint nuevo | Baja |
| 0.6 | Actualizar `falai.ts` | Eliminar key mgmt (localStorage). Nuevas funciones: `generateAsync()`, `pollStatus()`, `saveToR2()` | Media |
| 0.7 | Manejo de errores fal.ai | Safety checker rechazos, modelo down, timeout → mensajes amigables en español | Baja |
| 0.8 | Test end-to-end | Generar 1 imagen con Flux Schnell desde el browser via Worker proxy | Baja |

### Fase 1: Infraestructura + Style Guide (1 sesión)
**Objetivo:** Sistema de prompts, metadata D1, configuración de marca.

| # | Tarea | Descripción | Dificultad |
|---|-------|-------------|------------|
| 1.1 | `src/services/image-prompts.ts` | System prompt fijo + seed de prompts predefinidos | Baja |
| 1.2 | `GET /api/media/prompts` | Leer prompts de KV (con fallback al seed de código) | Baja |
| 1.3 | `PUT /api/media/prompts` | Actualizar un prompt en KV | Baja |
| 1.4 | Nuevas columnas D1 | `prompt_used`, `generation_model`, `generation_seed`, `generation_time_ms`, `fal_request_id` en `media_library` | Baja |
| 1.5 | `enable_safety_checker: true` | Activar safety checker + error "NSFW" → mensaje amigable "La imagen fue rechazada por el filtro de seguridad" | Baja |
| 1.6 | Feature flag KV | `feature:media-editor-v3: { enabled: false }` inicialmente. Los componentes viejos se mantienen. | Baja |

### Fase 2: MediaEditor Core (2 sesiones)
**Objetivo:** Construir el componente unificado y activarlo con feature flag.

| # | Tarea | Descripción | Dificultad |
|---|-------|-------------|------------|
| 2.1 | Layout 3-paneles | Crear `MediaEditor.tsx` con estructura base: grid lado izquierdo, preview centro, AI tools derecha | Alta |
| 2.2 | Grid + filtros + upload | Migrar lógica de MediaLibrary (categorías, media filter, search, upload, YouTube) | Media |
| 2.3 | Preview + tabs Info/SEO | Migrar preview de imagen + metadata + SEO scoring | Media |
| 2.4 | Panel AI: 3-capas | Dropdown categoría → dropdown prompt → texto libre → preview prompt → generar | Media |
| 2.5 | Panel AI: herramientas | Variante (img2img + strength slider), upscale (2x/4x), remove background | Media |
| 2.6 | Lightbox comparador | Grid 2×2 para 4 variantes, click para seleccionar | Media |
| 2.7 | Slider antes/después | Barra arrastrable para comparar original vs generada | Media |
| 2.8 | Historial de generaciones | Últimas 20 en estado local (useRef), thumbnails + prompt + timestamp | Baja |
| 2.9 | Actualizar consumidores | CMSPage.tsx, ImagePicker referencias → usar nuevo MediaEditor en modo "picker" | Media |
| 2.10 | Activar feature flag | `feature:media-editor-v3: { enabled: true }` → monitorear que funciona | Baja |
| 2.11 | Eliminar legacy | ImagePicker.tsx, MediaLibrary.tsx, LiteYouTube.tsx (solo si el flag está enabled 24h sin errores) | Baja |

### Fase 3: Batch + Contenido (1 sesión)
**Objetivo:** Batch generation y población de imágenes reales.

| # | Tarea | Descripción | Dificultad |
|---|-------|-------------|------------|
| 3.1 | Batch UI | Grid de checkboxes por categoría, "Generar seleccionados", concurrency 3, progress bar | Media |
| 3.2 | Batch backend | El frontend encola requests con Promise.all limitado a 3 concurrentes | Baja |
| 3.3 | Generar imágenes Guard Pod | Hero, condominio, obra, nocturno (~4 imágenes) | Baja |
| 3.4 | Generar imágenes Ajax | Hub producto, sensores, app, instalación (~4 imágenes) | Baja |
| 3.5 | Generar imágenes Servicios | Guardia, CCTV, accesos, escoltas, monitoreo, eventos, industrial, auditoría (~8 imágenes) | Baja |
| 3.6 | Generar imagen Nosotros | Fachada oficina | Baja |
| 3.7 | Asignar a entities D1 | `media_entities` con service_slug, usage "hero" o "gallery" | Baja |
| 3.8 | Actualizar content_json | Cambiar hero_image en D1 para servicios que usen fallback | Baja |

---

## 10. DECISIONES TOMADAS

| # | Decisión | Razón |
|---|----------|-------|
| 1 | **Solo herramientas IA, sin canvas/brush** | Complejidad innecesaria para el MVP |
| 2 | **Unificar todo en MediaEditor** | Un solo componente, una sola experiencia |
| 3 | **FAL_API_KEY en Worker secrets** | Seguridad — la key nunca llega al browser |
| 4 | **System prompt (Capa 1) fijo en código** | Es estable, define la marca |
| 5 | **Prompts (Capa 2) editables en KV** | Iteración sin deploy. El admin ajusta prompts empíricamente |
| 6 | **Patrón asíncrono con polling** | Resuelve el timeout del Worker. Simple, no requiere webhooks |
| 7 | **Server-side R2 upload** | Más eficiente que browser download + re-upload |
| 8 | **Feature flag para rollback** | Seguridad: mantener componentes viejos hasta validar |
| 9 | **Safety checker activado** | Negocio de seguridad → no arriesgar contenido inapropiado |
| 10 | **KV para estado de requests fal.ai** | TTL 10min, no contamina D1 con datos efímeros |
| 11 | **Modelos priorizados:** Flux Pro, Schnell, Fill, ESRGAN, BiRefNet | Cobertura completa de necesidades |
| 12 | **Metodología 3-capas** (style guide → categoría → usuario) | Coherencia visual garantizada |
| 13 | **Worker descarga a R2 en vez de browser** | Evita doble tránsito de datos, no depende de conexión del usuario |
| 14 | **Seed parameter** | Reproducibilidad: mismo prompt + mismo seed = misma imagen |
| 15 | **Plan Hobby ($10/mes) como mínimo viable** | 250 req/día cubren batch inicial. Subir a Pro ($30/mes) si se necesita |
