# GuardMan Admin — Plan de Estabilización y Despliegue
**Fecha:** 2026-05-09  
**Base:** Estado actual del código local (post-sesión 2026-05-08, sin commitear)  
**Estado SITE_URL:** `guardman.cl` NO activo → usar `guardman.oficinadesarrollo33.workers.dev`  
**Blog:** ELIMINAR completamente del sitio público (no del backend CMS/API)

---

## CONTEXTO DEL PROYECTO

### Arquitectura
```
Un solo Cloudflare Worker (guardman) que sirve:
├── /admin/*        → React SPA (Vite build copiado a public/admin/)
├── /api/*          → REST API (CMS CRUD, IA, media, leads)
├── /images/*       → R2 bucket (guardman-images)
├── /styles/*       → Workers Assets (site.css, dark.css)
├── /scripts/*      → Workers Assets (main.js)
├── /fonts/*        → Workers Assets (Inter TTF)
└── /*              → SSR dinámico (20+ rutas HTML)
```

### Stack
- **Runtime:** Cloudflare Workers (TypeScript)
- **DB:** D1 (`guardman-seo`, 65 tablas)
- **Storage:** R2 (`guardman-images`)
- **Cache:** KV (`CACHE` namespace)
- **AI:** Cloudflare AI Gateway + Minimax API
- **Frontend Admin:** React 19 + Vite + TailwindCSS

### Dominio de producción
- **ACTUAL:** `https://guardman.oficinadesarrollo33.workers.dev`
- **FUTURO:** `https://guardman.cl` (no activo aún)
- **Decisión:** SITE_URL debe ser configurable por variable de entorno

### Archivos clave del Worker SSR
| Archivo | Líneas | Rol |
|---------|--------|-----|
| `src/index.ts` | 735 | Router principal + formularios + sitemap + builders inline (gracias, blog, 404, 500) |
| `src/ssr/site-renderer.ts` | 1112 | Componentes HTML: hdr, ftr, hero, secciones, builders de páginas estáticas |
| `src/ssr/site-data.ts` | 423 | Fetchers D1 → SiteData para cada tipo de página |
| `src/ssr/*-html.ts` | 7 archivos | HTML canónico de fallback para páginas estáticas |
| `src/api/routes/cms.ts` | 720 | API CRUD del CMS: content, save, regenerate, media, blog |
| `src/services/ai.ts` | 417 | Generación de contenido con IA |
| `src/services/cache.ts` | 80 | KV cache get/set/invalidate/flush |
| `src/types/index.ts` | 211 | Interfaces Env, ContentJob, etc. |
| `public/styles/site.css` | 318 | CSS light theme completo |
| `public/styles/dark.css` | 78 | CSS dark theme (Guard Pod + Ajax) |
| `public/scripts/main.js` | 41 | Mobile menu toggle + form tracking |

### Archivos del Admin UI
| Archivo | Rol |
|---------|-----|
| `guardman-admin-ui/src/components/CMS/CMSPage.tsx` | Editor CMS principal (1607 líneas) |
| `guardman-admin-ui/src/components/CMS/SEOPanel.tsx` | Panel SEO lateral |
| `guardman-admin-ui/src/components/Media/ImagePicker.tsx` | Selector de imágenes R2 |
| `guardman-admin-ui/src/components/Media/MediaLibrary.tsx` | Biblioteca de medios |
| `guardman-admin-ui/vite.config.ts` | Build config (base: '/admin/') |

### Rutas SSR del sitio público (20+)
| Ruta | Builder | Tipo |
|------|---------|------|
| `/` | `buildHomepage()` | Homepage con CMS override |
| `/servicios` | `buildHubPage()` | Hub con cards |
| `/servicios/{slug}` | `buildDetailPage()` | Detalle servicio |
| `/servicios/{svc}/{loc}` | `buildDetailPage()` | Combo servicio+ubicación |
| `/ubicaciones` | `buildHubPage()` | Hub con mapa Leaflet |
| `/ubicaciones/{slug}` | `buildDetailPage()` | Detalle ubicación |
| `/sectores` | `buildHubPage()` | Hub con cards |
| `/sectores/{slug}` | `buildDetailPage()` | Detalle sector |
| `/nosotros` | `buildNosotrosPage()` | Página estática CMS-driven |
| `/guard-pod` | `buildGuardPodPage()` | Página dark CMS-driven |
| `/ajax-systems` | `buildAjaxPage()` | Página dark CMS-driven |
| `/contacto` | `buildContactoPage()` | Formulario + mapa CMS-driven |
| `/cotizacion` | `buildCotizacionPage()` | Formulario CMS-driven |
| `/gracias` | `buildGraciasPage()` | Post-form confirmación |
| `/privacidad` | `buildPrivacidadPage()` | Legal CMS-driven |
| `/terminos` | `buildTerminosPage()` | Legal CMS-driven |
| ~~`/blog`~~ | ~~`buildBlogListing()`~~ | **ELIMINAR** |
| ~~`/blog/{slug}`~~ | ~~`buildBlogPost()`~~ | **ELIMINAR** |
| `/sitemap.xml` | `handleSitemap()` | XML dinámico desde D1 |
| `/robots.txt` | inline | Texto estático |

---

## PROBLEMAS DETECTADOS

### 🔴 P0 — SITE_URL hardcodeado a dominio inactivo
- `site-renderer.ts` línea 8: `export const SITE_URL = 'https://guardman.cl';`
- Genera canonical URLs, OG tags y sitemap con dominio que no resuelve
- **Impacto:** SEO roto, sharing social roto, sitemap inválido

### 🔴 P0 — 36 archivos sin commitear, sin deploy
- El último commit es del 4-may, la sesión del 8-may dejó cambios sin deploy
- No hay punto de rollback en git

### 🟡 P1 — Blog debe eliminarse del sitio público
- Rutas `/blog` y `/blog/{slug}` no deben existir
- Sitemap incluye URLs de blog
- Nav header tiene link "Blog"
- Builders `buildBlogListing()`, `buildBlogPost()`, `fetchBlogPosts()`, `fetchBlogPost()` son código muerto
- Blog routes en CMS API pueden conservarse (uso interno futuro)

### 🟡 P1 — Cache KV stale post-deploy
- KV cache sobrevive a deploys del Worker
- Hay que flushear después de cada deploy

### 🟠 P2 — Regex frágiles en builders de contacto/cotización
- `buildContactoPage()` usa `.replace(/<h1>Cont[^<]*<\/h1>/)` para modificar HTML importado
- `buildCotizacionPage()` usa `.replace(/<section class="hero"[^>]*>[\s\S]*?<\/section>/)`
- Estos patrones son frágiles: cualquier cambio en el HTML importado los rompe

### 🟠 P2 — Admin UI build stale
- El admin en `public/admin/` tiene hash `main-BdYS6GLK.js` que puede no corresponder al código actual
- Hay que rebuildar y copiar

### 🟢 P3 — CSS_V hardcodeado
- `CSS_V = '1778255342'` es un valor fijo que nunca se actualiza automáticamente
- Funcional pero inútil como cache-bust real

---

## PLAN DE EJECUCIÓN

### FASE 1: SITE_URL configurable (P0)
**Objetivo:** Que SITE_URL use el dominio correcto sin hardcodear

#### T1.1 — Crear SITE_URL dinámico en site-renderer.ts

**Archivo:** `src/ssr/site-renderer.ts`

**Cambios:**
```typescript
// ANTES (línea 8):
export const SITE_URL = 'https://guardman.cl';

// DESPUÉS:
// SITE_URL se resuelve en tiempo de ejecución desde env.WORKER_BASE_URL
// Se exporta una función para obtenerlo, con fallback al dominio del Worker
let _SITE_URL = 'https://guardman.oficinadesarrollo33.workers.dev';
export function setSiteUrl(url: string): void { _SITE_URL = url; }
export function getSiteUrl(): string { return _SITE_URL; }
// Para uso en templates donde no hay env disponible, usar getSiteUrl()
// Para uso en index.ts donde SÍ hay env, pasar SITE_URL explícitamente
export const SITE_URL = _SITE_URL; // legacy compat — se sobreescribe vía setSiteUrl()
```

#### T1.2 — Inicializar SITE_URL desde env en index.ts

**Archivo:** `src/index.ts`

**Cambios:**
Al inicio de la función `fetch()`, agregar:
```typescript
import { setSiteUrl } from './ssr/site-renderer';
// En el handler fetch, primera línea:
setSiteUrl(env.WORKER_BASE_URL || 'https://guardman.oficinadesarrollo33.workers.dev');
```

#### T1.3 — Actualizar wrangler.jsonc

**Archivo:** `wrangler.jsonc`

**Cambios:**
```jsonc
"vars": {
    "ENVIRONMENT": "production",
    "ADMIN_EMAIL": "admin@guardman.cl",
    "WORKER_BASE_URL": "https://guardman.oficinadesarrollo33.workers.dev"  // ← corregido
}
```

**Verificación:**
- `grep -n "SITE_URL" src/ssr/site-renderer.ts` → debe mostrar la nueva función
- `grep -n "setSiteUrl" src/index.ts` → debe mostrar la llamada
- `grep -n "guardman.cl" src/ssr/site-renderer.ts` → NO debe aparecer (excepto en textos de contenido)

---

### FASE 2: Eliminar Blog del sitio público (P1)
**Objetivo:** Remover todas las rutas, links y builders de blog del SSR público

#### T2.1 — Eliminar rutas de blog en index.ts

**Archivo:** `src/index.ts`

**Eliminar:**
- Bloque `else if (path === '/blog')` (~líneas 523-526)
- Bloque `else if (path.match(/^\/blog\/[^/]+$/))` (~líneas 528-533)
- Entrada de cache para blog: `else if (path === '/blog') cacheKey = ...` y `else if (path.startsWith('/blog/')) cacheKey = ...`
- Entrada del sitemap: `` ` <url><loc>${SITE_URL}/blog</loc>...` ``
- Loop `for (const bp of blogPosts.results as any[])` (~líneas 314-316)
- La query de blog en `handleSitemap`: `env.DB.prepare("SELECT slug FROM blog_posts...").all()`

**Conservar:**
- Las funciones `fetchBlogPosts()`, `fetchBlogPost()`, `buildBlogListing()`, `buildBlogPost()` — se pueden mover a un archivo separado o marcar con comentario `// BLOG: conservado para uso futuro vía API`. **O mejor, eliminarlas completamente** ya que la API CMS tiene sus propios endpoints de blog.

**Decisión final:** Eliminar completamente. Si se necesita blog en el futuro, se implementa de nuevo limpio.

#### T2.2 — Eliminar link Blog del nav header

**Archivo:** `src/ssr/site-renderer.ts`

En la función `hdr()`, buscar y eliminar:
```
<a href="/blog" class="nav-link">Blog</a>
```

#### T2.3 — Eliminar entry de blog en sitemap

**Archivo:** `src/index.ts`

En `handleSitemap()`, eliminar la línea que genera la URL del blog y el array destructuring que incluye `blogPosts`.

**Verificación:**
- `grep -n "blog" src/index.ts` → solo debe quedar en `sanitizeHtml` o comentarios
- `grep -n "Blog" src/ssr/site-renderer.ts` → solo en textos de contenido (no en nav)
- Navegar a `/blog` → debe dar 404
- `/sitemap.xml` → no debe contener URLs de blog

---

### FASE 3: Flush caché y rebuild Admin (P1)
**Objetivo:** Poner el admin actualizado y limpiar caché stale

#### T3.1 — Rebuild Admin UI

```bash
cd C:/Users/56930/OneDrive/Escritorio/guardman-admin/guardman-admin-ui
npm run build
cd ..
```

#### T3.2 — Copiar dist a public/admin

```bash
# En Windows:
xcopy /E /Y "guardman-admin-ui\dist\assets" "public\admin\assets\"
copy /Y "guardman-admin-ui\dist\index.html" "public\admin\index.html"
```

Agregar favicon al index.html:
```html
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
```

#### T3.3 — Flush KV cache

Usar el endpoint CMS:
```bash
curl -X POST https://guardman.oficinadesarrollo33.workers.dev/api/cms/rebuild -H "Authorization: Bearer TOKEN"
```

O via wrangler:
```bash
npx wrangler kv key list --namespace-id 2090314bf4ca45318fabaa2fd4ef8ff5 --prefix "page:" --remote
# Luego delete cada key
```

**Verificación:**
- `/admin` carga correctamente
- El CMS muestra las páginas
- Guardar una página funciona
- Response headers incluyen `X-Cache: MISS` en la primera visita

---

### FASE 4: Commit y Deploy (P0)
**Objetivo:** Poner el código en producción de forma segura

#### T4.1 — Commit de todo el estado actual

```bash
cd C:/Users/56930/OneDrive/Escritorio/guardman-admin
git add -A
git commit -m "feat: session 2026-05-08 — CMS 100%, normalización visual, plan maestro

- CMS-driven builders para todas las páginas estáticas
- Mapas Leaflet en homepage y ubicaciones
- Carrusel de clientes con logos
- SEO scoring por página
- IA regeneration con deep merge
- CSP headers, critical CSS, OG tags
- CSS_V centralizado, esc() unificado
- Fix: staff-section invisible, dark theme cleanup
- Eliminar blog del sitio público
- SITE_URL configurable por env var"
```

#### T4.2 — Deploy a producción

```bash
npx wrangler deploy
```

#### T4.3 — Flush caché post-deploy

```bash
curl -X POST https://guardman.oficinadesarrollo33.workers.dev/api/cms/rebuild -H "Authorization: Bearer $AUTH_TOKEN"
```

#### T4.4 — Verificación manual

Checklist de URLs a verificar:
- [ ] `/` — Homepage completa (hero, nosotros, servicios, guard-pod, sectores, ajax, clientes, mapa)
- [ ] `/servicios` — Hub con cards y CTA final
- [ ] `/servicios/guardias-de-seguridad` — Detalle con sidebar
- [ ] `/ubicaciones` — Hub con mapa Leaflet
- [ ] `/ubicaciones/las-condes` — Detalle con mapa
- [ ] `/sectores` — Hub con cards y CTA
- [ ] `/sectores/residencial` — Detalle
- [ ] `/nosotros` — Stats, timeline, valores, diferenciadores, staff
- [ ] `/guard-pod` — Dark theme, hero-grid, features, problems, FAQ
- [ ] `/ajax-systems` — Dark theme, hero-grid, features, problems, FAQ
- [ ] `/contacto` — Formulario + mapa
- [ ] `/cotizacion` — Formulario + trust badges
- [ ] `/gracias` — Post-form
- [ ] `/privacidad` — Legal
- [ ] `/terminos` — Legal
- [ ] `/sitemap.xml` — XML válido sin URLs de blog
- [ ] `/robots.txt` — Correcto
- [ ] `/admin` — CMS carga y funciona
- [ ] `/blog` — Debe dar 404
- [ ] Menú móvil funciona (hamburguesa toggle)
- [ ] Formulario contacto POST → lead en D1

---

### FASE 5: Limpieza de código (P2)
**Objetivo:** Mejorar mantenibilidad del código

#### T5.1 — Eliminar funciones de blog de index.ts

**Archivo:** `src/index.ts`

Eliminar completamente:
- `async function fetchBlogPosts(env: Env)` (~líneas 654-660)
- `async function fetchBlogPost(env: Env, slug: string)` (~líneas 662-668)
- `function buildBlogListing(posts: any[]): string` (~líneas 688-706)
- `function buildBlogPost(post: any): string` (~líneas 708-735)

#### T5.2 — Limpiar CMS API routes de blog (opcional)

**Archivo:** `src/api/routes/cms.ts`

Los endpoints de blog (`/api/cms/blog/list`, `/api/cms/blog/get`, `/api/cms/blog/save`, `/api/cms/blog/delete`) se pueden conservar porque son API interna y no son accesibles públicamente como páginas web. **Decisión: conservar.**

#### T5.3 — Refactorizar buildContactoPage (frágil)

**Archivo:** `src/ssr/site-renderer.ts`, función `buildContactoPage()`

**Problema actual:** Usa regex para reemplazar partes del HTML importado:
```typescript
CONTACTO_HTML.replace(/<h1>Cont[^<]*<\/h1>/, '').replace(/<p>Estamos[^<]*<\/p>/, '').replace(/<section class="hero"[^>]*>[\s\S]*?<\/section>/, '')
```

**Solución:** Construir el body dinámicamente sin depender del HTML importado:
1. Extraer el contenido del formulario de `CONTACTO_HTML` (la parte que NO es hero)
2. Construir el hero dinámicamente con datos del CMS
3. Componer ambos en el builder

Implementación:
```typescript
export function buildContactoPage(env?: any): string {
  const d = (env as any)?._staticData;
  let title = d?.meta_title || 'Contacto — GuardMan Chile | Seguridad Privada en Santiago';
  let desc = d?.meta_description || 'Contacta a GuardMan Chile. Disponibles 24/7.';
  let heroH = 'Contáctanos';
  let heroS = 'Estamos disponibles las 24 horas, los 7 días de la semana.';
  let contactInfo = { phone: '+56 9 300 000 10', email: 'info@guardman.cl', address: 'Av. Américo Vespucio Norte 1980, Providencia, Santiago', lat: '-33.4569', lng: '-70.6483' };

  if (d?.content_json) {
    try {
      const cj = typeof d.content_json === 'string' ? JSON.parse(d.content_json) : d.content_json;
      const seo = cj.seo || {};
      const c = cj.content || cj;
      if (seo.title) title = seo.title;
      if (seo.description) desc = seo.description;
      if (c.hero?.headline) heroH = c.hero.headline;
      if (c.hero?.subheadline) heroS = c.hero.subheadline;
      if (c.contact_info) contactInfo = { ...contactInfo, ...c.contact_info };
    } catch {}
  }

  // Formulario HTML — extraído directamente sin regex sobre CONTACTO_HTML
  const formHtml = buildContactoForm(contactInfo);

  return `<!doctype html>...
    ${hdr('light')}
    ${brd([...])}
    <section class="hero"><div class="container"><h1>${esc(heroH)}</h1><p>${esc(heroS)}</p></div></section>
    ${formHtml}
    ${buildContactoMap(contactInfo)}
    ${ftr()}
    <script src="/scripts/main.js"></script>
  </body></html>`;
}

function buildContactoForm(ci: any): string {
  // HTML del formulario + info cards — sin depender de CONTACTO_HTML importado
  return `<section class="bg-white" style="padding:64px 0"><div class="container"><div class="section-grid">
    <div class="form-card"><h2>Envíanos un mensaje</h2><form method="POST" action="/contacto">...campos...</form></div>
    <div>
      <div class="contact-info-card">...teléfono...</div>
      <div class="contact-info-card">...email...</div>
      <div class="contact-info-card">...dirección...</div>
      <div class="contact-info-card">...horario...</div>
    </div>
  </div></div></section>`;
}

function buildContactoMap(ci: any): string {
  return `<section class="bg-neutral" style="padding:48px 0"><div class="container">
    <h2 class="section-title">Encuéntranos</h2>
    <p class="section-subtitle">${esc(ci.address)}</p>
    <div id="map-contacto" style="height:360px;border-radius:var(--radius-xl)"></div>
  </div></section>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script>(function(){...leaflet init...})()</script>`;
}
```

**NOTA:** Antes de implementar, leer `contacto-html.ts` para extraer el formulario exacto y no perder campos.

#### T5.4 — Refactorizar buildCotizacionPage (mismo patrón)

**Archivo:** `src/ssr/site-renderer.ts`, función `buildCotizacionPage()`

Mismo enfoque que T5.3: leer `cotizacion-html.ts`, extraer el formulario, construir dinámicamente sin regex.

---

## CHECKLIST CONSOLIDADO

### Fase 1: SITE_URL (P0)
- [ ] T1.1 — SITE_URL dinámico en site-renderer.ts
- [ ] T1.2 — Inicializar SITE_URL desde env en index.ts
- [ ] T1.3 — WORKER_BASE_URL corregido en wrangler.jsonc
- [ ] Verificar: `grep -c "guardman.cl" src/ssr/site-renderer.ts` → 0 (excepto contenido)

### Fase 2: Eliminar Blog (P1)
- [ ] T2.1 — Eliminar rutas /blog y /blog/{slug} en index.ts
- [ ] T2.2 — Eliminar link Blog del nav header en site-renderer.ts
- [ ] T2.3 — Eliminar blog del sitemap y cache keys
- [ ] T2.4 — Eliminar funciones muertas (fetchBlogPosts, fetchBlogPost, buildBlogListing, buildBlogPost, sanitizeHtml puede conservarse)
- [ ] Verificar: `/blog` → 404, sitemap sin URLs de blog

### Fase 3: Admin + Cache (P1)
- [ ] T3.1 — Rebuild Admin UI (`cd guardman-admin-ui && npm run build`)
- [ ] T3.2 — Copiar dist a public/admin/ con favicon
- [ ] T3.3 — Flush KV cache

### Fase 4: Commit + Deploy (P0)
- [ ] T4.1 — `git add -A && git commit`
- [ ] T4.2 — `npx wrangler deploy`
- [ ] T4.3 — Flush KV cache post-deploy
- [ ] T4.4 — Verificación manual de todas las rutas

### Fase 5: Limpieza (P2)
- [ ] T5.1 — Eliminar funciones blog muertas
- [ ] T5.2 — Conservar blog API routes
- [ ] T5.3 — Refactorizar buildContactoPage sin regex
- [ ] T5.4 — Refactorizar buildCotizacionPage sin regex

---

## NOTAS TÉCNICAS PARA LA IMPLEMENTACIÓN

### Cómo funciona el cache KV
```
1. Request llega → index.ts renderSitePage()
2. Genera cacheKey (ej: "page:homepage", "page:service:guardias-de-seguridad")
3. Busca en KV: getCache(env, cacheKey)
4. HIT → devuelve HTML cacheado con X-Cache: HIT
5. MISS → genera HTML con builder, guarda en KV con TTL 3600s, devuelve con X-Cache: MISS
6. CMS save → invalidateCache() borra la key específica + homepage
7. CMS rebuild → flushAllCache() borra todas las keys con prefix "page:"
```

### Cómo funciona el CMS → SSR
```
1. Admin UI (CMSPage.tsx) hace POST /api/cms/save con {path, content}
2. cms.ts parsea el path y guarda content_json en D1 (static_page_content o content_versions)
3. invalidateCache() borra la key KV de esa página
4. Next request: MISS → builder lee content_json de D1 → genera HTML con overrides → cachea
5. Subsiguientes: HIT → sirve HTML cacheado
```

### Formato de content_json para páginas estáticas
```json
{
  "seo": { "title": "...", "description": "..." },
  "content": {
    "hero": { "headline": "...", "subheadline": "...", "badge": "...", "image": "/images/..." },
    "stats": [{ "value": "500+", "label": "Guardias" }],
    "timeline": [{ "year": "2017", "title": "...", "description": "..." }],
    "values": [{ "title": "...", "description": "..." }],
    "differentiators": [{ "icon": "<svg>...", "title": "...", "description": "..." }],
    "certifications": [{ "title": "...", "description": "..." }],
    "staff": { "image": "/images/...", "traits": ["...", "..."] },
    "cta": { "heading": "...", "subheading": "...", "button_text": "...", "button_href": "..." }
  }
}
```

### Flujo de deploy
```bash
# 1. Build Admin UI
cd guardman-admin-ui && npm run build && cd ..

# 2. Copiar assets del admin
xcopy /E /Y "guardman-admin-ui\dist\assets" "public\admin\assets\"
copy /Y "guardman-admin-ui\dist\index.html" "public\admin\index.html"

# 3. Verificar que favicon está en el index.html del admin
# Si no: agregar <link rel="icon" type="image/svg+xml" href="/favicon.svg" /> antes de </head>

# 4. Deploy Worker
npx wrangler deploy

# 5. Flush cache
curl -X POST https://guardman.oficinadesarrollo33.workers.dev/api/cms/rebuild -H "Authorization: Bearer TOKEN"
```

### Dominio del Worker
- **Workers URL:** `https://guardman.oficinadesarrollo33.workers.dev`
- **Workers name:** `guardman` (definido en wrangler.jsonc)
- **D1 database:** `guardman-seo` (id: `aeaab85c-d4df-46c4-96b9-28d6a95aaec4`)
- **R2 bucket:** `guardman-images`
- **KV namespace:** `CACHE` (id: `2090314bf4ca45318fabaa2fd4ef8ff5`)

### Auth
- El CMS Admin usa `AUTH_TOKEN` para autenticación
- El formulario de login compara contra `ADMIN_EMAIL` + `AUTH_TOKEN`
- El endpoint `/health/homepage-debug` usa comparación estricta: `authHdr === \`Bearer ${env.AUTH_TOKEN}\``
