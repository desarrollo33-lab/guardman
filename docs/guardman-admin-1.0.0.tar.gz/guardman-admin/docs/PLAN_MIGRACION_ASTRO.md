# Plan de Migración a Astro — GuardMan Admin

**Fecha:** 2026-06-04
**Versión:** 1.0 — Documento de planificación (Fase 1)
**Fase actual:** 1 de 4 — Evaluación y documentación
**Objetivo:** Migrar de Vite/React + Cloudflare Worker monolithic a Astro + Worker API, estandarizando código y simplificando CRM.

---

## Visión General del Plan

```
FASE 1 (actual)   → Evaluación técnica y documentación
FASE 2            → Setup Astro + migración sitio público
FASE 3            → Migración admin SPA (CMS, CRM simplificado, etc.)
FASE 4            → Estabilización, testing, deploy final
```

**Principio rector:** Migración incremental. Cada fase produce un sistema funcional que puede coexistir con el actual. El switch final es un cambio de DNS, no un big bang.

---

## FASE 1 — Evaluación y Documentación ✅

**Duración:** 1 sesión
**Entregables:**
- [x] `MIGRACION_ASTRO_FASE1_EVALUACION.md` — Inventario completo, evaluación técnica, riesgos
- [x] `PLAN_MIGRACION_ASTRO.md` — Este documento, plan detallado de trabajo
- [ ] `PLAN_SIMPLIFICACION_CRM.md` — Especificación detallada del CRM reducido (Fase 2.5)
- [ ] `ARQUITECTURA_ASTRO.md` — Diagrama de arquitectura post-migración

**No se escribe código en esta fase.**

---

## FASE 2 — Setup Astro + Sitio Público

**Duración estimada:** 3-4 sesiones
**Objetivo:** Astro funcionando con el sitio público renderizado desde la API del Worker.

### 2.1 — Inicialización del Proyecto Astro

**Tareas:**
1. Crear proyecto Astro desde cero con `create astro@latest`
2. Instalar dependencias:
   - `@astrojs/cloudflare` — adapter para deploy en Cloudflare
   - `@astrojs/react` — para islas React en el admin
   - `@astrojs/tailwind` / `@tailwindcss/vite` — Tailwind v4
   - `tailwindcss` v4
3. Configurar `astro.config.mjs`:
   ```js
   import { defineConfig } from 'astro/config';
   import cloudflare from '@astrojs/cloudflare';
   import react from '@astrojs/react';
   import tailwindcss from '@tailwindcss/vite';

   export default defineConfig({
     output: 'server', // SSR para contenido dinámico de D1
     adapter: cloudflare({ mode: 'directory' }),
     integrations: [react()],
     vite: { plugins: [tailwindcss()] },
   });
   ```
4. Configurar TypeScript (`tsconfig.json`)
5. Migrar assets estáticos:
   - `public/styles/site.css` → `src/styles/global.css` (Tailwind)
   - `public/styles/dark.css` → clases Tailwind + `data-theme="dark"`
   - `public/scripts/main.js` → `src/scripts/` o inline
   - `public/favicon.svg` → `public/favicon.svg`
   - `public/fonts/` → `public/fonts/`
   - `public/cuestionario-ceo-rodrigo.html` → `public/cuestionario-ceo-rodrigo.html`
6. Crear layout base `src/layouts/BaseLayout.astro` con `<html>`, `<head>`, SEO meta
7. Crear componentes de layout:
   - `src/components/Header.astro` — navegación
   - `src/components/Footer.astro` — footer
   - `src/components/SEO.astro` — meta tags, OG, schemas JSON-LD

**Validación:** `npm run dev` muestra una página de prueba. Tailwind funciona. Assets se sirven.

### 2.2 — Migración de Páginas Públicas

**Principio:** Cada página Astro hace `fetch()` al Worker API (`/api/cms/content?type=...&slug=...`) para obtener los datos. Usa la misma lógica de `site-data.ts` pero adaptada al contexto Astro.

**Tareas:**

1. **Crear API client** (`src/lib/api.ts`):
   ```ts
   const API_BASE = import.meta.env.PUBLIC_API_URL || 'https://guardman.oficinadesarrollo33.workers.dev';
   
   export async function fetchPageData(type: string, slug: string, location?: string) {
     const params = new URLSearchParams({ type, slug });
     if (location) params.set('location', location);
     const res = await fetch(`${API_BASE}/api/cms/content?${params}`);
     return res.json();
   }
   
   export async function fetchHomepageData() {
     const res = await fetch(`${API_BASE}/api/cms/homepage`);
     return res.json();
   }
   ```

2. **Homepage** (`src/pages/index.astro`):
   - Fetch desde `/api/cms/homepage` + `/api/cms/content?type=static_page&slug=homepage`
   - Layout con hero, secciones (nosotros, servicios, sectores, Guard Pod, Ajax, ubicaciones, CTA final, clientes)
   - SEO: meta title/description, OG tags, schema JSON-LD
   - Replicar todos los overrides de `content_json` que hace `src/ssr/site-renderer.ts`

3. **Páginas de servicio** (`src/pages/servicios/[slug].astro`):
   - Fetch desde `/api/cms/content?type=service&slug=...`
   - Template: hero, intro, features, issues, staff, locations, FAQ, sidebar, CTA

4. **Páginas de combo** (`src/pages/servicios/[service]/[location].astro`):
   - Fetch desde `/api/cms/content?type=combo&slug=...&location=...`
   - Mismo template que servicio

5. **Páginas de ubicación** (`src/pages/ubicaciones/[slug].astro`):
   - Fetch desde `/api/cms/content?type=location&slug=...`
   - Template con mapa Leaflet/OSM, servicios disponibles en la comuna

6. **Páginas de sector** (`src/pages/sectores/[slug].astro`):
   - Fetch desde `/api/cms/content?type=sector&slug=...`
   - Template con color tag del sector

7. **Páginas Hub** (`src/pages/servicios/index.astro`, `src/pages/ubicaciones/index.astro`, `src/pages/sectores/index.astro`):
   - Fetch desde `/api/cms/list?type=...`
   - Grid de cards con imagen, nombre, descripción

8. **Páginas estáticas** (`src/pages/nosotros.astro`, `src/pages/guard-pod.astro`, `src/pages/ajax-systems.astro`, `src/pages/contacto.astro`, `src/pages/cotizacion.astro`, `src/pages/privacidad.astro`, `src/pages/terminos.astro`):
   - Fetch desde `/api/cms/content?type=static_page&slug=...`
   - Cada una con su layout específico (dark para guard-pod y ajax)

9. **Páginas especiales**:
   - `src/pages/gracias.astro` — post-formulario
   - `src/pages/404.astro` — página no encontrada
   - `src/pages/500.astro` — error del servidor
   - `src/pages/sitemap.xml.ts` — sitemap dinámico
   - `src/pages/robots.txt.ts` — robots.txt

**Validación:** `npm run build && npm run preview` — todas las rutas públicas renderizan correctamente. Lighthouse ≥ 90.

### 2.3 — CSS y Design Tokens

**Tareas:**
1. Definir design tokens en Tailwind v4 `@theme`:
   ```css
   @import "tailwindcss";
   
   @theme {
     --color-primary: #1E3A5F;     /* GuardMan navy */
     --color-primary-light: #2A5298;
     --color-accent: #3B82F6;      /* Blue accent */
     --color-surface: #FFFFFF;
     --color-surface-2: #F8FAFC;
     --color-surface-3: #1A2744;   /* Dark surface (admin) */
     --color-border: #E2E8F0;
     --color-border-subtle: rgba(255,255,255,0.05);
     --font-sans: 'Inter', system-ui, sans-serif;
     --radius-xl: 16px;
   }
   ```
2. Crear tema claro (sitio público) y tema oscuro (admin + Guard Pod + Ajax)
3. Componentes reutilizables: `Button.astro`, `Badge.astro`, `Card.astro`, `Section.astro`
4. Eliminar CSS custom properties sueltos del sistema actual

**Validación:** Consistencia visual entre old y new. El sitio público se ve igual.

---

## FASE 3 — Migración del Admin SPA

**Duración estimada:** 4-5 sesiones
**Objetivo:** Admin panel funcionando en Astro con islas React donde sea necesario.

### 3.1 — Layout del Admin

**Tareas:**
1. Crear layout `src/layouts/AdminLayout.astro`
2. Componentes Astro puros:
   - `src/components/admin/Sidebar.astro` — navegación lateral
   - `src/components/admin/Topbar.astro` — breadcrumb, título, avatar
   - `src/components/admin/LoginForm.astro` — formulario de login
3. Sistema de autenticación (token en localStorage, igual que el actual)
4. Protección de rutas `/admin/*`

**Validación:** Login funciona. Navegación entre vistas funciona.

### 3.2 — CMS Editor (Prioridad Alta)

**Estrategia:** El `CMSPage` actual es grande (1,580 LOC) y usa Monaco Editor. Se migra como isla React.

**Tareas:**
1. Migrar `CMSPage.tsx` como isla React (`client:only="react"`)
2. Migrar `SEOPanel.tsx` como componente Astro/React
3. Integrar `SEOScorePanel` (actualmente código muerto) o eliminarlo
4. Migrar `MonacoEditor.tsx` como isla React
5. Migrar `PreviewFrame.tsx`
6. Crear página Astro: `src/pages/admin/index.astro` → CMS

**Simplificación:** Unificar `SEOPanel` y `SEOScorePanel` en un solo componente. Eliminar código muerto.

### 3.3 — CRM Simplificado (Prioridad Alta)

**Estrategia:** Reescribir el CRM desde cero con solo las features esenciales. De 16 archivos → ~6 componentes.

**Componentes finales:**
1. `CRMDashboard.astro` — KPIs comerciales + agenda diaria (Mi Día fusionado)
2. `CRMPipeline.tsx` — Kanban con drag & drop (isla React, necesita interactividad)
3. `LeadDetail.tsx` — Ficha de lead con visitas y cotizaciones embebidas (isla React)
4. `ClientList.tsx` — Lista de clientes (isla React)
5. `ClientDetail.tsx` — Ficha de cliente (isla React)
6. `ProposalBuilder.tsx` — Crear/editar cotización (isla React)

**Lo que se elimina:**
- `CRMMiDia.tsx` → fusionado en Dashboard
- `VisitChecklist.tsx` → embebido en LeadDetail
- `MockDataLoader.tsx` → solo en dev
- `ConvertToClientModal.tsx` → cambio de status directo
- `useMockApi.ts` / `useRealApi.ts` → un solo `useApi`
- `PipelineBar.tsx` (huérfano)

**API endpoints consolidados:**
- Mantener: dashboard, leads CRUD, clients CRUD, pipeline, proposals
- Fusionar: tasks y visits dentro del lead (no endpoints separados)
- Eliminar: `/api/crm/leads/capture` (duplicado con intel)

### 3.4 — Media Editor (Prioridad Media)

**Estrategia:** Componente complejo con mucha lógica de estado (useMediaEditorReducer). Isla React completa.

**Tareas:**
1. Migrar `MediaEditor.tsx` + subcomponentes como islas React
2. Página Astro: `src/pages/admin/media.astro`
3. Evaluar si se puede simplificar: ¿se usa la generación IA (fal.ai) activamente?

### 3.5 — Intel Hub (Prioridad Media)

**Estrategia:** Dashboards y gráficos migran como islas React.

**Tareas:**
1. Migrar `IntelDashboard.tsx` como isla React
2. Migrar `CompetitorView.tsx`, `MarketMap.tsx`, `PositionTracker.tsx`
3. Migrar tabla CRUD `IntelCRUD.tsx`
4. Página Astro: `src/pages/admin/intel.astro`

### 3.6 — ADN Brand (Prioridad Baja)

**Estrategia:** Formulario simple, puede ser Astro puro o React.

**Tareas:**
1. Migrar `ADNPage.tsx` a Astro puro o isla React
2. Página Astro: `src/pages/admin/brand.astro`

### 3.7 — Chat (Prioridad Baja)

**Estrategia:** WebSocket (PartySocket) solo funciona en browser. Isla React `client:only`.

**Tareas:**
1. Migrar `ChatView.tsx`, `ChatDrawer.tsx` como islas React
2. Página Astro: `src/pages/admin/chat.astro`

### 3.8 — Publish & Deploy (Prioridad Baja)

**Estrategia:** Paneles informativos, Astro puro suficiente.

**Tareas:**
1. Migrar `PublishPage.tsx` a Astro puro
2. Simplificar: ¿realmente se necesita diff viewer y change list?

---

## FASE 4 — Estabilización, Testing y Deploy

**Duración estimada:** 2-3 sesiones
**Objetivo:** Sistema completo, testeado y en producción.

### 4.1 — Testing

**Tareas:**
1. Test de todas las rutas públicas (20+ rutas)
2. Test del admin (login, CMS CRUD, CRM pipeline, media upload)
3. Test de integración: admin guarda contenido → sitio público lo refleja
4. Test de performance: Lighthouse, bundle size, time to interactive
5. Test de regresión: features del sistema actual que deben seguir funcionando
6. Test de flujos automatizados (cron jobs, workflows, queues — no se tocan pero se verifica que sigan andando)

### 4.2 — Build y Deploy

**Tareas:**
1. Configurar `wrangler.toml` / `wrangler.jsonc` para Astro en Cloudflare Pages
2. Configurar variables de entorno en Pages (API_URL, etc.)
3. Build de producción: `npm run build`
4. Deploy a Cloudflare Pages (staging)
5. Validación en staging
6. Deploy a producción
7. Switch DNS (si aplica)
8. Monitoreo post-deploy (errores, performance, formularios)

### 4.3 — Limpieza

**Tareas:**
1. Archivar `guardman-admin-ui/` (deprecado)
2. Archivar `src/ssr/` del Worker (los builders de string ya no se usan)
3. Remover builders inline de `src/index.ts` (buildGraciasPage, build404Page, build500Page, handleSitemap, renderSitePage)
4. Remover dependencias no usadas del Worker (`react`, `react-dom`, `lucide-react` del package.json del backend)
5. Actualizar `wrangler.jsonc` — eliminar binding `ASSETS` (si ya no sirve el admin SPA)
6. Actualizar `README.md` y documentación

---

## Cronograma Estimado

| Fase | Sesiones | Entregable principal | Depende de |
|------|----------|---------------------|------------|
| Fase 1 | 1 | Documentación completa | — |
| Fase 2 | 3-4 | Sitio público en Astro | Fase 1 |
| Fase 3 | 4-5 | Admin SPA en Astro | Fase 2 |
| Fase 4 | 2-3 | Producción + limpieza | Fase 3 |
| **Total** | **10-13 sesiones** | Sistema completo migrado | — |

---

## Riesgos y Dependencias

### Dependencias Críticas

| Dependencia | Estado | Acción |
|-------------|--------|--------|
| `@astrojs/cloudflare` adapter | ✅ Disponible | Usar última versión |
| `@astrojs/react` | ✅ Disponible | Para islas React |
| Tailwind v4 + Astro | ✅ Compatible | Vite plugin |
| Monaco Editor en Astro | ⚠️ Validar | Posible isla React `client:only` |
| PartySocket en Astro | ⚠️ Validar | `client:only` debería funcionar |
| Worker API responde a CORS | ⚠️ Configurar | Agregar headers si Astro está en otro origen |

### Puntos de Decisión Pendientes

1. **¿Dónde se hostea Astro?**
   - Opción A: Cloudflare Pages (gratis, mismo ecosistema)
   - Opción B: Mismo Worker que la API (un solo deploy, sin CORS)
   - **Recomendación:** Opción A para staging, evaluar B para producción

2. **¿SSR o SSG para páginas públicas?**
   - SSG: más rápido, build más largo, contenido se actualiza solo en deploy
   - SSR: siempre fresco, cold start en Cloudflare
   - **Recomendación:** SSR con cache en KV (igual que ahora) para páginas públicas

3. **¿Las páginas del admin son SPA o MPA?**
   - SPA (client-side routing): más suave, una sola carga de React
   - MPA (server-side routing): más simple, mejor SEO, pero flickering
   - **Recomendación:** MPA con islas React. El admin no necesita SEO. La simplicidad gana.

4. **¿Mantener `guardman-admin-ui/` como paquete separado o unificar?**
   - **Recomendación:** Unificar en el proyecto Astro. Menos complejidad de build.

---

## Métricas de Éxito por Fase

### Fase 2 (Sitio Público)
- [ ] 20+ rutas públicas renderizan en Astro
- [ ] Lighthouse homepage ≥ 95
- [ ] Formularios de contacto/cotización funcionan
- [ ] Sitemap y robots.txt generados correctamente
- [ ] Cache KV funciona (misma lógica que ahora)
- [ ] Schema JSON-LD presente en todas las páginas

### Fase 3 (Admin)
- [ ] Login funciona contra el Worker
- [ ] CMS: guardar, regenerar, previsualizar contenido
- [ ] CRM simplificado: crear lead, mover en pipeline, crear cotización
- [ ] Media: subir, listar, borrar imágenes
- [ ] Chat con agentes IA vía WebSocket
- [ ] ADN Brand guarda en D1

### Fase 4 (Producción)
- [ ] ≥ 192 tests pasando (sin regresiones)
- [ ] Build time < 5s
- [ ] Bundle admin < 400KB
- [ ] Sitio público responde en < 2s
- [ ] Admin CRUD operations < 500ms
- [ ] Cero errores en producción (24h monitoring)

---

## Notas para la Implementación

1. **No reescribir el backend.** El Worker con su API REST, Durable Objects, Workflows y Cron jobs es estable y funcional. Solo se limpia el código de SSR que ya no se usa.

2. **Las islas React son tu amigo.** Componentes que necesitan estado complejo o interactividad (Monaco, Kanban drag-drop, WebSocket chat, Media Editor) se mantienen como React pero dentro de Astro.

3. **Tailwind v4 unifica estilos.** Adiós a CSS custom properties sueltos. Un `@theme` central con los design tokens de GuardMan.

4. **La simplificación del CRM es cultural, no técnica.** Preguntar a Rodrigo (CEO) qué features del CRM realmente usa antes de eliminar. El plan técnico asume un equipo comercial de 1-3 personas.

5. **Migración en rama separada.** Todo el trabajo se hace en `migracion-astro` sin tocar `main`. El sistema actual sigue en producción hasta el switch final.

---

## Próximos Pasos Inmediatos (Fase 2)

1. Crear proyecto Astro: `npm create astro@latest guardman-astro`
2. Instalar adapters y dependencias
3. Configurar `astro.config.mjs`
4. Crear `BaseLayout.astro` con header/footer
5. Migrar CSS a Tailwind v4
6. Conectar con Worker API
7. Migrar página por página, empezando por la homepage
