# Migración a Astro — Fase 1: Evaluación Técnica

**Fecha:** 2026-06-04
**Objetivo:** Evaluar la viabilidad y alcance de migrar GuardMan Admin de Vite/React + Cloudflare Worker a Astro, estandarizando el código y simplificando el CRM a herramientas esenciales.
**Fase:** 1 de 4 — Solo documentación y planificación. Sin código ejecutable.

---

## 1. Inventario del Sistema Actual

### 1.1 Stack Actual

| Capa | Tecnología | Ubicación |
|------|-----------|-----------|
| Admin SPA | Vite 8 + React 19 + Tailwind 4 | `guardman-admin-ui/` |
| Backend API | Cloudflare Worker (monolithic) | `src/index.ts` (~1,250 LOC) |
| SSR Público | String builders inline en Worker | `src/ssr/` (7 builders HTML + site-data + site-renderer) |
| Base de datos | Cloudflare D1 (`guardman-seo`) | Binding `DB` |
| Almacenamiento | Cloudflare R2 (`guardman-images`) | Binding `IMAGES` |
| Cache | Cloudflare KV | Binding `CACHE` |
| Colas | Cloudflare Queues (`seo-content-queue`) | Binding `SEO_CONTENT_QUEUE` |
| Agentes IA | Cloudflare Durable Objects (6) | `src/agents/` + `src/durable/` |
| Workflows | Cloudflare Workflows (6) | `src/workflows/` |
| Cron Jobs | Cloudflare Triggers (5 semanales) | `src/core/scheduler.ts` |
| MCP Server | API endpoint en Worker | `src/mcp/server.ts` |
| Build System | Vite build → Worker assets | `/admin/*` servido desde `ASSETS` binding |
| Deploy | `wrangler deploy` | `guardman.oficinadesarrollo33.workers.dev` |

### 1.2 Dependencias Clave

**Backend (guardman-admin/):**
- `@ai-sdk/anthropic`, `@ai-sdk/openai-compatible`, `workers-ai-provider` — inferencia IA
- `@cloudflare/ai-chat`, `@cloudflare/think`, `@cloudflare/workers-types` — runtime CF
- `agents` — SDK de Durable Objects/Workflows
- `ai` — Vercel AI SDK
- `@octokit/rest` — GitHub API
- `react`, `react-dom` — dependencias de SSR (usadas en el mismo worker para el admin SPA)
- `lucide-react` — iconos
- `memfs` — filesystem virtual

**Frontend (guardman-admin-ui/):**
- `react` 19, `react-dom` 19
- `@ai-sdk/react`, `@cloudflare/ai-chat` — chat IA
- `@monaco-editor/react` — editor de código
- `partysocket` — WebSocket para agentes
- `lucide-react`, `clsx` — UI utilities
- `marked` — Markdown rendering

### 1.3 Inventario de Archivos

```
Total: 204 archivos TypeScript/TSX | ~44,000 LOC

BACKEND (guardman-admin/src/) — 118 archivos
├── index.ts                         1,250  Router principal + SSR + builders inline
├── api.ts                             275  Router legacy (v7 compat)
├── types/index.ts                     200  Tipos compartidos + constantes
├── agents/ (8 archivos)              ~3,200  Durable Objects: content-agent, publisher-agent,
│                                            serper-agent, orchestrator, seo-auditor,
│                                            competitor-analyst, content-reviewer, page-templates
├── api/
│   ├── index.ts                        80  Router modular
│   ├── middleware/auth.ts              60  Auth middleware
│   ├── middleware/cors.ts              10  CORS headers
│   ├── routes/ (22 archivos)       ~6,000  admin, agents, ai, brand, chat-history, cms,
│                                            content, content-extra, cuestionario-ceo,
│                                            crm/{clients,dashboard,index,leads,pipeline,
│                                              proposals,tasks,visits},
│                                            intel/{competitors,crud,dashboard,helpers,index,
│                                              market,reports,seo},
│                                            media, memory, monitor, orchestrator, preview,
│                                            search, seo, serper, workflows
│   └── services/ (4 archivos)          400  log-session, preview-data-service,
│                                            template-renderer, worker-tail
├── core/scheduler.ts                   100  CRON job dispatcher
├── durable/ (2 archivos)               200  ai-generator, rate-limiter
├── mcp/server.ts                       150  MCP server endpoint
├── queues/ (2 archivos)                150  consumer, content-queue
├── serper/ (5 archivos)                600  Search intelligence pipeline
├── services/ (17 archivos)          ~2,800  ai, banned-patterns, brand-context, cache,
│                                            content-generation, db-session, de-generic-pass,
│                                            guardrails, image-prompts, inference, memory,
│                                            pipeline, preview, quality-review, rate-limit,
│                                            scoring, search, search-seed, section-generation,
│                                            section-merge, section-validators
├── ssr/ (13 archivos)               ~2,000  site-data, site-renderer, static-pages,
│                                            + 7 HTML builders (ajax, contacto, cotizacion,
│                                              guardpod, nosotros, privacidad, terminos)
│                                            + 4 content .txt files
├── utils/location.ts                     30
└── workflows/ (6 archivos)           ~1,200  bulk-generate, content-pipeline, quick-win,
                                              scheduled-reports, seo-intel, serper-scan

FRONTEND (guardman-admin-ui/src/) — 64 archivos
├── App.tsx                             280  Entry point + login form + settings
├── main.tsx                             20  React mount
├── index.css                           150  Tailwind + custom styles
├── components/
│   ├── Brand/ADNPage.tsx               300  Brand DNA editor
│   ├── Chart/ChartPanel.tsx            150  Chart visualization
│   ├── Chat/ (5 archivos)              800  ChatDrawer, ChatView, MiniDashboard,
│   │                                         Notifications, SessionSelector
│   ├── CMS/ (3 archivos)             1,900  CMSPage, SEOPanel, SEOScorePanel
│   ├── CRM/ (16 archivos)            ~3,000  CRMPage, CRMDashboard, CRMPipeline,
│   │                                         CRMMiDia, LeadDetail, ClientListView,
│   │                                         ClientDetailView, ConvertToClientModal,
│   │                                         ProposalBuilder, ProposalListView,
│   │                                         VisitChecklist, MockDataLoader + 4 tests
│   ├── Editor/MonacoEditor.tsx          150  Monaco editor wrapper
│   ├── Intel/ (8 archivos)            1,800  IntelPage, IntelDashboard, IntelCRUD,
│   │                                         CompetitorView, MarketMap, AlertsPanel,
│   │                                         PositionTracker, ContentStrategyView,
│   │                                         ReportView
│   ├── Layout/ (2 archivos)             160  AppLayout, Sidebar
│   ├── Media/ (14 archivos)           ~2,100  MediaEditor, MediaPicker, LiteYouTube,
│   │                                         panels/{GeneratePanel, MediaGrid,
│   │                                         MediaWorkspace, StaffPanel, TopNav}
│   │                                         shared/{AssignForm, CompareSlider,
│   │                                         EditModal, Lightbox, MediaCard,
│   │                                         SeoEditor, Toast, UploadModal}
│   │                                         useMediaEditorReducer
│   ├── Mobile/ (2 archivos)             100  DrawerMenu, MobileQuickActions
│   ├── Preview/PreviewFrame.tsx          80
│   ├── Publish/ (4 archivos)           400  ChangeList, DeployStatus, DiffViewer,
│   │                                         PublishPage
│   ├── Shared/PipelineBar.tsx           150
│   └── UI/ (4 archivos)                200  PipelineBar, Toast + tests
├── hooks/ (6 archivos)                 400  useApi, useMockApi, usePublish, useRealApi,
│                                             useSectionGenerator, useWebSocket
├── lib/falai.ts                        150  Fal.ai API client
├── mocks/crm-data.ts                   800  Mock data for CRM demo mode
└── services/scoring.ts                  80  Frontend SEO scoring
```

### 1.4 Vistas del Admin SPA

| Vista | Componente | Funcionalidad | Complejidad |
|-------|-----------|--------------|-------------|
| **CMS** | `CMSPage.tsx` | Editor de contenido: hero, secciones, SEO, previsualización, regeneración IA | 🔴 Alta (1,580 LOC) |
| **Media** | `MediaEditor.tsx` | Galería de imágenes, generación IA (fal.ai), edición SEO, subida/borrado | 🔴 Alta (2,100 LOC en 14 archivos) |
| **CRM** | `CRMPage.tsx` | Pipeline de leads, dashboard, cotizaciones, clientes, "Mi Día", visitas técnicas | 🔴 Alta (3,000 LOC en 16 archivos) |
| **Intel** | `IntelPage.tsx` | Inteligencia competitiva, SERP tracking, content strategy, reportes, alerts | 🟡 Media (1,800 LOC en 8 archivos) |
| **ADN** | `ADNPage.tsx` | Editor de identidad de marca (brand DNA en D1) | 🟢 Baja (300 LOC) |
| **Chat** | `ChatView.tsx` | Chat con agentes IA vía WebSocket + PartySocket | 🟡 Media (800 LOC en 5 archivos) |
| **Publish** | `PublishPage.tsx` | Control de cambios, diff viewer, deploy status | 🟢 Baja (400 LOC en 4 archivos) |

### 1.5 Estructura de Datos (D1)

**Tablas principales:**
- `services` — 9 servicios (guardias, CCTV, control accesos, etc.)
- `locations` — 14 comunas
- `sectors` — 9 sectores (residencial, comercial, industrial, etc.)
- `combo_content` — service+location combos
- `content_versions` — versiones de contenido por entidad
- `static_page_content` — páginas estáticas (homepage, nosotros, contacto, etc.)
- `blog_posts` — blog
- `brand_dna` — identidad de marca
- `intel_leads`, `intel_snapshots`, `intel_alerts`, `intel_reports`, `intel_opportunities` — intel
- `crm_leads`, `crm_clients`, `crm_proposals`, `crm_tasks`, `crm_visits`, `crm_interactions` — CRM
- `serper_results`, `serper_queries`, `serper_competitors` — search intelligence
- `media_library`, `media_entities` — media management
- `chat_history`, `chat_sessions` — chat de agentes
- `questionnaire_responses` — cuestionario CEO

### 1.6 Rutas del Sitio Público (SSR)

| Ruta | Tipo | Builder |
|------|------|---------|
| `/` | Homepage | `buildHomepage` |
| `/nosotros` | Estática | `buildNosotrosPage` |
| `/guard-pod` | Estática (dark) | `buildGuardPodPage` |
| `/ajax-systems` | Estática (dark) | `buildAjaxPage` |
| `/contacto` | Estática + POST form | `buildContactoPage` |
| `/cotizacion` | Estática + POST form | `buildCotizacionPage` |
| `/privacidad` | Estática | `buildPrivacidadPage` |
| `/terminos` | Estática | `buildTerminosPage` |
| `/gracias` | Estática (post-form) | `buildGraciasPage` (inline) |
| `/servicios` | Hub | `buildHubPage` |
| `/servicios/{slug}` | Detalle servicio | `buildDetailPage` |
| `/servicios/{svc}/{loc}` | Combo servicio+ubicación | `buildDetailPage` |
| `/ubicaciones` | Hub con mapa | `buildHubPage` |
| `/ubicaciones/{slug}` | Detalle ubicación | `buildDetailPage` |
| `/sectores` | Hub | `buildHubPage` |
| `/sectores/{slug}` | Detalle sector | `buildDetailPage` |
| `/cuestionario-ceo-rodrigo` | HTML estático | Assets |
| `/sitemap.xml` | Dinámico | `handleSitemap` (inline) |

---

## 2. Evaluación de Migración

### 2.1 ¿Qué se Migra a Astro?

| Componente | Migrar a Astro | Razón |
|------------|---------------|-------|
| **Admin SPA** (`guardman-admin-ui/`) | ✅ SÍ | Reemplazar Vite/React SPA por Astro con islas React |
| **Sitio Público SSR** (`src/ssr/`) | ✅ SÍ | Páginas Astro con `getStaticPaths` o SSR + fetching desde API |
| **CSS/Tailwind** | ✅ SÍ | Migrar a Tailwind v4 en contexto Astro |
| **Worker Backend** (`src/index.ts` + `src/api/`) | 🔄 PARCIAL | La API REST se mantiene en el Worker. El routing SSR se elimina (lo hace Astro) |
| **Durable Objects / Agents** | ❌ NO | Infraestructura Cloudflare, no migrable |
| **Workflows / Queues** | ❌ NO | Infraestructura Cloudflare, no migrable |
| **Cron Jobs** | ❌ NO | Infraestructura Cloudflare, no migrable |
| **D1 / R2 / KV** | ❌ NO | Infraestructura Cloudflare, no migrable |
| **MCP Server** | ❌ NO | Endpoint en Worker, no migrable |

### 2.2 Arquitectura Propuesta Post-Migración

```
                    ┌─────────────────────────────────────┐
                    │      Cloudflare Worker (backend)     │
                    │  POST https://guardman...workers.dev │
                    │                                      │
                    │  /api/* — REST API (igual que hoy)   │
                    │  /api/agents/* — WebSocket DO        │
                    │  /api/mcp — MCP Server               │
                    │  /api/login — Auth                   │
                    │  /api/images/* — R2 proxy            │
                    │                                      │
                    │  Bindings: D1, R2, KV, Queues,       │
                    │            DOs, Workflows, Cron       │
                    └──────────────┬──────────────────────┘
                                   │ fetch('/api/...')
                                   ▼
┌──────────────────────────────────────────────────────────┐
│              Astro Site (Cloudflare Pages)                │
│  https://guardman.pages.dev  (o dominio propio)          │
│                                                          │
│  ┌─────────────────────┐  ┌────────────────────────────┐ │
│  │  Sitio Público       │  │  Admin Panel               │ │
│  │  (SSR/SSG)           │  │  (SPA con islas React)     │ │
│  │                      │  │                            │ │
│  │  src/pages/          │  │  /admin/*                  │ │
│  │  • index.astro       │  │  • cms.astro               │ │
│  │  • servicios/[...]   │  │  • crm.astro               │ │
│  │  • ubicaciones/[...] │  │  • media.astro             │ │
│  │  • sectores/[...]    │  │  • intel.astro             │ │
│  │  • nosotros.astro    │  │  • brand.astro             │ │
│  │  • contacto.astro    │  │  • chat.astro              │ │
│  │  • cotizacion.astro  │  │                            │ │
│  │  • ...               │  │  Componentes React         │ │
│  │                      │  │  como islas donde sea      │ │
│  │  Componentes Astro   │  │  necesario                 │ │
│  │  puros (.astro)      │  │                            │ │
│  └─────────────────────┘  └────────────────────────────┘ │
│                                                          │
│  CSS: Tailwind v4 (compartido)                           │
│  Fonts: Google Fonts (Inter)                             │
└──────────────────────────────────────────────────────────┘
```

**Cambio fundamental:** El Worker deja de hacer SSR. Solo expone API REST + WebSocket. Astro (en Cloudflare Pages o Node) sirve el sitio público y el admin SPA.

### 2.3 Opciones de Deployment para Astro

| Opción | Ventajas | Desventajas |
|--------|----------|-------------|
| **A. Cloudflare Pages + Functions** | Mismo ecosistema CF, gratis, SSR nativo con `@astrojs/cloudflare` | Las Functions son limitadas vs Worker |
| **B. Cloudflare Pages + Worker externo** | Astro solo frontend, API en Worker existente | 2 deployments, CORS cross-origin |
| **C. Mismo Worker (SSR en Astro → Worker)** | Un solo deploy, sin CORS | Complejidad: Astro en Worker requiere `@astrojs/cloudflare` |
| **D. Node (VPS/Vercel/Netlify)** | Máxima flexibilidad | Sale del ecosistema CF, latencia a D1 |

**Recomendación:** **Opción A o C** — mantener todo en Cloudflare. Astro con adapter `@astrojs/cloudflare` puede deployarse a Cloudflare Pages con SSR, o empaquetarse como Worker.

### 2.4 Complejidad de Migración por Componente

| Componente | Complejidad | LOC a migrar | Notas |
|-----------|-------------|-------------|-------|
| **Sitio público SSR** | 🟡 Media | ~2,000 | Los builders de string se convierten en `.astro` templates. La lógica de fetching se mantiene similar. |
| **Admin Layout + Sidebar** | 🟢 Baja | ~160 | Componentes de layout simples |
| **CMS Page** | 🔴 Alta | ~1,900 | Componente más complejo con editor Monaco, paneles SEO, previsualización. Posible isla React. |
| **Media Editor** | 🔴 Alta | ~2,100 | Muchos subcomponentes, lógica de estado compleja. Candidato a isla React. |
| **CRM** | 🔴 Alta | ~3,000 | Muchos componentes interconectados. PERO se va a simplificar. |
| **Intel Hub** | 🟡 Media | ~1,800 | Dashboards, gráficos, tablas. Islas React. |
| **ADN Brand** | 🟢 Baja | ~300 | Formulario simple |
| **Chat** | 🟡 Media | ~800 | WebSocket + PartySocket. Isla React. |
| **Publish** | 🟢 Baja | ~400 | Paneles simples |
| **Login** | 🟢 Baja | ~280 | Formulario simple en Astro |

---

## 3. Simplificación del CRM

### 3.1 Estado Actual del CRM

El CRM actual tiene 16 archivos (~3,000 LOC) con estas funcionalidades:

| Funcionalidad | Archivos | Utilidad para GuardMan |
|--------------|----------|----------------------|
| **Dashboard KPIs** | `CRMDashboard.tsx` | ✅ ESENCIAL — métricas de ventas |
| **Pipeline Kanban** | `CRMPipeline.tsx` | ✅ ESENCIAL — seguimiento de leads |
| **Lead Detail** | `LeadDetail.tsx` | ✅ ESENCIAL — ficha de lead |
| **Client List** | `ClientListView.tsx` | ✅ ÚTIL — cartera de clientes |
| **Client Detail** | `ClientDetailView.tsx` | ✅ ÚTIL — ficha de cliente |
| **Proposals** | `ProposalBuilder.tsx`, `ProposalListView.tsx` | ✅ ÚTIL — cotizaciones |
| **Mi Día** | `CRMMiDia.tsx` | ✅ ÚTIL — agenda diaria del vendedor |
| **Visit Checklist** | `VisitChecklist.tsx` | ✅ ÚTIL — checklist de visita técnica |
| **Mock Data Loader** | `MockDataLoader.tsx` | 🔄 Útil solo para dev/demo |
| **Convert to Client Modal** | `ConvertToClientModal.tsx` | 🟡 Redundante — misma acción que cambiar status |
| **API hooks** | `useMockApi.ts`, `useRealApi.ts` | 🔄 Simplificable — un solo hook con switch |

**Gaps conocidos (auditoría v13):**
- Kanban sin `border-top` colors por etapa
- `PipelineBar` creado pero no usado en ningún workflow
- `SEOScorePanel` creado (140 LOC) pero no integrado en `CMSPage.tsx` — código muerto

### 3.2 Propuesta de Simplificación

**Principio:** El CRM de GuardMan es para un equipo comercial pequeño (1-3 personas). No necesita features enterprise.

**Mantener (ESENCIAL):**
1. **Dashboard** — KPIs comerciales (leads nuevos, pipeline $, ganados, revenue mensual)
2. **Pipeline Kanban** — Columnas por etapa con drag & drop (nuevo → contactado → visita → cotización → negociación → ganado/perdido)
3. **Lead Detail** — Ficha con datos de contacto, historial, interacciones, cotizaciones
4. **Clientes** — Lista simple + ficha de cliente
5. **Cotizaciones** — Crear/ver propuestas comerciales simples

**Eliminar/Simplificar:**
1. ❌ **"Mi Día"** — Fusionar con Dashboard (agenda diaria como sección del dashboard)
2. ❌ **VisitChecklist separado** — Embebido en Lead Detail como sección
3. ❌ **MockDataLoader UI** — Solo modo dev interno
4. ❌ **ConvertToClientModal** — El cambio de status `won → active` ya convierte
5. ❌ **useMockApi / useRealApi** — Unificar en un solo `useApi` con flag de demo
6. ❌ **PipelineBar** (componente huérfano) — Eliminar o integrar correctamente
7. ❌ **Intel Hub integrado al CRM** — Mantener Intel separado como analytics, no mezclar

**Resultado esperado:** CRM reducido de ~3,000 LOC a ~1,200 LOC, de 16 archivos a ~6 archivos.

### 3.3 Endpoints API del CRM Actual

```
GET    /api/crm/dashboard
GET    /api/crm/leads
POST   /api/crm/leads
GET    /api/crm/leads/:id
PUT    /api/crm/leads/:id
GET    /api/crm/leads/:id/interactions
POST   /api/crm/leads/:id/interactions
GET    /api/crm/leads/:id/proposals
POST   /api/crm/leads/:id/proposals
GET    /api/crm/proposals
GET    /api/crm/clients
POST   /api/crm/clients
GET    /api/crm/clients/:id
PUT    /api/crm/clients/:id
GET    /api/crm/pipeline
GET    /api/crm/tasks
POST   /api/crm/tasks
PUT    /api/crm/tasks/:id
GET    /api/crm/visits/:leadId
POST   /api/crm/visits
POST   /api/crm/visits/:id/photos
POST   /api/crm/leads/capture
```

**Simplificación propuesta:**
- Fusionar `/api/crm/tasks` → tasks como array dentro del lead (no tabla separada)
- Fusionar `/api/crm/visits` → visit como objeto dentro del lead
- Eliminar `/api/crm/visits/:id/photos` → las fotos van en R2 con referencia en el lead
- `/api/crm/leads/capture` → es lo mismo que `/api/intel/leads/capture` (está duplicado)

Endpoints finales: **12 → 10** (eliminar tasks y visits separados, consolidar capture)

---

## 4. Estandarización de Código

### 4.1 Problemas Identificados

| Problema | Ubicación | Impacto |
|----------|-----------|---------|
| **CSS_V duplicado** | `src/index.ts` (5 ocurrencias hardcoded) vs `src/ssr/site-renderer.ts` (centralizado) | Bugs de cache |
| **Rutas duplicadas** | CRM leads en `/api/crm/leads/*` Y `/api/intel/leads/*` | Doble mantenimiento |
| **Formato contenido inconsistente** | content_json con 3 formatos: `{sections, seo}`, `{content, seo}`, `{hero, intro, ...}` | Fragilidad |
| **Builders inline en index.ts** | `buildGraciasPage`, `build404Page`, `build500Page` en el router | index.ts muy grande (1,250 LOC) |
| **Dos archivos api.ts** | `src/api.ts` (legacy v7) + `src/api/index.ts` (v5.2 modular) | Confusión |
| **Hooks duplicados** | `useApi`, `useRealApi`, `useMockApi` | Fragilidad |
| **PipelineBar huérfano** | Creado en `Shared/PipelineBar.tsx` y `UI/PipelineBar.tsx`, no usado | Código muerto |
| **SEOScorePanel huérfano** | Creado en `SEOScorePanel.tsx`, no importado en `CMSPage.tsx` | Código muerto |
| **Estilos mezclados** | Tailwind utility classes + CSS custom properties + inline styles | Inconsistencia visual |
| **Tipos duplicados** | `Env` definido en `src/types/index.ts` y `src/api.ts` | Confusión |

### 4.2 Plan de Estandarización

1. **CSS único**: Migrar todo a Tailwind v4 con `@theme` custom. Eliminar CSS custom properties sueltos.
2. **Tipos centralizados**: Un solo archivo `src/types.ts` con todas las interfaces.
3. **API unificada**: Eliminar `src/api.ts` legacy. Consolidar rutas CRM/Intel duplicadas.
4. **Formato contenido único**: `{ sections: {...}, seo: {...} }` para todo.
5. **Builders externos**: Mover builders inline de `index.ts` a `src/ssr/`.
6. **Hooks unificados**: Un solo `useApi` con modo demo.
7. **Código muerto**: Eliminar PipelineBar no usado, SEOScorePanel no integrado, archivos legacy.

---

## 5. Riesgos y Consideraciones

### 5.1 Riesgos Técnicos

| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|-------------|---------|------------|
| Pérdida de funcionalidad en SSR | 🟡 Media | 🔴 Alto | Testing exhaustivo de todas las rutas públicas |
| Incompatibilidad Monaco Editor con Astro | 🟡 Media | 🟡 Medio | Monaco puede ser isla React con `client:only` |
| PartySocket/WebSocket en Astro | 🟢 Baja | 🟡 Medio | `client:only` resuelve, solo corre en browser |
| Performance del admin como islas React | 🟢 Baja | 🟢 Bajo | Las islas React son el patrón canónico de Astro |
| Cold start de Astro SSR en CF | 🟡 Media | 🟡 Medio | Evaluar SSG para páginas públicas + SSR para admin |
| Build time de Astro con 44K LOC | 🟢 Baja | 🟢 Bajo | Astro build es rápido con Vite |

### 5.2 Riesgos de Negocio

| Riesgo | Mitigación |
|--------|------------|
| Downtime durante migración | Deploy en paralelo, switch DNS cuando todo esté listo |
| Pérdida de datos | D1 no se toca, solo se migra la capa de presentación |
| Curva de aprendizaje Astro | El equipo ya conoce Vite/React, Astro es familiar |
| Funcionalidades del CRM que sí se usan | Validar con Rodrigo (CEO) antes de eliminar features |

### 5.3 Lo que NO se Toca

- ❌ D1 schema (tablas, datos)
- ❌ R2 buckets (imágenes)
- ❌ KV namespaces
- ❌ Durable Objects (agentes IA)
- ❌ Workflows (pipelines automatizadas)
- ❌ Cron triggers (scaneos semanales)
- ❌ MCP Server
- ❌ Colas (content queue)
- ❌ AI Gateway / Workers AI bindings
- ❌ Variables de entorno / secrets
- ❌ Dominio y DNS

---

## 6. Métricas de Éxito

| Métrica | Actual | Objetivo Post-Migración |
|---------|--------|------------------------|
| LOC totales TypeScript | ~44,000 | ~30,000 (-32%) |
| Archivos TypeScript | 204 | ~150 (-26%) |
| Archivos CRM | 16 | 6 (-62%) |
| LOC CRM | ~3,000 | ~1,200 (-60%) |
| Build time | 2.3s (Vite) | < 5s (Astro + Vite) |
| Bundle size admin SPA | ~495KB | < 400KB (Astro code splitting) |
| Lighthouse homepage | 85+ | 95+ (Astro optimiza HTML output) |
| Tests pasando | 192 | ≥ 192 (sin regresiones) |
| Endpoints API | 18 módulos | 16 módulos (consolidación) |
| Deployments | 1 Worker | 1 Pages + 1 Worker (o 1 solo) |

---

## Resumen Ejecutivo

El proyecto GuardMan Admin es altamente migrable a Astro. La arquitectura propuesta separa claramente:

1. **Infraestructura backend** (Worker con API, D1, R2, KV, DO, Workflows) — **permanece intacta**
2. **Sitio público** (SSR) — **migra a páginas Astro** puras, eliminando los string builders
3. **Admin SPA** — **migra a Astro con islas React** para componentes complejos (Monaco, Chat WebSocket, Media Editor)
4. **CRM** — **se simplifica** de 16 archivos a 6, eliminando features redundantes

La migración es incremental: se puede hacer por fases, manteniendo el sistema actual en producción hasta que cada fase esté validada.
