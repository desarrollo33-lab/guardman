# Auditoría Forense — CMS Editor /admin
## GuardMan Admin · Generación de Contenido con IA
**Fecha:** 2026-05-10 · **Auditor:** Pi Coding Agent · **Alcance:** `/admin` CMS → D1 → SSR

---

## 1. Resumen Ejecutivo

El sistema de generación de contenido del CMS en `/admin` presenta **fallos estructurales críticos** que explican comportamientos erráticos, contenido vacío, merges destructivos y pérdida de datos. La arquitectura actual tiene **dos proveedores de IA enfrentados** (DeepSeek vs MiniMax), **tres formatos de persistencia incompatibles** y un frontend con lógica de merge que sobrescribe campos esenciales.

**Estado de salud general:** 🔴 Crítico — funciona intermitentemente por acumulación de parches, no por diseño robusto.

---

## 2. Hallazgos Críticos (Causan Fallo Directo)

### 🔴 H-01 — "Dual Provider Chaos": Dos APIs de IA en guerra
**Archivos:** `src/services/ai.ts`, `src/api/routes/cms.ts`, `src/services/content-generation.ts`, `src/services/inference.ts`

| Endpoint del CMS | Proveedor real | URL destino | Variable de entorno |
|---|---|---|---|
| **Generar** (`/api/cms/generate`) | DeepSeek | `api.deepseek.com/v1/chat/completions` | `MINIMAX_API_KEY` |
| **Regenerar** (`/api/cms/regenerate`) | DeepSeek | `api.deepseek.com` vía `callMiniMaxAI` | `MINIMAX_API_KEY` |
| **Review (Workers AI)** | Cloudflare | `gateway.ai.cloudflare.com` | `AI_GATEWAY_TOKEN` |
| **Fallback directo** | MiniMax | `api.minimax.io/anthropic/v1/messages` | `MINIMAX_API_KEY` |
| **Content Agent DO** | DeepSeek | `api.deepseek.com` vía `callMiniMaxAI` | `MINIMAX_API_KEY` |

**Problema:** La función `callMiniMaxAI()` no llama a MiniMax. Llama a **DeepSeek**. Si la API key almacenada en `MINIMAX_API_KEY` es realmente una key de MiniMax (y no de DeepSeek), todas las llamadas de generación del CMS fallarán con `401 Unauthorized`. Si es una key de DeepSeek, los fallbacks a MiniMax (`inferDirect` en `inference.ts`) fallarán.

**Impacto:** El botón "Generar contenido" y "Regenerar con IA" pueden devolver errores `500` o contenido vacío sin explicación clara para el usuario.

**Evidencia:**
```ts
// src/services/ai.ts:298
const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${env.MINIMAX_API_KEY}` }, // ← key de MiniMax apuntando a DeepSeek
```

---

### 🔴 H-02 — Prompt de Homepage excede límite de tokens
**Archivo:** `src/services/ai.ts:201-230`

El prompt para generar la homepage incluye:
- Estructura JSON exacta de 10 secciones con todos sus campos
- Reglas críticas de 10 líneas
- Datos reales forzados (teléfono, email, dirección)
- Contexto de investigación Serper (competidores, keywords, gaps)
- Contexto semántico AI Search (brand DNA, FAQs, keywords estratégicos)
- Contexto de imágenes existentes
- Instrucciones de localización

**Estimación:** El prompt base supera los **3.000 tokens**. Con el contexto Serper + D1 enrichment, puede alcanzar **5.000-6.000 tokens**. DeepSeek `deepseek-chat` tiene contexto de 4K-8K dependiendo de la versión, pero si el prompt ocupa casi todo el contexto, la respuesta JSON se trunca.

**Impacto:** La IA devuelve JSON incompleto (faltan cierres de `}` o `]`), `JSON.parse()` lanza excepción y la generación falla con "No JSON found in AI response".

**Evidencia:**
```ts
// src/services/ai.ts:221
prompt += `IMPORTANT: Usa EXACTAMENTE estas secciones y nombres de campos...`;
// + ~200 líneas más de estructura fija
```

---

### 🔴 H-03 — JSON.parse sin blindaje en el servicio de IA principal
**Archivo:** `src/services/ai.ts:310-315`

```ts
const data = await response.json() as any;
let text = data.choices?.[0]?.message?.content || '';
// ... stripping markdown ...
const parsed = JSON.parse(text) as GeneratedContent; // ← SIN try/catch
```

Si DeepSeek devuelve:
- JSON con comentarios (`// explicación`)
- Texto truncado por límite de tokens
- Markdown mal cerrado
- Respuesta de error empaquetada como texto

...la excepción `JSON.parse` **no es capturada** dentro de `callMiniMaxAI`. El caller (`generateContent` en `cms.ts` o el Content Agent) recibe un `500` opaco.

**Nota:** `cms.ts` tiene try/catch en su handler, pero `ai.ts` no maneja el caso de "JSON malformado dentro de una respuesta HTTP 200".

---

### 🔴 H-04 — Merge destructivo en el frontend (CMSPage.tsx)
**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx:535-620`

La función `regenerateContent` hace un `deepMerge` para preservar campos críticos, pero la lista de campos preservados es **incompleta**:

**Sí preserva:** `hero.image`, `intro.image`, `hero.badge`, `hero.cta1_text/cta1_href`, `hero.cta2_text/cta2_href`, `clientes.items`, `nosotros.image`, `guardpod.image`, `ajax.image`.

**NO preserva:**
- `homeServices` (array de servicios del homepage)
- `homeSectors` (array de sectores del homepage)
- `homeZones` (zonas de ubicaciones del homepage)
- `homeClientLogos` (logos de clientes)
- `stats` (en páginas estáticas como Guard Pod / Ajax)
- `hero_ctas` (CTAs del hero en estáticas)
- `trust_badges` (cotización)
- `body_content` (privacidad/términos)

**Impacto:** Al hacer clic en "Regenerar con IA", se pueden perder secciones completas del homepage o de páginas estáticas que fueron editadas manualmente.

**Evidencia:**
```ts
// Solo preserva imágenes de 3 secciones:
const sectionsWithImages = ['nosotros','guardpod','ajax'];
// Falta: 'servicios', 'sectores', 'ubicaciones', 'clientes', 'cta_final', etc.
```

---

### 🔴 H-05 — Doble fuente de verdad en Homepage
**Archivos:** `src/api/routes/cms.ts:230-280`, `src/services/content-generation.ts`

El homepage se guarda en **dos tablas simultáneamente**:
1. `content_versions` (entity_type='page', entity_slug='homepage')
2. `static_page_content` (slug='homepage')

Si la inserción en `content_versions` falla (por constraint o timeout), el CMS responde `ok: true` igualmente porque el `catch` solo hace `console.warn`. El frontend cree que guardó, pero `content_versions` no tiene la versión.

**Impacto:**
- El endpoint `/api/cms/homepage` lee de `static_page_content`, por lo que parece funcionar.
- Pero el Content Agent y el pipeline de calidad leen de `content_versions`, por lo que evalúan contenido desactualizado.
- La invalidación de caché solo usa `invalidateCache(env, 'homepage')`, sin especificar si es static o content version.

---

## 3. Hallazgos de Arquitectura (Deuda Técnica Grave)

### 🟠 A-01 — Tres formatos de persistencia incompatibles

| Tipo de página | Tabla | Formato esperado por SSR | Formato guardado por CMS |
|---|---|---|---|
| Servicios | `content_versions` | `{ sections: { hero, intro, features... }, seo: {...} }` | `{ sections, seo }` ✅ |
| Homepage | `static_page_content` + `content_versions` | `{ content: { hero, nosotros, servicios... }, seo: {...} }` | `{ content, seo }` (UI) → `{ sections, seo }` (DB save) ❌ |
| Páginas estáticas | `static_page_content` | `{ content: { hero, stats, features... }, seo: {...} }` | `{ content, seo }` (UI) → columnas planas + JSON anidado ❌ |
| Combos | `combo_content` | columnas planas (`h1`, `intro_paragraph`) | columnas planas + `content_json` opcional ❌ |

El SSR (`site-data.ts`, `site-renderer.ts`) tiene múltiples rutas de fallback:
```ts
// site-data.ts: parseJson → content?.sections || content || {}
const sections = content?.sections || content || {};
```
Esto oculta el problema pero hace que el comportamiento sea no determinista.

---

### 🟠 A-02 — El CMS no usa el pipeline unificado
**Archivo:** `src/api/routes/cms.ts:505-580`

`/api/cms/regenerate` llama a `generateContent()` del servicio unificado (`content-generation.ts`), pero `/api/cms/generate` tiene **su propia implementación duplicada**:
- Construye el prompt a mano
- Llama a `fetch('https://api.minimax.io/...')` directamente
- No pasa por guardrails, banned patterns, ni LLM review
- Guarda el resultado directo en `content_versions`

**Impacto:** El botón "Generar" produce contenido de menor calidad y sin revisión de calidad, mientras que "Regenerar" pasa por el pipeline completo.

---

### 🟠 A-03 — Content Agent (Durable Object) está huérfano
**Archivo:** `src/agents/content-agent.ts`

El `GMContentAgent` es un Durable Object sofisticado con:
- Fibers para recuperación ante crashes
- Iteración de hasta 3 intentos con feedback
- Auto-approve si score ≥ 85
- Broadcasting por WebSocket

**Pero:** No hay evidencia de que el CMS lo use. El frontend llama a endpoints REST (`/api/cms/generate`, `/api/cms/regenerate`). El Content Agent solo se activaría si:
- Se usa WebSocket directo (`/api/agents/content-agent`)
- Se ejecuta un workflow (`BulkGenerateWorkflow`, etc.)

**Impacto:** Se mantienen ~500 líneas de código complejo que no están integradas al flujo principal del CMS. Esto genera confusión y duplicación lógica.

---

### 🟠 A-04 — Cache invalidation inconsistente
**Archivos:** `src/services/cache.ts`, `src/api/routes/cms.ts`, `src/index.ts`

- Al guardar servicio: `invalidateCache(env, entityType, invSlug)`
- Al guardar homepage: `invalidateCache(env, 'homepage')`
- Al guardar static page: `invalidateCache(env, 'static', staticSlug)`
- Al guardar combo: sin invalidación explícita de cache de combos
- El SSR usa `getCacheKey` con prefijos como `page:static:`, `page:service:`, `page:combo:`, pero no hay mapeo claro entre el tipo usado en invalidación y el tipo usado en lectura.

**Impacto:** Cambios en el CMS pueden no reflejarse en el sitio público hasta que expire el TTL de KV (1 hora por defecto).

---

## 4. Hallazgos de Seguridad

### 🟡 S-01 — Auth token como password de login
**Archivo:** `src/api/middleware/auth.ts`, `src/index.ts`

```ts
// login endpoint
if (body.password === env.AUTH_TOKEN) { ... }
```

El mismo `AUTH_TOKEN` se usa como:
- Contraseña del panel de administración
- Bearer token para todas las APIs
- Token de WebSocket para agents

**Impacto:** Si el token se filtra (logs, frontend en localStorage, repo), un atacante tiene acceso total sin posibilidad de rotación selectiva.

---

### 🟡 S-02 — CORS abierto en endpoints sensibles
**Archivo:** `src/types/index.ts` (CORS_HEADERS)

```ts
'Access-Control-Allow-Origin': '*'
```

Aplicado globalmente a `/api/cms/*`, `/api/content/*`, `/api/media/*`. Aunque requieren auth, un sitio malicioso puede hacer preflight requests y extraer información de tiempos de respuesta (timing attacks) o intentar CSRF con credenciales.

---

### 🟡 S-03 — LocalStorage para token de sesión
**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx`

```ts
headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` }
```

El token se almacena en `localStorage` sin expiración. Vulnerable a XSS si algún componente renderiza HTML sin sanitizar.

---

## 5. Análisis de Flujo de Datos (Generación completa)

```
┌──────────────┐     ┌─────────────────┐     ┌──────────────────┐
│  Admin UI    │────▶│ /api/cms/generate│────▶│  cms.ts          │
│  (CMSPage.tsx)│     │  (POST)          │     │  Prompt propio   │
└──────────────┘     └─────────────────┘     │  Llama MiniMax   │
                                             │  (en realidad    │
                                             │   DeepSeek)      │
                                             └────────┬─────────┘
                                                      │
                              ┌───────────────────────┘
                              ▼
                    ┌─────────────────┐
                    │  DeepSeek API   │
                    │  (o MiniMax?)   │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  JSON crudo     │
                    │  (sin guardrails)│
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  content_versions│
                    │  (DB D1)        │
                    └────────┬────────┘
                             │
                             ▼
                    ┌─────────────────┐
                    │  SSR site-data  │
                    │  (fetchService) │
                    └─────────────────┘
```

**Observación:** No hay paso de calidad entre la generación y la persistencia para `/api/cms/generate`. El contenido se guarda "tal cual" llega de la IA.

---

## 6. Recomendaciones Priorizadas

### P0 — Corrección Inmediata (Bloqueante)

1. **Unificar proveedor de IA**
   - Decidir si se usa DeepSeek o MiniMax.
   - Renombrar `MINIMAX_API_KEY` → `AI_API_KEY` o crear `DEEPSEEK_API_KEY`.
   - Actualizar `callMiniMaxAI` para que el nombre coincida con la URL, o mejor: crear `callAI(provider, ...)`.

2. **Blindar JSON.parse en `ai.ts`**
   ```ts
   let parsed;
   try {
     parsed = JSON.parse(text);
   } catch (e) {
     console.error('[AI] JSON parse failed. Raw:', text.substring(0, 500));
     throw new Error('AI returned invalid JSON');
   }
   ```

3. **Truncar prompt de homepage**
   - Mover la estructura JSON exacta a un template en `src/services/templates/homepage.json`
   - En el prompt solo referenciar: "Sigue la estructura de homepage.json"
   - Reducir contexto Serper a top 3 resultados y top 5 keywords.

### P1 — Alta Prioridad (Estabilidad)

4. **Eliminar `/api/cms/generate` duplicado**
   - Hacer que `/api/cms/generate` sea un wrapper de `generateContent()` del pipeline unificado.
   - Eliminar el prompt hardcodeado en `cms.ts`.

5. **Completar lista de preservación en CMSPage.tsx**
   - Agregar `homeServices`, `homeSectors`, `homeZones`, `homeClientLogos`, `stats`, `hero_ctas`, `trust_badges`, `body_content` al merge de regeneración.
   - O mejor: usar un merge inverso: "toma el nuevo contenido de la IA y le inyectas solo los campos que sabes que la IA no debe tocar".

6. **Estandarizar formato de persistencia**
   - Decidir UN formato: `{ seo, content }` (UI-friendly) o `{ sections, seo }` (DB-friendly).
   - Crear una capa de normalización (`normalizeToDB()`, `normalizeFromDB()`) en `cms.ts`.

### P2 — Media Prioridad (Deuda Técnica)

7. **Integrar o eliminar Content Agent**
   - Opción A: Hacer que el frontend use WebSocket contra el Content Agent para generación.
   - Opción B: Eliminar `GMContentAgent` y consolidar toda la lógica en el servicio REST.

8. **Separar Auth Token de Password**
   - Crear tabla `admin_users` con hashes bcrypt.
   - Generar JWTs de corta duración (2h) para la sesión.
   - Mantener `AUTH_TOKEN` solo para API interna worker→worker.

9. **Cache keys audit**
   - Documentar el mapa de `invalidateCache(type, slug)` → `getCacheKey(type, slug)`.
   - Agregar tests que validen que guardar contenido invalida la cache del SSR.

---

## 7. Métricas de Riesgo

| Riesgo | Severidad | Probabilidad | Detección |
|---|---|---|---|
| Key API inválida (DeepSeek vs MiniMax) | 🔴 Crítica | 🔴 Alta | 🟡 Media (logs de worker) |
| JSON truncado / parse error | 🔴 Crítica | 🟠 Media | 🟡 Media (sentry/logs) |
| Merge destructivo en homepage | 🔴 Crítica | 🟠 Media | 🟢 Alta (usuario lo ve) |
| Cache stale después de guardar | 🟠 Alta | 🟠 Media | 🔴 Baja (difícil de detectar) |
| Auth token expuesto | 🟠 Alta | 🟡 Baja | 🟡 Media |
| Content Agent sin uso | 🟡 Media | 🟢 Cierta | 🟢 Alta (código muerto) |

---

## 8. Próximos Pasos Sugeridos

1. **Validar qué API key se está usando:** Revisar en Cloudflare Dashboard el valor de `MINIMAX_API_KEY`. ¿Es de DeepSeek o MiniMax?
2. **Revisar logs de worker:** Buscar errores `DeepSeek API error` o `JSON parse failed` en los últimos 7 días.
3. **Probar generación de homepage:** Verificar si el prompt actual produce respuestas completas o truncadas.
4. **Definir sesión de arquitectura:** Decidir si se consolida todo en el pipeline unificado (`content-generation.ts`) o si se separan generación y regeneración.

---

*Fin del reporte. Preparado para discusión y priorización de fixes.*
