# Auditoría Forense — CRM GuardMan Admin (/admin)
**Fecha:** 2026-05-10  
**Alcance:** Frontend CRM (React) + Backend CRM (Worker/D1)  
**Estado:** Funcional al ~70%. Necesita refactors críticos para 100%.

---

## Hallazgos Críticos

### 🔴 CRÍTICO — Frontend

| ID | Hallazgo | Impacto | Archivo(s) |
|---|---|---|---|
| CRM-FE-01 | **Duplicación de exports**: `StatusBadge`, `DifficultyBadge`, `fmt` se definen en `CRMPage.tsx` Y en `CRMDashboard.tsx` | Colisiones, bundle innecesario | `CRMPage.tsx`, `CRMDashboard.tsx` |
| CRM-FE-02 | **Abuso de `any`**: Todo el CRM usa `any` masivamente. Cero type safety | Bugs silenciosos, refactors imposibles | Todos los `CRM/*.tsx` |
| CRM-FE-03 | **Errores silenciados**: `.catch(() => {})` en todos los `useEffect` API calls | UX rota, loading infinito, sin feedback | `CRMPipeline.tsx`, `CRMDashboard.tsx`, `CRMMiDia.tsx`, etc. |
| CRM-FE-04 | **LeadDetail.tsx monolito**: 450+ líneas con 4 modales inline (`InteractionModal`, `LossModal`, `NewProposalModal`, etc.) | Violación SRP, imposible testear | `LeadDetail.tsx` |
| CRM-FE-05 | **Math.random() en ProposalPreview** para número de cotización | No deterministico, imposible reproducir | `ProposalBuilder.tsx` |
| CRM-FE-06 | **Inconsistencia API shape**: `CRMMiDia` espera `data?.data?.mi_dia` mientras `CRMDashboard` usa `data.leads` | Si el backend cambia, un tab falla y otro no | `CRMMiDia.tsx` vs `CRMDashboard.tsx` |
| CRM-FE-07 | **Sin validación de formularios**: Nuevo lead, interacción, propuesta — no validan campos antes de enviar | Datos corruptos en D1 | `CRMPipeline.tsx`, `LeadDetail.tsx` |
| CRM-FE-08 | **Sin paginación en ClientListView**: Carga TODOS los clientes en memoria | Crash con >500 clientes | `ClientListView.tsx` |
| CRM-FE-09 | **Sin loading granulado**: Un solo `loading` global bloquea toda la UI | UX pobre en conexiones lentas | Todos los componentes CRM |
| CRM-FE-10 | **useApi no maneja 401/403**: Si el token expira, los requests fallan silenciosamente | Sesión "zombie" | `useApi.ts` |

### 🔴 CRÍTICO — Backend

| ID | Hallazgo | Impacto | Archivo(s) |
|---|---|---|---|
| CRM-BE-01 | **Sin rate limiting en `/api/crm/leads/capture`** | Público, vulnerable a spam masivo | `crm/index.ts` |
| CRM-BE-02 | **Sin validación de schema en handleCreateLead** | Puede crear leads con `contact_name` vacío | `crm/leads.ts` |
| CRM-BE-03 | **Sin soft delete / auditoría**: No hay `created_by`, `updated_by`, `deleted_at` | Compliance imposible, sin trazabilidad | Todas las tablas `intel_*` |
| CRM-BE-04 | **CORS duplicado**: Cada handler repite `{ headers: cors }` | Código duplicado, riesgo de inconsistencia | Todos los `crm/*.ts` |
| CRM-BE-05 | **handleUpdateLead permite saltarse lógica de negocio** (excepto visita para proposal_sent) | Estado inválido posible | `crm/leads.ts` |
| CRM-BE-06 | **Nombre de tablas legacy**: `intel_*` en lugar de `crm_*` | Deuda técnica, confusión para nuevos devs | Schema SQL |
| CRM-BE-07 | **No hay endpoint DELETE para leads/clientes** | Imposible limpiar datos de prueba | `crm/index.ts` |
| CRM-BE-08 | **handleListLeads search usa LIKE con bind** — aunque seguro, el patrón `%?%` con bind no funciona en SQLite D1 si no se concatena correctamente | Potencial bug de búsqueda | `crm/leads.ts` |

### 🟡 MAYOR — Código Limpio

| ID | Hallazgo | Impacto |
|---|---|---|
| CRM-CL-01 | **Mix de inline styles y Tailwind**: Algunos componentes usan `style={{}}` y otros `className` | Inconsistencia visual, difícil mantener |
| CRM-CL-02 | **useEffect sin cleanup**: Posibles memory leaks en componentes desmontados | Degradación de performance |
| CRM-CL-03 | **No hay custom hooks para CRM**: Lógica de fetch duplicada en cada componente | DRY violado |
| CRM-CL-04 | **Props drilling excesivo**: `onSelectLead` pasa por 4+ niveles | Difícil rastrear flujo de datos |
| CRM-CL-05 | **Constantes duplicadas**: `STAGES` definido en `CRMPipeline.tsx` y también usado implícitamente en `CRMDashboard.tsx` | Inconsistencia si cambia el pipeline |

---

## Recomendaciones para 100% Operabilidad

### 1. Refactor Inmediato (Hotfixes)
1. **Centralizar utilidades**: Crear `guardman-admin-ui/src/components/CRM/utils.tsx` con `StatusBadge`, `DifficultyBadge`, `fmt`, `daysSince`
2. **Eliminar `.catch(() => {})`**: Reemplazar por `.catch(err => toast.error(err.message))` o similar
3. **Extraer modales de LeadDetail**: Crear `components/CRM/modals/` con cada modal como componente independiente
4. **Agregar validación mínima**: `contact_name` required, `estimated_value >= 0`

### 2. Mejoras Estructurales
1. **Renombrar tablas `intel_*` → `crm_*`** con migración D1
2. **Agregar Zod schemas** para validación de request body en backend
3. **Implementar paginación** en `handleListClients` y `handleListLeads`
4. **Agregar `created_by`, `updated_by`** a todas las tablas CRM
5. **Rate limit en `/api/crm/leads/capture`**: Max 5 requests/IP/minuto

### 3. Tests Necesarios
- Backend: CRUD leads, validación de estados, pipeline aggregation
- Frontend: Render de dashboard, pipeline kanban, form validation, modal flows
- Integration: Lead → Visit → Proposal → Won → Client (flujo completo)

---

## Mock Data Necesaria
Para testear el CRM sin dependencia de D1, se requiere:
- **12 Leads** distribuidos en los 7 estados del pipeline
- **5 Clientes** (3 activos, 1 pausado, 1 churned)
- **8 Interacciones** vinculadas a leads
- **4 Propuestas** (2 draft, 1 sent, 1 accepted)
- **3 Visitas técnicas** (2 completadas, 1 pendiente)

*Mocks generados en: `tests/mocks/crm-mocks.ts` y `sql/seed-crm-mocks.sql`*
