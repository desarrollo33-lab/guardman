-- Reemplazar "prospecto" por "persona interesada" o "cliente potencial"
-- Reemplazar "semántico" por algo natural
-- Reemplazar "embudo" por "flujo"

UPDATE ceo_questionnaire_questions
SET subtitle_es = 'Una, dos, tres, más. ¿Cuántos contactos tiene con una persona interesada antes de que firme?'
WHERE id = 'com_04';

UPDATE ceo_questionnaire_questions
SET subtitle_es = 'Un número aproximado. ¿Días, semanas, meses?'
WHERE id = 'com_06';

UPDATE ceo_questionnaire_questions
SET objective_es = 'Esta objeción se publica como una pregunta frecuente con su respuesta. Si el material responde la objeción antes de que la persona interesada la formule, la tasa de cierre sube.'
WHERE id = 'com_03';

UPDATE ceo_questionnaire_questions
SET objective_es = 'Este número se publica como prueba de trayectoria. Es uno de los indicadores de confianza más buscados por las personas interesadas.'
WHERE id = 'srv_16';

UPDATE ceo_questionnaire_questions
SET helper_text = 'Se recomienda elegir entre 8 y 10 palabras para mantener el foco en un solo tema.'
WHERE id = 'id_04';

UPDATE ceo_questionnaire_sections
SET description = 'Ocho preguntas sobre cómo se decide la gente, cuánto tiempo toma, qué objeciones escucha y por qué algunos clientes se van. Las respuestas afinan el flujo de ventas y el material de presentación para reducir la distancia entre el primer contacto y la firma.'
WHERE id = 'comercial';
