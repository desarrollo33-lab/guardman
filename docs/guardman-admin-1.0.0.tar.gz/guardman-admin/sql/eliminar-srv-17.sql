-- Eliminar pregunta srv_17 (fotos/videos) y reordenar las siguientes
DELETE FROM ceo_questionnaire_questions WHERE id = 'srv_17';

-- Reordenar sort_order para que no queden huecos
UPDATE ceo_questionnaire_questions SET sort_order = 17 WHERE id = 'srv_18';
UPDATE ceo_questionnaire_questions SET sort_order = 18 WHERE id = 'srv_19';
UPDATE ceo_questionnaire_questions SET sort_order = 19 WHERE id = 'srv_20';
UPDATE ceo_questionnaire_questions SET sort_order = 20 WHERE id = 'srv_21';
