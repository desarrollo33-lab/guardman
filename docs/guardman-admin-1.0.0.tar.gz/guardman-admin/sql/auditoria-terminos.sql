-- Auditoría de términos prohibidos (un campo por vez)
-- Genera un solo JSON con todas las coincidencias

-- 1. questions
SELECT id, 'question_es' AS campo, question_es AS texto
FROM ceo_questionnaire_questions
WHERE question_es LIKE '%SEO%' OR question_es LIKE '%seo%' COLLATE NOCASE
   OR question_es LIKE '%google%' COLLATE NOCASE OR question_es LIKE '%Google%'
   OR question_es LIKE '%buscador%' COLLATE NOCASE
   OR question_es LIKE '%posicionamiento%' COLLATE NOCASE
   OR question_es LIKE '%marketing%' COLLATE NOCASE
   OR question_es LIKE '%keyword%' COLLATE NOCASE
   OR question_es LIKE '%ranking%' COLLATE NOCASE;
