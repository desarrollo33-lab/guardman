-- ============================================================
-- Actualización de preguntas a español neutro + objetivos
-- Secciones 2, 3, 4 y 5
-- ============================================================

-- ============================================================
-- SECCIÓN 2: SERVICIOS Y OPERACIÓN
-- ============================================================

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué servicios ofrece GuardMan en la actualidad?',
  subtitle_es = 'El catálogo real, no el aspiracional. Marque todos los que apliquen.',
  objective_es = 'Inventariar el portafolio real de servicios para alimentar el sitio web, el modelo de cotización, la estructura del equipo comercial y el catálogo de propuestas.',
  options_json = '["Portería en edificios residenciales","Portería en oficinas y empresas corporativas","Rondas y vigilancia perimetral","Control de acceso (recepción, torniquetes, lectores)","Conserjería (recepción con tareas administrativas)","Seguridad para retail y locales comerciales","Seguridad para eventos (conciertos, ferias, corporativos)","Escolta privada y protección de personas","Monitoreo de cámaras de seguridad y alarmas","Asesoría y auditoría de seguridad","Instalación de sistemas (cámaras, alarmas, control de acceso)","Investigaciones privadas","Seguridad para condominios y comunidades","Seguridad industrial y faenas","Servicios de bínting y choferes de reemplazo","Servicios de mudanza y traslado de valores"]'
WHERE id = 'srv_01';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene los servicios por importancia de generación de ingresos (1 = mayor ingreso):',
  subtitle_es = 'Use las flechas para reordenar la lista.',
  objective_es = 'Determinar cuáles servicios concentran el grueso de los ingresos. El primer tercio de la lista suele representar más del 70% de la facturación, lo que orienta dónde invertir en retención y desarrollo.',
  options_json = '["Portería en edificios","Portería en oficinas","Rondas perimetrales","Control de acceso","Conserjería","Seguridad retail","Seguridad para eventos","Monitoreo CCTV y alarmas","Escolta privada","Auditoría y asesoría de seguridad"]'
WHERE id = 'srv_02';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuál es la cobertura geográfica actual de GuardMan?',
  subtitle_es = NULL,
  objective_es = 'Caracterizar la huella territorial actual, lo cual define la promesa de cobertura, las metas de expansión y los modelos de servicio en zonas alejadas.',
  options_json = '["Solo Santiago, en algunas comunas específicas","Santiago completo (más de cuarenta comunas)","Santiago más una o dos regiones (Valparaíso, Rancagua u otras)","Nacional completo (todas las regiones del país)","Otra configuración (describir en el espacio libre)"]'
WHERE id = 'srv_03';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene los grupos de comunas por importancia estratégica para GuardMan (1 = mayor importancia):',
  subtitle_es = 'Esto permite entender dónde concentrar la inversión en marketing y operaciones.',
  objective_es = 'Identificar las zonas prioritarias para asignar presupuesto de marketing, supervisores de zona y densidad de servicio.',
  options_json = '["Las Condes, Vitacura y Lo Barnechea","Providencia, Ñuñoa y Santiago centro","Maipú, Pudahuel y Estación Central","Puente Alto y San Bernardo","La Florida, Macul y Peñalolén","Conchalí, Recoleta e Independencia","San Miguel, San Joaquín y Quinta Normal","Cerrillos, Cerro Navia y Lo Prado"]'
WHERE id = 'srv_04';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué tan estandarizados están los servicios?',
  subtitle_es = '1 = cada cliente recibe un servicio a medida, configurado de forma artesanal. 10 = el servicio es idéntico para todos y se configura solo con parámetros.',
  objective_es = 'Medir el nivel de estandarización operativa, lo cual determina la complejidad para escalar y la velocidad con la que GuardMan puede absorber nuevos clientes sin contratar más personal de coordinación.'
WHERE id = 'srv_05';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuál es el modelo principal de cobro?',
  subtitle_es = NULL,
  objective_es = 'Caracterizar el modelo de revenue, lo que define la previsibilidad de ingresos, los indicadores financieros clave y la estructura del contrato con el cliente.',
  options_json = '["Mensual fijo por guardia asignado (turno completo)","Mensual fijo por horas contratadas","Por evento (eventos puntuales, escoltas, servicios esporádicos)","Modelo mixto: mensual para contratos base más cobro por evento para servicios adicionales","Modelo mixto: tarifa base más un componente variable según las horas reales trabajadas"]'
WHERE id = 'srv_06';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Debería GuardMan contar con una central de monitoreo propia, operativa 24/7?',
  subtitle_es = 'Sí implica invertir en infraestructura, software y operadores. No significa tercerizar el servicio con un socio estratégico.',
  objective_es = 'Decidir sobre una de las inversiones de capital más relevantes del modelo operativo, con impacto directo en la propuesta de valor, los costos fijos y la capacidad de ofrecer servicios diferenciados.'
WHERE id = 'srv_07';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Describa el proceso de incorporación de un nuevo cliente.',
  subtitle_es = 'Desde el primer contacto hasta que el primer guardia se presenta en el puesto. ¿Cuántos días toma? ¿Qué pasos sigue? ¿Quién aprueba cada etapa?',
  objective_es = 'Documentar el proceso de onboarding, identificar cuellos de botella y detectar oportunidades de automatización para reducir el tiempo entre la firma del contrato y el inicio efectivo del servicio.'
WHERE id = 'srv_08';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Debería GuardMan ofrecer garantía de servicio?',
  subtitle_es = 'Por ejemplo, si no se cumple el SLA definido, se devuelve un porcentaje de la cuota mensual. Sí es un diferenciador potente pero costoso ante errores. No es el modelo tradicional, con menor riesgo financiero.',
  objective_es = 'Decidir sobre un elemento de posicionamiento de marca con implicaciones financieras, operativas y contractuales profundas.'
WHERE id = 'srv_09';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué tan importante es la tecnología? (aplicación del cliente, aplicación del guardia, panel de control, seguimiento por GPS, entre otros)',
  subtitle_es = '1 = irrelevante, todo se resuelve con radio y teléfono. 10 = absolutamente central, sin tecnología no se puede competir.',
  objective_es = 'Calibrar el peso de la tecnología en la propuesta de valor, lo que define el presupuesto de TI, el roadmap de producto y el perfil del guardia que se necesita contratar.'
WHERE id = 'srv_10';

-- ============================================================
-- SECCIÓN 3: ESTRATEGIA COMERCIAL Y CLIENTES
-- ============================================================

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuál es el cliente principal de GuardMan en la actualidad?',
  subtitle_es = NULL,
  objective_es = 'Identificar el segmento dominante de la cartera actual, lo que define a quién se habla primero en el sitio, en la publicidad y en el discurso comercial.',
  options_json = '["Edificios residenciales (comunidades y condominios)","Oficinas y empresas corporativas","Retail y locales comerciales","Sector industrial y faenas","Productores de eventos","Residenciales premium (casas particulares)","Una mezcla heterogénea sin predominio claro"]'
WHERE id = 'com_01';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene los segmentos por prioridad estratégica para los próximos doce meses (1 = mayor prioridad):',
  subtitle_es = NULL,
  objective_es = 'Definir hacia dónde dirigir el esfuerzo comercial y la inversión de marketing durante el próximo año.',
  options_json = '["Edificios residenciales","Oficinas corporativas","Retail","Sector industrial","Eventos","Residencial premium","Condominios"]'
WHERE id = 'com_02';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué tan exclusiva es GuardMan?',
  subtitle_es = '1 = aceptamos a cualquier cliente que cuente con presupuesto. 10 = somos altamente selectivos, con criterios estrictos de entrada.',
  objective_es = 'Definir el balance entre velocidad de crecimiento y calidad de la cartera. Esta calibración determina la estrategia de precios y los criterios de aceptación de clientes.'
WHERE id = 'com_03';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene los canales de captación por efectividad actual (1 = el que más leads convierte):',
  subtitle_es = NULL,
  objective_es = 'Determinar dónde colocar el presupuesto de marketing. Los primeros tres canales suelen concentrar la mayor parte del retorno, lo que evita dispersión de recursos.',
  options_json = '["Recomendaciones de clientes actuales","Búsqueda en Google (posicionamiento orgánico)","Google Ads y Meta Ads","WhatsApp directo y redes sociales","Visitas en terreno (preventas)","Ruedas de negocios y eventos del rubro","LinkedIn (especialmente para clientes corporativos)","Tráfico orgánico al sitio web"]'
WHERE id = 'com_04';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Describa el ciclo de venta típico de GuardMan.',
  subtitle_es = 'Desde que un cliente toma contacto hasta que firma el contrato. ¿Cuántas reuniones se realizan? ¿Quiénes participan? ¿Cuántos días toma? ¿Cuál es la objeción más frecuente?',
  objective_es = 'Caracterizar el ciclo de venta para identificar cuellos de botella, calcular el costo de adquisición de clientes y diseñar un proceso comercial replicable.'
WHERE id = 'com_05';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Debería GuardMan trabajar con contratos anuales con renovación automática?',
  subtitle_es = 'Sí aporta previsibilidad de ingresos pero rigidez. No ofrece flexibilidad pero menor previsibilidad.',
  objective_es = 'Decidir la estructura contractual que define la previsibilidad financiera y el nivel de fricción administrativa con el cliente.'
WHERE id = 'com_06';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Relate un caso de éxito memorable de GuardMan.',
  subtitle_es = 'Un cliente real (o anonimizado) en el que el servicio de GuardMan marcó una diferencia concreta. Qué ocurrió, cómo actuó el equipo, qué ganó el cliente. Si no existe, describa un caso representativo.',
  objective_es = 'Recopilar material para el discurso de ventas, las propuestas comerciales y la sección de testimonios del sitio web.'
WHERE id = 'com_07';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué servicios adicionales debería ofrecer GuardMan para aumentar el ticket promedio?',
  subtitle_es = 'Marque todos los que apliquen.',
  objective_es = 'Detectar líneas de servicio complementarias que eleven el ticket promedio, mejoren la retención y refuercen la propuesta de valor integral.',
  options_json = '["Monitoreo remoto de cámaras desde la central propia","Conexión del sistema de cámaras del cliente a nuestra central","Instalación de cámaras y alarmas","Arriendo de equipos (radios, cámaras corporales)","Consultoría de seguridad (auditoría y levantamiento de riesgos)","Servicios de bínting y chofer de reemplazo","Gestión de visitas y credenciales","Recepción de paquetería y correspondencia","Auxiliares de aseo","Auxiliares de mantenimiento"]'
WHERE id = 'com_08';

-- ============================================================
-- SECCIÓN 4: PERSONAS Y CULTURA
-- ============================================================

UPDATE ceo_questionnaire_questions SET
  question_es = 'Cuéntenos su historia: ¿quién es Rodrigo Mora, director general de GuardMan?',
  subtitle_es = 'Formación, trayectoria profesional previa, razón por la que incursionó en seguridad, qué lo trajo hasta aquí. Sin filtro editorial.',
  objective_es = 'Construir la biografía institucional del director general, que se publicará en el sitio web y se utilizará en presentaciones, propuestas y notas de prensa.'
WHERE id = 'per_01';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene estos valores según la cultura interna de GuardMan (1 = más importante, lo que se vive día a día):',
  subtitle_es = NULL,
  objective_es = 'Identificar los valores efectivamente vividos dentro del equipo. Esta jerarquía alimenta los procesos de selección, inducción y evaluación de desempeño.',
  options_json = '["Cumplimiento de turnos (nunca faltar)","Honestidad y transparencia","Vocación de servicio","Disciplina y respeto","Responsabilidad y compromiso","Lealtad al cliente","Trabajo en equipo","Capacitación continua","Imagen personal y presentación","Adaptabilidad y resolución"]'
WHERE id = 'per_02';

UPDATE ceo_questionnaire_questions SET
  question_es = 'La selección de un nuevo guardia de GuardMan prioriza:',
  subtitle_es = NULL,
  objective_es = 'Definir la barrera de entrada para nuevos guardias, lo que establece los filtros de reclutamiento, los contenidos de capacitación y el perfil que se publica en las ofertas de trabajo.',
  options_json = '["Experiencia previa en seguridad (excluyente)","Curso OS-10 vigente (excluyente)","Pruebas psicológicas y de integridad","Capacitación propia posterior al ingreso","Modelo combinado: OS-10 más curso interno más prueba en terreno","Otro modelo (describir en el espacio libre)"]'
WHERE id = 'per_03';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué tan importante es la capacitación continua de los guardias?',
  subtitle_es = '1 = una vez que ingresan, el proceso formativo termina. 10 = capacitación mensual obligatoria, certificaciones anuales y un programa permanente de mejora continua.',
  objective_es = 'Calibrar la inversión en desarrollo de personal, lo que define el presupuesto de capacitación, los contenidos anuales y el nivel de profesionalización del equipo.'
WHERE id = 'per_04';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene los problemas de retención de personal más comunes en GuardMan (1 = más común):',
  subtitle_es = NULL,
  objective_es = 'Identificar las tres causas principales de rotación. El primer tercio de la lista concentra la mayoría de las salidas, lo que define la estrategia de retención con mayor retorno.',
  options_json = '["Rotación por salarios bajos en comparación con la competencia","Rotación por agotamiento (turnos largos, sin francos suficientes)","Abandono por una mejor oferta de otra empresa","Abandono por malas condiciones (clima laboral o trato del cliente)","Abandono por motivos familiares o personales","Abandono tras una sanción disciplinaria (faltas o atrasos)","Abandono por falta de oportunidades de crecimiento","Abandono por conflictos con supervisores o compañeros"]'
WHERE id = 'per_05';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cómo está compuesto hoy el equipo directivo de GuardMan?',
  subtitle_es = NULL,
  objective_es = 'Caracterizar la estructura actual de liderazgo, lo que alimenta el organigrama, las descripciones de cargo y la planificación de sucesiones.',
  options_json = '["Solo yo (Rodrigo, como director general operativo, asumo todas las funciones)","Yo más una o dos personas clave (por ejemplo, gerente de operaciones y contador)","Yo más entre tres y cinco personas (gerencia media)","Yo más un equipo directivo estructurado (gerentes y subgerentes)","Otra configuración (describir en el espacio libre)"]'
WHERE id = 'per_06';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuál es el dolor operativo número uno que más le quita el sueño hoy?',
  subtitle_es = 'El problema que más le molesta, el que más tiempo le consume, el que, si se resolviera, le cambiaría la vida. Sin filtro.',
  objective_es = 'Detectar la fricción operativa más urgente para priorizarla en el roadmap de automatización y mejora de procesos.'
WHERE id = 'per_07';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Le gustaría que GuardMan crezca hasta superar los mil guardias, o prefiere mantenerse como una empresa boutique de doscientos a trescientos?',
  subtitle_es = 'Esta decisión define la ambición de escala y el modelo de crecimiento a largo plazo.',
  objective_es = 'Determinar la ambición de escala de la empresa, lo que define el plan de crecimiento, la estructura organizacional objetivo y los criterios de inversión.'
WHERE id = 'per_08';

-- ============================================================
-- SECCIÓN 5: DIFERENCIACIÓN Y MERCADO
-- ============================================================

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuál es la propuesta de valor que ningún competidor de GuardMan puede replicar?',
  subtitle_es = 'La ventaja defensiva. ¿Por qué un cliente lo elige a usted y no a Securitas, Prosegur o la empresa de seguridad de la esquina? ¿Es el trato, la rapidez, la flexibilidad, la calidad humana?',
  objective_es = 'Articular la ventaja competitiva central, que se convierte en el mensaje principal de todas las propuestas comerciales y del posicionamiento público de la marca.'
WHERE id = 'dif_01';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene los competidores según el nivel de amenaza real para GuardMan (1 = más amenazante):',
  subtitle_es = NULL,
  objective_es = 'Identificar los tres competidores más relevantes para definir la estrategia competitiva, los mensajes diferenciadores y el seguimiento de movimientos del mercado.',
  options_json = '["Securitas (multinacional)","Prosegur (latinoamericana de gran tamaño)","Otras empresas familiares chilenas","Empresas de seguridad informales o no regularizadas","Seguridad interna del cliente (su propio equipo)","Cámaras y alarmas (sustitutos tecnológicos)","Empresas nuevas con modelo tecnológico (startups)","Servicios integrados (aseo más seguridad más mantenimiento)"]'
WHERE id = 'dif_02';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué certificaciones y acreditaciones tiene GuardMan en la actualidad?',
  subtitle_es = 'Marque todas las que apliquen.',
  objective_es = 'Inventariar las certificaciones vigentes, lo que es fundamental para presentar propuestas a clientes corporativos, participar en licitaciones y respaldar la promesa de calidad.',
  options_json = '["Resolución OS-10 vigente (Carabineros de Chile)","Patente municipal al día","Iniciación de actividades en el Servicio de Impuestos Internos","Mutualidad de Seguridad o IST al día","Seguro de responsabilidad civil vigente","Seguro de robo y daños","Pólizas para clientes corporativos grandes","Certificación ISO 9001 (calidad)","Certificación ISO 45001 (seguridad y salud ocupacional)","Certificación OHSAS 18001","Acreditación de la Asociación Chilena de Seguridad","Membresía en gremiales del rubro","Reconocimientos o premios sectoriales"]'
WHERE id = 'dif_03';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué tan importante es para GuardMan diferenciarse por precio frente a diferenciarse por calidad?',
  subtitle_es = '1 = competimos por precio, somos la opción más económica. 10 = competimos por calidad, el precio no es el factor principal.',
  objective_es = 'Definir el posicionamiento competitivo, lo que orienta la política de precios, los mensajes de marketing y la estrategia de retención.'
WHERE id = 'dif_04';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Considera que la industria de seguridad privada en Chile está creciendo, estable o en declive?',
  subtitle_es = 'Sí equivale a crecimiento. No equivale a declive. Si crece, ¿a qué ritmo?',
  objective_es = 'Caracterizar el entorno macroeconómico del sector, lo que informa la estrategia de inversión, la planificación de capacidad y las decisiones de expansión.'
WHERE id = 'dif_05';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Imagine que es el año 2031. GuardMan cumplió quince años (o los que correspondan). Alguien escribe la historia de la empresa. ¿Cuál sería el primer párrafo?',
  subtitle_es = 'Escríbalo como si fuera la apertura de una nota en un medio de referencia del sector. Sin modestia.',
  objective_es = 'Definir el norte estratégico: la aspiración de largo plazo. Este párrafo funciona como la estrella polar que guía todas las decisiones tácticas.'
WHERE id = 'dif_06';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Si tuviera que elegir una de estas dos posiciones, ¿cuál adoptaría?',
  subtitle_es = 'Elija la opción con la que más se identifica.',
  objective_es = 'Forzar una decisión de posicionamiento excluyente. La marca debe elegir una trinchera principal, ya que la ambigüedad diluye el mensaje.',
  options_json = '["La empresa más profesional de Chile: calidad por encima de todo, certificaciones premium, procesos rigurosos","La empresa más confiable de Chile: cercanía, servicio humano, relación de largo plazo con cada cliente"]'
WHERE id = 'dif_07';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Qué tan dispuesto está a innovar tecnológicamente? (aplicaciones, inteligencia artificial, cámaras inteligentes, drones, entre otros)',
  subtitle_es = '1 = somos tradicionales, nuestro activo principal son los guardias. 10 = sin innovación tecnológica no somos competitivos.',
  objective_es = 'Medir la apertura hacia la innovación, lo que define el presupuesto de investigación y desarrollo, el perfil de las contrataciones técnicas y el ritmo de evolución del producto.'
WHERE id = 'dif_08';
