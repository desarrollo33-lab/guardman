-- ============================================================
-- GuardMan v3.0 — D1 Migrations
-- Ejecutar: npx wrangler d1 execute guardman-seo --remote --file=sql/v3-migrations.sql
-- ============================================================

-- ===== COORDENADAS PARA GEOLOCALIZACIÓN (C7) =====
-- locations ya tiene latitude/longitude. Solo actualizamos valores.
UPDATE locations SET latitude = -33.4117, longitude = -70.5667  WHERE slug = 'las-condes';
UPDATE locations SET latitude = -33.3957, longitude = -70.5833  WHERE slug = 'vitacura';
UPDATE locations SET latitude = -33.3561, longitude = -70.5167  WHERE slug = 'lo-barnechea';
UPDATE locations SET latitude = -33.4378, longitude = -70.6506  WHERE slug = 'santiago-centro';
UPDATE locations SET latitude = -33.3583, longitude = -70.6750  WHERE slug = 'huechuraba';
UPDATE locations SET latitude = -33.3667, longitude = -70.7333  WHERE slug = 'quilicura';
UPDATE locations SET latitude = -33.4000, longitude = -70.6833  WHERE slug = 'conchali';
UPDATE locations SET latitude = -33.4500, longitude = -70.5833  WHERE slug = 'la-reina';
UPDATE locations SET latitude = -33.4333, longitude = -70.7500  WHERE slug = 'pudahuel';
UPDATE locations SET latitude = -33.5833, longitude = -70.6333  WHERE slug = 'la-pintana';
UPDATE locations SET latitude = -33.4000, longitude = -70.7000  WHERE slug = 'renca';
UPDATE locations SET latitude = -33.2833, longitude = -70.8833  WHERE slug = 'lampa';
UPDATE locations SET latitude = -32.8333, longitude = -70.6000  WHERE slug = 'los-andes';
UPDATE locations SET latitude = -32.7500, longitude = -70.7333  WHERE slug = 'san-felipe';

-- ===== CONTENT SIMILARITY TRACKING (C2) =====
CREATE TABLE IF NOT EXISTS content_similarity (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_slug TEXT NOT NULL,
  location_a TEXT NOT NULL,
  location_b TEXT NOT NULL,
  similarity_score REAL NOT NULL,
  overlapping_phrases TEXT,
  checked_at TEXT DEFAULT (datetime('now')),
  UNIQUE(service_slug, location_a, location_b)
);
CREATE INDEX IF NOT EXISTS idx_cs_service ON content_similarity(service_slug);

-- ===== PAGE ANALYTICS (C4) =====
CREATE TABLE IF NOT EXISTS page_analytics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  path TEXT NOT NULL,
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  referer TEXT,
  visitor_country TEXT,
  visited_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_pa_path ON page_analytics(path);
CREATE INDEX IF NOT EXISTS idx_pa_date ON page_analytics(visited_at);

-- ===== POSITION SNAPSHOTS INDEX (A12) =====
-- position_snapshots usa (service_slug, location_slug, snapshot_date, domain)
CREATE INDEX IF NOT EXISTS idx_ps_svc_loc_date ON position_snapshots(service_slug, location_slug, snapshot_date);
CREATE INDEX IF NOT EXISTS idx_ps_date ON position_snapshots(snapshot_date);
