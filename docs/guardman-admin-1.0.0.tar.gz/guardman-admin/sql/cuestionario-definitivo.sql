-- ═══════════════════════════════════════════════════════════════
-- GuardMan · Cuestionario CEO — VERSIÓN DEFINITIVA
-- Basado en: DCR Motors patrón + guardman.cl real + guardman-admin completo
-- Flujo: origen → territorio → cliente → diagnóstico
-- 44 preguntas · 4 secciones · 0 términos prohibidos
-- ═══════════════════════════════════════════════════════════════

-- ============================================================
-- FASE 1: Eliminar preguntas débiles de servicios (4)
-- ============================================================
DELETE FROM ceo_questionnaire_questions WHERE id IN ('srv_05', 'srv_12', 'srv_16', 'srv_18');
DELETE FROM ceo_questionnaire_answers WHERE question_id IN ('srv_05', 'srv_12', 'srv_16', 'srv_18');
DELETE FROM ceo_questionnaire_services WHERE question_id IN ('srv_05', 'srv_12', 'srv_16', 'srv_18');

-- ============================================================
-- FASE 2: Mover preguntas entre secciones (2)
-- ============================================================
-- srv_19 (factores de elección) → comercial: es comportamiento de compra, no operación
-- srv_20 (factores de retención) → comercial: es comportamiento post-venta, no operación
UPDATE ceo_questionnaire_questions SET section_id = 'comercial' WHERE id = 'srv_19';
UPDATE ceo_questionnaire_questions SET section_id = 'comercial' WHERE id = 'srv_20';

-- ============================================================
-- FASE 3: Insertar 4 preguntas NUEVAS (2 identidad + 2 diferenciación)
-- ============================================================

-- id_09: ORIGEN — La historia fundacional real
INSERT INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, objective_es, required) VALUES (
  'id_09', 'identidad', 9, 'free_text',
  '¿Cómo nació GuardMan? Cuénteme la historia real. La que le contaría a un amigo tomando un café, no la del brochure.',
  '¿Dónde estaba usted cuando decidió crear la empresa? ¿Qué vio en el mercado que no le gustó? ¿Fue una oportunidad, una necesidad, una rabia? Lo que haya sido, cuéntelo como fue.',
  '[]',
  'Esta es su historia. Nadie la conoce mejor que usted. Cuéntela.',
  'La historia de cómo nació GuardMan es lo más humano que tiene la empresa. Detrás de cada empresa hay una persona que un día decidió empezar. Esa historia conecta con la gente de una forma que ningún argumento comercial puede igualar.',
  1
);

-- id_10: PRINCIPIOS — Lo que GuardMan NUNCA haría
INSERT INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, objective_es, required) VALUES (
  'id_10', 'identidad', 10, 'free_text',
  '¿Hay algo que GuardMan NUNCA haría, aunque significara perder un cliente? ¿Qué principios no se transan?',
  'Toda empresa que dura en el tiempo tiene líneas que no cruza. No por plata, no por conveniencia. Por convicción. ¿Cuáles son las de GuardMan?',
  '[]',
  'Si no se le ocurre nada, piénselo. Toda empresa seria tiene al menos una línea roja.',
  'Saber lo que GuardMan NO hace es tan importante como saber lo que SÍ hace. Define el carácter de la empresa. Esto se convierte en una sección que genera confianza porque demuestra que GuardMan tiene principios, no solo precios.',
  1
);

-- dif_09: DIAGNÓSTICO — Lo que Rodrigo ve que está roto en la industria
INSERT INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, objective_es, required) VALUES (
  'dif_09', 'diferenciacion', 9, 'free_text',
  'En todos estos años en seguridad, ¿cuál es la falla más común que ha visto repetirse en otras empresas? Esa que usted ya reconoce a los cinco minutos de entrar a un lugar nuevo.',
  'Guardias que no llegan. Supervisores que nunca aparecen. Empresas que venden barato y entregan menos. Contratos que no se cumplen. Usted ha visto de todo. ¿Cuál es la falla que más le molesta porque sabe que es evitable?',
  '[]',
  'Piense en lo que le da rabia del rubro. Eso que usted jamás permitiría en GuardMan.',
  'Rodrigo lleva años viendo lo que funciona y lo que falla en seguridad privada. Su diagnóstico de la industria es conocimiento que nadie más tiene. Esto se convierte en el contenido más auténtico de GuardMan: un experto que sabe de lo que habla porque lo ha vivido.',
  1
);

-- dif_10: FUTURO — La visión de Rodrigo
INSERT INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, objective_es, required) VALUES (
  'dif_10', 'diferenciacion', 10, 'free_text',
  'Si usted tuviera los recursos para arreglar lo que está mal en la seguridad privada en Chile, ¿qué cambiaría y cómo?',
  'No se limite por plata ni por gente. Piense en grande. Si mañana le dieran todo lo que necesita para resolver el problema más grande del rubro, ¿por dónde empezaría?',
  '[]',
  'Imagine que no hay restricciones. Ni de plata, ni de personal, ni de nada.',
  'Esta pregunta revela hacia dónde quiere llevar GuardMan. Es la visión de alguien que no solo trabaja en seguridad, sino que piensa cómo mejorarla. Esto posiciona a Rodrigo como una voz autorizada en el rubro.',
  1
);

-- ============================================================
-- FASE 4: Renombrar secciones para el nuevo arco narrativo
-- ============================================================
UPDATE ceo_questionnaire_sections SET
  title_es = 'Origen e identidad',
  description = 'Diez preguntas sobre la historia de GuardMan, cómo lo perciben sus clientes, qué dice la gente cuando lo contacta y qué principios no se transan. Las respuestas definen quién es GuardMan de verdad.'
WHERE id = 'identidad';

UPDATE ceo_questionnaire_sections SET
  title_es = 'Territorio y operación',
  description = 'Catorce preguntas sobre dónde opera GuardMan, qué servicios entrega, cuánta gente trabaja con usted y qué herramientas propias ha desarrollado. Las respuestas muestran la capacidad operativa real.'
WHERE id = 'servicios';

UPDATE ceo_questionnaire_sections SET
  title_es = 'La decisión del cliente',
  description = 'Diez preguntas sobre cómo eligen los clientes, qué objeciones tienen, por qué algunos se quedan años y por qué otros se van. Las respuestas revelan qué valora realmente la gente al contratar seguridad.'
WHERE id = 'comercial';

UPDATE ceo_questionnaire_sections SET
  title_es = 'Lo que Rodrigo sabe',
  description = 'Diez preguntas sobre lo que distingue a GuardMan, el diagnóstico personal de Rodrigo sobre la industria, los competidores reales y hacia dónde va la seguridad privada. Las respuestas son el contenido más valioso: la visión de un experto.'
WHERE id = 'diferenciacion';

-- ============================================================
-- FASE 5: Reordenar sort_order en TODAS las secciones
-- ============================================================

-- identidad (10 preguntas: id_01-08 + id_09-10)
UPDATE ceo_questionnaire_questions SET sort_order = 1 WHERE id = 'id_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2 WHERE id = 'id_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3 WHERE id = 'id_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4 WHERE id = 'id_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5 WHERE id = 'id_05';
UPDATE ceo_questionnaire_questions SET sort_order = 6 WHERE id = 'id_06';
UPDATE ceo_questionnaire_questions SET sort_order = 7 WHERE id = 'id_07';
UPDATE ceo_questionnaire_questions SET sort_order = 8 WHERE id = 'id_08';
UPDATE ceo_questionnaire_questions SET sort_order = 9 WHERE id = 'id_09';
UPDATE ceo_questionnaire_questions SET sort_order = 10 WHERE id = 'id_10';

-- servicios (14 preguntas)
UPDATE ceo_questionnaire_questions SET sort_order = 1 WHERE id = 'srv_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2 WHERE id = 'srv_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3 WHERE id = 'srv_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4 WHERE id = 'srv_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5 WHERE id = 'srv_06';
UPDATE ceo_questionnaire_questions SET sort_order = 6 WHERE id = 'srv_07';
UPDATE ceo_questionnaire_questions SET sort_order = 7 WHERE id = 'srv_08';
UPDATE ceo_questionnaire_questions SET sort_order = 8 WHERE id = 'srv_09';
UPDATE ceo_questionnaire_questions SET sort_order = 9 WHERE id = 'srv_10';
UPDATE ceo_questionnaire_questions SET sort_order = 10 WHERE id = 'srv_11';
UPDATE ceo_questionnaire_questions SET sort_order = 11 WHERE id = 'srv_13';
UPDATE ceo_questionnaire_questions SET sort_order = 12 WHERE id = 'srv_14';
UPDATE ceo_questionnaire_questions SET sort_order = 13 WHERE id = 'srv_15';
UPDATE ceo_questionnaire_questions SET sort_order = 14 WHERE id = 'srv_21';

-- comercial (10 preguntas: com_01-08 + srv_19 + srv_20)
UPDATE ceo_questionnaire_questions SET sort_order = 1 WHERE id = 'com_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2 WHERE id = 'com_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3 WHERE id = 'com_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4 WHERE id = 'com_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5 WHERE id = 'com_05';
UPDATE ceo_questionnaire_questions SET sort_order = 6 WHERE id = 'com_06';
UPDATE ceo_questionnaire_questions SET sort_order = 7 WHERE id = 'com_07';
UPDATE ceo_questionnaire_questions SET sort_order = 8 WHERE id = 'com_08';
UPDATE ceo_questionnaire_questions SET sort_order = 9 WHERE id = 'srv_19';
UPDATE ceo_questionnaire_questions SET sort_order = 10 WHERE id = 'srv_20';

-- diferenciacion (10 preguntas: dif_01-08 + dif_09-10)
UPDATE ceo_questionnaire_questions SET sort_order = 1 WHERE id = 'dif_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2 WHERE id = 'dif_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3 WHERE id = 'dif_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4 WHERE id = 'dif_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5 WHERE id = 'dif_05';
UPDATE ceo_questionnaire_questions SET sort_order = 6 WHERE id = 'dif_06';
UPDATE ceo_questionnaire_questions SET sort_order = 7 WHERE id = 'dif_07';
UPDATE ceo_questionnaire_questions SET sort_order = 8 WHERE id = 'dif_08';
UPDATE ceo_questionnaire_questions SET sort_order = 9 WHERE id = 'dif_09';
UPDATE ceo_questionnaire_questions SET sort_order = 10 WHERE id = 'dif_10';

-- ============================================================
-- FASE 6: Reescritura de contenido CLAVE
-- (Las preguntas ya mejoradas en v3 se mantienen.
--  Solo reescribimos las que necesitan ajuste para el nuevo arco.)
-- ============================================================

-- srv_07: REPROPÓSITO → Guard Pod (tecnología propia)
UPDATE ceo_questionnaire_questions SET
  type = 'free_text',
  question_es = 'Cuénteme del Guard Pod. ¿Cómo nació la idea? ¿Quién lo desarrolló? ¿Cuánto tiempo tomó?',
  subtitle_es = 'El Guard Pod® V1 es algo que casi ninguna empresa de seguridad tiene: tecnología propia. Cuente cómo pasó de ser una idea a ser un producto que ya está operando.',
  options_json = '[]',
  helper_text = 'Esto es un diferenciador real. Muy pocas empresas de seguridad desarrollan hardware propio.',
  objective_es = 'El Guard Pod es una ventaja concreta que ninguna otra empresa de seguridad tiene. Contar su historia —cómo nació, quién lo hizo, cuánto costó— demuestra que GuardMan no solo presta un servicio: innova.',
  required = 1
WHERE id = 'srv_07';

-- srv_11: SERVICIOS — Agregar Guard Pod y drones a las opciones
UPDATE ceo_questionnaire_questions SET
  options_json = '[
    "Portería en edificios residenciales — guardia fijo en la entrada, conoce a los vecinos, controla el acceso",
    "Portería en oficinas — control de visitantes, registro de ingreso, presencia profesional",
    "Rondas y vigilancia perimetral — recorridos programados, revisión de accesos y perímetros",
    "Control de acceso — registro de entradas y salidas, verificación de identidad",
    "Conserjería — atención al público, paquetería, control de visitas y proveedores",
    "Seguridad para locales comerciales — prevención de robos, presencia disuasiva",
    "Seguridad para eventos — control de acceso masivo, verificación de entradas",
    "Guard Pod® V1 — unidad autónoma de vigilancia, no requiere electricidad, se instala en minutos",
    "Drones de seguridad — vigilancia aérea para perímetros grandes o eventos",
    "Guardias y aseo — servicio combinado de seguridad y limpieza para condominios y edificios",
    "Monitoreo de alarmas y cámaras — atención remota, respuesta ante incidentes",
    "Asesoría de seguridad — diagnóstico, recomendaciones, plan de acción"
  ]'
WHERE id = 'srv_11';

-- srv_21: REPROPÓSITO → Servicio combinado guardias + aseo
UPDATE ceo_questionnaire_questions SET
  type = 'free_text',
  question_es = 'Algunos clientes contratan guardias y aseo juntos. ¿Cómo nació ese modelo? ¿Cómo funciona en la práctica?',
  subtitle_es = 'No es común que una empresa de seguridad también haga aseo. Pero usted lo hace, y tiene clientes que lo valoran. Cuente cómo llegó a ofrecer ese servicio combinado y qué aprendió en el camino.',
  options_json = '[]',
  helper_text = 'Esto es inusual en el rubro. Vale la pena contarlo.',
  objective_es = 'El servicio combinado de guardias y aseo es un modelo poco común que habla de la flexibilidad operativa de GuardMan. Explicar cómo funciona muestra que la empresa se adapta a lo que el cliente necesita, no al revés.',
  required = 1
WHERE id = 'srv_21';

-- dif_02: DIFERENCIADOR — Hacer más específica la pregunta
UPDATE ceo_questionnaire_questions SET
  question_es = 'Usted tiene el Guard Pod, los drones, la academia OS-10, el servicio combinado de aseo. De todo eso, ¿qué cree que es lo que más lo diferencia de verdad?',
  subtitle_es = 'No todo lo que uno tiene es un diferenciador real. A veces lo más valioso no es lo más visible. ¿Qué es lo que sus clientes le mencionan cuando le dicen por qué lo eligieron?',
  objective_es = 'Identificar cuál es el diferenciador que realmente mueve la aguja. No el que queda bien en el papel, sino el que hace que un cliente diga "por esto los elegí".',
  helper_text = 'Piense en lo que sus clientes le han dicho, no en lo que a usted le gustaría que dijeran.'
WHERE id = 'dif_02';

-- dif_05: COMPETIDORES — Hacer opciones más específicas
UPDATE ceo_questionnaire_questions SET
  question_es = 'Cuando un cliente le dice "gracias, pero me voy con otra empresa", ¿con quién se va? Ordene del más común al menos común:',
  subtitle_es = 'No importa si el competidor es más grande o más chico. Lo que importa es contra quién compite GuardMan en la vida real. Si no está en la lista, agréguelo abajo.',
  options_json = '[
    "Securitas — presencia nacional, marca conocida, respaldo corporativo",
    "Prosegur — fuerte en retail y oficinas, mucha inversión en tecnología",
    "Empresas locales de la comuna — más baratas, conocen el barrio, pero menos formales",
    "Guardias particulares — trabajan por su cuenta, sin empresa, sin respaldo",
    "Otra empresa mediana con buen marketing — similares a GuardMan pero más visibles",
    "El portero o conserje que también hace de guardia — no es competencia formal pero quita clientes",
    "Empresas nuevas con precios muy agresivos — entran regalando el servicio para ganar mercado"
  ]'
WHERE id = 'dif_05';

-- dif_08: HISTORIA — Ya no es necesaria porque id_09 la cubre. Cambiar foco.
UPDATE ceo_questionnaire_questions SET
  question_es = 'De todos los clientes que han pasado por GuardMan, ¿cuál fue el más difícil de conseguir y por qué? Ese que le costó sangre, sudor y lágrimas.',
  subtitle_es = 'No el más rentable. El más difícil. Ese que le dijo que no tres veces y a la cuarta le dijo que sí. Esa historia dice más de GuardMan que cualquier caso de éxito.',
  objective_es = 'Los clientes difíciles de conseguir son los que más enseñan. Contar esa historia muestra perseverancia, capacidad de adaptación y convicción en el servicio.',
  helper_text = 'Ese cliente que cuando finalmente firmó, usted sintió que había ganado algo más que un contrato.'
WHERE id = 'dif_08';

-- ═══════════════════════════════════════════════════════════════
-- VERIFICACIÓN FINAL
-- ═══════════════════════════════════════════════════════════════
-- SELECT section_id, COUNT(*) FROM ceo_questionnaire_questions GROUP BY section_id;
-- Debe dar: identidad=10, servicios=14, comercial=10, diferenciacion=10
