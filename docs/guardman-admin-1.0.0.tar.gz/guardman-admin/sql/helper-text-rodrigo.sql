-- Rewrite ALL helper_text to be Rodrigo-facing explanations
-- What each question asks + what kind of answer is expected
-- NO strategy, NO internal info, NO "we will do X with this"

-- ═══ SECCIÓN 1: ORIGEN E IDENTIDAD ═══
UPDATE ceo_questionnaire_questions SET helper_text = 'Escriba una frase breve, con las palabras que usaría su cliente. No necesita que sea perfecta: cuanto más natural y cotidiana, mejor.' WHERE id = 'id_01';
UPDATE ceo_questionnaire_questions SET helper_text = 'Escriba varios ejemplos reales, con las palabras exactas que usa la gente. Cinco, diez, los que recuerde. Cada ejemplo suma.' WHERE id = 'id_02';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene arrastrando cada opción. Ponga arriba lo que más escucha, abajo lo que menos. Si falta alguna pregunta frecuente, agréguela con el botón de abajo.' WHERE id = 'id_03';
UPDATE ceo_questionnaire_questions SET helper_text = 'Responda como si estuviera tomando un café con un amigo. Sin tecnicismos. La respuesta más honesta es la que más sirve.' WHERE id = 'id_04';
UPDATE ceo_questionnaire_questions SET helper_text = 'Puede ser una frase corta, una muletilla, una forma de explicar las cosas que repite sin darse cuenta. Si no tiene una, déjelo en blanco.' WHERE id = 'id_05';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija una sola opción. Piense en el error que más veces ha visto repetirse en clientes que llegan después de haber tenido una mala experiencia con otra empresa.' WHERE id = 'id_06';
UPDATE ceo_questionnaire_questions SET helper_text = 'Póngase en los zapatos de su cliente. ¿Qué palabras usaría él para recomendarlo? No invente: recuerde una situación real.' WHERE id = 'id_07';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija la primera pregunta que le hacen. No la segunda ni la tercera. La que abre la conversación. Si no está en la lista, agréguela.' WHERE id = 'id_08';
UPDATE ceo_questionnaire_questions SET helper_text = 'Cuéntelo como fue. Sin adornar. La historia real de cómo decidió crear GuardMan. Qué lo empujó, qué vio, qué sintió.' WHERE id = 'id_09';
UPDATE ceo_questionnaire_questions SET helper_text = 'Piense en sus convicciones más profundas sobre el negocio. Eso que nunca haría, aunque le ofrecieran buena plata. Escríbalo con sus palabras.' WHERE id = 'id_10';

-- ═══ SECCIÓN 2: TERRITORIO Y OPERACIÓN ═══
UPDATE ceo_questionnaire_questions SET helper_text = 'Marque todas las comunas donde tiene al menos un cliente activo hoy. Si una comuna no aparece, agréguela abajo con el botón.' WHERE id = 'srv_01';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene de arriba hacia abajo. Arriba donde más lo llaman, abajo donde menos. No piense en dónde tiene clientes, piense en dónde lo contactan.' WHERE id = 'srv_02';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija una sola. Esa comuna donde usted siente que GuardMan ya es conocido. Donde la gente lo ubica.' WHERE id = 'srv_03';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija una opción. Si tiene aunque sea un solo cliente fuera de Santiago, responda que sí.' WHERE id = 'srv_04';
UPDATE ceo_questionnaire_questions SET helper_text = 'Piense en grande. Sin restricciones de plata ni de gente. ¿Dónde le gustaría estar operando dentro de un año? Mencione hasta tres comunas.' WHERE id = 'srv_06';
UPDATE ceo_questionnaire_questions SET helper_text = 'Cuente cómo nació la idea, quién lo desarrolló, cuánto tiempo tomó. Esto es algo que muy pocas empresas de seguridad tienen.' WHERE id = 'srv_07';
UPDATE ceo_questionnaire_questions SET helper_text = 'Un número aproximado. Cuente a todos: guardias, supervisores, administrativos. Toda la gente que depende de GuardMan.' WHERE id = 'srv_08';
UPDATE ceo_questionnaire_questions SET helper_text = 'Un número aproximado. Todos los contratos vigentes este mes. Edificios, condominios, empresas, locales.' WHERE id = 'srv_09';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene de arriba hacia abajo. Arriba el tipo de lugar donde más clientes tiene, abajo donde menos. Piense en su cartera actual, no en la que le gustaría tener.' WHERE id = 'srv_10';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene de arriba hacia abajo. Arriba lo que más le piden sus clientes, abajo lo que menos. El orden debe reflejar la demanda real.' WHERE id = 'srv_11';
UPDATE ceo_questionnaire_questions SET helper_text = 'No el más rentable, sino el que más lo enorgullece. Ese donde usted siente que GuardMan hace la diferencia. Puede ser uno solo.' WHERE id = 'srv_13';
UPDATE ceo_questionnaire_questions SET helper_text = 'Cuente la historia completa: cómo llegó el cliente, qué problema tenía, qué hizo GuardMan, qué resultado hubo. Si tiene cifras o datos concretos, inclúyalos.' WHERE id = 'srv_14';
UPDATE ceo_questionnaire_questions SET helper_text = 'El año real en que empezó a operar. No importa si fue con un solo cliente. Todos los años cuentan.' WHERE id = 'srv_15';
UPDATE ceo_questionnaire_questions SET helper_text = 'Cuente cómo nació ese modelo, cómo funciona en la práctica y qué aprendió ofreciendo dos servicios distintos bajo el mismo techo.' WHERE id = 'srv_21';

-- ═══ SECCIÓN 3: LA DECISIÓN DEL CLIENTE ═══
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija el perfil que más se repite entre sus clientes actuales. No el que más le gusta, sino el que más tiene.' WHERE id = 'com_01';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene de arriba hacia abajo. Arriba el canal que más clientes le trae, abajo el que menos. Sea honesto: no hay canal mejor ni peor.' WHERE id = 'com_02';
UPDATE ceo_questionnaire_questions SET helper_text = 'Esa corazonada que tiene después de años de escuchar la misma conversación. La razón de fondo, no la excusa que le dan.' WHERE id = 'com_03';
UPDATE ceo_questionnaire_questions SET helper_text = 'Cuente todo el proceso: llamada inicial, visita, cotización, reunión final. Elija la opción que mejor describa a su cliente promedio.' WHERE id = 'com_04';
UPDATE ceo_questionnaire_questions SET helper_text = 'Una estimación. Su intuición después de todos estos años ya es un dato. No necesita abrir la planilla.' WHERE id = 'com_05';
UPDATE ceo_questionnaire_questions SET helper_text = 'El tiempo del cliente promedio. No el más rápido ni el más lento. El que más se repite.' WHERE id = 'com_06';
UPDATE ceo_questionnaire_questions SET helper_text = 'Un número aproximado. Consultas, llamadas, correos. Todo contacto de alguien que quiere saber del servicio en un mes normal.' WHERE id = 'com_07';
UPDATE ceo_questionnaire_questions SET helper_text = 'El número real de clientes nuevos que firma en un mes promedio. Sin inflar. Este es el resultado final de todo el trabajo.' WHERE id = 'com_08';

-- srv_19 and srv_20 (moved to comercial)
UPDATE ceo_questionnaire_questions SET helper_text = 'Póngase en los zapatos del cliente. Ordene de arriba hacia abajo: arriba lo que MÁS pesa para que lo elijan a usted y no a otro.' WHERE id = 'srv_19';
UPDATE ceo_questionnaire_questions SET helper_text = 'Piense en ese cliente que lleva años con usted. ¿Por qué se queda? Ordene de arriba hacia abajo: arriba la razón principal, abajo la menos relevante.' WHERE id = 'srv_20';

-- ═══ SECCIÓN 4: LO QUE RODRIGO SABE ═══
UPDATE ceo_questionnaire_questions SET helper_text = 'Treinta segundos. Una sola frase. La que cierra. La que convence. Escríbala exactamente como la diría en persona.' WHERE id = 'dif_01';
UPDATE ceo_questionnaire_questions SET helper_text = 'Piense en lo que sus clientes le han dicho cuando le explican por qué lo eligieron. No en lo que a usted le gustaría que dijeran.' WHERE id = 'dif_02';
UPDATE ceo_questionnaire_questions SET helper_text = 'Esa historia que ya ha contado varias veces y cada vez la cuenta con el mismo orgullo. Escríbala como se la contaría a un conocido.' WHERE id = 'dif_03';
UPDATE ceo_questionnaire_questions SET helper_text = 'No hay respuesta correcta. Elija la que mejor describa a GuardMan como realmente es, no como le gustaría que fuera.' WHERE id = 'dif_04';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene de arriba hacia abajo. Arriba el competidor contra el que más compite en la vida real. Si falta alguno, agréguelo abajo.' WHERE id = 'dif_05';
UPDATE ceo_questionnaire_questions SET helper_text = 'Piense en ese cliente o esa zona donde la gente le ha dicho que quiere que GuardMan llegue. Si nadie se lo ha pedido, déjelo en blanco.' WHERE id = 'dif_06';
UPDATE ceo_questionnaire_questions SET helper_text = 'No piense en precios ni certificaciones. Piense en algo más profundo: una forma de trabajar, una relación, un conocimiento que solo usted tiene.' WHERE id = 'dif_07';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ese cliente que le dijo que no varias veces. Cuente cómo fue el proceso, qué hizo para convencerlo y qué sintió cuando finalmente firmó.' WHERE id = 'dif_08';
UPDATE ceo_questionnaire_questions SET helper_text = 'Esa falla que a usted ya no le sorprende. La ha visto tantas veces que la reconoce al instante. Descríbala con sus palabras.' WHERE id = 'dif_09';
UPDATE ceo_questionnaire_questions SET helper_text = 'Imagine que no hay límites. Ni de plata, ni de gente, ni de nada. ¿Qué haría para arreglar lo que está mal en el rubro?' WHERE id = 'dif_10';

-- ═══ SECCIÓN 5: RELACIÓN CON CLIENTES (CRM) ═══
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija una opción. La persona que atiende el primer contacto define la primera impresión que tiene un cliente nuevo de GuardMan.' WHERE id = 'crm_01';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija la opción que mejor describa cómo hace el seguimiento hoy. No lo que le gustaría hacer, sino lo que realmente hace.' WHERE id = 'crm_02';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija la información que más le habría servido tener en esa visita donde llegó sin saber algo clave. Puede elegir una o varias.' WHERE id = 'crm_03';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene de arriba hacia abajo. Arriba la etapa que más tiempo le consume, abajo la que menos. Piense en un cliente típico.' WHERE id = 'crm_04';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija la opción que mejor describa cómo se comunica con sus clientes en el día a día. No lo ideal, sino lo real.' WHERE id = 'crm_05';
UPDATE ceo_questionnaire_questions SET helper_text = 'Elija lo que realmente pasa, no lo que dice el manual. Si nunca le ha pasado, elija la última opción.' WHERE id = 'crm_06';
UPDATE ceo_questionnaire_questions SET helper_text = 'Ordene de arriba hacia abajo. Arriba lo que más urgente le resulta tener centralizado, abajo lo que puede esperar.' WHERE id = 'crm_07';
UPDATE ceo_questionnaire_questions SET helper_text = 'No piense en lo que existe. Piense en lo que le resolvería el día. Puede ser algo muy simple o muy ambicioso.' WHERE id = 'crm_08';
