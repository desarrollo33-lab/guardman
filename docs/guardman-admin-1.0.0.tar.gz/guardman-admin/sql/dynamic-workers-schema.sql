-- ============================================================
-- Dynamic Workers Schema Extensions
-- Tablas adicionales para la arquitectura v2
-- ============================================================

-- Analytics events tracking
CREATE TABLE IF NOT EXISTS analytics_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    entity_slug TEXT,
    entity_type TEXT,
    metadata_json TEXT,
    session_id TEXT,
    user_agent TEXT,
    ip_hash TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Deployments tracking
CREATE TABLE IF NOT EXISTS deployments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pages_url TEXT NOT NULL,
    version TEXT,
    items_updated INTEGER DEFAULT 0,
    deploy_time_ms INTEGER,
    deployed_by TEXT,
    deployed_at TEXT DEFAULT (datetime('now'))
);

-- Pipeline jobs
CREATE TABLE IF NOT EXISTS pipeline_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_type TEXT NOT NULL,
    scope TEXT,
    status TEXT DEFAULT 'pending',
    total_items INTEGER DEFAULT 0,
    completed_items INTEGER DEFAULT 0,
    progress_percent INTEGER DEFAULT 0,
    error_message TEXT,
    started_at TEXT,
    completed_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Alerts
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_type TEXT NOT NULL,
    severity TEXT DEFAULT 'info',
    message TEXT NOT NULL,
    entity_type TEXT,
    entity_slug TEXT,
    is_resolved INTEGER DEFAULT 0,
    resolved_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Uptime checks
CREATE TABLE IF NOT EXISTS uptime_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_name TEXT NOT NULL,
    status TEXT NOT NULL,
    response_time_ms INTEGER,
    error_message TEXT,
    checked_at TEXT DEFAULT (datetime('now'))
);

-- A/B Tests
CREATE TABLE IF NOT EXISTS ab_tests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_name TEXT NOT NULL,
    entity_type TEXT,
    entity_slug TEXT,
    variant_a TEXT,
    variant_b TEXT,
    traffic_split INTEGER DEFAULT 50,
    status TEXT DEFAULT 'draft',
    started_at TEXT,
    ended_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Keywords tracking
CREATE TABLE IF NOT EXISTS keywords_rankings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    entity_slug TEXT,
    search_engine TEXT DEFAULT 'google',
    position INTEGER,
    previous_position INTEGER,
    checked_at TEXT DEFAULT (datetime('now'))
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_analytics_events_type ON analytics_events(event_type, created_at);
CREATE INDEX IF NOT EXISTS idx_analytics_events_entity ON analytics_events(entity_type, entity_slug);
CREATE INDEX IF NOT EXISTS idx_deployments_date ON deployments(deployed_at);
CREATE INDEX IF NOT EXISTS idx_pipeline_status ON pipeline_jobs(status);
CREATE INDEX IF NOT EXISTS idx_alerts_unresolved ON alerts(is_resolved, created_at);
CREATE INDEX IF NOT EXISTS idx_uptime_service ON uptime_checks(service_name, checked_at);

-- Vista para contenido publicado (performance)
CREATE VIEW IF NOT EXISTS published_content_view AS
SELECT 
    cv.entity_type,
    cv.entity_slug,
    cv.version,
    cv.content_json,
    cv.word_count,
    cv.seo_score,
    cv.created_at as published_at,
    s.name as service_name,
    s.short_description,
    s.price_range
FROM content_versions cv
INNER JOIN workflow_status w 
    ON w.entity_type = cv.entity_type 
    AND w.entity_slug = cv.entity_slug
LEFT JOIN services s 
    ON s.slug = cv.entity_slug 
    AND cv.entity_type = 'service'
WHERE w.status = 'published'
    AND cv.version = (
        SELECT MAX(version) 
        FROM content_versions cv2 
        WHERE cv2.entity_type = cv.entity_type 
        AND cv2.entity_slug = cv.entity_slug
    );
