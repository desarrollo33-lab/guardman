#!/usr/bin/env python3
"""Generate FAQ seed SQL for all 126 service×location combos"""

locations = [
    ('las-condes', 'Las Condes'),
    ('vitacura', 'Vitacura'),
    ('lo-barnechea', 'Lo Barnechea'),
    ('la-reina', 'La Reina'),
    ('huechuraba', 'Huechuraba'),
    ('quilicura', 'Quilicura'),
    ('conchali', 'Conchalí'),
    ('santiago-centro', 'Santiago Centro'),
    ('pudahuel', 'Pudahuel'),
    ('la-pintana', 'La Pintana'),
    ('renca', 'Renca'),
    ('lampa', 'Lampa'),
    ('los-andes', 'Los Andes'),
    ('san-felipe', 'San Felipe'),
]

services = [
    ('guardias-de-seguridad', 'guardias de seguridad',
     [
         ('¿Hay guardias de seguridad disponibles en {loc}?', 'Sí, GuardMan Chile cuenta con guardias de seguridad certificados OS-10 disponibles en {loc}. Nuestro equipo está desplegado en la zona con capacidad de respuesta inmediata.', 1),
         ('¿Cuánto cuesta un guardia de seguridad en {loc}?', 'El costo de un guardia de seguridad en {loc} depende del tipo de servicio, jornada y cantidad de personal requerida. Ofrecemos cotizaciones personalizadas sin compromiso. Contáctenos para una evaluación gratuita.', 2),
         ('¿Qué empresas de seguridad privada operan en {loc}?', 'En {loc} operan varias empresas de seguridad, pero GuardMan Chile se distingue por contar con certificación OS-10, centro de monitoreo propio 24/7 y más de 8 años de experiencia en la zona.', 3),
         ('¿Los guardias de seguridad tienen certificación OS-10 en {loc}?', 'Sí, todos nuestros guardias de seguridad en {loc} cuentan con la autorización OS-10 vigente emitida por el Ministerio del Interior, además de cédula de identidad y antecedentes limpios.', 4),
         ('¿Cuál es el tiempo de respuesta para un guardia en {loc}?', 'Nuestro tiempo de respuesta en {loc} es inferior a 30 minutos. Tenemos personal desplegado en la zona que permite una activación rápida del servicio.', 5),
     ]),
    ('cctv-videovigilancia', 'sistemas de CCTV y videovigilancia',
     [
         ('¿Cuánto cuesta instalar cámaras de seguridad en {loc}?', 'El costo de instalación de cámaras de seguridad en {loc} varía según la cantidad de cámaras, tipo de tecnología y complejidad del sitio. Solicite una cotización gratuita y personalizada.', 1),
         ('¿Qué marcas de cámaras usan para videovigilancia en {loc}?', 'En {loc} utilizamos marcas líderes como Hikvision, Dahua y Axis Communications, todas con garantía oficial y soporte técnico local.', 2),
         ('¿Las cámaras de seguridad funcionan sin internet en {loc}?', 'Sí, nuestras cámaras de seguridad en {loc} pueden funcionar con almacenamiento local en DVR/NVR. Sin embargo, para monitoreo remoto se requiere conexión a internet.', 3),
         ('¿Puedo ver las cámaras desde mi celular en {loc}?', 'Sí, todos nuestros sistemas de CCTV en {loc} incluyen acceso remoto desde smartphone mediante app dedicada, con notificaciones en tiempo real y grabación en la nube.', 4),
         ('¿Cuántas cámaras necesito para mi propiedad en {loc}?', 'La cantidad de cámaras depende del tamaño y distribución de su propiedad en {loc}. Realizamos una evaluación presencial gratuita para recomendar el sistema óptimo.', 5),
     ]),
    ('control-de-accesos', 'sistemas de control de accesos',
     [
         ('¿Qué tipos de control de accesos ofrecen en {loc}?', 'En {loc} ofrecemos control de accesos biométrico (huella dactilar), tarjetas RFID, código PIN, reconocimiento facial y sistemas híbridos. Evaluamos su propiedad para recomendar la mejor opción.', 1),
         ('¿Cuánto cuesta instalar control de accesos en {loc}?', 'El precio de instalación de control de accesos en {loc} depende del número de puntos de acceso y tecnología elegida. Contáctenos para una cotización sin costo.', 2),
         ('¿El control de accesos funciona sin energía eléctrica en {loc}?', 'Nuestros sistemas de control de accesos en {loc} incluyen respaldo UPS que garantiza operación continua durante cortes de energía hasta por 8 horas.', 3),
         ('¿Puedo gestionar visitantes con control de accesos en {loc}?', 'Sí, nuestro sistema de control de accesos en {loc} incluye módulo de gestión de visitantes con registro fotográfico, autorización previa y notificación al residente.', 4),
         ('¿Qué mantenimiento requiere un sistema de control de accesos en {loc}?', 'Los sistemas de control de accesos en {loc} requieren mantenimiento preventivo cada 6 meses, que incluye limpieza de sensores, actualización de software y verificación de respaldos.', 5),
     ]),
    ('escoltas-privados', 'escoltas privados',
     [
         ('¿Cómo contratar un escolta privado en {loc}?', 'Para contratar un escolta privado en {loc}, contáctenos por teléfono o formulario web. Realizamos una evaluación de riesgo gratuita y le asignamos el profesional adecuado.', 1),
         ('¿Cuánto cobra un escolta privado en {loc}?', 'El valor de un escolta privado en {loc} depende del nivel de riesgo, duración del servicio y perfil requerido. Ofrecemos planes desde servicios puntuales hasta protección permanente.', 2),
         ('¿Los escoltas privados están armados en {loc}?', 'Nuestros escoltas en {loc} pueden operar armados o desarmados según la necesidad del cliente. Todos cuentan con permisos vigentes y entrenamiento especializado.', 3),
         ('¿Los escoltas privados sirven para ejecutivos en {loc}?', 'Sí, en {loc} ofrecemos protección ejecutiva discreta y profesional, adaptada a las necesidades de alta gerencia y directivos de empresas.', 4),
         ('¿Qué cobertura tiene el servicio de escoltas en {loc}?', 'Nuestro servicio de escoltas en {loc} cubre traslados punto a punto, acompañamiento permanente y protección en eventos. Cobertura 24/7 con centro de monitoreo propio.', 5),
     ]),
    ('monitoreo-24-7', 'monitoreo 24/7',
     [
         ('¿Cómo funciona el monitoreo 24/7 en {loc}?', 'El monitoreo 24/7 en {loc} opera desde nuestro centro de control con personal capacitado las 24 horas. Recibimos señales de alarmas, cámaras y sensores, y coordinamos la respuesta inmediata.', 1),
         ('¿Cuánto cuesta el servicio de monitoreo 24/7 en {loc}?', 'El precio del monitoreo 24/7 en {loc} depende de la cantidad de dispositivos y tipo de respaldo requerido. Ofrecemos planes mensuales desde planes accesibles.', 2),
         ('¿Qué pasa si se activa una alarma en {loc}?', 'Si se activa una alarma en {loc}, nuestro centro de monitoreo verifica la señal, contacta al titular y despacha personal de seguridad o coordina con Carabineros según el protocolo.', 3),
         ('¿El monitoreo 24/7 funciona con cualquier sistema de alarmas en {loc}?', 'En {loc}, nuestro centro de monitoreo es compatible con las principales marcas de alarmas. Para sistemas propietarios, evaluamos la integración sin costo.', 4),
         ('¿Puedo recibir notificaciones del monitoreo en mi celular en {loc}?', 'Sí, en {loc} ofrecemos notificaciones push, SMS y correo electrónico para todos los eventos detectados por nuestro centro de monitoreo 24/7.', 5),
     ]),
    ('seguridad-eventos', 'seguridad para eventos',
     [
         ('¿Cuántos guardias necesito para un evento en {loc}?', 'La cantidad de guardias para eventos en {loc} depende de la asistencia esperada, tipo de evento y riesgo. La regla general es 1 guardia por cada 50-100 asistentes. Solicite una evaluación gratuita.', 1),
         ('¿Qué tipo de eventos cubren en {loc}?', 'En {loc} cubrimos seguridad para eventos corporativos, conciertos, ferias, conferencias, fiestas privadas, lanzamientos de producto y cualquier congregación de personas.', 2),
         ('¿Los guardias para eventos en {loc} tienen experiencia?', 'Sí, nuestro personal para eventos en {loc} tiene experiencia en control de acceso, gestión de masas, primeros auxilios y protocolos de evacuación. Todos certificados OS-10.', 3),
         ('¿Cuánto cuesta la seguridad para eventos en {loc}?', 'El costo de seguridad para eventos en {loc} varía según la duración, cantidad de personal y equipamiento requerido. Ofrecemos cotizaciones personalizadas sin compromiso.', 4),
         ('¿Ofrecen seguridad para eventos corporativos en {loc}?', 'Sí, en {loc} tenemos amplia experiencia en seguridad para eventos corporativos, desde reuniones ejecutivas hasta convenciones masivas, con personal capacitado y discreto.', 5),
     ]),
    ('seguridad-industrial', 'seguridad industrial',
     [
         ('¿Qué incluye el servicio de seguridad industrial en {loc}?', 'El servicio de seguridad industrial en {loc} incluye control de accesos, rondas preventivas, vigilancia perimetral, monitoreo de CCTV, gestión de visitantes y coordinación con equipos de emergencia.', 1),
         ('¿Cuánto cuesta seguridad industrial en {loc}?', 'El costo de seguridad industrial en {loc} depende del tamaño de la instalación, cantidad de turnos y nivel de riesgo. Realizamos diagnóstico gratuito y cotización personalizada.', 2),
         ('¿Los guardias industriales tienen capacitación especializada en {loc}?', 'Sí, nuestros guardias industriales en {loc} reciben capacitación en seguridad minera, prevención de incendios, manejo de sustancias peligrosas y protocolos de emergencia industrial.', 3),
         ('¿Qué industrias atienden en {loc}?', 'En {loc} atendemos minería, construcción, manufactura, logística, energia, petróleo y cualquier industria que requiera seguridad especializada.', 4),
         ('¿Ofrecen seguridad para plantas y fábricas en {loc}?', 'Sí, en {loc} proveemos seguridad integral para plantas industriales y fábricas, con control de accesos biométrico, vigilancia 24/7 y rondas preventivas programadas.', 5),
     ]),
    ('auditoria-seguridad', 'auditoría de seguridad',
     [
         ('¿Qué es una auditoría de seguridad en {loc}?', 'Una auditoría de seguridad en {loc} es una evaluación profesional de los riesgos y vulnerabilidades de su propiedad o negocio. Incluye inspección presencial, análisis de brechas y plan de acción prioritario.', 1),
         ('¿Cuánto cuesta una auditoría de seguridad en {loc}?', 'El valor de una auditoría de seguridad en {loc} depende del tamaño de la propiedad, complejidad y profundidad del análisis. Ofrecemos una evaluación inicial sin costo.', 2),
         ('¿Qué incluye una auditoría de seguridad en {loc}?', 'Nuestra auditoría en {loc} incluye evaluación de accesos, análisis de videovigilancia, revisión de alarmas, planimetría de riesgo, recomendaciones prioritarias y plan de implementación.', 3),
         ('¿Quiénes realizan la auditoría de seguridad en {loc}?', 'Las auditorías en {loc} son realizadas por profesionales certificados con experiencia en seguridad física, electrónica y gestión de riesgos.', 4),
         ('¿Cuánto demora una auditoría de seguridad en {loc}?', 'Una auditoría de seguridad estándar en {loc} toma entre 3 a 7 días hábiles, dependiendo del tamaño de la instalación. El informe completo se entrega en un plazo máximo de 10 días.', 5),
     ]),
    ('guard-pod', 'Guard Pod',
     [
         ('¿Qué es Guard Pod en {loc}?', 'Guard Pod en {loc} es nuestra unidad autónoma de seguridad portátil con cámaras 4K, sensores de movimiento, iluminación LED y conectividad 4G. Ideal para obras, estacionamientos y sitios remotos.', 1),
         ('¿Cuánto cuesta arrendar un Guard Pod en {loc}?', 'El arriendo de Guard Pod en {loc} tiene planes desde modalidad diaria hasta mensual, con monitoreo 24/7 incluido. Solicite cotización para su caso específico.', 2),
         ('¿El Guard Pod funciona con energía solar en {loc}?', 'Sí, el Guard Pod en {loc} puede operar con paneles solares para locations sin conexión eléctrica. Incluye batería de respaldo para operación continua.', 3),
         ('¿El Guard Pod necesita internet en {loc}?', 'El Guard Pod en {loc} opera con conectividad 4G/LTE, no requiere WiFi ni conexión por cable. Funciona de forma autónoma en cualquier ubicación con cobertura celular.', 4),
         ('¿Qué vigilancia incluye el Guard Pod en {loc}?', 'El Guard Pod en {loc} incluye cámaras 4K con visión nocturna, detección de movimiento con alertas, intercomunicador bidireccional, alumbrado LED y monitoreo 24/7 desde nuestro centro de control.', 5),
     ]),
]

sql_lines = []
for svc_slug, svc_name, faqs in services:
    for loc_slug, loc_name in locations:
        for question, answer, rank in faqs:
            q = question.replace('{loc}', loc_name)
            a = answer.replace('{loc}', loc_name)
            q_escaped = q.replace("'", "''")
            a_escaped = a.replace("'", "''")
            sql_lines.append(f"('{svc_slug}', '{loc_slug}', '{q_escaped}', '{a_escaped}', 'static', {rank}, 0, NULL, 'approved')")

print("INSERT INTO faqs (service_slug, location_slug, question, answer, source, frequency_rank, is_generated, generated_answer, status) VALUES")
print(",\n".join(sql_lines) + ";")