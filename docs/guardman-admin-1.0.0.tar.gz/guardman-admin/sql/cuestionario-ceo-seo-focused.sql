-- ============================================================
-- CUESTIONARIO CEO — REESCRITURA ORIENTADA A SEO + LEADS
-- Todas las preguntas en lenguaje cotidiano para un director
-- de seguridad privada. Sin jerga técnica.
-- Cada respuesta alimenta un objetivo SEO/lead documentado.
-- ============================================================

-- ============================================================
-- SECCIÓN 1: "Lo que ven los ojos del cliente"
-- 8 preguntas (id_01 a id_08)
-- Objetivo SEO: capturar el lenguaje real que usa la gente
-- ============================================================

UPDATE ceo_questionnaire_sections SET
  title_es = 'Lo que ven los ojos del cliente',
  description = 'Ocho preguntas sobre cómo te percibe la gente, qué te dice cuando te contacta y cómo te recomienda. Tus respuestas se convierten en los textos del sitio web, las preguntas frecuentes, los testimonios y el tono de toda la comunicación.',
  icon = '👁️'
WHERE id = 'identidad';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Si un cliente satisfecho te tuviera que recomendar a un amigo, ¿cómo te describiría? Use sus palabras, no las suyas.',
  subtitle_es = 'Imagine que su cliente le habla a un vecino. ¿Qué le diría? Use la palabra por palabra que usaría él.',
  objective_es = 'Esta frase se convierte en el texto principal del sitio web (hero), en las páginas de servicio y en el anuncio de Google. Es la primera impresión que tiene un prospecto antes de contactarlos.',
  helper_text = 'Esta frase va al hero del sitio y al anuncio de Google. Cuanto más auténtica, mejor.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'id_01';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Cuando alguien lo llama por primera vez, ¿qué le dice? Cuente las palabras exactas que usa la gente.',
  subtitle_es = 'Por ejemplo: "necesito un guardia para un edificio en Las Condes", "tengo un local que me han robado tres veces", "cuánto cobran por cuidar una casa". Escriba varios ejemplos reales de lo que escucha.',
  objective_es = 'Estas frases son oro para SEO. Las personas escriben en Google exactamente lo que dicen por teléfono. Cada frase se convierte en una palabra clave long tail para el sitio.',
  type = 'free_text',
  options_json = '[]',
  helper_text = '5 a 10 ejemplos reales. Cada uno se convierte en una keyword long tail.'
WHERE id = 'id_02';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuáles son las tres preguntas que más le hace la gente antes de decidir si contratarlo?',
  subtitle_es = 'Por WhatsApp, por teléfono o en una reunión. Piense en las preguntas que se repiten una y otra vez, las que ya sabe de memoria.',
  objective_es = 'Estas tres preguntas se publican en la sección de Preguntas Frecuentes del sitio, con las respuestas. Aparecen como resultado expandido en Google y en los anuncios.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'id_03';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Si un conocido le preguntara "¿de verdad vale la pena contratar seguridad privada?", ¿qué le respondería?',
  subtitle_es = 'La respuesta de alguien que conoce el negocio desde adentro vale más que cualquier argumento de marketing. Sea honesto.',
  objective_es = 'Esta respuesta se usa como texto principal de la home, en los anuncios de Google y en los videos del sitio. Es la objeción universal que la gente tiene antes de contratar.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'id_04';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene alguna frase, eslogan o dicho que use mucho cuando habla con clientes?',
  subtitle_es = 'Alguna manera particular de explicar el servicio, algún lema, alguna forma de presentarlo. Si no lo tiene, está bien. Pero si lo tiene, vale oro.',
  objective_es = 'Si tiene una frase propia, se usa en el sitio con su firma. Si no, la creamos a partir de cómo habla. Esto le da autenticidad a toda la comunicación.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'id_05';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuál es el error más común que comete la gente cuando busca seguridad privada?',
  subtitle_es = 'Por ejemplo: "contratan por precio y se arrepienten", "no preguntan si los guardias están certificados", "creen que cualquier empresa es igual". ¿Cuál es el error que usted más ve?',
  objective_es = 'Este error es el ángulo de entrada para artículos de blog y contenido que educa al cliente. Un artículo que corrige el error rankea en Google y genera confianza antes de la venta.',
  type = 'free_text',
  options_json = '[]',
  helper_text = 'Un artículo en el blog que corrija este error puede llegar a miles de prospectos.'
WHERE id = 'id_06';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Piense en un cliente que lo haya recomendado a otra persona. ¿Qué cree que le dijo?',
  subtitle_es = 'No necesita el nombre. Solo la frase. Lo que la gente dice cuando recomienda es la publicidad más poderosa que existe.',
  objective_es = 'Estas frases se publican en el sitio con foto y nombre del cliente (previa autorización). Son los testimonios que más convierten, porque suenan reales, no a publicidad.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'id_07';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuál es la primera pregunta que le hace alguien nuevo, antes de cualquier otra cosa?',
  subtitle_es = 'Esa pregunta inicial define la primera impresión que tiene que dar el sitio web. Si la página responde esa pregunta en los primeros cinco segundos, la persona se queda.',
  objective_es = 'El sitio web debe responder esta pregunta antes de cualquier otra cosa. Si no la responde, la persona se va en menos de diez segundos.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'id_08';

-- ============================================================
-- SECCIÓN 2: "El territorio"
-- 10 preguntas (srv_01 a srv_10)
-- Objetivo SEO: priorizar páginas de servicio × ubicación
-- ============================================================

UPDATE ceo_questionnaire_sections SET
  title_es = 'El territorio',
  description = 'Diez preguntas sobre dónde están sus clientes, dónde recibe consultas y dónde quiere crecer. Las respuestas definen qué páginas del sitio web se crean primero para aparecer en Google.',
  icon = '📍'
WHERE id = 'servicios';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿En qué comunas de Santiago tiene clientes hoy?',
  subtitle_es = 'Marque todas las que apliquen. Esta lista define las páginas de "seguridad en [comuna]" que vamos a crear en el sitio.',
  objective_es = 'Estas comunas son las primeras páginas service × location que se publican en el sitio. Cada una es una puerta de entrada en Google para captar clientes locales.',
  type = 'multiple_choice',
  options_json = '["Las Condes","Vitacura","Lo Barnechea","Providencia","Ñuñoa","Santiago Centro","Maipú","Pudahuel","Estación Central","Puente Alto","San Bernardo","La Florida","Macul","Peñalolén","Conchalí","Recoleta","Independencia","San Miguel","San Joaquín","Quinta Normal","Cerrillos","Cerro Navia","Lo Prado","La Reina","La Cisterna","El Bosque","La Pintana","San Ramón","Lo Espejo","Pedro Aguirre Cerda","Huechuraba","Quilicura","Renca","Lampa","Colina","Padre Hurtado","Peñaflor","Talagante","Isla de Maipo","Melipilla","Buin","Paine"]'
WHERE id = 'srv_01';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene estos grupos de comunas según la cantidad de consultas que recibe de cada una (1 = donde más le preguntan):',
  subtitle_es = 'Esto permite saber dónde hay mayor demanda y dónde hay que crear las páginas de Google con más urgencia.',
  objective_es = 'Determinar el orden de prioridad de las páginas de Google. El grupo número uno recibe el contenido primero porque tiene la mayor demanda.',
  type = 'ranking',
  options_json = '["Las Condes, Vitacura y Lo Barnechea","Providencia, Ñuñoa y Santiago Centro","Maipú, Pudahuel y Estación Central","Puente Alto, San Bernardo","La Florida, Macul, Peñalolén","Conchalí, Recoleta, Independencia","San Miguel, San Joaquín, Quinta Normal","Cerrillos, Cerro Navia, Lo Prado","Quilicura, Renca, Huechuraba","Fuera de Santiago (regiones)"]'
WHERE id = 'srv_02';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿En qué comuna o sector le llegan más consultas que en cualquier otra parte?',
  subtitle_es = 'Un solo lugar. Donde usted nota que la gente lo busca más.',
  objective_es = 'Esta comuna se convierte en la primera página de Google con contenido reforzado. Toda la inversión de marketing local apunta ahí primero.',
  type = 'single_choice',
  options_json = '["Las Condes","Vitacura","Lo Barnechea","Providencia","Ñuñoa","Santiago Centro","Maipú","Pudahuel","Estación Central","Puente Alto","La Florida","Macul","Otra comuna"]'
WHERE id = 'srv_03';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Trabaja en regiones fuera de Santiago?',
  subtitle_es = NULL,
  objective_es = 'Si la respuesta es sí, el sitio web debe tener páginas regionales. Si la respuesta es no, todo el SEO se enfoca en la Región Metropolitana.',
  type = 'single_choice',
  options_json = '["No, solo Santiago","Sí, una región adicional","Sí, dos o tres regiones","Sí, en todas las regiones del país"]'
WHERE id = 'srv_04';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Hay alguna comuna donde la gente lo busca pero casi nunca termina contratando?',
  subtitle_es = 'Puede ser por distancia, por precio, por desconocimiento de la marca, por algo cultural. ¿Cuál es esa comuna y por qué cree que pasa?',
  objective_es = 'Detectar oportunidades perdidas. Si la gente busca pero no cierra, el problema es del mensaje. Esta comuna se convierte en un caso de estudio para ajustar la propuesta.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_05';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿En qué comuna o sector le gustaría crecer más en los próximos doce meses?',
  subtitle_es = 'Un máximo de tres lugares. Piense en dónde hay más oportunidades para GuardMan.',
  objective_es = 'Estas comunas se convierten en los próximos objetivos de SEO y campañas de marketing local. Se planifica el contenido de Google con anticipación.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_06';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Sabe de alguna comuna donde la competencia no llega o llega mal?',
  subtitle_es = 'Un barrio, una zona, un sector donde la gente se queja de que no hay buena seguridad. Si lo sabe, vale oro.',
  objective_es = 'Estas comunas son las próximas oportunidades de SEO con baja competencia. Las páginas del sitio rankean más fácil cuando hay menos competidores.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_07';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántos guardias tiene operando ahora mismo? (aproximado)',
  subtitle_es = 'Un número honesto. Va a aparecer en el sitio como prueba de experiencia y tamaño de la empresa.',
  objective_es = 'Este número se publica en la página principal como prueba social. "Más de X guardias operando" genera confianza y es un factor de posicionamiento en Google.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_08';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántos clientes activos tiene hoy GuardMan? (aproximado)',
  subtitle_es = 'Edificios, condominios, empresas, locales. Un número total.',
  objective_es = 'Este número se publica en el sitio como prueba de trayectoria. También se usa para estimar la densidad de mercado y planificar el crecimiento.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_09';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿En qué tipo de lugares trabaja más? (puede marcar varios)',
  subtitle_es = 'Marque los que apliquen. Esto define qué tipos de páginas de servicio se crean en el sitio.',
  objective_es = 'Cada tipo de lugar tiene su propia página de servicio en el sitio con palabras clave específicas. Por ejemplo: "seguridad para edificios", "seguridad para condominios", "seguridad para oficinas".',
  type = 'multiple_choice',
  options_json = '["Edificios residenciales","Condominios y comunidades","Oficinas y empresas","Locales comerciales y retail","Bodegas y centros de distribución","Faenas industriales","Casas particulares","Eventos (conciertos, ferias, lanzamientos)","Colegios y universidades","Hospitales y clínicas"]'
WHERE id = 'srv_10';

-- ============================================================
-- SECCIÓN 3: "Lo que la gente busca"
-- 8 preguntas nuevas (srv_11 a srv_18)
-- Objetivo SEO: alimentar el catálogo de servicios del sitio
-- ============================================================

UPDATE ceo_questionnaire_questions SET
  question_es = 'De los servicios que ofrece, ¿cuáles son los que más le piden? (marque los principales)',
  subtitle_es = 'Esta lista alimenta directamente las páginas de servicios del sitio. Las que más pide la gente van primero.',
  objective_es = 'Esta lista se convierte en el menú principal de servicios del sitio web. El orden de los servicios refleja la demanda real de la gente.',
  type = 'multiple_choice',
  options_json = '["Portería en edificios residenciales","Portería en oficinas y empresas","Rondas y vigilancia perimetral","Control de acceso","Conserjería","Seguridad para retail y locales","Seguridad para eventos","Escolta privada y protección de personas","Monitoreo de cámaras de seguridad y alarmas","Asesoría y auditoría de seguridad","Instalación de sistemas (cámaras, alarmas)","Investigaciones privadas","Seguridad para condominios","Seguridad industrial y faenas"]',
  helper_text = 'Lo que la gente más pide va primero en el menú del sitio.'
WHERE id = 'srv_11';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Hay algo que la gente le pida seguido y que hoy GuardMan no ofrezca?',
  subtitle_es = 'Servicios que le consultan, pero que termina rechazando o derivando a otro. Vale la pena saberlo porque puede ser una oportunidad.',
  objective_es = 'Detectar servicios que la gente busca pero GuardMan no entrega. Si la demanda es alta, vale la pena desarrollarlos y publicarlos en el sitio.',
  type = 'free_text',
  options_json = '[]',
  helper_text = 'Una demanda frecuente sin oferta es una oportunidad de catálogo.'
WHERE id = 'srv_12';

UPDATE ceo_questionnaire_questions SET
  question_es = 'De todos los servicios que ofrece, ¿cuál es el que más le gusta dar? ¿Cuál le da más orgullo?',
  subtitle_es = 'No el más rentable, sino el que más le gusta. El que lo hace sentir que hace la diferencia.',
  objective_es = 'Este servicio se convierte en la "joya" de la home del sitio. Es el que más se destaca visualmente porque es el que mejor representa a GuardMan.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_13';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene algún cliente cuyo caso le enorgullezca particularmente? Cuéntelo con detalle.',
  subtitle_es = 'No necesita el nombre. Describa la situación, qué problema tenía el cliente, qué hizo GuardMan, qué pasó después. Si tiene números concretos, mejor.',
  objective_es = 'Este caso se publica en el sitio como historia de éxito. Las historias reales con cifras convierten más que cualquier texto publicitario.',
  type = 'free_text',
  options_json = '[]',
  helper_text = 'Un caso de éxito con números concretos puede ser la página más vista del sitio.'
WHERE id = 'srv_14';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántos años lleva operando GuardMan?',
  subtitle_es = 'El año de fundación. Va a aparecer en el sitio como prueba de experiencia.',
  objective_es = 'Los años de operación son un factor de autoridad para Google. "Operando desde el año X" se publica en el hero y en el footer.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_15';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántos clientes ha tenido GuardMan en su historia, sumando los que ya no son clientes?',
  subtitle_es = 'Un número total acumulado. Es un número de prueba social muy fuerte.',
  objective_es = 'Este número se publica en el sitio como prueba de trayectoria. Es uno de los indicadores de confianza más buscados por los prospectos.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_16';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene fotos o videos de operaciones reales de GuardMan? (guardias, rondas, controles, eventos)',
  subtitle_es = 'Inventario de lo que tiene. Si tiene poco, vale la pena producir más. Las fotos reales son非常重要的 para SEO local.',
  objective_es = 'Las fotos y videos reales se publican en el sitio. Google prioriza sitios con imágenes auténticas. Las fotos reales también generan más confianza que las de banco de imágenes.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'srv_17';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene alguna certificación, resolución OS-10, o acreditación específica que lo respalde?',
  subtitle_es = 'Marque todas las que apliquen. Cada certificación es un punto de confianza adicional para el cliente y un factor de autoridad para Google.',
  objective_es = 'Las certificaciones se publican en el footer de cada página y en una sección dedicada. Son factores de E-E-A-T (experiencia, especialización, autoridad, confianza) que Google usa para rankear.',
  type = 'multiple_choice',
  options_json = '["Resolución OS-10 vigente (autorización de Carabineros)","Patente municipal al día","Mutualidad de Seguridad o IST al día","Seguro de responsabilidad civil","Seguro de robo y daños","Certificación ISO 9001 (calidad)","Certificación ISO 45001 (seguridad ocupacional)","Membresía en gremiales del rubro (ANACSE u otra)","Premios o reconocimientos sectoriales","Ninguna en particular","Otra certificación específica (escribir en notas)"]'
WHERE id = 'srv_18';

-- ============================================================
-- SECCIÓN 4: "Cómo se cierra y se pierde"
-- 8 preguntas (com_01 a com_08)
-- Objetivo SEO/leads: entender el embudo, las objeciones, la conversión
-- ============================================================

UPDATE ceo_questionnaire_sections SET
  title_es = 'Cómo se cierra y se pierde',
  description = 'Ocho preguntas sobre cómo se decide la gente, cuánto tiempo toma, qué objeciones escucha y por qué algunos clientes se van. Las respuestas afinan el embudo de ventas y el contenido del sitio para reducir las pérdidas.',
  icon = '🎯'
WHERE id = 'comercial';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Quién es el cliente típico que lo busca? Descríbalo.',
  subtitle_es = 'No necesita el nombre. Describa la empresa o persona: a qué se dedica, qué tamaño tiene, qué problema suele tener, dónde queda, qué presupuesto maneja.',
  objective_es = 'Esta descripción se convierte en el perfil de cliente objetivo del sitio. Toda la comunicación, las imágenes, el lenguaje y las palabras clave se ajustan a este perfil.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'com_01';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cómo llega la mayoría de sus clientes a GuardMan?',
  subtitle_es = 'Recomendación de otro cliente, búsqueda en Google, redes sociales, WhatsApp, ferias. Ordene los canales del que más trae al que menos trae.',
  objective_es = 'Determinar dónde se concentra el presupuesto de marketing. Si los referidos son el canal principal, se invierte en experiencia del cliente. Si Google está creciendo, se invierte en SEO.',
  type = 'ranking',
  options_json = '["Recomendación de otro cliente","Búsqueda en Google (alguien los buscó)","Google Ads (anuncios pagados)","WhatsApp directo","Facebook o Instagram","LinkedIn","Visitas en terreno (preventas)","Ruedas de negocios o ferias del rubro","Email marketing","Tráfico orgánico al sitio web"]'
WHERE id = 'com_02';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Cuando alguien le dice "lo voy a pensar", ¿cuál es su sospecha de por qué no lo eligió?',
  subtitle_es = 'La razón que usted intuye. La que más se repite. Sin filtro.',
  objective_es = 'Esta objeción se publica en el sitio como una pregunta frecuente con su respuesta. Si la página responde la objeción antes de que el prospecto la formule, la tasa de cierre sube.',
  type = 'free_text',
  options_json = '[]',
  helper_text = 'Si la página web responde esta objeción de antemano, la conversión sube.'
WHERE id = 'com_03';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántas llamadas o reuniones toma cerrar a un cliente nuevo?',
  subtitle_es = 'Una, dos, tres, más. ¿Cuántos contactos tiene con un prospecto antes de que firme?',
  objective_es = 'Si cierra en una llamada, la landing page del sitio tiene que ser autosuficiente. Si toma tres reuniones, hay que pensar en una secuencia de emails y materiales que acompañen al prospecto.',
  type = 'single_choice',
  options_json = '["Una sola (cierra en el primer contacto)","Dos (una primera conversación y luego cierra)","Tres (suele pedir una reunión presencial)","Cuatro o más (proceso largo con varias aprobaciones)","Depende mucho del tipo de cliente"]'
WHERE id = 'com_04';

UPDATE ceo_questionnaire_questions SET
  question_es = 'De cada cien personas que preguntan, ¿cuántas terminan contratándolo?',
  subtitle_es = 'Una estimación. No necesita el número exacto. Si está cerca del 30%, el problema puede ser el SEO. Si está cerca del 5%, el problema es la conversión.',
  objective_es = 'Esta tasa revela dónde está el cuello de botella. Si recibe muchas consultas pero cierra pocas, el problema es la página. Si recibe pocas consultas, el problema es SEO.',
  type = 'single_choice',
  options_json = '["Menos del 10%","Entre 10% y 25%","Entre 25% y 50%","Más del 50%","No lo sé con certeza"]'
WHERE id = 'com_05';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuánto tiempo pasa en promedio desde que alguien lo contacta hasta que firma el contrato?',
  subtitle_es = 'Un número aproximado. ¿Días, semanas, meses?',
  objective_es = 'Define la urgencia del seguimiento. Si pasan más de 24 horas entre el contacto y la primera respuesta, el lead se enfría. Esto se traduce en chatbots o respuestas automáticas.',
  type = 'single_choice',
  options_json = '["Menos de una semana","Una a dos semanas","Dos semanas a un mes","Uno a tres meses","Más de tres meses"]'
WHERE id = 'com_06';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántas consultas o pedidos de cotización recibe al mes, aproximadamente?',
  subtitle_es = 'Un número total. Sea honesto. Si dice "más o menos diez", eso ya es información valiosa.',
  objective_es = 'Este es el volumen del embudo. Si es bajo, hay que aumentar el tráfico (más SEO, más anuncios). Si es alto pero no cierran, hay que mejorar la conversión.',
  type = 'single_choice',
  options_json = '["Menos de 10 al mes","Entre 10 y 30","Entre 30 y 100","Más de 100 al mes","No llevo un registro exacto"]'
WHERE id = 'com_07';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántos clientes nuevos firma al mes, en promedio?',
  subtitle_es = 'Un número. La métrica más importante del negocio.',
  objective_es = 'Esta es la métrica clave del negocio. La diferencia entre el volumen de consultas y los clientes firmados define la tasa de conversión que hay que mejorar.',
  type = 'single_choice',
  options_json = '["Menos de 1 al mes","Entre 1 y 3","Entre 3 y 10","Más de 10 al mes","No llevo un registro exacto"]'
WHERE id = 'com_08';

-- ============================================================
-- SECCIÓN 5: "Por qué tú y no otro"
-- 8 preguntas (dif_01 a dif_08)
-- Objetivo SEO: propuesta de valor, diferenciadores,竞争优势
-- ============================================================

UPDATE ceo_questionnaire_sections SET
  title_es = 'Por qué tú y no otro',
  description = 'Ocho preguntas sobre su diferenciador, los competidores y por qué alguien debería elegir GuardMan por sobre cualquier otra opción. Las respuestas se convierten en la propuesta de valor del sitio, los mensajes de los anuncios y la posición competitiva.',
  icon = '🏆'
WHERE id = 'diferenciacion';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Si alguien le preguntara "¿por qué lo elijo a usted y no a Securitas o Prosegur?", ¿qué le diría?',
  subtitle_es = 'Una sola frase. La más importante del cuestionario. Es el corazón de toda la comunicación.',
  objective_es = 'Esta frase se convierte en el texto principal del sitio, en los anuncios de Google y en la primera respuesta que da cualquier ejecutivo de ventas. Es la propuesta de valor pura.',
  type = 'free_text',
  options_json = '[]',
  helper_text = 'La frase más importante del cuestionario. Vale la pena pensarla con tiempo.'
WHERE id = 'dif_01';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene alguna certificación o capacidad que la mayoría de las otras empresas de seguridad no tiene?',
  subtitle_es = 'Algo que usted puede hacer y ellos no. Una herramienta, una certificación, un proceso, un equipo. Lo que sea.',
  objective_es = 'Este diferenciador técnico se publica en el sitio como "por qué elegirnos". Va al hero, a la página de servicios y a los anuncios. Es lo que hace que GuardMan sea único.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'dif_02';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene otro caso de éxito, distinto al anterior, donde su trabajo haya marcado una diferencia clara?',
  subtitle_es = 'Otro caso, con números si es posible. Los casos de éxito son el contenido más persuasivo del sitio.',
  objective_es = 'Se publica como segundo caso de éxito. Los estudios de caso con cifras concretas son el contenido que más convierte visitantes en clientes.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'dif_03';

UPDATE ceo_questionnaire_questions SET
  question_es = 'Si tuviera que elegir entre estos dos posicionamientos, ¿cuál refleja mejor a GuardMan?',
  subtitle_es = 'La elección entre los dos define el tono de todo el sitio y los mensajes de los anuncios.',
  objective_es = 'Define el posicionamiento central. Si elige "profesional", el sitio habla de certificaciones, procesos y rigor. Si elige "cercano", habla de confianza, relaciones humanas y servicio personalizado.',
  type = 'comparison',
  options_json = '["La empresa más profesional y rigurosa de Chile: certificaciones premium, procesos estrictos, tecnología de punta","La empresa más cercana y de confianza: trato humano, relaciones de largo plazo, el guardia que ya conoce a su familia"]'
WHERE id = 'dif_04';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Sabe de alguna otra empresa de seguridad que aparezca muy por encima de usted en Google?',
  subtitle_es = 'Cuando alguien busca "seguridad en Santiago" o "portería en Las Condes", ¿quiénes salen primero? Si los conoce, los podemos estudiar y superar.',
  objective_es = 'Lista de competidores SEO. Saber contra quién competimos en Google es el primer paso para superarlos. Se analizan sus palabras clave, sus páginas y su estrategia.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'dif_05';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Hay alguna comuna donde sus clientes le hayan pedido que abra operación y que usted aún no cubre?',
  subtitle_es = 'Si la gente le pide en un lugar donde usted no está, hay una demanda SEO sin atender. Vale la pena saberlo.',
  objective_es = 'Demanda reprimida. Estas comunas son la próxima frontera de expansión. Se planifica contenido SEO con anticipación para cuando se decida abrir operación.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'dif_06';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Hay algo que GuardMan pueda hacer y la competencia no, por alguna razón específica?',
  subtitle_es = 'Una capacidad, un permiso, un equipo, una tecnología, una relación con algún cliente clave, una forma de operar. Lo que sea.',
  objective_es = 'Ventaja operativa única. Va al sitio como "el único que puede hacer X". Es un argumento de cierre muy fuerte en las propuestas comerciales.',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'dif_07';

UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cómo empezó GuardMan? Cuente la historia, en un párrafo.',
  subtitle_es = 'La anécdota real. No la versión para inversionistas. La versión que le contaría a un amigo.',
  objective_es = 'La historia fundacional se publica en la página "Nosotros" del sitio, con foto del director. Google premia los sitios con secciones "About" bien desarrolladas (E-E-A-T).',
  type = 'free_text',
  options_json = '[]'
WHERE id = 'dif_08';
