-- GuardMan Admin — Media Editor D1 Migration
-- Fase 0: Columnas para metadata de IA en media_library
-- DEBE ejecutarse ANTES de T0.5 (save-to-r2)

ALTER TABLE media_library ADD COLUMN prompt_used TEXT;
ALTER TABLE media_library ADD COLUMN generation_model TEXT;
ALTER TABLE media_library ADD COLUMN generation_seed INTEGER;
ALTER TABLE media_library ADD COLUMN generation_time_ms INTEGER;
ALTER TABLE media_library ADD COLUMN fal_request_id TEXT;
