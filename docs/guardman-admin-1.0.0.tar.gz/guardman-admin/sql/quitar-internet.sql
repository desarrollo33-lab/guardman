UPDATE ceo_questionnaire_questions
SET subtitle_es = 'Recomendación de otro cliente, búsqueda directa, redes sociales, correo, ferias. Ordene los canales del que más trae al que menos trae.'
WHERE id = 'com_02';

UPDATE ceo_questionnaire_questions
SET objective_es = 'Determinar dónde se concentra el presupuesto comercial. Si los referidos son el canal principal, se invierte en experiencia del cliente. Si las búsquedas directas están creciendo, se invierte en material de presentación.'
WHERE id = 'com_02';
