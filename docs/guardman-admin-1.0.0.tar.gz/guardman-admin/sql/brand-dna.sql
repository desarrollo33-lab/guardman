-- ============================================================
-- GuardMan Brand DNA — Single source of truth for brand identity
-- ============================================================

CREATE TABLE IF NOT EXISTS brand_dna (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL CHECK(category IN (
    'company',
    'stats',
    'colors',
    'voice',
    'differentiators',
    'exclusions',
    'certifications',
    'usps',
    'social',
    'hours'
  )),
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'string' CHECK(type IN ('string', 'number', 'json', 'color', 'url', 'boolean')),
  description TEXT DEFAULT '',
  updated_at TEXT DEFAULT (datetime('now')),
  UNIQUE(category, key)
);

CREATE INDEX IF NOT EXISTS idx_brand_category ON brand_dna(category);
