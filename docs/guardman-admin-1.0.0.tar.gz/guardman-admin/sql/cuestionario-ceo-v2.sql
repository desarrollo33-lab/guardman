-- ============================================================
-- CUESTIONARIO CEO — MEJORAS
-- 1) Eliminar menciones de "SEO" del texto visible
-- 2) Convertir preguntas a ranking de importancia
-- 3) Nuevas preguntas de ranking
-- ============================================================

-- ============================================================
-- SECCIÓN 1: id_01 a id_08 — limpiar objetivos
-- ============================================================

-- id_02: cambiar "oro para SEO" por algo cotidiano
UPDATE ceo_questionnaire_questions SET
  objective_es = 'Estas frases son las que la gente escribe en internet cuando busca seguridad. Las personas escriben en Google exactamente lo que dicen por teléfono. Cada frase se convierte en una página del sitio que la gente va a encontrar cuando busque.'
WHERE id = 'id_02';

-- id_03: ya está OK, pero reforzar el objetivo
UPDATE ceo_questionnaire_questions SET
  objective_es = 'Estas tres preguntas se publican en la sección de Preguntas Frecuentes del sitio, con sus respuestas. Aparecen destacadas en los resultados de Google y se usan también en los anuncios para responder antes de que la persona pregunte.'
WHERE id = 'id_03';

-- id_06: "rankea en Google" → "la gente lo encuentre"
UPDATE ceo_questionnaire_questions SET
  objective_es = 'Este error es el ángulo de entrada para artículos del blog. Un artículo que corrija el error y enseñe a la gente lo que usted sabe se comparte mucho, aparece cuando alguien busca y genera confianza antes de la venta.'
WHERE id = 'id_06';

-- id_08: OK, sin SEO
-- (sin cambios)

-- ============================================================
-- SECCIÓN 2: srv_01 a srv_10 — limpiar objetivos + convertir a ranking
-- ============================================================

-- srv_02: limpiar "páginas de Google" → "páginas en el sitio"
UPDATE ceo_questionnaire_questions SET
  objective_es = 'Determinar el orden de prioridad de las páginas del sitio web. El grupo número uno recibe el contenido primero porque tiene la mayor demanda de consultas.'
WHERE id = 'srv_02';

-- srv_10: CONVERTIR de multiple_choice a ranking
UPDATE ceo_questionnaire_questions SET
  type = 'ranking',
  question_es = 'Ordene estos tipos de lugares según la cantidad de clientes que tiene en cada uno (1 = donde más trabaja):',
  subtitle_es = 'Piense en sus clientes actuales. En qué tipo de lugar trabaja más. Esto define las páginas principales de servicios del sitio.',
  objective_es = 'Determinar dónde se concentra el negocio. Los tipos de lugar en los primeros lugares son los que reciben páginas de servicio dedicadas en el sitio con contenido reforzado.',
  helper_text = 'Lo que más tiene va primero en el menú del sitio.'
WHERE id = 'srv_10';

-- srv_11: CONVERTIR de multiple_choice a ranking (mantiene el CRUD)
UPDATE ceo_questionnaire_questions SET
  type = 'ranking',
  question_es = 'Ordene los servicios según la frecuencia con que se los piden (1 = el que más piden):',
  subtitle_es = 'Piense en lo que más le solicitan. Lo que más piden va primero en el menú de servicios del sitio. Si hay un servicio que la gente le pide y no está en la lista, agréguelo abajo.',
  objective_es = 'Esta lista se convierte en el menú principal de servicios del sitio web. El orden de los servicios refleja la demanda real de la gente, con los más pedidos primero.',
  helper_text = 'Lo que la gente más pide va primero en el menú del sitio.'
WHERE id = 'srv_11';

-- ============================================================
-- SECCIÓN 2 (continuación): 3 nuevas preguntas de ranking
-- ============================================================

INSERT OR REPLACE INTO ceo_questionnaire_questions
  (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, objective_es, required)
VALUES

('srv_19', 'servicios', 19, 'ranking',
 'Ordene estos factores según la importancia que tienen para que un cliente lo elija por sobre la competencia (1 = el factor más decisivo):',
 'Piense en las razones por las que un cliente firma con usted y no con otra empresa. Lo que más pesa define los argumentos principales de la comunicación.',
 '["Cercanía y atención personalizada","Precio competitivo","Calidad profesional de los guardias","Tecnología y herramientas modernas","Certificaciones y acreditaciones","Recomendación de otro cliente","Rapidez de respuesta a la consulta","Años de experiencia operando","Garantía de servicio","Disponibilidad inmediata (24/7)"]',
 'El factor #1 se convierte en el mensaje principal del sitio.',
 'El primer factor de la lista se convierte en el mensaje principal del sitio, de los anuncios de Google y de las propuestas comerciales. Los siguientes tres son los argumentos de apoyo.',
 1),

('srv_20', 'servicios', 20, 'ranking',
 'Ordene estos aspectos según la importancia que tienen para que un cliente se quede con ustedes mes tras mes (1 = lo que más retiene):',
 'Piense en por qué un cliente sigue con ustedes. Lo que más retiene es lo que tiene que aparecer destacado en la comunicación después de la firma.',
 '["Calidad consistente del servicio","Trato humano y cercano","Rapidez ante cualquier incidente","Reportes claros y oportunos","Guardia asignado estable que ya conoce el lugar","Supervisor presente y visible","Comunicación constante con el cliente","Cumplimiento estricto de turnos","Capacitación continua de los guardias","Imagen profesional (uniformes, presentación)"]',
 'Lo que más retiene es la promesa post-venta.',
 'Los tres primeros aspectos de la lista se convierten en la promesa post-venta del sitio y en la base de los reportes que se envían a los clientes actuales.',
 1),

('srv_21', 'servicios', 21, 'ranking',
 'Ordene estas razones por las que un cliente deja de contratar a una empresa de seguridad (1 = la más común en su experiencia):',
 'Piense en los clientes que se han ido o casi se van. La razón más común define cuál es la fuga que hay que prevenir con contenido del sitio.',
 '["El precio sube y no lo ven justificado","No perciben el valor del servicio","Les ofrecen algo mejor en otra empresa","Reducen presupuesto por crisis","Cambian a seguridad interna propia","Cierran el negocio o se mudan","Tuvieron un problema con un guardia","Incumplimiento de turnos o atrasos","Falta de comunicación","Piden cambios que no podemos hacer"]',
 'La fuga más común define qué contenido preventivo crear.',
 'La razón #1 de la lista define qué contenido se publica para que los clientes actuales no se vayan. Se usa en los reportes, en la comunicación periódica y en los argumentos de renovación.',
 1);

-- ============================================================
-- SECCIÓN 4 (servicios sigue): srv_18 → ranking
-- ============================================================

-- srv_18: CONVERTIR de multiple_choice a ranking
UPDATE ceo_questionnaire_questions SET
  type = 'ranking',
  question_es = 'Ordene estas certificaciones y acreditaciones según la importancia que tienen para GuardMan (1 = la más importante):',
  subtitle_es = 'Marque las que tiene, y póngalas en orden de importancia. Lo que más importa va primero en el sitio.',
  objective_es = 'Las certificaciones se publican en el footer de cada página del sitio y en una sección dedicada. Las más importantes aparecen primero.',
  options_json = '["Resolución OS-10 vigente (autorización de Carabineros)","Patente municipal al día","Mutualidad de Seguridad o IST al día","Seguro de responsabilidad civil","Seguro de robo y daños","Certificación ISO 9001 (calidad)","Certificación ISO 45001 (seguridad ocupacional)","Membresía en gremiales del rubro (ANACSE u otra)","Premios o reconocimientos sectoriales","Otra certificación específica (escribir en notas)"]',
  required = 0
WHERE id = 'srv_18';

-- ============================================================
-- SECCIÓN 5: limpiar menciones de SEO en dif_05 y dif_08
-- ============================================================

-- dif_05: "competidores SEO" → lenguaje cotidiano
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Sabe de alguna otra empresa de seguridad que aparezca muy por encima de usted cuando alguien busca en Google?',
  subtitle_es = 'Cuando alguien busca "seguridad en Santiago" o "portería en Las Condes", ¿quiénes salen primero? Si los conoce, los podemos estudiar y superar.',
  objective_es = 'Lista de competidores a los que se enfrenta GuardMan en internet. Saber contra quién competimos en las búsquedas en línea es el primer paso para que más gente encuentre a GuardMan y no a la competencia.'
WHERE id = 'dif_05';

-- dif_08: "E-E-A-T" → lenguaje cotidiano
UPDATE ceo_questionnaire_questions SET
  objective_es = 'La historia fundacional se publica en la página "Nosotros" del sitio, con foto del director. Una historia bien contada ayuda a que la gente confíe y elija a GuardMan por sobre otras opciones.'
WHERE id = 'dif_08';

-- ============================================================
-- Reordenar sort_order para que coincida con la nueva estructura
-- ============================================================
UPDATE ceo_questionnaire_questions SET sort_order = 1  WHERE id = 'id_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2  WHERE id = 'id_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3  WHERE id = 'id_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4  WHERE id = 'id_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5  WHERE id = 'id_05';
UPDATE ceo_questionnaire_questions SET sort_order = 6  WHERE id = 'id_06';
UPDATE ceo_questionnaire_questions SET sort_order = 7  WHERE id = 'id_07';
UPDATE ceo_questionnaire_questions SET sort_order = 8  WHERE id = 'id_08';
UPDATE ceo_questionnaire_questions SET sort_order = 1  WHERE id = 'srv_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2  WHERE id = 'srv_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3  WHERE id = 'srv_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4  WHERE id = 'srv_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5  WHERE id = 'srv_05';
UPDATE ceo_questionnaire_questions SET sort_order = 6  WHERE id = 'srv_06';
UPDATE ceo_questionnaire_questions SET sort_order = 7  WHERE id = 'srv_07';
UPDATE ceo_questionnaire_questions SET sort_order = 8  WHERE id = 'srv_08';
UPDATE ceo_questionnaire_questions SET sort_order = 9  WHERE id = 'srv_09';
UPDATE ceo_questionnaire_questions SET sort_order = 10 WHERE id = 'srv_10';
UPDATE ceo_questionnaire_questions SET sort_order = 11 WHERE id = 'srv_11';
UPDATE ceo_questionnaire_questions SET sort_order = 12 WHERE id = 'srv_12';
UPDATE ceo_questionnaire_questions SET sort_order = 13 WHERE id = 'srv_13';
UPDATE ceo_questionnaire_questions SET sort_order = 14 WHERE id = 'srv_14';
UPDATE ceo_questionnaire_questions SET sort_order = 15 WHERE id = 'srv_15';
UPDATE ceo_questionnaire_questions SET sort_order = 16 WHERE id = 'srv_16';
UPDATE ceo_questionnaire_questions SET sort_order = 17 WHERE id = 'srv_17';
UPDATE ceo_questionnaire_questions SET sort_order = 18 WHERE id = 'srv_18';
UPDATE ceo_questionnaire_questions SET sort_order = 19 WHERE id = 'srv_19';
UPDATE ceo_questionnaire_questions SET sort_order = 20 WHERE id = 'srv_20';
UPDATE ceo_questionnaire_questions SET sort_order = 21 WHERE id = 'srv_21';
UPDATE ceo_questionnaire_questions SET sort_order = 1  WHERE id = 'com_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2  WHERE id = 'com_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3  WHERE id = 'com_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4  WHERE id = 'com_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5  WHERE id = 'com_05';
UPDATE ceo_questionnaire_questions SET sort_order = 6  WHERE id = 'com_06';
UPDATE ceo_questionnaire_questions SET sort_order = 7  WHERE id = 'com_07';
UPDATE ceo_questionnaire_questions SET sort_order = 8  WHERE id = 'com_08';
UPDATE ceo_questionnaire_questions SET sort_order = 1  WHERE id = 'dif_01';
UPDATE ceo_questionnaire_questions SET sort_order = 2  WHERE id = 'dif_02';
UPDATE ceo_questionnaire_questions SET sort_order = 3  WHERE id = 'dif_03';
UPDATE ceo_questionnaire_questions SET sort_order = 4  WHERE id = 'dif_04';
UPDATE ceo_questionnaire_questions SET sort_order = 5  WHERE id = 'dif_05';
UPDATE ceo_questionnaire_questions SET sort_order = 6  WHERE id = 'dif_06';
UPDATE ceo_questionnaire_questions SET sort_order = 7  WHERE id = 'dif_07';
UPDATE ceo_questionnaire_questions SET sort_order = 8  WHERE id = 'dif_08';
