-- ============================================================
-- Seed Brand DNA from existing data across the ecosystem
-- ============================================================

-- COMPANY
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('company', 'legal_name', 'GuardMan Seguridad Privada SpA', 'string', 'Razón social legal'),
('company', 'brand_name', 'GuardMan Chile', 'string', 'Nombre de marca'),
('company', 'rut', '76.123.456-7', 'string', 'RUT de la empresa'),
('company', 'tagline', 'Protegemos lo que más te importa', 'string', 'Slogan principal'),
('company', 'description', 'Empresa líder en servicios de seguridad privada en Santiago de Chile. Con más de 8 años de experiencia, ofrecemos soluciones integrales de seguridad para empresas, condominios, eventos y residencias particulares. Contamos con un equipo de más de 500 guardias certificados y un centro de monitoreo propio operativo 24/7.', 'string', 'Descripción larga de la empresa'),
('company', 'short_description', 'Empresa líder en servicios de seguridad privada en Santiago. Guardias certificados OS-10, CCTV, control de accesos y monitoreo 24/7 en toda la Región Metropolitana.', 'string', 'Descripción corta (SEO)'),
('company', 'phone', '+56 9 300 000 10', 'string', 'Teléfono principal'),
('company', 'phone_display', '+56 9 300 000 10', 'string', 'Teléfono para mostrar'),
('company', 'whatsapp', '+56 9 3000 0010', 'string', 'WhatsApp Business'),
('company', 'email', 'info@guardman.cl', 'string', 'Email de contacto'),
('company', 'commercial_email', 'ventas@guardman.cl', 'string', 'Email comercial'),
('company', 'address', 'Av. Américo Vespucio Norte 1980, Providencia, Santiago, Chile', 'string', 'Dirección física'),
('company', 'address_street', 'Av. Américo Vespucio Norte 1980', 'string', 'Calle'),
('company', 'address_city', 'Providencia', 'string', 'Comuna'),
('company', 'address_region', 'Santiago', 'string', 'Región'),
('company', 'address_country', 'Chile', 'string', 'País'),
('company', 'postal_code', '7560000', 'string', 'Código postal'),
('company', 'latitude', '-33.4569', 'number', 'Latitud geográfica'),
('company', 'longitude', '-70.6483', 'number', 'Longitud geográfica'),
('company', 'site_url', 'https://guardman.cl', 'url', 'URL del sitio web'),
('company', 'price_range', '$$$', 'string', 'Rango de precios (Schema)');

-- SOCIAL
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('social', 'instagram', 'https://www.instagram.com/grupo_guardman', 'url', 'Instagram'),
('social', 'youtube', 'https://youtu.be/mqpLsKrwjAI', 'url', 'YouTube'),
('social', 'instagram_handle', '@grupo_guardman', 'string', 'Handle de Instagram');

-- STATS
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('stats', 'years', '8+', 'string', 'Años de experiencia'),
('stats', 'guards', '500+', 'string', 'Cantidad de guardias'),
('stats', 'clients', '200+', 'string', 'Clientes activos'),
('stats', 'locations', '14', 'string', 'Comunas cubiertas'),
('stats', 'rating', '4.8', 'number', 'Rating promedio'),
('stats', 'rating_count', '127', 'number', 'Cantidad de reviews');

-- HOURS
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('hours', 'schedule', '[{"day":"Lunes","hours":"24 horas"},{"day":"Martes","hours":"24 horas"},{"day":"Miércoles","hours":"24 horas"},{"day":"Jueves","hours":"24 horas"},{"day":"Viernes","hours":"24 horas"},{"day":"Sábado","hours":"24 horas"},{"day":"Domingo","hours":"24 horas"}]', 'json', 'Horario de atención'),
('hours', 'summary', '24/7', 'string', 'Resumen de horario');

-- COLORS
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('colors', 'primary_50', '#E8ECF1', 'color', 'Primary 50'),
('colors', 'primary_100', '#C5CED9', 'color', 'Primary 100'),
('colors', 'primary_200', '#8FA4BA', 'color', 'Primary 200'),
('colors', 'primary_300', '#5F7A96', 'color', 'Primary 300'),
('colors', 'primary_400', '#3A5572', 'color', 'Primary 400'),
('colors', 'primary_500', '#1A3A5C', 'color', 'Primary 500'),
('colors', 'primary_600', '#1A2744', 'color', 'Primary 600 (base)'),
('colors', 'primary_700', '#152038', 'color', 'Primary 700'),
('colors', 'primary_800', '#0F1829', 'color', 'Primary 800'),
('colors', 'primary_900', '#0A1019', 'color', 'Primary 900'),
('colors', 'secondary_500', '#4A4A4A', 'color', 'Secondary (Steel Gray)'),
('colors', 'accent', '#3B82F6', 'color', 'Accent Blue'),
('colors', 'accent_hover', '#2563EB', 'color', 'Accent Hover'),
('colors', 'success', '#10B981', 'color', 'Success Green'),
('colors', 'warning', '#F59E0B', 'color', 'Warning Yellow'),
('colors', 'error', '#EF4444', 'color', 'Error Red'),
('colors', 'sector_comercial', 'bg-blue-50 text-blue-800 border-blue-200', 'string', 'Sector Comercial'),
('colors', 'sector_industrial', 'bg-orange-50 text-orange-800 border-orange-200', 'string', 'Sector Industrial'),
('colors', 'sector_residencial', 'bg-emerald-50 text-emerald-800 border-emerald-200', 'string', 'Sector Residencial'),
('colors', 'sector_salud', 'bg-red-50 text-red-800 border-red-200', 'string', 'Sector Salud'),
('colors', 'sector_educacion', 'bg-violet-50 text-violet-800 border-violet-200', 'string', 'Sector Educación'),
('colors', 'sector_eventos', 'bg-fuchsia-50 text-fuchsia-800 border-fuchsia-200', 'string', 'Sector Eventos'),
('colors', 'sector_construccion', 'bg-amber-50 text-amber-800 border-amber-200', 'string', 'Sector Construcción'),
('colors', 'sector_automotriz', 'bg-cyan-50 text-cyan-800 border-cyan-200', 'string', 'Sector Automotriz'),
('colors', 'sector_hoteleria', 'bg-rose-50 text-rose-800 border-rose-200', 'string', 'Sector Hotelería'),
('colors', 'zone_oriente', 'bg-emerald-100 text-emerald-800 border-emerald-300', 'string', 'Zona Oriente'),
('colors', 'zone_centro', 'bg-blue-100 text-blue-800 border-blue-300', 'string', 'Zona Centro'),
('colors', 'zone_norte', 'bg-amber-100 text-amber-800 border-amber-300', 'string', 'Zona Norte'),
('colors', 'zone_sur', 'bg-red-100 text-red-800 border-red-300', 'string', 'Zona Sur'),
('colors', 'zone_poniente', 'bg-purple-100 text-purple-800 border-purple-300', 'string', 'Zona Poniente'),
('colors', 'zone_valparaiso', 'bg-teal-100 text-teal-800 border-teal-300', 'string', 'Zona Valparaíso');

-- VOICE
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('voice', 'tone', 'Profesional, orientado a conversión, en español chileno', 'string', 'Tono de comunicación'),
('voice', 'audience', 'Empresas, condominios, eventos y residencias que buscan seguridad privada profesional en Santiago y RM', 'string', 'Audiencia objetivo'),
('voice', 'language', 'Español chileno formal', 'string', 'Idioma y registro'),
('voice', 'personality', 'Confiable, profesional, cercano. Somos expertos en seguridad pero hablamos de forma accesible. No somos militaristas ni agresivos.', 'string', 'Personalidad de marca'),
('voice', ' forbidden_words', 'garantía 100%, impecable, infalible, mejor empresa, líder absoluto', 'string', 'Palabras prohibidas'),
('voice', 'mandatory_mentions', 'certificación OS-10, experiencia 8+ años, cobertura 14 comunas, centro de monitoreo propio', 'string', 'Menciones obligatorias en contenido');

-- DIFFERENTIATORS
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('differentiators', 'centro_monitoreo', 'Centro de monitoreo propio (no tercerizado) con redundancia y supervisión 24/7', 'string', 'Centro de Monitoreo'),
('differentiators', 'guard_pod', 'Unidad Autónoma de Vigilancia 24/7 — 15 meses de desarrollo propio (GuardPod V1)', 'string', 'Guard Pod'),
('differentiators', 'os10_academia', 'GuardMan tiene academia propia para certificación OS-10 — diferenciador único', 'string', 'Academia OS-10'),
('differentiators', 'cobertura_regional', 'Presencia en 14 comunas + Los Andes + San Felipe = escala única', 'string', 'Cobertura Regional'),
('differentiators', 'supervision_nocturna', 'Supervisión Nocturna Preventiva — Monitoreo proactivo de conductas sospechosas', 'string', 'Supervisión Nocturna'),
('differentiators', 'respuesta_certificada', 'Tiempos de respuesta garantizados contractualmente', 'string', 'Respuesta Inmediata'),
('differentiators', 'ajax_distribuidor', 'Distribuidores oficiales de Ajax Systems en Chile', 'string', 'Ajax Systems');

-- EXCLUSIONS
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('exclusions', 'no_competidores', 'No nombrar competidores directamente en contenido — usar "empresas del rubro" o similar', 'string', 'No mencionar competidores'),
('exclusions', 'no_garantias', 'No prometer "seguridad 100%" — esto es legalmente problemático y poco creíble', 'string', 'No prometer garantías'),
('exclusions', 'no_hype', 'No sobrevalorar tecnología — el factor humano sigue siendo clave', 'string', 'No hype tecnológico'),
('exclusions', 'no_precios', 'No mencionar precios específicos sin validar — puede afectar comerciales', 'string', 'No undercutting precios');

-- CERTIFICATIONS
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('certifications', 'autorizacion_laboral', 'Autorización de la Autoridad Administrativa Laboral (Chile) para servicios de seguridad privada', 'string', 'Autorización Laboral'),
('certifications', 'seguro_rc', 'Seguro de responsabilidad civil obligatorio', 'string', 'Seguro RC'),
('certifications', 'os10', 'Personal con certificación OS-10 vigente', 'string', 'Certificación OS-10'),
('certifications', 'antecedentes', 'Verificación de antecedentes para todo el personal', 'string', 'Verificación Antecedentes'),
('certifications', 'protocolos_carabineros', 'Protocolos de seguridad certificados por Carabineros de Chile', 'string', 'Protocolos Carabineros');

-- USPs
INSERT OR IGNORE INTO brand_dna (category, key, value, type, description) VALUES
('usps', 'guard_pod', 'GuardPod V1|Unidad Autónoma de Vigilancia 24/7 - 15 meses de desarrollo propio|shield-check', 'string', 'USP Guard Pod (título|desc|icon)'),
('usps', 'supervision_nocturna', 'Supervisión Nocturna Preventiva|Monitoreo proactivo de conductas sospechosas|eye', 'string', 'USP Supervisión'),
('usps', 'respuesta_inmediata', 'Respuesta Inmediata Certificada|Tiempos de respuesta garantizados contractualmente|clock', 'string', 'USP Respuesta'),
('usps', 'os10_cert', 'Personal Certificación OS-10|Todos nuestros guardias cuentan con certificación OS-10 vigente|badge-check', 'string', 'USP OS-10'),
('usps', 'centro_monitoreo', 'Centro de Monitoreo Propio|Con redundancia y supervisión 24/7|monitor', 'string', 'USP Monitoreo');
