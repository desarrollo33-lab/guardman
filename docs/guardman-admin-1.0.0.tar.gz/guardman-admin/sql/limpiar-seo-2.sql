-- Eliminar las 3 menciones de SEO en subtitle_es
UPDATE ceo_questionnaire_questions SET subtitle_es = 'Una estimación. No necesita el número exacto. Si está cerca del 30%, el problema puede ser el contenido del sitio. Si está cerca del 5%, el problema es la conversión.' WHERE id = 'com_05';

UPDATE ceo_questionnaire_questions SET subtitle_es = 'Si la gente le pide en un lugar donde usted no está, hay una demanda sin atender. Vale la pena saberlo.' WHERE id = 'dif_06';

UPDATE ceo_questionnaire_questions SET subtitle_es = 'Inventario de lo que tiene. Si tiene poco, vale la pena producir más. Las fotos reales son muy importantes para el sitio.' WHERE id = 'srv_17';
