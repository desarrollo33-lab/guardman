-- GuardMan — Section Versions table
-- Tracks individual section changes with version numbers.
-- Enables granular rollback without affecting other sections.

CREATE TABLE IF NOT EXISTS section_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_slug TEXT NOT NULL,
  section_key TEXT NOT NULL,
  version INTEGER NOT NULL,
  content_json TEXT NOT NULL,
  generated_by TEXT DEFAULT 'ai',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_section_versions_lookup
  ON section_versions(entity_type, entity_slug, section_key, version);

CREATE INDEX IF NOT EXISTS idx_section_versions_recent
  ON section_versions(entity_slug, section_key, created_at DESC);
