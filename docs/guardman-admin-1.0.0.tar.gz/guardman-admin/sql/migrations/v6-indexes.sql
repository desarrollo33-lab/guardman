-- GuardMan v6 — D1 Index Optimization (safe version)
-- Run: npx wrangler d1 execute guardman-seo --remote --file=sql/migrations/v6-indexes.sql
-- Only indexes columns confirmed by INSERT INTO statements in the codebase

-- ===== content_versions =====
CREATE INDEX IF NOT EXISTS idx_cv_entity_latest ON content_versions(entity_type, entity_slug, version DESC);
CREATE INDEX IF NOT EXISTS idx_cv_type ON content_versions(entity_type);
CREATE INDEX IF NOT EXISTS idx_cv_generated ON content_versions(generated_by);
CREATE INDEX IF NOT EXISTS idx_cv_created ON content_versions(created_at DESC);

-- ===== combo_content =====
CREATE INDEX IF NOT EXISTS idx_cc_status ON combo_content(status);
CREATE INDEX IF NOT EXISTS idx_cc_service ON combo_content(service_slug);
CREATE INDEX IF NOT EXISTS idx_cc_location ON combo_content(location_slug);

-- ===== serper_queries =====
CREATE INDEX IF NOT EXISTS idx_sq_service_location ON serper_queries(service_slug, location_slug);
CREATE INDEX IF NOT EXISTS idx_sq_status ON serper_queries(status);
CREATE INDEX IF NOT EXISTS idx_sq_executed ON serper_queries(executed_at DESC);

-- ===== serper_results =====
CREATE INDEX IF NOT EXISTS idx_sr_query ON serper_results(query_id);
CREATE INDEX IF NOT EXISTS idx_sr_site_type ON serper_results(site_type);
CREATE INDEX IF NOT EXISTS idx_sr_position ON serper_results(position);
CREATE INDEX IF NOT EXISTS idx_sr_domain ON serper_results(domain);

-- ===== publish_queue =====
CREATE INDEX IF NOT EXISTS idx_pq_status ON publish_queue(status);
CREATE INDEX IF NOT EXISTS idx_pq_score ON publish_queue(score DESC) WHERE status = 'approved';
CREATE INDEX IF NOT EXISTS idx_pq_entity ON publish_queue(entity_type, entity_slug);
CREATE INDEX IF NOT EXISTS idx_pq_created ON publish_queue(created_at DESC);

-- ===== published_versions =====
CREATE INDEX IF NOT EXISTS idx_pv_entity ON published_versions(entity_type, entity_slug, published_at DESC);

-- ===== entity_images =====
CREATE INDEX IF NOT EXISTS idx_ei_entity ON entity_images(entity_type, entity_slug);
CREATE INDEX IF NOT EXISTS idx_ei_primary ON entity_images(entity_type, entity_slug, is_primary DESC);

-- ===== agent_corrections =====
CREATE INDEX IF NOT EXISTS idx_ac_entity ON agent_corrections(entity_type, entity_slug);

-- ===== audit_reports =====
CREATE INDEX IF NOT EXISTS idx_ar_entity ON audit_reports(entity_type, entity_slug);

-- ===== position_snapshots =====
CREATE INDEX IF NOT EXISTS idx_ps_date ON position_snapshots(snapshot_date);
CREATE INDEX IF NOT EXISTS idx_ps_service ON position_snapshots(service_slug, location_slug, snapshot_date DESC);

-- ===== faqs =====
CREATE INDEX IF NOT EXISTS idx_faq_service ON faqs(service_slug, location_slug, frequency_rank);

-- ===== landmarks =====
CREATE INDEX IF NOT EXISTS idx_lm_location ON landmarks(location_slug, relevance_score DESC);

-- ===== agent_knowledge =====
CREATE INDEX IF NOT EXISTS idx_ak_category ON agent_knowledge(category, confidence DESC);

-- ===== scheduled_reports =====
CREATE INDEX IF NOT EXISTS idx_sr_type_date ON scheduled_reports(type, report_date DESC);

-- ===== chat_sessions =====
CREATE INDEX IF NOT EXISTS idx_cs_updated ON chat_sessions(updated_at DESC);
