-- ============================================================
-- Intel Module — Phase 1: CRM Core + Market Map
-- Tables for leads, clients, competitors, opportunities
-- ============================================================

-- ===== LEADS =====
CREATE TABLE IF NOT EXISTS intel_leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE,
  status TEXT DEFAULT 'new',
  source TEXT,

  -- Contacto
  contact_name TEXT NOT NULL,
  contact_email TEXT,
  contact_phone TEXT,
  company_name TEXT,
  company_rut TEXT,
  company_industry TEXT,

  -- Qué busca
  service_slug TEXT,
  location_slug TEXT,
  location_address TEXT,
  message TEXT,
  estimated_sqm REAL,
  has_existing_system INTEGER DEFAULT 0,

  -- Inteligencia automática (llenada desde Serper data)
  serper_opportunity_score REAL DEFAULT 0,
  competitor_density INT DEFAULT 0,
  guardman_position INT DEFAULT 999,
  market_difficulty TEXT DEFAULT 'unknown',

  -- Seguimiento
  assigned_to TEXT,
  first_contact_at TEXT,
  last_contact_at TEXT,
  next_follow_up TEXT,
  estimated_value REAL DEFAULT 0,
  probability REAL DEFAULT 0.3,

  -- Metadata
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  landing_page TEXT,
  ip_hash TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

-- ===== INTERACCIONES =====
CREATE TABLE IF NOT EXISTS intel_interactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES intel_leads(id),
  client_id INTEGER,
  type TEXT NOT NULL,
  direction TEXT DEFAULT 'outbound',
  summary TEXT,
  outcome TEXT,
  next_action TEXT,
  next_action_date TEXT,
  created_by TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

-- ===== PROPUESTAS =====
CREATE TABLE IF NOT EXISTS intel_proposals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES intel_leads(id),
  slug TEXT UNIQUE,
  status TEXT DEFAULT 'draft',
  services_json TEXT,
  total_monthly REAL DEFAULT 0,
  total_setup REAL DEFAULT 0,
  discount_pct REAL DEFAULT 0,
  valid_until TEXT,
  notes TEXT,
  ai_generated INTEGER DEFAULT 0,
  competitor_price_ref REAL,
  win_probability REAL DEFAULT 0.3,
  sent_at TEXT,
  viewed_at TEXT,
  responded_at TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

-- ===== CLIENTES =====
CREATE TABLE IF NOT EXISTS intel_clients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES intel_leads(id),
  slug TEXT UNIQUE,
  status TEXT DEFAULT 'active',

  -- Datos empresa
  company_name TEXT,
  company_rut TEXT,
  industry TEXT,
  size TEXT,
  employee_count INT,

  -- Contacto principal
  primary_contact_name TEXT,
  primary_contact_email TEXT,
  primary_contact_phone TEXT,

  -- Contrato
  contract_start TEXT,
  contract_end TEXT,
  contract_type TEXT,
  monthly_value REAL DEFAULT 0,

  -- Ubicación
  location_slug TEXT,
  address TEXT,
  latitude REAL,
  longitude REAL,

  -- Inteligencia
  serper_sentiment TEXT DEFAULT 'neutral',
  renewal_risk TEXT DEFAULT 'low',

  -- Metadata
  notes TEXT,
  tags TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

-- ===== SERVICIOS POR CLIENTE =====
CREATE TABLE IF NOT EXISTS intel_client_services (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client_id INTEGER REFERENCES intel_clients(id),
  service_slug TEXT NOT NULL,
  status TEXT DEFAULT 'active',
  quantity INT DEFAULT 1,
  unit TEXT,
  monthly_price REAL,
  start_date TEXT,
  end_date TEXT,
  notes TEXT
);

-- ===== COMPETIDORES ENRIQUECIDOS =====
CREATE TABLE IF NOT EXISTS intel_competitors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain TEXT UNIQUE NOT NULL,
  company_name TEXT,
  status TEXT DEFAULT 'active',

  -- Presencia digital
  website_url TEXT,
  has_ssl INTEGER DEFAULT 0,
  website_quality TEXT,
  has_blog INTEGER DEFAULT 0,
  has_pricing_page INTEGER DEFAULT 0,
  has_whatsapp INTEGER DEFAULT 0,
  google_rating REAL,
  google_reviews INT,
  google_business_name TEXT,

  -- Presencia Serper
  total_appearances INT DEFAULT 0,
  services_present INT DEFAULT 0,
  locations_present INT DEFAULT 0,
  avg_position REAL DEFAULT 0,
  best_position INT DEFAULT 999,
  estimated_monthly_budget REAL DEFAULT 0,

  -- Análisis
  strengths TEXT,
  weaknesses TEXT,
  pricing_strategy TEXT DEFAULT 'unknown',
  target_market TEXT DEFAULT 'general',
  certifications TEXT,

  -- Amenaza
  threat_level TEXT DEFAULT 'medium',
  trend TEXT DEFAULT 'stable',

  -- Metadata
  last_analyzed TEXT,
  notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

-- ===== OPORTUNIDADES DE MERCADO =====
CREATE TABLE IF NOT EXISTS intel_opportunities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  priority TEXT DEFAULT 'medium',
  status TEXT DEFAULT 'open',

  service_slug TEXT,
  location_slug TEXT,

  title TEXT NOT NULL,
  description TEXT,
  evidence_json TEXT,
  estimated_value REAL DEFAULT 0,
  effort TEXT DEFAULT 'medium',
  roi_score REAL DEFAULT 0,

  lead_id INTEGER REFERENCES intel_leads(id),
  assigned_to TEXT,

  competitor_count INT DEFAULT 0,
  guardman_position INT DEFAULT 999,
  search_volume_estimate INT DEFAULT 0,

  created_at TEXT DEFAULT (datetime('now')),
  expires_at TEXT
);

-- ===== ÍNDICES =====
CREATE INDEX IF NOT EXISTS idx_intel_leads_status ON intel_leads(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_intel_leads_service ON intel_leads(service_slug, location_slug);
CREATE INDEX IF NOT EXISTS idx_intel_leads_company ON intel_leads(company_name);
CREATE INDEX IF NOT EXISTS idx_intel_interactions_lead ON intel_interactions(lead_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_intel_interactions_client ON intel_interactions(client_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_intel_proposals_lead ON intel_proposals(lead_id);
CREATE INDEX IF NOT EXISTS idx_intel_proposals_status ON intel_proposals(status);
CREATE INDEX IF NOT EXISTS idx_intel_clients_status ON intel_clients(status);
CREATE INDEX IF NOT EXISTS idx_intel_clients_industry ON intel_clients(industry);
CREATE INDEX IF NOT EXISTS idx_intel_client_services_client ON intel_client_services(client_id);
CREATE INDEX IF NOT EXISTS idx_intel_competitors_domain ON intel_competitors(domain);
CREATE INDEX IF NOT EXISTS idx_intel_competitors_threat ON intel_competitors(threat_level);
CREATE INDEX IF NOT EXISTS idx_intel_opportunities_type ON intel_opportunities(type, priority);
CREATE INDEX IF NOT EXISTS idx_intel_opportunities_status ON intel_opportunities(status, priority DESC);
