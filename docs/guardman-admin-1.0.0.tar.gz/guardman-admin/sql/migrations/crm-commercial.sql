-- ============================================================
-- CRM Comercial — Fases CRM-1 a CRM-6
-- Nuevos campos y tablas para pipeline comercial, visitas técnicas,
-- cotizaciones versionadas, y tareas.
-- ============================================================

-- ----- CRM-1: Cualificación + Motivo Pérdida + SLA -----
ALTER TABLE intel_leads ADD COLUMN facility_type TEXT;
ALTER TABLE intel_leads ADD COLUMN facility_sqm INTEGER;
ALTER TABLE intel_leads ADD COLUMN has_current_security INTEGER DEFAULT 0;
ALTER TABLE intel_leads ADD COLUMN current_competitor TEXT;
ALTER TABLE intel_leads ADD COLUMN current_contract_end TEXT;
ALTER TABLE intel_leads ADD COLUMN shifts_needed INTEGER;
ALTER TABLE intel_leads ADD COLUMN armed_service INTEGER DEFAULT 0;
ALTER TABLE intel_leads ADD COLUMN no_contact_attempts INTEGER DEFAULT 0;
ALTER TABLE intel_leads ADD COLUMN loss_reason TEXT;
ALTER TABLE intel_leads ADD COLUMN loss_competitor TEXT;
ALTER TABLE intel_leads ADD COLUMN loss_price_ref REAL;
ALTER TABLE intel_leads ADD COLUMN last_activity_at TEXT;
ALTER TABLE intel_leads ADD COLUMN frozen_flag INTEGER DEFAULT 0;

CREATE TABLE IF NOT EXISTS intel_contact_attempts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES intel_leads(id),
  attempt_number INTEGER,
  attempted_at TEXT DEFAULT (datetime('now')),
  result TEXT
);

CREATE INDEX IF NOT EXISTS idx_leads_status ON intel_leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_last_activity ON intel_leads(last_activity_at);
CREATE INDEX IF NOT EXISTS idx_leads_frozen ON intel_leads(frozen_flag);

-- ----- CRM-2: Visitas Técnicas -----
CREATE TABLE IF NOT EXISTS intel_visits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER REFERENCES intel_leads(id),
  visit_date TEXT NOT NULL,
  facility_type TEXT,
  facility_sqm INTEGER,
  num_access_points INTEGER,
  has_current_security INTEGER DEFAULT 0,
  current_competitor TEXT,
  current_contract_end TEXT,
  shifts_needed INTEGER,
  armed_service INTEGER DEFAULT 0,
  risks_noted TEXT,
  notes TEXT,
  photos_count INTEGER DEFAULT 0,
  completed_at TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS intel_visit_photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  visit_id INTEGER REFERENCES intel_visits(id),
  r2_key TEXT NOT NULL,
  caption TEXT,
  photo_order INTEGER,
  created_at TEXT DEFAULT (datetime('now'))
);

-- ----- CRM-4: Items de Cotización + Versionado -----
CREATE TABLE IF NOT EXISTS intel_proposal_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  proposal_id INTEGER REFERENCES intel_proposals(id),
  service_type TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price REAL NOT NULL,
  total REAL NOT NULL,
  details TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

ALTER TABLE intel_proposals ADD COLUMN contract_period_months INTEGER;
ALTER TABLE intel_proposals ADD COLUMN payment_terms TEXT;
ALTER TABLE intel_proposals ADD COLUMN annual_adjustment TEXT;
ALTER TABLE intel_proposals ADD COLUMN sla_response_minutes INTEGER;
ALTER TABLE intel_proposals ADD COLUMN version INTEGER DEFAULT 1;
ALTER TABLE intel_proposals ADD COLUMN parent_proposal_id INTEGER;
ALTER TABLE intel_proposals ADD COLUMN executive_notes TEXT;
