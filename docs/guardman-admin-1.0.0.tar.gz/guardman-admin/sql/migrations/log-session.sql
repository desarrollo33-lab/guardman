-- Workflow Logs Table
-- Stores workflow execution events for monitoring and debugging
CREATE TABLE IF NOT EXISTS workflow_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  workflow_type TEXT NOT NULL,
  instance_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  data_json TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_workflow_logs_type ON workflow_logs(workflow_type);
CREATE INDEX IF NOT EXISTS idx_workflow_logs_instance ON workflow_logs(instance_id);
CREATE INDEX IF NOT EXISTS idx_workflow_logs_created ON workflow_logs(created_at);
