-- GuardMan v4 — published_versions table
-- Required by publish-pipeline.ts and publisher-agent.ts
-- Stores successfully published content versions for history tracking

CREATE TABLE IF NOT EXISTS published_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_slug TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  content_json TEXT,
  score REAL DEFAULT 0,
  published_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(entity_type, entity_slug, version)
);

-- Index for fast lookup of latest published version per entity
CREATE INDEX IF NOT EXISTS idx_published_versions_entity 
  ON published_versions(entity_type, entity_slug, published_at DESC);
