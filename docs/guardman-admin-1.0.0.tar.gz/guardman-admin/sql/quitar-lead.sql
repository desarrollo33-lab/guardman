UPDATE ceo_questionnaire_questions
SET objective_es = 'Define la urgencia del seguimiento. Si pasan más de 24 horas entre el contacto y la primera respuesta, el cliente potencial se enfría. Esto obliga a definir un protocolo de respuesta inmediata.'
WHERE id = 'com_06';
