-- GuardMan Admin v2.0 — Publish Log Table
-- Tracks every publish action for change control & audit

CREATE TABLE IF NOT EXISTS publish_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,       -- 'service', 'location', 'sector', 'combo', 'page'
  entity_slug TEXT NOT NULL,       -- slug or 'service/location' for combos
  from_version INTEGER NOT NULL,   -- version before publish
  to_version INTEGER NOT NULL,     -- version after publish
  action TEXT NOT NULL DEFAULT 'draft',  -- 'draft', 'published', 'synced', 'deployed'
  published_by TEXT DEFAULT 'admin',
  published_at TEXT DEFAULT (datetime('now')),
  deploy_id TEXT,                  -- Cloudflare Pages deployment ID
  deploy_url TEXT,                 -- Preview URL
  status TEXT DEFAULT 'pending',   -- 'pending', 'syncing', 'synced', 'deploying', 'deployed', 'failed'
  error_message TEXT,
  content_snapshot TEXT            -- JSON snapshot of published content (for rollback)
);

CREATE INDEX IF NOT EXISTS idx_publish_log_entity ON publish_log(entity_type, entity_slug);
CREATE INDEX IF NOT EXISTS idx_publish_log_status ON publish_log(status);
CREATE INDEX IF NOT EXISTS idx_publish_log_at ON publish_log(published_at DESC);
