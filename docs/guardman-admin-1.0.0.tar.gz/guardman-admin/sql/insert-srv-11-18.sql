-- Insertar preguntas nuevas srv_11 a srv_18
INSERT INTO ceo_questionnaire_questions
  (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, objective_es, required)
VALUES

('srv_11', 'servicios', 11, 'multiple_choice',
 'De los servicios que ofrece, ¿cuáles son los que más le piden? (marque los principales)',
 'Esta lista alimenta directamente las páginas de servicios del sitio. Las que más pide la gente van primero.',
 '["Portería en edificios residenciales","Portería en oficinas y empresas","Rondas y vigilancia perimetral","Control de acceso","Conserjería","Seguridad para retail y locales","Seguridad para eventos","Escolta privada y protección de personas","Monitoreo de cámaras de seguridad y alarmas","Asesoría y auditoría de seguridad","Instalación de sistemas (cámaras, alarmas)","Investigaciones privadas","Seguridad para condominios","Seguridad industrial y faenas"]',
 'Lo que la gente más pide va primero en el menú del sitio.',
 'Esta lista se convierte en el menú principal de servicios del sitio web. El orden de los servicios refleja la demanda real de la gente.',
 1),

('srv_12', 'servicios', 12, 'free_text',
 '¿Hay algo que la gente le pida seguido y que hoy GuardMan no ofrezca?',
 'Servicios que le consultan, pero que termina rechazando o derivando a otro. Vale la pena saberlo porque puede ser una oportunidad.',
 '[]',
 'Una demanda frecuente sin oferta es una oportunidad de catálogo.',
 'Detectar servicios que la gente busca pero GuardMan no entrega. Si la demanda es alta, vale la pena desarrollarlos y publicarlos en el sitio.',
 1),

('srv_13', 'servicios', 13, 'free_text',
 'De todos los servicios que ofrece, ¿cuál es el que más le gusta dar? ¿Cuál le da más orgullo?',
 'No el más rentable, sino el que más le gusta. El que lo hace sentir que hace la diferencia.',
 '[]',
 NULL,
 'Este servicio se convierte en la "joya" de la home del sitio. Es el que más se destaca visualmente porque es el que mejor representa a GuardMan.',
 1),

('srv_14', 'servicios', 14, 'free_text',
 '¿Tiene algún cliente cuyo caso le enorgullezca particularmente? Cuéntelo con detalle.',
 'No necesita el nombre. Describa la situación, qué problema tenía el cliente, qué hizo GuardMan, qué pasó después. Si tiene números concretos, mejor.',
 '[]',
 'Un caso de éxito con números concretos puede ser la página más vista del sitio.',
 'Este caso se publica en el sitio como historia de éxito. Las historias reales con cifras convierten más que cualquier texto publicitario.',
 1),

('srv_15', 'servicios', 15, 'free_text',
 '¿Cuántos años lleva operando GuardMan?',
 'El año de fundación. Va a aparecer en el sitio como prueba de experiencia.',
 '[]',
 NULL,
 'Los años de operación son un factor de autoridad para Google. "Operando desde el año X" se publica en el hero y en el footer.',
 1),

('srv_16', 'servicios', 16, 'free_text',
 '¿Cuántos clientes ha tenido GuardMan en su historia, sumando los que ya no son clientes?',
 'Un número total acumulado. Es un número de prueba social muy fuerte.',
 '[]',
 NULL,
 'Este número se publica en el sitio como prueba de trayectoria. Es uno de los indicadores de confianza más buscados por los prospectos.',
 1),

('srv_17', 'servicios', 17, 'free_text',
 '¿Tiene fotos o videos de operaciones reales de GuardMan? (guardias, rondas, controles, eventos)',
 'Inventario de lo que tiene. Si tiene poco, vale la pena producir más. Las fotos reales son muy importantes para SEO local.',
 '[]',
 NULL,
 'Las fotos y videos reales se publican en el sitio. Google prioriza sitios con imágenes auténticas. Las fotos reales también generan más confianza que las de banco de imágenes.',
 1),

('srv_18', 'servicios', 18, 'multiple_choice',
 '¿Tiene alguna certificación, resolución OS-10, o acreditación específica que lo respalde?',
 'Marque todas las que apliquen. Cada certificación es un punto de confianza adicional para el cliente y un factor de autoridad para Google.',
 '["Resolución OS-10 vigente (autorización de Carabineros)","Patente municipal al día","Mutualidad de Seguridad o IST al día","Seguro de responsabilidad civil","Seguro de robo y daños","Certificación ISO 9001 (calidad)","Certificación ISO 45001 (seguridad ocupacional)","Membresía en gremiales del rubro (ANACSE u otra)","Premios o reconocimientos sectoriales","Ninguna en particular","Otra certificación específica (escribir en notas)"]',
 NULL,
 'Las certificaciones se publican en el footer de cada página y en una sección dedicada. Son factores de E-E-A-T (experiencia, especialización, autoridad, confianza) que Google usa para rankear.',
 1);
