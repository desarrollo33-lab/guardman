-- ============================================================
-- GuardMan Media Library — Single source of truth for images
-- ============================================================

-- Main image registry
CREATE TABLE IF NOT EXISTS media_library (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT NOT NULL UNIQUE,           -- R2 key: media/hero-home.webp
  filename TEXT NOT NULL,             -- hero-home.webp
  alt_text TEXT DEFAULT '',
  mime_type TEXT NOT NULL DEFAULT 'image/webp',
  file_size INTEGER DEFAULT 0,
  width INTEGER DEFAULT 0,
  height INTEGER DEFAULT 0,
  category TEXT NOT NULL DEFAULT 'generic',  -- hero | service | sector | client | staff | cta | og | badge | ajax | generic
  tags TEXT DEFAULT '[]',             -- JSON array: ["hero","homepage"]
  created_at TEXT DEFAULT (datetime('now'))
);

-- Many-to-many: image ↔ entity usage
CREATE TABLE IF NOT EXISTS media_entities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  media_id INTEGER NOT NULL REFERENCES media_library(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL,          -- service | sector | location | combo | homepage | global | client
  entity_slug TEXT NOT NULL,          -- guardias-de-seguridad | industrial | global | etc.
  usage TEXT NOT NULL DEFAULT 'hero', -- hero | cta | badge | og | gallery | staff | logo
  sort_order INTEGER DEFAULT 0,
  UNIQUE(media_id, entity_type, entity_slug, usage)
);

CREATE INDEX IF NOT EXISTS idx_ml_category ON media_library(category);
CREATE INDEX IF NOT EXISTS idx_ml_tags ON media_library(tags);
CREATE INDEX IF NOT EXISTS idx_me_entity ON media_entities(entity_type, entity_slug);
CREATE INDEX IF NOT EXISTS idx_me_media ON media_entities(media_id);
