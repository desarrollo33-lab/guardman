-- ============================================================
-- GuardMan · Cuestionario CEO v3 — Mejoras basadas en patrón DCR
-- Principios:
--   1. Lenguaje conversacional, personal, de confianza (usted)
--   2. Opciones ricas con contexto descriptivo (como DCR)
--   3. Reducir free_text (28→15), aumentar ranking/choice con opciones
--   4. Cada pregunta tiene un "por qué" claro en objective_es
--   5. Reorganizar el flujo: origen → terreno → personas → competencia
-- ============================================================

-- ═══════════════════════════════════════════════════════════════
-- SECCIÓN 1: identidad — LO QUE LOS OJOS DEL CLIENTE VEN
-- (8 preguntas, todas se mantienen pero mejoradas)
-- ═══════════════════════════════════════════════════════════════

-- id_01: free_text → REWRITE pregunta más inspiradora
UPDATE ceo_questionnaire_questions SET
  question_es = 'Si uno de sus clientes más antiguos tuviera que recomendar a GuardMan en una sola frase, ¿qué cree que diría? Póngase en sus zapatos. Use SUS palabras.',
  subtitle_es = 'No lo piense como Rodrigo Mora, piénselo como don Carlos, que lleva tres años con GuardMan y ya no se imagina su edificio sin ellos. ¿Qué le diría don Carlos a un amigo que necesita seguridad?',
  objective_es = 'Esta frase se convierte en el mensaje principal. Es lo primero que una persona lee cuando conoce a GuardMan. Por eso necesita ser auténtica. No publicitaria. Real.',
  helper_text = 'La frase más importante del cuestionario. Tómese el tiempo que necesite. Cuanto más auténtica, más efectiva.'
WHERE id = 'id_01';

-- id_02: free_text → MEJORAR con ejemplos más ricos y personales
UPDATE ceo_questionnaire_questions SET
  question_es = 'Cuando suena el teléfono y es alguien que nunca ha llamado antes, ¿qué es lo primero que le dice? Escriba varios ejemplos reales. Las palabras exactas.',
  subtitle_es = 'No lo que usted espera oír. Lo que realmente le dicen. Por ejemplo: "mire, me robaron dos veces en el local y ya no sé qué hacer", o "necesito un guardia para el edificio, ¿cuánto cobran más o menos?". Mientras más ejemplos, mejor.',
  objective_es = 'Cada una de estas frases es literalmente lo que la gente dice cuando necesita seguridad. GuardMan necesita poder responder a cada una. Cada frase que usted escriba aquí se convierte en un texto que responde a esa duda concreta.',
  helper_text = 'Escriba todos los que recuerde. Cinco, diez, los que sean. Cada uno es valioso.'
WHERE id = 'id_02';

-- id_03: free_text → RANKING con opciones de preguntas frecuentes reales
UPDATE ceo_questionnaire_questions SET
  type = 'ranking',
  question_es = 'Ordene estas preguntas según la frecuencia con que se las hacen. Ponga primero la que más escucha:',
  subtitle_es = 'Las preguntas que ya sabe de memoria. Esas que contesta tres veces al día y ya ni las piensa. Si hay alguna que no está en la lista, agréguela con el botón de abajo.',
  options_json = '[
    "¿Cuánto cobran por un guardia al mes?",
    "¿Los guardias están todos certificados por Carabineros?",
    "¿Qué pasa si el guardia falta un día? ¿Tienen reemplazo?",
    "¿Tienen cobertura de seguro si pasa algo?",
    "¿Hace cuánto que trabajan con edificios como el mío?",
    "¿Puedo hablar con algún cliente que tengan para preguntarle cómo le ha ido?",
    "¿Me pueden mandar una cotización por correo para revisarla?",
    "¿Cuánta gente tienen trabajando? ¿Son muchos o pocos?",
    "¿Hasta qué hora trabajan? ¿Hay servicio nocturno?",
    "¿Qué diferencia tienen con Securitas o Prosegur?"
  ]',
  objective_es = 'Estas preguntas son lo que la gente realmente quiere saber antes de decidir. Las tres primeras se convierten en las preguntas frecuentes destacadas. Si GuardMan las responde antes de que la persona pregunte, la decisión es más rápida.',
  helper_text = 'Piense en lo que le preguntan esta semana. No lo que le preguntaban hace cinco años.'
WHERE id = 'id_03';

-- id_04: free_text → MEJORAR pregunta más desafiante
UPDATE ceo_questionnaire_questions SET
  question_es = 'Un amigo suyo, de toda la vida, le dice: "Rodrigo, ¿de verdad vale la pena pagar seguridad privada? ¿No es un lujo nomás?". ¿Qué le responde?',
  subtitle_es = 'No la respuesta de catálogo. La respuesta de verdad. La que le daría a un amigo tomando un café. Esa es la que convence.',
  objective_es = 'Esta respuesta es la más honesta que puede dar. Cuando la gente lee algo que suena a verdad y no a publicidad, confía. Esta respuesta se convierte en el argumento principal de por qué la seguridad privada vale la pena.',
  helper_text = 'Piense en esa conversación real. No en el brochure.'
WHERE id = 'id_04';

-- id_05: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene alguna frase, dicho o manera de explicar las cosas que repite mucho cuando habla con clientes? Algo que sea muy suyo.',
  subtitle_es = 'Esa muletilla, esa forma de cerrar una conversación, ese argumento que siempre funciona. Si no tiene una, no importa. Pero si la tiene, es más valiosa que cualquier eslogan.',
  objective_es = 'Si usted tiene una forma propia de decir las cosas, esa es la voz de GuardMan. No hay que inventar nada. Solo hay que escribir lo que usted ya dice.',
  helper_text = 'Puede ser una frase corta o una idea. Lo que sea que repita.'
WHERE id = 'id_05';

-- id_06: free_text → SINGLE_CHOICE con opciones de errores comunes MÁS RICAS
UPDATE ceo_questionnaire_questions SET
  type = 'single_choice',
  question_es = 'En todos sus años en esto, ¿cuál es el error más grave que comete la gente cuando busca seguridad privada? El que más ha visto.',
  subtitle_es = 'Ese error que usted ya sabe identificar a los cinco minutos de hablar con alguien. El que le hace pensar "otra vez lo mismo". Elija el que más le resuene.',
  options_json = '[
    "Contratan por precio y después pagan las consecuencias: guardias sin experiencia, rotación constante, el día que falta uno no hay reemplazo",
    "No preguntan por la certificación OS-10: cualquiera puede decir que es empresa de seguridad, pero pocas tienen la autorización real de Carabineros",
    "Asumen que todas las empresas son iguales: no comparan capacitación, no preguntan por supervisión, no revisan seguros",
    "No entienden la diferencia entre un portero del edificio y un guardia de seguridad profesional: uno abre la puerta, el otro protege",
    "No revisan referencias: contratan a la primera que les sale en el teléfono sin preguntarle a nadie cómo trabaja",
    "Subestiman el riesgo hasta que pasa algo: creen que nunca les va a tocar y cuando les toca ya es tarde",
    "No leen el contrato: firman sin saber qué incluye el servicio, qué excluye, qué pasa si hay un incidente"
  ]',
  objective_es = 'Este error es el punto de entrada para todo lo que GuardMan puede enseñar. Cuando usted corrige este error, la persona deja de verlo como un gasto y empieza a verlo como lo que es: protección para su patrimonio y su gente.',
  helper_text = 'El error que más le molesta ver. Ese es el que más convence cuando lo explica.'
WHERE id = 'id_06';

-- id_07: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = 'Piense en esa vez que un cliente lo recomendó. No porque usted se lo pidió, sino porque quiso. ¿Qué cree que dijo de usted?',
  subtitle_es = 'La recomendación voluntaria es el acto de confianza más grande que existe. Alguien puso su propio prestigio en juego para recomendarlo a usted. ¿Con qué palabras lo habrá hecho?',
  objective_es = 'Lo que la gente dice cuando recomienda sin que nadie se lo pida es más poderoso que cualquier publicidad. Estas frases se publican como testimonios porque suenan a verdad.',
  helper_text = 'No invente. Recuerde de verdad. Póngase en los zapatos de quien lo recomendó.'
WHERE id = 'id_07';

-- id_08: free_text → SINGLE_CHOICE con opciones
UPDATE ceo_questionnaire_questions SET
  type = 'single_choice',
  question_es = 'Cuando alguien lo contacta por primera vez, ¿cuál es la pregunta que le hace antes que cualquier otra cosa? La que abre todas las conversaciones.',
  subtitle_es = 'No la segunda ni la tercera. La PRIMERA. Esa pregunta define lo que la persona necesita saber ya, ahora, antes de seguir hablando. Si usted la responde en el acto, ganó.',
  options_json = '[
    "¿Cuánto cuesta? (necesita saber si está dentro de su presupuesto antes de seguir)",
    "¿Están autorizados por Carabineros? (quiere asegurarse de que son una empresa formal)",
    "¿Trabajan en mi comuna? (si no llegan hasta donde está, no hay nada más que hablar)",
    "¿Tienen disponibilidad ahora? (necesita el servicio urgente, para ayer)",
    "¿Con qué tipo de clientes trabajan? (quiere saber si entienden su rubro)",
    "¿Me puede mandar referencias? (quiere hablar con alguien que ya los haya contratado)",
    "¿Qué incluye el servicio exactamente? (quiere entender qué está comprando)"
  ]',
  objective_es = 'La primera pregunta del cliente es la primera respuesta que GuardMan debe dar. En los primeros segundos. Si no la responde, la persona se va.',
  helper_text = 'Piense en la última llamada que recibió. ¿Qué le preguntaron primero?'
WHERE id = 'id_08';

-- ═══════════════════════════════════════════════════════════════
-- SECCIÓN 2: servicios — EL TERRITORIO
-- (20 preguntas, todas mejoradas en opciones y redacción)
-- ═══════════════════════════════════════════════════════════════

-- srv_01: multiple_choice → MEJORAR opciones agrupadas con descripción
UPDATE ceo_questionnaire_questions SET
  question_es = 'Marque todas las comunas donde GuardMan tiene clientes hoy. Cada comuna donde haya al menos un contrato activo.',
  subtitle_es = 'Esto no es un catálogo. Es un mapa real de dónde está su operación. Marque incluso las comunas donde tiene un solo cliente. Si una comuna no aparece en la lista, agréguela abajo.',
  options_json = '[
    "Las Condes — zona oriente alta, casas y edificios premium",
    "Vitacura — zona oriente premium, residencial y oficinas",
    "Lo Barnechea — zona oriente residencial, casas y condominios",
    "Providencia — zona oriente mixta, edificios de oficinas y residenciales",
    "Ñuñoa — zona centro-sur, barrios consolidados y edificios",
    "Santiago Centro — zona centro, alta densidad comercial y residencial",
    "Maipú — zona poniente, grandes condominios y comercio local",
    "Pudahuel — zona poniente, comercio y residencial",
    "Estación Central — zona poniente, comercio y residencial",
    "Puente Alto — zona sur, condominios y casas",
    "San Bernardo — zona sur, residencial e industrial",
    "La Florida — zona sur, residencial y locales comerciales",
    "Macul — zona sur, universitario y residencial",
    "Peñalolén — zona sur, barrios residenciales y condominios",
    "La Reina — zona oriente, residencial",
    "Huechuraba — zona centro-norte, oficinas corporativas y residencial",
    "Quilicura — zona norte, comercio y residencial",
    "Renca — zona norte, residencial y faenas",
    "San Miguel — zona sur, residencial e industrial",
    "La Cisterna — zona sur, residencial y comercio",
    "Cerrillos — zona sur, residencial y comercio",
    "Colina — zona norte, condominios"
  ]',
  objective_es = 'Estas comunas son el territorio real de GuardMan. Cada una representa clientes que ya confían. El material de presentación se organiza por estas zonas, con lo que ya existe primero.',
  helper_text = 'Marque aunque tenga un solo cliente en esa comuna.'
WHERE id = 'srv_01';

-- srv_02: ranking → MEJORAR opciones con contexto
UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene estos grupos de comunas según la cantidad de gente que lo contacta preguntando por el servicio. Ponga primero donde más lo buscan:',
  subtitle_es = 'No piense en dónde TIENE clientes. Piense en dónde lo LLAMAN. A veces son lugares distintos. Esto define dónde está la demanda real.',
  options_json = '[
    "Las Condes, Vitacura, Lo Barnechea — zona oriente premium, mucha llamada de edificios y casas",
    "Providencia, Ñuñoa, Santiago Centro — zona central densa, mucha oficina y comercio",
    "Maipú, Pudahuel, Estación Central — zona poniente, condominios y locales",
    "Puente Alto, San Bernardo — zona sur, residencial e industrial",
    "La Florida, Macul, Peñalolén — zona sur, residencial y condominios",
    "Huechuraba, Quilicura, Renca — zona norte, oficinas y comercio",
    "San Miguel, La Cisterna — zona sur, residencial",
    "Colina, Lampa — zona norte, condominios nuevos",
    "Fuera de Santiago — regiones"
  ]',
  objective_es = 'Donde más lo buscan es donde GuardMan necesita estar más presente. El primer grupo de la lista recibe prioridad en todo lo que se prepara sobre el servicio.',
  helper_text = 'Pregúntese sinceramente: ¿de dónde me llaman más?'
WHERE id = 'srv_02';

-- srv_03: single_choice → MEJORAR opciones con descripción
UPDATE ceo_questionnaire_questions SET
  question_es = 'Si tuviera que elegir una sola comuna donde GuardMan es más conocido y donde más lo buscan, ¿cuál sería?',
  subtitle_es = 'Esa comuna donde usted siente que ya lo conocen. Donde el nombre GuardMan suena y la gente dice "ah, sí, los he visto". Esa es su plaza fuerte.',
  options_json = '[
    "Las Condes",
    "Vitacura",
    "Lo Barnechea",
    "Providencia",
    "Ñuñoa",
    "Santiago Centro",
    "Maipú",
    "Puente Alto",
    "La Florida",
    "Huechuraba",
    "Otra (escríbala en notas)"
  ]',
  objective_es = 'La comuna donde GuardMan tiene más presencia es donde todo se refuerza primero. Es la vitrina principal de lo que la empresa puede hacer.',
  helper_text = 'La comuna donde usted ya es conocido. No donde quiere ser conocido.'
WHERE id = 'srv_03';

-- srv_04: single_choice → OK pero mejorar redacción
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Tiene clientes fuera de Santiago?',
  subtitle_es = 'Si tiene aunque sea uno en región, responda que sí. Esto cambia la manera en que GuardMan se presenta.',
  options_json = '[
    "No, solo en Santiago por ahora",
    "Sí, en una región",
    "Sí, en dos o tres regiones",
    "Sí, en varias regiones del país"
  ]',
  objective_es = 'Si GuardMan opera en regiones, la presentación tiene que reflejarlo. Si solo está en Santiago, toda la fuerza se concentra en la capital.',
  helper_text = 'Un solo cliente en región ya cuenta como sí.'
WHERE id = 'srv_04';

-- srv_05: free_text → MEJORAR pregunta más concreta
UPDATE ceo_questionnaire_questions SET
  question_es = '¿En alguna comuna la gente lo llama, pregunta, pide cotización... pero después no lo contrata? ¿Cuál y por qué cree que pasa?',
  subtitle_es = 'Puede ser por precio, por distancia, porque no lo conocen lo suficiente, porque hay otro más barato cerca. Sea honesto. Saber dónde perdemos es más importante que saber dónde ganamos.',
  objective_es = 'Las comunas donde la gente busca pero no cierra son una oportunidad para mejorar. Si el problema es el precio, el mensaje tiene que enfocarse en el valor. Si es la distancia, hay que evaluar si vale la pena llegar.',
  helper_text = 'No se castigue. Todos los negocios tienen zonas donde cuesta más.'
WHERE id = 'srv_05';

-- srv_06: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = 'Si mañana pudiera abrir operación en una comuna nueva y tuviera garantizado el éxito, ¿dónde sería? ¿Por qué justo ahí?',
  subtitle_es = 'Puede ser porque ya tiene algunos clientes ahí, porque le han pedido, porque hay poca competencia, o simplemente porque le gusta la zona. Mencione hasta tres comunas y la razón.',
  objective_es = 'Estas comunas son la dirección natural del crecimiento. Son el "hacia dónde vamos" de GuardMan. Todo lo que se prepara para la empresa apunta en esa dirección.',
  helper_text = 'Piense con ambición. Sin restricciones de presupuesto ni de personal.'
WHERE id = 'srv_06';

-- srv_07: free_text → CAMBIAR PREGUNTA (de "comuna sin competencia" a "equipo")
UPDATE ceo_questionnaire_questions SET
  question_es = 'Hábleme de su gente. ¿Cuánto tiempo lleva trabajando con usted el guardia más antiguo? ¿Y el supervisor?',
  subtitle_es = 'La rotación de personal es uno de los problemas más grandes del rubro. Si usted tiene gente que lleva años, eso dice algo importante sobre GuardMan que ninguna otra empresa puede copiar.',
  objective_es = 'El tiempo que su gente lleva con usted es una de las pruebas de confianza más poderosas. Dice que GuardMan trata bien a los suyos. Y una empresa que trata bien a su gente, trata bien a sus clientes.',
  helper_text = 'Si tiene alguien que lleva más de cinco años, menciónelo. Eso vale oro.'
WHERE id = 'srv_07';

-- srv_08: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuánta gente trabaja hoy con usted? Guardias, supervisores, administrativos. El total de personas que dependen de GuardMan.',
  subtitle_es = 'No necesita el número exacto. Una aproximación honesta. Este número habla del tamaño real de la operación y de la responsabilidad que usted maneja.',
  objective_es = 'El número de personas que trabajan en GuardMan es una medida de experiencia y capacidad operativa. Publicarlo genera confianza porque muestra que no es una empresa improvisada.',
  helper_text = 'Cuente a todos. Cada persona que depende de GuardMan cuenta.'
WHERE id = 'srv_08';

-- srv_09: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántos clientes activos tiene GuardMan hoy? Edificios, condominios, empresas, locales. Todos los que le pagan este mes.',
  subtitle_es = 'Aproximado. El número total de contratos vigentes. Este número es la prueba más concreta de que GuardMan es una empresa sólida.',
  objective_es = 'La cantidad de clientes activos es la prueba social más directa. Publicar este número muestra que mucha gente ya confía en GuardMan.',
  helper_text = 'No se preocupe por la precisión. Una aproximación basta.'
WHERE id = 'srv_09';

-- srv_10: ranking → MEJORAR opciones con contexto operativo
UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene estos tipos de lugares según dónde trabaja GuardMan más seguido. Ponga primero donde tiene más clientes:',
  subtitle_es = 'Piense en su cartera actual. ¿Dónde están sus guardias en este momento? Lo que más tiene define el corazón del negocio.',
  options_json = '[
    "Edificios residenciales (portería, control de acceso, rondas nocturnas)",
    "Condominios y comunidades (portería, vigilancia perimetral, control de visitas)",
    "Oficinas corporativas (control de acceso, recepción, seguridad perimetral)",
    "Locales comerciales y tiendas (prevención de robos, control de ingreso)",
    "Bodegas y centros de distribución (control de entrada y salida, rondas)",
    "Faenas industriales (control de acceso, vigilancia de equipos y materiales)",
    "Casas particulares (guardia residencial, rondas programadas)",
    "Eventos (conciertos, ferias, lanzamientos — control de acceso masivo)",
    "Colegios y universidades (control de ingreso, rondas en campus)",
    "Clínicas y centros de salud (control de acceso, vigilancia 24 horas)"
  ]',
  objective_es = 'Los tipos de lugar donde GuardMan ya tiene clientes son su especialidad real. El orden de esta lista define qué servicios se destacan primero y qué experiencia se comunica.',
  helper_text = 'No piense en lo que le gustaría tener. Piense en lo que YA tiene.'
WHERE id = 'srv_10';

-- srv_11: ranking → MEJORAR opciones con descripción de cada servicio
UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene estos servicios según qué tanto se los piden sus clientes. Ponga primero el que más le solicitan:',
  subtitle_es = 'Lo que la gente más pide es lo que GuardMan mejor sabe hacer. Si hay algún servicio que no está en la lista, agréguelo abajo.',
  options_json = '[
    "Portería en edificios residenciales — guardia fijo en la entrada, conoce a los vecinos, controla el acceso",
    "Portería en oficinas — control de visitantes, registro de ingreso, presencia profesional",
    "Rondas y vigilancia perimetral — recorridos programados, revisión de accesos y perímetros",
    "Control de acceso — registro de entradas y salidas, verificación de identidad",
    "Conserjería — atención al público, paquetería, control de visitas y proveedores",
    "Seguridad para locales comerciales — prevención de robos, presencia disuasiva",
    "Seguridad para eventos — control de acceso masivo, verificación de entradas",
    "Monitoreo de alarmas y cámaras — atención remota, respuesta ante incidentes",
    "Asesoría de seguridad — diagnóstico, recomendaciones, plan de acción",
    "Seguridad industrial — faenas, bodegas, control de materiales y equipos"
  ]',
  objective_es = 'Esta lista es el catálogo real de GuardMan. El orden refleja lo que la gente pide, no lo que la empresa quiere vender. El servicio más pedido es el que va primero en la presentación.',
  helper_text = 'El orden lo define la demanda real, no sus preferencias personales.'
WHERE id = 'srv_11';

-- srv_12: free_text → MEJORAR con ejemplos
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Hay algo que la gente le pida con frecuencia y que GuardMan HOY no ofrece? Un servicio, una cobertura, un tipo de guardia, algo.',
  subtitle_es = 'Puede ser algo que usted ha pensado en ofrecer pero no ha podido, o algo que derechamente no está en sus planes. Saberlo ayuda a entender qué falta en el mercado y qué podría ser una oportunidad.',
  objective_es = 'Cuando la gente pide algo que no existe en el mercado, ahí hay una oportunidad. Puede que GuardMan no quiera tomarla ahora, pero saber que existe ya es valioso.',
  helper_text = 'Si no se le ocurre nada, está bien. Pero si hay algo, por chico que sea, vale la pena anotarlo.'
WHERE id = 'srv_12';

-- srv_13: free_text → MEJORAR más personal
UPDATE ceo_questionnaire_questions SET
  question_es = 'De todo lo que hace GuardMan, ¿cuál es el servicio que más orgullo le da entregar? Ese donde usted dice "esto lo hacemos bien".',
  subtitle_es = 'No el más rentable. No el más fácil. El que más lo enorgullece. Ese donde usted siente que GuardMan marca la diferencia.',
  objective_es = 'El servicio que más orgullo le da es el que mejor representa a la empresa. Es el que se destaca visualmente y se cuenta con más detalle, porque cuando alguien habla de lo que le enorgullece, convence.',
  helper_text = 'Puede ser uno solo. El que le saca una sonrisa cuando piensa en él.'
WHERE id = 'srv_13';

-- srv_14: free_text → MEJORAR como historia
UPDATE ceo_questionnaire_questions SET
  question_es = 'Cuénteme un caso real. Un cliente que llegó con un problema, GuardMan lo resolvió, y el resultado fue mejor de lo que el cliente esperaba.',
  subtitle_es = 'No necesita nombres. Cuente la situación inicial, qué hizo GuardMan y qué pasó después. Si tiene cifras o datos concretos, mejor todavía. Las historias reales son lo que más convence.',
  objective_es = 'Un caso real bien contado convence más que diez páginas de folleto. La gente recuerda historias, no listas de servicios. Este caso se convierte en la historia principal de GuardMan.',
  helper_text = 'Piense en ese cliente que todavía lo saluda con una sonrisa cuando lo ve.'
WHERE id = 'srv_14';

-- srv_15: free_text → OK, mejora menor
UPDATE ceo_questionnaire_questions SET
  question_es = '¿En qué año empezó GuardMan? ¿Cuántos años lleva operando?',
  subtitle_es = 'El año de fundación. Si fue formalizado después, ponga el año en que empezó a operar de verdad, aunque fuera con un solo cliente.',
  objective_es = 'Los años de experiencia son una de las pruebas de confianza más directas. "Operando desde XXXX" comunica trayectoria y seriedad.',
  helper_text = 'El año real. No hay años malos. Todos suman experiencia.'
WHERE id = 'srv_15';

-- srv_16: free_text → OK, mejora menor
UPDATE ceo_questionnaire_questions SET
  question_es = 'Si suma todos los clientes que ha tenido GuardMan en su historia — los actuales y los que ya no están — ¿cuántos han sido?',
  subtitle_es = 'Un número total acumulado. Todos los que alguna vez confiaron en GuardMan. Este número habla de la trayectoria real, no solo del presente.',
  objective_es = 'El total acumulado de clientes muestra la escala real de la experiencia de GuardMan. No es lo mismo haber atendido a veinte clientes que a doscientos.',
  helper_text = 'Aproximado. Lo importante es el orden de magnitud.'
WHERE id = 'srv_16';

-- srv_18: ranking → mejorar opciones con descripción de cada certificación
UPDATE ceo_questionnaire_questions SET
  question_es = 'Ordene estas certificaciones según qué tan importantes son para GuardMan. Ponga primero la que más valor le da a su operación:',
  subtitle_es = 'Marque solo las que tiene. Las que no tenga, déjelas abajo. Lo que aparece primero es lo que más pesa al momento de presentar a GuardMan.',
  options_json = '[
    "Resolución OS-10 vigente — la autorización de Carabineros que permite operar como empresa de seguridad. Sin esto, no hay empresa",
    "Patente municipal al día — requisito básico para operar formalmente en cada comuna",
    "Mutualidad de Seguridad al día — cobertura de accidentes laborales para todos los guardias",
    "Seguro de responsabilidad civil — protege al cliente si algo llegara a pasar",
    "Seguro de robo y daños — cobertura adicional sobre los bienes del cliente",
    "Certificación ISO 9001 — sistema de gestión de calidad certificado internacionalmente",
    "Certificación ISO 45001 — sistema de gestión de seguridad y salud en el trabajo",
    "Membresía en gremiales (ANACSE u otra) — pertenencia al rubro organizado",
    "Premios o reconocimientos sectoriales — validación externa de la calidad del servicio",
    "Capacitación OS-10 para guardias — todos los guardias con su curso al día"
  ]',
  objective_es = 'Las certificaciones son la base de la confianza formal. Las más importantes aparecen destacadas y le dicen al cliente: "esta empresa está en regla y se toma en serio lo que hace".',
  helper_text = 'Las que tiene de verdad. No las que planea tener.'
WHERE id = 'srv_18';

-- srv_19: ranking → mejorar opciones con contexto más rico
UPDATE ceo_questionnaire_questions SET
  question_es = 'Póngase en los zapatos de un cliente que está decidiendo. ¿Qué es lo que más pesa para que lo elija a usted y no al de al lado? Ordene de más a menos importante:',
  subtitle_es = 'No lo que a usted le gustaría que pesara. Lo que REALMENTE pesa en la decisión. Lo que ha visto una y otra vez en todos estos años.',
  options_json = '[
    "La calidad profesional de los guardias — cómo se ven, cómo hablan, cómo trabajan. La primera impresión",
    "Cercanía y atención personalizada — sienten que usted los conoce, los escucha, responde rápido",
    "Precio — al final del día, el presupuesto manda y hay que ser competitivo",
    "Recomendación de alguien de confianza — el boca a boca es el vendedor más efectivo",
    "Experiencia comprobable — años en el rubro, cantidad de clientes, casos de éxito",
    "Rapidez de respuesta — qué tan rápido contesta el teléfono, manda la cotización, resuelve dudas",
    "Certificaciones al día — OS-10, patentes, seguros. Lo básico que demuestra seriedad",
    "Flexibilidad — se adaptan a lo que el cliente necesita, no le venden un paquete cerrado",
    "Disponibilidad inmediata — pueden empezar mañana si el cliente lo necesita urgente",
    "Presencia de un supervisor — saben que hay alguien a cargo revisando que todo funcione"
  ]',
  objective_es = 'El primer factor de esta lista es la razón principal por la que un cliente elige a GuardMan. Eso se convierte en el argumento principal de la presentación. Los siguientes tres son los argumentos de apoyo.',
  helper_text = 'Sea brutalmente honesto. Esto define todo lo demás.'
WHERE id = 'srv_19';

-- srv_20: ranking → mejorar opciones con más realismo operativo
UPDATE ceo_questionnaire_questions SET
  question_es = 'Un cliente ya firmó. Ya está con usted. ¿Qué es lo que hace que se quede mes tras mes? Ordene de más a menos importante:',
  subtitle_es = 'No piense en la venta. Piense en la retención. En ese cliente que lleva años con usted y no se va. ¿Por qué se queda?',
  options_json = '[
    "Calidad consistente — el servicio no baja nunca, siempre igual de bueno, el cliente no tiene de qué quejarse",
    "El guardia asignado ya conoce el lugar y a la gente — se genera una relación de confianza entre las personas",
    "Trato humano — el cliente siente que habla con personas, no con una empresa anónima",
    "Respuesta inmediata a cualquier problema — si algo pasa, GuardMan aparece en minutos, no en días",
    "Comunicación constante — el cliente sabe lo que pasa, recibe reportes, nunca está a oscuras",
    "Cumplimiento de turnos — el guardia siempre llega, nunca hay ausencias sin aviso, nunca hay sorpresas",
    "Supervisor presente — hay alguien de GuardMan que va, revisa, supervisa, se nota que hay control",
    "Capacitación continua — los guardias se ven preparados, actualizados, profesionales",
    "Imagen profesional — uniformes impecables, presentación cuidada, vehículos identificados",
    "Flexibilidad ante cambios — si el cliente necesita ajustar algo, GuardMan se adapta sin dramas"
  ]',
  objective_es = 'Lo que retiene a un cliente es la base de la reputación de GuardMan. Los tres primeros factores de esta lista se convierten en la promesa de servicio que se comunica en todo momento.',
  helper_text = 'Lo que hace que un cliente diga "me quedo con GuardMan" cuando otro le ofrece cambiar.'
WHERE id = 'srv_20';

-- srv_21: ranking → mejorar opciones con causas reales de fuga
UPDATE ceo_questionnaire_questions SET
  question_es = 'En su experiencia, ¿por qué un cliente deja de contratar a una empresa de seguridad? Ordene de la razón más común a la menos común:',
  subtitle_es = 'Piense en los clientes que perdió o casi pierde. Y también en los que usted sabe que otras empresas perdieron. La razón más común es la que más hay que prevenir.',
  options_json = '[
    "El cliente siente que el servicio ya no vale lo que cuesta — el precio sube pero no ve mejoras",
    "Tuvo un problema con un guardia — una falta de respeto, un descuido, un incidente puntual",
    "Encontró a alguien más barato — y la diferencia de precio fue suficiente para cambiar",
    "Fallas repetidas en los turnos — el guardia falta o llega tarde con frecuencia",
    "Falta de comunicación — nunca le avisan nada, no recibe reportes, se siente abandonado",
    "Cambiaron al guardia que conocía — y el nuevo no generó la misma confianza",
    "El supervisor nunca aparece — el cliente siente que nadie está a cargo",
    "Cierre del negocio o cambio de locación — razones externas, no culpa de la empresa",
    "Pidió algo que la empresa no pudo o no quiso hacer — falta de flexibilidad",
    "Reducción de presupuesto — el cliente ya no puede pagar seguridad privada"
  ]',
  objective_es = 'Saber por qué se van los clientes permite prevenir la fuga antes de que ocurra. La razón más común define dónde hay que poner más atención en la operación diaria.',
  helper_text = 'No se autocensure. La honestidad aquí es lo que salva contratos en el futuro.'
WHERE id = 'srv_21';

-- ═══════════════════════════════════════════════════════════════
-- SECCIÓN 3: comercial — CÓMO SE CIERRA Y SE PIERDE
-- (8 preguntas, todas mejoradas)
-- ═══════════════════════════════════════════════════════════════

-- com_01: free_text → SINGLE_CHOICE con perfiles de cliente enriquecidos
UPDATE ceo_questionnaire_questions SET
  type = 'single_choice',
  question_es = 'De todos los clientes que tiene hoy, ¿cómo describiría al cliente más típico de GuardMan? El que más se repite.',
  subtitle_es = 'No necesita nombre ni empresa. Describa el tipo de cliente: qué busca, qué problema tiene, cómo lo contactó, por qué lo eligió. Si cree que hay varios perfiles distintos, elija el que más tiene.',
  options_json = '[
    "El administrador de un edificio residencial — tiene entre 50 y 200 departamentos, ya tuvo mala experiencia con otra empresa, busca confianza y continuidad",
    "El dueño o gerente de un local comercial — tiene uno o dos locales, ya lo robaron al menos una vez, busca presencia disuasiva y un guardia visible",
    "El comité de un condominio — manejan un presupuesto ajustado, necesitan aprobación de varios vecinos, buscan referencias comprobables antes de decidir",
    "El gerente de una oficina corporativa — valora la presentación profesional, quiere un guardia que proyecte buena imagen, la decisión es rápida si cumple con los requisitos",
    "El dueño de una casa grande — busca discreción, quiere un guardia de confianza que ya conozca el barrio, le preocupa más la seguridad de su familia que el precio",
    "El encargado de una faena o bodega — necesita controlar entrada y salida de materiales, el turno nocturno es clave, valora la puntualidad sobre todas las cosas",
    "El organizador de un evento — necesita personal por una noche o un fin de semana, la decisión es urgente, valora la rapidez de respuesta y la disponibilidad inmediata",
    "El dueño de una clínica o centro médico — necesita guardias las 24 horas, valora la capacitación en primeros auxilios, la presentación impecable es innegociable"
  ]',
  objective_es = 'Saber exactamente quién es el cliente principal de GuardMan permite que toda la comunicación hable directamente a esa persona. Cuando el mensaje es preciso, la respuesta es más rápida.',
  helper_text = 'El cliente que más tiene. No el que más le gusta. El que más se repite.'
WHERE id = 'com_01';

-- com_02: ranking → mejorar opciones con descripción de canales
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cómo llega la mayoría de sus clientes a GuardMan? Ordene los canales del que más le trae al que menos:',
  subtitle_es = 'No piense en qué canal le gustaría que funcionara mejor. Piense en por dónde realmente le llegan. Si es por recomendación, es por recomendación. No hay canal mejor ni peor.',
  options_json = '[
    "Recomendación de otro cliente — alguien que ya trabaja con GuardMan lo refirió directamente",
    "Lo buscaron por su cuenta — preguntaron a conocidos, lo encontraron en alguna parte, llamaron",
    "Lo vieron trabajando en otro lado — vieron a sus guardias en un edificio vecino y preguntaron",
    "Contacto directo — alguien que ya lo conocía de antes, un ex cliente, un colega",
    "Visita en terreno — usted o alguien de su equipo fue a ofrecer el servicio directamente",
    "Contacto por teléfono o correo — lo ubicaron en algún listado, guía o base de datos",
    "Ferias, ruedas de negocio, eventos del rubro — contacto profesional en un contexto de industria",
    "Redes sociales — lo encontraron en alguna red y le escribieron por ahí"
  ]',
  objective_es = 'Saber por dónde llegan los clientes permite concentrar el esfuerzo donde ya funciona. Si el 80% llega por recomendación, entonces hay que cuidar a los clientes actuales como el canal más valioso.',
  helper_text = 'El canal que más le trae clientes es su mejor vendedor.'
WHERE id = 'com_02';

-- com_03: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = 'Esa conversación que ya conoce de memoria. Cuando alguien le dice "lo voy a pensar" y usted ya intuye que no lo va a contratar. ¿Cuál cree que es la verdadera razón?',
  subtitle_es = 'No la excusa que le dan. La razón de fondo que usted sospecha. Esa intuición que tiene después de años de escuchar la misma conversación.',
  objective_es = 'La razón por la que la gente no contrata es la objeción que GuardMan tiene que responder antes de que se la pregunten. Si el material de presentación resuelve esa duda, la decisión es más fácil.',
  helper_text = 'Esa corazonada que tiene. Escúchela. Probablemente es cierta.'
WHERE id = 'com_03';

-- com_04: single_choice → MEJORAR opciones
UPDATE ceo_questionnaire_questions SET
  question_es = 'Desde que alguien lo contacta por primera vez hasta que firma el contrato, ¿cuántas conversaciones o reuniones toma normalmente?',
  subtitle_es = 'Cuente todo: la llamada inicial, la visita al lugar, la cotización, la reunión final. Todo el camino hasta la firma.',
  options_json = '[
    "Una sola conversación — con eso basta para cerrar",
    "Dos contactos — una llamada y una visita o cotización",
    "Tres contactos — llamada, visita, reunión final",
    "Cuatro o más — proceso más largo, a veces incluye aprobación de un comité o varios dueños",
    "Depende mucho — hay clientes que cierran en un día y otros que toman semanas"
  ]',
  objective_es = 'La cantidad de contactos que toma cerrar determina cuánto material de presentación necesita GuardMan. Si cierra en una llamada, la primera impresión lo es todo. Si toma semanas, necesita mantener el interés.',
  helper_text = 'El cliente típico. No la excepción.'
WHERE id = 'com_04';

-- com_05: single_choice → MEJORAR opciones
UPDATE ceo_questionnaire_questions SET
  question_es = 'De cada diez personas que lo contactan preguntando por el servicio, ¿cuántas terminan contratando a GuardMan?',
  subtitle_es = 'Una estimación. No necesita datos exactos. Su intuición después de todos estos años ya es un dato.',
  options_json = '[
    "Una o dos de cada diez — cierran pocos",
    "Tres o cuatro de cada diez — cierran algunos",
    "Cinco o seis de cada diez — cierra la mitad",
    "Siete u ocho de cada diez — cierran la mayoría",
    "Nueve o diez de cada diez — casi todos los que preguntan contratan"
  ]',
  objective_es = 'La proporción de personas que contratan después de preguntar revela qué tan efectivo es GuardMan para convertir el interés en un contrato. Si la proporción es baja, hay que revisar qué pasa entre la consulta y la firma.',
  helper_text = 'Su intuición. Sin calculadora.'
WHERE id = 'com_05';

-- com_06: single_choice → MEJORAR opciones con más rango
UPDATE ceo_questionnaire_questions SET
  question_es = 'Desde el primer contacto hasta la firma del contrato, ¿cuánto tiempo pasa normalmente?',
  subtitle_es = 'Piense en el cliente promedio. ¿Días, semanas, meses?',
  options_json = '[
    "Menos de una semana — la decisión es rápida, el cliente necesita el servicio urgente",
    "De una a dos semanas — tiempo razonable para evaluar, visitar y cotizar",
    "De dos semanas a un mes — proceso más pausado, tal vez comparan con otras opciones",
    "De uno a tres meses — proceso lento, a veces hay aprobaciones internas que tomar",
    "Más de tres meses — proceso muy largo, típico de clientes corporativos o grandes contratos"
  ]',
  objective_es = 'El tiempo entre el primer contacto y la firma revela la urgencia del cliente y la complejidad de la decisión. Si toma semanas, GuardMan necesita mantener el contacto durante todo ese período.',
  helper_text = 'El tiempo del cliente promedio.'
WHERE id = 'com_06';

-- com_07: single_choice → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = 'En un mes normal, ¿cuántas personas o empresas contactan a GuardMan preguntando por el servicio?',
  subtitle_es = 'Consultas, llamadas, correos, cotizaciones. Todo contacto de alguien que quiere saber del servicio. Aproximado.',
  options_json = '[
    "Menos de cinco al mes — goteo constante pero bajo",
    "Entre cinco y quince — flujo estable y manejable",
    "Entre quince y treinta — buen volumen de consultas",
    "Más de treinta al mes — alto volumen de interés",
    "No sabría decir con precisión — nunca lo he medido"
  ]',
  objective_es = 'El volumen de consultas mensuales es el pulso del negocio. Si es bajo, hay que trabajar en que más gente conozca a GuardMan. Si es alto pero cierran pocos, hay que mejorar la conversión.',
  helper_text = 'Un número aproximado. No necesita abrir la planilla.'
WHERE id = 'com_07';

-- com_08: single_choice → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cuántos clientes nuevos firma GuardMan en un mes típico?',
  subtitle_es = 'Su promedio real. Sin inflar. Este número es el resultado final de todo el proceso comercial.',
  options_json = '[
    "Menos de uno al mes — crecimiento lento pero sostenido",
    "Uno o dos al mes — crecimiento orgánico y saludable",
    "Tres a cinco al mes — buen ritmo de crecimiento",
    "Más de cinco al mes — crecimiento acelerado",
    "Varía mucho, no tengo un promedio claro"
  ]',
  objective_es = 'La cantidad de clientes nuevos por mes es el resultado final del trabajo de GuardMan. La distancia entre las consultas que recibe y los clientes que firma muestra dónde está la oportunidad de mejora.',
  helper_text = 'El número real. El que importa al final del mes.'
WHERE id = 'com_08';

-- ═══════════════════════════════════════════════════════════════
-- SECCIÓN 4: diferenciacion — POR QUÉ TÚ Y NO OTRO
-- (8 preguntas, todas mejoradas)
-- ═══════════════════════════════════════════════════════════════

-- dif_01: free_text → MEJORAR pregunta más desafiante
UPDATE ceo_questionnaire_questions SET
  question_es = 'Usted está en un ascensor con el gerente de un edificio grande. Tiene treinta segundos. El gerente le dice: "¿por qué contrataría a GuardMan y no a otra empresa?". ¿Qué le dice?',
  subtitle_es = 'Treinta segundos. No alcanza para un discurso. Solo para una frase. La que cierra. La que convence. Esa frase es la más importante de todo el cuestionario.',
  objective_es = 'La respuesta a esta pregunta es el corazón de GuardMan. Define por qué existe la empresa y por qué alguien debería elegirla. Es la primera frase que se lee, la primera que se escucha y la última que se olvida.',
  helper_text = 'Tómese su tiempo. Esta respuesta vale todo el cuestionario.'
WHERE id = 'dif_01';

-- dif_02: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Hay algo que GuardMan tenga o pueda hacer que la mayoría de las otras empresas de seguridad simplemente no tienen ni pueden?',
  subtitle_es = 'Un permiso especial, una certificación única, una capacidad operativa que otros no han desarrollado, una relación con algún organismo, un proceso interno que es superior. Lo que sea que lo hace distinto.',
  objective_es = 'Si GuardMan tiene algo que nadie más tiene, eso se convierte en el diferenciador principal. Es la razón por la que un cliente elige a GuardMan y no puede obtener lo mismo en otra parte.',
  helper_text = 'No se limite. Si cree que es único, dígalo.'
WHERE id = 'dif_02';

-- dif_03: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = 'Cuénteme de esa vez que GuardMan resolvió algo que parecía imposible. Ese caso donde usted sintió que realmente hicieron la diferencia.',
  subtitle_es = 'Todos los que trabajan en seguridad tienen al menos una historia así. Esa vez que llegaron antes que Carabineros. Esa vez que detectaron algo que nadie más había visto. Esa vez que la capacitación marcó la diferencia.',
  objective_es = 'Los casos donde GuardMan superó lo esperado son la mejor carta de presentación. Una historia real de un problema resuelto convence más que cualquier lista de cualidades.',
  helper_text = 'Esa historia que ya ha contado diez veces y cada vez la cuenta con el mismo orgullo.'
WHERE id = 'dif_03';

-- dif_04: comparison → MEJORAR opciones con más contexto operativo
UPDATE ceo_questionnaire_questions SET
  question_es = 'Si tuviera que elegir entre estas dos formas de ser, ¿cuál describe mejor a GuardMan?',
  subtitle_es = 'No hay respuesta correcta. Las dos son válidas. Pero una es más GuardMan que la otra.',
  options_json = '[
    "La empresa más profesional y rigurosa: certificaciones al día, procesos estrictos, cada guardia capacitado, cada turno supervisado, cero improvisación",
    "La empresa más cercana y humana: conocemos a cada cliente por su nombre, sabemos cómo se llama el guardia de cada edificio, cuando alguien llama habla con una persona, no con un menú telefónico"
  ]',
  objective_es = 'La elección define cómo se presenta GuardMan. Si elige profesional, la comunicación habla de certificaciones, procesos y rigor. Si elige cercano, habla de confianza, relaciones y servicio personalizado.',
  helper_text = 'No piense en lo que queda bien. Piense en lo que GuardMan realmente es.'
WHERE id = 'dif_04';

-- dif_05: free_text → RANKING con competidores
UPDATE ceo_questionnaire_questions SET
  type = 'ranking',
  question_es = 'En su experiencia, ¿quiénes son los competidores a los que más se enfrenta GuardMan? Ordene del más común al menos común:',
  subtitle_es = 'Piense en las propuestas que ha perdido. Cuando un cliente le dice "gracias pero me voy con otra empresa", ¿con quién se va? Si no aparece en la lista, agréguelo abajo.',
  options_json = '[
    "Securitas — el grande, el que todos conocen, presencia nacional",
    "Prosegur — el otro grande, mucha presencia en retail y oficinas",
    "Empresas locales chicas — el competidor de la esquina, más barato pero menos formal",
    "Independientes o guardias particulares — alguien que trabaja por su cuenta sin empresa",
    "Otra empresa mediana conocida en el rubro — similar a GuardMan pero con más años o más marketing",
    "El conserje del edificio que hace de guardia — no es competencia formal pero le quita clientes",
    "Empresas nuevas que recién están entrando al mercado — precios agresivos para ganar clientes"
  ]',
  objective_es = 'Saber contra quién compite GuardMan permite entender el mercado real. El competidor más común define contra quién hay que diferenciarse con más fuerza.',
  helper_text = 'Sea honesto. Incluso si el competidor es más grande o más conocido.'
WHERE id = 'dif_05';

-- dif_06: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Hay algún lugar donde sus propios clientes le han dicho "por favor, ábranse acá también"? Una comuna, un barrio, una zona donde ya lo conocen y quieren que llegue.',
  subtitle_es = 'Cuando un cliente pide que usted se expanda, es la señal más clara de que el servicio funciona. Si hay varios clientes pidiendo lo mismo, hay una oportunidad real de crecer.',
  objective_es = 'Donde los clientes piden que GuardMan llegue es el próximo paso natural de expansión. No es una apuesta: es una demanda comprobada.',
  helper_text = 'Si nadie se lo ha pedido, no importa. Pero si sí, vale la pena anotarlo.'
WHERE id = 'dif_06';

-- dif_07: free_text → MEJORAR
UPDATE ceo_questionnaire_questions SET
  question_es = 'Si un competidor quisiera copiar lo que hace GuardMan, ¿qué es lo que jamás podría copiar? ¿Qué es lo que solo GuardMan tiene?',
  subtitle_es = 'No hable de precios ni de certificaciones. Eso se copia. Hable de algo más profundo: la forma de trabajar, la relación con los clientes, el conocimiento del territorio, la cultura interna. Lo que hace que GuardMan sea irrepetible.',
  objective_es = 'Lo que no se puede copiar es la ventaja real de GuardMan. Es el argumento definitivo. No se puede competir contra algo que no se puede replicar.',
  helper_text = 'Si no se le ocurre nada, piénselo más. Todo negocio que sobrevive tiene algo que es solo suyo.'
WHERE id = 'dif_07';

-- dif_08: free_text → MEJORAR como pregunta fundacional
UPDATE ceo_questionnaire_questions SET
  question_es = '¿Cómo nació GuardMan? Cuénteme la historia real. La que le contaría a un amigo, no la del brochure.',
  subtitle_es = '¿Dónde estaba usted cuando decidió empezar? ¿Qué lo empujó? ¿Había algo que vio en el mercado y dijo "esto se puede hacer mejor"? ¿O fue más personal? Cuente lo que pasó de verdad.',
  objective_es = 'La historia fundacional es la pieza más humana de GuardMan. Detrás de cada empresa hay una persona que un día decidió empezar. Contar esa historia crea una conexión que ninguna publicidad puede igualar.',
  helper_text = 'La versión real. Con sus palabras. Como si estuviéramos tomando un café.'
WHERE id = 'dif_08';

-- ═══════════════════════════════════════════════════════════════
-- VERIFICACIÓN FINAL: ningún término prohibido
-- ═══════════════════════════════════════════════════════════════
-- Ejecutar después para verificar
-- SELECT id, question_es FROM ceo_questionnaire_questions
-- WHERE LOWER(question_es) GLOB '*seo*' OR LOWER(question_es) GLOB '*google*'
--    OR LOWER(question_es) GLOB '*buscador*' OR LOWER(question_es) GLOB '*marketing*'
--    OR LOWER(question_es) GLOB '*internet*' OR LOWER(question_es) GLOB '*sitio web*'
--    OR LOWER(question_es) GLOB '*anuncio*' OR LOWER(question_es) GLOB '*digital*'
--    OR LOWER(question_es) GLOB '*publicado*' OR LOWER(question_es) GLOB '*publicar*';
