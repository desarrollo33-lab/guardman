-- ============================================================
-- GuardMan v5.2 — Intel Snapshots + Content Lessons
-- Part of Workflows v2.0 implementation plan
-- ============================================================

-- Snapshots de inteligencia (output de SEOIntelWorkflow)
CREATE TABLE IF NOT EXISTS intel_snapshots (
  id TEXT PRIMARY KEY,
  trigger_type TEXT NOT NULL DEFAULT 'manual',    -- 'manual' | 'post-scan'
  created_at TEXT DEFAULT (datetime('now')),
  position_map TEXT NOT NULL,                       -- JSON: PositionSummary[]
  competitor_profiles TEXT NOT NULL,                -- JSON: CompetitorProfile[]
  content_gaps TEXT NOT NULL,                       -- JSON: ContentGap[]
  keyword_intelligence TEXT NOT NULL,               -- JSON: KeywordIntelligence
  content_proposals TEXT NOT NULL,                  -- JSON: ContentProposal[]
  summary TEXT NOT NULL                             -- JSON: IntelSnapshotSummary
);

CREATE INDEX IF NOT EXISTS idx_intel_snapshots_created ON intel_snapshots(created_at);

-- Lecciones de generaciones anteriores (para mejorar futuras generaciones)
CREATE TABLE IF NOT EXISTS content_lessons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_slug TEXT NOT NULL,
  score INTEGER,
  feedback TEXT,                                    -- JSON del review
  improvements TEXT,                                -- Sugerencias para próxima generación
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_content_lessons_slug ON content_lessons(entity_type, entity_slug);
