-- entity_images table for associating images with entities
-- Part of preview-imagenes feature (Fase 2)

CREATE TABLE IF NOT EXISTS entity_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_slug TEXT NOT NULL,
  image_key TEXT NOT NULL,
  image_url TEXT NOT NULL,
  image_type TEXT NOT NULL DEFAULT 'gallery',
  section_name TEXT,
  alt_text TEXT,
  width INTEGER,
  height INTEGER,
  file_size INTEGER,
  mime_type TEXT,
  is_primary INTEGER DEFAULT 0,
  sort_order INTEGER DEFAULT 0,
  uploaded_at TEXT DEFAULT (datetime('now')),
  UNIQUE(entity_type, entity_slug, image_key)
);

CREATE INDEX IF NOT EXISTS idx_ei_entity ON entity_images(entity_type, entity_slug);
CREATE INDEX IF NOT EXISTS idx_ei_type ON entity_images(entity_type, entity_slug, image_type);