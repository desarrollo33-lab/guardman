-- ============================================================
-- GuardMan CRM — Mock Data Seed
-- 12 Leads + 5 Clientes + 8 Interacciones + 4 Propuestas + 3 Visitas + 5 Servicios
-- Ejecutar después de aplicar intel-tables.sql y crm-commercial.sql
-- ============================================================

-- Clear existing test data (optional — uncomment if needed)
-- DELETE FROM intel_client_services;
-- DELETE FROM intel_proposal_items;
-- DELETE FROM intel_visit_photos;
-- DELETE FROM intel_visits;
-- DELETE FROM intel_proposals;
-- DELETE FROM intel_interactions;
-- DELETE FROM intel_clients;
-- DELETE FROM intel_leads;

-- ===== LEADS =====
INSERT INTO intel_leads (id, slug, status, source, contact_name, contact_email, contact_phone, company_name, company_rut, company_industry, service_slug, location_slug, location_address, message, estimated_value, probability, serper_opportunity_score, competitor_density, market_difficulty, facility_type, facility_sqm, has_current_security, current_competitor, shifts_needed, armed_service, no_contact_attempts, loss_reason, loss_competitor, loss_price_ref, next_follow_up, last_activity_at, created_at, updated_at) VALUES
(1, 'ld-1a2b3c', 'new', 'web', 'Juan Pérez', 'juan@empresa1.cl', '+56912345678', 'Empresa Uno SpA', '77.123.456-7', 'Retail', 'guardias-de-seguridad', 'las-condes', 'Av. Apoquindo 4500', 'Necesitamos 2 guardias para turno noche', 1800000, 0.3, 72, 4, 'medium', 'Oficina', 800, 1, 'Seguritas', 2, 0, 0, null, null, null, '2026-05-11T09:00:00Z', '2026-05-01T10:00:00Z', '2026-05-01T10:00:00Z', '2026-05-01T10:00:00Z'),
(2, 'ld-2b3c4d', 'contacted', 'manual', 'María González', 'maria@condo2.cl', '+56923456789', 'Condominio Los Pinos', null, 'Residencial', 'control-de-accesos', 'vitacura', 'Los Pinos 123', 'Control de acceso para 120 unidades', 950000, 0.4, 65, 3, 'easy', 'Condominio', 5000, 0, null, 1, 0, 1, null, null, null, '2026-05-08T10:00:00Z', '2026-05-05T11:00:00Z', '2026-05-02T14:30:00Z', '2026-05-05T11:00:00Z'),
(3, 'ld-3c4d5e', 'visit_scheduled', 'web', 'Carlos Ruiz', 'carlos@industria3.cl', '+56934567890', 'Industria Tres Ltda', '76.987.654-3', 'Industrial', 'cctv-videovigilancia', 'quilicura', 'Av. La Montana 8900', 'CCTV para planta de 2000m2', 3200000, 0.5, 58, 5, 'hard', 'Planta industrial', 2000, 1, 'Prosegur', 0, 0, 0, null, null, null, '2026-05-12T14:00:00Z', '2026-05-06T16:00:00Z', '2026-04-28T09:00:00Z', '2026-05-06T16:00:00Z'),
(4, 'ld-4d5e6f', 'proposal_sent', 'referral', 'Ana Martínez', 'ana@clinica4.cl', '+56945678901', 'Clínica Cuatro', '78.456.123-9', 'Salud', 'monitoreo-24-7', 'lo-barnechea', 'Camino El Alba 1234', 'Monitoreo 24/7 para clínica', 4500000, 0.6, 81, 2, 'easy', 'Clínica', 3000, 1, 'Grupo Security', 3, 1, 0, null, null, null, '2026-05-09T09:00:00Z', '2026-05-04T10:30:00Z', '2026-04-20T11:00:00Z', '2026-05-04T10:30:00Z'),
(5, 'ld-5e6f7g', 'negotiation', 'web', 'Pedro Soto', 'pedro@eventos5.cl', '+56956789012', 'Eventos Cinco', null, 'Eventos', 'seguridad-eventos', 'santiago-centro', 'Alameda 800', 'Seguridad para eventos corporativos mensuales', 2800000, 0.75, 70, 4, 'medium', 'Centro de eventos', 1500, 0, null, 4, 0, 0, null, null, null, '2026-05-10T11:00:00Z', '2026-05-07T15:00:00Z', '2026-04-15T08:00:00Z', '2026-05-07T15:00:00Z'),
(6, 'ld-6f7g8h', 'won', 'manual', 'Laura Díaz', 'laura@bodega6.cl', '+56967890123', 'Bodega Central Seis', '79.123.789-0', 'Logística', 'guard-pod', 'huechuraba', 'Av. Santa Clara 567', 'Guard Pod para bodega sin energía', 1500000, 1.0, 45, 1, 'easy', 'Bodega', 5000, 0, null, 0, 0, 0, null, null, null, null, '2026-04-01T12:00:00Z', '2026-03-10T10:00:00Z', '2026-04-01T12:00:00Z'),
(7, 'ld-7g8h9i', 'lost', 'web', 'Roberto Vega', 'roberto@edificio7.cl', '+56978901234', 'Edificio Siete', null, 'Residencial', 'guardias-de-seguridad', 'la-reina', 'Príncipe de Gales 890', 'Guardias para edificio 40 deptos', 2200000, 0, 55, 6, 'hard', 'Edificio', 3500, 1, 'Securitas', 3, 0, 2, 'Precio', 'Securitas', 1800000, null, '2026-04-20T10:00:00Z', '2026-04-05T09:00:00Z', '2026-04-20T10:00:00Z'),
(8, 'ld-8h9i0j', 'new', 'web', 'Carmen Silva', 'carmen@mall8.cl', '+56989012345', 'Mall Ocho', '80.456.789-1', 'Comercial', 'cctv-videovigilancia', 'pudahuel', 'Av. San Pablo 12000', 'CCTV para estacionamiento 500 autos', 5500000, 0.25, 60, 5, 'hard', 'Mall', 12000, 1, 'Prosegur', 0, 0, 0, null, null, null, '2026-05-12T10:00:00Z', '2026-05-08T16:00:00Z', '2026-05-08T16:00:00Z', '2026-05-08T16:00:00Z'),
(9, 'ld-9i0j1k', 'contacted', 'whatsapp', 'Diego Morales', null, '+56990123456', 'Constructora Nueve', '81.789.123-4', 'Construcción', 'seguridad-industrial', 'lampa', 'Ruta 5 Norte km 20', 'Seguridad obra en construcción 6 meses', 3800000, 0.35, 48, 3, 'medium', 'Obra', 8000, 0, null, 2, 0, 1, null, null, null, '2026-05-09T10:00:00Z', '2026-05-06T14:00:00Z', '2026-05-03T11:00:00Z', '2026-05-06T14:00:00Z'),
(10, 'ld-0j1k2l', 'proposal_sent', 'manual', 'Isabel Reyes', 'isabel@hotel10.cl', '+56901234567', 'Hotel Diez', '82.012.456-5', 'Turismo', 'escoltas-privados', 'las-condes', 'Alonso de Córdova 5678', 'Escoltas para VIP hotel', 4200000, 0.55, 75, 2, 'easy', 'Hotel', 6000, 1, 'Grupo Security', 2, 1, 0, null, null, null, '2026-05-11T11:00:00Z', '2026-05-03T09:00:00Z', '2026-04-25T10:00:00Z', '2026-05-03T09:00:00Z'),
(11, 'ld-1k2l3m', 'new', 'web', 'Francisco López', 'francisco@colegio11.cl', '+56912345098', 'Colegio Once', '83.345.678-6', 'Educación', 'guardias-de-seguridad', 'la-pintana', 'Av. La Florida 8900', 'Guardias para colegio 800 alumnos', 2600000, 0.2, 40, 4, 'medium', 'Colegio', 10000, 1, 'Seguritas', 3, 0, 3, null, null, null, '2026-04-01T09:00:00Z', '2026-03-25T10:00:00Z', '2026-03-20T09:00:00Z', '2026-03-25T10:00:00Z'),
(12, 'ld-2l3m4n', 'new', 'web', 'Patricia Torres', 'patricia@oficina12.cl', '+56923456109', 'Oficina Doce', null, 'Corporativo', 'auditoria-seguridad', 'santiago-centro', 'Moneda 800', 'Auditoría de seguridad anual', 800000, 0.3, 68, 3, 'easy', 'Oficina', 1200, 0, null, 0, 0, 0, null, null, null, '2026-05-13T09:00:00Z', '2026-05-09T10:00:00Z', '2026-05-09T10:00:00Z', '2026-05-09T10:00:00Z');

-- Reset SQLite sequence so AUTOINCREMENT continues after 12
DELETE FROM sqlite_sequence WHERE name='intel_leads';
INSERT INTO sqlite_sequence (name, seq) VALUES ('intel_leads', 12);

-- ===== CLIENTS =====
INSERT INTO intel_clients (id, lead_id, slug, status, company_name, company_rut, industry, size, employee_count, primary_contact_name, primary_contact_email, primary_contact_phone, contract_start, contract_end, contract_type, monthly_value, location_slug, address, notes, tags, created_at, updated_at) VALUES
(101, 6, 'cl-abc123', 'active', 'Bodega Central Seis', '79.123.789-0', 'Logística', 'Mediana', 45, 'Laura Díaz', 'laura@bodega6.cl', '+56967890123', '2026-04-01', '2027-04-01', 'Anual', 1500000, 'huechuraba', 'Av. Santa Clara 567', 'Cliente Guard Pod. Sin problemas reportados.', '["guard-pod","bodega"]', '2026-04-01T12:00:00Z', '2026-05-01T10:00:00Z'),
(102, null, 'cl-def456', 'active', 'Minera del Norte', '84.567.123-8', 'Minería', 'Grande', 320, 'Hugo Rojas', 'hugo@minera.cl', '+56934567123', '2025-01-15', '2026-07-15', '18 meses', 8500000, 'los-andes', 'Ruta 60 km 45', 'Renovación próxima. Negociar aumento 8%.', '["industrial","armado"]', '2025-01-15T09:00:00Z', '2026-05-05T11:00:00Z'),
(103, null, 'cl-ghi789', 'active', 'Supermercados Sur', '85.123.789-2', 'Retail', 'Mediana', 120, 'Diana Castillo', 'diana@super Sur.cl', '+56945678123', '2025-06-01', '2026-06-01', 'Anual', 3200000, 'san-felipe', 'Av. Argentina 1200', '5 sucursales. CCTV + guardias.', '["retail","multi-sucursal"]', '2025-06-01T10:00:00Z', '2026-04-20T14:00:00Z'),
(104, null, 'cl-jkl012', 'paused', 'Eventos Elegance', null, 'Eventos', 'Pequeña', 12, 'Sofía Herrera', 'sofia@elegance.cl', '+56956789123', '2025-03-01', '2026-03-01', 'Anual', 900000, 'vitacura', 'Alonso de Córdova 3400', 'Pausado por baja temporada. Reactivar septiembre.', '["eventos","pausado"]', '2025-03-01T11:00:00Z', '2026-03-15T10:00:00Z'),
(105, null, 'cl-mno345', 'churned', 'Textiles del Pacífico', '86.789.012-3', 'Textil', 'Mediana', 80, 'Andrés Navarro', null, '+56967890124', '2024-01-10', '2025-01-10', 'Anual', 2100000, 'quilicura', 'Av. Lo Marcoleta 450', 'Churned. Fue por precio con competencia.', '["churned","precio"]', '2024-01-10T09:00:00Z', '2025-01-15T10:00:00Z');

DELETE FROM sqlite_sequence WHERE name='intel_clients';
INSERT INTO sqlite_sequence (name, seq) VALUES ('intel_clients', 105);

-- ===== INTERACTIONS =====
INSERT INTO intel_interactions (id, lead_id, client_id, type, direction, summary, outcome, next_action, next_action_date, created_at) VALUES
(1, 1, null, 'call', 'outbound', 'Llamada inicial. Interesado en guardias nocturnos.', 'interested', 'Enviar cotización preliminar', '2026-05-03', '2026-05-01T11:00:00Z'),
(2, 2, null, 'email', 'outbound', 'Propuesta enviada por email con brochure.', 'proposal_requested', 'Esperar respuesta', '2026-05-10', '2026-05-02T15:00:00Z'),
(3, 2, null, 'call', 'inbound', 'Cliente consulta por descuento por volumen.', 'callback', 'Preparar descuento 5%', '2026-05-09', '2026-05-05T11:00:00Z'),
(4, 3, null, 'visit', 'outbound', 'Visita técnica realizada. Medidas tomadas.', 'proposal_requested', 'Enviar cotización CCTV', '2026-05-10', '2026-05-06T16:00:00Z'),
(5, 4, null, 'email', 'outbound', 'Cotización monitoreo enviada. Válida 30 días.', 'proposal_requested', 'Seguimiento telefónico', '2026-05-09', '2026-05-04T10:30:00Z'),
(6, 5, null, 'whatsapp', 'outbound', 'Negociación por WhatsApp. Pide 10% descuento.', 'interested', 'Aprobar descuento con gerencia', '2026-05-10', '2026-05-07T15:00:00Z'),
(7, 7, null, 'call', 'outbound', 'Última llamada. Cliente ya firmó con Securitas.', 'not_interested', null, null, '2026-04-20T10:00:00Z'),
(8, null, 101, 'note', 'outbound', 'Revisión mensual. Todo operativo.', null, 'Próxima revisión junio', '2026-06-01', '2026-05-01T10:00:00Z');

DELETE FROM sqlite_sequence WHERE name='intel_interactions';
INSERT INTO sqlite_sequence (name, seq) VALUES ('intel_interactions', 8);

-- ===== PROPOSALS =====
INSERT INTO intel_proposals (id, lead_id, slug, status, total_monthly, total_setup, discount_pct, valid_until, version, parent_proposal_id, executive_notes, contract_period_months, payment_terms, annual_adjustment, sla_response_minutes, sent_at, created_at) VALUES
(1, 4, 'cot-2026-001', 'sent', 4200000, 350000, 5, '2026-06-04', 1, null, 'Monitoreo 24/7 clínica', 12, '30 días', 'IPC + 3%', 15, '2026-05-04T10:30:00Z', '2026-05-04T10:30:00Z'),
(2, 5, 'cot-2026-002', 'draft', 2800000, 0, 0, '2026-05-20', 1, null, 'Eventos corporativos mensuales', 12, '30 días', 'IPC + 3%', 15, null, '2026-05-07T15:00:00Z'),
(3, 10, 'cot-2026-003', 'sent', 4500000, 200000, 10, '2026-06-03', 2, null, 'Escoltas VIP hotel', 12, '30 días', 'IPC + 3%', 10, '2026-05-03T09:00:00Z', '2026-05-03T09:00:00Z'),
(4, 3, 'cot-2026-004', 'draft', 3200000, 500000, 0, '2026-05-25', 1, null, 'CCTV planta industrial', 18, '30 días', 'IPC + 3%', 15, null, '2026-05-06T16:00:00Z');

DELETE FROM sqlite_sequence WHERE name='intel_proposals';
INSERT INTO sqlite_sequence (name, seq) VALUES ('intel_proposals', 4);

-- ===== VISITS =====
INSERT INTO intel_visits (id, lead_id, visit_date, facility_type, facility_sqm, num_access_points, has_current_security, current_competitor, risks_noted, notes, photos_count, completed_at, created_at) VALUES
(1, 3, '2026-05-06', 'Planta industrial', 2000, 4, 1, 'Prosegur', 'Zona perimetral sin iluminación', 'Visita completa. Cotización en preparación.', 5, '2026-05-06T16:00:00Z', '2026-05-06T16:00:00Z'),
(2, 1, '2026-05-12', 'Oficina', 800, 2, 1, 'Seguritas', null, 'Pendiente visita técnica.', 0, null, '2026-05-02T10:00:00Z'),
(3, 4, '2026-04-28', 'Clínica', 3000, 6, 1, 'Grupo Security', 'Acceso de emergencia necesita reforzarse', 'Visita completa. Cliente requiere cotización urgente.', 8, '2026-04-28T14:00:00Z', '2026-04-28T14:00:00Z');

DELETE FROM sqlite_sequence WHERE name='intel_visits';
INSERT INTO sqlite_sequence (name, seq) VALUES ('intel_visits', 3);

-- ===== CLIENT SERVICES =====
INSERT INTO intel_client_services (id, client_id, service_slug, status, quantity, unit, monthly_price, start_date, end_date, notes) VALUES
(1, 101, 'guard-pod', 'active', 2, 'torre', 750000, '2026-04-01', null, 'Torres solares sector norte y sur'),
(2, 102, 'guardias-de-seguridad', 'active', 8, 'guardia', 6500000, '2025-01-15', null, 'Turnos rotativos 24/7'),
(3, 102, 'cctv-videovigilancia', 'active', 1, 'sistema', 2000000, '2025-01-15', null, '32 cámaras PTZ'),
(4, 103, 'guardias-de-seguridad', 'active', 4, 'guardia', 2200000, '2025-06-01', null, '4 sucursales, 1 guardia c/u'),
(5, 103, 'cctv-videovigilancia', 'active', 5, 'sucursal', 1000000, '2025-06-01', null, 'Sistema estándar por sucursal');

DELETE FROM sqlite_sequence WHERE name='intel_client_services';
INSERT INTO sqlite_sequence (name, seq) VALUES ('intel_client_services', 5);
