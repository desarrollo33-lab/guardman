-- GuardMan Admin — Fase 3: Variantes WebP optimizadas
-- Migración D1

CREATE TABLE IF NOT EXISTS media_library_variants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  media_id INTEGER NOT NULL,
  variant_type TEXT NOT NULL,
  key TEXT NOT NULL,
  file_size INTEGER DEFAULT 0,
  width INTEGER DEFAULT 0,
  height INTEGER DEFAULT 0,
  quality INTEGER DEFAULT 85,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (media_id) REFERENCES media_library(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_variants_media ON media_library_variants(media_id);
