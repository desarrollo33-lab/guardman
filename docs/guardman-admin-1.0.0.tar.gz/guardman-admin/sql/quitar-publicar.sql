UPDATE ceo_questionnaire_questions
SET objective_es = 'Estas tres preguntas se incluyen en la sección de Preguntas Frecuentes, con sus respuestas. Aparecen destacadas cuando alguien busca y se usan también en los avisos para responder antes de que la persona pregunte.'
WHERE id = 'id_03';

UPDATE ceo_questionnaire_questions
SET objective_es = 'Esta respuesta se usa como texto principal de la presentación, en los avisos y en los videos de presentación. Es la objeción universal que la gente tiene antes de contratar.'
WHERE id = 'id_04';

UPDATE ceo_questionnaire_questions
SET objective_es = 'Esta frase se convierte en el texto principal de la presentación, en los avisos y en la primera respuesta que da cualquier ejecutivo de ventas. Es la propuesta de valor pura.'
WHERE id = 'dif_01';

UPDATE ceo_questionnaire_questions
SET objective_es = 'Detectar servicios que la gente busca pero GuardMan no entrega. Si la demanda es alta, vale la pena desarrollarlos y darlos a conocer.'
WHERE id = 'srv_12';

UPDATE ceo_questionnaire_questions
SET objective_es = 'El primer factor de la lista se convierte en el mensaje principal de la presentación, de los avisos y de las propuestas a clientes. Los siguientes tres son los argumentos de apoyo.'
WHERE id = 'srv_19';
