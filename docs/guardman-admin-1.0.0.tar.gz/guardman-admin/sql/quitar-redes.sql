UPDATE ceo_questionnaire_questions
SET subtitle_es = 'Recomendación de otro cliente, búsqueda directa, presentaciones, correo, ferias. Ordene los canales del que más trae al que menos trae.'
WHERE id = 'com_02';
