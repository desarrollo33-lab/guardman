-- ═══════════════════════════════════════════════════════════════
-- GuardMan · CRM Alignment Questionnaire
-- 8 preguntas para entender cómo GuardMan se relaciona con sus clientes
-- Se ejecuta en el admin UI, secciones fijas, sin Rodrigo
-- ═══════════════════════════════════════════════════════════════

-- Insertar sección CRM (si no existe)
INSERT OR IGNORE INTO ceo_questionnaire_sections (id, title_es, description, sort_order, icon, status) VALUES
  ('crm', 'Relación con clientes', 'Ocho preguntas para entender cómo GuardMan gestiona su relación con los clientes, desde el primer contacto hasta la operación diaria.', 5, '🤝', 'pending');

-- Insertar 8 preguntas CRM
INSERT OR IGNORE INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, objective_es, required) VALUES

  ('crm_01', 'crm', 1, 'single_choice',
    'Cuando alguien contacta a GuardMan por primera vez, ¿quién atiende esa llamada o mensaje?',
    'La persona que tiene el primer contacto define la primera impresión. ¿Es usted mismo? ¿Una secretaria? ¿Un comercial?',
    '[
      "Rodrigo personalmente — yo atiendo todas las consultas nuevas",
      "Un ejecutivo comercial dedicado — yo solo entro en la etapa final",
      "Una secretaria o asistente — filtra y agenda",
      "Varios pueden atender — no hay una persona fija",
      "Depende del canal — teléfono uno, WhatsApp otro"
    ]',
    'El primer contacto define la experiencia completa del cliente.',
    'Saber quién atiende el primer contacto permite diseñar el flujo de leads en el CRM. Si es Rodrigo, el CRM debe ser simple y directo. Si hay un equipo, necesita asignación automática.',
    1),

  ('crm_02', 'crm', 2, 'single_choice',
    'Después de que alguien pide una cotización, ¿cómo hace el seguimiento?',
    'El seguimiento es donde se gana o se pierde un cliente. ¿Tiene un sistema o es de memoria?',
    '[
      "Tengo una planilla o cuaderno donde anoto y voy llamando",
      "Uso WhatsApp y voy revisando los chats pendientes",
      "Me acuerdo de memoria — los clientes importantes no se me olvidan",
      "Tengo un sistema o software donde registro todo",
      "No hago seguimiento formal — si el cliente quiere, me vuelve a llamar"
    ]',
    'Sin seguimiento sistemático, se pierden clientes todos los meses.',
    'Entender cómo hace el seguimiento hoy permite decidir si el CRM debe reemplazar una planilla, un cuaderno, o la memoria. Define la complejidad necesaria del sistema.',
    1),

  ('crm_03', 'crm', 3, 'single_choice',
    'Cuando va a visitar a un cliente potencial por primera vez, ¿qué información le gustaría tener a mano antes de llegar?',
    'Piense en esa visita donde llegó sin saber algo clave y tuvo que improvisar. ¿Qué le habría gustado saber?',
    '[
      "Qué tipo de lugar es (edificio, condominio, oficina, bodega) y los metros cuadrados",
      "Si ya tiene seguridad y con qué empresa — para saber contra quién compito",
      "Cuántos guardias necesita y en qué turnos — para llevar una propuesta lista",
      "Quién es la persona que decide — a veces el que atiende no es el que firma",
      "Qué presupuesto aproximado manejan — para no perder el tiempo si no hay match",
      "Si ya pidió cotización a otras empresas — para saber si hay urgencia",
      "Todo lo anterior junto, en una sola pantalla"
    ]',
    'La información correcta antes de la visita puede ser la diferencia entre cerrar y perder.',
    'Esta respuesta define qué datos debe mostrar el CRM en la ficha del lead antes de una visita técnica. Si necesita todo junto, el CRM debe consolidar datos de múltiples fuentes.',
    1),

  ('crm_04', 'crm', 4, 'ranking',
    'Ordene estas etapas del proceso comercial según el tiempo que le toma cada una (1 = la que más tiempo consume):',
    'Piense en un cliente típico desde que lo contacta hasta que firma.',
    '[
      "Conseguir el contacto inicial — que la persona correcta sepa que GuardMan existe",
      "La primera llamada o reunión — entender qué necesita el cliente",
      "La visita técnica — ir al lugar, ver el espacio, evaluar riesgos",
      "Preparar la cotización — calcular costos, armar la propuesta",
      "El seguimiento — llamar, insistir, responder dudas adicionales",
      "La negociación final — ajustar precio, condiciones, plazos",
      "La firma del contrato y el inicio del servicio — papeles, facturación, inducción"
    ]',
    'Saber dónde se va el tiempo permite enfocar el CRM en lo que más duele.',
    'El CRM debe optimizar las etapas que más tiempo consumen. Si armar la cotización toma días, necesita un generador de propuestas rápido. Si el seguimiento toma horas, necesita recordatorios automáticos.',
    1),

  ('crm_05', 'crm', 5, 'single_choice',
    'Cuando un cliente ya está operando, ¿cómo se comunica con GuardMan en el día a día?',
    'Piense en un cliente típico. ¿Le escribe por WhatsApp? ¿Lo llama? ¿Habla con el guardia? ¿Con el supervisor?',
    '[
      "Me llaman o escriben a mí directamente — yo soy el punto de contacto",
      "Hablan con el supervisor asignado a su cuenta",
      "El guardia en terreno es el canal — él avisa si pasa algo",
      "Combinación de canales — WhatsApp para cosas rápidas, llamado para urgencias",
      "No tengo un canal definido — cada cliente se comunica como puede"
    ]',
    'La comunicación diaria es donde se construye o se destruye la relación con el cliente.',
    'El CRM debe reflejar el canal real de comunicación. Si todo pasa por Rodrigo, necesita centralización de mensajes. Si hay supervisores, el CRM debe permitir asignación y trazabilidad por cuenta.',
    1),

  ('crm_06', 'crm', 6, 'single_choice',
    'Si un cliente llama un viernes a las 8 PM porque el guardia no llegó, ¿qué pasa?',
    'No la respuesta del manual. Lo que realmente pasa. ¿Quién contesta? ¿Cuánto demora en resolverse?',
    '[
      "Me llaman a mí y yo personalmente resuelvo — consigo un reemplazo en menos de una hora",
      "El supervisor de turno lo resuelve — yo me entero al día siguiente",
      "Tenemos un protocolo y un número de emergencia — se escala y se resuelve",
      "Depende — a veces se resuelve rápido, a veces el cliente se queda sin guardia esa noche",
      "No me ha pasado, o ha pasado muy pocas veces"
    ]',
    'La capacidad de respuesta ante una emergencia es lo que separa a una empresa seria de una improvisada.',
    'El CRM debe tener un módulo de incidentes o al menos un registro rápido. Si la resolución depende de Rodrigo, el CRM debe darle visibilidad inmediata de disponibilidad de guardias.',
    1),

  ('crm_07', 'crm', 7, 'ranking',
    'Ordene estas cosas según lo que más le gustaría tener centralizado en un solo lugar (1 = lo más urgente):',
    'Si pudiera abrir una sola pantalla y ver todo lo importante, ¿qué tendría que aparecer?',
    '[
      "Todos los clientes activos con su estado de servicio — quién está al día, quién debe, quién pidió algo",
      "Los leads nuevos que entraron hoy — para no perder ninguno",
      "Los contratos que vencen este mes — para renovar a tiempo",
      "Los guardias asignados a cada cliente — quién está dónde y en qué turno",
      "Historial de comunicación con cada cliente — cuándo hablamos y de qué",
      "Pagos y facturación — quién pagó, quién está atrasado, montos pendientes",
      "Incidentes o reclamos abiertos — qué pasó y cómo se resolvió"
    ]',
    'Lo que más urge centralizar define el alcance inicial del CRM.',
    'El CRM debe priorizar lo que Rodrigo considera más urgente. Si la facturación es prioridad 1, el CRM necesita integración contable. Si son los leads, el foco es pipeline comercial.',
    1),

  ('crm_08', 'crm', 8, 'free_text',
    'Si pudiera pedirle una sola cosa al sistema ideal para manejar sus clientes, ¿qué le pediría?',
    'No piense en lo que existe. Piense en lo que le resolvería el día. Puede ser algo muy simple o muy ambicioso.',
    '[]',
    'Esta respuesta define el norte del CRM. Todo lo demás se construye alrededor de esto.',
    'El CRM debe resolver el problema más importante de Rodrigo. Esta respuesta es la especificación funcional más valiosa que podemos obtener.',
    1);
