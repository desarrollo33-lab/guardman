-- ============================================================
-- Catálogo dinámico de servicios (CRUD)
-- ============================================================
CREATE TABLE IF NOT EXISTS ceo_questionnaire_services (
  id          TEXT PRIMARY KEY,
  question_id TEXT NOT NULL,
  name        TEXT NOT NULL,
  description TEXT,
  status      TEXT DEFAULT 'active' CHECK(status IN ('active','archived')),
  source      TEXT DEFAULT 'custom' CHECK(source IN ('predefined','custom')),
  sort_order  INTEGER DEFAULT 0,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ceo_services_question
  ON ceo_questionnaire_services(question_id, status, sort_order);

-- ============================================================
-- Tabla de auditoría (opcional pero útil)
-- ============================================================
CREATE TABLE IF NOT EXISTS ceo_questionnaire_audit (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  entity      TEXT NOT NULL,           -- 'service' | 'answer' | 'session'
  entity_id   TEXT NOT NULL,
  action      TEXT NOT NULL,           -- 'create' | 'update' | 'delete' | 'archive'
  payload     TEXT,                    -- JSON
  actor       TEXT,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
