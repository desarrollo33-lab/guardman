-- ============================================================
-- Seed: Register all existing images + entity assignments
-- ============================================================

-- ===== GLOBAL images =====
INSERT OR IGNORE INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags) VALUES
('images/hero-home.webp',            'hero-home.webp',            'GuardMan Chile - Seguridad Privada Profesional', 'image/webp', 132898, 'hero',   '["hero","homepage","global"]'),
('images/og-default.webp',           'og-default.webp',           'GuardMan Chile - Seguridad Privada',             'image/webp', 98,     'og',     '["og","global"]'),
('images/escudo-os10.webp',          'escudo-os10.webp',          'Certificación OS-10 GuardMan Chile',             'image/webp', 19826,  'badge',  '["badge","os10","global"]'),
('images/nosotros_seccion.webp',     'nosotros_seccion.webp',     'Personal de seguridad GuardMan Chile',           'image/webp', 64902,  'staff',  '["staff","nosotros","global"]'),
('images/s4-thumbnail.webp',         's4-thumbnail.webp',         'Guard Pod - Unidad de vigilancia autónoma',      'image/webp', 14178,  'hero',   '["hero","guardpod","product"]'),
('images/Ajax-systems-header.jpg',   'Ajax-systems-header.jpg',   'Ajax Systems - Distribuidor oficial GuardMan',   'image/jpeg', 308149, 'ajax',   '["ajax","partner","homepage"]'),
('images/og-default.jpg',            'og-default.jpg',            'GuardMan Chile - Open Graph Default',            'image/jpeg', 70,     'og',     '["og","global"]');

-- Global entity assignments
INSERT OR IGNORE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES
(1, 'global', 'global', 'hero'),
(2, 'global', 'global', 'og'),
(3, 'global', 'global', 'badge'),
(4, 'global', 'global', 'staff'),
(5, 'global', 'guard-pod', 'product'),
(6, 'global', 'ajax', 'partner');

-- ===== SERVICE images =====
INSERT OR IGNORE INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags) VALUES
('images/service-guardias-de-seguridad.webp',    'service-guardias-de-seguridad.webp',    'Guardias de seguridad certificados OS-10',         'image/webp', 7312,  'service', '["hero","service"]'),
('images/service-cctv-videovigilancia.webp',     'service-cctv-videovigilancia.webp',     'Sistema de CCTV y videovigilancia',                'image/webp', 6280,  'service', '["hero","service"]'),
('images/service-control-de-accesos.webp',       'service-control-de-accesos.webp',       'Control de accesos biométrico',                    'image/webp', 4564,  'service', '["hero","service"]'),
('images/service-escoltas-privados.webp',        'service-escoltas-privados.webp',        'Escoltas privados profesionales',                  'image/webp', 8716,  'service', '["hero","service"]'),
('images/service-monitoreo-24-7.webp',           'service-monitoreo-24-7.webp',           'Centro de monitoreo 24/7',                         'image/webp', 11700, 'service', '["hero","service"]'),
('images/service-seguridad-eventos.webp',        'service-seguridad-eventos.webp',        'Seguridad para eventos corporativos',              'image/webp', 9132,  'service', '["hero","service"]'),
('images/service-seguridad-industrial.webp',     'service-seguridad-industrial.webp',     'Seguridad industrial y perimetral',                'image/webp', 7932,  'service', '["hero","service"]'),
('images/service-auditoria-seguridad.webp',      'service-auditoria-seguridad.webp',      'Auditoría de seguridad profesional',               'image/webp', 9568,  'service', '["hero","service"]');

-- Service entity assignments
INSERT OR IGNORE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES
(8,  'service', 'guardias-de-seguridad', 'hero'),
(9,  'service', 'cctv-videovigilancia',  'hero'),
(10, 'service', 'control-de-accesos',    'hero'),
(11, 'service', 'escoltas-privados',     'hero'),
(12, 'service', 'monitoreo-24-7',        'hero'),
(13, 'service', 'seguridad-eventos',     'hero'),
(14, 'service', 'seguridad-industrial',  'hero'),
(15, 'service', 'auditoria-seguridad',   'hero');
-- guard-pod uses s4-thumbnail (id=5)
INSERT OR IGNORE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES
(5,  'service', 'guard-pod', 'hero');

-- ===== SECTOR images =====
INSERT OR IGNORE INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags) VALUES
('images/sector-industrial.webp',   'sector-industrial.webp',   'Seguridad para sector industrial',   'image/webp', 16718, 'sector', '["hero","sector"]'),
('images/sector-residencial.webp',  'sector-residencial.webp',  'Seguridad para sector residencial', 'image/webp', 23274, 'sector', '["hero","sector"]'),
('images/sector-automotriz.webp',   'sector-automotriz.webp',   'Seguridad para sector automotriz',  'image/webp', 13204, 'sector', '["hero","sector"]'),
('images/sector-corporativo.webp',  'sector-corporativo.webp',  'Seguridad para sector corporativo', 'image/webp', 14566, 'sector', '["hero","sector"]'),
('images/sector-diplomatico.webp',  'sector-diplomatico.webp',  'Seguridad para sector diplomático', 'image/webp', 22358, 'sector', '["hero","sector"]'),
('images/sector-hoteleria.webp',    'sector-hoteleria.webp',    'Seguridad para sector hotelería',   'image/webp', 16392, 'sector', '["hero","sector"]');

-- Sector entity assignments
INSERT OR IGNORE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES
(16, 'sector', 'industrial',   'hero'),
(17, 'sector', 'residencial',  'hero'),
(18, 'sector', 'automotriz',   'hero'),
(19, 'sector', 'comercial',    'hero'),
(20, 'sector', 'diplomatico',  'hero'),
(21, 'sector', 'hoteleria',    'hero');
-- Sectors sharing images from other categories
INSERT OR IGNORE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES
(16, 'sector', 'construccion', 'hero'),
(5,  'sector', 'eventos',      'hero'),
(5,  'sector', 'comercial',    'hero'),
(1,  'sector', 'educacion',    'hero'),
(1,  'sector', 'hoteleria',    'hero'),
(4,  'sector', 'salud',        'hero');

-- ===== CLIENT images =====
INSERT OR IGNORE INTO media_library (key, filename, alt_text, mime_type, file_size, category, tags) VALUES
('images/client-avanzapark.webp',        'client-avanzapark.webp',        'Avanza Park',           'image/webp', 21052, 'client', '["logo","client"]'),
('images/client-courtyardmarriot.webp',  'client-courtyardmarriot.webp',  'Courtyard by Marriott', 'image/webp', 14504, 'client', '["logo","client"]'),
('images/client-hamptons.webp',          'client-hamptons.webp',          'Hamptons',              'image/webp', 24266, 'client', '["logo","client"]'),
('images/client-kavak.webp',             'client-kavak.webp',             'Kavak',                 'image/webp', 26938, 'client', '["logo","client"]'),
('images/client-workcenter.webp',        'client-workcenter.webp',        'Work Center',           'image/webp', 20014, 'client', '["logo","client"]');

-- Client entity assignments
INSERT OR IGNORE INTO media_entities (media_id, entity_type, entity_slug, usage) VALUES
(22, 'client', 'avanza-park',        'logo'),
(23, 'client', 'courtyard-marriott', 'logo'),
(24, 'client', 'hamptons',           'logo'),
(25, 'client', 'kavak',              'logo'),
(26, 'client', 'work-center',        'logo');
