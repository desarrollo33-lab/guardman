-- Corrección masiva: reemplazar TODO lenguaje técnico/contaminante
-- por lenguaje natural enfocado en el trabajo de Rodrigo

-- ═══════════════════════════════════════════════════════════
-- PREGUNTAS (question_es)
-- ═══════════════════════════════════════════════════════════

UPDATE ceo_questionnaire_questions SET question_es = 'Si tuviera que elegir entre estos dos estilos, ¿cuál refleja mejor a GuardMan?'
WHERE id = 'dif_04';

UPDATE ceo_questionnaire_questions SET question_es = '¿Sabe de alguna otra empresa de seguridad que sea mucho más conocida o visible que GuardMan en su sector?'
WHERE id = 'dif_05';

-- ═══════════════════════════════════════════════════════════
-- SUBTÍTULOS (subtitle_es)
-- ═══════════════════════════════════════════════════════════

UPDATE ceo_questionnaire_questions SET subtitle_es = 'Por teléfono, por correo o en una reunión. Piense en las preguntas que se repiten una y otra vez, las que ya sabe de memoria.'
WHERE id = 'id_03';

UPDATE ceo_questionnaire_questions SET subtitle_es = 'La respuesta de alguien que conoce el negocio desde adentro vale más que cualquier argumento comercial. Sea honesto.'
WHERE id = 'id_04';

UPDATE ceo_questionnaire_questions SET subtitle_es = 'Esa pregunta inicial define la primera impresión que tiene que dar GuardMan. Si la respuesta a esa pregunta llega en los primeros cinco segundos, la persona se queda.'
WHERE id = 'id_08';

UPDATE ceo_questionnaire_questions SET subtitle_es = 'Esto permite saber dónde hay mayor demanda y dónde hay que reforzar la presencia con más urgencia.'
WHERE id = 'srv_02';

UPDATE ceo_questionnaire_questions SET subtitle_es = 'Recomendación de otro cliente, búsqueda en internet, redes sociales, correo, ferias. Ordene los canales del que más trae al que menos trae.'
WHERE id = 'com_02';

UPDATE ceo_questionnaire_questions SET subtitle_es = 'La elección entre los dos define el tono de toda la comunicación y los mensajes de presentación.'
WHERE id = 'dif_04';

-- ═══════════════════════════════════════════════════════════
-- OBJETIVOS (objective_es) - 22 correcciones
-- ═══════════════════════════════════════════════════════════

UPDATE ceo_questionnaire_questions SET objective_es = 'Esta frase se convierte en el texto principal de presentación de GuardMan, en las descripciones de cada servicio y en los avisos que se publican con el nombre de la empresa. Es la primera impresión que tiene una persona antes de contactarlos.'
WHERE id = 'id_01';

UPDATE ceo_questionnaire_questions SET objective_es = 'Estas frases son las que la gente usa cuando describe lo que necesita. Las personas expresan sus dudas de la misma forma en cualquier canal, y GuardMan debe poder responder a cada una. Cada frase se convierte en un texto que responde a esa duda concreta.'
WHERE id = 'id_02';

UPDATE ceo_questionnaire_questions SET objective_es = 'Estas tres preguntas se publican en la sección de Preguntas Frecuentes, con sus respuestas. Aparecen destacadas cuando alguien busca y se usan también en los avisos publicados para responder antes de que la persona pregunte.'
WHERE id = 'id_03';

UPDATE ceo_questionnaire_questions SET objective_es = 'Esta respuesta se usa como texto principal de la presentación, en los avisos publicados y en los videos de presentación. Es la objeción universal que la gente tiene antes de contratar.'
WHERE id = 'id_04';

UPDATE ceo_questionnaire_questions SET objective_es = 'Este error es el ángulo de entrada para artículos informativos. Un artículo que corrija el error y enseñe a la gente lo que Rodrigo sabe se comparte mucho, llega a personas que tienen esa duda y genera confianza antes de la venta.'
WHERE id = 'id_06';

UPDATE ceo_questionnaire_questions SET objective_es = 'El material de presentación debe responder esta pregunta antes de cualquier otra cosa. Si no la responde, la persona se va en menos de diez segundos.'
WHERE id = 'id_08';

UPDATE ceo_questionnaire_questions SET objective_es = 'Estas comunas son las primeras zonas donde se refuerza la presencia de GuardMan. Cada una es un punto de contacto con clientes de esa zona, y se prepara material específico para captar clientes locales.'
WHERE id = 'srv_01';

UPDATE ceo_questionnaire_questions SET objective_es = 'Determinar el orden de prioridad del material de presentación. El grupo número uno recibe el contenido primero porque tiene la mayor demanda de consultas.'
WHERE id = 'srv_02';

UPDATE ceo_questionnaire_questions SET objective_es = 'Esta comuna se convierte en la zona prioritaria con material reforzado. Todo el esfuerzo local apunta ahí primero.'
WHERE id = 'srv_03';

UPDATE ceo_questionnaire_questions SET objective_es = 'Si la respuesta es sí, se debe crear material regional. Si la respuesta es no, todo el contenido se enfoca en la Región Metropolitana.'
WHERE id = 'srv_04';

UPDATE ceo_questionnaire_questions SET objective_es = 'Estas comunas se convierten en los próximos objetivos de contenido y los esfuerzos locales. Se planifica con anticipación.'
WHERE id = 'srv_06';

UPDATE ceo_questionnaire_questions SET objective_es = 'Este número se publica en la presentación principal como prueba social. "Más de X guardias operando" genera confianza y es un factor de credibilidad.'
WHERE id = 'srv_08';

UPDATE ceo_questionnaire_questions SET objective_es = 'Determinar dónde se concentra el presupuesto comercial. Si los referidos son el canal principal, se invierte en experiencia del cliente. Si las búsquedas en internet están creciendo, se invierte en material de presentación.'
WHERE id = 'com_02';

UPDATE ceo_questionnaire_questions SET objective_es = 'Si cierra en una llamada, la página de presentación tiene que ser autosuficiente. Si toma tres reuniones, hay que pensar en una secuencia de materiales de seguimiento que acompañen al cliente potencial.'
WHERE id = 'com_04';

UPDATE ceo_questionnaire_questions SET objective_es = 'Este es el volumen del flujo. Si es bajo, hay que aumentar los contactos recibidos (más difusión, más avisos). Si es alto pero no cierran, hay que mejorar el cierre.'
WHERE id = 'com_07';

UPDATE ceo_questionnaire_questions SET objective_es = 'Esta frase se convierte en el texto principal de la presentación, en los avisos publicados y en la primera respuesta que da cualquier ejecutivo de ventas. Es la propuesta de valor pura.'
WHERE id = 'dif_01';

UPDATE ceo_questionnaire_questions SET objective_es = 'Este diferenciador técnico se publica en la presentación como "por qué elegirnos". Se incluye en la presentación principal, en las descripciones de los servicios y en los avisos. Es lo que hace que GuardMan sea único.'
WHERE id = 'dif_02';

UPDATE ceo_questionnaire_questions SET objective_es = 'Define el enfoque principal. Si elige "profesional", la presentación habla de certificaciones, procesos y rigor. Si elige "cercano", habla de confianza, relaciones humanas y servicio personalizado.'
WHERE id = 'dif_04';

UPDATE ceo_questionnaire_questions SET objective_es = 'Lista de competidores a los que se enfrenta GuardMan. Saber contra quién competimos es el primer paso para que más gente encuentre a GuardMan y no a la competencia.'
WHERE id = 'dif_05';

UPDATE ceo_questionnaire_questions SET objective_es = 'Esta lista se convierte en el catálogo principal de servicios de la presentación. El orden de los servicios refleja la demanda real de la gente, con los más pedidos primero.'
WHERE id = 'srv_11';

UPDATE ceo_questionnaire_questions SET objective_es = 'Los años de operación son un factor de credibilidad. "Operando desde el año X" se publica en la presentación principal y al pie de los documentos.'
WHERE id = 'srv_15';

UPDATE ceo_questionnaire_questions SET objective_es = 'El primer factor de la lista se convierte en el mensaje principal de la presentación, de los avisos publicados y de las propuestas a clientes. Los siguientes tres son los argumentos de apoyo.'
WHERE id = 'srv_19';

-- ═══════════════════════════════════════════════════════════
-- HELPER TEXT - 8 correcciones
-- ═══════════════════════════════════════════════════════════

UPDATE ceo_questionnaire_questions SET helper_text = 'Esta frase va a la presentación principal y a los avisos publicados. Cuanto más auténtica, mejor.'
WHERE id = 'id_01';

UPDATE ceo_questionnaire_questions SET helper_text = '5 a 10 ejemplos reales. Cada uno se convierte en una pregunta específica.'
WHERE id = 'id_02';

UPDATE ceo_questionnaire_questions SET helper_text = 'Un artículo informativo que corrija este error puede llegar a miles de personas.'
WHERE id = 'id_06';

UPDATE ceo_questionnaire_questions SET helper_text = 'Decisión de enfoque.'
WHERE id = 'srv_09';

UPDATE ceo_questionnaire_questions SET helper_text = 'Define dónde invertir esfuerzo comercial.'
WHERE id = 'com_02';

UPDATE ceo_questionnaire_questions SET helper_text = 'Si la presentación responde esta objeción de antemano, el cierre sube.'
WHERE id = 'com_03';

UPDATE ceo_questionnaire_questions SET helper_text = 'Define dónde poner presupuesto comercial.'
WHERE id = 'com_04';

UPDATE ceo_questionnaire_questions SET helper_text = 'Define el enfoque competitivo.'
WHERE id = 'dif_04';

-- ═══════════════════════════════════════════════════════════
-- DESCRIPCIONES DE SECCIONES
-- ═══════════════════════════════════════════════════════════

UPDATE ceo_questionnaire_sections SET description = 'Ocho preguntas sobre cómo te percibe la gente, qué te dice cuando te contacta y cómo te recomienda. Tus respuestas se convierten en los textos de presentación, las preguntas frecuentes, los testimonios y el tono de toda la comunicación.'
WHERE id = 'identidad';

UPDATE ceo_questionnaire_sections SET description = 'Preguntas sobre dónde están sus clientes, dónde recibe consultas y dónde quiere crecer. Las respuestas muestran en qué zonas GuardMan tiene más presencia y en cuáles le conviene fortalecerse.'
WHERE id = 'servicios';

UPDATE ceo_questionnaire_sections SET description = 'Ocho preguntas sobre su diferenciador, los competidores y por qué alguien debería elegir GuardMan por sobre cualquier otra opción. Las respuestas se convierten en la propuesta de valor de la presentación, los mensajes de los avisos y la posición competitiva.'
WHERE id = 'diferenciacion';
