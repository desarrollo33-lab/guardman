-- Eliminar las menciones de SEO restantes (8 preguntas)
UPDATE ceo_questionnaire_questions SET objective_es = 'Si la respuesta es sí, el sitio web debe tener páginas regionales. Si la respuesta es no, todo el contenido se enfoca en la Región Metropolitana.' WHERE id = 'srv_04';

UPDATE ceo_questionnaire_questions SET objective_es = 'Estas comunas se convierten en los próximos objetivos de contenido del sitio y campañas de marketing local. Se planifica el contenido con anticipación.' WHERE id = 'srv_06';

UPDATE ceo_questionnaire_questions SET objective_es = 'Estas comunas son las próximas oportunidades de contenido con baja competencia. Las páginas del sitio se posicionan más fácil cuando hay menos competidores.' WHERE id = 'srv_07';

UPDATE ceo_questionnaire_questions SET objective_es = 'Determinar dónde se concentra el presupuesto de marketing. Si los referidos son el canal principal, se invierte en experiencia del cliente. Si las búsquedas en Google están creciendo, se invierte en contenido del sitio.' WHERE id = 'com_02';

UPDATE ceo_questionnaire_questions SET objective_es = 'Esta tasa revela dónde está el cuello de botella. Si recibe muchas consultas pero cierra pocas, el problema es el contenido del sitio. Si recibe pocas consultas, el problema es la visibilidad.' WHERE id = 'com_05';

UPDATE ceo_questionnaire_questions SET objective_es = 'Este es el volumen del embudo. Si es bajo, hay que aumentar las visitas al sitio (más contenido, más anuncios). Si es alto pero no cierran, hay que mejorar la conversión.' WHERE id = 'com_07';

UPDATE ceo_questionnaire_questions SET objective_es = 'Demanda reprimida. Estas comunas son la próxima frontera de expansión. Se planifica contenido del sitio con anticipación para cuando se decida abrir operación.' WHERE id = 'dif_06';

UPDATE ceo_questionnaire_questions SET objective_es = 'Las fotos y videos reales se publican en el sitio. Una galería con imágenes auténticas genera más confianza que las fotos de banco de imágenes.' WHERE id = 'srv_17';
