-- ============================================================
-- GuardMan · Cuestionario de ADN de Marca — CEO Rodrigo Mora
-- Schema dinámico para capturar las 42 respuestas en D1
-- Patrón basado en dcr-motors-mvp schema-brand-dna.sql
-- ============================================================

-- 1. SECCIONES DEL CUESTIONARIO
CREATE TABLE IF NOT EXISTS ceo_questionnaire_sections (
  id            TEXT PRIMARY KEY,            -- 'identidad', 'servicios', 'comercial', 'personas', 'diferenciacion'
  title_es      TEXT NOT NULL,
  description   TEXT,
  icon          TEXT,                        -- emoji
  sort_order    INTEGER DEFAULT 0,
  status        TEXT DEFAULT 'pending' CHECK(status IN ('pending','in_progress','complete')),
  completed_at  TIMESTAMP,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. PREGUNTAS (pre-seeded, estructura fija)
CREATE TABLE IF NOT EXISTS ceo_questionnaire_questions (
  id            TEXT PRIMARY KEY,            -- 'id_01', 'srv_01', 'com_01', 'per_01', 'dif_01'
  section_id    TEXT NOT NULL REFERENCES ceo_questionnaire_sections(id) ON DELETE CASCADE,
  sort_order    INTEGER DEFAULT 0,
  type          TEXT NOT NULL CHECK(type IN (
                  'single_choice',        -- una alternativa
                  'multiple_choice',      -- múltiples alternativas
                  'scale_1_10',           -- escala 1-10
                  'scale_agreement',      -- totalmente en desacuerdo → totalmente de acuerdo
                  'free_text',            -- texto libre
                  'ranking',              -- ordenar prioridades
                  'binary',               -- sí/no con explicación
                  'comparison'            -- comparación A vs B con justificación
                )),
  question_es   TEXT NOT NULL,
  subtitle_es   TEXT,                        -- contexto adicional
  options_json  TEXT DEFAULT '[]',            -- alternativas predefinidas (JSON array)
  helper_text   TEXT,                        -- texto de ayuda
  required      INTEGER DEFAULT 1,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ceo_q_section ON ceo_questionnaire_questions(section_id, sort_order);

-- 3. RESPUESTAS DE RODRIGO
CREATE TABLE IF NOT EXISTS ceo_questionnaire_answers (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  question_id         TEXT NOT NULL REFERENCES ceo_questionnaire_questions(id) ON DELETE CASCADE,
  section_id          TEXT NOT NULL REFERENCES ceo_questionnaire_sections(id) ON DELETE CASCADE,

  -- Campos de respuesta (según type)
  selected_values_json  TEXT DEFAULT '[]',   -- para single_choice, multiple_choice, ranking
  scale_value     REAL,                      -- para scale_1_10, scale_agreement
  binary_value    INTEGER,                   -- 0 = no, 1 = sí
  free_text       TEXT,                      -- texto libre, justificaciones
  comparison_a    TEXT,                      -- opción A en comparison
  comparison_b    TEXT,                      -- opción B en comparison
  comparison_choice TEXT,                    -- 'A' o 'B'
  comparison_why  TEXT,                      -- justificación

  -- Metadata
  confidence      INTEGER CHECK(confidence BETWEEN 1 AND 5),  -- qué tan seguro está (1-5)
  tags_json       TEXT DEFAULT '[]',        -- tags semánticos
  notes           TEXT,                     -- notas internas/contexto
  status          TEXT DEFAULT 'draft' CHECK(status IN ('draft','final')),
  answered_by     TEXT DEFAULT 'rodrigo.mora@guardman.cl',
  answered_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ceo_a_question ON ceo_questionnaire_answers(question_id);
CREATE INDEX IF NOT EXISTS idx_ceo_a_section  ON ceo_questionnaire_answers(section_id, status);

-- 4. SESIÓN (tracking de quién está completando el cuestionario)
CREATE TABLE IF NOT EXISTS ceo_questionnaire_session (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  respondent_email  TEXT NOT NULL,
  respondent_name   TEXT NOT NULL,
  started_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_seen_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at      TIMESTAMP,
  total_questions   INTEGER DEFAULT 42,
  questions_answered INTEGER DEFAULT 0,
  completion_pct    REAL DEFAULT 0,
  ip_hash           TEXT,
  user_agent        TEXT
);

CREATE INDEX IF NOT EXISTS idx_ceo_session_email ON ceo_questionnaire_session(respondent_email);

-- 5. CONVERSACIÓN / NOTAS LIBRES (para el "diálogo" con Rodrigo)
CREATE TABLE IF NOT EXISTS ceo_questionnaire_conversation (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER REFERENCES ceo_questionnaire_session(id) ON DELETE CASCADE,
  section_id    TEXT REFERENCES ceo_questionnaire_sections(id) ON DELETE SET NULL,
  question_id   TEXT REFERENCES ceo_questionnaire_questions(id) ON DELETE SET NULL,
  speaker       TEXT NOT NULL CHECK(speaker IN ('rodrigo','pi','system')),
  message       TEXT NOT NULL,
  context_json  TEXT DEFAULT '{}',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ceo_conv_session  ON ceo_questionnaire_conversation(session_id);
CREATE INDEX IF NOT EXISTS idx_ceo_conv_section  ON ceo_questionnaire_conversation(section_id);

-- ============================================================
-- SEED: SECCIONES
-- ============================================================
INSERT OR IGNORE INTO ceo_questionnaire_sections (id, title_es, description, sort_order, icon) VALUES
  ('identidad',      'Identidad de Marca',          'Quién es GuardMan, su historia fundacional, valores, voz y personalidad. La constitución de la marca.', 1, '🧬'),
  ('servicios',      'Servicios y Operación',       'Qué hace GuardMan, cómo lo hace, qué incluye cada servicio y qué no. La operación real del día a día.', 2, '🛡️'),
  ('comercial',      'Estrategia Comercial y Clientes','Modelo de negocio, pricing, segmentos de clientes, ciclo de venta y casos de éxito.', 3, '💼'),
  ('personas',       'Personas y Cultura',          'El equipo directivo, los guardias, la formación, la retención y Rodrigo como líder.', 4, '👥'),
  ('diferenciacion', 'Diferenciación y Mercado',    'La competencia, el moat competitivo, el futuro de la industria de seguridad privada en Chile.', 5, '🎯');

-- ============================================================
-- SEED: PREGUNTAS SECCIÓN 1 — IDENTIDAD (8 preguntas)
-- ============================================================
INSERT OR IGNORE INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, required) VALUES
  ('id_01', 'identidad', 1, 'free_text',
    '¿Qué significa "GuardMan"? ¿De dónde viene el nombre?',
    'Contanos la historia real. ¿Por qué ese nombre? ¿Qué intentabas comunicar cuando lo elegiste?',
    '[]',
    'Esta respuesta define el tono de toda la identidad verbal de la marca.',
    1),

  ('id_02', 'identidad', 2, 'single_choice',
    'Si GuardMan fuera una persona, ¿qué arquetipo la describe mejor?',
    'Pensá en la personalidad de la marca, no en vos como CEO.',
    '["El Guardián: protege, vigila, está siempre alerta. Serio y confiable.","El Profesional: técnico, formado, preciso. Inspirado en la seguridad corporativa.","El Aliado: cercano, accesible, resuelve problemas. Estilo partner estratégico.","El Veterano: experiencia, conocimiento callejero, sabiduría ganada con los años.","El Innovador: tecnología, modernidad, nuevos métodos. Seguridad 4.0.","El Sargento: disciplina, jerarquía, orden. Estilo militar moderno."]',
    'No hay respuesta correcta. Es la intuición primera.',
    1),

  ('id_03', 'identidad', 3, 'scale_1_10',
    '¿Qué tan importante es que GuardMan sea percibido como "chileno" vs "global"?',
    '1 = 100% chileno, local, arraigado a comunas específicas. 10 = 100% global, sin anclaje geográfico.',
    '[]',
    'Esto define idioma del sitio, tono del copy, referencias culturales.',
    1),

  ('id_04', 'identidad', 4, 'multiple_choice',
    '¿Qué palabras NO pueden faltar en el vocabulario de GuardMan? (elegí todas las que apliquen)',
    'Estas palabras serán el léxico canónico de la marca. Serán obligatorias en el sitio, propuestas y comunicación.',
    '["Confianza","Seguridad","Profesionalismo","Compromiso","Vigilancia","Prevención","Protección","Custodia","Resguardo","Discreción","Disciplina","Experiencia","Capacitación","Responsabilidad","Cercanía","Respuesta","Cumplimiento","Tecnología","OS-10","Cero tolerancia"]',
    'Máximo 10 para mantener foco semántico. Si elegís más, reducilo.',
    1),

  ('id_05', 'identidad', 5, 'single_choice',
    'El tono de voz de GuardMan debería ser:',
    NULL,
    '["Institucional y serio (estilo banco o AFP)","Cercano y directo (estilo vecino de confianza)","Técnico y operativo (estilo manual de procedimientos)","Profesional pero accesible (estudio jurídico moderno)","Resolutivo y ejecutivo (estilo CEO hablando con shareholders)"]',
    'Esto determina copywriting, propuestas, comunicados, manejo de incidentes.',
    1),

  ('id_06', 'identidad', 6, 'free_text',
    'Describí el momento exacto en que decidiste crear GuardMan.',
    'La anécdota fundacional. ¿Qué viste en el mercado que nadie más estaba viendo? ¿Fue una necesidad insatisfecha? ¿Un cliente que te pidió algo que no existía?',
    '[]',
    'Esta historia será el narrative core de la marca.',
    1),

  ('id_07', 'identidad', 7, 'comparison',
    'GuardMan se parece más a:',
    'Elegí la opción con la que más te identificás y explicá por qué.',
    '["Securitas: gigante global, marca reconocida, propuesta estandarizada","Prosegur: latam, equilibrio entre marca y servicio, presencia regional","Empresa familiar chilena de seguridad: cercana, personalizada, dueña presente","Startup de seguridad tech: moderna, app-first, modelo disruptivo","Consultora boutique: especializada en clientes corporativos grandes, premium"]',
    'Compará con 2 de estas opciones. Elegí la más cercana y la más lejana.',
    1),

  ('id_08', 'identidad', 8, 'free_text',
    '¿Qué NO es GuardMan? ¿Qué nunca va a ser?',
    'Los límites son tan importantes como el centro. Definir lo que no sos define lo que sí sos.',
    '[]',
    'Fundamental para evitar dilución de marca en el tiempo.',
    1);

-- ============================================================
-- SEED: PREGUNTAS SECCIÓN 2 — SERVICIOS Y OPERACIÓN (10 preguntas)
-- ============================================================
INSERT OR IGNORE INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, required) VALUES
  ('srv_01', 'servicios', 1, 'multiple_choice',
    '¿Qué servicios ofrece GuardMan HOY? (elegí todos los que apliquen)',
    'El catálogo actual real, no el aspiracional.',
    '["Portería en edificios residenciales","Portería en oficinas y corporativos","Rondas y vigilancia perimetral","Control de acceso (recepción, torniquetes, lectores)","Conserjería (recepción + tareas administrativas)","Seguridad para retail y locales comerciales","Seguridad para eventos (conciertos, ferias, corporativos)","Escolta privada y protección de personas","Monitoreo CCTV / Alarmas","Asesoría y auditoría de seguridad","Instalación de sistemas (cámaras, alarmas, control acceso)","Investigaciones privadas","Seguridad para condominios y comunidades","Seguridad industrial y faenas","Servicios de bínting y choferes de reemplazo","Servicios de mudanza y traslado de valores"]',
    'Esto es la base del sitio, de las propuestas y del modelo de revenue.',
    1),

  ('srv_02', 'servicios', 2, 'ranking',
    'Ordená los servicios por IMPORTANCIA DE INGRESO (1 = genera más revenue):',
    'Arrastrá con las flechas para reordenar.',
    '["Portería edificios","Portería oficinas","Rondas perimetrales","Control de acceso","Conserjería","Retail","Eventos","CCTV/Monitoreo","Escolta","Auditoría/Asesoría"]',
    'El top 3 concentra probablemente el 80% del MRR.',
    1),

  ('srv_03', 'servicios', 3, 'single_choice',
    'La cobertura geográfica actual de GuardMan es:',
    NULL,
    '["Solo Santiago (algunas comunas específicas)","Santiago completo (40+ comunas)","Santiago + 1-2 regiones (Valparaíso, Rancagua, etc.)","Nacional completo (todas las regiones)","Otra cobertura (describir en comentario)"]',
    'Define la promesa de cobertura y la estrategia de expansión.',
    1),

  ('srv_04', 'servicios', 4, 'ranking',
    'Ordená las COMUNAS o zonas por importancia estratégica para GuardMan (1 = más importante):',
    'Esto define dónde concentrar inversión en marketing y operaciones.',
    '["Las Condes / Vitacura / Lo Barnechea","Providencia / Ñuñoa / Santiago centro","Maipú / Pudahuel / Estación Central","Puente Alto / San Bernardo","La Florida / Macul / Peñalolén","Conchalí / Recoleta / Independencia","San Miguel / San Joaquín / Quinta Normal","Cerrillos / Cerro Navia / Lo Prado"]',
    'Esto es para entender el perfil de cliente y la densidad de servicio.',
    1),

  ('srv_05', 'servicios', 5, 'scale_1_10',
    '¿Qué tan estandarizados están los servicios?',
    '1 = Cada cliente recibe un servicio custom artesanal. 10 = Servicio tipo producto, idéntico para todos, configurable solo por parámetros.',
    '[]',
    'Define la complejidad operativa y la velocidad de escalar.',
    1),

  ('srv_06', 'servicios', 6, 'single_choice',
    '¿Cuál es el modelo de cobro principal?',
    NULL,
    '["Mensual fijo por guardia asignado (turno completo)","Mensual fijo por horas contratadas","Por evento (eventos, escoltas, servicios puntuales)","Mixto: mensual para contratos + por evento para adicionales","Mixto: fee base + variable según número de horas reales trabajadas"]',
    'Esto define la previsibilidad de ingresos.',
    1),

  ('srv_07', 'servicios', 7, 'binary',
    '¿GuardMan debería tener su propia Central de Monitoreo 24/7?',
    'Sí = invertir en infraestructura, software, operadores. No = tercerizar con partner.',
    '[]',
    'Define estructura de costos fijos y nivel de servicio.',
    1),

  ('srv_08', 'servicios', 8, 'free_text',
    'Describí el proceso de incorporación de un nuevo cliente.',
    'Desde que llega el primer contacto hasta que el primer guardia está en el puesto. ¿Cuántos días? ¿Qué pasos? ¿Quién aprueba qué?',
    '[]',
    'Este proceso es el onboarding playbook.',
    1),

  ('srv_09', 'servicios', 9, 'binary',
    '¿GuardMan debería ofrecer garantía de servicio? (Si no cumplís SLA, devolvés X% del fee mensual)',
    'Sí = diferenciador potente pero costoso en errores. No = modelo tradicional, menor riesgo financiero.',
    '[]',
    'Decisión de posicionamiento.',
    1),

  ('srv_10', 'servicios', 10, 'scale_1_10',
    '¿Qué tan importante es la tecnología (app del cliente, app del guardia, dashboard, GPS, etc.)?',
    '1 = irrelevante, todo se hace con radio y teléfono. 10 = absolutamente central, sin tech no competimos.',
    '[]',
    'Define roadmap tecnológico y presupuesto de IT.',
    1);

-- ============================================================
-- SEED: PREGUNTAS SECCIÓN 3 — ESTRATEGIA COMERCIAL Y CLIENTES (8 preguntas)
-- ============================================================
INSERT OR IGNORE INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, required) VALUES
  ('com_01', 'comercial', 1, 'single_choice',
    '¿Cuál es el cliente #1 de GuardMan HOY?',
    NULL,
    '["Edificios residenciales (comunidades, condominios)","Oficinas y empresas corporativas","Retail y locales comerciales","Industrial y faenas","Eventos y productores","Residenciales premium (casas particulares)","Mix heterogéneo sin predominio claro"]',
    'Esto define a quién le hablamos primero.',
    1),

  ('com_02', 'comercial', 2, 'ranking',
    'Ordená los segmentos por PRIORIDAD ESTRATÉGICA de aquí a 12 meses (1 = más prioritario):',
    NULL,
    '["Edificios residenciales","Oficinas corporativas","Retail","Industrial","Eventos","Residencial premium","Condominios"]',
    'Define dónde invertir marketing y esfuerzo comercial.',
    1),

  ('com_03', 'comercial', 3, 'scale_1_10',
    '¿Qué tan exclusivo es GuardMan?',
    '1 = captamos a cualquier cliente con presupuesto. 10 = somos altamente selectivos, criterios estrictos.',
    '[]',
    'Define la velocidad de crecimiento vs. la calidad de cartera.',
    1),

  ('com_04', 'comercial', 4, 'ranking',
    'Ordená los canales de captación por EFECTIVIDAD actual (1 = el que más leads convierte):',
    NULL,
    '["Referidos de clientes actuales","Búsqueda en Google (SEO)","Google Ads / Meta Ads","WhatsApp directo / redes sociales","Visitas en terreno (preventas)","Ruedas de negocios y eventos del rubro","LinkedIn (especialmente para corporativo)","Página web (orgánico)"]',
    'Define dónde poner presupuesto de marketing.',
    1),

  ('com_05', 'comercial', 5, 'free_text',
    'Describí el ciclo de venta típico de GuardMan.',
    'Desde que un cliente nos contacta hasta que firma el contrato. ¿Cuántas reuniones? ¿Quiénes participan? ¿Cuántos días? ¿Cuál es la objeción más común?',
    '[]',
    'Permite identificar cuellos de botella.',
    1),

  ('com_06', 'comercial', 6, 'binary',
    '¿GuardMan debería tener contratos anuales con renovación automática?',
    'Sí = previsibilidad de revenue, pero rigidez. No = flexibilidad, pero menor previsibilidad.',
    '[]',
    'Define la estructura contractual.',
    1),

  ('com_07', 'comercial', 7, 'free_text',
    'Contá un caso de éxito memorable de GuardMan.',
    'Un cliente real (o anonimizado) donde el servicio de GuardMan hizo una diferencia concreta. Qué pasó, cómo actuaron, qué ganó el cliente. Si no hay, describí un caso "tipo".',
    '[]',
    'Este caso será pilar de propuestas y testimonios.',
    1),

  ('com_08', 'comercial', 8, 'multiple_choice',
    '¿Qué servicios adicionales debería ofrecer GuardMan para subir el ticket promedio? (elegí los que apliquen)',
    NULL,
    '["Monitoreo remoto de CCTV propio","Conexión del CCTV del cliente a nuestra central","Instalación de cámaras y alarmas","Servicio de arriendo de equipos (radios, bodycams)","Consultoría de seguridad (auditoría, levantamiento de riesgos)","Servicios de bínting / chofer de reemplazo","Gestión de visitas y credenciales","Recepción de paquetería y correspondencia","Auxiliares de aseo","Auxiliares de mantenimiento"]',
    'Servicios complementarios mejoran retención y ticket.',
    1);

-- ============================================================
-- SEED: PREGUNTAS SECCIÓN 4 — PERSONAS Y CULTURA (8 preguntas)
-- ============================================================
INSERT OR IGNORE INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, required) VALUES
  ('per_01', 'personas', 1, 'free_text',
    'Contanos tu historia: ¿quién es Rodrigo Mora, CEO de GuardMan?',
    'Formación, trayectoria profesional previa, por qué seguridad, qué te trajo acá. Sin marketing barato.',
    '[]',
    'Esta es la bio de Rodrigo que va al sitio.',
    1),

  ('per_02', 'personas', 2, 'ranking',
    'Ordená estos valores según la CULTURA INTERNA de GuardMan (1 = más importante, lo que se vive día a día):',
    NULL,
    '["Cumplimiento de turnos (nunca faltar)","Honestidad y transparencia","Vocación de servicio","Disciplina y respeto","Responsabilidad y compromiso","Loyalty al cliente","Trabajo en equipo","Capacitación continua","Imagen personal y presentación","Adaptabilidad y resolución"]',
    'La cultura es la que retiene a los buenos guardias.',
    1),

  ('per_03', 'personas', 3, 'single_choice',
    'La selección de un nuevo Guardia de GuardMan prioriza:',
    NULL,
    '["Experiencia previa en seguridad (excluyente)","Curso OS-10 vigente (excluyente)","Pruebas psicológicas y de integridad","Capacitación propia posterior al ingreso","Mix: OS-10 + curso interno + prueba de campo","Otro modelo (describir en comentario)"]',
    'Define la barrera de entrada para guardias.',
    1),

  ('per_04', 'personas', 4, 'scale_1_10',
    '¿Qué tan importante es la capacitación continua de los guardias?',
    '1 = Una vez que ingresan, se acabó. 10 = Capacitación mensual obligatoria, certificaciones anuales, mejora continua permanente.',
    '[]',
    'Define presupuesto de capacitación y procesos.',
    1),

  ('per_05', 'personas', 5, 'ranking',
    'Ordená los problemas RETENCIÓN de personal más comunes en GuardMan (1 = más común):',
    NULL,
    '["Rotación por bajos salarios (vs. competencia)","Rotación por agotamiento (turnos largos, sin francos)","Abandono por mejor oferta de otra empresa","Abandono por malas condiciones (clima, trato del cliente)","Abandono por problemas familiares o personales","Abandono por sanción disciplinaria (faltas, llegadas tarde)","Abandono por falta de oportunidades de crecimiento","Abandono por conflictos con supervisores o compañeros"]',
    'El top 3 define la estrategia de retención.',
    1),

  ('per_06', 'personas', 6, 'single_choice',
    'El equipo directivo de GuardMan hoy se compone de:',
    NULL,
    '["Solo yo (Rodrigo como CEO operativo, hago todo)","Yo + 1-2 personas clave (gerente operaciones, contador)","Yo + 3-5 personas (gerencia media)","Yo + equipo directivo estructurado (gerentes + subgerentes)","Otro (describir en comentario)"]',
    'Define el organigrama.',
    1),

  ('per_07', 'personas', 7, 'free_text',
    '¿Cuál es el DOLOR OPERATIVO #1 que más te quita el sueño hoy?',
    'El problema que más te molesta, el que más tiempo te consume, el que si se resolviera te cambiaría la vida. Sin filtro.',
    '[]',
    'Esto es prioritario para automatizaciones y mejoras.',
    1),

  ('per_08', 'personas', 8, 'binary',
    '¿Te gustaría que GuardMan crezca hasta tener 1000+ guardias, o preferís mantenerte como empresa boutique de 200-300?',
    'Define la ambición de escala y el modelo de crecimiento.',
    '[]',
    'Decisión estratégica de largo plazo.',
    1);

-- ============================================================
-- SEED: PREGUNTAS SECCIÓN 5 — DIFERENCIACIÓN Y MERCADO (8 preguntas)
-- ============================================================
INSERT OR IGNORE INTO ceo_questionnaire_questions (id, section_id, sort_order, type, question_es, subtitle_es, options_json, helper_text, required) VALUES
  ('dif_01', 'diferenciacion', 1, 'free_text',
    '¿Cuál es la propuesta de valor que ningún competidor de GuardMan puede copiar?',
    'El "moat". ¿Por qué un cliente te elige a vos y no a Securitas, Prosegur, o la empresa de seguridad de la esquina? ¿Es el trato? ¿La rapidez? ¿La flexibilidad? ¿La calidad humana?',
    '[]',
    'Esto es el claim central de todas las propuestas.',
    1),

  ('dif_02', 'diferenciacion', 2, 'ranking',
    'Ordená los COMPETIDORES por amenaza real para GuardMan (1 = más amenazante):',
    NULL,
    '["Securitas (multinacional)","Prosegur (latinoamericana grande)","Otras empresas familiares chilenas","Empresas de seguridad informales / no regularizadas","Seguridad interna del cliente (su propia gente)","Cámaras y alarmas (sustitutos tecnológicos)","Empresas nuevas con modelo tech (startups)","Servicios integrados (aseo + seguridad + mantenimiento)"]',
    'El top 3 define la estrategia competitiva.',
    1),

  ('dif_03', 'diferenciacion', 3, 'multiple_choice',
    '¿Qué certificaciones / acreditaciones tiene GuardMan HOY? (elegí todas las que apliquen)',
    NULL,
    '["Resolución OS-10 vigente (Carabineros de Chile)","Patente municipal al día","Iniciación de actividades SII","Mutualidad de Seguridad / IST (al día)","Seguro de Responsabilidad Civil vigente","Seguro de robo y/o daños","Pólizas para clientes corporativos grandes","Certificación ISO 9001 (calidad)","Certificación ISO 45001 (seguridad y salud ocupacional)","Certificación OSHAS 18001","Acreditación ACHS","Membresía en ACHS / gremiales del rubro","Reconocimientos / premios sectoriales"]',
    'Fundamental para propuestas a corporativos y licitaciones.',
    1),

  ('dif_04', 'diferenciacion', 4, 'scale_1_10',
    '¿Qué tan importante es para GuardMan diferenciarse por PRECIO vs. CALIDAD?',
    '1 = competimos por precio, somos la opción más barata. 10 = competimos por calidad, precio no es lo principal.',
    '[]',
    'Define el posicionamiento competitivo.',
    1),

  ('dif_05', 'diferenciacion', 5, 'binary',
    '¿Crees que la industria de seguridad privada en Chile está creciendo, estable o en declive?',
    'Sí = creciendo / No = en declive. Si crece, ¿a qué ritmo?',
    '[]',
    'Macro del sector.',
    1),

  ('dif_06', 'diferenciacion', 6, 'free_text',
    'Imaginá que es el año 2031. GuardMan cumplió 15 años (o los que correspondan). Alguien escribe la historia de la empresa. ¿Cuál es el primer párrafo?',
    'Escribilo como si fuera una nota en El Mercurio o Diario Financiero. Sin modestia.',
    '[]',
    'Este es el north star. El faro.',
    1),

  ('dif_07', 'diferenciacion', 7, 'comparison',
    'Si tuvieras que posicionarte en UNA de estas dos trincheras, ¿cuál elegís?',
    'Elegí la opción con la que más te identificás.',
    '["La empresa más PROFESIONAL de Chile (calidad sobre todo, certificaciones premium, procesos rigurosos)","La empresa más CONFIABLE de Chile (cercanía, servicio humano, relación de largo plazo)"]',
    'Una sola posición. Lo otro se convierte en "también" no en "es".',
    1),

  ('dif_08', 'diferenciacion', 8, 'scale_1_10',
    '¿Qué tan dispuesto estás a innovar tecnológicamente? (apps, IA, cámaras inteligentes, drones, etc.)',
    '1 = somos tradicionales, lo nuestro son los guardias. 10 = sin tecnología no somos competitivos.',
    '[]',
    'Define el presupuesto de innovación.',
    1);

-- ============================================================
-- VISTAS ÚTILES PARA REPORTES
-- ============================================================

-- Vista: Resumen de respuestas por sección
DROP VIEW IF EXISTS v_ceo_questionnaire_summary;
CREATE VIEW v_ceo_questionnaire_summary AS
SELECT
  s.id AS section_id,
  s.title_es AS section_title,
  s.icon,
  s.status AS section_status,
  s.completed_at,
  COUNT(q.id) AS total_questions,
  SUM(CASE WHEN q.required = 1 THEN 1 ELSE 0 END) AS required_questions,
  COUNT(a.id) AS answered_questions,
  ROUND(
    CAST(COUNT(a.id) AS REAL) / NULLIF(COUNT(q.id), 0) * 100,
    1
  ) AS completion_pct
FROM ceo_questionnaire_sections s
LEFT JOIN ceo_questionnaire_questions q ON q.section_id = s.id
LEFT JOIN ceo_questionnaire_answers a ON a.question_id = q.id AND a.status = 'final'
GROUP BY s.id, s.title_es, s.icon, s.status, s.completed_at
ORDER BY s.sort_order;

-- Vista: Progreso general
DROP VIEW IF EXISTS v_ceo_questionnaire_progress;
CREATE VIEW v_ceo_questionnaire_progress AS
SELECT
  (SELECT COUNT(*) FROM ceo_questionnaire_questions WHERE required = 1) AS total_required,
  (SELECT COUNT(DISTINCT question_id) FROM ceo_questionnaire_answers WHERE status = 'final') AS total_answered,
  ROUND(
    CAST((SELECT COUNT(DISTINCT question_id) FROM ceo_questionnaire_answers WHERE status = 'final') AS REAL) /
    NULLIF((SELECT COUNT(*) FROM ceo_questionnaire_questions WHERE required = 1), 0) * 100,
    1
  ) AS global_completion_pct,
  (SELECT MAX(answered_at) FROM ceo_questionnaire_answers) AS last_answer_at;
