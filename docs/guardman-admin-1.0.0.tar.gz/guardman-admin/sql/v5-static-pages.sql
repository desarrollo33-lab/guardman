-- GuardMan v4 — Static Page Content tables
-- Cada página estática tiene su contenido editable desde el CMS

-- Tabla principal: contenido de páginas estáticas
CREATE TABLE IF NOT EXISTS static_page_content (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  -- Hero
  hero_heading TEXT,
  hero_subheading TEXT,
  hero_badge TEXT,
  hero_image TEXT,
  -- SEO
  meta_title TEXT,
  meta_description TEXT,
  -- Contenido completo como JSON (fallback/override)
  content_json TEXT,
  status TEXT DEFAULT 'published',
  updated_at TEXT DEFAULT (datetime('now')),
  created_at TEXT DEFAULT (datetime('now'))
);

-- ===== SEED: datos iniciales para cada página estática =====
INSERT OR IGNORE INTO static_page_content (slug, hero_heading, hero_subheading, hero_badge, meta_title, meta_description) VALUES
('nosotros', 'Protegemos lo que más te importa desde 2017', 'GuardMan Chile nació con una convicción: la seguridad privada en Chile merecía un estándar más alto.', 'Grupo GuardMan Chile', 'Nosotros — GuardMan Chile | Seguridad Privada en Santiago', 'GuardMan Chile: más de 8 años protegiendo Santiago. 500+ guardias OS-10, centro de monitoreo propio. Conoce nuestra historia y equipo.'),
('guard-pod', 'Guard Pod', 'Vigilancia autónoma 24/7 para obras, eventos y zonas sin infraestructura.', 'Tecnología Propia GuardMan', 'Guard Pod — Vigilancia Autónoma 24/7 | GuardMan Chile', 'Guard Pod V1: unidad autónoma de vigilancia con energía solar, cámaras PTZ 360° y monitoreo remoto.'),
('ajax-systems', 'Ajax Systems', 'Tecnología de seguridad Grado 3 con certificación internacional.', 'Instalador Oficial', 'Ajax Systems — Instalador Oficial | GuardMan Chile', 'Instalador oficial Ajax Systems. Alarmas Grado 3 con tecnología Jeweller.'),
('contacto', 'Contáctanos', 'Estamos disponibles las 24 horas, los 7 días de la semana.', NULL, 'Contacto — GuardMan Chile | Seguridad Privada en Santiago', 'Contacta a GuardMan Chile. Disponibles 24/7. Cotización sin compromiso.'),
('cotizacion', 'Solicita tu Cotización', 'Evaluación gratuita sin compromiso. Respuesta en 24 horas.', NULL, 'Cotizar Seguridad — GuardMan Chile', 'Solicita tu cotización de seguridad privada sin compromiso.'),
('privacidad', 'Política de Privacidad', NULL, NULL, 'Política de Privacidad — GuardMan Chile', 'Política de Privacidad de GuardMan Chile.'),
('terminos', 'Términos y Condiciones', NULL, NULL, 'Términos y Condiciones — GuardMan Chile', 'Términos y Condiciones de GuardMan Chile.');
