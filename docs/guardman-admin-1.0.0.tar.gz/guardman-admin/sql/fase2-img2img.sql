-- GuardMan Admin — Fase 2: Edición img2img
-- Migración D1: parent_media_id para tracking de ediciones

ALTER TABLE media_library ADD COLUMN parent_media_id INTEGER REFERENCES media_library(id);
CREATE INDEX IF NOT EXISTS idx_media_parent ON media_library(parent_media_id);
