-- GuardMan Admin — Fase 1: Subida de Fotos Staff
-- Migración D1: Columnas para metadata del personal

ALTER TABLE media_library ADD COLUMN staff_name TEXT;
ALTER TABLE media_library ADD COLUMN incident_date TEXT;
ALTER TABLE media_library ADD COLUMN location_slug TEXT;

CREATE INDEX IF NOT EXISTS idx_media_staff ON media_library(category, staff_name);
CREATE INDEX IF NOT EXISTS idx_media_location ON media_library(location_slug);
