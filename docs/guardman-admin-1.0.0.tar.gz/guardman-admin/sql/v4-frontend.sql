-- GuardMan v3.0 — D1 Migrations for Open Design Frontend
-- Ejecutar: npx wrangler d1 execute guardman-seo --remote --file=sql/v4-frontend.sql

-- ===== SERVICES: sectors JSON array =====
ALTER TABLE services ADD COLUMN sectors TEXT;

-- ===== SECTORS: color_tag para tags visuales =====
ALTER TABLE sectors ADD COLUMN color_tag TEXT;

-- ===== STATIC PAGES =====
CREATE TABLE IF NOT EXISTS static_pages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  meta_title TEXT,
  meta_description TEXT,
  content_json TEXT,
  status TEXT DEFAULT 'published',
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

-- ===== SEED services.sectors =====
UPDATE services SET sectors = '["comercial","residencial","industrial","educacion","salud","eventos"]' WHERE slug = 'guardias-de-seguridad';
UPDATE services SET sectors = '["comercial","industrial","residencial"]' WHERE slug = 'cctv-videovigilancia';
UPDATE services SET sectors = '["comercial","industrial","residencial","educacion","salud"]' WHERE slug = 'control-de-accesos';
UPDATE services SET sectors = '["comercial","industrial","eventos"]' WHERE slug = 'escoltas-privados';
UPDATE services SET sectors = '["comercial","industrial","residencial"]' WHERE slug = 'monitoreo-24-7';
UPDATE services SET sectors = '["eventos","comercial"]' WHERE slug = 'seguridad-eventos';
UPDATE services SET sectors = '["industrial","construccion","comercial"]' WHERE slug = 'seguridad-industrial';
UPDATE services SET sectors = '["comercial","industrial","residencial","educacion","salud"]' WHERE slug = 'auditoria-seguridad';
UPDATE services SET sectors = '["industrial","construccion","comercial","residencial"]' WHERE slug = 'guard-pod';

-- ===== SEED sectors.color_tag =====
UPDATE sectors SET color_tag = 'tag-green' WHERE slug = 'residencial';
UPDATE sectors SET color_tag = 'tag-blue' WHERE slug = 'comercial';
UPDATE sectors SET color_tag = 'tag-amber' WHERE slug = 'industrial';
UPDATE sectors SET color_tag = 'tag-orange' WHERE slug = 'construccion';
UPDATE sectors SET color_tag = 'tag-violet' WHERE slug = 'educacion';
UPDATE sectors SET color_tag = 'tag-pink' WHERE slug = 'eventos';
UPDATE sectors SET color_tag = 'tag-rose' WHERE slug = 'hoteleria';
UPDATE sectors SET color_tag = 'tag-red' WHERE slug = 'salud';
UPDATE sectors SET color_tag = 'tag-cyan' WHERE slug = 'automotriz';

-- ===== SEED locations.image =====
UPDATE locations SET image = '/images/location-las-condes.webp' WHERE slug = 'las-condes' AND image IS NULL;
UPDATE locations SET image = '/images/location-vitacura.webp' WHERE slug = 'vitacura' AND image IS NULL;
UPDATE locations SET image = '/images/location-lo-barnechea.webp' WHERE slug = 'lo-barnechea' AND image IS NULL;
UPDATE locations SET image = '/images/location-santiago-centro.webp' WHERE slug = 'santiago-centro' AND image IS NULL;
UPDATE locations SET image = '/images/location-la-reina.webp' WHERE slug = 'la-reina' AND image IS NULL;
UPDATE locations SET image = '/images/location-huechuraba.webp' WHERE slug = 'huechuraba' AND image IS NULL;
UPDATE locations SET image = '/images/location-quilicura.webp' WHERE slug = 'quilicura' AND image IS NULL;
UPDATE locations SET image = '/images/location-pudahuel.webp' WHERE slug = 'pudahuel' AND image IS NULL;
UPDATE locations SET image = '/images/location-conchali.webp' WHERE slug = 'conchali' AND image IS NULL;
UPDATE locations SET image = '/images/location-renca.webp' WHERE slug = 'renca' AND image IS NULL;
UPDATE locations SET image = '/images/location-lampa.webp' WHERE slug = 'lampa' AND image IS NULL;
UPDATE locations SET image = '/images/location-la-pintana.webp' WHERE slug = 'la-pintana' AND image IS NULL;
UPDATE locations SET image = '/images/location-los-andes.webp' WHERE slug = 'los-andes' AND image IS NULL;
UPDATE locations SET image = '/images/location-san-felipe.webp' WHERE slug = 'san-felipe' AND image IS NULL;
