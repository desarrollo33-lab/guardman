-- GuardMan Admin — Fase 4: Asignación + Responsive Images
-- Migración D1

ALTER TABLE services ADD COLUMN hero_image_mobile TEXT;
ALTER TABLE services ADD COLUMN hero_image_tablet TEXT;
ALTER TABLE sectors ADD COLUMN hero_image_mobile TEXT;
ALTER TABLE sectors ADD COLUMN hero_image_tablet TEXT;
ALTER TABLE locations ADD COLUMN hero_image_mobile TEXT;
ALTER TABLE locations ADD COLUMN hero_image_tablet TEXT;
