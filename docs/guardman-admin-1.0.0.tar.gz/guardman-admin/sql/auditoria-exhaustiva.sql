-- Búsqueda exhaustiva de CUALQUIER término técnico relacionado con presencia en línea
-- Genera una lista de TODAS las coincidencias para corregir

SELECT id, 'question_es' AS campo, question_es AS texto
FROM ceo_questionnaire_questions
WHERE LOWER(question_es) LIKE '% seo %'
   OR LOWER(question_es) LIKE '%seo %' OR LOWER(question_es) LIKE '%seo%'
   OR LOWER(question_es) LIKE '%google%' OR LOWER(question_es) LIKE '%google %'
   OR LOWER(question_es) LIKE '%buscador%' OR LOWER(question_es) LIKE '%buscar en%'
   OR LOWER(question_es) LIKE '%posicionamiento%' OR LOWER(question_es) LIKE '%posicionar%'
   OR LOWER(question_es) LIKE '%marketing%'
   OR LOWER(question_es) LIKE '%keyword%'
   OR LOWER(question_es) LIKE '%sitio web%' OR LOWER(question_es) LIKE '%página web%'
   OR LOWER(question_es) LIKE '%landing%' OR LOWER(question_es) LIKE '%hero%'
   OR LOWER(question_es) LIKE '%anuncio%' OR LOWER(question_es) LIKE '%digital%'
   OR LOWER(question_es) LIKE '%online%' OR LOWER(question_es) LIKE '%app %'
   OR LOWER(question_es) LIKE '%internet%' OR LOWER(question_es) LIKE '%web %'
   OR LOWER(question_es) LIKE '%redes sociales%' OR LOWER(question_es) LIKE '%facebook%'
   OR LOWER(question_es) LIKE '%instagram%' OR LOWER(question_es) LIKE '%linkedin%'
   OR LOWER(question_es) LIKE '%whatsapp%' OR LOWER(question_es) LIKE '%correo%'
   OR LOWER(question_es) LIKE '%email%' OR LOWER(question_es) LIKE '%newsletter%'
   OR LOWER(question_es) LIKE '%blog%' OR LOWER(question_es) LIKE '%link%'
   OR LOWER(question_es) LIKE '%url%' OR LOWER(question_es) LIKE '%click%'
   OR LOWER(question_es) LIKE '%ranking%';

SELECT id, 'subtitle_es' AS campo, subtitle_es AS texto
FROM ceo_questionnaire_questions
WHERE LOWER(subtitle_es) LIKE '% seo %'
   OR LOWER(subtitle_es) LIKE '%seo %' OR LOWER(subtitle_es) LIKE '%seo%'
   OR LOWER(subtitle_es) LIKE '%google%' OR LOWER(subtitle_es) LIKE '%google %'
   OR LOWER(subtitle_es) LIKE '%buscador%' OR LOWER(subtitle_es) LIKE '%buscar en%'
   OR LOWER(subtitle_es) LIKE '%posicionamiento%' OR LOWER(subtitle_es) LIKE '%posicionar%'
   OR LOWER(subtitle_es) LIKE '%marketing%'
   OR LOWER(subtitle_es) LIKE '%keyword%'
   OR LOWER(subtitle_es) LIKE '%sitio web%' OR LOWER(subtitle_es) LIKE '%página web%'
   OR LOWER(subtitle_es) LIKE '%landing%' OR LOWER(subtitle_es) LIKE '%hero%'
   OR LOWER(subtitle_es) LIKE '%anuncio%' OR LOWER(subtitle_es) LIKE '%digital%'
   OR LOWER(subtitle_es) LIKE '%online%' OR LOWER(subtitle_es) LIKE '%app %'
   OR LOWER(subtitle_es) LIKE '%internet%' OR LOWER(subtitle_es) LIKE '%web %'
   OR LOWER(subtitle_es) LIKE '%redes sociales%' OR LOWER(subtitle_es) LIKE '%facebook%'
   OR LOWER(subtitle_es) LIKE '%instagram%' OR LOWER(subtitle_es) LIKE '%linkedin%'
   OR LOWER(subtitle_es) LIKE '%whatsapp%' OR LOWER(subtitle_es) LIKE '%correo%'
   OR LOWER(subtitle_es) LIKE '%email%' OR LOWER(subtitle_es) LIKE '%newsletter%'
   OR LOWER(subtitle_es) LIKE '%blog%' OR LOWER(subtitle_es) LIKE '%link%'
   OR LOWER(subtitle_es) LIKE '%url%' OR LOWER(subtitle_es) LIKE '%click%'
   OR LOWER(subtitle_es) LIKE '%ranking%';

SELECT id, 'objective_es' AS campo, objective_es AS texto
FROM ceo_questionnaire_questions
WHERE LOWER(objective_es) LIKE '% seo %'
   OR LOWER(objective_es) LIKE '%seo %' OR LOWER(objective_es) LIKE '%seo%'
   OR LOWER(objective_es) LIKE '%google%' OR LOWER(objective_es) LIKE '%google %'
   OR LOWER(objective_es) LIKE '%buscador%' OR LOWER(objective_es) LIKE '%buscar en%'
   OR LOWER(objective_es) LIKE '%posicionamiento%' OR LOWER(objective_es) LIKE '%posicionar%'
   OR LOWER(objective_es) LIKE '%marketing%'
   OR LOWER(objective_es) LIKE '%keyword%'
   OR LOWER(objective_es) LIKE '%sitio web%' OR LOWER(objective_es) LIKE '%página web%'
   OR LOWER(objective_es) LIKE '%landing%' OR LOWER(objective_es) LIKE '%hero%'
   OR LOWER(objective_es) LIKE '%anuncio%' OR LOWER(objective_es) LIKE '%digital%'
   OR LOWER(objective_es) LIKE '%online%' OR LOWER(objective_es) LIKE '%app %'
   OR LOWER(objective_es) LIKE '%internet%' OR LOWER(objective_es) LIKE '%web %'
   OR LOWER(objective_es) LIKE '%redes sociales%' OR LOWER(objective_es) LIKE '%facebook%'
   OR LOWER(objective_es) LIKE '%instagram%' OR LOWER(objective_es) LIKE '%linkedin%'
   OR LOWER(objective_es) LIKE '%whatsapp%' OR LOWER(objective_es) LIKE '%correo%'
   OR LOWER(objective_es) LIKE '%email%' OR LOWER(objective_es) LIKE '%newsletter%'
   OR LOWER(objective_es) LIKE '%blog%' OR LOWER(objective_es) LIKE '%link%'
   OR LOWER(objective_es) LIKE '%url%' OR LOWER(objective_es) LIKE '%click%'
   OR LOWER(objective_es) LIKE '%ranking%';
