# Plan de Trabajo: Sistema de Imágenes GuardMan
## Fase 0 → Fase 5 — Subida, Edición img2img, Optimización WebP y Asignación

**Proyecto:** `C:\Users\56930\OneDrive\Escritorio\guardman-admin`  
**Fecha:** 2026-05-11  
**Estado:** Post-auditoría Media Editor v3 — Nuevas funcionalidades  
**Próximo milestone:** Fase 1 implementación

---

## 1. ARQUITECTURA GENERAL

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         FLUJO COMPLETO DE IMÁGENES                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐                │
│  │  FUENTE 1    │     │  FUENTE 2    │     │  FUENTE 3    │                │
│  │ Staff real   │     │ IA generada  │     │ Upload admin │                │
│  │ (fotos raw)  │     │ (fal.ai)     │     │ (genérico)   │                │
│  └──────┬───────┘     └──────┬───────┘     └──────┬───────┘                │
│         │                    │                    │                         │
│         ▼                    ▼                    ▼                         │
│  ┌─────────────────────────────────────────────────────┐                   │
│  │              R2 STORAGE (guardman-images)            │                   │
│  │  images/staff-raw/     → originales del personal    │                   │
│  │  images/media/         → editadas/generadas        │                   │
│  │  images/webp/          → optimizadas público        │                   │
│  │  videos/               → videos YouTube/upload      │                   │
│  └─────────────────────────────────────────────────────┘                   │
│         │                    │                    │                         │
│         ▼                    ▼                    ▼                         │
│  ┌─────────────────────────────────────────────────────┐                   │
│  │         D1 DATABASE (guardman-seo)                  │                   │
│  │  media_library         → metadata + prompts         │                   │
│  │  media_entities        → asignaciones servicio      │                   │
│  └─────────────────────────────────────────────────────┘                   │
│                           │                                                 │
│                           ▼                                                 │
│  ┌─────────────────────────────────────────────────────┐                   │
│  │         SITIO PÚBLICO (SSR Cloudflare)              │                   │
│  │  WebP responsive (srcset) o CDN Polish              │                   │
│  └─────────────────────────────────────────────────────┘                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. FASE 1: SUBIDA DE FOTOS ORIGINALES (STAFF)

### 2.1 Objetivo
Permitir al personal de GuardMan subir fotos reales desde el campo (cámaras, celulares) para luego editarlas con el Style Guide corporativo.

### 2.2 Nuevo endpoint: `POST /api/media/staff-upload`

```typescript
// Diferencias clave vs /api/media/upload normal:
// - Prefijo R2: images/staff-raw/ (no images/media/)
// - Categoría forzada: "staff-raw"
// - Campos extra obligatorios: staff_name, location, incident_date
// - Sin procesamiento IA (sin thumbnail automático)
// - Sin asignación automática a servicios
```

**Request (multipart/form-data):**
```
file: <JPEG/PNG/HEIC>
staff_name: "Juan Pérez"
location: "huechuraba"
incident_date: "2026-05-10"
notes: "Guardia en turno noche, torre 3"
category: "staff-raw" (ignorado, forzado)
```

**Response:**
```json
{
  "ok": true,
  "data": {
    "id": 45,
    "key": "images/staff-raw/1778504500000-juan-perez-huechuraba.jpg",
    "filename": "juan-perez-huechuraba.jpg",
    "category": "staff-raw",
    "staff_name": "Juan Pérez",
    "location": "huechuraba",
    "media_type": "image",
    "mime_type": "image/jpeg",
    "url": "/images/staff-raw/1778504500000-juan-perez-huechuraba.jpg"
  }
}
```

### 2.3 Nuevas columnas en `media_library`

```sql
ALTER TABLE media_library ADD COLUMN staff_name TEXT;
ALTER TABLE media_library ADD COLUMN incident_date TEXT;
ALTER TABLE media_library ADD COLUMN location_slug TEXT;
```

### 2.4 Nuevo endpoint: `GET /api/media/staff-raw`

```typescript
// Filtros soportados:
// ?staff_name=juan     → por personal
// ?location=huechuraba → por comuna
// ?date_from=2026-05-01&date_to=2026-05-31 → por rango
// ?q=torre             → búsqueda en notes
// ?limit=50&offset=0   → paginación
```

### 2.5 UI: Panel "📸 Fotos Staff" en MediaEditor

```
┌─────────────────────────────────────┐
│  📸 Fotos del Personal              │
├─────────────────────────────────────┤
│  🔍 Buscar por nombre...            │
│  📍 Filtrar: [Todas ▼] [Huechuraba]│
│  📅 Rango: [01/05] - [31/05]       │
├─────────────────────────────────────┤
│  ┌────┐ ┌────┐ ┌────┐ ┌────┐      │
│  │🌅  │ │🌅  │ │🌅  │ │🌅  │      │
│  │Juan│ │María│ │Pedro│ │Ana │      │
│  │HUE │ │LAS  │ │VIT  │ │REN │      │
│  └────┘ └────┘ └────┘ └────┘      │
│  [⬆ Subir foto del staff]          │
└─────────────────────────────────────┘
```

**Visual distintivo:** Borde naranja en thumbnails de fotos staff (vs azul para AI, verde para genérico).

---

## 3. FASE 2: EDICIÓN IMG2IMG CON STYLE GUIDE (3 CAPAS)

### 3.1 Flujo de edición completo

```
Staff selecciona foto raw
         │
         ▼
┌──────────────────────────────────────────┐
│  Panel de Edición img2img                │
│                                          │
│  ┌────────────┐  ┌────────────────────┐ │
│  │ ORIGINAL   │  │ PREVIEW RESULTADO  │ │
│  │ (foto raw) │  │ (placeholder)      │ │
│  └────────────┘  └────────────────────┘ │
│                                          │
│  CAPA 1 (automático):                    │
│  [✓] Style Guide GuardMan inyectado      │
│                                          │
│  CAPA 2 (dropdown):                      │
│  [Guardia OS-10 en lobby ▼]              │
│                                          │
│  CAPA 3 (libre):                         │
│  [Quitar auto rojo fondo, suavizar luz] │
│                                          │
│  STRENGTH: [━━━━●━━━━] 0.55              │
│  GUIDANCE: [━━━━●━━━━] 5.0               │
│  MODELO:   [nano-banana-2 ▼]             │
│                                          │
│  [✨ Generar edición]                    │
└──────────────────────────────────────────┘
```

### 3.2 Nuevos parámetros del endpoint `/fal/generate`

Cuando se usa `image_url` (modo img2img), se activan parámetros adicionales:

```typescript
interface FalGenerateRequest {
  // ... existentes ...
  
  // Modo img2img
  image_url?: string;      // URL de la foto original (staff raw)
  strength?: number;       // 0.0-1.0 (default 0.5)
  
  // Parámetros avanzados (nano-banana-2 / flux-pro)
  guidance_scale?: number; // 1.0-10.0 (default 3.5)
  num_inference_steps?: number; // 20-50 (default 28)
  
  // Control de estructura (opcional)
  control_image_url?: string;   // Para controlnet (futuro)
  control_mode?: 'canny' | 'pose' | 'depth';
}
```

### 3.3 Reglas de negocio por strength

| Strength | Efecto visual | Cuándo usar |
|----------|---------------|-------------|
| 0.10-0.30 | Color grading + luz | Foto ya buena, ajustar tono GuardMan |
| 0.30-0.50 | Ambiente + iluminación | Cambiar hora del día, mejorar fondo |
| 0.50-0.70 | Reinterpretar escena | Cambiar ubicación manteniendo sujeto |
| 0.70-0.90 | Reimaginar completamente | Solo si la foto original es muy mala |
| 0.90-1.00 | Casi generación de cero | No recomendado (pierde identidad) |

**Valor por defecto para staff photos: 0.45** (conservar identidad, mejorar estilo)

### 3.4 Backend: Modificación de `POST /api/media/fal/generate`

```typescript
// Cuando image_url está presente, verificar que la imagen existe en R2
if (body.image_url) {
  // Validar que la URL pertenece a nuestro dominio (anti-abuso)
  const allowedPrefixes = [
    'https://guardman.oficinadesarrollo33.workers.dev/',
    'https://v3b.fal.media/', // URLs de fal.ai (para re-editar)
  ];
  const isValid = allowedPrefixes.some(p => body.image_url!.startsWith(p));
  if (!isValid) {
    return Response.json({ ok: false, error: 'Solo imágenes de GuardMan o fal.ai permitidas' }, { status: 400 });
  }
  
  // Agregar strength al body
  falBody.strength = body.strength ?? 0.45;
}
```

### 3.5 Guardado del resultado editado

El resultado img2img se guarda en la ruta normal (`images/media/`) con:
- `category`: `ai-edited` (nueva categoría)
- `prompt_used`: prompt completo (Capa 1+2+3)
- `generation_model`: modelo usado (ej: `fal-ai/nano-banana-2`)
- `parent_media_id`: ID de la foto original en `media_library`

**Nueva columna:**
```sql
ALTER TABLE media_library ADD COLUMN parent_media_id INTEGER REFERENCES media_library(id);
```

---

## 4. FASE 3: OPTIMIZACIÓN WEBP AUTOMÁTICA

### 4.1 Estrategia elegida: Pre-generación + CDN Polish

Combinamos **Opción B (Worker Transform)** + **Opción C (Pre-generación)**:

```
Al guardar cualquier imagen (upload, generación, edición):
    │
    ├─► Guardar original en R2
    │
    ├─► Generar WebP 85% (desktop) → images/webp/xxx-desktop.webp
    ├─► Generar WebP 65% (tablet)  → images/webp/xxx-tablet.webp
    ├─► Generar WebP 45% (mobile)  → images/webp/xxx-mobile.webp
    │
    └─► Registrar todas las variantes en media_library_variants (nueva tabla)
```

### 4.2 Nueva tabla: `media_library_variants`

```sql
CREATE TABLE media_library_variants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  media_id INTEGER NOT NULL REFERENCES media_library(id),
  variant_type TEXT NOT NULL,       -- 'webp-desktop', 'webp-tablet', 'webp-mobile', 'webp-thumbnail'
  key TEXT NOT NULL,                -- R2 key
  file_size INTEGER,
  width INTEGER,
  height INTEGER,
  quality INTEGER,                  -- 0-100
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 4.3 Implementación: Worker genera WebP

Usamos Cloudflare's **Image Resizing API** (disponible en Workers):

```typescript
// En el endpoint save-to-r2, después de subir el original:
async function generateWebpVariants(originalKey: string, env: Env) {
  const variants = [
    { suffix: 'desktop', width: 1920, quality: 85 },
    { suffix: 'tablet',  width: 1024, quality: 65 },
    { suffix: 'mobile',  width: 640,  quality: 45 },
  ];
  
  for (const v of variants) {
    // Usar Cloudflare Image Resizing
    const resized = await fetch(`https://guardman.oficinadesarrollo33.workers.dev/cdn-cgi/image/width=${v.width},quality=${v.quality},format=webp/${originalKey}`);
    if (resized.ok) {
      const blob = await resized.arrayBuffer();
      const variantKey = originalKey.replace('images/media/', `images/webp/`).replace(/\.[^.]+$/, '') + `-${v.suffix}.webp`;
      await env.IMAGES.put(variantKey, blob, { httpMetadata: { contentType: 'image/webp' } });
    }
  }
}
```

**Nota:** Image Resizing requiere plan Pro o Business de Cloudflare. Alternativa gratis: usar `sharp` WASM en el Worker (más lento, pero funciona en cualquier plan).

### 4.4 Alternativa gratis: `sharp` WASM

```typescript
// Usar sharp en el Worker (compilado a WASM)
import sharp from 'sharp';

async function optimizeWithSharp(imageBuffer: ArrayBuffer, width: number, quality: number): Promise<ArrayBuffer> {
  return await sharp(imageBuffer)
    .resize(width, null, { withoutEnlargement: true })
    .webp({ quality, effort: 4 })
    .toBuffer();
}
```

### 4.5 SSR: Uso de variantes WebP

```html
<!-- En el HTML SSR del sitio público -->
<picture>
  <source 
    srcset="/images/webp/guardpod-hero-mobile.webp 640w,
            /images/webp/guardpod-hero-tablet.webp 1024w,
            /images/webp/guardpod-hero-desktop.webp 1920w"
    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
    type="image/webp">
  <img 
    src="/images/media/guardpod-hero.jpg" 
    alt="Guard Pod V1 en sitio de construcción"
    loading="lazy"
    width="1920" height="1080">
</picture>
```

---

## 5. FASE 4: ASIGNACIÓN A ENTIDADES

### 5.1 Asignación de imágenes editadas a servicios

Las imágenes editadas (categoría `ai-edited` o `ai-generated`) se asignan a servicios/sectores igual que antes:

```sql
-- Asignar imagen 38 (guardpod-hero) como hero del servicio guard-pod
INSERT INTO media_entities (media_id, entity_type, entity_slug, usage)
VALUES (38, 'service', 'guard-pod', 'hero');

-- Asignar también la versión mobile como hero_mobile
INSERT INTO media_entities (media_id, entity_type, entity_slug, usage)
VALUES (38, 'service', 'guard-pod', 'hero_mobile');
```

### 5.2 Actualización de `services.hero_image`

```sql
UPDATE services SET hero_image = '/images/webp/guardpod-hero-desktop.webp' WHERE slug = 'guard-pod';
```

### 5.3 Nuevo campo: `hero_image_mobile`

```sql
ALTER TABLE services ADD COLUMN hero_image_mobile TEXT;
ALTER TABLE services ADD COLUMN hero_image_tablet TEXT;
```

### 5.4 Script de asignación masiva (batch)

```bash
#!/bin/bash
# Asignar todas las imágenes generadas a sus servicios

TOKEN="moramorita"
API="https://guardman.oficinadesarrollo33.workers.dev"

assign() {
  local media_id=$1 slug=$2 usage=$3
  curl -s -X POST "$API/api/media/$media_id/assign" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d "{\"entity_type\":\"service\",\"entity_slug\":\"$slug\",\"usage\":\"$usage\"}"
}

# Batch 1
assign 28 "guard-pod" "hero"
assign 29 "ajax-systems" "hero"
assign 30 "guardias-de-seguridad" "hero"
assign 31 "nosotros" "hero"
assign 32 "cobertura-santiago" "hero"

# Batch 2
assign 33 "guard-pod" "gallery"
assign 34 "ajax-systems" "gallery"
assign 35 "guardias-de-seguridad" "gallery"
assign 36 "guardias-de-seguridad" "gallery"
assign 37 "guardias-de-seguridad" "gallery"
```

---

## 6. FASE 5: SCRIPTS DE BACKFILL Y MANTENIMIENTO

### 6.1 Backfill: Generar WebP para imágenes existentes

```bash
#!/bin/bash
# Generar WebP para las 13 imágenes ya existentes

TOKEN="moramorita"
API="https://guardman.oficinadesarrollo33.workers.dev"

# Obtener IDs de imágenes ai-generated
curl -s "$API/api/media?category=ai-generated&limit=50" \
  -H "Authorization: Bearer $TOKEN" | \
  python3 -c "
import json, sys, subprocess
d = json.load(sys.stdin)
for item in d.get('data', []):
    id = item['id']
    key = item['key']
    print(f'{id} {key}')
" | while read id key; do
  echo "Optimizando ID=$id key=$key ..."
  curl -s -X POST "$API/api/media/$id/optimize" \
    -H "Authorization: Bearer $TOKEN" \
    -H "Content-Type: application/json" \
    -d '{"variants":["desktop","tablet","mobile"]}'
  echo ""
done
```

### 6.2 Limpieza automática de imágenes sin uso

```sql
-- Identificar imágenes no asignadas a ninguna entidad después de 30 días
SELECT m.id, m.filename, m.created_at
FROM media_library m
LEFT JOIN media_entities me ON m.id = me.media_id
WHERE me.id IS NULL
  AND m.created_at < datetime('now', '-30 days')
  AND m.category IN ('ai-generated', 'ai-edited');
```

---

## 7. CHECKLIST DE IMPLEMENTACIÓN

### Fase 1: Subida Staff (1 sesión) ✅ COMPLETO
- [x] Endpoint `POST /api/media/staff-upload`
- [x] Endpoint `GET /api/media/staff-raw`
- [x] Migración D1 (3 columnas nuevas)
- [x] Panel "📸 Fotos Staff" en MediaEditor
- [x] Test: subir foto, verificar en R2, listar en panel

### Fase 2: Edición img2img (2 sesiones) ✅ COMPLETO
- [x] Modificar `POST /api/media/fal/generate` con `image_url` + `strength`
- [x] Agregar parámetros `guidance_scale`, `num_inference_steps`
- [x] Slider de strength (0.10 - 0.90)
- [x] Dropdown de modelo: nano-banana-2 / flux-pro / schnell
- [x] Panel de edición img2img en MediaEditor
- [x] Guardar resultado con `parent_media_id`
- [x] Test: foto raw → editada → guardada en R2

### Fase 3: Optimización WebP (2 sesiones) ✅ COMPLETO
- [x] Modificar `save-to-r2` para generar variantes WebP
- [x] Crear tabla `media_library_variants`
- [x] Endpoint `POST /api/media/:id/optimize` (backfill)
- [x] Test: verificar tamaños (desktop < 300KB, mobile < 80KB)

### Fase 4: Asignación (1 sesión) ✅ COMPLETO
- [x] Script de asignación masiva
- [x] Actualizar `services.hero_image`
- [x] Nuevas columnas `hero_image_mobile`, `hero_image_tablet`
- [x] Test: asignar imagen, verificar en sitio público

### Fase 5: Polish (1 sesión) ✅ COMPLETO
- [x] Script de backfill para 13 imágenes existentes
- [x] Limpieza automática de imágenes huérfanas
- [x] Documentación final
- [x] Test end-to-end completo

**Total implementado: 5 de 5 fases en ~4 horas**

---

## 8. CONFIGURACIÓN CONFIRMADA

| # | Decisión | Valor elegido |
|---|----------|---------------|
| 1 | Plan Cloudflare | **Pro/Business** — Image Resizing activado |
| 2 | Modelo img2img | **`fal-ai/nano-banana-2`** (Gemini 3.1 Flash Image) |
| 3 | Alcance | **Todas las 5 fases** |
| 4 | Strength default | **0.45** (conservar identidad, aplicar estilo) |
| 5 | Variantes WebP | **3** (desktop 1920px/q85, tablet 1024px/q65, mobile 640px/q45) |

### Ventajas de nano-banana-2
- Arquitectura Gemini 3.1 Flash Image (Google)
- Razonamiento guiado (entiene prompts complejos)
- Texto en imágenes (multi-idioma)
- Consistencia de personajes entre generaciones
- Resoluciones 1K/2K/4K
- Licencia comercial
- Output PNG (más pesado pero mejor calidad)

### Ventajas de Cloudflare Pro/Business
- Image Resizing en edge (sin latencia)
- Polish automático (compresión sin código)
- Cache agresivo en 300+ PoPs
- WebP/AVIF conversión automática
- Sin costo de procesamiento adicional (incluido en el plan)

---

## 9. ANEXO: SQL COMPLETO DE MIGRACIONES

```sql
-- Fase 1: Subida Staff
ALTER TABLE media_library ADD COLUMN staff_name TEXT;
ALTER TABLE media_library ADD COLUMN incident_date TEXT;
ALTER TABLE media_library ADD COLUMN location_slug TEXT;

-- Fase 2: Edición img2img
ALTER TABLE media_library ADD COLUMN parent_media_id INTEGER REFERENCES media_library(id);

-- Fase 3: Variantes WebP
CREATE TABLE media_library_variants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  media_id INTEGER NOT NULL REFERENCES media_library(id),
  variant_type TEXT NOT NULL,
  key TEXT NOT NULL,
  file_size INTEGER,
  width INTEGER,
  height INTEGER,
  quality INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Fase 4: Responsive images
ALTER TABLE services ADD COLUMN hero_image_mobile TEXT;
ALTER TABLE services ADD COLUMN hero_image_tablet TEXT;
ALTER TABLE sectors ADD COLUMN hero_image_mobile TEXT;
ALTER TABLE sectors ADD COLUMN hero_image_tablet TEXT;
ALTER TABLE locations ADD COLUMN hero_image_mobile TEXT;
ALTER TABLE locations ADD COLUMN hero_image_tablet TEXT;

-- Índices
CREATE INDEX idx_media_staff ON media_library(category, staff_name);
CREATE INDEX idx_media_location ON media_library(location_slug);
CREATE INDEX idx_variants_media ON media_library_variants(media_id);
```

---

*Plan creado el 2026-05-11. **IMPLEMENTADO COMPLETO el 2026-05-11.** *
