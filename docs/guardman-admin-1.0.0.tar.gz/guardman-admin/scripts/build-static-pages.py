import sys, os

BASE = r'C:\Users\56930\OneDrive\Escritorio\guardman-admin'
os.chdir(BASE)

def esc(s):
    return s.replace('\\', '\\\\').replace('`', '\\`').replace('$', '\\$')

for name in ['nosotros', 'guardpod', 'ajax']:
    file_path = f'src/ssr/{name}-content.txt'
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    cap = name.replace('-', '').capitalize()
    var_name = f'{cap.upper()}_HTML'
    out_path = f'src/ssr/{name}-html.ts'
    
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(f'export const {var_name} = `{esc(content)}`;\n')
    
    print(f'{out_path}: {len(content)} bytes')
