#!/usr/bin/env bash
# Batch: 5 imágenes GuardMan con Flux Schnell (respuesta inmediata)
set -e

TOKEN="moramorita"
API="https://guardman.oficinadesarrollo33.workers.dev"
AUTH="Authorization: Bearer $TOKEN"
MODEL="fal-ai/flux/schnell"

echo "========================================="
echo "  BATCH: 5 imágenes GuardMan"
echo "  Modelo: $MODEL"
echo "========================================="
echo ""

# ─── Prompts concisos (el system prompt se inyecta en el frontend, aquí vamos directo) ───
generate_and_save() {
  local label="$1" prompt="$2" neg="$3" size="$4" filename="$5"
  
  echo "🎨 Generando: $label ..."
  
  local gen_resp=$(curl -s -X POST "$API/api/media/fal/generate" \
    -H "$AUTH" -H "Content-Type: application/json" \
    -d @- <<EOF
{
  "prompt": "$prompt",
  "model": "$MODEL",
  "image_size": "$size",
  "num_images": 1,
  "negative_prompt": "$neg",
  "enable_safety_checker": true
}
EOF
)
  
  local ok=$(echo "$gen_resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('ok'))" 2>/dev/null)
  if [ "$ok" != "True" ]; then
    local err=$(echo "$gen_resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('error','unknown'))" 2>/dev/null)
    echo "   ❌ Error generando: $err"
    return 1
  fi
  
  local request_id=$(echo "$gen_resp" | python3 -c "import json,sys; print(json.load(sys.stdin)['request_id'])" 2>/dev/null)
  echo "   ✅ Generado: $request_id"
  
  echo "💾 Guardando en R2..."
  local save_resp=$(curl -s -X POST "$API/api/media/fal/save-to-r2" \
    -H "$AUTH" -H "Content-Type: application/json" \
    -d "{\"request_id\":\"$request_id\",\"image_index\":0,\"filename\":\"$filename\",\"category\":\"ai-generated\",\"alt_text\":\"$label\",\"tags\":[\"ai-generated\",\"fal-ai\",\"batch-test\"]}")
  
  local save_ok=$(echo "$save_resp" | python3 -c "import json,sys; print(json.load(sys.stdin).get('ok'))" 2>/dev/null)
  if [ "$save_ok" = "True" ]; then
    local url=$(echo "$save_resp" | python3 -c "import json,sys; print(json.load(sys.stdin)['data']['url'])" 2>/dev/null)
    echo "   ✅ Guardado: $url"
  else
    echo "   ❌ Error guardando: $save_resp"
    return 1
  fi
  echo ""
}

# 1. Guard Pod Hero (16:9)
generate_and_save \
  "Guard Pod V1 — Hero" \
  "Wide establishing shot of a Guard Pod V1 autonomous security tower deployed at a construction site entrance in Santiago Chile. White and navy blue tower with solar panels on top, PTZ camera dome, and 4G antenna. Modern, sleek, imposing presence. Late afternoon golden hour, clear blue sky, Andes mountains faintly visible. Clean environment, professional installation. Navy blue #1A2744 branding. Photorealistic, Canon EOS R5 quality." \
  "people, dark, rain, messy site, graffiti, cartoon, 3D render" \
  "landscape_16_9" \
  "guardpod-hero"

# 2. Ajax Hero (16:9)
generate_and_save \
  "Ajax Systems Hub — Hero" \
  "Close-up product photography of an Ajax Systems Hub 2 central alarm panel installed on a clean modern wall in a Santiago office. MotionCam detector, DoorProtect sensor, and KeyPad nearby. Clean white wall, subtle navy accent from GuardMan branding. Professional lighting, shallow depth of field. Photorealistic, Canon EOS R5, natural light." \
  "messy desk, visible cables, old building, dark room, people" \
  "landscape_16_9" \
  "ajax-hero"

# 3. Guardia OS-10 (4:3)
generate_and_save \
  "Guardia de Seguridad OS-10" \
  "Professional security guard in navy blue GuardMan uniform standing at the entrance lobby of a corporate office building in Santiago Chile. OS-10 certification badge visible on chest. Guard from 45-degree angle, looking toward entrance. Clean modern lobby, glass doors, corporate atmosphere. Natural diffuse daylight. Photorealistic, Canon EOS R5 quality." \
  "visible face details, weapons, military posture, dark, empty lobby" \
  "landscape_4_3" \
  "servicio-guardia"

# 4. Oficina GuardMan (16:9)
generate_and_save \
  "Oficina GuardMan — Fachada" \
  "Exterior wide shot of the GuardMan Chile office building in Providencia Santiago. Modern 3-story building with navy blue GuardMan signage. Professional landscaping around entrance. Clear blue sky, golden hour side lighting. OS-10 certification plaque visible. Photorealistic, Canon EOS R5, professional architecture photography." \
  "people visible faces, rain, dark, neighboring buildings prominent" \
  "landscape_16_9" \
  "nosotros-oficina"

# 5. Cobertura Santiago (4:3)
generate_and_save \
  "Santiago — Cobertura Urbana" \
  "Aerial-style wide view of a Santiago residential neighborhood with modern apartment buildings and tree-lined streets. Clear blue sky, distant Andes mountains on the eastern horizon. Professional urban photography style communicating comprehensive city coverage. Photorealistic, natural lighting." \
  "smog, night, identifiable addresses, people, text" \
  "landscape_4_3" \
  "cobertura-santiago"

echo "========================================="
echo "  ✅ BATCH COMPLETADO"
echo "========================================="
