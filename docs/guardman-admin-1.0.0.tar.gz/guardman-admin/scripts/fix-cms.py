import os
os.chdir(r'C:\Users\56930\OneDrive\Escritorio\guardman-admin')

with open('guardman-admin-ui/src/components/CMS/CMSPage.tsx', 'r', encoding='utf-8') as f:
    t = f.read()

# 1. Fix API_BASE
t = t.replace("guardman-admin-api.oficinadesarrollo33.workers.dev", "guardman.oficinadesarrollo33.workers.dev")

# 2. Add STATIC_PAGES constant after SECTOR_SLUGS
old_sectors = "const SECTOR_SLUGS = ['comercial', 'industrial', 'residencial', 'salud', 'educacion', 'eventos', 'construccion', 'automotriz', 'hoteleria'];"
new_const = """const SECTOR_SLUGS = ['comercial', 'industrial', 'residencial', 'salud', 'educacion', 'eventos', 'construccion', 'automotriz', 'hoteleria'];

const STATIC_PAGES = [
  { slug: 'homepage', name: 'Homepage' },
  { slug: 'nosotros', name: 'Nosotros' },
  { slug: 'guard-pod', name: 'Guard Pod' },
  { slug: 'ajax-systems', name: 'Ajax Systems' },
  { slug: 'contacto', name: 'Contacto' },
  { slug: 'cotizacion', name: 'Cotizaci\u00f3n' },
  { slug: 'privacidad', name: 'Privacidad' },
  { slug: 'terminos', name: 'T\u00e9rminos' },
];"""
t = t.replace(old_sectors, new_const)

# 3. Replace the Home button + static dropdown with a unified list
old_home_button = """            <button
              onClick={() => setContentType('home')}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                contentType === 'home' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              Home
            </button>
            {(['services', 'locations', 'sectors', 'combos', 'static'] as const).map(type => (
              <button key={type}
                onClick={() => { setContentType(type); setComboFilter(''); setHomeLoaded(false); }}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                  contentType === type ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                {type === 'static' ? 'P\u00e1ginas' : type} ({type === 'services' ? 9 : type === 'locations' ? 14 : type === 'sectors' ? 9 : type === 'combos' ? 126 : 7})
              </button>
            ))}"""

new_tabs = """            {(['services', 'locations', 'sectors', 'combos', 'static'] as const).map(type => (
              <button key={type}
                onClick={() => { setContentType(type); setComboFilter(''); setHomeLoaded(false); }}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                  contentType === type ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                {type === 'static' ? 'P\u00e1ginas' : type} ({type === 'services' ? 9 : type === 'locations' ? 14 : type === 'sectors' ? 9 : type === 'combos' ? 126 : 8})
              </button>
            ))}"""
t = t.replace(old_home_button, new_tabs)

# 4. Replace old homepage hint in sidebar with static pages list
old_home_hint = """          {contentType === 'home' ? (
            <div className="text-center text-gray-400 py-8">
              <div className="text-2xl mb-2">\ud83c\udfe0</div>
              <p className="text-sm">Homepage se edita directamente</p>
              <p className="text-xs mt-1">Selecciona Home arriba</p>
            </div>
          ) : loading ? ("""

new_static_list = """          {contentType === 'static' ? (
            STATIC_PAGES.map(page => (
              <div key={page.slug}
                onClick={() => {
                  if (page.slug === 'homepage') { setContentType('home'); setHomeLoaded(false); loadHomepage(); }
                  else { setSelectedItem({ slug: page.slug, type: 'static', name: page.name, score: 0, published: false }); loadStaticPage(page.slug); }
                }}
                className={`p-3 rounded-lg mb-1 cursor-pointer transition-colors ${
                  (page.slug === 'homepage' && contentType === 'home') || selectedItem?.slug === page.slug ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-750'
                }`}
              >
                <div className="font-medium text-sm">{page.name}</div>
                <div className="text-xs text-gray-400">{page.slug}</div>
              </div>
            ))
          ) : loading ? ("""
t = t.replace(old_home_hint, new_static_list)

# 5. Fix loadHomepage slug
t = t.replace("setSelectedItem({ slug: 'home', type: 'home', name: 'Homepage', score: 0, published: false });",
              "setSelectedItem({ slug: 'homepage', type: 'home', name: 'Homepage', score: 0, published: false });")

# 6. Fix loadHomepage API call
t = t.replace("const res = await fetch(`${API_BASE}/api/cms/homepage`);",
              "const res = await fetch(`${API_BASE}/api/cms/content?type=static_page&slug=homepage`);")

# 7. Fix saveHomepage
old_save = "body: JSON.stringify({ path: 'homepage.json', content })"
new_save = "body: JSON.stringify({ path: 'static/homepage.json', content: { hero_heading: content.content?.hero?.headline || content.content?.hero?.heading || '', hero_subheading: content.content?.hero?.subheadline || content.content?.hero?.subheading || '', hero_badge: content.content?.hero?.badge || '', hero_image: content.content?.hero?.background_image || '', meta_title: content.seo?.title || '', meta_description: content.seo?.description || '' } })"
t = t.replace(old_save, new_save)

with open('guardman-admin-ui/src/components/CMS/CMSPage.tsx', 'w', encoding='utf-8') as f:
    f.write(t)

print("All changes applied successfully")
