import re, os
os.chdir(r'C:\Users\56930\OneDrive\Escritorio\guardman-admin')

with open('src/ssr/site-renderer.ts', 'r', encoding='utf-8') as f:
    t = f.read()

# Update all static page builders to accept env param
replacements = {
    'export function buildAjaxPage(): string {':
        'export function buildAjaxPage(env?: any): string {\n  const d = (env as any)?._staticData;\n  const title = d?.meta_title || \'Ajax Systems — Instalador Oficial | GuardMan Chile\';\n  const desc = d?.meta_description || \'Instalador oficial Ajax Systems. Alarmas Grado 3 con tecnologia Jeweller.\';\n  const badge = d?.hero_badge || \'Instalador Oficial\';',
    'export function buildContactoPage(): string {':
        'export function buildContactoPage(env?: any): string {\n  const d = (env as any)?._staticData;\n  const title = d?.meta_title || \'Contacto — GuardMan Chile | Seguridad Privada en Santiago\';\n  const desc = d?.meta_description || \'Contacta a GuardMan Chile. Disponibles 24/7. Cotizacion sin compromiso.\';',
    'export function buildCotizacionPage(): string {':
        'export function buildCotizacionPage(env?: any): string {\n  const d = (env as any)?._staticData;\n  const title = d?.meta_title || \'Cotizar Seguridad — GuardMan Chile\';\n  const desc = d?.meta_description || \'Solicita tu cotizacion de seguridad privada sin compromiso.\';',
    'export function buildPrivacidadPage(): string {':
        'export function buildPrivacidadPage(env?: any): string {\n  const d = (env as any)?._staticData;\n  const title = d?.meta_title || \'Politica de Privacidad — GuardMan Chile\';\n  const desc = d?.meta_description || \'Politica de Privacidad de GuardMan Chile.\';',
    'export function buildTerminosPage(): string {':
        'export function buildTerminosPage(env?: any): string {\n  const d = (env as any)?._staticData;\n  const title = d?.meta_title || \'Terminos y Condiciones — GuardMan Chile\';\n  const desc = d?.meta_description || \'Terminos y Condiciones de GuardMan Chile.\';',
}

for old, new in replacements.items():
    t = t.replace(old, new)

# Replace hardcoded titles/descriptions with dynamic ones in template literals
t = t.replace(
    "<title>Ajax Systems — Instalador Oficial | GuardMan Chile</title>",
    "<title>${esc(title)}</title>"
)
t = t.replace(
    'Instalador oficial Ajax Systems. Alarmas Grado 3 con tecnologia Jeweller."',
    '${esc(desc)}"'
)
t = t.replace(
    "<title>Contacto — GuardMan Chile | Seguridad Privada en Santiago</title>",
    "<title>${esc(title)}</title>"
)
t = t.replace(
    'Contacta a GuardMan Chile. Disponibles 24/7. Cotizacion sin compromiso."',
    '${esc(desc)}"'
)
t = t.replace(
    "<title>Cotizar Seguridad — GuardMan Chile</title>",
    "<title>${esc(title)}</title>"
)
t = t.replace(
    'Solicita tu cotizacion de seguridad privada sin compromiso."',
    '${esc(desc)}"'
)
t = t.replace(
    "<title>Politica de Privacidad — GuardMan Chile</title>",
    "<title>${esc(title)}</title>"
)
t = t.replace(
    'Politica de Privacidad de GuardMan Chile."',
    '${esc(desc)}"'
)
t = t.replace(
    "<title>Terminos y Condiciones — GuardMan Chile</title>",
    "<title>${esc(title)}</title>"
)
t = t.replace(
    'Terminos y Condiciones de GuardMan Chile."',
    '${esc(desc)}"'
)

with open('src/ssr/site-renderer.ts', 'w', encoding='utf-8') as f:
    f.write(t)

print('All builders updated')
