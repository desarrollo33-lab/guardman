import { Octokit } from '@octokit/rest';
import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';

const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
if (!GITHUB_TOKEN) { console.error('ERROR: GITHUB_TOKEN env var required'); process.exit(1); }
const REPO_OWNER = 'desarrollo33-lab';
const REPO_NAME = 'guardman-site';
const BRANCH = 'main';

const octokit = new Octokit({ auth: GITHUB_TOKEN });

async function getFileSha(path) {
  try {
    const res = await octokit.repos.getContent({ owner: REPO_OWNER, repo: REPO_NAME, path, ref: BRANCH });
    if (res.data.sha) return res.data.sha;
  } catch {}
  return null;
}

async function uploadFile(path, content, message) {
  try {
    const sha = await getFileSha(path);
    await octokit.repos.createOrUpdateFileContents({
      owner: REPO_OWNER, repo: REPO_NAME, path, message, branch: BRANCH,
      content: Buffer.from(content).toString('base64'),
      sha: sha || undefined
    });
    return true;
  } catch (err) {
    console.log(`Error uploading ${path}: ${err.message}`);
    return false;
  }
}

async function main() {
  const baseDir = 'src/data/cms-new';
  let total = 0, success = 0;

  const types = ['services', 'locations', 'sectors'];
  for (const type of types) {
    const typePath = join(baseDir, type);
    try {
      for (const file of readdirSync(typePath).filter(f => f.endsWith('.json'))) {
        const content = readFileSync(join(typePath, file), 'utf-8');
        const path = `${type}/${file}`;
        total++;
        if (await uploadFile(path, content, `chore(cms): Sync ${path}`)) success++;
        else console.log(`  Failed: ${path}`);
      }
    } catch {}
  }

  // Combos
  const combosPath = join(baseDir, 'combos');
  try {
    for (const service of readdirSync(combosPath)) {
      const servicePath = join(combosPath, service);
      for (const file of readdirSync(servicePath).filter(f => f.endsWith('.json'))) {
        const content = readFileSync(join(servicePath, file), 'utf-8');
        const path = `combos/${service}/${file}`;
        total++;
        if (await uploadFile(path, content, `chore(cms): Sync ${path}`)) success++;
        else console.log(`  Failed: ${path}`);
      }
    }
  } catch {}

  console.log(`\nUploaded ${success}/${total} files to GitHub`);
}

main().catch(console.error);