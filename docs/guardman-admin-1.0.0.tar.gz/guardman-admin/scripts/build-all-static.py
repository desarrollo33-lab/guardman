import re, os

BASE_OD = r'C:/Users/56930/open-design/.od/projects/cf058157-57c0-47d5-8751-812c8d13c1a8'
BASE_OUT = r'C:/Users/56930/OneDrive/Escritorio/guardman-admin/src/ssr'

pages = {
    'contacto': 'contacto.html',
    'cotizacion': 'cotizacion.html',
    'privacidad': 'privacidad.html',
    'terminos': 'terminos.html'
}

for name, file in pages.items():
    path = os.path.join(BASE_OD, file)
    with open(path, 'r', encoding='utf-8') as f:
        html = f.read()
    
    # Extract inline style from head (if any)
    style_match = re.search(r'<style>(.*?)</style>', html, re.DOTALL)
    inline_style = style_match.group(1).strip() if style_match else ''
    
    # Extract body content (body may have attributes like data-od-id)
    body_match = re.search(r'<body[^>]*>(.*?)</body>', html, re.DOTALL)
    if not body_match:
        print(f'{name}: no body found')
        continue
    content = body_match.group(1)
    
    # Remove header, breadcrumb, footer, scripts
    content = re.sub(r'<header[\s\S]*?</header>', '', content)
    content = re.sub(r'<nav data-od-id="breadcrumb"[\s\S]*?</nav>', '', content)
    content = re.sub(r'<footer[\s\S]*?</footer>', '', content)
    content = re.sub(r'<script[\s\S]*?</script>', '', content)
    
    # Fix links: replace .html hrefs
    content = content.replace('href="index.html"', 'href="/"')
    content = content.replace('href="contacto.html"', 'href="/contacto"')
    content = content.replace('href="cotizacion.html"', 'href="/cotizacion"')
    content = content.replace('href="nosotros.html"', 'href="/nosotros"')
    content = content.replace('href="servicios.html"', 'href="/servicios"')
    content = content.replace('href="ubicaciones.html"', 'href="/ubicaciones"')
    content = content.strip()
    
    # Save raw content
    content_path = os.path.join(BASE_OUT, f'{name}-content.txt')
    with open(content_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    # Create TS module with template literal
    escaped = content.replace('\\', '\\\\').replace('`', '\\`').replace('$', '\\$')
    cap = name.upper()
    ts_path = os.path.join(BASE_OUT, f'{name}-html.ts')
    with open(ts_path, 'w', encoding='utf-8') as f:
        f.write(f'export const {cap}_HTML = `{escaped}`;\n')
    
    print(f'{name}: {len(content)} bytes -> {name}-html.ts')

print('Done')
