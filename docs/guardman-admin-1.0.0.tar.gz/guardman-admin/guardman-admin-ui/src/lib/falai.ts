// GuardMan Admin — fal.ai client (v3 simplificado)
// Ya no maneja API keys — el Worker proxy a fal.ai via /api/media/fal/*
// Soporta cancelación via AbortSignal + timeout

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

// Cleanup old localStorage key (ya no se usa)
if (typeof localStorage !== 'undefined') {
  try { localStorage.removeItem('gm_fal_key'); } catch {}
}

function authHeaders(): Record<string, string> {
  const token = typeof localStorage !== 'undefined' ? (localStorage.getItem('gm_token') || '') : '';
  return {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
}

export interface FalImageResult {
  url: string;
  width: number;
  height: number;
}

interface GenerateResponse {
  ok: boolean;
  request_id?: string;
  status?: string;
  images?: FalImageResult[];
  error?: string;
}

interface StatusResponse {
  ok: boolean;
  request_id?: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  images?: FalImageResult[];
  error?: string;
}

export interface GenerateParams {
  prompt: string;
  model: string;
  image_size?: string;
  num_images?: number;
  seed?: number;
  image_url?: string;
  strength?: number;
  negative_prompt?: string;
  enable_safety_checker?: boolean;
}

/**
 * Inicia generación asíncrona. Devuelve request_id inmediatamente.
 */
export async function generateAsync(params: GenerateParams): Promise<{ request_id: string; status: string }> {
  const res = await fetch(`${API_BASE}/api/media/fal/generate`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(params),
  });
  const data: GenerateResponse = await res.json();
  if (!data.ok) throw new Error(data.error || 'Generation failed');
  return { request_id: data.request_id!, status: data.status! };
}

/**
 * Consulta el estado de una generación.
 */
export async function pollStatus(requestId: string): Promise<StatusResponse> {
  const res = await fetch(`${API_BASE}/api/media/fal/status/${requestId}`, {
    headers: authHeaders(),
  });
  const data: StatusResponse = await res.json();
  if (!data.ok) throw new Error(data.error || 'Status check failed');
  return data;
}

/**
 * Poll hasta completar o fallar. Cancelable via AbortSignal.
 * @param signal - AbortSignal para cancelar (ej: al desmontar el componente)
 * @param intervalMs - intervalo entre polls (default 3000ms)
 * @param maxAttempts - máximo de intentos antes de timeout (default 40 = 120s)
 */
export async function waitForCompletion(
  requestId: string,
  signal?: AbortSignal,
  intervalMs = 3000,
  maxAttempts = 40
): Promise<FalImageResult[]> {
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

    const status = await pollStatus(requestId);

    if (status.status === 'completed' && status.images) return status.images;
    if (status.status === 'failed') throw new Error(status.error || 'Generation failed');

    // Esperar con abort support
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(resolve, intervalMs);
      if (signal) {
        const onAbort = () => { clearTimeout(timer); reject(new DOMException('Aborted', 'AbortError')); };
        signal.addEventListener('abort', onAbort, { once: true });
      }
    });
  }
  throw new Error('Generation timed out after ' + (maxAttempts * intervalMs / 1000) + 's');
}

/**
 * Generar y esperar (conveniencia). Cancelable via AbortSignal.
 */
export async function generateAndWait(
  params: GenerateParams,
  signal?: AbortSignal,
  pollIntervalMs = 3000
): Promise<FalImageResult[]> {
  const { request_id } = await generateAsync(params);
  return waitForCompletion(request_id, signal, pollIntervalMs);
}

/**
 * Guardar imagen generada en R2 (server-side download).
 * Si generateAsync usó num_images > 1, llamar esta función N veces con image_index 0..N-1.
 */
export async function saveToR2(params: {
  request_id: string;
  image_index?: number;
  filename: string;
  category?: string;
  alt_text?: string;
  tags?: string[];
  parent_media_id?: number;
}): Promise<{ id: number; key: string; url: string }> {
  const res = await fetch(`${API_BASE}/api/media/fal/save-to-r2`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(params),
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || 'Save failed');
  return data.data;
}

