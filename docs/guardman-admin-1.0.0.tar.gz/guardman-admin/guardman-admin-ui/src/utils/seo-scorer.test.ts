import { describe, it, expect } from 'vitest';
import { calculateSEOScore } from './seo-scorer';

describe('calculateSEOScore', () => {
  it('returns excellent for perfect content', () => {
    const result = calculateSEOScore({
      title: 'GuardMan Chile — Seguridad Privada y Monitoreo 24/7',
      description: 'GuardMan ofrece servicios de seguridad privada, guardias, CCTV, escoltas y monitoreo 24/7 en todo Chile. Tecnología Ajax Systems.',
      h1: 'Protección que va más allá de la presencia física',
      h2: ['Servicios', 'Tecnología', 'Clientes'],
      bodyText: 'Lorem ipsum '.repeat(200),
      images: [{ alt: 'hero image' }, { alt: 'guard pod' }],
      internalLinks: ['/nosotros', '/contacto', '/cotizacion'],
      keyword: 'GuardMan Chile',
    });
    expect(result.score).toBeGreaterThanOrEqual(90);
    expect(result.grade).toBe('excellent');
  });

  it('returns poor for empty content', () => {
    const result = calculateSEOScore({});
    expect(result.score).toBeLessThanOrEqual(30);
    expect(result.grade).toBe('poor');
  });

  it('detects missing H1', () => {
    const result = calculateSEOScore({
      title: 'Test Title for Length Testing Purposes Here',
      description: 'Test description that is long enough to be considered good for SEO purposes within the limits',
    });
    const h1Check = result.checks.find(c => c.name === 'H1 ausente');
    expect(h1Check).toBeDefined();
    expect(h1Check?.status).toBe('fail');
  });

  it('warns on short title', () => {
    const result = calculateSEOScore({ title: 'Short' });
    expect(result.score).toBeLessThan(50);
  });

  it('detects missing alt text', () => {
    const result = calculateSEOScore({
      title: 'Test Title for SEO Testing That Is Long Enough',
      description: 'Description long enough for testing purposes here yes',
      images: [{ alt: '' }, { alt: '' }],
    });
    const altCheck = result.checks.find(c => c.name === 'Alt text faltante');
    expect(altCheck).toBeDefined();
    expect(altCheck?.status).toBe('fail');
  });

  it('returns 100 for perfect score', () => {
    const result = calculateSEOScore({
      title: 'Perfect SEO Title Exactly Right Size Here',
      description: 'This description is perfectly sized for SEO purposes, between one hundred twenty and one hundred sixty characters total.',
      h1: 'Main Heading',
      h2: ['Section 1', 'Section 2', 'Section 3'],
      bodyText: 'word '.repeat(350),
      images: [{ alt: 'img1' }, { alt: 'img2' }],
      internalLinks: ['/a', '/b', '/c'],
      keyword: 'Perfect SEO Title',
    });
    expect(result.score).toBe(100);
    expect(result.grade).toBe('excellent');
    expect(result.checks.every(c => c.status === 'pass' || c.status === 'warn')).toBe(true);
  });

  it('calculates breakdown percentages', () => {
    const result = calculateSEOScore({
      title: 'Test Title for SEO Testing That Is Long Enough',
      description: 'Description long enough for testing purposes here yes',
    });
    expect(result.breakdown.content).toBeGreaterThanOrEqual(0);
    expect(result.breakdown.technical).toBeGreaterThanOrEqual(0);
    expect(result.breakdown.conversion).toBeGreaterThanOrEqual(0);
  });
});
