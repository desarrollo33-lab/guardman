// GuardMan Admin v13 — SEO Score Calculator
// Heuristic rules evaluated in real-time on the frontend
// No backend required.

export interface SEOCheck {
  name: string;
  status: 'pass' | 'fail' | 'warn';
  detail: string;
  points: number;
  maxPoints: number;
}

export interface SEOScoreResult {
  score: number;        // 0-100
  grade: 'excellent' | 'good' | 'fair' | 'poor';
  checks: SEOCheck[];
  breakdown: {
    content: number;    // percentage
    technical: number;  // percentage
    conversion: number; // percentage
  };
}

interface ContentData {
  title?: string;
  description?: string;
  h1?: string;
  h2?: string[];
  bodyText?: string;       // all text content combined
  images?: { alt?: string }[];
  internalLinks?: string[];
  keyword?: string;        // primary keyword
}

export function calculateSEOScore(data: ContentData): SEOScoreResult {
  const checks: SEOCheck[] = [];
  let totalPoints = 0;
  const maxPoints = 100;

  // 1. Title length (30-60 chars) — 15 pts
  const titleLen = (data.title || '').length;
  if (titleLen >= 30 && titleLen <= 60) {
    checks.push({ name: 'Title tag optimizado', status: 'pass', detail: `${titleLen}/60 caracteres`, points: 15, maxPoints: 15 });
    totalPoints += 15;
  } else if (titleLen > 0 && titleLen < 30) {
    checks.push({ name: 'Title tag muy corto', status: 'warn', detail: `${titleLen}/30 mínimo. Agrega más contexto.`, points: 7, maxPoints: 15 });
    totalPoints += 7;
  } else if (titleLen > 60) {
    checks.push({ name: 'Title tag muy largo', status: 'warn', detail: `${titleLen}/60 máximo. Reduce a <60.`, points: 7, maxPoints: 15 });
    totalPoints += 7;
  } else {
    checks.push({ name: 'Title tag ausente', status: 'fail', detail: 'Agrega un título SEO.', points: 0, maxPoints: 15 });
  }

  // 2. Description length (120-160 chars) — 15 pts
  const descLen = (data.description || '').length;
  if (descLen >= 120 && descLen <= 160) {
    checks.push({ name: 'Meta description optimizada', status: 'pass', detail: `${descLen}/160 caracteres`, points: 15, maxPoints: 15 });
    totalPoints += 15;
  } else if (descLen > 0 && descLen < 120) {
    checks.push({ name: 'Meta description corta', status: 'warn', detail: `${descLen}/120 mínimo`, points: 8, maxPoints: 15 });
    totalPoints += 8;
  } else if (descLen > 160) {
    checks.push({ name: 'Meta description larga', status: 'warn', detail: `${descLen}/160 máximo`, points: 8, maxPoints: 15 });
    totalPoints += 8;
  } else {
    checks.push({ name: 'Meta description ausente', status: 'fail', detail: 'Agrega una descripción.', points: 0, maxPoints: 15 });
  }

  // 3. H1 present (exactly one) — 15 pts
  const hasH1 = !!(data.h1 && data.h1.trim());
  if (hasH1) {
    checks.push({ name: 'H1 único presente', status: 'pass', detail: `"${data.h1!.substring(0, 40)}${data.h1!.length > 40 ? '...' : ''}"`, points: 15, maxPoints: 15 });
    totalPoints += 15;
  } else {
    checks.push({ name: 'H1 ausente', status: 'fail', detail: 'Cada página debe tener un H1.', points: 0, maxPoints: 15 });
  }

  // 4. H2-H3 structure (at least 2 H2s) — 10 pts
  const h2Count = (data.h2 || []).length;
  if (h2Count >= 2) {
    checks.push({ name: 'Estructura de headings', status: 'pass', detail: `${h2Count} H2s — buena jerarquía`, points: 10, maxPoints: 10 });
    totalPoints += 10;
  } else if (h2Count === 1) {
    checks.push({ name: 'Estructura de headings', status: 'warn', detail: 'Solo 1 H2. Recomendado ≥2.', points: 5, maxPoints: 10 });
    totalPoints += 5;
  } else {
    checks.push({ name: 'Estructura de headings', status: 'fail', detail: 'Sin H2. Agrega subtítulos.', points: 0, maxPoints: 10 });
  }

  // 5. Content length (> 300 words) — 15 pts
  const wordCount = (data.bodyText || '').split(/\s+/).filter(Boolean).length;
  if (wordCount >= 300) {
    checks.push({ name: 'Contenido sustancial', status: 'pass', detail: `${wordCount} palabras`, points: 15, maxPoints: 15 });
    totalPoints += 15;
  } else if (wordCount >= 150) {
    checks.push({ name: 'Contenido aceptable', status: 'warn', detail: `${wordCount}/300 palabras`, points: 10, maxPoints: 15 });
    totalPoints += 10;
  } else if (wordCount > 0) {
    checks.push({ name: 'Contenido insuficiente', status: 'fail', detail: `${wordCount}/300 palabras`, points: 3, maxPoints: 15 });
    totalPoints += 3;
  } else {
    checks.push({ name: 'Contenido vacío', status: 'fail', detail: 'Agrega contenido de texto.', points: 0, maxPoints: 15 });
  }

  // 6. Images with alt text (100% of images have alt) — 15 pts
  const images = data.images || [];
  const imagesWithAlt = images.filter(img => !!(img.alt && img.alt.trim()));
  if (images.length === 0) {
    checks.push({ name: 'Imágenes con alt text', status: 'warn', detail: 'No hay imágenes para verificar', points: 15, maxPoints: 15 });
    totalPoints += 15;
  } else if (imagesWithAlt.length === images.length) {
    checks.push({ name: 'Imágenes con alt text', status: 'pass', detail: `${images.length}/${images.length} con alt`, points: 15, maxPoints: 15 });
    totalPoints += 15;
  } else {
    const missing = images.length - imagesWithAlt.length;
    checks.push({ name: 'Alt text faltante', status: 'fail', detail: `${missing} de ${images.length} imágenes sin alt`, points: 5, maxPoints: 15 });
    totalPoints += 5;
  }

  // 7. Internal links (at least 1) — 10 pts
  const linkCount = (data.internalLinks || []).length;
  if (linkCount >= 3) {
    checks.push({ name: 'Links internos', status: 'pass', detail: `${linkCount} links internos`, points: 10, maxPoints: 10 });
    totalPoints += 10;
  } else if (linkCount >= 1) {
    checks.push({ name: 'Links internos', status: 'warn', detail: `${linkCount} link. Recomendado ≥3.`, points: 6, maxPoints: 10 });
    totalPoints += 6;
  } else {
    checks.push({ name: 'Links internos', status: 'fail', detail: 'Sin links internos.', points: 0, maxPoints: 10 });
  }

  // 8. Keyword in title — 5 pts
  const keyword = (data.keyword || '').toLowerCase();
  const title = (data.title || '').toLowerCase();
  if (keyword && title.includes(keyword)) {
    checks.push({ name: 'Keyword en título', status: 'pass', detail: `"${data.keyword}" en el título`, points: 5, maxPoints: 5 });
    totalPoints += 5;
  } else if (!keyword) {
    checks.push({ name: 'Keyword en título', status: 'warn', detail: 'Define una keyword principal', points: 5, maxPoints: 5 });
    totalPoints += 5;
  } else {
    checks.push({ name: 'Keyword en título', status: 'fail', detail: `"${data.keyword}" no está en el título`, points: 0, maxPoints: 5 });
  }

  // Calculate grade
  let grade: SEOScoreResult['grade'];
  if (totalPoints >= 90) grade = 'excellent';
  else if (totalPoints >= 80) grade = 'good';
  else if (totalPoints >= 60) grade = 'fair';
  else grade = 'poor';

  // Breakdown percentages
  const contentPass = checks.filter(c => ['Title tag optimizado', 'Title tag muy corto', 'Title tag muy largo', 'Title tag ausente', 'H1 único presente', 'H1 ausente', 'Estructura de headings', 'Contenido sustancial', 'Contenido aceptable', 'Contenido insuficiente', 'Contenido vacío', 'Keyword en título'].includes(c.name));
  const contentEarned = contentPass.reduce((s, c) => s + c.points, 0);
  const contentMax = contentPass.reduce((s, c) => s + c.maxPoints, 0);

  const techPass = checks.filter(c => ['Meta description optimizada', 'Meta description corta', 'Meta description larga', 'Meta description ausente', 'Imágenes con alt text', 'Alt text faltante'].includes(c.name));
  const techEarned = techPass.reduce((s, c) => s + c.points, 0);
  const techMax = techPass.reduce((s, c) => s + c.maxPoints, 0);

  const convPass = checks.filter(c => ['Links internos'].includes(c.name));
  const convEarned = convPass.reduce((s, c) => s + c.points, 0);
  const convMax = convPass.reduce((s, c) => s + c.maxPoints, 0);

  const breakdown = {
    content: contentMax > 0 ? Math.round((contentEarned / contentMax) * 100) : 0,
    technical: techMax > 0 ? Math.round((techEarned / techMax) * 100) : 0,
    conversion: convMax > 0 ? Math.round((convEarned / convMax) * 100) : 0,
  };

  return { score: totalPoints, grade, checks, breakdown };
}
