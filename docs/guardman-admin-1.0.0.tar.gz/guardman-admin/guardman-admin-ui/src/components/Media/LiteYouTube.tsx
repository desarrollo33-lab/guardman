// GuardMan Admin — LiteYouTube Embed
// Best practice for PageSpeed: shows thumbnail, loads iframe only on click.
// Saves ~800KB per video until user interaction.
// Pattern: https://web.dev/articles/embed-youtube-videos

interface LiteYouTubeProps {
  videoId: string;
  title?: string;
  poster?: 'hq' | 'mq' | 'sd' | 'maxres';
  className?: string;
  aspectRatio?: string; // e.g. 'aspect-video' (default)
}

export function LiteYouTube({ videoId, title, poster = 'hq', className = '', aspectRatio = 'aspect-video' }: LiteYouTubeProps) {
  // hqdefault.jpg is 480x360 and always available
  // maxresdefault.jpg is 1280x720 but not always available
  const thumbUrl = poster === 'maxres'
    ? `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
    : poster === 'sd'
      ? `https://img.youtube.com/vi/${videoId}/sddefault.jpg`
      : `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

  const embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    // Don't re-create if already activated
    if (container.querySelector('iframe')) return;

    const iframe = document.createElement('iframe');
    iframe.src = embedUrl;
    iframe.className = 'absolute inset-0 w-full h-full';
    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
    iframe.allowFullscreen = true;
    iframe.title = title || `YouTube video ${videoId}`;
    iframe.setAttribute('loading', 'lazy');
    // Remove thumbnail overlay, append iframe
    const overlay = container.querySelector('.yt-thumb-overlay') as HTMLElement;
    if (overlay) overlay.style.display = 'none';
    container.appendChild(iframe);
  };

  return (
    <div
      className={`relative ${aspectRatio} bg-black rounded overflow-hidden cursor-pointer group ${className}`}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && handleClick(e as any)}
      aria-label={title || `Reproducir video de YouTube ${videoId}`}
    >
      {/* Thumbnail */}
      <div className="yt-thumb-overlay absolute inset-0">
        <img
          src={thumbUrl}
          alt={title || ''}
          className="w-full h-full object-cover"
          loading="lazy"
          onError={(e) => {
            // Fallback to hqdefault if maxres not available
            if (poster === 'maxres') {
              (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
            }
          }}
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors" />
      </div>

      {/* Play button */}
      <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
        <div className="w-16 h-16 rounded-full bg-red-600/90 flex items-center justify-center shadow-lg group-hover:bg-red-600 group-hover:scale-110 transition-all">
          <svg className="w-7 h-7 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8 5v14l11-7z"/>
          </svg>
        </div>
      </div>

      {/* YouTube logo watermark */}
      <div className="absolute top-2 left-2 z-10 pointer-events-none">
        <span className="text-[9px] px-1.5 py-0.5 rounded bg-black/60 text-white/70 font-medium">YouTube</span>
      </div>
    </div>
  );
}
