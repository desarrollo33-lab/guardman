// GuardMan Admin — useMediaEditorReducer v4
// Estado global del editor con useReducer

import { useReducer } from 'react';

export interface MediaEditorState {
  activeTab: 'biblioteca' | 'staff' | 'generar' | 'batch';
  selectedId: number | null;
  searchQuery: string;
  filters: {
    category?: string;
    mediaType?: 'all' | 'image' | 'video';
    staffName?: string;
    location?: string;
    dateFrom?: string;
    dateTo?: string;
  };
  uploadModal: { open: boolean; mode: 'generic' | 'staff' };
  editModal: { open: boolean; mediaId: number | null; sourceUrl: string };
  lightbox: { open: boolean; url: string };
  aiState: {
    generating: boolean;
    requestId: string | null;
    model: string;
    strength: number;
    category: string;
    promptId: string;
    userPrompt: string;
    imageSize: string;
    numVariants: number;
    results: Array<{ url: string; width: number; height: number }>;
    error: string;
  };
}

export const initialMediaEditorState: MediaEditorState = {
  activeTab: 'biblioteca',
  selectedId: null,
  searchQuery: '',
  filters: { mediaType: 'all' },
  uploadModal: { open: false, mode: 'generic' },
  editModal: { open: false, mediaId: null, sourceUrl: '' },
  lightbox: { open: false, url: '' },
  aiState: {
    generating: false,
    requestId: null,
    model: 'fal-ai/nano-banana-2',
    strength: 0.45,
    category: '',
    promptId: '',
    userPrompt: '',
    imageSize: 'landscape_4_3',
    numVariants: 1,
    results: [],
    error: '',
  },
};

export type MediaEditorAction =
  | { type: 'SET_TAB'; tab: MediaEditorState['activeTab'] }
  | { type: 'SELECT_MEDIA'; id: number | null }
  | { type: 'SET_SEARCH'; query: string }
  | { type: 'SET_FILTER'; key: string; value: string | undefined }
  | { type: 'OPEN_UPLOAD'; mode: 'generic' | 'staff' }
  | { type: 'CLOSE_UPLOAD' }
  | { type: 'OPEN_EDIT'; mediaId: number; sourceUrl: string }
  | { type: 'CLOSE_EDIT' }
  | { type: 'OPEN_LIGHTBOX'; url: string }
  | { type: 'CLOSE_LIGHTBOX' }
  | { type: 'AI_START' }
  | { type: 'AI_SET_REQUEST_ID'; requestId: string }
  | { type: 'AI_SET_RESULTS'; results: MediaEditorState['aiState']['results'] }
  | { type: 'AI_SET_ERROR'; error: string }
  | { type: 'AI_SET_PARAM'; key: string; value: any }
  | { type: 'AI_RESET' }
  | { type: 'AI_CLEAR_RESULTS' };

export function mediaEditorReducer(state: MediaEditorState, action: MediaEditorAction): MediaEditorState {
  switch (action.type) {
    case 'SET_TAB':
      return { ...state, activeTab: action.tab, selectedId: null, aiState: { ...state.aiState, results: [], error: '' } };
    case 'SELECT_MEDIA':
      return { ...state, selectedId: action.id, aiState: { ...state.aiState, results: [], error: '' } };
    case 'SET_SEARCH':
      return { ...state, searchQuery: action.query };
    case 'SET_FILTER':
      return { ...state, filters: { ...state.filters, [action.key]: action.value } };
    case 'OPEN_UPLOAD':
      return { ...state, uploadModal: { open: true, mode: action.mode } };
    case 'CLOSE_UPLOAD':
      return { ...state, uploadModal: { open: false, mode: 'generic' } };
    case 'OPEN_EDIT':
      return { ...state, editModal: { open: true, mediaId: action.mediaId, sourceUrl: action.sourceUrl } };
    case 'CLOSE_EDIT':
      return { ...state, editModal: { open: false, mediaId: null, sourceUrl: '' }, aiState: { ...state.aiState, results: [], error: '' } };
    case 'OPEN_LIGHTBOX':
      return { ...state, lightbox: { open: true, url: action.url } };
    case 'CLOSE_LIGHTBOX':
      return { ...state, lightbox: { ...state.lightbox, open: false } };
    case 'AI_START':
      return { ...state, aiState: { ...state.aiState, generating: true, error: '', results: [] } };
    case 'AI_SET_REQUEST_ID':
      return { ...state, aiState: { ...state.aiState, requestId: action.requestId } };
    case 'AI_SET_RESULTS':
      return { ...state, aiState: { ...state.aiState, generating: false, results: action.results } };
    case 'AI_SET_ERROR':
      return { ...state, aiState: { ...state.aiState, generating: false, error: action.error } };
    case 'AI_SET_PARAM':
      return { ...state, aiState: { ...state.aiState, [action.key]: action.value } };
    case 'AI_RESET':
      return { ...state, aiState: { ...initialMediaEditorState.aiState } };
    case 'AI_CLEAR_RESULTS':
      return { ...state, aiState: { ...state.aiState, results: [], error: '' } };
    default:
      return state;
  }
}

export function useMediaEditorReducer() {
  return useReducer(mediaEditorReducer, initialMediaEditorState);
}
