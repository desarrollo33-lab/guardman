// GuardMan Admin — MediaWorkspace v4
// Panel derecho: preview + tabs (Info / SEO / AI)

import { useState, useEffect, useCallback } from 'react';
import { useApi } from '../../../hooks/useApi';
import { LiteYouTube } from '../LiteYouTube';
import { SeoEditor } from '../shared/SeoEditor';
import { AssignForm } from '../shared/AssignForm';
import { CompareSlider } from '../shared/CompareSlider';
import type { MediaItem } from '../shared/MediaCard';
import { imgUrl } from '../shared/MediaCard';

interface MediaWorkspaceProps {
  selectedId: number | null;
  onUpdate: () => void;
}

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

function fmt(b: number) { return b > 1024 * 1024 ? `${(b/1048576).toFixed(1)} MB` : b > 1024 ? `${(b/1024).toFixed(1)} KB` : `${b} B`; }
function parseTags(t: string): string[] { try { const p = JSON.parse(t); return Array.isArray(p) ? p : []; } catch { return []; } }
function tagsToJson(tags: string[]): string { return JSON.stringify(tags); }

function calcMediaScore(item: MediaItem): { score: number; checks: { label: string; ok: boolean; detail: string }[] } {
  const checks: { label: string; ok: boolean; detail: string }[] = [];
  let score = 0;
  const hasAlt = item.alt_text && item.alt_text.length > 10;
  const altQuality = hasAlt && !/^image|^img|^foto|\.(jpg|png|webp|mp4)/i.test(item.alt_text);
  if (altQuality) { score += 25; checks.push({ label: 'Alt text', ok: true, detail: `${item.alt_text.length} chars` }); }
  else if (hasAlt) { score += 10; checks.push({ label: 'Alt descriptivo', ok: false, detail: 'Muy genérico' }); }
  else checks.push({ label: 'Alt text', ok: false, detail: 'Sin alt text' });
  const hasTitle = item.title && item.title.length > 3;
  if (hasTitle) { score += 15; checks.push({ label: 'Title', ok: true, detail: '✓' }); }
  else checks.push({ label: 'Title', ok: false, detail: 'Sin title' });
  const hasCaption = item.caption && item.caption.length > 5;
  if (hasCaption) { score += 10; checks.push({ label: 'Caption', ok: true, detail: '✓' }); }
  else checks.push({ label: 'Caption', ok: false, detail: 'Sin caption' });
  const tags = parseTags(item.tags);
  if (tags.length >= 3) { score += 15; checks.push({ label: 'Tags', ok: true, detail: `${tags.length}` }); }
  else checks.push({ label: 'Tags', ok: false, detail: `${tags.length} (mín 3)` }); 
  const hasAsg = item.entities && item.entities.length > 0;
  if (hasAsg) { score += 15; checks.push({ label: 'Asignada', ok: true, detail: `${item.entities!.length} ent.` }); }
  else checks.push({ label: 'Asignada', ok: false, detail: 'No asignada' });
  if (item.mime_type === 'image/webp') { score += 20; checks.push({ label: 'WebP', ok: true, detail: '✓' }); }
  else { score += 10; checks.push({ label: 'WebP', ok: false, detail: item.mime_type || '?' }); }
  return { score: Math.min(100, score), checks };
}

export function MediaWorkspace({ selectedId, onUpdate }: MediaWorkspaceProps) {
  const { api } = useApi();
  const [item, setItem] = useState<MediaItem | null>(null);
  const [activeTab, setActiveTab] = useState<'info' | 'seo'>('info');
  const [editAlt, setEditAlt] = useState('');
  const [editTitle, setEditTitle] = useState('');
  const [editCaption, setEditCaption] = useState('');
  const [editTags, setEditTags] = useState<string[]>([]);
  const [seoSaving, setSeoSaving] = useState(false);

  useEffect(() => {
    if (!selectedId) { setItem(null); return; }
    api<MediaItem>(`/api/media/${selectedId}`).then(d => {
      setItem(d);
      setEditAlt(d.alt_text || '');
      setEditTitle(d.title || '');
      setEditCaption(d.caption || '');
      setEditTags(parseTags(d.tags));
    }).catch(() => {});
  }, [selectedId, api]);

  const handleSaveSeo = async () => {
    if (!item) return;
    setSeoSaving(true);
    try {
      await api(`/api/media/${item.id}`, { method: 'PUT', body: JSON.stringify({ alt_text: editAlt, title: editTitle, caption: editCaption, tags: tagsToJson(editTags) }) });
      onUpdate();
    } catch (err: any) { alert('Error: ' + err.message); }
    setSeoSaving(false);
  };

  const handleAssign = async (mediaId: number, entityType: string, entitySlug: string, usage: string) => {
    try { await api(`/api/media/${mediaId}/assign`, { method: 'POST', body: JSON.stringify({ entity_type: entityType, entity_slug: entitySlug, usage }) }); onUpdate(); } catch (err: any) { alert('Error: ' + err.message); }
  };

  const handleUnassign = async (mediaId: number, entityType: string, entitySlug: string, usage: string) => {
    try { await api(`/api/media/${mediaId}/unassign`, { method: 'POST', body: JSON.stringify({ entity_type: entityType, entity_slug: entitySlug, usage }) }); onUpdate(); } catch (err: any) { alert('Error: ' + err.message); }
  };

  const score = item ? calcMediaScore(item) : null;

  if (!item) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-400 p-6">
        <div className="text-center">
          <div className="text-4xl mb-3">📷</div>
          <p className="text-sm">Selecciona un medio para ver detalles</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Preview */}
      <div className="p-4 border-b border-gray-700 shrink-0">
        <div className="rounded-lg overflow-hidden bg-black/30 flex items-center justify-center" style={{ maxHeight: '320px' }}>
          {item.mime_type === 'video/youtube' && item.youtube_id ? (
            <LiteYouTube videoId={item.youtube_id} title={item.title || item.alt_text || 'YouTube'} className="max-h-[320px]" />
          ) : item.media_type === 'video' ? (
            <video src={imgUrl(item.key)} controls className="max-w-full max-h-[320px] rounded" preload="metadata" />
          ) : (
            <img src={imgUrl(item.key)} alt={item.alt_text} className="max-w-full max-h-[320px] object-contain" />
          )}
        </div>
        <div className="mt-2 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-white truncate">{item.filename}</p>
            <p className="text-xs text-gray-400">{item.media_type === 'video' ? '🎬 Video' : '🖼 Imagen'} · {fmt(item.file_size)} · {item.mime_type}</p>
          </div>
          <button onClick={() => { navigator.clipboard.writeText('/'+item.key); }}
            className="px-2 py-1 text-[10px] bg-gray-700 hover:bg-gray-600 rounded text-gray-300">📋 Copiar ruta</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-700 shrink-0">
        {(['info', 'seo'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 ${activeTab === tab ? 'border-blue-500 text-blue-400' : 'border-transparent text-gray-400 hover:text-gray-200'}`}>
            {tab === 'info' ? '📋 Info' : '🔍 SEO'}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'info' && (
          <div className="space-y-4 max-w-lg">
            <div className="bg-gray-800 rounded-lg p-3 space-y-2 text-xs">
              <div className="flex justify-between"><span className="text-gray-400">Archivo</span><span className="text-white">{item.filename}</span></div>
              <div className="flex justify-between"><span className="text-gray-400">Ruta</span><code className="text-blue-400 text-[10px]">/{item.key}</code></div>
              <div className="flex justify-between"><span className="text-gray-400">Tamaño</span><span className="text-white">{fmt(item.file_size)}</span></div>
              <div className="flex justify-between"><span className="text-gray-400">Tipo</span><span className="text-white">{item.mime_type}</span></div>
              <div className="flex justify-between"><span className="text-gray-400">Categoría</span><span className="text-blue-400">{item.category}</span></div>
              <div className="flex justify-between"><span className="text-gray-400">Creado</span><span className="text-white">{item.created_at?.split('T')[0]}</span></div>
              {item.staff_name && <div className="flex justify-between"><span className="text-gray-400">👤 Personal</span><span className="text-orange-400">{item.staff_name}</span></div>}
              {item.location_slug && <div className="flex justify-between"><span className="text-gray-400">📍 Ubicación</span><span className="text-white">{item.location_slug}</span></div>}
              {item.incident_date && <div className="flex justify-between"><span className="text-gray-400">📅 Fecha</span><span className="text-white">{item.incident_date}</span></div>}
            </div>
            <AssignForm
              mediaId={item.id}
              onAssign={handleAssign}
              onUnassign={handleUnassign}
              currentAssignments={item.entities || []}
            />
          </div>
        )}
        {activeTab === 'seo' && (
          <SeoEditor
            altText={editAlt}
            title={editTitle}
            caption={editCaption}
            tags={editTags}
            onAltChange={setEditAlt}
            onTitleChange={setEditTitle}
            onCaptionChange={setEditCaption}
            onTagsChange={setEditTags}
            onSave={handleSaveSeo}
            saving={seoSaving}
            score={score}
          />
        )}
      </div>
    </div>
  );
}
