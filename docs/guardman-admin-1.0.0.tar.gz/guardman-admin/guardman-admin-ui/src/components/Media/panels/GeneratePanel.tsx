// GuardMan Admin — GeneratePanel v4
// Panel de generación desde cero con sistema 3-capas

import { useState, useEffect, useRef } from 'react';
import { generateAsync, waitForCompletion, saveToR2 } from '../../../lib/falai';
import { Lightbox } from '../shared/Lightbox';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

interface ImagePrompt {
  id: string; label: string; category: string; resolution: string;
  aspect_ratio: string; prompt: string; negative: string;
}

interface GeneratePanelProps {
  onGenerated?: () => void;
}

export function GeneratePanel({ onGenerated }: GeneratePanelProps) {
  const [prompts, setPrompts] = useState<ImagePrompt[]>([]);
  const [selectedPromptId, setSelectedPromptId] = useState('');
  const [aiCategory, setAiCategory] = useState('');
  const [userPrompt, setUserPrompt] = useState('');
  const [aiModel, setAiModel] = useState('fal-ai/nano-banana-2');
  const [aiImageSize, setAiImageSize] = useState('landscape_4_3');
  const [generating, setGenerating] = useState(false);
  const [results, setResults] = useState<Array<{ url: string; width: number; height: number }>>([]);
  const [savingIdx, setSavingIdx] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [requestId, setRequestId] = useState<string | null>(null);
  const [showComposed, setShowComposed] = useState(false);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('gm_token');
    if (!token) return;
    fetch(`${API_BASE}/api/media/prompts`, { headers: { 'Authorization': `Bearer ${token}` } })
      .then(r => r.json()).then(d => { if (d.ok) setPrompts(d.data || []); }).catch(() => {});
  }, []);

  const filteredPrompts = aiCategory ? prompts.filter(p => p.category === aiCategory) : prompts;
  const categories = [...new Set(prompts.map(p => p.category))];
  const selectedPrompt = prompts.find(p => p.id === selectedPromptId);

  const composedPrompt = selectedPrompt
    ? `${selectedPrompt.prompt}${userPrompt.trim() ? '\n\nAdditional: ' + userPrompt.trim() : ''}`
    : userPrompt;

  const handleGenerate = async (variants = 1) => {
    if (!composedPrompt.trim()) { setError('Escribe un prompt o selecciona uno predefinido.'); return; }
    setGenerating(true); setError(''); setResults([]); setRequestId(null);
    if (abortRef.current) abortRef.current.abort();
    const ctrl = new AbortController(); abortRef.current = ctrl;

    try {
      const { request_id } = await generateAsync({
        prompt: composedPrompt, model: aiModel, image_size: aiImageSize,
        num_images: variants, negative_prompt: selectedPrompt?.negative || undefined, enable_safety_checker: true,
      });
      setRequestId(request_id);
      const images = await waitForCompletion(request_id, ctrl.signal, 3000, 40);
      if (ctrl.signal.aborted) return;
      setResults(images);
    } catch (err: any) {
      if (err.name !== 'AbortError') setError(err.message || 'Error generando');
    } finally { setGenerating(false); setRequestId(null); abortRef.current = null; }
  };

  const handleSave = async (idx: number) => {
    if (!requestId) return;
    setSavingIdx(idx); setError('');
    try {
      const name = selectedPrompt ? selectedPrompt.id : 'ai-generated';
      await saveToR2({ request_id: requestId, image_index: idx, filename: `${name}-v${idx+1}`, category: 'ai-generated', alt_text: composedPrompt.substring(0, 200) });
      onGenerated?.();
    } catch (err: any) { setError('Error al guardar: ' + err.message); }
    setSavingIdx(null);
  };

  useEffect(() => () => { if (abortRef.current) abortRef.current.abort(); }, []);

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-white">🎨 Generar Imagen con IA</h2>
        {selectedPrompt && <span className="text-[10px] px-2 py-0.5 rounded bg-purple-600/30 text-purple-400">{selectedPrompt.label}</span>}
      </div>

      {/* 3-capas */}
      <div className="bg-gray-800 rounded-lg p-4 space-y-3">
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Categoría (Style Guide)</label>
          <select value={aiCategory} onChange={e => { setAiCategory(e.target.value); setSelectedPromptId(''); }}
            className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600">
            <option value="">Todas las categorías</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Prompt predefinido</label>
          <select value={selectedPromptId} onChange={e => { setSelectedPromptId(e.target.value); if (e.target.value) setUserPrompt(''); }}
            className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600">
            <option value="">— Libre —</option>
            {filteredPrompts.map(p => <option key={p.id} value={p.id}>{p.label} ({p.resolution} {p.aspect_ratio})</option>)}
          </select>
        </div>
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Instrucciones adicionales</label>
          <textarea value={userPrompt} onChange={e => setUserPrompt(e.target.value)}
            placeholder="Describe la imagen..." rows={3}
            className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600" />
        </div>
        {composedPrompt && (
          <button onClick={() => setShowComposed(!showComposed)} className="text-[10px] text-purple-400 hover:text-purple-300">
            {showComposed ? 'Ocultar prompt' : 'Ver prompt completo'}
          </button>
        )}
        {showComposed && (
          <pre className="p-2 bg-gray-900 rounded text-[10px] text-gray-300 max-h-32 overflow-y-auto">{composedPrompt}</pre>
        )}
      </div>

      {/* Model + Size */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Modelo</label>
          <select value={aiModel} onChange={e => setAiModel(e.target.value)}
            className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600">
            <option value="fal-ai/nano-banana-2">Nano Banana 2</option>
            <option value="fal-ai/flux/schnell">Flux Schnell</option>
            <option value="fal-ai/flux/dev">Flux Dev</option>
          </select>
        </div>
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Tamaño</label>
          <select value={aiImageSize} onChange={e => setAiImageSize(e.target.value)}
            className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600">
            <option value="square_hd">1:1 Square</option>
            <option value="landscape_4_3">4:3 Landscape</option>
            <option value="landscape_16_9">16:9 Widescreen</option>
            <option value="portrait_4_3">3:4 Portrait</option>
          </select>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex gap-2">
        <button onClick={() => handleGenerate(1)} disabled={generating || !composedPrompt.trim()}
          className="flex-1 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600 rounded text-sm text-white font-medium">
          {generating ? '⏳ Generando...' : '🎨 Generar'}
        </button>
        <button onClick={() => handleGenerate(4)} disabled={generating || !composedPrompt.trim()}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:bg-gray-600 rounded text-sm text-white font-medium">
          4 variantes
        </button>
        {generating && (
          <button onClick={() => abortRef.current?.abort()}
            className="px-4 py-2.5 bg-red-600 hover:bg-red-500 rounded text-sm text-white">Cancelar</button>
        )}
      </div>

      {/* Status */}
      {generating && requestId && (
        <div className="text-center text-sm text-purple-400 animate-pulse">⏳ Procesando...</div>
      )}
      {error && <div className="p-3 bg-red-900/20 border border-red-500/20 rounded text-sm text-red-400">{error}</div>}

      {/* Results */}
      {results.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-green-400">✅ {results.length} resultado(s)</h3>
          <div className={`grid gap-3 ${results.length === 1 ? '' : 'grid-cols-2'}`}>
            {results.map((img, i) => (
              <div key={i} className="relative group">
                <img src={img.url} alt={`Result ${i + 1}`}
                  className="w-full rounded border border-gray-600 cursor-pointer hover:border-purple-500"
                  onClick={() => setLightboxUrl(img.url)} />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 p-2 flex items-center justify-between">
                  <span className="text-xs text-white">{img.width}x{img.height}</span>
                  <button onClick={() => handleSave(i)} disabled={savingIdx === i}
                    className="px-3 py-1 bg-green-600 hover:bg-green-600/80 rounded text-xs text-white">
                    {savingIdx === i ? '...' : 'Guardar'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Lightbox url={lightboxUrl} onClose={() => setLightboxUrl(null)} />
    </div>
  );
}
