// GuardMan Admin — MediaGrid v4
// Panel de grid con filtros y upload button

import { useState, useEffect, useCallback, useRef } from 'react';
import { useApi } from '../../../hooks/useApi';
import { MediaCard, type MediaItem, imgUrl } from '../shared/MediaCard';
import { UploadModal } from '../shared/UploadModal';

interface MediaGridProps {
  onSelect: (item: MediaItem) => void;
  selectedId: number | null;
  onRefresh?: () => void;
}

const CATEGORIES = [
  { value: '', label: 'Todas' },
  { value: 'hero', label: 'Hero' },
  { value: 'service', label: 'Servicios' },
  { value: 'sector', label: 'Sectores' },
  { value: 'client', label: 'Clientes' },
  { value: 'staff', label: 'Staff' },
  { value: 'og', label: 'OG' },
  { value: 'badge', label: 'Badges' },
  { value: 'ai-generated', label: 'IA Generada' },
  { value: 'ai-edited', label: 'IA Editada' },
];

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

export function MediaGrid({ onSelect, selectedId, onRefresh }: MediaGridProps) {
  const { api } = useApi();
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [category, setCategory] = useState('');
  const [mediaFilter, setMediaFilter] = useState<'all' | 'image' | 'video'>('all');
  const [search, setSearch] = useState('');
  const [showYoutube, setShowYoutube] = useState(false);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [youtubeAdding, setYoutubeAdding] = useState(false);
  const [uploadModal, setUploadModal] = useState<{ open: boolean; mode: 'generic' | 'staff' }>({ open: false, mode: 'generic' });
  const [uploading, setUploading] = useState(false);
  const imageRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLInputElement>(null);

  const loadItems = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const params = new URLSearchParams();
      if (category) params.set('category', category);
      if (search) params.set('q', search);
      params.set('limit', '500');
      const data = await api<MediaItem[]>(`/api/media?${params}`);
      let filtered = data || [];
      if (mediaFilter !== 'all') filtered = filtered.filter(i => i.media_type === mediaFilter);
      setItems(filtered);
    } catch (err: any) {
      setError(err.message || 'Error cargando');
    } finally {
      setLoading(false);
    }
  }, [category, search, mediaFilter, api]);

  useEffect(() => { loadItems(); }, [loadItems]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('category', category || 'generic');
      fd.append('alt_text', file.name.replace(/\.[^.]+$/, ''));
      await api('/api/media/upload', { method: 'POST', body: fd });
      loadItems();
      onRefresh?.();
    } catch (err: any) { alert('Error: ' + err.message); }
    finally { setUploading(false); e.target.value = ''; }
  };

  const handleStaffUpload = async (formData: FormData) => {
    setUploading(true);
    try {
      const token = localStorage.getItem('gm_token') || '';
      const resp = await fetch(`${API_BASE}/api/media/staff-upload`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData,
      });
      const data = await resp.json();
      if (!data.ok) throw new Error(data.error);
      setUploadModal({ open: false, mode: 'generic' });
      loadItems();
      onRefresh?.();
    } catch (err: any) { alert('Error: ' + err.message); }
    finally { setUploading(false); }
  };

  const handleAddYoutube = async () => {
    if (!youtubeUrl.trim()) return;
    setYoutubeAdding(true);
    try {
      await api('/api/media/youtube', { method: 'POST', body: JSON.stringify({ youtube_url: youtubeUrl.trim(), category: 'video' }) });
      setYoutubeUrl(''); setShowYoutube(false);
      loadItems();
    } catch (err: any) { alert('Error: ' + err.message); }
    setYoutubeAdding(false);
  };

  return (
    <div className="w-80 flex flex-col overflow-hidden border-r border-gray-700 shrink-0">
      {/* Toolbar */}
      <div className="shrink-0 p-3 border-b border-gray-700 space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white/80">📁 Biblioteca</h2>
          <button
            onClick={() => setUploadModal({ open: true, mode: 'generic' })}
            className="px-2 py-1 bg-blue-600 hover:bg-blue-500 rounded text-xs text-white font-medium"
          >
            ⬆ Subir
          </button>
        </div>

        {/* Media type */}
        <div className="flex gap-1">
          {(['all', 'image', 'video'] as const).map(t => (
            <button key={t} onClick={() => setMediaFilter(t)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${mediaFilter === t ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}>
              {t === 'all' ? 'Todos' : t === 'image' ? '🖼 Imágenes' : '🎬 Videos'}
            </button>
          ))}
        </div>

        {/* Categories */}
        <div className="flex gap-1 flex-wrap">
          {CATEGORIES.map(c => (
            <button key={c.value} onClick={() => setCategory(c.value)}
              className={`px-2 py-0.5 rounded-full text-[10px] font-medium transition-colors ${category === c.value ? 'bg-blue-600 text-white' : 'bg-gray-700/50 text-white/50 hover:bg-gray-600'}`}>
              {c.label}
            </button>
          ))}
        </div>

        {/* Search + extra actions */}
        <div className="flex gap-1">
          <input type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar..." className="flex-1 bg-gray-700 rounded px-2 py-1.5 text-xs text-white placeholder-gray-500 border border-gray-600" />
          <button onClick={() => setShowYoutube(!showYoutube)}
            className="px-2 py-1.5 rounded text-xs bg-red-600 hover:bg-red-500 text-white" title="Agregar YouTube">
            🔗
          </button>
        </div>

        {showYoutube && (
          <div className="flex gap-1">
            <input type="text" value={youtubeUrl} onChange={e => setYoutubeUrl(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleAddYoutube()}
              placeholder="URL de YouTube..." className="flex-1 bg-gray-700 rounded px-2 py-1 text-xs text-white border border-gray-600" />
            <button onClick={handleAddYoutube} disabled={youtubeAdding}
              className="px-2 py-1 bg-red-600 hover:bg-red-500 disabled:bg-gray-600 rounded text-xs text-white">
              {youtubeAdding ? '⏳' : 'OK'}
            </button>
          </div>
        )}

        {/* Hidden file inputs */}
        <input ref={imageRef} type="file" accept="image/*" onChange={handleUpload} className="hidden" disabled={uploading} />
        <input ref={videoRef} type="file" accept="video/*" onChange={handleUpload} className="hidden" disabled={uploading} />
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-auto p-2">
        {error && <div className="mb-2 p-2 bg-red-900/30 border border-red-500/20 rounded text-red-400 text-xs">{error}</div>}
        {loading ? (
          <div className="grid grid-cols-3 gap-1.5">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="aspect-square bg-gray-800 rounded animate-pulse" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12 text-white/30">
            <div className="text-3xl mb-2">📷</div>
            <p className="text-sm">Sin medios</p>
            <button
              onClick={() => setUploadModal({ open: true, mode: 'generic' })}
              className="mt-2 px-3 py-1.5 bg-blue-600/30 rounded text-xs text-blue-400"
            >
              ⬆ Subir primer archivo
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-1.5">
            {items.map(item => (
              <MediaCard
                key={item.id}
                item={item}
                selected={selectedId === item.id}
                onSelect={onSelect}
                mode="grid"
              />
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-2 border-t border-gray-700 text-[10px] text-gray-500 flex justify-between">
        <span>{items.length} medios</span>
        <span>{items.filter(i => i.media_type === 'video').length} videos</span>
      </div>

      {/* Upload Modal */}
      <UploadModal
        open={uploadModal.open}
        mode={uploadModal.mode}
        uploading={uploading}
        onClose={() => setUploadModal({ open: false, mode: 'generic' })}
        onUpload={handleStaffUpload}
      />
    </div>
  );
}
