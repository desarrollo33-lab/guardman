// GuardMan Admin — StaffPanel v4
// Panel dedicado de fotos del personal con grid y upload prominente

import { useState, useEffect, useCallback, useRef } from 'react';
import { MediaCard, type MediaItem, imgUrl } from '../shared/MediaCard';
import { UploadModal } from '../shared/UploadModal';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

interface StaffPanelProps {
  onSelect: (item: MediaItem) => void;
  onEdit?: (item: MediaItem) => void;
  selectedId: number | null;
  onRefresh?: () => void;
}

export function StaffPanel({ onSelect, onEdit, selectedId, onRefresh }: StaffPanelProps) {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [nameFilter, setNameFilter] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [search, setSearch] = useState('');
  const [uploadModal, setUploadModal] = useState(false);
  const [uploading, setUploading] = useState(false);

  const loadItems = useCallback(async () => {
    setLoading(true); setError('');
    try {
      const params = new URLSearchParams();
      if (nameFilter) params.set('staff_name', nameFilter);
      if (locationFilter) params.set('location', locationFilter);
      if (search) params.set('q', search);
      params.set('limit', '500');
      const token = localStorage.getItem('gm_token') || '';
      const resp = await fetch(`${API_BASE}/api/media/staff-raw?${params}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await resp.json();
      if (data.ok) setItems(data.data || []);
      else setError(data.error || 'Error');
    } catch (err: any) { setError(err.message || 'Error'); }
    finally { setLoading(false); }
  }, [nameFilter, locationFilter, search]);

  useEffect(() => { loadItems(); }, [loadItems]);

  const handleUpload = async (formData: FormData) => {
    setUploading(true);
    try {
      const token = localStorage.getItem('gm_token') || '';
      const resp = await fetch(`${API_BASE}/api/media/staff-upload`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData,
      });
      const data = await resp.json();
      if (!data.ok) throw new Error(data.error);
      setUploadModal(false);
      loadItems();
      onRefresh?.();
    } catch (err: any) { alert('Error: ' + err.message); }
    finally { setUploading(false); }
  };

  return (
    <div className="w-80 flex flex-col overflow-hidden border-r border-gray-700 shrink-0">
      {/* Toolbar */}
      <div className="shrink-0 p-3 border-b border-gray-700 space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white/80">📸 Fotos del Personal</h2>
          <button
            onClick={() => setUploadModal(true)}
            className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 rounded text-xs text-white font-medium"
          >
            ⬆ Subir foto
          </button>
        </div>

        <div className="grid grid-cols-2 gap-1">
          <input type="text" value={nameFilter} onChange={e => setNameFilter(e.target.value)}
            placeholder="Nombre..." className="bg-gray-700 rounded px-2 py-1.5 text-xs text-white placeholder-gray-500 border border-gray-600" />
          <input type="text" value={locationFilter} onChange={e => setLocationFilter(e.target.value)}
            placeholder="Ubicación..." className="bg-gray-700 rounded px-2 py-1.5 text-xs text-white placeholder-gray-500 border border-gray-600" />
        </div>
        <input type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Buscar..." className="w-full bg-gray-700 rounded px-2 py-1.5 text-xs text-white placeholder-gray-500 border border-gray-600" />
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-auto p-2">
        {error && <div className="mb-2 p-2 bg-red-900/30 border border-red-500/20 rounded text-red-400 text-xs">{error}</div>}
        {loading ? (
          <div className="grid grid-cols-3 gap-1.5">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="aspect-square bg-gray-800 rounded animate-pulse" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12 text-white/30">
            <div className="text-3xl mb-2">📸</div>
            <p className="text-sm">Sin fotos del personal</p>
            <button
              onClick={() => setUploadModal(true)}
              className="mt-2 px-3 py-1.5 bg-orange-600/30 rounded text-xs text-orange-400"
            >
              ⬆ Subir primera foto
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-1.5">
            {items.map(item => (
              <MediaCard
                key={item.id}
                item={item}
                selected={selectedId === item.id}
                onSelect={onSelect}
                onEdit={onEdit}
                mode="grid"
              />
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-2 border-t border-gray-700 text-[10px] text-gray-500 flex justify-between">
        <span>{items.length} fotos</span>
        <span>{items.filter((i: any) => i.location_slug).length} ubicaciones</span>
      </div>

      <UploadModal
        open={uploadModal}
        mode="staff"
        uploading={uploading}
        onClose={() => setUploadModal(false)}
        onUpload={handleUpload}
      />
    </div>
  );
}
