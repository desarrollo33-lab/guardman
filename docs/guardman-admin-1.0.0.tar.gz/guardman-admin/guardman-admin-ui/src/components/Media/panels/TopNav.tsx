// GuardMan Admin — TopNav v4
// Navegación principal del Media Editor

const TABS = [
  { id: 'biblioteca', icon: '📁', label: 'Biblioteca', desc: 'Todas las imágenes y videos' },
  { id: 'staff', icon: '📸', label: 'Staff', desc: 'Fotos del personal de GuardMan' },
  { id: 'generar', icon: '🎨', label: 'Generar', desc: 'Crear imágenes con IA' },
  { id: 'batch', icon: '📦', label: 'Batch', desc: 'Generar múltiples imágenes' },
] as const;

type TabId = (typeof TABS)[number]['id'];

interface TopNavProps {
  activeTab: TabId;
  onChange: (tab: TabId) => void;
}

export function TopNav({ activeTab, onChange }: TopNavProps) {
  return (
    <nav className="flex items-center gap-1 px-4 py-2 border-b border-gray-700 bg-gray-900 shrink-0">
      <span className="text-sm font-bold text-white mr-4">🖼 Media</span>
      {TABS.map(tab => {
        const isActive = activeTab === tab.id;
        const colorMap: Record<TabId, string> = {
          biblioteca: 'bg-blue-600 text-white shadow-lg shadow-blue-900/30',
          staff: 'bg-orange-600 text-white shadow-lg shadow-orange-900/30',
          generar: 'bg-purple-600 text-white shadow-lg shadow-purple-900/30',
          batch: 'bg-amber-600 text-white shadow-lg shadow-amber-900/30',
        };
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              isActive
                ? colorMap[tab.id]
                : 'text-gray-400 hover:text-white hover:bg-gray-800'
            }`}
            title={tab.desc}
          >
            <span>{tab.icon}</span>
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

export { TABS };
export type { TabId };
