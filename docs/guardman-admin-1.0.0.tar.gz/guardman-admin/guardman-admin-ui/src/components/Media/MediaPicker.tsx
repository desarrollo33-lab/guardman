// GuardMan Admin — MediaPicker v4
// Componente independiente para selección rápida de imágenes (CMS)

import { useState, useEffect, useCallback } from 'react';
import { useApi } from '../../hooks/useApi';
import { MediaCard, type MediaItem } from './shared/MediaCard';

interface MediaPickerProps {
  open: boolean;
  currentImage?: string;
  onSelect: (path: string) => void;
  onClose: () => void;
}

export function MediaPicker({ open, currentImage, onSelect, onClose }: MediaPickerProps) {
  const { api } = useApi();
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [mediaFilter, setMediaFilter] = useState<'all' | 'image' | 'video'>('all');

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set('q', search);
      params.set('limit', '200');
      const data = await api<MediaItem[]>(`/api/media?${params}`);
      let filtered = data || [];
      if (mediaFilter !== 'all') {
        filtered = filtered.filter(i => i.media_type === mediaFilter);
      }
      setItems(filtered);
    } catch {} finally {
      setLoading(false);
    }
  }, [search, mediaFilter, api]);

  useEffect(() => { if (open) loadItems(); }, [loadItems, open]);

  const handleSelect = (item: MediaItem) => {
    const path = item.youtube_id ? `yt:${item.youtube_id}` : `/${item.key}`;
    onSelect(path);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="bg-gray-900 rounded-xl w-full max-w-3xl max-h-[85vh] flex flex-col border border-gray-700 shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700 shrink-0">
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-bold text-white">Seleccionar imagen</h3>
            <div className="flex gap-1">
              {(['all', 'image', 'video'] as const).map(t => (
                <button
                  key={t}
                  onClick={() => setMediaFilter(t)}
                  className={`px-2 py-0.5 rounded-full text-[10px] font-medium transition-colors ${
                    mediaFilter === t
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  {t === 'all' ? 'Todos' : t === 'image' ? 'Imagen' : 'Video'}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar..."
              className="bg-gray-700 rounded px-2 py-1 text-xs text-white placeholder-gray-500 border border-gray-600 w-44"
            />
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-xl">✕</button>
        </div>

        {/* Grid */}
        <div className="flex-1 overflow-y-auto p-3">
          {loading ? (
            <div className="text-center py-12 text-white/30 text-sm">Cargando...</div>
          ) : items.length === 0 ? (
            <div className="text-center py-12 text-white/30">
              <div className="text-3xl mb-2">📷</div>
              <p className="text-sm">Sin medios</p>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-2">
              {items.map(item => (
                <MediaCard
                  key={item.id}
                  item={item}
                  selected={item.youtube_id ? `yt:${item.youtube_id}` === currentImage : `/${item.key}` === currentImage}
                  onSelect={handleSelect}
                  mode="picker"
                />
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-700 shrink-0">
          <span className="text-sm text-gray-400">{items.length} medios</span>
          <button onClick={onClose} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white">
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}
