// GuardMan Admin — MediaEditor v4
// Orquestador: TopNav + Panel activo (Biblioteca / Staff / Generar)

import { useState, useCallback, useEffect } from 'react';
import { TopNav, type TabId } from './panels/TopNav';
import { MediaGrid } from './panels/MediaGrid';
import { StaffPanel } from './panels/StaffPanel';
import { GeneratePanel } from './panels/GeneratePanel';
import { MediaWorkspace } from './panels/MediaWorkspace';
import { EditModal } from './shared/EditModal';
import type { MediaItem } from './shared/MediaCard';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

function BatchPlaceholder() {
  return (
    <div className="flex-1 flex items-center justify-center text-gray-400">
      <div className="text-center">
        <div className="text-3xl mb-2">📦</div>
        <p className="text-sm">Panel Batch</p>
        <p className="text-xs mt-1">Próximamente</p>
      </div>
    </div>
  );
}

interface ImagePrompt {
  id: string; label: string; category: string; resolution: string;
  aspect_ratio: string; prompt: string; negative: string;
}

export function MediaEditor() {
  const [activeTab, setActiveTab] = useState<TabId>('biblioteca');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [editItem, setEditItem] = useState<MediaItem | null>(null);
  const [prompts, setPrompts] = useState<ImagePrompt[]>([]);

  // Load prompts for EditModal
  useEffect(() => {
    const token = localStorage.getItem('gm_token');
    if (!token) return;
    fetch(`${API_BASE}/api/media/prompts`, { headers: { 'Authorization': `Bearer ${token}` } })
      .then(r => r.json()).then(d => { if (d.ok) setPrompts(d.data || []); }).catch(() => {});
  }, []);

  const handleSelect = useCallback((item: MediaItem) => {
    setSelectedId(prev => prev === item.id ? null : item.id);
  }, []);

  const handleEdit = useCallback((item: MediaItem) => {
    setEditItem(item);
  }, []);

  const handleRefresh = useCallback(() => {
    setRefreshKey(k => k + 1);
  }, []);

  const showGrid = activeTab === 'biblioteca' || activeTab === 'staff';

  return (
    <div className="flex flex-col h-full bg-gray-900 text-white">
      <TopNav activeTab={activeTab} onChange={setActiveTab} />

      <div className="flex-1 flex overflow-hidden">
        {activeTab === 'biblioteca' && (
          <MediaGrid
            onSelect={handleSelect}
            selectedId={showGrid ? selectedId : null}
            onRefresh={handleRefresh}
          />
        )}
        {activeTab === 'staff' && (
          <StaffPanel
            onSelect={handleSelect}
            onEdit={handleEdit}
            selectedId={showGrid ? selectedId : null}
            onRefresh={handleRefresh}
          />
        )}

        {(activeTab === 'biblioteca' || activeTab === 'staff') && (
          <MediaWorkspace
            key={refreshKey}
            selectedId={selectedId}
            onUpdate={handleRefresh}
          />
        )}

        {activeTab === 'generar' && (
          <GeneratePanel onGenerated={handleRefresh} />
        )}

        {activeTab === 'batch' && (
          <BatchPlaceholder />
        )}
      </div>

      {/* Edit Modal for staff photos */}
      <EditModal
        open={!!editItem}
        item={editItem}
        prompts={prompts}
        onClose={() => setEditItem(null)}
        onSaved={handleRefresh}
      />
    </div>
  );
}

// Re-export for CMSPage compatibility
export function MediaEditorPicker({ open, currentImage, onSelect, onClose }: {
  open: boolean; currentImage?: string; onSelect: (path: string) => void; onClose: () => void;
}) {
  const { MediaPicker } = require('./MediaPicker');
  return <MediaPicker open={open} currentImage={currentImage} onSelect={onSelect} onClose={onClose} />;
}
