// GuardMan Admin — Lightbox v4

interface LightboxProps {
  url: string | null;
  onClose: () => void;
}

export function Lightbox({ url, onClose }: LightboxProps) {
  if (!url) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center cursor-pointer" onClick={onClose}>
      <img src={url} alt="Lightbox" className="max-w-[90vw] max-h-[90vh] object-contain rounded" />
      <button onClick={onClose} className="absolute top-4 right-4 text-white/60 hover:text-white text-2xl">
        ✕
      </button>
    </div>
  );
}
