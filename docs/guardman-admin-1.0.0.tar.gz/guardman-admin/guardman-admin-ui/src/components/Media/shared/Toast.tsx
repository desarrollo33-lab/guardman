// GuardMan Admin — Toast v4
// Notificaciones toast en lugar de alert()

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

interface Toast {
  id: number;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface ToastContextType {
  toast: (type: Toast['type'], message: string) => void;
}

const ToastContext = createContext<ToastContextType>({ toast: () => {} });

let nextId = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = useCallback((type: Toast['type'], message: string) => {
    const id = nextId++;
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  const removeToast = (id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ toast: addToast }}>
      {children}
      {/* Toast container */}
      <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2">
        {toasts.map(t => {
          const colors: Record<Toast['type'], string> = {
            success: 'bg-green-600 border-green-400',
            error: 'bg-red-600 border-red-400',
            info: 'bg-blue-600 border-blue-400',
          };
          const icons: Record<Toast['type'], string> = { success: '✅', error: '❌', info: 'ℹ️' };
          return (
            <div
              key={t.id}
              onClick={() => removeToast(t.id)}
              className={`${colors[t.type]} border text-white px-4 py-3 rounded-lg shadow-2xl cursor-pointer text-sm max-w-sm animate-[slideIn_0.2s_ease-out]`}
            >
              {icons[t.type]} {t.message}
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
}
