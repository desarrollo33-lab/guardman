// GuardMan Admin — MediaCard v4
// Thumbnail individual con hover actions y distintivos visuales

import { useState } from 'react';

export interface MediaItem {
  id: number;
  key: string;
  filename: string;
  alt_text: string;
  mime_type: string;
  file_size: number;
  category: string;
  tags: string;
  media_type: string;
  youtube_id?: string | null;
  youtube_url?: string | null;
  thumbnail_key?: string | null;
  staff_name?: string | null;
  location_slug?: string | null;
  incident_date?: string | null;
  created_at?: string;
  width?: number;
  height?: number;
}

interface MediaCardProps {
  item: MediaItem;
  selected: boolean;
  onSelect: (item: MediaItem) => void;
  onEdit?: (item: MediaItem) => void;
  onDelete?: (item: MediaItem) => void;
  mode: 'grid' | 'picker';
}

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

export function imgUrl(key: string, thumb?: string | null) {
  const k = thumb || key;
  return k.startsWith('http') ? k : `${API_BASE}/api/images/${k}`;
}

export function MediaCard({ item, selected, onSelect, onEdit, onDelete, mode }: MediaCardProps) {
  const [hovered, setHovered] = useState(false);
  const isStaff = item.category === 'staff-raw';
  const isVideo = item.youtube_id != null;

  return (
    <div
      onClick={() => onSelect(item)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={`group relative rounded overflow-hidden border-2 cursor-pointer transition-all aspect-square bg-gray-800 ${
        selected
          ? isStaff
            ? 'border-orange-500 ring-1 ring-orange-500/30 shadow-lg shadow-orange-900/20'
            : 'border-blue-500 ring-1 ring-blue-500/30 shadow-lg shadow-blue-900/20'
          : isStaff
            ? 'border-transparent hover:border-orange-400/50'
            : 'border-transparent hover:border-white/20'
      }`}
    >
      {/* Image or video thumbnail */}
      {isVideo ? (
        <>
          <img
            src={`https://img.youtube.com/vi/${item.youtube_id}/hqdefault.jpg`}
            alt={item.alt_text}
            className="w-full h-full object-cover"
            loading="lazy"
            onError={(e) => {
              (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${item.youtube_id}/default.jpg`;
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <div className="w-8 h-8 rounded-full bg-white/20 backdrop-blur flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
          </div>
          <div className="absolute top-1 left-1">
            <span className="text-[8px] px-1 py-0.5 rounded bg-red-600/80 text-white">YT</span>
          </div>
        </>
      ) : (
        <img src={imgUrl(item.key)} alt={item.alt_text} className="w-full h-full object-cover" loading="lazy" />
      )}

      {/* Hover actions overlay */}
      {hovered && mode === 'grid' && !selected && (
        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-1.5 p-2">
          <button
            onClick={(e) => { e.stopPropagation(); onSelect(item); }}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 rounded text-xs text-white font-medium w-full"
          >
            Ver
          </button>
          {isStaff && onEdit && (
            <button
              onClick={(e) => { e.stopPropagation(); onEdit(item); }}
              className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 rounded text-xs text-white font-medium w-full"
            >
              Editar con IA
            </button>
          )}
          {onDelete && (
            <button
              onClick={(e) => { e.stopPropagation(); onDelete(item); }}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-500 rounded text-xs text-white font-medium w-full"
            >
              Eliminar
            </button>
          )}
        </div>
      )}

      {/* Bottom caption */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-1 pointer-events-none">
        <p className="text-[9px] text-white truncate leading-tight">
          {isStaff && item.staff_name ? item.staff_name : item.filename}
        </p>
        {isStaff && item.location_slug && (
          <p className="text-[7px] text-orange-300 truncate leading-tight">{item.location_slug}</p>
        )}
      </div>

      {/* Category badge */}
      <div className="absolute top-1 right-1 pointer-events-none">
        <span
          className={`text-[8px] px-1.5 py-0.5 rounded font-medium ${
            isStaff ? 'bg-orange-600 text-white' : 'bg-black/50 text-blue-300'
          }`}
        >
          {isStaff ? 'Staff' : item.category}
        </span>
      </div>

      {isVideo && (
        <div className="absolute top-1 left-1 pointer-events-none">
          <span className="text-[8px] px-1.5 py-0.5 rounded bg-purple-600/80 text-white">VID</span>
        </div>
      )}
    </div>
  );
}
