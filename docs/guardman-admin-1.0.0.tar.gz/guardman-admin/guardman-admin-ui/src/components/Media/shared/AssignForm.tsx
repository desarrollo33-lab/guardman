// GuardMan Admin — AssignForm v4
// Asignación rápida de imagen a entidad (servicio, sector, etc.)

import { useState, useEffect } from 'react';
import { useApi } from '../../../hooks/useApi';

interface AssignFormProps {
  mediaId: number;
  onAssign: (id: number, type: string, slug: string, usage: string) => void;
  onUnassign: (id: number, type: string, slug: string, usage: string) => void;
  currentAssignments: Array<{ id: number; entity_type: string; entity_slug: string; usage: string }>;
}

const ENTITY_TYPES = ['service', 'sector', 'global'];

export function AssignForm({ mediaId, onAssign, onUnassign, currentAssignments }: AssignFormProps) {
  const [entityType, setEntityType] = useState('service');
  const [entitySlug, setEntitySlug] = useState('');
  const [usage, setUsage] = useState('hero');
  const { api } = useApi();

  const handleAssign = () => {
    if (entitySlug) onAssign(mediaId, entityType, entitySlug, usage);
  };

  // Current assignments display
  const hasAssignments = currentAssignments && currentAssignments.length > 0;

  return (
    <div className="bg-gray-800 rounded-lg p-3 space-y-3">
      <h4 className="text-xs font-bold text-white/50 uppercase tracking-wide">Asignaciones</h4>

      {/* Current assignments */}
      {hasAssignments ? (
        <div className="space-y-1">
          {currentAssignments.map((e, i) => (
            <div key={i} className="flex items-center gap-1.5 bg-gray-700/50 rounded px-2 py-1.5 text-[10px]">
              <span className="text-blue-400">{e.entity_type}</span>
              <span className="text-white/20">/</span>
              <span className="text-white/70 flex-1 truncate">{e.entity_slug}</span>
              <span className="text-white/20">/</span>
              <span className="text-amber-400">{e.usage}</span>
              <button
                onClick={() => onUnassign(mediaId, e.entity_type, e.entity_slug, e.usage)}
                className="text-red-400/60 hover:text-red-400 ml-1 shrink-0"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-[10px] text-white/20">Sin asignaciones</p>
      )}

      {/* New assignment form */}
      <div className="bg-gray-700/50 rounded p-2 space-y-1.5">
        <div className="grid grid-cols-3 gap-1">
          <select value={entityType} onChange={e => setEntityType(e.target.value)}
            className="px-1 py-1 bg-gray-600 border border-gray-500 rounded text-white text-[10px]">
            {ENTITY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <input
            type="text"
            value={entitySlug}
            onChange={e => setEntitySlug(e.target.value)}
            placeholder="slug..."
            className="px-1 py-1 bg-gray-600 border border-gray-500 rounded text-white text-[10px] placeholder-gray-400"
          />
          <select value={usage} onChange={e => setUsage(e.target.value)}
            className="px-1 py-1 bg-gray-600 border border-gray-500 rounded text-white text-[10px]">
            <option value="hero">hero</option>
            <option value="gallery">gallery</option>
            <option value="product">product</option>
            <option value="partner">partner</option>
            <option value="badge">badge</option>
          </select>
        </div>
        <button
          onClick={handleAssign}
          disabled={!entitySlug}
          className="w-full px-2 py-1 bg-blue-600/80 rounded text-white text-[10px] hover:bg-blue-600 disabled:opacity-30 disabled:cursor-not-allowed"
        >
          Asignar
        </button>
      </div>
    </div>
  );
}
