// GuardMan Admin — UploadModal v4
// Modal prominente de upload con formulario (genérico y staff)

import { useState, useRef, useEffect } from 'react';

interface UploadModalProps {
  open: boolean;
  mode: 'generic' | 'staff';
  onClose: () => void;
  onUpload: (formData: FormData) => Promise<void>;
  uploading: boolean;
}

export function UploadModal({ open, mode, onClose, onUpload, uploading }: UploadModalProps) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [staffName, setStaffName] = useState('');
  const [location, setLocation] = useState('');
  const [incidentDate, setIncidentDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  // Escape key to close
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose]);

  if (!open) return null;

  const handleSubmit = async () => {
    if (!file) return;
    if (mode === 'staff' && !staffName.trim()) return;

    const fd = new FormData();
    fd.append('file', file);
    if (mode === 'staff') {
      fd.append('staff_name', staffName.trim());
      fd.append('location', location.trim());
      fd.append('incident_date', incidentDate);
      fd.append('notes', notes.trim());
    }
    await onUpload(fd);

    // Reset form
    setFile(null);
    setStaffName('');
    setLocation('');
    setIncidentDate(new Date().toISOString().split('T')[0]);
    setNotes('');
  };

  const ready = file && (mode === 'generic' || staffName.trim());

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center" onClick={onClose}>
      <div
        className="bg-gray-900 rounded-xl w-full max-w-md border border-gray-700 shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-700">
          <h3 className="text-lg font-bold text-white">
            {mode === 'staff' ? '📸 Subir foto del personal' : '⬆ Subir archivo'}
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-xl">✕</button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {/* File selector */}
          <div>
            <label className={`block w-full text-center px-4 py-6 rounded-lg border-2 border-dashed cursor-pointer transition-colors ${
              file ? 'border-green-500/50 bg-green-900/10' : 'border-gray-600 hover:border-gray-500'
            }`}>
              {file ? (
                <div className="space-y-1">
                  <p className="text-sm text-green-400 font-medium">📎 {file.name}</p>
                  <p className="text-xs text-gray-400">{(file.size / 1024).toFixed(0)} KB</p>
                  <p className="text-xs text-blue-400 underline">Click para cambiar</p>
                </div>
              ) : (
                <div className="space-y-1">
                  <p className="text-2xl">📁</p>
                  <p className="text-sm text-gray-400">Click para seleccionar archivo</p>
                  <p className="text-xs text-gray-500">JPG, PNG, WebP (max 20MB)</p>
                </div>
              )}
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={e => { const f = e.target.files?.[0]; if (f) setFile(f); }}
                className="hidden"
              />
            </label>
          </div>

          {/* Staff fields */}
          {mode === 'staff' && (
            <div className="space-y-3 bg-gray-800 rounded-lg p-3">
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Nombre del guardia *</label>
                <input
                  type="text" value={staffName} onChange={e => setStaffName(e.target.value)}
                  placeholder="Ej: Juan Pérez"
                  className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-500 border border-gray-600"
                />
              </div>
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Ubicación</label>
                <input
                  type="text" value={location} onChange={e => setLocation(e.target.value)}
                  placeholder="Ej: Huechuraba, Las Condes"
                  className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-500 border border-gray-600"
                />
              </div>
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Fecha</label>
                <input
                  type="date" value={incidentDate} onChange={e => setIncidentDate(e.target.value)}
                  className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600"
                />
              </div>
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Notas</label>
                <textarea
                  value={notes} onChange={e => setNotes(e.target.value)}
                  placeholder="Equipo, turno, observaciones..."
                  rows={2}
                  className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white placeholder-gray-500 border border-gray-600"
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 px-5 py-4 border-t border-gray-700">
          <button onClick={onClose} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white">
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            disabled={!ready || uploading}
            className={`px-4 py-2 rounded text-sm font-medium ${
              mode === 'staff'
                ? 'bg-orange-600 hover:bg-orange-500 disabled:bg-gray-600 disabled:text-gray-400'
                : 'bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 disabled:text-gray-400'
            } text-white`}
          >
            {uploading ? '⏳ Subiendo...' : mode === 'staff' ? '📸 Subir foto del personal' : '⬆ Subir archivo'}
          </button>
        </div>
      </div>
    </div>
  );
}
