// GuardMan Admin — SeoEditor v4
// Editor de metadatos SEO con score visual

import { useState } from 'react';

interface SeoEditorProps {
  altText: string;
  title: string;
  caption: string;
  tags: string[];
  onAltChange: (v: string) => void;
  onTitleChange: (v: string) => void;
  onCaptionChange: (v: string) => void;
  onTagsChange: (tags: string[]) => void;
  onSave: () => void;
  saving: boolean;
  score: { score: number; checks: { label: string; ok: boolean; detail: string }[] } | null;
}

export function SeoEditor({
  altText, title, caption, tags,
  onAltChange, onTitleChange, onCaptionChange, onTagsChange,
  onSave, saving, score,
}: SeoEditorProps) {
  const [newTag, setNewTag] = useState('');

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      onTagsChange([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  return (
    <div className="space-y-4 max-w-lg">
      {/* Score ring */}
      {score && (
        <div className="bg-gray-800 rounded-lg p-4 flex items-center gap-4">
          <div className="relative w-16 h-16 shrink-0">
            <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
              <circle cx="50" cy="50" r="42" fill="none" stroke="#374151" strokeWidth="6" />
              <circle cx="50" cy="50" r="42" fill="none"
                stroke={score.score >= 70 ? '#22c55e' : score.score >= 40 ? '#eab308' : '#ef4444'}
                strokeWidth="6" strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 42}
                strokeDashoffset={2 * Math.PI * 42 - (score.score / 100) * 2 * Math.PI * 42} />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center text-lg font-bold"
              style={{ color: score.score >= 70 ? '#22c55e' : score.score >= 40 ? '#eab308' : '#ef4444' }}>
              {score.score}
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-white">
              {score.score >= 70 ? 'SEO Excelente' : score.score >= 40 ? 'SEO Mejorable' : 'SEO Deficiente'}
            </p>
            <div className="mt-1 space-y-0.5">
              {score.checks.filter(c => !c.ok).map((c, i) => (
                <p key={i} className="text-[10px] text-red-400">✗ {c.label}: {c.detail}</p>
              ))}
              {score.checks.filter(c => c.ok).slice(0, 3).map((c, i) => (
                <p key={i} className="text-[10px] text-green-400">✓ {c.label}: {c.detail}</p>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SEO Fields */}
      <div className="bg-gray-800 rounded-lg p-3 space-y-3">
        <h4 className="text-xs font-bold text-white/50 uppercase tracking-wide">Metadatos SEO</h4>

        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Alt Text</label>
          <input type="text" value={altText} onChange={e => onAltChange(e.target.value)}
            className="w-full bg-gray-700 rounded px-2 py-1.5 text-xs text-white border border-gray-600" />
          {altText.length > 0 && altText.length < 10 && (
            <p className="text-[9px] text-yellow-400 mt-0.5">⚠ Muy corto, mínimo 10 caracteres</p>
          )}
        </div>

        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Title</label>
          <input type="text" value={title} onChange={e => onTitleChange(e.target.value)}
            className="w-full bg-gray-700 rounded px-2 py-1.5 text-xs text-white border border-gray-600" />
        </div>

        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Caption</label>
          <textarea value={caption} onChange={e => onCaptionChange(e.target.value)}
            rows={2} className="w-full bg-gray-700 rounded px-2 py-1.5 text-xs text-white border border-gray-600" />
        </div>

        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Tags</label>
          <div className="flex flex-wrap gap-1 mb-1.5">
            {tags.map((tag, i) => (
              <span key={i} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-600/30 text-blue-300 text-[10px]">
                {tag}
                <button onClick={() => onTagsChange(tags.filter((_, j) => j !== i))} className="text-blue-400 hover:text-red-400">×</button>
              </span>
            ))}
          </div>
          <div className="flex gap-1">
            <input type="text" value={newTag} onChange={e => setNewTag(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') { addTag(); e.preventDefault(); } }}
              placeholder="Agregar tag..."
              className="flex-1 bg-gray-700 rounded px-2 py-1.5 text-xs text-white border border-gray-600" />
            <button onClick={addTag} className="px-2 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-xs text-white">+</button>
          </div>
        </div>

        <button onClick={onSave} disabled={saving}
          className="w-full px-3 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 rounded text-xs text-white font-medium">
          {saving ? 'Guardando...' : 'Guardar SEO'}
        </button>
      </div>
    </div>
  );
}
