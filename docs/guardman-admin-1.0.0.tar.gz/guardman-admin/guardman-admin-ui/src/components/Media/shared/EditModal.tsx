// GuardMan Admin — EditModal v4
// Modal de edición img2img con Style Guide (3-capas)

import { useState, useEffect, useRef } from 'react';
import { generateAsync, waitForCompletion, saveToR2 } from '../../../lib/falai';
import { CompareSlider } from './CompareSlider';
import { Lightbox } from './Lightbox';
import { imgUrl, type MediaItem } from './MediaCard';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

interface ImagePrompt {
  id: string; label: string; category: string; resolution: string;
  aspect_ratio: string; prompt: string; negative: string;
}

interface EditModalProps {
  open: boolean;
  item: MediaItem | null;
  prompts: ImagePrompt[];
  onClose: () => void;
  onSaved: () => void;
}

export function EditModal({ open, item, prompts, onClose, onSaved }: EditModalProps) {
  const [aiCategory, setAiCategory] = useState('');
  const [selectedPromptId, setSelectedPromptId] = useState('');
  const [userPrompt, setUserPrompt] = useState('');
  const [aiModel, setAiModel] = useState('fal-ai/nano-banana-2');
  const [strength, setStrength] = useState(0.45);
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<{ url: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [requestId, setRequestId] = useState<string | null>(null);
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const filteredPrompts = aiCategory ? prompts.filter(p => p.category === aiCategory) : prompts;
  const categories = [...new Set(prompts.map(p => p.category))];
  const selectedPrompt = prompts.find(p => p.id === selectedPromptId);

  const composedPrompt = selectedPrompt
    ? `${selectedPrompt.prompt}${userPrompt.trim() ? '\n\nAdditional: ' + userPrompt.trim() : ''}`
    : userPrompt;

  // Reset on open
  useEffect(() => {
    if (open) {
      setAiCategory(''); setSelectedPromptId(''); setUserPrompt('');
      setStrength(0.45); setResult(null); setError('');
    }
  }, [open]);

  const handleGenerate = async () => {
    if (!item) return;
    if (!composedPrompt.trim()) { setError('Describe el cambio o selecciona un prompt.'); return; }
    setGenerating(true); setError(''); setResult(null);
    if (abortRef.current) abortRef.current.abort();
    const ctrl = new AbortController(); abortRef.current = ctrl;

    try {
      const sourceUrl = imgUrl(item.key);
      const { request_id } = await generateAsync({
        prompt: composedPrompt, model: aiModel,
        image_url: sourceUrl, strength, num_images: 1,
        negative_prompt: selectedPrompt?.negative || undefined,
        enable_safety_checker: true,
      });
      setRequestId(request_id);
      const images = await waitForCompletion(request_id, ctrl.signal, 3000, 40);
      if (ctrl.signal.aborted) return;
      if (images.length > 0) setResult(images[0]);
    } catch (err: any) {
      if (err.name !== 'AbortError') setError(err.message || 'Error en edición');
    } finally { setGenerating(false); setRequestId(null); abortRef.current = null; }
  };

  const handleSave = async () => {
    if (!result || !item || !requestId) return;
    setSaving(true);
    try {
      const name = selectedPrompt ? selectedPrompt.id : 'staff-edited';
      await saveToR2({
        request_id: requestId, image_index: 0,
        filename: `${name}-v1`, category: 'ai-edited',
        alt_text: composedPrompt.substring(0, 200),
        tags: ['ai-generated', 'fal-ai', 'staff-edited'],
        parent_media_id: item.id,
      });
      onSaved();
      onClose();
    } catch (err: any) { setError('Error al guardar: ' + err.message); }
    finally { setSaving(false); }
  };

  useEffect(() => () => { if (abortRef.current) abortRef.current.abort(); }, []);

  // Escape key to close
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onClose]);

  if (!open || !item) return null;

  const isStaff = item.category === 'staff-raw';

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center" onClick={onClose}>
      <div className="bg-gray-900 rounded-xl w-full max-w-3xl max-h-[90vh] border border-gray-700 shadow-2xl overflow-hidden flex flex-col"
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-700">
          <div>
            <h3 className="text-lg font-bold text-white">
              {isStaff ? '✨ Editar foto del personal' : '🔄 Editar imagen'}
            </h3>
            {isStaff && item.staff_name && (
              <p className="text-xs text-orange-400 mt-0.5">👤 {item.staff_name} · 📍 {item.location_slug || 'Sin ubicación'}</p>
            )}
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white text-xl">✕</button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Source + Result preview */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-[10px] text-gray-400 mb-1">Original</p>
              <img src={imgUrl(item.key)} alt="Original"
                className="w-full rounded border border-gray-600 object-cover" style={{ maxHeight: '200px' }} />
            </div>
            <div>
              <p className="text-[10px] text-gray-400 mb-1">
                {result ? 'Resultado' : generating ? 'Generando...' : 'Resultado'}
              </p>
              {result ? (
                <img src={result.url} alt="Result" onClick={() => setLightboxUrl(result.url)}
                  className="w-full rounded border border-gray-600 object-cover cursor-pointer hover:border-purple-500"
                  style={{ maxHeight: '200px' }} />
              ) : (
                <div className="w-full rounded border border-dashed border-gray-600 flex items-center justify-center bg-gray-800/50"
                  style={{ height: '200px' }}>
                  {generating ? (
                    <span className="text-xs text-purple-400 animate-pulse">⏳ Procesando...</span>
                  ) : (
                    <span className="text-xs text-gray-500">No generado aún</span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Before/After slider */}
          {result && (
            <CompareSlider beforeUrl={`/${item.key}`} afterUrl={result.url} />
          )}

          {/* Controls */}
          <div className="bg-gray-800 rounded-lg p-4 space-y-3">
            {isStaff && (
              <>
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">Categoría Style Guide</label>
                  <select value={aiCategory} onChange={e => { setAiCategory(e.target.value); setSelectedPromptId(''); }}
                    className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600">
                    <option value="">Todas</option>
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">Prompt predefinido</label>
                  <select value={selectedPromptId} onChange={e => { setSelectedPromptId(e.target.value); setUserPrompt(''); }}
                    className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600">
                    <option value="">— Libre —</option>
                    {filteredPrompts.map(p => <option key={p.id} value={p.id}>{p.label}</option>)}
                  </select>
                </div>
              </>
            )}
            <div>
              <label className="text-[10px] text-gray-400 block mb-1">
                {isStaff ? 'Instrucciones adicionales' : 'Prompt de edición'}
              </label>
              <textarea value={userPrompt} onChange={e => setUserPrompt(e.target.value)}
                placeholder={isStaff ? 'Ej: quitar auto rojo de fondo, suavizar iluminación...' : 'Describe el cambio a aplicar...'}
                rows={2} className="w-full bg-gray-700 rounded px-3 py-2 text-sm text-white border border-gray-600" />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Modelo</label>
                <select value={aiModel} onChange={e => setAiModel(e.target.value)}
                  className="w-full bg-gray-700 rounded px-2 py-1.5 text-xs text-white border border-gray-600">
                  <option value="fal-ai/nano-banana-2">Nano Banana 2</option>
                  <option value="fal-ai/flux/schnell">Flux Schnell</option>
                  <option value="fal-ai/flux/dev">Flux Dev</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">
                  Strength: <span className={strength <= 0.3 ? 'text-green-400' : strength <= 0.6 ? 'text-yellow-400' : 'text-red-400'}>{strength.toFixed(2)}</span>
                </label>
                <input type="range" min="0.1" max="0.9" step="0.05" value={strength}
                  onChange={e => setStrength(parseFloat(e.target.value))}
                  className="w-full accent-cyan-500" />
                <div className="flex justify-between text-[8px] text-gray-600">
                  <span>Conservar</span><span>Estilizar</span><span>Reimaginar</span>
                </div>
              </div>
            </div>
          </div>

          {error && <div className="p-3 bg-red-900/20 border border-red-500/20 rounded text-sm text-red-400">{error}</div>}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 px-5 py-4 border-t border-gray-700">
          <button onClick={onClose} className="px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white">
            Cancelar
          </button>
          {result ? (
            <button onClick={handleSave} disabled={saving}
              className="px-4 py-2 bg-green-600 hover:bg-green-500 disabled:bg-gray-600 rounded text-sm text-white font-medium">
              {saving ? 'Guardando...' : '💾 Guardar en biblioteca'}
            </button>
          ) : (
            <button onClick={handleGenerate} disabled={generating || !composedPrompt.trim()}
              className="px-4 py-2 bg-orange-600 hover:bg-orange-500 disabled:bg-gray-600 rounded text-sm text-white font-medium">
              {generating ? '⏳ Generando...' : '✨ Aplicar Style Guide'}
            </button>
          )}
        </div>
      </div>

      <Lightbox url={lightboxUrl} onClose={() => setLightboxUrl(null)} />
    </div>
  );
}
