// GuardMan Admin — CompareSlider v4
// Comparador antes/después con barra arrastrable

import { useState } from 'react';

interface CompareSliderProps {
  beforeUrl: string | null;
  afterUrl: string | null;
}

export function CompareSlider({ beforeUrl, afterUrl }: CompareSliderProps) {
  const [sliderPos, setSliderPos] = useState(50);

  if (!beforeUrl || !afterUrl) return null;

  const handleMouseDown = (e: React.MouseEvent) => {
    const container = e.currentTarget.parentElement!;
    const onMove = (me: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = Math.max(0, Math.min(100, ((me.clientX - rect.left) / rect.width) * 100));
      setSliderPos(x);
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  };

  return (
    <div className="space-y-2">
      <h5 className="text-[11px] font-medium text-cyan-300">Comparar antes/después</h5>
      <div className="relative overflow-hidden rounded border border-gray-600" style={{ height: '200px' }}>
        <img src={afterUrl} alt="After" className="absolute inset-0 w-full h-full object-contain" />
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
          <img src={beforeUrl} alt="Before" className="absolute inset-0 w-full h-full object-contain" style={{ width: `${100 / (sliderPos / 100)}%` }} />
        </div>
        <div
          className="absolute inset-y-0 cursor-ew-resize"
          style={{ left: `${sliderPos}%`, width: '3px' }}
          onMouseDown={handleMouseDown}
        >
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-6 bg-white rounded-full shadow-lg flex items-center justify-center">
            <div className="w-0.5 h-3 bg-gray-400" />
          </div>
        </div>
      </div>
      <div className="flex justify-between text-[9px] text-gray-500">
        <span>Original</span>
        <span>Editada</span>
      </div>
    </div>
  );
}
