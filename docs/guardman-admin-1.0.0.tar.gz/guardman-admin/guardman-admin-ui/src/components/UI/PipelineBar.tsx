// GuardMan Admin v13 — Pipeline Bar
// Reusable horizontal step indicator for workflows

interface PipelineStep {
  label: string;
  status: 'pending' | 'active' | 'done';
}

interface Props {
  steps: PipelineStep[];
}

const stepStyle = {
  done: {
    bg: '#10B981',
    color: '#fff',
    border: '#10B981',
    shadow: 'none',
  },
  active: {
    bg: '#3B82F6',
    color: '#fff',
    border: '#3B82F6',
    shadow: '0 0 12px rgba(59,130,246,0.3)',
  },
  pending: {
    bg: '#1A2744',
    color: '#5a6880',
    border: 'rgba(255,255,255,0.08)',
    shadow: 'none',
  },
};

export function PipelineBar({ steps }: Props) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 0,
      justifyContent: 'center', padding: '16px 0',
    }}>
      {steps.map((step, i) => {
        const s = stepStyle[step.status];
        const isLast = i === steps.length - 1;
        return (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 600,
                background: s.bg, color: s.color,
                border: `2px solid ${s.border}`,
                boxShadow: s.shadow,
                transition: 'all 150ms ease',
                flexShrink: 0,
              }}>
                {step.status === 'done' ? '✓' : i + 1}
              </div>
              <span style={{
                fontSize: 11, color: step.status === 'pending' ? '#5a6880' : '#8896ab',
                fontWeight: 500,
                whiteSpace: 'nowrap',
              }}>
                {step.label}
              </span>
            </div>
            {!isLast && (
              <div style={{
                width: 40, height: 2, margin: '0 4px',
                background: step.status === 'done' ? '#10B981' : 'rgba(255,255,255,0.08)',
                transition: 'background 150ms ease',
              }} />
            )}
          </div>
        );
      })}
    </div>
  );
}
