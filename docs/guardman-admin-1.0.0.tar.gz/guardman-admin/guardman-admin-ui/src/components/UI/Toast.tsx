// GuardMan Admin v13 — Toast Notification System

import { useEffect, useState, useCallback, createContext, useContext } from 'react';

type ToastType = 'success' | 'error' | 'info';

interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  showToast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextType>({ showToast: () => {} });

export function useToast() {
  return useContext(ToastContext);
}

let globalShowToast: ((message: string, type?: ToastType) => void) | null = null;

/** Imperative API — call from anywhere without hooks */
export function toast(message: string, type: ToastType = 'info') {
  if (globalShowToast) globalShowToast(message, type);
  else console.warn('[Toast] ToastProvider not mounted:', message);
}

const config: Record<ToastType, { bg: string; border: string; color: string; icon: string }> = {
  success: { bg: '#064e3b', border: 'rgba(16,185,129,0.3)', color: '#6ee7b7', icon: '✓' },
  error: { bg: '#450a0a', border: 'rgba(239,68,68,0.3)', color: '#fca5a5', icon: '✗' },
  info: { bg: '#1A2744', border: 'rgba(59,130,246,0.3)', color: '#93c5fd', icon: 'ℹ' },
};

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev.slice(-4), { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  useEffect(() => {
    globalShowToast = showToast;
    return () => { globalShowToast = null; };
  }, [showToast]);

  const dismiss = (id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      {/* Render stack */}
      <div style={{
        position: 'fixed', bottom: 24, right: 24, zIndex: 2000,
        display: 'flex', flexDirection: 'column', gap: 8,
        pointerEvents: 'none',
      }}>
        {toasts.map(t => {
          const c = config[t.type];
          return (
            <div
              key={t.id}
              style={{
                padding: '10px 18px', borderRadius: 10,
                background: c.bg, color: c.color,
                border: `1px solid ${c.border}`,
                fontSize: 13, fontWeight: 500,
                boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
                display: 'flex', alignItems: 'center', gap: 8,
                animation: 'slideInRight 0.3s ease',
                pointerEvents: 'auto',
                cursor: 'pointer',
              }}
              onClick={() => dismiss(t.id)}
            >
              <span style={{ fontWeight: 700, fontSize: 14 }}>{c.icon}</span>
              {t.message}
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

/* Add keyframe if not already in globals.css */
const style = document.createElement('style');
style.textContent = `
  @keyframes slideInRight {
    from { opacity: 0; transform: translateX(20px); }
    to { opacity: 1; transform: translateX(0); }
  }
`;
if (!document.querySelector('style[data-toast]')) {
  style.setAttribute('data-toast', 'true');
  document.head.appendChild(style);
}
