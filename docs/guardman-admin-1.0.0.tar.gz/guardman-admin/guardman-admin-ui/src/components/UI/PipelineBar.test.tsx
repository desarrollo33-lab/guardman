import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { PipelineBar } from './PipelineBar';

describe('PipelineBar', () => {
  it('renders all steps', () => {
    const steps = [
      { label: 'CMS', status: 'done' as const },
      { label: 'Intel', status: 'active' as const },
      { label: 'Publish', status: 'pending' as const },
    ];
    render(<PipelineBar steps={steps} />);
    expect(screen.getByText('CMS')).toBeInTheDocument();
    expect(screen.getByText('Intel')).toBeInTheDocument();
    expect(screen.getByText('Publish')).toBeInTheDocument();
  });

  it('shows checkmark for done steps', () => {
    const steps = [{ label: 'Done', status: 'done' as const }, { label: 'Pending', status: 'pending' as const }];
    render(<PipelineBar steps={steps} />);
    expect(screen.getByText('✓')).toBeInTheDocument();
    expect(screen.getByText('2')).toBeInTheDocument();
  });

  it('renders without steps', () => {
    render(<PipelineBar steps={[]} />);
  });
});
