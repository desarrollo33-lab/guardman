import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { ToastProvider, useToast } from './Toast';

// Component that uses the toast hook
function TestConsumer({ onToast }: { onToast: (fn: any) => void }) {
  const { showToast } = useToast();
  onToast(showToast);
  return <div>Test</div>;
}

describe('Toast', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  it('renders children', () => {
    render(
      <ToastProvider>
        <div>Hello</div>
      </ToastProvider>
    );
    expect(screen.getByText('Hello')).toBeInTheDocument();
  });

  it('ToastProvider mounts without error', () => {
    render(<ToastProvider><div /></ToastProvider>);
  });

  it('showToast is callable via hook', () => {
    let showFn: any = null;
    render(
      <ToastProvider>
        <TestConsumer onToast={(fn) => { showFn = fn; }} />
      </ToastProvider>
    );
    expect(showFn).toBeDefined();
    // Calling should not throw
    expect(() => showFn('Test message', 'info')).not.toThrow();
  });
});
