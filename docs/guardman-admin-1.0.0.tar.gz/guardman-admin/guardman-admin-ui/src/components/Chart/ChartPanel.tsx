// GuardMan v1 — ChartPanel
// Simple chart component using Chart.js for coverage and score visualization
// No Dynamic Worker required - uses Chart.js directly in client
import { useEffect, useRef, useState } from 'react';

interface ChartData {
  chart_type?: string;
  title?: string;
  labels?: string[];
  datasets?: Array<{
    label: string;
    data: number[];
    color?: string;
    colors?: string[];
  }>;
  coverage?: { services: any[]; combos: { with_content: number; total_possible: number } };
  scores?: any[];
  gaps?: { services_with_gaps: number; total_services: number };
}

interface ChartPanelProps {
  onClose?: () => void;
  initialChart?: 'coverage' | 'scores' | 'gaps';
  chartData?: ChartData | null;
  activeChart?: 'coverage' | 'scores' | 'gaps' | null;
}

type ChartType = 'coverage' | 'scores' | 'gaps';

export function ChartPanel({ onClose, initialChart = 'coverage', chartData, activeChart }: ChartPanelProps) {
  const [tab, setTab] = useState<ChartType>(initialChart);
  const effectiveTab = activeChart || tab;
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstance = useRef<any>(null);

  // When chartData changes, determine the appropriate tab from the data
  useEffect(() => {
    if (chartData?.chart_type === 'doughnut') {
      setTab('gaps');
    } else if (chartData?.datasets) {
      // Check if this looks like scores data (has numeric scores not 0/1)
      const firstData = chartData.datasets[0]?.data || [];
      const looksLikeScores = firstData.length > 0 && typeof firstData[0] === 'number' && firstData[0] > 1;
      if (looksLikeScores) {
        setTab('scores');
      } else {
        setTab('coverage');
      }
    }
  }, [chartData]);

  useEffect(() => {
    if (!chartData) return;
    renderChart();
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, [chartData, effectiveTab]);

  const renderChart = () => {
    if (!window.Chart || !chartRef.current || !chartData) return;

    if (chartInstance.current) {
      chartInstance.current.destroy();
      chartInstance.current = null;
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    // Determine chart configuration based on effectiveTab and data
    let type: 'bar' | 'doughnut' = 'bar';
    let chartLabels: string[] = [];
    let chartDatasets: any[] = [];
    let title = chartData.title || '';

    if (effectiveTab === 'coverage' && chartData.datasets) {
      // Coverage: grouped bar chart
      type = 'bar';
      chartLabels = chartData.labels || [];
      title = chartData.title || 'Coverage por Servicio';

      chartDatasets = chartData.datasets.map((ds, i) => ({
        label: ds.label,
        data: ds.data,
        backgroundColor: ds.color === 'green'
          ? 'rgba(34, 197, 94, 0.8)'
          : ds.color === 'red'
            ? 'rgba(239, 68, 68, 0.8)'
            : 'rgba(34, 197, 94, 0.8)',
      }));
    } else if (effectiveTab === 'scores' && chartData.datasets) {
      // Scores: horizontal bar chart with color based on value
      type = 'bar';
      chartLabels = chartData.labels || [];
      title = chartData.title || 'Top Quality Scores';

      const scores = chartData.datasets[0]?.data || [];
      chartDatasets = [{
        label: chartData.datasets[0]?.label || 'Score',
        data: scores,
        backgroundColor: scores.map((v: number) =>
          v >= 85 ? 'rgba(34, 197, 94, 0.8)' :
          v >= 75 ? 'rgba(234, 179, 8, 0.8)' :
          'rgba(239, 68, 68, 0.8)'
        ),
      }];
    } else if (effectiveTab === 'gaps' && chartData.datasets) {
      // Gaps: doughnut chart
      type = 'doughnut';

      // Find "Con contenido" and "Sin contenido" data
      let withContent = 0;
      let missing = 0;

      if (chartData.datasets.length >= 2) {
        // Usually datasets[0] = Con contenido (1s or count), datasets[1] = Sin contenido (0s or count)
        const conData = chartData.datasets[0]?.data || [];
        const sinData = chartData.datasets[1]?.data || [];

        if (conData.length === 1 && typeof conData[0] === 'number') {
          // It's a total count format
          withContent = conData[0];
          missing = sinData[0];
        } else {
          // It's a per-service format - sum up
          withContent = conData.reduce((sum: number, v: number) => sum + (v > 0 ? 1 : 0), 0);
          missing = conData.length - withContent;
        }
      }

      chartDatasets = [{
        data: [withContent, missing],
        backgroundColor: ['rgba(34, 197, 94, 0.8)', 'rgba(239, 68, 68, 0.8)'],
      }];
      chartLabels = ['Con contenido', 'Faltante'];
      title = `Combos: ${withContent}/${withContent + missing} (${Math.round(withContent/(withContent+missing)*100)}%)`;
    } else {
      // Fallback
      type = 'bar';
      chartLabels = chartData.labels || [];
      chartDatasets = (chartData.datasets || []).map((ds) => ({
        label: ds.label,
        data: ds.data,
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
      }));
    }

    const isHorizontal = type === 'bar' && chartLabels.length > 4;

    chartInstance.current = new window.Chart(ctx, {
      type,
      data: { labels: chartLabels, datasets: chartDatasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: isHorizontal ? 'y' : 'x',
        plugins: {
          legend: { position: 'bottom', labels: { color: '#94a3b8' } },
          title: { display: true, text: title, color: '#fff' },
        },
        scales: type !== 'doughnut' ? {
          x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.1)' } },
          y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.1)' } },
        } : undefined,
      },
    });
  };

  // Calculate stats text
  let statsText = '';
  if (chartData?.datasets) {
    if (effectiveTab === 'gaps') {
      const conData = chartData.datasets[0]?.data || [];
      const sinData = chartData.datasets[1]?.data || [];
      const withContent = conData.length === 1 ? conData[0] : conData.filter((v: number) => v > 0).length;
      const missing = sinData.length === 1 ? sinData[0] : sinData.filter((v: number) => v > 0).length;
      statsText = `${withContent} combos con contenido, ${missing} faltantes`;
    } else if (effectiveTab === 'coverage') {
      const totalServices = chartData.labels?.length || 0;
      const withContent = chartData.datasets[0]?.data?.filter((v: number) => v > 0).length || 0;
      statsText = `${withContent}/${totalServices} servicios tienen al menos 1 combo`;
    } else if (effectiveTab === 'scores') {
      statsText = `Top ${chartData.labels?.length || 0} rankings`;
    }
  }

  const handleTabClick = (newTab: ChartType) => {
    if (!chartData) {
      setTab(newTab);
    }
    // If clicking on a different tab than the data type, we could show a prompt
    // For now, just allow switching
    setTab(newTab);
  };

  return (
    <div className="flex flex-col h-full bg-[#0c1222]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-[#0a0e1a]">
        <div className="flex items-center gap-3">
          <span className="text-lg">📊</span>
          <h3 className="text-white font-semibold">Charts & Analytics</h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleTabClick('coverage')}
            className={`text-xs px-2 py-1 rounded transition-colors ${
              effectiveTab === 'coverage' ? 'bg-blue-500/30 text-blue-400' : 'text-white/40 hover:text-white'
            }`}
          >
            Coverage
          </button>
          <button
            onClick={() => handleTabClick('scores')}
            className={`text-xs px-2 py-1 rounded transition-colors ${
              effectiveTab === 'scores' ? 'bg-blue-500/30 text-blue-400' : 'text-white/40 hover:text-white'
            }`}
          >
            Scores
          </button>
          <button
            onClick={() => handleTabClick('gaps')}
            className={`text-xs px-2 py-1 rounded transition-colors ${
              effectiveTab === 'gaps' ? 'bg-blue-500/30 text-blue-400' : 'text-white/40 hover:text-white'
            }`}
          >
            Gaps
          </button>
          {onClose && (
            <button onClick={onClose} className="text-white/30 hover:text-white ml-2">✕</button>
          )}
        </div>
      </div>

      {/* Chart container */}
      <div className="flex-1 p-4 min-h-0">
        {!chartData ? (
          <div className="flex items-center justify-center h-full">
            <div className="text-white/40 text-sm text-center">
              Pide al agente<br/>
              <span className="text-blue-400">"genera un gráfico de coverage"</span><br/>
              <span className="text-white/60">o "muéstrame los scores"</span>
            </div>
          </div>
        ) : (
          <div className="h-full min-h-[300px]">
            <canvas ref={chartRef} />
          </div>
        )}
      </div>

      {/* Stats summary */}
      {statsText && chartData && (
        <div className="border-t border-white/5 p-3">
          <div className="text-xs text-white/50">{statsText}</div>
        </div>
      )}
    </div>
  );
}

// TypeScript declaration for Chart.js loaded from CDN
declare global {
  interface Window {
    Chart: any;
  }
}