// GuardMan Admin v5.2 — Preview Frame with Device Toggle + SERP Preview + Logs Tab
import { useState, useEffect, useRef, useCallback } from 'react';
import { getToken } from '../../hooks/useApi';

interface PreviewFrameProps {
  entityType: string;
  entitySlug: string;
}

type Device = 'desktop' | 'tablet' | 'mobile';
type Tab = 'preview' | 'logs';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

const DEVICE_CONFIGS: Record<Device, { width: string; height: string; scale: number; label: string; icon: string }> = {
  desktop: { width: '100%', height: '100%', scale: 1, label: 'Desktop', icon: '🖥️' },
  tablet: { width: '768px', height: '1024px', scale: 0.6, label: 'Tablet', icon: '📱' },
  mobile: { width: '375px', height: '812px', scale: 0.5, label: 'Mobile', icon: '📲' },
};

interface LogEntry {
  id: number;
  timestamp: number;
  source: string;
  level: string;
  message: string;
  data?: any;
}

export function PreviewFrame({ entityType, entitySlug }: PreviewFrameProps) {
  const [device, setDevice] = useState<Device>('desktop');
  const [refreshKey, setRefreshKey] = useState(0);
  const [activeTab, setActiveTab] = useState<Tab>('preview');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);
  const previewUrl = `${API_BASE}/api/preview/${entityType}/${entitySlug}`;
  const config = DEVICE_CONFIGS[device];
  const sessionKey = `preview-${entityType}-${entitySlug}`;

  const loadLogs = useCallback(async () => {
    setLogsLoading(true);
    try {
      const token = getToken();
      const headers: Record<string, string> = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;
      const resp = await fetch(`${API_BASE}/api/monitor/logs?session=${sessionKey}&limit=50`, { headers });
      if (resp.ok) {
        const data = await resp.json();
        if (data.ok && data.data) {
          setLogs(data.data);
        }
      }
    } catch (e) {
      console.error('Failed to load logs:', e);
    }
    setLogsLoading(false);
  }, [sessionKey]);

  useEffect(() => {
    if (activeTab === 'logs') {
      loadLogs();
    }
  }, [activeTab, loadLogs]);

  useEffect(() => {
    if (activeTab === 'logs' && logs.length > 0) {
      logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, activeTab]);

  const levelColor = (level: string) => {
    switch (level) {
      case 'error': return 'text-red-400';
      case 'warn': return 'text-yellow-400';
      case 'debug': return 'text-white/30';
      default: return 'text-white/60';
    }
  };

  const levelBg = (level: string) => {
    switch (level) {
      case 'error': return 'bg-red-500/10';
      case 'warn': return 'bg-yellow-500/10';
      default: return 'bg-white/3';
    }
  };

  const exportLogs = () => {
    const json = JSON.stringify(logs, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `logs-${sessionKey}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#131D33] border-b border-white/10">
        {/* Tab switcher */}
        <button
          onClick={() => setActiveTab('preview')}
          className={`px-2.5 py-1.5 rounded text-xs font-medium transition-colors ${
            activeTab === 'preview' ? 'bg-accent/20 text-accent' : 'text-white/50 hover:text-white/70 hover:bg-white/5'
          }`}
        >
          👁️ Preview
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-2.5 py-1.5 rounded text-xs font-medium transition-colors ${
            activeTab === 'logs' ? 'bg-accent/20 text-accent' : 'text-white/50 hover:text-white/70 hover:bg-white/5'
          }`}
        >
          📋 Logs {logs.length > 0 && <span className="ml-1 text-white/30">({logs.length})</span>}
        </button>

        <div className="w-px h-4 bg-white/10 mx-1" />

        {/* Device toggle (preview tab only) */}
        {activeTab === 'preview' && (['desktop', 'tablet', 'mobile'] as Device[]).map(d => (
          <button
            key={d}
            onClick={() => setDevice(d)}
            className={`px-2.5 py-1.5 rounded text-xs font-medium transition-colors ${
              device === d ? 'bg-accent/20 text-accent' : 'text-white/50 hover:text-white/70 hover:bg-white/5'
            }`}
            title={DEVICE_CONFIGS[d].label}
          >
            {DEVICE_CONFIGS[d].icon} {DEVICE_CONFIGS[d].label}
          </button>
        ))}

        <div className="flex-1" />

        {activeTab === 'logs' && (
          <>
            <button
              onClick={loadLogs}
              className="text-xs text-white/40 hover:text-white/70 px-2 py-1 rounded hover:bg-white/5"
            >
              🔄 Refresh
            </button>
            <button
              onClick={exportLogs}
              className="text-xs text-white/40 hover:text-white/70 px-2 py-1 rounded hover:bg-white/5"
              disabled={logs.length === 0}
            >
              📥 Export
            </button>
          </>
        )}

        {activeTab === 'preview' && (
          <>
            <button
              onClick={() => setRefreshKey(k => k + 1)}
              className="text-xs text-white/40 hover:text-white/70 px-2 py-1 rounded hover:bg-white/5"
              title="Refrescar preview"
            >
              🔄
            </button>
            <a
              href={previewUrl}
              target="_blank"
              className="text-xs text-white/40 hover:text-white/70 px-2 py-1 rounded hover:bg-white/5"
              title="Abrir en nueva pestaña"
            >
              Abrir ↗
            </a>
          </>
        )}
      </div>

      {/* Content area */}
      {activeTab === 'preview' ? (
        <div className="flex-1 bg-gray-700/50 flex items-start justify-center overflow-auto p-4">
          <div
            style={{
              width: config.width,
              height: config.height,
              transform: device !== 'desktop' ? `scale(${config.scale})` : undefined,
              transformOrigin: 'top center',
            }}
            className="bg-white rounded-lg shadow-2xl overflow-hidden"
          >
            <iframe
              key={refreshKey}
              src={previewUrl}
              className="w-full h-full border-0"
              sandbox="allow-scripts"
              title={`Preview ${entityType}/${entitySlug}`}
            />
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-auto bg-[#0D1117] p-4 font-mono text-xs">
          {logsLoading && logs.length === 0 ? (
            <div className="flex items-center justify-center h-32 text-white/30">
              <div className="animate-spin mr-2">⏳</div> Cargando logs...
            </div>
          ) : logs.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 text-white/30">
              <div className="text-2xl mb-2">📋</div>
              <p>No hay logs para {entityType}/{entitySlug}</p>
              <p className="text-white/20 mt-1">Los logs de Dynamic Worker se capturarán aquí</p>
            </div>
          ) : (
            <div className="space-y-1">
              {logs.map(log => (
                <div
                  key={log.id}
                  className={`flex items-start gap-3 px-3 py-2 rounded ${levelBg(log.level)}`}
                >
                  <span className="text-white/20 flex-shrink-0 w-16">
                    {new Date(log.timestamp).toLocaleTimeString('es-CL')}
                  </span>
                  <span className={`flex-shrink-0 uppercase font-bold w-12 ${levelColor(log.level)}`}>
                    {log.level}
                  </span>
                  <span className="text-white/40 flex-shrink-0 w-24 truncate" title={log.source}>
                    {log.source}
                  </span>
                  <span className="text-white/70 flex-1">{log.message}</span>
                  {log.data && (
                    <span className="text-white/20 truncate max-w-48" title={JSON.stringify(log.data)}>
                      {JSON.stringify(log.data).substring(0, 60)}
                    </span>
                  )}
                </div>
              ))}
              <div ref={logsEndRef} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
