// GuardMan Admin — Brand DNA (ADN de Marca)
// Full CRUD: Create, Read, Update, Delete per field/category

import { useState, useEffect, useCallback, useRef } from 'react';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

// ===== Types =====
type BrandData = Record<string, Record<string, any>>;

interface FieldDef {
  key: string;
  label: string;
  type: 'text' | 'textarea' | 'color' | 'url';
  rows?: number;
  placeholder?: string;
}

interface CategoryMeta {
  label: string;
  icon: string;
  description: string;
  fields: FieldDef[];
}

// ===== Category Definitions =====
const CATEGORIES: Record<string, CategoryMeta> = {
  company: {
    label: 'Empresa',
    icon: '🏢',
    description: 'Datos legales y contacto',
    fields: [
      { key: 'brand_name', label: 'Nombre de Marca', type: 'text' },
      { key: 'legal_name', label: 'Razón Social', type: 'text' },
      { key: 'rut', label: 'RUT', type: 'text', placeholder: '76.XXX.XXX-X' },
      { key: 'tagline', label: 'Tagline / Slogan', type: 'text' },
      { key: 'description', label: 'Descripción Larga', type: 'textarea', rows: 4 },
      { key: 'short_description', label: 'Descripción Corta (SEO)', type: 'textarea', rows: 2 },
      { key: 'phone', label: 'Teléfono', type: 'text' },
      { key: 'phone_display', label: 'Teléfono (Display)', type: 'text' },
      { key: 'whatsapp', label: 'WhatsApp', type: 'text' },
      { key: 'email', label: 'Email Contacto', type: 'text' },
      { key: 'commercial_email', label: 'Email Comercial', type: 'text' },
      { key: 'address', label: 'Dirección Completa', type: 'text' },
      { key: 'address_street', label: 'Calle', type: 'text' },
      { key: 'address_city', label: 'Comuna', type: 'text' },
      { key: 'address_region', label: 'Región', type: 'text' },
      { key: 'postal_code', label: 'Código Postal', type: 'text' },
      { key: 'latitude', label: 'Latitud', type: 'text' },
      { key: 'longitude', label: 'Longitud', type: 'text' },
      { key: 'site_url', label: 'URL del Sitio', type: 'url' },
      { key: 'price_range', label: 'Rango de Precios', type: 'text' },
    ],
  },
  social: {
    label: 'Redes Sociales',
    icon: '📱',
    description: 'Perfiles y handles',
    fields: [
      { key: 'instagram', label: 'Instagram URL', type: 'url' },
      { key: 'instagram_handle', label: 'Handle Instagram', type: 'text', placeholder: '@grupo_guardman' },
      { key: 'youtube', label: 'YouTube URL', type: 'url' },
    ],
  },
  stats: {
    label: 'Estadísticas',
    icon: '📊',
    description: 'Números clave (usados en +158 páginas)',
    fields: [
      { key: 'years', label: 'Años Experiencia', type: 'text', placeholder: '8+' },
      { key: 'guards', label: 'Guardias', type: 'text', placeholder: '500+' },
      { key: 'clients', label: 'Clientes', type: 'text', placeholder: '200+' },
      { key: 'locations', label: 'Comunas', type: 'text', placeholder: '14' },
      { key: 'rating', label: 'Rating', type: 'text', placeholder: '4.8' },
      { key: 'rating_count', label: 'Total Reviews', type: 'text', placeholder: '127' },
    ],
  },
  hours: {
    label: 'Horarios',
    icon: '🕐',
    description: 'Horarios de atención',
    fields: [
      { key: 'summary', label: 'Resumen', type: 'text', placeholder: '24/7' },
      { key: 'schedule', label: 'Horario por día', type: 'json' as any },
    ],
  },
  voice: {
    label: 'Voz de Marca',
    icon: '🗣️',
    description: 'Tono y personalidad para contenido AI',
    fields: [
      { key: 'tone', label: 'Tono', type: 'textarea', rows: 2 },
      { key: 'audience', label: 'Audiencia', type: 'textarea', rows: 2 },
      { key: 'language', label: 'Idioma y Registro', type: 'text' },
      { key: 'personality', label: 'Personalidad', type: 'textarea', rows: 3 },
      { key: 'forbidden_words', label: 'Palabras Prohibidas', type: 'textarea', rows: 2 },
      { key: 'mandatory_mentions', label: 'Menciones Obligatorias', type: 'textarea', rows: 2 },
    ],
  },
  differentiators: {
    label: 'Diferenciadores',
    icon: '💎',
    description: 'Ventajas competitivas únicas de GuardMan',
    fields: [],  // Rendered dynamically as cards by StructuredCardEditor
  },
  exclusions: {
    label: 'Exclusiones',
    icon: '🚫',
    description: 'Lo que NO se debe decir',
    fields: [
      { key: 'no_competidores', label: 'No Competidores', type: 'textarea', rows: 2 },
      { key: 'no_garantias', label: 'No Garantías Absolutas', type: 'textarea', rows: 2 },
      { key: 'no_hype', label: 'No Hype Tecnológico', type: 'textarea', rows: 2 },
      { key: 'no_precios', label: 'No Precios Específicos', type: 'textarea', rows: 2 },
    ],
  },
  certifications: {
    label: 'Certificaciones',
    icon: '✅',
    description: 'Autorizaciones y certificaciones legales',
    fields: [
      { key: 'autorizacion_laboral', label: 'Autorización Laboral', type: 'textarea', rows: 2 },
      { key: 'seguro_rc', label: 'Seguro RC', type: 'textarea', rows: 2 },
      { key: 'os10', label: 'OS-10', type: 'textarea', rows: 2 },
      { key: 'antecedentes', label: 'Verif. Antecedentes', type: 'textarea', rows: 2 },
      { key: 'protocolos_carabineros', label: 'Protocolos Carabineros', type: 'textarea', rows: 2 },
    ],
  },
  usps: {
    label: 'USPs',
    icon: '⭐',
    description: 'Unique Selling Points — ventajas competitivas destacadas',
    fields: [],  // Rendered dynamically as cards by StructuredCardEditor
  },
  colors: {
    label: 'Colores',
    icon: '🎨',
    description: 'Paleta de marca, sectores y zonas',
    fields: [
      { key: 'primary_50', label: 'Primary 50', type: 'color' },
      { key: 'primary_100', label: 'Primary 100', type: 'color' },
      { key: 'primary_200', label: 'Primary 200', type: 'color' },
      { key: 'primary_300', label: 'Primary 300', type: 'color' },
      { key: 'primary_400', label: 'Primary 400', type: 'color' },
      { key: 'primary_500', label: 'Primary 500', type: 'color' },
      { key: 'primary_600', label: 'Primary 600 (Base)', type: 'color' },
      { key: 'primary_700', label: 'Primary 700', type: 'color' },
      { key: 'primary_800', label: 'Primary 800', type: 'color' },
      { key: 'primary_900', label: 'Primary 900', type: 'color' },
      { key: 'accent', label: 'Accent', type: 'color' },
      { key: 'accent_hover', label: 'Accent Hover', type: 'color' },
      { key: 'success', label: 'Success', type: 'color' },
      { key: 'warning', label: 'Warning', type: 'color' },
      { key: 'error', label: 'Error', type: 'color' },
    ],
  },
};

const CAT_ORDER = ['company', 'social', 'stats', 'hours', 'voice', 'differentiators', 'exclusions', 'certifications', 'usps', 'colors'];

// ===== Color Palette Preview =====
function PalettePreview({ colors }: { colors: Record<string, string> }) {
  const shades = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900]
    .map(n => ({ n, color: colors[`primary_${n}`] }))
    .filter(c => c.color);

  if (shades.length === 0) return null;

  return (
    <div className="mb-6 p-4 bg-white/[0.03] rounded-xl border border-white/5">
      <p className="text-[10px] text-white/30 uppercase tracking-wider mb-3">Paleta Primary</p>
      <div className="flex gap-1">
        {shades.map(({ n, color }) => (
          <div key={n} className="flex-1 text-center">
            <div
              className="w-full h-10 rounded-lg border border-white/10"
              style={{ backgroundColor: color }}
            />
            <span className="text-[9px] text-white/20 mt-1 block">{n}</span>
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-3">
        {colors.accent && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/10" style={{ backgroundColor: colors.accent + '20' }}>
            <div className="w-4 h-4 rounded" style={{ backgroundColor: colors.accent }} />
            <span className="text-[10px] text-white/50">Accent</span>
          </div>
        )}
        {colors.success && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/10" style={{ backgroundColor: colors.success + '20' }}>
            <div className="w-4 h-4 rounded" style={{ backgroundColor: colors.success }} />
            <span className="text-[10px] text-white/50">Success</span>
          </div>
        )}
        {colors.warning && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/10" style={{ backgroundColor: colors.warning + '20' }}>
            <div className="w-4 h-4 rounded" style={{ backgroundColor: colors.warning }} />
            <span className="text-[10px] text-white/50">Warning</span>
          </div>
        )}
        {colors.error && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/10" style={{ backgroundColor: colors.error + '20' }}>
            <div className="w-4 h-4 rounded" style={{ backgroundColor: colors.error }} />
            <span className="text-[10px] text-white/50">Error</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ===== Confirm Modal =====
function ConfirmModal({ title, message, onConfirm, onCancel }: {
  title: string; message: string; onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4" onClick={onCancel}>
      <div className="bg-[#1A2744] rounded-xl border border-white/10 w-full max-w-sm overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="px-5 py-4 border-b border-white/5">
          <h3 className="text-sm font-semibold">{title}</h3>
        </div>
        <div className="px-5 py-4">
          <p className="text-sm text-white/60">{message}</p>
        </div>
        <div className="px-5 py-3 flex gap-2 justify-end border-t border-white/5">
          <button onClick={onCancel} className="px-4 py-1.5 text-sm text-white/50 hover:text-white rounded-lg hover:bg-white/5">Cancelar</button>
          <button onClick={onConfirm} className="px-4 py-1.5 text-sm bg-red-600 hover:bg-red-700 rounded-lg font-medium">Eliminar</button>
        </div>
      </div>
    </div>
  );
}

// ===== Stats Bar =====
function StatsBar({ stats }: { stats: Record<string, any> }) {
  if (!stats || Object.keys(stats).length === 0) return null;
  const items = [
    { icon: '📅', value: stats.years, label: 'Años' },
    { icon: '👷', value: stats.guards, label: 'Guardias' },
    { icon: '🏢', value: stats.clients, label: 'Clientes' },
    { icon: '📍', value: stats.locations, label: 'Comunas' },
    { icon: '⭐', value: stats.rating, label: 'Rating' },
  ];

  return (
    <div className="grid grid-cols-5 gap-2 mb-5">
      {items.map(it => (
        <div key={it.label} className="bg-white/[0.03] border border-white/5 rounded-lg p-3 text-center">
          <div className="text-lg">{it.icon}</div>
          <div className="text-base font-semibold mt-1">{it.value || '—'}</div>
          <div className="text-[10px] text-white/30">{it.label}</div>
        </div>
      ))}
    </div>
  );
}

// ===== Main Component =====
export function ADNPage() {
  const [brand, setBrand] = useState<BrandData>({});
  const [originalBrand, setOriginalBrand] = useState<BrandData>({});
  const [activeCategory, setActiveCategory] = useState('company');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<{ category: string; key: string; label: string } | null>(null);
  const [showAddField, setShowAddField] = useState(false);
  const [newFieldKey, setNewFieldKey] = useState('');
  const [newFieldLabel, setNewFieldLabel] = useState('');
  const [newFieldType, setNewFieldType] = useState<'text' | 'textarea' | 'color' | 'url'>('text');
  const addFieldRef = useRef<HTMLInputElement>(null);

  const token = localStorage.getItem('gm_token');

  const fetchBrand = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/api/brand`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) {
        setBrand(data.data);
        setOriginalBrand(JSON.parse(JSON.stringify(data.data)));
      }
    } catch {
      showToast('Error al cargar', 'err');
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchBrand(); }, [fetchBrand]);

  const showToast = (msg: string, type: 'ok' | 'err' = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  // ===== Dirty detection =====
  const isDirty = JSON.stringify(brand) !== JSON.stringify(originalBrand);
  const catDirty = (cat: string) => JSON.stringify(brand[cat]) !== JSON.stringify(originalBrand[cat]);

  // ===== UPDATE: Save entire category =====
  const handleSave = async () => {
    setSaving(true);
    try {
      const catData = brand[activeCategory];
      if (!catData) return;

      const items = Object.entries(catData).map(([key, value]) => ({
        category: activeCategory,
        key,
        value: typeof value === 'object' ? JSON.stringify(value) : String(value),
      }));

      const res = await fetch(`${API_BASE}/api/brand`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
      });

      const data = await res.json();
      if (data.ok) {
        setOriginalBrand(JSON.parse(JSON.stringify(brand)));
        showToast('✅ Guardado');
      } else {
        showToast('❌ Error: ' + (data.error || 'desconocido'), 'err');
      }
    } catch {
      showToast('❌ Error de red', 'err');
    } finally {
      setSaving(false);
    }
  };

  // ===== UPDATE: Single field =====
  const handleSaveSingle = async (key: string) => {
    const value = brand[activeCategory]?.[key];
    if (value === undefined) return;
    try {
      const res = await fetch(`${API_BASE}/api/brand`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: [{ category: activeCategory, key, value: typeof value === 'object' ? JSON.stringify(value) : String(value) }] }),
      });
      const data = await res.json();
      if (data.ok) {
        setOriginalBrand(prev => ({
          ...prev,
          [activeCategory]: { ...(prev[activeCategory] || {}), [key]: value },
        }));
        showToast('✅ Campo guardado');
      }
    } catch {
      showToast('❌ Error', 'err');
    }
  };

  // ===== DELETE: Remove field =====
  const handleDelete = async (category: string, key: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/brand/${category}/${key}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) {
        setBrand(prev => {
          const next = { ...prev, [category]: { ...prev[category] } };
          delete next[category][key];
          return next;
        });
        setOriginalBrand(prev => {
          const next = { ...prev, [category]: { ...prev[category] } };
          delete next[category][key];
          return next;
        });
        showToast('🗑️ Eliminado');
      }
    } catch {
      showToast('❌ Error al eliminar', 'err');
    }
    setConfirmDelete(null);
  };

  // ===== CREATE: Add new field =====
  const handleAddField = () => {
    if (!newFieldKey.trim()) return;
    const key = newFieldKey.trim().toLowerCase().replace(/[^a-z0-9_]/g, '_').replace(/_+/g, '_');
    if (brand[activeCategory]?.[key] !== undefined) {
      showToast('❌ Ya existe esa key', 'err');
      return;
    }
    setBrand(prev => ({
      ...prev,
      [activeCategory]: {
        ...(prev[activeCategory] || {}),
        [key]: '',
      },
    }));
    setShowAddField(false);
    setNewFieldKey('');
    setNewFieldLabel('');
    showToast(`✅ Campo "${key}" agregado (guardar para persistir)`);
  };

  // ===== UNDO: Revert category =====
  const handleUndo = () => {
    setBrand(prev => ({
      ...prev,
      [activeCategory]: JSON.parse(JSON.stringify(originalBrand[activeCategory] || {})),
    }));
    showToast('↩️ Revertido');
  };

  // ===== REVERT ALL =====
  const handleRevertAll = () => {
    setBrand(JSON.parse(JSON.stringify(originalBrand)));
    showToast('↩️ Todo revertido');
  };

  const updateField = (category: string, key: string, value: any) => {
    setBrand(prev => ({
      ...prev,
      [category]: { ...(prev[category] || {}), [key]: value },
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="flex items-center gap-3 text-white/40">
          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          Cargando ADN...
        </div>
      </div>
    );
  }

  const catMeta = CATEGORIES[activeCategory];
  const catData = brand[activeCategory] || {};
  const definedKeys = new Set(catMeta?.fields.map(f => f.key) || []);
  const extraKeys = Object.keys(catData).filter(k => !definedKeys.has(k));
  const totalFields = CAT_ORDER.reduce((sum, id) => sum + Object.keys(brand[id] || {}).length, 0);
  const dirtyCats = CAT_ORDER.filter(id => catDirty(id));

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="shrink-0 border-b border-white/5 px-6 py-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-base font-semibold flex items-center gap-2">
              🧬 ADN de Marca
            </h1>
            <div className="flex items-center gap-3 text-[11px] text-white/25">
              <span>{totalFields} campos</span>
              <span>•</span>
              <span>{CAT_ORDER.length} categorías</span>
              {dirtyCats.length > 0 && (
                <>
                  <span>•</span>
                  <span className="text-amber-400/70">{dirtyCats.length} sin guardar</span>
                </>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isDirty && (
              <button
                onClick={handleRevertAll}
                className="px-3 py-1.5 text-xs text-white/40 hover:text-white rounded-lg hover:bg-white/5"
              >
                ↩ Revertir todo
              </button>
            )}
            <button
              onClick={handleSave}
              disabled={saving || !isDirty}
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-30
                disabled:cursor-not-allowed rounded-lg text-sm font-medium transition-colors flex items-center gap-2"
            >
              {saving ? (
                <><div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> Guardando...</>
              ) : (
                '💾 Guardar todo'
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-44 shrink-0 border-r border-white/5 overflow-y-auto">
          <nav className="p-2 space-y-0.5">
            {CAT_ORDER.map(id => {
              const meta = CATEGORIES[id];
              const isActive = activeCategory === id;
              const count = Object.keys(brand[id] || {}).length;
              const dirty = catDirty(id);
              return (
                <button
                  key={id}
                  onClick={() => setActiveCategory(id)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-[13px] flex items-center gap-2 transition-all relative
                    ${isActive
                      ? 'bg-blue-600/20 text-white'
                      : 'text-white/40 hover:text-white/70 hover:bg-white/[0.03]'
                    }`}
                >
                  {isActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r-full bg-blue-500" />}
                  <span className="text-sm">{meta.icon}</span>
                  <span className="flex-1 truncate">{meta.label}</span>
                  <div className="flex items-center gap-1">
                    {dirty && <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
                    <span className="text-[10px] text-white/15">{count}</span>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-3xl mx-auto p-6">
            {/* Category Header */}
            <div className="flex items-start justify-between mb-5">
              <div>
                <h2 className="text-[15px] font-medium flex items-center gap-2">
                  {catMeta.icon} {catMeta.label}
                </h2>
                <p className="text-xs text-white/25 mt-0.5">{catMeta.description}</p>
              </div>
              <div className="flex items-center gap-1.5">
                {catDirty(activeCategory) && (
                  <button onClick={handleUndo} className="px-2.5 py-1 text-[11px] text-amber-400/70 hover:text-amber-300 rounded-lg hover:bg-white/5">
                    ↩ Revertir
                  </button>
                )}
                <button
                  onClick={() => { setShowAddField(true); setTimeout(() => addFieldRef.current?.focus(), 100); }}
                  className="px-2.5 py-1 text-[11px] text-blue-400 hover:text-blue-300 rounded-lg hover:bg-white/5"
                >
                  + Campo
                </button>
              </div>
            </div>

            {/* Stats Preview (only for stats category) */}
            {activeCategory === 'stats' && <StatsBar stats={catData} />}
            {/* Palette Preview (only for colors category) */}
            {activeCategory === 'colors' && <PalettePreview colors={catData} />}

            {/* Add Field Form */}
            {showAddField && (
              <div className="mb-5 p-4 bg-blue-600/10 border border-blue-500/20 rounded-xl">
                <p className="text-xs text-blue-300/80 mb-3">Agregar nuevo campo a <strong>{catMeta.label}</strong></p>
                <div className="flex gap-2">
                  <input
                    ref={addFieldRef}
                    type="text"
                    value={newFieldKey}
                    onChange={e => setNewFieldKey(e.target.value)}
                    placeholder="key (ej: linkedin_url)"
                    className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm
                      text-white font-mono placeholder-white/20 focus:outline-none focus:border-blue-500/50"
                    onKeyDown={e => e.key === 'Enter' && handleAddField()}
                  />
                  <select
                    value={newFieldType}
                    onChange={e => setNewFieldType(e.target.value as any)}
                    className="bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-sm text-white focus:outline-none"
                  >
                    <option value="text">Texto</option>
                    <option value="textarea">Textarea</option>
                    <option value="url">URL</option>
                    <option value="color">Color</option>
                  </select>
                  <button
                    onClick={handleAddField}
                    disabled={!newFieldKey.trim()}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-30 rounded-lg text-sm"
                  >
                    Agregar
                  </button>
                  <button onClick={() => setShowAddField(false)} className="px-3 py-1.5 text-white/40 hover:text-white rounded-lg hover:bg-white/5 text-sm">
                    ✕
                  </button>
                </div>
              </div>
            )}

            {/* Structured card categories: USPs + Differentiators */}
            {(activeCategory === 'usps' || activeCategory === 'differentiators') ? (
              <StructuredCardEditor
                category={activeCategory}
                data={catData}
                onUpdate={(key, field, value) => {
                  // field is 'title', 'description', 'icon', or '__new__' for full JSON
                  if (field === '__new__') {
                    // Adding new card — value is full JSON string
                    updateField(activeCategory, key, value);
                  } else {
                    // Updating a single field inside the JSON object
                    const current = catData[key];
                    let parsed: any = {};
                    if (current && typeof current === 'object') parsed = { ...current };
                    else if (typeof current === 'string') { try { parsed = JSON.parse(current); } catch { parsed = {}; } }
                    parsed[field] = value;
                    updateField(activeCategory, key, JSON.stringify(parsed));
                  }
                }}
                onSave={(key) => handleSaveSingle(key)}
                onDelete={(key) => setConfirmDelete({ category: activeCategory, key, label: key })}
              />
            ) : (
            <div>
              {/* Defined Fields */}
              {catMeta?.fields.length > 0 && (
                <div className="space-y-3">
                  {catMeta.fields.map(field => {
                    const value = catData[field.key] ?? '';
                    const origValue = originalBrand[activeCategory]?.[field.key];
                    const isChanged = JSON.stringify(value) !== JSON.stringify(origValue ?? '');
                    return (
                      <FieldRow
                        key={field.key}
                        fieldKey={field.key}
                        label={field.label}
                        type={field.type}
                        value={value}
                        placeholder={field.placeholder}
                        rows={field.rows}
                        isChanged={isChanged}
                        canDelete={false}
                        onChange={v => updateField(activeCategory, field.key, v)}
                        onSave={() => handleSaveSingle(field.key)}
                        onDelete={() => setConfirmDelete({ category: activeCategory, key: field.key, label: field.label })}
                      />
                    );
                  })}
                </div>
              )}

              {/* Extra Fields (not in schema) */}
              {extraKeys.length > 0 && (
                <div>
                  <div className="mt-4 mb-3 flex items-center gap-2">
                    <div className="h-px flex-1 bg-white/5" />
                    <span className="text-[10px] text-white/20 uppercase tracking-wider">Campos extras</span>
                    <div className="h-px flex-1 bg-white/5" />
                  </div>
                  <div className="space-y-3">
                    {extraKeys.map(key => {
                      const value = catData[key];
                      const origValue = originalBrand[activeCategory]?.[key];
                      const isChanged = JSON.stringify(value) !== JSON.stringify(origValue ?? '');
                      return (
                        <FieldRow
                          key={key}
                          fieldKey={key}
                          label={key}
                          type="text"
                          value={value}
                          isChanged={isChanged}
                          canDelete={true}
                          onChange={v => updateField(activeCategory, key, v)}
                          onSave={() => handleSaveSingle(key)}
                          onDelete={() => setConfirmDelete({ category: activeCategory, key, label: key })}
                        />
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
            )}

            <div className="h-12" />
          </div>
        </div>
      </div>

      {/* Confirm Delete Modal */}
      {confirmDelete && (
        <ConfirmModal
          title="Eliminar campo"
          message={`¿Eliminar "${confirmDelete.label}" (${confirmDelete.category}.${confirmDelete.key})? Esta acción es inmediata.`}
          onConfirm={() => handleDelete(confirmDelete.category, confirmDelete.key)}
          onCancel={() => setConfirmDelete(null)}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-6 right-6 z-50 px-4 py-2.5 border rounded-xl shadow-2xl text-sm
          ${toast.type === 'ok' ? 'bg-[#0f2a1a] border-emerald-500/20 text-emerald-300' : 'bg-[#2a0f0f] border-red-500/20 text-red-300'}`}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}

// ===== Structured Card Editor (USPs + Differentiators) =====
const CARD_ICONS: { id: string; emoji: string }[] = [
  { id: 'shield-check', emoji: '🛡️' }, { id: 'eye', emoji: '👁️' }, { id: 'clock', emoji: '⏰' },
  { id: 'badge-check', emoji: '✅' }, { id: 'monitor', emoji: '📺' }, { id: 'zap', emoji: '⚡' },
  { id: 'users', emoji: '👥' }, { id: 'map-pin', emoji: '📍' }, { id: 'star', emoji: '⭐' },
  { id: 'award', emoji: '🏆' }, { id: 'check-circle', emoji: '✔️' }, { id: 'alert-triangle', emoji: '⚠️' },
  { id: 'smartphone', emoji: '📱' }, { id: 'lock', emoji: '🔒' }, { id: 'sun', emoji: '☀️' },
];

function StructuredCardEditor({ category, data, onUpdate, onSave, onDelete }: {
  category: string;
  data: Record<string, any>;
  onUpdate: (key: string, field: string, value: string) => void;
  onSave: (key: string) => void;
  onDelete: (key: string) => void;
}) {
  const entries = Object.entries(data);
  const [adding, setAdding] = useState(false);
  const [newKey, setNewKey] = useState('');

  // Parse any format into { title, description, icon }
  const parse = (raw: any): { title: string; description: string; icon: string } => {
    if (raw && typeof raw === 'object') return { title: raw.title || '', description: raw.description || '', icon: raw.icon || 'star' };
    if (typeof raw === 'string') {
      // Try JSON first
      try {
        const obj = JSON.parse(raw);
        if (obj.title) return { title: obj.title, description: obj.description || '', icon: obj.icon || 'star' };
      } catch {}
      // Legacy pipe format
      const parts = raw.split('|');
      return { title: parts[0] || '', description: parts[1] || '', icon: parts[2] || 'star' };
    }
    return { title: '', description: '', icon: 'star' };
  };

  const addCard = () => {
    if (!newKey.trim()) return;
    const key = newKey.trim().toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_');
    onUpdate(key, '__new__', JSON.stringify({ title: '', description: '', icon: 'star' }));
    setAdding(false);
    setNewKey('');
  };

  const label = category === 'usps' ? 'USP' : 'Diferenciador';

  return (
    <div className="space-y-3">
      {entries.map(([key, raw]) => {
        const card = parse(raw);
        return (
          <div key={key} className="group bg-white/[0.02] border border-white/[0.06] rounded-xl p-4 hover:border-white/10 transition-colors">
            {/* Header: key + delete */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] text-white/20 font-mono bg-white/5 px-2 py-0.5 rounded">{key}</span>
              <button
                onClick={() => onDelete(key)}
                className="opacity-0 group-hover:opacity-100 text-[10px] text-red-400 hover:text-red-300 transition-opacity"
              >🗑️</button>
            </div>

            {/* Title */}
            <input
              type="text"
              value={card.title}
              onChange={e => onUpdate(key, 'title', e.target.value)}
              placeholder={`Título del ${label}`}
              className="w-full bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2 text-sm font-semibold text-white placeholder-white/20 focus:outline-none focus:border-blue-500/40 mb-2"
            />

            {/* Description */}
            <textarea
              value={card.description}
              onChange={e => onUpdate(key, 'description', e.target.value)}
              placeholder={`Descripción del ${label}`}
              rows={2}
              className="w-full bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2 text-sm text-white/70 placeholder-white/15 focus:outline-none focus:border-blue-500/30 resize-none mb-3"
            />

            {/* Icon picker */}
            <div className="flex items-center gap-1 flex-wrap">
              <span className="text-[10px] text-white/20 mr-1">Icono:</span>
              {CARD_ICONS.map(({ id, emoji }) => (
                <button
                  key={id}
                  onClick={() => onUpdate(key, 'icon', id)}
                  className={`w-7 h-7 rounded text-xs flex items-center justify-center transition-all
                    ${card.icon === id ? 'bg-blue-600/30 ring-1 ring-blue-500/50 scale-110' : 'bg-white/5 hover:bg-white/10'}`}
                  title={id}
                >{emoji}</button>
              ))}
            </div>

            {/* Save */}
            <button
              onClick={() => onSave(key)}
              className="mt-3 w-full py-1.5 text-[11px] text-blue-300 hover:text-blue-200 bg-blue-600/10 hover:bg-blue-600/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
            >💾 Guardar</button>
          </div>
        );
      })}

      {/* Add new */}
      {adding ? (
        <div className="bg-blue-600/10 border border-blue-500/20 rounded-xl p-4">
          <input
            type="text"
            value={newKey}
            onChange={e => setNewKey(e.target.value)}
            placeholder={`key (ej: tecnologia_propia)`}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white font-mono placeholder-white/20 focus:outline-none focus:border-blue-500/50 mb-2"
            onKeyDown={e => e.key === 'Enter' && addCard()}
            autoFocus
          />
          <div className="flex gap-2">
            <button onClick={addCard} disabled={!newKey.trim()} className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-30 rounded-lg text-xs">Agregar</button>
            <button onClick={() => { setAdding(false); setNewKey(''); }} className="px-3 py-1.5 text-white/40 hover:text-white text-xs">Cancelar</button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setAdding(true)}
          className="w-full py-3 border border-dashed border-white/10 rounded-xl text-xs text-white/25 hover:text-white/40 hover:border-white/20 transition-colors"
        >+ Agregar {label}</button>
      )}
    </div>
  );
}

// ===== Schedule Editor =====
function ScheduleEditor({ value, onChange }: { value: any; onChange: (v: string) => void }) {
  const days = ['Lunes', 'Martes', 'Mi\u00e9rcoles', 'Jueves', 'Viernes', 'S\u00e1bado', 'Domingo'];
  let schedule: { day: string; hours: string }[] = [];
  try {
    schedule = typeof value === 'string' ? JSON.parse(value) : Array.isArray(value) ? value : [];
  } catch { schedule = []; }

  // Ensure all days exist
  if (schedule.length === 0) {
    schedule = days.map(day => ({ day, hours: '24 horas' }));
  }

  const updateDay = (idx: number, hours: string) => {
    const next = [...schedule];
    next[idx] = { ...next[idx], hours };
    onChange(JSON.stringify(next));
  };

  const setAll = (hours: string) => {
    onChange(JSON.stringify(schedule.map(s => ({ ...s, hours }))));
  };

  return (
    <div className="space-y-1.5">
      {/* Quick actions */}
      <div className="flex gap-2 mb-2">
        <button onClick={() => setAll('24 horas')} className="px-2.5 py-1 text-[10px] text-white/40 hover:text-white rounded bg-white/5 hover:bg-white/10">Todos 24h</button>
        <button onClick={() => setAll('09:00 - 18:00')} className="px-2.5 py-1 text-[10px] text-white/40 hover:text-white rounded bg-white/5 hover:bg-white/10">Todos 9-18h</button>
        <button onClick={() => setAll('Cerrado')} className="px-2.5 py-1 text-[10px] text-white/40 hover:text-white rounded bg-white/5 hover:bg-white/10">Todos cerrado</button>
      </div>
      {schedule.map((item, idx) => (
        <div key={item.day} className="flex items-center gap-3">
          <span className="text-xs text-white/40 w-20 shrink-0">{item.day}</span>
          <input
            type="text"
            value={item.hours}
            onChange={e => updateDay(idx, e.target.value)}
            className="flex-1 bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-1.5 text-sm
              text-white focus:outline-none focus:border-blue-500/40"
          />
        </div>
      ))}
    </div>
  );
}

// ===== Field Row Component =====
function FieldRow({ fieldKey, label, type, value, placeholder, rows, isChanged, canDelete, onChange, onSave, onDelete }: {
  fieldKey: string;
  label: string;
  type: string;
  value: any;
  placeholder?: string;
  rows?: number;
  isChanged: boolean;
  canDelete: boolean;
  onChange: (v: string) => void;
  onSave: () => void;
  onDelete: () => void;
}) {
  return (
    <div className={`group rounded-lg border px-4 py-3 transition-colors
      ${isChanged ? 'border-blue-500/30 bg-blue-500/[0.04]' : 'border-white/[0.04] bg-white/[0.01]'}`}>
      <div className="flex items-start gap-4">
        {/* Label + Input */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <label className="text-[11px] text-white/40 font-mono">{label}</label>
            {isChanged && (
              <span className="text-[9px] text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded">modificado</span>
            )}
          </div>
          {type === 'json' && fieldKey === 'schedule' ? (
            <ScheduleEditor value={value} onChange={onChange} />
          ) : type === 'json' ? (
            <textarea
              value={typeof value === 'string' ? value : JSON.stringify(value, null, 2)}
              onChange={e => onChange(e.target.value)}
              rows={4}
              className="w-full bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2 text-sm
                text-white font-mono placeholder-white/15 focus:outline-none focus:border-blue-500/40 resize-none"
            />
          ) : type === 'textarea' ? (
            <textarea
              value={value}
              onChange={e => onChange(e.target.value)}
              rows={rows || 3}
              placeholder={placeholder}
              className="w-full bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2 text-sm
                text-white placeholder-white/15 focus:outline-none focus:border-blue-500/40 resize-none"
            />
          ) : type === 'color' ? (
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={value || '#000000'}
                onChange={e => onChange(e.target.value)}
                className="w-9 h-8 rounded-lg border border-white/10 bg-transparent cursor-pointer"
              />
              <input
                type="text"
                value={value}
                onChange={e => onChange(e.target.value)}
                className="flex-1 bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-1.5 text-sm
                  text-white font-mono focus:outline-none focus:border-blue-500/40"
              />
              {value && (
                <div className="w-7 h-7 rounded-lg border border-white/10 shadow-inner" style={{ backgroundColor: value }} />
              )}
            </div>
          ) : (
            <input
              type={type === 'url' ? 'url' : 'text'}
              value={value}
              onChange={e => onChange(e.target.value)}
              placeholder={placeholder}
              className="w-full bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2 text-sm
                text-white placeholder-white/15 focus:outline-none focus:border-blue-500/40"
            />
          )}
        </div>
        {/* Actions */}
        <div className="flex flex-col gap-1 pt-5 opacity-0 group-hover:opacity-100 transition-opacity">
          {isChanged && (
            <button
              onClick={onSave}
              className="px-2 py-1 text-[10px] text-blue-300 hover:text-blue-200 bg-blue-600/10 hover:bg-blue-600/20 rounded"
              title="Guardar este campo"
            >
              💾
            </button>
          )}
          {canDelete && (
            <button
              onClick={onDelete}
              className="px-2 py-1 text-[10px] text-red-400 hover:text-red-300 bg-red-600/10 hover:bg-red-600/20 rounded"
              title="Eliminar campo"
            >
              🗑️
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
