// GuardMan Intel — Content Strategy View
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';

export function ContentStrategyView() {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);
  const [tab, setTab] = useState<'pages' | 'refresh' | 'faqs' | 'roi'>('pages');

  useEffect(() => {
    Promise.all([
      api('/api/intel/content-strategy').catch(() => null),
      api('/api/intel/content-roi').catch(() => null),
    ]).then(([cs, roi]) => setData({ ...cs, roi }));
  }, []);

  if (loading && !data) return <div className="flex items-center justify-center h-64 text-white/30">Cargando estrategia...</div>;

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold text-white">Content Strategy</h2>
        <div className="flex gap-2">
          {([
            { id: 'pages' as const, label: '📄 Prioridad' },
            { id: 'refresh' as const, label: '🔄 Refrescar' },
            { id: 'faqs' as const, label: '❓ FAQs' },
            { id: 'roi' as const, label: '💰 ROI' },
          ]).map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-3 py-1.5 text-sm rounded-lg ${tab === t.id ? 'bg-blue-600 text-white' : 'bg-white/5 text-white/40'}`}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === 'pages' && <PriorityPages pages={data?.priority_pages || []} />}
      {tab === 'refresh' && <RefreshCandidates candidates={data?.refresh_candidates || []} />}
      {tab === 'faqs' && <FAQOpps faqs={data?.faq_opportunities || []} />}
      {tab === 'roi' && <ContentROI data={data?.roi} />}
    </div>
  );
}

function PriorityPages({ pages }: { pages: any[] }) {
  return (
    <div className="space-y-3">
      <p className="text-xs text-white/30">{pages.length} combos sin presencia GuardMan donde hay demanda de búsqueda</p>
      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/5">
              <th className="text-left p-3 text-white/40 text-xs">Servicio</th>
              <th className="text-left p-3 text-white/40 text-xs">Comuna</th>
              <th className="text-center p-3 text-white/40 text-xs">Demanda</th>
              <th className="text-center p-3 text-white/40 text-xs">Competidores</th>
              <th className="text-left p-3 text-white/40 text-xs">Sample Queries</th>
            </tr>
          </thead>
          <tbody>
            {pages.map((p, i) => (
              <tr key={i} className="border-b border-white/[0.03] hover:bg-white/[0.02]">
                <td className="p-3 text-white/60">{p.service_slug?.replace(/-/g, ' ')}</td>
                <td className="p-3 text-white/60">{p.location_slug?.replace(/-/g, ' ')}</td>
                <td className="p-3 text-center text-blue-400">{p.demand_queries}</td>
                <td className="p-3 text-center text-orange-400">{p.competitors}</td>
                <td className="p-3 text-xs text-white/30 max-w-xs truncate">{(p.sample_queries || '').substring(0, 80)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RefreshCandidates({ candidates }: { candidates: any[] }) {
  return (
    <div className="space-y-3">
      <p className="text-xs text-white/30">{candidates.length} combos en pos 4-10 que podrían mejorar con mejor contenido</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {candidates.map((c, i) => (
          <div key={i} className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-4 flex items-center justify-between">
            <div>
              <p className="text-sm text-white/70">{c.service_slug?.replace(/-/g, ' ')}</p>
              <p className="text-xs text-white/30">{c.location_slug?.replace(/-/g, ' ')} · {c.queries} queries</p>
            </div>
            <span className="text-lg font-bold text-yellow-400">#{c.best_pos}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function FAQOpps({ faqs }: { faqs: any[] }) {
  return (
    <div className="space-y-3">
      <p className="text-xs text-white/30">{faqs.length} preguntas reales de Google que podrías responder</p>
      <div className="space-y-2">
        {faqs.map((f, i) => (
          <div key={i} className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-4">
            <p className="text-sm text-white/70">❓ {f.question}</p>
            <div className="flex gap-2 mt-2">
              {f.service_slug && <span className="text-[10px] bg-white/5 px-1.5 py-0.5 rounded text-white/30">{f.service_slug.replace(/-/g, ' ')}</span>}
              <span className="text-[10px] bg-purple-500/10 px-1.5 py-0.5 rounded text-purple-300">{f.frequency}× vista</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ContentROI({ data }: { data: any }) {
  if (!data) return <p className="text-white/20">Sin datos de ROI</p>;
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-5 text-center">
        <div className="text-3xl font-bold text-blue-400">{data.published_pages || 0}</div>
        <div className="text-xs text-white/30 mt-1">Páginas publicadas</div>
      </div>
      <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-5 text-center">
        <div className="text-3xl font-bold text-emerald-400">{data.published_with_serper_presence || 0}</div>
        <div className="text-xs text-white/30 mt-1">Con presencia SEO</div>
      </div>
      <div className="bg-purple-500/10 border border-purple-500/20 rounded-xl p-5 text-center">
        <div className="text-3xl font-bold text-purple-400">{data.leads_from_published || 0}</div>
        <div className="text-xs text-white/30 mt-1">Leads desde contenido</div>
      </div>
      <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-5 text-center">
        <div className="text-2xl font-bold text-orange-400">{data.pipeline_from_published ? `$${(data.pipeline_from_published / 1000000).toFixed(1)}M` : '—'}</div>
        <div className="text-xs text-white/30 mt-1">Pipeline desde contenido</div>
      </div>
    </div>
  );
}
