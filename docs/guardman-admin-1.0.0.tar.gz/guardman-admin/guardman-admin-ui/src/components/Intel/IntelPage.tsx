// GuardMan Admin v3.0 — Intel Hub
import { useState } from 'react';
import { IntelDashboard } from './IntelDashboard';

type IntelTab = 'overview' | 'competitors' | 'opportunities' | 'reports';

const TABS: { id: IntelTab; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'competitors', label: 'Competidores' },
  { id: 'opportunities', label: 'Oportunidades' },
  { id: 'reports', label: 'Reportes' },
];

export function IntelPage() {
  const [tab, setTab] = useState<IntelTab>('overview');

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      <div className="tabs">
        {TABS.map(t => (
          <div key={t.id} className={`tab${tab === t.id ? ' active' : ''}`} onClick={() => setTab(t.id)}>
            {t.label}
          </div>
        ))}
      </div>
      <div style={{flex:1,overflowY:'auto'}}>
        {tab === 'overview' && <IntelDashboard onNavigate={(t: any) => setTab(t)} onSelectLead={() => {}} />}
        {tab !== 'overview' && (
          <div className="panel">
            <div className="panel-header"><h3>{TABS.find(t => t.id === tab)?.label}</h3></div>
            <div className="empty-state">
              <div className="empty-icon">📊</div>
              <h3>Vista en desarrollo</h3>
              <p>Esta sección estará disponible próximamente con datos reales de Serper.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
