// GuardMan Intel — Competitor View
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';

export function CompetitorView() {
  const { api, loading } = useApi();
  const [competitors, setCompetitors] = useState<any[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    api('/api/intel/competitors').then((data: any) => {
      setCompetitors(Array.isArray(data) ? data : []);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (selected) {
      api(`/api/intel/competitors/${encodeURIComponent(selected)}`).then(setProfile).catch(() => {});
    } else {
      setProfile(null);
    }
  }, [selected]);

  if (loading && competitors.length === 0) return <div className="flex items-center justify-center h-64 text-white/30">Cargando competidores...</div>;

  return (
    <div className="flex h-full">
      {/* List */}
      <div className="w-80 border-r border-white/5 bg-[#0f1729] overflow-y-auto shrink-0">
        <div className="p-4 border-b border-white/5">
          <h2 className="text-sm font-bold text-white/70 uppercase tracking-wider">Competidores ({competitors.length})</h2>
        </div>
        <div className="divide-y divide-white/[0.03]">
          {competitors.map((c: any, i: number) => (
            <div
              key={c.domain}
              onClick={() => setSelected(c.domain)}
              className={`p-3 cursor-pointer transition-colors ${selected === c.domain ? 'bg-blue-600/10 border-l-2 border-blue-500' : 'hover:bg-white/[0.02]'}`}
            >
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-sm text-white truncate">{c.domain}</p>
                  <p className="text-xs text-white/30">{c.label || c.site_type}</p>
                </div>
                <div className="text-right shrink-0 ml-2">
                  <p className="text-lg font-bold text-white/60">#{i + 1}</p>
                  <p className="text-[10px] text-white/20">{c.appearances} apariciones</p>
                </div>
              </div>
              {/* Presence bar */}
              <div className="mt-2 h-1 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500/40 rounded-full" style={{ width: `${Math.min(100, (c.appearances / (competitors[0]?.appearances || 1)) * 100)}%` }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detail */}
      <div className="flex-1 overflow-y-auto p-6">
        {!selected ? (
          <div className="flex items-center justify-center h-full text-white/20">
            Selecciona un competidor para ver su perfil
          </div>
        ) : !profile ? (
          <div className="flex items-center justify-center h-full text-white/20">Cargando perfil...</div>
        ) : (
          <CompetitorProfile domain={selected} data={profile} />
        )}
      </div>
    </div>
  );
}

function CompetitorProfile({ domain, data }: { domain: string; data: any }) {
  const summary = data.summary || {};
  const whereWeWin = data.where_we_win || [];
  const whereWeLose = data.where_we_lose || [];
  const weaknesses = summary.detected_weaknesses || [];
  const strengths = summary.detected_strengths || [];

  return (
    <div className="max-w-3xl space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">{domain}</h2>
          <p className="text-sm text-white/30 mt-1">
            {summary.appearances || 0} apariciones · {summary.services?.length || 0} servicios · {summary.locations?.length || 0} comunas
          </p>
          <p className="text-sm text-white/40 mt-1">
            Pos promedio: {summary.avg_position || '—'} · Mejor: {summary.best_position ? `#${summary.best_position}` : '—'}
          </p>
        </div>
        {data.profile?.threat_level && (
          <span className={`text-sm px-3 py-1 rounded-full font-medium ${threatColors(data.profile.threat_level)}`}>
            Amenaza: {data.profile.threat_level.toUpperCase()}
          </span>
        )}
      </div>

      {/* Services & Locations */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-4">
          <h3 className="text-sm font-medium text-white/50 mb-2">Servicios donde compite</h3>
          <div className="flex flex-wrap gap-1">
            {(summary.services || []).map((s: string) => (
              <span key={s} className="text-xs bg-white/5 text-white/50 px-2 py-1 rounded">{s.replace(/-/g, ' ')}</span>
            ))}
          </div>
        </div>
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-4">
          <h3 className="text-sm font-medium text-white/50 mb-2">Comunas donde compite</h3>
          <div className="flex flex-wrap gap-1">
            {(summary.locations || []).map((l: string) => (
              <span key={l} className="text-xs bg-white/5 text-white/50 px-2 py-1 rounded">{l.replace(/-/g, ' ')}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Battle Card */}
      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
        <h3 className="text-sm font-medium text-white/50 mb-4">⚔️ Battle Card vs GuardMan</h3>
        <div className="grid grid-cols-2 gap-6">
          <div>
            <h4 className="text-xs text-emerald-400/70 uppercase mb-2">✅ Donde LE GANAMOS ({whereWeWin.length})</h4>
            <div className="space-y-1.5">
              {whereWeWin.length === 0 ? <p className="text-xs text-white/20">Sin datos</p> : whereWeWin.slice(0, 8).map((r: any, i: number) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="text-white/40">{r.service_slug?.replace(/-/g, ' ')} · {r.location_slug?.replace(/-/g, ' ')}</span>
                  <span className="text-emerald-400">#{r.our_pos} vs #{r.their_pos}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-xs text-red-400/70 uppercase mb-2">⚠️ Donde NOS GANA ({whereWeLose.length})</h4>
            <div className="space-y-1.5">
              {whereWeLose.length === 0 ? <p className="text-xs text-white/20">Sin datos</p> : whereWeLose.slice(0, 8).map((r: any, i: number) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="text-white/40">{r.service_slug?.replace(/-/g, ' ')} · {r.location_slug?.replace(/-/g, ' ')}</span>
                  <span className="text-red-400">#{r.our_pos} vs #{r.their_pos}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Strengths & Weaknesses */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-orange-400/70 mb-3">💪 Fortalezas detectadas</h3>
          {strengths.length === 0 ? <p className="text-xs text-white/20">Sin fortalezas detectadas automáticamente</p> : (
            <ul className="space-y-1">{strengths.map((s: string, i: number) => <li key={i} className="text-sm text-white/50">• {s}</li>)}</ul>
          )}
        </div>
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-emerald-400/70 mb-3">🎯 Debilidades detectadas</h3>
          {weaknesses.length === 0 ? <p className="text-xs text-white/20">Sin debilidades detectadas automáticamente</p> : (
            <ul className="space-y-1">{weaknesses.map((w: string, i: number) => <li key={i} className="text-sm text-white/50">• {w}</li>)}</ul>
          )}
        </div>
      </div>
    </div>
  );
}

function threatColors(level: string): string {
  const map: Record<string, string> = {
    low: 'bg-emerald-500/15 text-emerald-300',
    medium: 'bg-yellow-500/15 text-yellow-300',
    high: 'bg-orange-500/15 text-orange-300',
    critical: 'bg-red-500/15 text-red-300',
  };
  return map[level] || 'bg-gray-500/15 text-gray-300';
}
