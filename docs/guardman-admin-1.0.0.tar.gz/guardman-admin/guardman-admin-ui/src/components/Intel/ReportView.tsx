// GuardMan Intel — Report View
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { formatMoney } from './IntelDashboard';

export function ReportView() {
  const { api, loading } = useApi();
  const [report, setReport] = useState<any>(null);

  useEffect(() => {
    api('/api/intel/report/latest').then(setReport).catch(() => {});
  }, []);

  const handleGenerate = async () => {
    try {
      const r = await api('/api/intel/report/generate', { method: 'POST', body: JSON.stringify({}) });
      setReport(r);
    } catch {}
  };

  if (loading && !report) return <div className="flex items-center justify-center h-64 text-white/30">Cargando reporte...</div>;

  if (!report) return (
    <div className="p-6 text-center">
      <p className="text-white/30 mb-4">No hay reporte disponible</p>
      <button onClick={handleGenerate} className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium">
        Generar Reporte Intel
      </button>
    </div>
  );

  const seo = report.seo || {};
  const leads = report.leads?.by_status || [];
  const clients = report.clients || {};
  const topComp = report.top_competitors || [];
  const gaps = report.priority_gaps || [];

  const totalLeads = leads.reduce((s: number, r: any) => s + (r.cnt || 0), 0);
  const pipelineValue = leads.reduce((s: number, r: any) => s + (r.value || 0), 0);

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">📊 Reporte Intel — {report.date}</h2>
          <p className="text-xs text-white/30">Generado automáticamente</p>
        </div>
        <button onClick={handleGenerate} className="px-4 py-2 bg-white/5 text-white/50 text-sm rounded-lg hover:bg-white/10">
          🔄 Regenerar
        </button>
      </div>

      {/* Executive summary */}
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl border border-blue-500/20 p-6">
        <h3 className="text-white/60 text-sm uppercase tracking-wider mb-4">Resumen Ejecutivo</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div><span className="text-2xl font-bold text-white">{totalLeads}</span><span className="text-xs text-white/30 ml-2">Leads totales</span></div>
          <div><span className="text-2xl font-bold text-emerald-400">{formatMoney(pipelineValue)}</span><span className="text-xs text-white/30 ml-2">Pipeline</span></div>
          <div><span className="text-2xl font-bold text-blue-400">{seo.top3 || 0}</span><span className="text-xs text-white/30 ml-2">TOP 3 SEO</span></div>
          <div><span className="text-2xl font-bold text-orange-400">{seo.competitors || 0}</span><span className="text-xs text-white/30 ml-2">Competidores</span></div>
        </div>
      </div>

      {/* Two columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* CRM */}
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-white/50 mb-3">💼 CRM Pipeline</h3>
          <div className="space-y-2">
            {leads.map((l: any, i: number) => (
              <div key={i} className="flex items-center justify-between text-sm">
                <span className="text-white/50">{l.status}</span>
                <div className="flex items-center gap-3">
                  <span className="text-white/70">{l.cnt} leads</span>
                  <span className="text-white/30">{formatMoney(l.value)}</span>
                </div>
              </div>
            ))}
            <div className="pt-2 border-t border-white/5">
              <div className="flex justify-between text-sm">
                <span className="text-white/50">Clientes activos</span>
                <span className="text-white/70">{clients.total || 0} · MRR {formatMoney(clients.active_mrr || 0)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* SEO */}
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-white/50 mb-3">📈 SEO & Posiciones</h3>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 bg-emerald-500/5 rounded-lg">
              <div className="text-xl font-bold text-emerald-400">{seo.top3 || 0}</div>
              <div className="text-[10px] text-white/30">TOP 3</div>
            </div>
            <div className="text-center p-3 bg-yellow-500/5 rounded-lg">
              <div className="text-xl font-bold text-yellow-400">{seo.top10 || 0}</div>
              <div className="text-[10px] text-white/30">TOP 10</div>
            </div>
            <div className="text-center p-3 bg-red-500/5 rounded-lg">
              <div className="text-xl font-bold text-red-400">{seo.competitors || 0}</div>
              <div className="text-[10px] text-white/30">Competidores</div>
            </div>
          </div>
        </div>
      </div>

      {/* Top Competitors */}
      {topComp.length > 0 && (
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-white/50 mb-3">⚔️ Top 5 Competidores</h3>
          <div className="space-y-2">
            {topComp.map((c: any, i: number) => (
              <div key={i} className="flex items-center justify-between p-2 bg-white/[0.02] rounded-lg">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-white/20">#{i + 1}</span>
                  <span className="text-sm text-white/60">{c.domain}</span>
                </div>
                <div className="text-xs text-white/30">{c.appearances} apariciones · pos {c.avg_pos}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Priority Gaps */}
      {gaps.length > 0 && (
        <div className="bg-[#1A2744]/60 rounded-xl border border-red-500/10 p-5">
          <h3 className="text-sm font-medium text-red-300 mb-3">🎯 Gaps Prioritarios ({gaps.length})</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {gaps.slice(0, 10).map((g: any, i: number) => (
              <div key={i} className="flex items-center justify-between p-2 bg-red-500/5 rounded-lg">
                <span className="text-xs text-white/50">{g.service_slug?.replace(/-/g, ' ')} · {g.location_slug?.replace(/-/g, ' ')}</span>
                <span className="text-xs text-red-400">{g.queries} queries</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
