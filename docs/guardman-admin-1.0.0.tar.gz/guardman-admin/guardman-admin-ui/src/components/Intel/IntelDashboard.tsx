// GuardMan Intel — Dashboard Overview (Market Intelligence only)
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';

interface Props {
  onNavigate: (tab: string) => void;
  onSelectLead: (id: number) => void;
}

export function IntelDashboard({ onNavigate }: Props) {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);

  const syncCompetitors = async () => {
    try {
      const result = await api('/api/intel/competitors/sync', { method: 'POST', body: JSON.stringify({}) });
      alert(`Sincronizados ${result.synced} competidores`);
    } catch (err: any) { alert('Error: ' + err.message); }
  };

  useEffect(() => {
    api('/api/intel/dashboard').then(setData).catch(() => {});
  }, []);

  if (loading && !data) return <div className="flex items-center justify-center h-64 text-white/30">Cargando inteligencia...</div>;
  if (!data) return <div className="p-6 text-red-400">Error cargando datos de Intel.</div>;

  const market = data.market || {};

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">🧠 Intel Hub</h1>
          <p className="text-sm text-white/40 mt-1">Inteligencia de mercado y competencia</p>
        </div>
        <span className="text-xs text-white/20">{new Date().toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard icon="⚔️" label="Competidores" value={market.unique_competitors || 0} color="orange" />
        <KPICard icon="🔍" label="Queries Serper" value={market.serper_queries || 0} color="blue" />
        <KPICard icon="🥇" label="TOP 3" value={market.top3_positions || 0} color="emerald" />
        <KPICard icon="📍" label="Presencias GM" value={market.total_own_positions || 0} color="purple" />
      </div>

      {/* Market Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider mb-4">Presencia Digital GuardMan</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-emerald-400">{market.top3_positions || 0}</div>
              <div className="text-xs text-white/30">Posiciones TOP 3</div>
            </div>
            <div className="bg-blue-500/5 border border-blue-500/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-blue-400">{market.total_own_positions || 0}</div>
              <div className="text-xs text-white/30">Presencias Totales</div>
            </div>
          </div>
        </div>

        {/* Top Competitors */}
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider">Top Competidores</h3>
            <button onClick={() => onNavigate('competitors')} className="text-xs text-blue-400 hover:text-blue-300">Ver todos →</button>
          </div>
          <div className="space-y-2">
            {(data.top_competitors || []).map((c: any, i: number) => (
              <div key={c.domain} className="flex items-center justify-between p-2.5 rounded-lg bg-white/[0.02] hover:bg-white/[0.04]">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-white/20 w-4">#{i + 1}</span>
                  <span className="text-sm text-white/70">{c.domain}</span>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-white/30">{c.appearances} apariciones</span>
                  <span className="text-white/50">pos {c.avg_pos}</span>
                </div>
              </div>
            ))}
            {(data.top_competitors || []).length === 0 && <p className="text-sm text-white/15 text-center py-4">Sin datos de competidores</p>}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <button onClick={syncCompetitors} className="px-4 py-2.5 bg-orange-500/10 text-orange-300 text-sm rounded-lg hover:bg-orange-500/20 border border-orange-500/20">
          ⚔️ Sincronizar Competidores
        </button>
        <button onClick={() => onNavigate('alerts')} className="px-4 py-2.5 bg-white/5 text-white/50 text-sm rounded-lg hover:bg-white/10">
          🔔 Alertas
        </button>
        <button onClick={() => onNavigate('positions')} className="px-4 py-2.5 bg-white/5 text-white/50 text-sm rounded-lg hover:bg-white/10">
          📈 Posiciones SEO
        </button>
        <button onClick={() => onNavigate('strategy')} className="px-4 py-2.5 bg-white/5 text-white/50 text-sm rounded-lg hover:bg-white/10">
          🎯 Estrategia de Contenido
        </button>
        <button onClick={() => onNavigate('reports')} className="px-4 py-2.5 bg-white/5 text-white/50 text-sm rounded-lg hover:bg-white/10">
          📊 Reporte
        </button>
      </div>
    </div>
  );
}

function KPICard({ icon, label, value, color }: {
  icon: string; label: string; value: string | number; subtext?: string; color: string;
}) {
  const borders: Record<string, string> = {
    blue: 'border-blue-500/20', emerald: 'border-emerald-500/20',
    purple: 'border-purple-500/20', orange: 'border-orange-500/20',
  };
  const texts: Record<string, string> = {
    blue: 'text-blue-400', emerald: 'text-emerald-400',
    purple: 'text-purple-400', orange: 'text-orange-400',
  };
  return (
    <div className={`bg-[#1A2744]/60 rounded-xl border ${borders[color] || 'border-white/5'} p-4`}>
      <div className="flex items-center gap-2 mb-2"><span>{icon}</span><span className="text-xs text-white/40 uppercase tracking-wider">{label}</span></div>
      <div className={`text-2xl font-bold ${texts[color] || 'text-white'}`}>{value}</div>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { bg: string; text: string; label: string }> = {
    new: { bg: 'bg-blue-500/15', text: 'text-blue-300', label: 'Nuevo' },
    contacted: { bg: 'bg-yellow-500/15', text: 'text-yellow-300', label: 'Contactado' },
    qualified: { bg: 'bg-emerald-500/15', text: 'text-emerald-300', label: 'Calificado' },
    proposal: { bg: 'bg-purple-500/15', text: 'text-purple-300', label: 'Propuesta' },
    won: { bg: 'bg-green-500/15', text: 'text-green-300', label: 'Ganado' },
    lost: { bg: 'bg-red-500/15', text: 'text-red-300', label: 'Perdido' },
  };
  const c = config[status] || { bg: 'bg-gray-500/15', text: 'text-gray-300', label: status };
  return <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${c.bg} ${c.text}`}>{c.label}</span>;
}

export function DifficultyBadge({ difficulty }: { difficulty: string }) {
  const config: Record<string, { bg: string; text: string; label: string }> = {
    easy: { bg: 'bg-emerald-500/15', text: 'text-emerald-300', label: '🟢 Easy' },
    medium: { bg: 'bg-yellow-500/15', text: 'text-yellow-300', label: '🟡 Medium' },
    hard: { bg: 'bg-red-500/15', text: 'text-red-300', label: '🔴 Hard' },
    unknown: { bg: 'bg-gray-500/15', text: 'text-gray-400', label: '⚪ N/A' },
  };
  const c = config[difficulty] || config.unknown;
  return <span className={`text-[10px] px-1.5 py-0.5 rounded ${c.bg} ${c.text}`}>{c.label}</span>;
}

export function formatMoney(n: number): string {
  if (!n || n === 0) return '—';
  if (n >= 1000000) return `$${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `$${(n / 1000).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}
