// GuardMan Intel — Market Map (Service × Location matrix)
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';

export function MarketMap() {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);
  const [view, setView] = useState<'matrix' | 'locations'>('matrix');

  useEffect(() => {
    api('/api/intel/market-matrix').then(setData).catch(() => {});
  }, []);

  if (loading && !data) return <div className="flex items-center justify-center h-64 text-white/30">Cargando mapa de mercado...</div>;
  if (!data) return <div className="p-6 text-red-400">Error cargando datos</div>;

  const services = data.services || [];
  const locations = data.locations || [];
  const matrix = data.matrix || [];

  // Build lookup: service_slug|location_slug -> row
  const lookup = new Map<string, any>();
  for (const row of matrix) {
    lookup.set(`${row.service_slug}|${row.location_slug}`, row);
  }

  function getPositionColor(pos: number, competitors: number): string {
    if (pos <= 0 || pos >= 999) return competitors > 0 ? 'bg-red-500/20 text-red-300' : 'bg-gray-500/10 text-gray-500';
    if (pos <= 3) return 'bg-emerald-500/20 text-emerald-300';
    if (pos <= 5) return 'bg-yellow-500/20 text-yellow-300';
    if (pos <= 10) return 'bg-orange-500/20 text-orange-300';
    return 'bg-red-500/20 text-red-300';
  }

  function getPositionLabel(pos: number): string {
    if (pos <= 0 || pos >= 999) return '—';
    return `#${pos}`;
  }

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Mapa de Mercado</h2>
          <p className="text-xs text-white/30">{services.length} servicios × {locations.length} comunas = {services.length * locations.length} combos</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setView('matrix')}
            className={`px-3 py-1.5 text-sm rounded-lg ${view === 'matrix' ? 'bg-blue-600 text-white' : 'bg-white/5 text-white/40'}`}>
            Matriz
          </button>
          <button onClick={() => setView('locations')}
            className={`px-3 py-1.5 text-sm rounded-lg ${view === 'locations' ? 'bg-blue-600 text-white' : 'bg-white/5 text-white/40'}`}>
            Por Comuna
          </button>
        </div>
      </div>

      {/* Legend */}
      <div className="flex gap-3 text-xs flex-wrap">
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-emerald-500/30" /> TOP 3</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-yellow-500/30" /> TOP 5</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-orange-500/30" /> TOP 10</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-red-500/30" /> {'>'}10 / Alta competencia</span>
        <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-gray-500/20" /> Sin presencia</span>
      </div>

      {view === 'matrix' ? (
        <MatrixView services={services} locations={locations} lookup={lookup} getPositionColor={getPositionColor} getPositionLabel={getPositionLabel} />
      ) : (
        <LocationListView />
      )}
    </div>
  );
}

function MatrixView({ services, locations, lookup, getPositionColor, getPositionLabel }: any) {
  // Group locations by zone
  const zones = new Map<string, any[]>();
  for (const loc of locations) {
    const zone = loc.zone || 'Otro';
    if (!zones.has(zone)) zones.set(zone, []);
    zones.get(zone)!.push(loc);
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr>
            <th className="text-left p-2 text-white/40 text-xs sticky left-0 bg-[#0D1525] z-10 min-w-[140px]">Servicio</th>
            {Array.from(zones.entries()).map(([zone, locs]) => (
              locs.map((loc: any) => (
                <th key={loc.slug} className={`p-1.5 text-center min-w-[80px] ${zoneColors(loc.zone)}`}>
                  <span className="text-[10px] font-medium block truncate" title={loc.name}>{loc.name}</span>
                </th>
              ))
            ))}
          </tr>
        </thead>
        <tbody>
          {services.map((svc: any) => (
            <tr key={svc.slug} className="border-t border-white/5 hover:bg-white/[0.02]">
              <td className="p-2 text-white/60 text-xs sticky left-0 bg-[#0D1525] z-10 truncate" title={svc.name}>{svc.name}</td>
              {Array.from(zones.entries()).map(([_, locs]) => (
                locs.map((loc: any) => {
                  const row = lookup.get(`${svc.slug}|${loc.slug}`);
                  const pos = row?.best_position || 999;
                  const comp = row?.competitor_count || 0;
                  return (
                    <td key={`${svc.slug}-${loc.slug}`} className="p-1 text-center">
                      <div className={`rounded px-1 py-0.5 text-xs font-medium ${getPositionColor(pos, comp)}`} title={`${svc.name} en ${loc.name}\nPos: ${pos < 999 ? pos : 'N/A'}\nCompetidores: ${comp}`}>
                        {getPositionLabel(pos)}
                      </div>
                    </td>
                  );
                })
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function LocationListView() {
  const { api } = useApi();
  const [locations, setLocations] = useState<any[]>([]);

  useEffect(() => {
    api('/api/intel/market-map').then(setLocations).catch(() => {});
  }, []);

  return (
    <div className="space-y-3">
      {locations.map((loc: any) => (
        <div key={loc.location_slug} className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <span className={`text-xs px-2 py-0.5 rounded-full ${zoneColors(loc.zone)}`}>{loc.zone}</span>
              <h3 className="text-white font-medium">{loc.location_name || loc.location_slug}</h3>
            </div>
            <div className="flex items-center gap-4 text-xs text-white/40">
              <span>{loc.competitor_count || 0} competidores</span>
              <span>Coverage: {loc.coverage_pct || 0}%</span>
              <span>{loc.active_leads || 0} leads</span>
              <span>{loc.active_clients || 0} clientes</span>
            </div>
          </div>
          {/* Mini stats */}
          <div className="grid grid-cols-4 gap-3">
            <div className="bg-white/[0.02] rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-white/70">{loc.total_queries || 0}</div>
              <div className="text-[10px] text-white/30">Queries</div>
            </div>
            <div className="bg-white/[0.02] rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-emerald-400">{loc.top3_count || 0}</div>
              <div className="text-[10px] text-white/30">TOP 3</div>
            </div>
            <div className="bg-white/[0.02] rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-white/50">{loc.best_own_position < 999 ? `#${loc.best_own_position}` : '—'}</div>
              <div className="text-[10px] text-white/30">Mejor pos</div>
            </div>
            <div className="bg-white/[0.02] rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-orange-400">{loc.competitor_count || 0}</div>
              <div className="text-[10px] text-white/30">Competidores</div>
            </div>
          </div>
        </div>
      ))}
      {locations.length === 0 && <p className="text-white/20 text-center py-8">Cargando datos por comuna...</p>}
    </div>
  );
}

function zoneColors(zone: string): string {
  const map: Record<string, string> = {
    Oriente: 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20',
    Norte: 'bg-amber-500/10 text-amber-300 border border-amber-500/20',
    Centro: 'bg-blue-500/10 text-blue-300 border border-blue-500/20',
    Occidente: 'bg-purple-500/10 text-purple-300 border border-purple-500/20',
    Sur: 'bg-red-500/10 text-red-300 border border-red-500/20',
    Valle: 'bg-teal-500/10 text-teal-300 border border-teal-500/20',
  };
  return map[zone] || 'bg-gray-500/10 text-gray-300';
}
