// GuardMan Intel — Position Tracker with timeline and scorecard
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';

export function PositionTracker() {
  const { api, loading } = useApi();
  const [scorecard, setScorecard] = useState<any>(null);
  const [timeline, setTimeline] = useState<any>(null);
  const [quickWins, setQuickWins] = useState<any>(null);
  const [tab, setTab] = useState<'scorecard' | 'timeline' | 'wins'>('scorecard');

  useEffect(() => {
    Promise.all([
      api('/api/intel/positions/scorecard').catch(() => null),
      api('/api/intel/positions/timeline').catch(() => null),
      api('/api/intel/quick-wins').catch(() => null),
    ]).then(([sc, tl, qw]) => {
      setScorecard(sc);
      setTimeline(tl);
      setQuickWins(qw);
    });
  }, []);

  if (loading && !scorecard) return <div className="flex items-center justify-center h-64 text-white/30">Cargando posiciones...</div>;

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Posiciones SEO GuardMan</h2>
          <p className="text-xs text-white/30">{scorecard?.summary?.total_combos || 0} combos analizados</p>
        </div>
        <div className="flex gap-2">
          {(['scorecard', 'timeline', 'wins'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-3 py-1.5 text-sm rounded-lg ${tab === t ? 'bg-blue-600 text-white' : 'bg-white/5 text-white/40'}`}>
              {t === 'scorecard' ? '📊 Scorecard' : t === 'timeline' ? '📈 Timeline' : '🎯 Quick Wins'}
            </button>
          ))}
        </div>
      </div>

      {tab === 'scorecard' && <ScorecardTab data={scorecard} />}
      {tab === 'timeline' && <TimelineTab data={timeline} />}
      {tab === 'wins' && <QuickWinsTab data={quickWins} />}
    </div>
  );
}

function ScorecardTab({ data }: { data: any }) {
  if (!data) return <p className="text-white/20">Sin datos</p>;
  const s = data.summary || {};
  const p = data.positions || {};
  const t = data.trend || {};

  return (
    <div className="space-y-6">
      {/* Scorecard grid */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <MiniCard label="TOP 3 🥇" value={p.top3 || 0} color="emerald" />
        <MiniCard label="TOP 5 🥈" value={p.top5 || 0} color="yellow" />
        <MiniCard label="TOP 10 🥉" value={p.top10 || 0} color="orange" />
        <MiniCard label="Sin presencia ❌" value={p.no_presence || 0} color="red" />
        <MiniCard label="Con presencia ✅" value={s.with_presence || 0} color="blue" />
      </div>

      {/* Trend */}
      {t && (t.improved > 0 || t.declined > 0 || t.new > 0 || t.lost > 0) && (
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-white/50 mb-3">Tendencia vs snapshot anterior</h3>
          <div className="flex gap-6">
            {t.improved > 0 && <span className="text-emerald-400 text-sm">↑ {t.improved} mejoraron</span>}
            {t.declined > 0 && <span className="text-red-400 text-sm">↓ {t.declined} empeoraron</span>}
            {t.new > 0 && <span className="text-blue-400 text-sm">🆕 {t.new} nuevas</span>}
            {t.lost > 0 && <span className="text-orange-400 text-sm">⚠️ {t.lost} perdidas</span>}
          </div>
        </div>
      )}

      {/* Distribution bar */}
      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
        <h3 className="text-sm font-medium text-white/50 mb-3">Distribución de posiciones</h3>
        <div className="flex h-8 rounded-lg overflow-hidden">
          {p.top3 > 0 && <div className="bg-emerald-500/40 flex items-center justify-center text-xs text-white/70" style={{ width: `${(p.top3 / s.total_combos) * 100}%` }}>{p.top3}</div>}
          {p.top5 > 0 && <div className="bg-yellow-500/40 flex items-center justify-center text-xs text-white/70" style={{ width: `${(p.top5 / s.total_combos) * 100}%` }}>{p.top5}</div>}
          {p.top10 > 0 && <div className="bg-orange-500/40 flex items-center justify-center text-xs text-white/70" style={{ width: `${(p.top10 / s.total_combos) * 100}%` }}>{p.top10}</div>}
          {p.no_presence > 0 && <div className="bg-gray-500/20 flex items-center justify-center text-xs text-white/30" style={{ width: `${(p.no_presence / s.total_combos) * 100}%` }}>{p.no_presence}</div>}
        </div>
        <div className="flex justify-between text-xs text-white/20 mt-1">
          <span>Mejor</span>
          <span>Peor</span>
        </div>
      </div>
    </div>
  );
}

function TimelineTab({ data }: { data: any }) {
  if (!data || !data.own_history?.length) return <p className="text-white/20 py-8 text-center">Sin datos de timeline. Necesitas al menos 2 snapshots.</p>;
  const history = data.own_history || [];

  return (
    <div className="space-y-4">
      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
        <h3 className="text-sm font-medium text-white/50 mb-4">Posición promedio GuardMan en el tiempo</h3>
        <div className="space-y-1">
          {history.slice().reverse().map((h: any, i: number) => {
            const prev = history.slice().reverse()[i - 1];
            const delta = prev ? (h.avg_pos - prev.avg_pos) : 0;
            const width = Math.max(4, Math.min(100, (1 - (h.avg_pos / 15)) * 100));
            return (
              <div key={h.snapshot_date} className="flex items-center gap-3">
                <span className="text-xs text-white/30 w-20 shrink-0">{h.snapshot_date?.substring(5)}</span>
                <div className="flex-1 h-6 bg-white/[0.03] rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all ${delta < -0.3 ? 'bg-emerald-500/40' : delta > 0.3 ? 'bg-red-500/30' : 'bg-blue-500/30'}`}
                    style={{ width: `${width}%` }} />
                </div>
                <span className={`text-sm font-medium w-12 text-right ${delta < -0.3 ? 'text-emerald-400' : delta > 0.3 ? 'text-red-400' : 'text-white/50'}`}>
                  {h.avg_pos ? h.avg_pos.toFixed(1) : '—'}
                </span>
                <span className="text-xs text-white/20 w-20 text-right">{h.combos} combos</span>
              </div>
            );
          })}
        </div>
      </div>
      <p className="text-xs text-white/15 text-center">Datos basados en {data.dates?.length || 0} snapshots disponibles</p>
    </div>
  );
}

function QuickWinsTab({ data }: { data: any }) {
  if (!data) return <p className="text-white/20">Sin datos</p>;
  const qw = data.quick_wins || [];
  const ew = data.easy_wins || [];

  return (
    <div className="space-y-6">
      {ew.length > 0 && (
        <div className="bg-[#1A2744]/60 rounded-xl border border-emerald-500/20 p-5">
          <h3 className="text-sm font-medium text-emerald-300 mb-3">🟢 Easy Wins — Sin competencia, solo necesitas publicar ({ew.length})</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {ew.map((w: any, i: number) => (
              <div key={i} className="p-3 bg-emerald-500/5 rounded-lg border border-emerald-500/10">
                <p className="text-sm text-white/60">{w.service_slug?.replace(/-/g, ' ')}</p>
                <p className="text-xs text-white/30">{w.location_slug?.replace(/-/g, ' ')} · {w.queries} queries</p>
              </div>
            ))}
          </div>
        </div>
      )}
      {qw.length > 0 && (
        <div className="bg-[#1A2744]/60 rounded-xl border border-blue-500/20 p-5">
          <h3 className="text-sm font-medium text-blue-300 mb-3">🎯 Quick Wins — Pos 4-10, factible mejorar ({qw.length})</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {qw.map((w: any, i: number) => (
              <div key={i} className="flex items-center justify-between p-3 bg-white/[0.02] rounded-lg">
                <div className="text-xs text-white/50">
                  <span className="text-white/70">{w.service_slug?.replace(/-/g, ' ')}</span>
                  <span className="text-white/15"> · </span>
                  <span>{w.location_slug?.replace(/-/g, ' ')}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-white/20">{w.competitors} comp</span>
                  <span className="text-sm font-bold text-blue-400">#{w.best_position}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MiniCard({ label, value, color }: { label: string; value: number; color: string }) {
  const colors: Record<string, string> = {
    emerald: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400',
    yellow: 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400',
    orange: 'bg-orange-500/10 border-orange-500/20 text-orange-400',
    red: 'bg-red-500/10 border-red-500/20 text-red-400',
    blue: 'bg-blue-500/10 border-blue-500/20 text-blue-400',
  };
  return (
    <div className={`rounded-xl border p-4 text-center ${colors[color]}`}>
      <div className="text-2xl font-bold">{value}</div>
      <div className="text-xs opacity-60">{label}</div>
    </div>
  );
}
