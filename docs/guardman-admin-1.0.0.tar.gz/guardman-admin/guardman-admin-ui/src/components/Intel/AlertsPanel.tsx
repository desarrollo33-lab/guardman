// GuardMan Intel — Alerts Panel
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';

export function AlertsPanel() {
  const { api, loading } = useApi();
  const [alerts, setAlerts] = useState<any[]>([]);

  useEffect(() => {
    api('/api/intel/alerts').then((data: any) => {
      setAlerts(Array.isArray(data) ? data : []);
    }).catch(() => {});
  }, []);

  if (loading) return <div className="text-white/20 text-center py-4">Cargando alertas...</div>;

  const severityIcon: Record<string, string> = { info: '🔵', warning: '🟡', critical: '🔴' };

  return (
    <div className="space-y-2">
      {alerts.length === 0 ? (
        <p className="text-white/15 text-center py-8">No hay alertas activas</p>
      ) : alerts.map((a, i) => (
        <div key={i} className={`flex items-start gap-3 p-3 rounded-lg ${a.severity === 'warning' ? 'bg-yellow-500/5 border border-yellow-500/10' : a.severity === 'critical' ? 'bg-red-500/5 border border-red-500/10' : 'bg-white/[0.02] border border-white/5'}`}>
          <span className="text-sm mt-0.5">{severityIcon[a.severity] || '⚪'}</span>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-white/70">{a.title}</p>
            <p className="text-xs text-white/40 mt-0.5">{a.description}</p>
          </div>
          <span className={`text-[10px] px-1.5 py-0.5 rounded ${a.type?.includes('lost') ? 'bg-red-500/10 text-red-300' : a.type?.includes('gained') || a.type?.includes('new') ? 'bg-emerald-500/10 text-emerald-300' : 'bg-white/5 text-white/30'}`}>
            {a.type?.replace(/_/g, ' ')}
          </span>
        </div>
      ))}
    </div>
  );
}
