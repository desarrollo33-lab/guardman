// GuardMan Intel — CRUD Data Manager
// Browse, filter, classify, and manage raw serper data, competitors, and opportunities
import { useEffect, useState, useCallback } from 'react';
import { useApi } from '../../hooks/useApi';

type CRUDTab = 'results' | 'competitors' | 'opportunities';

const SITE_TYPES = [
  'own', 'direct_competitor', 'indirect_competitor', 'competitor', 'weak',
  'job_board', 'directory', 'government', 'social', 'marketplace', 'media', 'authority', 'irrelevant',
];
const SITE_TYPE_COLORS: Record<string, string> = {
  own: 'bg-emerald-500/20 text-emerald-300',
  direct_competitor: 'bg-red-500/20 text-red-300',
  indirect_competitor: 'bg-orange-500/20 text-orange-300',
  competitor: 'bg-red-500/15 text-red-300',
  weak: 'bg-yellow-500/15 text-yellow-300',
  job_board: 'bg-gray-500/20 text-gray-300',
  directory: 'bg-blue-500/15 text-blue-300',
  government: 'bg-purple-500/15 text-purple-300',
  social: 'bg-cyan-500/15 text-cyan-300',
  marketplace: 'bg-amber-500/15 text-amber-300',
  media: 'bg-indigo-500/15 text-indigo-300',
  authority: 'bg-violet-500/15 text-violet-300',
  irrelevant: 'bg-white/5 text-white/30',
};
const THREAT_COLORS: Record<string, string> = {
  high: 'text-red-400', medium: 'text-yellow-400', low: 'text-emerald-400',
};
const PRIORITY_COLORS: Record<string, string> = {
  high: 'bg-red-500/20 text-red-300', medium: 'bg-yellow-500/20 text-yellow-300', low: 'bg-emerald-500/20 text-emerald-300',
};
const OPP_STATUS_COLORS: Record<string, string> = {
  open: 'bg-blue-500/20 text-blue-300', in_progress: 'bg-yellow-500/20 text-yellow-300',
  done: 'bg-emerald-500/20 text-emerald-300', dismissed: 'bg-white/5 text-white/30',
};

export function IntelCRUD() {
  const [tab, setTab] = useState<CRUDTab>('results');
  const [stats, setStats] = useState<any>(null);
  const { api } = useApi();

  useEffect(() => {
    api('/api/intel/crud-stats').then(setStats).catch(() => {});
  }, []);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header with stats */}
      <div className="px-6 pt-5 pb-3 bg-[#0f1729] border-b border-white/5 shrink-0">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-lg font-bold text-white">🗃️ Gestión de Datos</h2>
            <p className="text-xs text-white/30">Filtra, clasifica y califica los datos de inteligencia</p>
          </div>
          {stats && (
            <div className="flex gap-4 text-xs">
              <span className="text-white/40">{stats.serper_results.total.toLocaleString()} resultados</span>
              <span className="text-white/40">{stats.competitors.total} competidores</span>
              <span className="text-white/40">{stats.opportunities.total} oportunidades</span>
            </div>
          )}
        </div>

        {/* Tab selector */}
        <div className="flex gap-1 bg-white/[0.03] p-1 rounded-lg w-fit">
          {([
            { id: 'results' as const, label: 'Serper Results', icon: '🔍', count: stats?.serper_results.total },
            { id: 'competitors' as const, label: 'Competidores', icon: '⚔️', count: stats?.competitors.total },
            { id: 'opportunities' as const, label: 'Oportunidades', icon: '🎯', count: stats?.opportunities.total },
          ]).map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${
                tab === t.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-white/40 hover:text-white/70 hover:bg-white/5'
              }`}>
              <span>{t.icon}</span>
              {t.label}
              {t.count !== undefined && <span className="text-[10px] opacity-60">({t.count})</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {tab === 'results' && <SerperResultsManager />}
        {tab === 'competitors' && <CompetitorsManager />}
        {tab === 'opportunities' && <OpportunitiesManager />}
      </div>
    </div>
  );
}

// ============================================================
// SERPER RESULTS
// ============================================================

function SerperResultsManager() {
  const { api } = useApi();
  const [data, setData] = useState<any>(null);
  const [filters, setFilters] = useState<any>({});
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [editing, setEditing] = useState<number | null>(null);
  const [bulkType, setBulkType] = useState('');
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    const params = new URLSearchParams();
    params.set('page', String(page));
    params.set('limit', '50');
    if (filters.service) params.set('service', filters.service);
    if (filters.location) params.set('location', filters.location);
    if (filters.site_type) params.set('site_type', filters.site_type);
    if (filters.domain) params.set('domain', filters.domain);
    if (filters.result_type) params.set('result_type', filters.result_type);
    if (search) params.set('q', search);
    const d = await api(`/api/intel/serper-results?${params}`);
    setData(d);
  }, [page, filters, search, api]);

  useEffect(() => { load(); }, [load]);

  const classifyResult = async (id: number, siteType: string) => {
    await api(`/api/intel/serper-results/${id}`, {
      method: 'PUT', body: JSON.stringify({ site_type: siteType }),
    });
    load();
  };

  const bulkClassify = async () => {
    if (!bulkType || selected.size === 0) return;
    await api('/api/intel/serper-results/bulk/classify', {
      method: 'PUT', body: JSON.stringify({ ids: [...selected], site_type: bulkType }),
    });
    setSelected(new Set());
    setBulkType('');
    load();
  };

  const deleteResult = async (id: number) => {
    if (!confirm('¿Eliminar este resultado?')) return;
    try {
      await api(`/api/intel/serper-results/${id}`, { method: 'DELETE' });
      load();
    } catch (err: any) {
      alert('Error al eliminar: ' + err.message);
    }
  };

  const toggleSelect = (id: number) => {
    const s = new Set(selected);
    if (s.has(id)) s.delete(id); else s.add(id);
    setSelected(s);
  };

  if (!data) return <div className="flex items-center justify-center h-64 text-white/30">Cargando...</div>;

  const f = data.filters || {};

  return (
    <div className="p-4 space-y-3">
      {/* Filters bar */}
      <div className="flex flex-wrap gap-2 items-end bg-[#1A2744]/40 rounded-xl p-3 border border-white/5">
        <FilterSelect label="Servicio" value={filters.service || ''} options={f.services || []}
          onChange={v => { setFilters({ ...filters, service: v }); setPage(1); }} />
        <FilterSelect label="Comuna" value={filters.location || ''} options={f.locations || []}
          onChange={v => { setFilters({ ...filters, location: v }); setPage(1); }} />
        <FilterSelect label="Tipo Sitio" value={filters.site_type || ''} options={f.site_types || []}
          onChange={v => { setFilters({ ...filters, site_type: v }); setPage(1); }} />
        <FilterSelect label="Dominio" value={filters.domain || ''}
          options={(f.top_domains || []).map((d: any) => d.domain)}
          onChange={v => { setFilters({ ...filters, domain: v }); setPage(1); }} />
        <div className="flex-1 min-w-[200px]">
          <label className="text-[10px] text-white/30 uppercase">Buscar</label>
          <input type="text" value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
            placeholder="título, dominio, snippet..."
            className="w-full px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-white/20 focus:outline-none focus:border-blue-500/50" />
        </div>
        <button onClick={() => { setFilters({}); setSearch(''); setPage(1); }}
          className="px-3 py-1.5 text-xs text-white/40 hover:text-white/70 bg-white/5 rounded-lg">
          Limpiar
        </button>
      </div>

      {/* Bulk actions */}
      {selected.size > 0 && (
        <div className="flex items-center gap-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded-lg">
          <span className="text-sm text-blue-300">{selected.size} seleccionados</span>
          <select value={bulkType} onChange={e => setBulkType(e.target.value)}
            className="px-2 py-1 bg-white/5 border border-white/10 rounded text-xs text-white">
            <option value="">Clasificar como...</option>
            {SITE_TYPES.map(st => <option key={st} value={st}>{st.replace(/_/g, ' ')}</option>)}
          </select>
          <button onClick={bulkClassify} disabled={!bulkType}
            className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 disabled:opacity-30">
            Aplicar
          </button>
          <button onClick={() => setSelected(new Set())}
            className="px-3 py-1 text-xs text-white/40 hover:text-white/60">
            Deseleccionar
          </button>
        </div>
      )}

      {/* Results count + pagination */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-white/30">{data.total?.toLocaleString()} resultados</span>
        <div className="flex gap-1">
          <button disabled={page <= 1} onClick={() => setPage(page - 1)}
            className="px-2 py-1 text-xs bg-white/5 text-white/40 rounded disabled:opacity-20 hover:bg-white/10">← Anterior</button>
          <span className="px-2 py-1 text-xs text-white/40">{page}/{data.pages}</span>
          <button disabled={page >= data.pages} onClick={() => setPage(page + 1)}
            className="px-2 py-1 text-xs bg-white/5 text-white/40 rounded disabled:opacity-20 hover:bg-white/10">Siguiente →</button>
        </div>
      </div>

      {/* Results table */}
      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5 text-xs text-white/40">
                <th className="p-2 w-8"><input type="checkbox" checked={selected.size === data.results?.length && data.results?.length > 0}
                  onChange={e => { if (e.target.checked) setSelected(new Set(data.results?.map((r: any) => r.id))); else setSelected(new Set()); }}
                  className="rounded" /></th>
                <th className="p-2 text-left">ID</th>
                <th className="p-2 text-left">Pos</th>
                <th className="p-2 text-left">Dominio</th>
                <th className="p-2 text-left">Título</th>
                <th className="p-2 text-left">Servicio · Comuna</th>
                <th className="p-2 text-left">Tipo Sitio</th>
                <th className="p-2 text-left">Tipo Resultado</th>
                <th className="p-2 w-20">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {(data.results || []).map((r: any) => (
                <tr key={r.id} className={`border-b border-white/[0.03] hover:bg-white/[0.02] ${selected.has(r.id) ? 'bg-blue-500/5' : ''}`}>
                  <td className="p-2"><input type="checkbox" checked={selected.has(r.id)} onChange={() => toggleSelect(r.id)} className="rounded" /></td>
                  <td className="p-2 text-white/20 text-xs">{r.id}</td>
                  <td className="p-2">
                    <span className={`text-xs font-mono ${r.position <= 3 ? 'text-emerald-400' : r.position <= 10 ? 'text-yellow-400' : 'text-white/30'}`}>
                      #{r.position}
                    </span>
                  </td>
                  <td className="p-2 max-w-[200px] truncate">
                    <span className={`text-xs ${r.site_type === 'own' ? 'text-emerald-400 font-medium' : r.site_type === 'direct_competitor' ? 'text-red-400' : 'text-white/50'}`}>
                      {r.domain}
                    </span>
                    {r.is_cl === 1 && <span className="ml-1 text-[9px] bg-chile-500/20 text-red-300 px-1 rounded">🇨🇱</span>}
                  </td>
                  <td className="p-2 max-w-[250px]">
                    {editing === r.id ? (
                      <input type="text" defaultValue={r.title}
                        onBlur={async (e) => { await api(`/api/intel/serper-results/${r.id}`, { method: 'PUT', body: JSON.stringify({ title: e.target.value }) }); setEditing(null); }}
                        onKeyDown={async (e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') setEditing(null); }}
                        className="w-full px-1 py-0.5 bg-white/5 border border-blue-500/30 rounded text-xs text-white focus:outline-none" autoFocus />
                    ) : (
                      <span className="text-xs text-white/40 truncate block cursor-pointer hover:text-white/60" onClick={() => setEditing(r.id)} title={r.title}>
                        {r.title}
                      </span>
                    )}
                    {r.snippet && <p className="text-[10px] text-white/20 truncate mt-0.5">{r.snippet}</p>}
                  </td>
                  <td className="p-2">
                    <span className="text-[10px] text-white/30">{(r.service_slug || '').replace(/-/g, ' ')}</span>
                    <span className="text-[10px] text-white/15"> · </span>
                    <span className="text-[10px] text-white/30">{(r.location_slug || '').replace(/-/g, ' ')}</span>
                  </td>
                  <td className="p-2">
                    <select value={r.site_type || ''} onChange={e => classifyResult(r.id, e.target.value)}
                      className={`text-[10px] px-1.5 py-0.5 rounded border-0 bg-white/5 cursor-pointer ${SITE_TYPE_COLORS[r.site_type] || 'text-white/30'}`}>
                      <option value="">— sin clasificar —</option>
                      {SITE_TYPES.map(st => <option key={st} value={st}>{st.replace(/_/g, ' ')}</option>)}
                    </select>
                  </td>
                  <td className="p-2">
                    <span className="text-[10px] text-white/25 bg-white/[0.03] px-1.5 py-0.5 rounded">{r.result_type}</span>
                  </td>
                  <td className="p-2">
                    <button onClick={() => deleteResult(r.id)} className="text-[10px] text-red-400/50 hover:text-red-400 px-1">✕</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// COMPETITORS
// ============================================================

function CompetitorsManager() {
  const { api } = useApi();
  const [competitors, setCompetitors] = useState<any[]>([]);
  const [editing, setEditing] = useState<string | null>(null);
  const [editData, setEditData] = useState<any>({});
  const [filter, setFilter] = useState('');
  const [threatFilter, setThreatFilter] = useState('');

  const load = useCallback(async () => {
    const d = await api('/api/intel/competitors');
    setCompetitors(Array.isArray(d) ? d : d?.data || []);
  }, [api]);

  useEffect(() => { load(); }, [load]);

  const startEdit = (c: any) => {
    setEditing(c.domain);
    setEditData({
      company_name: c.company_name || '',
      threat_level: c.threat_level || 'medium',
      trend: c.trend || 'stable',
      status: c.status || 'active',
      pricing_strategy: c.pricing_strategy || 'unknown',
      target_market: c.target_market || 'general',
      strengths: typeof c.strengths === 'string' ? c.strengths : JSON.stringify(c.strengths || []),
      weaknesses: typeof c.weaknesses === 'string' ? c.weaknesses : JSON.stringify(c.weaknesses || []),
      notes: c.notes || '',
      google_rating: c.google_rating || '',
      google_reviews: c.google_reviews || '',
    });
  };

  const saveEdit = async (domain: string) => {
    const payload: any = {};
    for (const [k, v] of Object.entries(editData)) {
      if (v !== '' && v !== undefined) payload[k] = v;
    }
    await api(`/api/intel/competitors/${encodeURIComponent(domain)}`, {
      method: 'PUT', body: JSON.stringify(payload),
    });
    setEditing(null);
    load();
  };

  const deleteComp = async (domain: string) => {
    if (!confirm(`¿Eliminar competidor ${domain}?`)) return;
    try {
      await api(`/api/intel/competitors/${encodeURIComponent(domain)}`, { method: 'DELETE' });
      load();
    } catch (err: any) {
      alert('Error al eliminar: ' + err.message);
    }
  };

  const filtered = competitors.filter(c => {
    if (filter && !c.domain.includes(filter) && !(c.company_name || '').toLowerCase().includes(filter.toLowerCase())) return false;
    if (threatFilter && c.threat_level !== threatFilter) return false;
    return true;
  });

  return (
    <div className="p-4 space-y-3">
      {/* Filters */}
      <div className="flex gap-2 items-end">
        <div className="flex-1">
          <input type="text" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Buscar dominio o nombre..."
            className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-white/20 focus:outline-none focus:border-blue-500/50" />
        </div>
        <select value={threatFilter} onChange={e => setThreatFilter(e.target.value)}
          className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white">
          <option value="">Todas las amenazas</option>
          <option value="high">🔴 Alta</option>
          <option value="medium">🟡 Media</option>
          <option value="low">🟢 Baja</option>
        </select>
      </div>

      <span className="text-xs text-white/30">{filtered.length} competidores</span>

      {/* Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {filtered.map(c => (
          <div key={c.domain} className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-4">
            {editing === c.domain ? (
              /* Edit mode */
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-white/70">{c.domain}</span>
                  <div className="flex gap-1">
                    <button onClick={() => saveEdit(c.domain)} className="px-2 py-1 bg-emerald-600 text-white text-xs rounded">✓ Guardar</button>
                    <button onClick={() => setEditing(null)} className="px-2 py-1 bg-white/5 text-white/40 text-xs rounded">✕</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <EditField label="Nombre" value={editData.company_name} onChange={v => setEditData({ ...editData, company_name: v })} />
                  <div>
                    <label className="text-[10px] text-white/30">Amenaza</label>
                    <select value={editData.threat_level} onChange={e => setEditData({ ...editData, threat_level: e.target.value })}
                      className="w-full px-2 py-1 bg-white/5 border border-white/10 rounded text-xs text-white">
                      <option value="high">Alta</option><option value="medium">Media</option><option value="low">Baja</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-white/30">Tendencia</label>
                    <select value={editData.trend} onChange={e => setEditData({ ...editData, trend: e.target.value })}
                      className="w-full px-2 py-1 bg-white/5 border border-white/10 rounded text-xs text-white">
                      <option value="rising">↑ Creciendo</option><option value="stable">→ Estable</option><option value="declining">↓ Decayendo</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-white/30">Pricing</label>
                    <select value={editData.pricing_strategy} onChange={e => setEditData({ ...editData, pricing_strategy: e.target.value })}
                      className="w-full px-2 py-1 bg-white/5 border border-white/10 rounded text-xs text-white">
                      <option value="premium">Premium</option><option value="competitive">Competitivo</option><option value="budget">Económico</option><option value="unknown">Desconocido</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-white/30">Estado</label>
                    <select value={editData.status} onChange={e => setEditData({ ...editData, status: e.target.value })}
                      className="w-full px-2 py-1 bg-white/5 border border-white/10 rounded text-xs text-white">
                      <option value="active">Activo</option><option value="inactive">Inactivo</option><option value="acquired">Adquirido</option>
                    </select>
                  </div>
                </div>
                <EditField label="Fortalezas" value={editData.strengths} onChange={v => setEditData({ ...editData, strengths: v })} multiline />
                <EditField label="Debilidades" value={editData.weaknesses} onChange={v => setEditData({ ...editData, weaknesses: v })} multiline />
                <EditField label="Notas" value={editData.notes} onChange={v => setEditData({ ...editData, notes: v })} multiline />
              </div>
            ) : (
              /* View mode */
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-medium ${THREAT_COLORS[c.threat_level] || 'text-white/50'}`}>
                      {c.threat_level === 'high' ? '🔴' : c.threat_level === 'low' ? '🟢' : '🟡'}
                    </span>
                    <span className="text-sm font-medium text-white/80">{c.company_name || c.domain}</span>
                    {c.domain !== c.company_name && <span className="text-[10px] text-white/20">{c.domain}</span>}
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => startEdit(c)} className="text-[10px] text-blue-400/60 hover:text-blue-400 px-1">✏️</button>
                    <button onClick={() => deleteComp(c.domain)} className="text-[10px] text-red-400/60 hover:text-red-400 px-1">✕</button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center mb-2">
                  <div className="bg-white/[0.02] rounded-lg p-1.5">
                    <div className="text-xs font-bold text-white/60">{c.total_appearances || 0}</div>
                    <div className="text-[9px] text-white/25">Apariciones</div>
                  </div>
                  <div className="bg-white/[0.02] rounded-lg p-1.5">
                    <div className="text-xs font-bold text-white/60">{c.avg_position ? `#${Math.round(c.avg_position)}` : '—'}</div>
                    <div className="text-[9px] text-white/25">Pos Media</div>
                  </div>
                  <div className="bg-white/[0.02] rounded-lg p-1.5">
                    <div className="text-xs font-bold text-white/60">{c.google_rating || '—'}{c.google_reviews ? ` (${c.google_reviews})` : ''}</div>
                    <div className="text-[9px] text-white/25">Google</div>
                  </div>
                </div>
                <div className="flex gap-1 flex-wrap">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${c.trend === 'rising' ? 'bg-red-500/10 text-red-300' : c.trend === 'declining' ? 'bg-emerald-500/10 text-emerald-300' : 'bg-white/5 text-white/30'}`}>
                    {c.trend === 'rising' ? '↑ Subiendo' : c.trend === 'declining' ? '↓ Bajando' : '→ Estable'}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-white/30">{c.pricing_strategy}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-white/30">{c.services_present || 0} servicios · {c.locations_present || 0} comunas</span>
                </div>
                {c.notes && <p className="text-[10px] text-white/20 mt-2 italic border-t border-white/5 pt-2">{c.notes}</p>}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// OPPORTUNITIES
// ============================================================

function OpportunitiesManager() {
  const { api } = useApi();
  const [opportunities, setOpportunities] = useState<any[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [newOpp, setNewOpp] = useState({ title: '', type: 'gap', priority: 'medium', service_slug: '', location_slug: '', description: '', estimated_value: 0, effort: 'medium' });
  const [statusFilter, setStatusFilter] = useState('');

  const load = useCallback(async () => {
    const params = statusFilter ? `?status=${statusFilter}` : '';
    const d = await api(`/api/intel/opportunities${params}`);
    setOpportunities(d?.data?.results || d?.data || []);
  }, [api, statusFilter]);

  useEffect(() => { load(); }, [load]);

  const createOpp = async () => {
    await api('/api/intel/opportunities', { method: 'POST', body: JSON.stringify(newOpp) });
    setShowCreate(false);
    setNewOpp({ title: '', type: 'gap', priority: 'medium', service_slug: '', location_slug: '', description: '', estimated_value: 0, effort: 'medium' });
    load();
  };

  const updateOpp = async (id: number, changes: any) => {
    await api(`/api/intel/opportunities/${id}`, { method: 'PUT', body: JSON.stringify(changes) });
    load();
  };

  const deleteOpp = async (id: number) => {
    if (!confirm('¿Eliminar esta oportunidad?')) return;
    try {
      await api(`/api/intel/opportunities/${id}`, { method: 'DELETE' });
      load();
    } catch (err: any) {
      alert('Error al eliminar: ' + err.message);
    }
  };

  return (
    <div className="p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2 items-end">
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white">
            <option value="">Todos los estados</option>
            <option value="open">Abierto</option>
            <option value="in_progress">En progreso</option>
            <option value="done">Hecho</option>
            <option value="dismissed">Descartado</option>
          </select>
          <span className="text-xs text-white/30">{opportunities.length} oportunidades</span>
        </div>
        <button onClick={() => setShowCreate(true)} className="px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
          + Nueva Oportunidad
        </button>
      </div>

      {/* Create form */}
      {showCreate && (
        <div className="bg-[#1A2744]/80 rounded-xl border border-blue-500/20 p-4 space-y-3">
          <h3 className="text-sm font-medium text-white/70">Nueva Oportunidad</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <input type="text" value={newOpp.title} onChange={e => setNewOpp({ ...newOpp, title: e.target.value })} placeholder="Título *"
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-white/20 focus:outline-none focus:border-blue-500/50" />
            </div>
            <select value={newOpp.type} onChange={e => setNewOpp({ ...newOpp, type: e.target.value })}
              className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white">
              <option value="gap">Gap (sin presencia)</option>
              <option value="content">Contenido</option>
              <option value="keyword">Keyword</option>
              <option value="competitor_weakness">Debilidad competidor</option>
              <option value="market_expansion">Expansión</option>
            </select>
            <select value={newOpp.priority} onChange={e => setNewOpp({ ...newOpp, priority: e.target.value })}
              className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white">
              <option value="high">Alta</option><option value="medium">Media</option><option value="low">Baja</option>
            </select>
            <input type="text" value={newOpp.service_slug} onChange={e => setNewOpp({ ...newOpp, service_slug: e.target.value })} placeholder="service-slug"
              className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-white/20" />
            <input type="text" value={newOpp.location_slug} onChange={e => setNewOpp({ ...newOpp, location_slug: e.target.value })} placeholder="location-slug"
              className="px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-white/20" />
            <div className="col-span-2">
              <textarea value={newOpp.description} onChange={e => setNewOpp({ ...newOpp, description: e.target.value })} placeholder="Descripción..."
                className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-white/20 h-20 resize-none" />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={createOpp} disabled={!newOpp.title} className="px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:opacity-30">Crear</button>
            <button onClick={() => setShowCreate(false)} className="px-4 py-2 bg-white/5 text-white/40 text-sm rounded-lg hover:bg-white/10">Cancelar</button>
          </div>
        </div>
      )}

      {/* Opportunity cards */}
      {opportunities.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-white/20 text-sm">Sin oportunidades registradas</p>
          <p className="text-white/10 text-xs mt-1">Crea una manualmente o usa Content Strategy para detectarlas</p>
        </div>
      ) : (
        <div className="space-y-2">
          {opportunities.map(o => (
            <div key={o.id} className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-4 flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${PRIORITY_COLORS[o.priority] || 'bg-white/5'}`}>{o.priority}</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${OPP_STATUS_COLORS[o.status] || 'bg-white/5'}`}>{o.status.replace(/_/g, ' ')}</span>
                  <span className="text-[10px] text-white/20 bg-white/[0.03] px-1.5 py-0.5 rounded">{o.type?.replace(/_/g, ' ')}</span>
                </div>
                <p className="text-sm text-white/70">{o.title}</p>
                {o.description && <p className="text-xs text-white/30 mt-0.5">{o.description}</p>}
                <div className="flex gap-2 mt-1.5">
                  {o.service_slug && <span className="text-[10px] text-white/20">{o.service_slug.replace(/-/g, ' ')}</span>}
                  {o.location_slug && <span className="text-[10px] text-white/15">· {o.location_slug.replace(/-/g, ' ')}</span>}
                  {o.estimated_value > 0 && <span className="text-[10px] text-emerald-400">${o.estimated_value.toLocaleString()}</span>}
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <select value={o.status} onChange={e => updateOpp(o.id, { status: e.target.value })}
                  className="text-[10px] px-2 py-1 bg-white/5 border border-white/10 rounded text-white cursor-pointer">
                  <option value="open">Abierto</option>
                  <option value="in_progress">En progreso</option>
                  <option value="done">Hecho</option>
                  <option value="dismissed">Descartado</option>
                </select>
                <select value={o.priority} onChange={e => updateOpp(o.id, { priority: e.target.value })}
                  className="text-[10px] px-2 py-1 bg-white/5 border border-white/10 rounded text-white cursor-pointer">
                  <option value="high">Alta</option>
                  <option value="medium">Media</option>
                  <option value="low">Baja</option>
                </select>
                <button onClick={() => deleteOpp(o.id)} className="text-[10px] text-red-400/50 hover:text-red-400 px-1">✕</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// SHARED COMPONENTS
// ============================================================

function FilterSelect({ label, value, options, onChange }: {
  label: string; value: string; options: string[]; onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="text-[10px] text-white/30 uppercase">{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)}
        className="block px-2 py-1.5 bg-white/5 border border-white/10 rounded-lg text-xs text-white min-w-[140px]">
        <option value="">Todos</option>
        {options.map(o => <option key={o} value={o}>{o.replace(/-/g, ' ')}</option>)}
      </select>
    </div>
  );
}

function EditField({ label, value, onChange, multiline }: {
  label: string; value: string; onChange: (v: string) => void; multiline?: boolean;
}) {
  return (
    <div className={multiline ? 'col-span-2' : ''}>
      <label className="text-[10px] text-white/30">{label}</label>
      {multiline ? (
        <textarea value={value} onChange={e => onChange(e.target.value)}
          className="w-full px-2 py-1 bg-white/5 border border-white/10 rounded text-xs text-white h-16 resize-none" />
      ) : (
        <input type="text" value={value} onChange={e => onChange(e.target.value)}
          className="w-full px-2 py-1 bg-white/5 border border-white/10 rounded text-xs text-white" />
      )}
    </div>
  );
}
