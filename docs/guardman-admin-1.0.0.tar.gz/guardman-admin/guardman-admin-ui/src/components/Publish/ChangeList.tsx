// GuardMan Admin v2.0 — ChangeList Component

export interface PendingChange {
  entity_type: string;
  entity_slug: string;
  current_version: number;
  published_version: number;
  score: number;
  words: number;
  changes: { field: string; before: string; after: string }[];
  modified_at: string;
  modified_by: string;
  is_new: boolean;
}

interface Props {
  changes: PendingChange[];
  selected: Set<string>;
  onToggle: (slug: string) => void;
  onSelect: (change: PendingChange) => void;
  activeSlug: string | null;
}

const TYPE_LABELS: Record<string, string> = {
  service: 'Servicio',
  location: 'Ubicación',
  sector: 'Sector',
  combo: 'Combo',
  page: 'Página',
};

const TYPE_COLORS: Record<string, string> = {
  service: 'bg-blue-900/30 text-blue-300',
  location: 'bg-green-900/30 text-green-300',
  sector: 'bg-purple-900/30 text-purple-300',
  combo: 'bg-amber-900/30 text-amber-300',
  page: 'bg-pink-900/30 text-pink-300',
};

function formatName(slug: string): string {
  return slug.replace(/-/g, ' ').replace(/\//g, ' + ').replace(/\b\w/g, l => l.toUpperCase());
}

function timeAgo(dateStr: string): string {
  const now = Date.now();
  const then = new Date(dateStr).getTime();
  const diff = now - then;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Ahora';
  if (mins < 60) return `Hace ${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `Hace ${hours}h`;
  const days = Math.floor(hours / 24);
  return `Hace ${days}d`;
}

export function ChangeList({ changes, selected, onToggle, onSelect, activeSlug }: Props) {
  return (
    <div className="divide-y divide-gray-700/50">
      {changes.map(change => {
        const isActive = activeSlug === change.entity_slug;
        const isSelected = selected.has(change.entity_slug);
        const scoreColor = change.score >= 70 ? 'text-green-400' : change.score >= 50 ? 'text-yellow-400' : 'text-red-400';

        return (
          <div
            key={change.entity_slug}
            className={`p-3 cursor-pointer transition-colors hover:bg-gray-750 ${
              isActive ? 'bg-blue-900/20 border-l-2 border-blue-500' : ''
            }`}
            onClick={() => onSelect(change)}
          >
            <div className="flex items-start gap-2">
              {/* Checkbox */}
              <input
                type="checkbox"
                checked={isSelected}
                onChange={(e) => { e.stopPropagation(); onToggle(change.entity_slug); }}
                className="mt-0.5 shrink-0 rounded border-gray-600 bg-gray-700"
              />

              <div className="flex-1 min-w-0">
                {/* Header row */}
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs px-1.5 py-0.5 rounded ${TYPE_COLORS[change.entity_type] || 'bg-gray-700 text-gray-300'}`}>
                    {TYPE_LABELS[change.entity_type] || change.entity_type}
                  </span>
                  {change.is_new && (
                    <span className="text-xs bg-green-900/30 text-green-300 px-1.5 py-0.5 rounded">NUEVO</span>
                  )}
                  <span className={`text-xs font-mono ml-auto ${scoreColor}`}>
                    {change.score}pts
                  </span>
                </div>

                {/* Name */}
                <div className="font-medium text-sm truncate">{formatName(change.entity_slug)}</div>

                {/* Version info */}
                <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                  <span>v{change.published_version} → v{change.current_version}</span>
                  <span>{change.words} palabras</span>
                  <span>{timeAgo(change.modified_at)}</span>
                </div>

                {/* Changes summary */}
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {change.changes.slice(0, 3).map((c, i) => (
                    <span key={i} className="text-xs bg-gray-700/50 px-1.5 py-0.5 rounded text-gray-400 truncate max-w-[200px]">
                      {c.field}
                    </span>
                  ))}
                  {change.changes.length > 3 && (
                    <span className="text-xs text-gray-500">+{change.changes.length - 3} más</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
