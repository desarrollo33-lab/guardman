// GuardMan Admin v2.0 — DeployStatus (compact header version)

import { useState, useEffect } from 'react';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

export function DeployStatus() {
  const [deploy, setDeploy] = useState<any>(null);

  const check = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/publish/deploy-status`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` }
      });
      const data = await res.json();
      if (data.ok) setDeploy(data);
    } catch {}
  };

  useEffect(() => { check(); const i = setInterval(check, 30000); return () => clearInterval(i); }, []);

  if (!deploy) return <span className="text-xs text-white/20">Sin datos</span>;

  const icon = deploy.status === 'success' ? '✅' : deploy.status === 'failure' ? '❌' : deploy.status === 'active' ? '🔨' : '⏳';
  const ago = (() => {
    const h = Math.floor((Date.now() - new Date(deploy.created_on).getTime()) / 3600000);
    return h < 1 ? 'ahora' : h < 24 ? `${h}h` : `${Math.floor(h / 24)}d`;
  })();

  return (
    <div className="flex items-center gap-2 text-xs">
      <span>{icon}</span>
      <span className={deploy.status === 'success' ? 'text-emerald-400' : deploy.status === 'failure' ? 'text-red-400' : 'text-yellow-400'}>
        {deploy.status === 'success' ? 'Online' : deploy.status === 'failure' ? 'Falló' : deploy.status}
      </span>
      <span className="text-white/20">· hace {ago}</span>
      {deploy.url && (
        <a href={deploy.url} target="_blank" rel="noopener" className="text-blue-400 hover:underline ml-1">↗</a>
      )}
    </div>
  );
}
