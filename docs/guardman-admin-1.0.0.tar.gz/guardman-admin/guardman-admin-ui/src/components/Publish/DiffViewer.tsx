// GuardMan Admin v2.0 — DiffViewer Component
// Shows side-by-side comparison of published vs draft content

import type { PendingChange } from './ChangeList';

interface Props {
  change: PendingChange;
  diffData: any;
}

function formatName(slug: string): string {
  return slug.replace(/-/g, ' ').replace(/\//g, ' + ').replace(/\b\w/g, l => l.toUpperCase());
}

export function DiffViewer({ change, diffData }: Props) {
  const isNew = change.is_new || !diffData?.published;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-700 shrink-0">
        <h3 className="font-bold text-sm">{formatName(change.entity_slug)}</h3>
        <div className="flex items-center gap-3 mt-2 text-xs text-gray-400">
          <span>Tipo: {change.entity_type}</span>
          <span>v{change.published_version} → v{change.current_version}</span>
          <span className="ml-auto">{change.words} palabras</span>
        </div>
      </div>

      {/* Diff summary */}
      <div className="p-4 border-b border-gray-700 shrink-0">
        <h4 className="text-xs font-semibold text-gray-400 uppercase mb-3">
          {isNew ? 'Contenido nuevo' : `${diffData?.changes?.length || 0} cambios detectados`}
        </h4>
        <div className="space-y-2">
          {(diffData?.changes || change.changes).map((c: any, i: number) => (
            <div key={i} className="bg-gray-800/50 rounded-lg p-3">
              <div className="text-xs font-medium text-blue-400 mb-1">{c.field}</div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-red-400 uppercase">Antes</span>
                  <p className="text-xs text-red-300/70 mt-0.5 line-through">{c.before}</p>
                </div>
                <div>
                  <span className="text-[10px] text-green-400 uppercase">Después</span>
                  <p className="text-xs text-green-300/70 mt-0.5">{c.after}</p>
                </div>
              </div>
            </div>
          ))}
          {(!diffData?.changes && !change.changes?.length) && (
            <p className="text-xs text-gray-500">Sin diferencias detectadas</p>
          )}
        </div>
      </div>

      {/* Content Preview (draft) */}
      <div className="flex-1 overflow-y-auto p-4">
        <h4 className="text-xs font-semibold text-gray-400 uppercase mb-3">Vista previa del contenido</h4>
        
        {diffData?.draft ? (
          <div className="space-y-4 text-sm">
            {/* Hero */}
            {diffData.draft?.sections?.hero && (
              <div className="bg-gray-800 rounded-lg p-4">
                <span className="text-[10px] text-gray-500 uppercase">Hero</span>
                <h5 className="font-bold text-white mt-1">{diffData.draft.sections.hero.heading}</h5>
                {diffData.draft.sections.hero.subheading && (
                  <p className="text-gray-300 text-xs mt-1">{diffData.draft.sections.hero.subheading}</p>
                )}
              </div>
            )}

            {/* Meta */}
            {diffData.draft?.sections?.meta && (
              <div className="bg-gray-800 rounded-lg p-4">
                <span className="text-[10px] text-gray-500 uppercase">SEO Meta</span>
                <p className="text-xs text-gray-300 mt-1">
                  <span className="text-gray-500">Title:</span> {diffData.draft.sections.meta.title}
                </p>
                {diffData.draft.sections.meta.description && (
                  <p className="text-xs text-gray-300 mt-0.5">
                    <span className="text-gray-500">Desc:</span> {diffData.draft.sections.meta.description.substring(0, 120)}
                  </p>
                )}
              </div>
            )}

            {/* Intro */}
            {diffData.draft?.sections?.intro?.paragraphs && (
              <div className="bg-gray-800 rounded-lg p-4">
                <span className="text-[10px] text-gray-500 uppercase">Intro</span>
                <p className="text-xs text-gray-300 mt-1 line-clamp-3">
                  {diffData.draft.sections.intro.paragraphs[0]}
                </p>
              </div>
            )}

            {/* FAQs */}
            {diffData.draft?.sections?.faq && (
              <div className="bg-gray-800 rounded-lg p-4">
                <span className="text-[10px] text-gray-500 uppercase">FAQs ({Array.isArray(diffData.draft.sections.faq) ? diffData.draft.sections.faq.length : 0})</span>
                {(Array.isArray(diffData.draft.sections.faq) ? diffData.draft.sections.faq : []).slice(0, 3).map((faq: any, i: number) => (
                  <div key={i} className="mt-2 text-xs">
                    <p className="text-white font-medium">Q: {faq.question}</p>
                    <p className="text-gray-400 mt-0.5 line-clamp-2">A: {faq.answer}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Features */}
            {diffData.draft?.sections?.features?.items && (
              <div className="bg-gray-800 rounded-lg p-4">
                <span className="text-[10px] text-gray-500 uppercase">Features ({diffData.draft.sections.features.items.length})</span>
                <ul className="mt-1 space-y-0.5">
                  {diffData.draft.sections.features.items.slice(0, 5).map((item: string, i: number) => (
                    <li key={i} className="text-xs text-gray-300">• {item}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ) : (
          <p className="text-xs text-gray-500">Cargando contenido...</p>
        )}
      </div>

      {/* JSON Raw toggle */}
      <details className="p-4 border-t border-gray-700 shrink-0">
        <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-400">
          Ver JSON crudo
        </summary>
        <pre className="mt-2 text-[10px] text-gray-400 max-h-48 overflow-y-auto bg-gray-900 rounded p-2">
          {JSON.stringify(diffData?.draft?.sections || {}, null, 2)}
        </pre>
      </details>
    </div>
  );
}
