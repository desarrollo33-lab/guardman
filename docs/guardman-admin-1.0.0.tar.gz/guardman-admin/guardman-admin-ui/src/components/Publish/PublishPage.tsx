// GuardMan Admin v2.0 — PublishPage
// Global state via usePublish hook → survives section switches
// Clear deploy lifecycle: idle → exporting → deploying → success/failure

import { useState, useCallback } from 'react';
import { usePublish, type DeployState } from '../../hooks/usePublish';

const TYPE_ICON: Record<string, string> = { service: '🔧', location: '📍', sector: '🏭', combo: '🔗' };
const TYPE_LABEL: Record<string, string> = { service: 'Servicios', location: 'Ubicaciones', sector: 'Sectores', combo: 'Combos' };
const SCORE_BADGE = (s: number) => s >= 70 ? 'bg-emerald-900/30 text-emerald-400' : s >= 50 ? 'bg-amber-900/30 text-amber-400' : 'bg-red-900/30 text-red-400';

export function PublishPage() {
  const { pending, summary, deploy, load, deployAction, resetDeploy } = usePublish();
  const [filter, setFilter] = useState('');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<string | null>(null);
  const [showDeployView, setShowDeployView] = useState(false);

  // Apply filters
  const applyFilter = useCallback((f: string) => {
    const next = f === filter ? '' : f;
    setFilter(next);
    setSelected(new Set());
    load(next, search);
  }, [filter, search, load]);

  const applySearch = useCallback((s: string) => {
    setSearch(s);
    load(filter, s);
  }, [filter, load]);

  // Selection
  const isAllSelected = pending.length > 0 && selected.size === pending.length;
  const toggle = (slug: string) => setSelected(prev => { const n = new Set(prev); n.has(slug) ? n.delete(slug) : n.add(slug); return n; });
  const toggleAll = () => isAllSelected ? setSelected(new Set()) : setSelected(new Set(pending.map(e => e.entity_slug)));

  // Deploy actions
  const handleDeploySelected = async () => {
    const entities = pending.filter(e => selected.has(e.entity_slug)).map(e => ({ entity_type: e.entity_type, entity_slug: e.entity_slug }));
    if (entities.length === 0) return;
    setShowDeployView(true);
    await deployAction(entities);
  };

  const handleDeployAll = async () => {
    setShowDeployView(true);
    await deployAction(undefined, 'all');
  };

  // Helpers
  const fmt = (s: string) => s.replace(/-/g, ' ').replace(/\//g, ' › ').replace(/\b\w/g, l => l.toUpperCase());
  const ago = (d: string) => { const m = Math.floor((Date.now() - new Date(d).getTime()) / 60000); return m < 1 ? 'ahora' : m < 60 ? `${m}m` : `${Math.floor(m / 60)}h`; };

  // ===== DEPLOY IN PROGRESS VIEW =====
  if (deploy.phase !== 'idle') {
    return (
      <div className="flex-1 flex items-center justify-center bg-[#0D1525] p-8">
        <div className="max-w-lg w-full text-center">
          {/* Phase icon */}
          <div className="text-5xl mb-6">
            {deploy.phase === 'exporting' ? '📤' :
             deploy.phase === 'deploying' ? '🔨' :
             deploy.phase === 'success' ? '✅' : '❌'}
          </div>

          <h3 className="text-xl font-bold text-white mb-2">
            {deploy.phase === 'exporting' ? 'Exportando a GitHub...' :
             deploy.phase === 'deploying' ? 'Desplegando en Cloudflare...' :
             deploy.phase === 'success' ? '¡Publicación completada!' : 'Error en la publicación'}
          </h3>

          <p className="text-sm text-white/50 mb-6">
            {deploy.phase === 'exporting' && 'Guardando archivos JSON en el repositorio guardman-site...'}
            {deploy.phase === 'deploying' && (
              <>
                {deploy.exported || '?'} archivos exportados. Cloudflare Pages está construyendo el sitio.
                <br /><span className="text-white/30 mt-1 block">Esto toma 1-3 minutos. Podés ir a otra sección, el estado se conserva.</span>
              </>
            )}
            {deploy.phase === 'success' && (
              <>
                {deploy.exported || '?'} entidades publicadas exitosamente.
                {deploy.deploy_url && (
                  <a href={deploy.deploy_url} target="_blank" rel="noopener" className="block mt-2 text-blue-400 hover:underline">
                    {deploy.deploy_url} ↗
                  </a>
                )}
              </>
            )}
            {deploy.phase === 'failure' && deploy.errors?.map((e, i) => <span key={i} className="block text-red-400">{e}</span>)}
          </p>

          {/* Progress animation for deploying */}
          {deploy.phase === 'deploying' && (
            <div className="flex justify-center gap-1.5 mb-6">
              {[0, 1, 2].map(i => (
                <div key={i} className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
              ))}
            </div>
          )}

          <div className="flex gap-3 justify-center">
            {deploy.phase === 'success' && (
              <button onClick={resetDeploy} className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-sm font-semibold transition-colors">
                Volver a cambios pendientes
              </button>
            )}
            {deploy.phase === 'failure' && (
              <button onClick={resetDeploy} className="px-6 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-sm transition-colors">
                Reintentar
              </button>
            )}
            {(deploy.phase === 'exporting' || deploy.phase === 'deploying') && (
              <p className="text-xs text-white/30">Podés navegar a otras secciones — el deploy sigue en background</p>
            )}
          </div>

          {/* Elapsed time */}
          {deploy.startedAt && (
            <p className="text-xs text-white/20 mt-6">
              Tiempo transcurrido: {Math.floor((Date.now() - deploy.startedAt) / 1000)}s
            </p>
          )}
        </div>
      </div>
    );
  }

  // ===== MAIN REVIEW VIEW =====
  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#0D1525]">
      {/* ── HEADER ── */}
      <div className="p-5 border-b border-white/5 shrink-0">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">📦 Publicación</h2>
            <p className="text-xs text-white/40 mt-1">Control de cambios · GitHub · Cloudflare Pages</p>
          </div>
          <button onClick={() => load(filter, search)} className="px-3 py-1.5 text-xs bg-white/5 hover:bg-white/10 rounded-lg text-white/60 transition-colors">
            🔄 Refrescar
          </button>
        </div>

        {/* ── Summary Cards ── */}
        {summary && (
          <div className="flex gap-3 mt-4">
            {(['service','location','sector','combo'] as const).map(type => (
              <button
                key={type}
                onClick={() => applyFilter(type)}
                className={`flex-1 rounded-xl p-3 text-left transition-all ${
                  filter === type ? 'bg-blue-600/20 border border-blue-500/30' : 'bg-white/[0.03] border border-white/5 hover:bg-white/[0.06]'
                }`}
              >
                <div className="text-lg">{TYPE_ICON[type]}</div>
                <div className="text-2xl font-bold text-white mt-1">{summary[type + 's' as keyof typeof summary] || 0}</div>
                <div className="text-xs text-white/40">{TYPE_LABEL[type]}</div>
              </button>
            ))}
            <div className="flex-1 rounded-xl p-3 bg-white/[0.03] border border-white/5 min-w-[100px]">
              <div className="flex items-center justify-between">
                <span className="text-xs text-white/40">Score avg</span>
                <span className={`text-sm font-bold ${summary.avgScore >= 70 ? 'text-emerald-400' : 'text-amber-400'}`}>{summary.avgScore}</span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-white/40">Palabras</span>
                <span className="text-sm text-white/60">{summary.totalWords?.toLocaleString()}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ── TOOLBAR ── */}
      <div className="px-5 py-2 border-b border-white/5 flex items-center gap-3 shrink-0">
        <input
          type="text" value={search} onChange={e => applySearch(e.target.value)}
          placeholder="Buscar entidad..." className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white placeholder-white/20 focus:outline-none focus:border-blue-500/50"
        />
        <button onClick={toggleAll} className="text-xs text-white/50 hover:text-white/80 whitespace-nowrap">
          {isAllSelected ? 'Deseleccionar' : 'Seleccionar todos'}
        </button>
        <span className="text-xs text-white/30">{selected.size}/{pending.length}</span>
      </div>

      {/* ── LIST ── */}
      <div className="flex-1 overflow-y-auto px-5 py-3">
        {pending.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-4xl mb-4">✅</div>
            <p className="text-white/60 font-medium">Todo está publicado</p>
            <p className="text-sm text-white/30 mt-1">No hay cambios pendientes</p>
          </div>
        ) : (
          <div className="space-y-2">
            {pending.map(item => {
              const isSel = selected.has(item.entity_slug);
              const isExp = expanded === item.entity_slug;
              return (
                <div
                  key={item.entity_slug}
                  className={`rounded-xl border transition-all ${
                    isExp ? 'bg-white/[0.06] border-blue-500/30' :
                    isSel ? 'bg-white/[0.04] border-blue-500/20' : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="flex items-center gap-3 p-3 cursor-pointer" onClick={() => setExpanded(isExp ? null : item.entity_slug)}>
                    <input type="checkbox" checked={isSel} onChange={e => { e.stopPropagation(); toggle(item.entity_slug); }} className="shrink-0 rounded border-white/20 bg-white/5" />
                    <span className="text-sm">{TYPE_ICON[item.entity_type]}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-white font-medium truncate">{fmt(item.entity_slug)}</div>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-white/30">
                        <span>{TYPE_LABEL[item.entity_type]}</span>
                        {item.is_new && <span className="text-emerald-400 bg-emerald-900/20 px-1 rounded">NUEVO</span>}
                        <span>v{item.published_version}→v{item.current_version}</span>
                        <span>· {item.words} pal.</span>
                        <span>· {ago(item.modified_at)}</span>
                      </div>
                    </div>
                    <span className={`text-xs font-mono px-2 py-1 rounded-full ${SCORE_BADGE(item.score)}`}>{item.score}</span>
                    <svg className={`w-4 h-4 text-white/30 transition-transform ${isExp ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                  {isExp && (
                    <div className="px-4 pb-4 border-t border-white/5">
                      <div className="grid grid-cols-3 gap-3 mt-3 text-xs">
                        <div className="bg-white/[0.03] rounded-lg p-2">
                          <span className="text-white/30">Draft</span>
                          <span className="text-white font-mono block">v{item.current_version}</span>
                        </div>
                        <div className="bg-white/[0.03] rounded-lg p-2">
                          <span className="text-white/30">Publicada</span>
                          <span className="text-white font-mono block">{item.published_version === 0 ? '—' : `v${item.published_version}`}</span>
                        </div>
                        <div className="bg-white/[0.03] rounded-lg p-2">
                          <span className="text-white/30">Por</span>
                          <span className="text-white block">{item.modified_by}</span>
                        </div>
                      </div>
                      <div className="mt-3">
                        <span className="text-xs text-white/40 uppercase tracking-wider">Cambios</span>
                        <div className="mt-1.5 space-y-1.5">
                          {item.changes.map((c, i) => (
                            <div key={i} className="bg-white/[0.03] rounded-lg p-2 flex items-center gap-2 text-xs">
                              <span className="text-blue-400 font-medium shrink-0">{c.field}</span>
                              <span className="text-white/20">→</span>
                              <span className="text-white/70 truncate">{c.after}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── FOOTER ── */}
      <div className="p-4 border-t border-white/5 shrink-0 flex items-center gap-3">
        <button onClick={handleDeployAll} className="px-4 py-2 text-sm bg-white/5 hover:bg-white/10 rounded-lg text-white/50 transition-colors">
          Publicar TODO ({summary?.total || 0})
        </button>
        <div className="flex-1" />
        <button
          onClick={handleDeploySelected}
          disabled={selected.size === 0}
          className={`px-6 py-2.5 rounded-lg text-sm font-semibold transition-all ${
            selected.size === 0 ? 'bg-white/5 text-white/20 cursor-not-allowed' :
            'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/20'
          }`}
        >
          Publicar seleccionados ({selected.size})
        </button>
      </div>
    </div>
  );
}
