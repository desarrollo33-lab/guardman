// GuardMan Admin v2.0 — PipelineBar
// Shared component: shows content pipeline progress (5 stages)

import { useEffect, useState } from 'react';

interface PipelineData {
  total_combos: number;
  researched: number;
  with_content: number;
  published: number;
  in_serp: number;
  top3_serp: number;
}

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

// Global cache
let cachedPipeline: PipelineData | null = null;
let lastFetch = 0;

export function PipelineBar() {
  const [data, setData] = useState<PipelineData | null>(cachedPipeline);

  useEffect(() => {
    if (cachedPipeline && Date.now() - lastFetch < 60000) {
      setData(cachedPipeline);
      return;
    }
    fetch(`${API_BASE}/api/intel/dashboard`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` }
    })
    .then(r => r.json())
    .then(d => {
      if (d.data?.pipeline) {
        cachedPipeline = d.data.pipeline;
        lastFetch = Date.now();
        setData(d.data.pipeline);
      }
    })
    .catch(() => {});
  }, []);

  if (!data) return null;

  const stages = [
    { label: 'Invest.', value: data.researched, color: 'bg-blue-500' },
    { label: 'Contenido', value: data.with_content, color: 'bg-purple-500' },
    { label: 'Publicado', value: data.published, color: 'bg-yellow-500' },
    { label: 'En SERP', value: data.in_serp, color: 'bg-orange-500' },
    { label: 'TOP 3', value: data.top3_serp, color: 'bg-emerald-500' },
  ];

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-white/[0.03] rounded-lg text-xs">
      {stages.map((s, i) => (
        <div key={s.label} className="flex items-center gap-1.5">
          <div className="w-12 h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${s.color} transition-all duration-500`}
              style={{ width: `${Math.max(3, (s.value / Math.max(data.total_combos, 1)) * 100)}%` }}
            />
          </div>
          <span className="text-white/30">{s.label}</span>
          <span className="text-white/50 font-mono text-[10px]">{s.value}</span>
          {i < stages.length - 1 && <span className="text-white/10 mx-0.5">·</span>}
        </div>
      ))}
    </div>
  );
}
