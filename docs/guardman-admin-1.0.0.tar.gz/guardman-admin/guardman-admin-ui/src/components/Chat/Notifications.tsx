// GuardMan v12 — Inline Notifications
import { useEffect, useState } from 'react';

export type NotifType = 'success' | 'warning' | 'error' | 'loading' | 'info';

interface Notif {
  id: string;
  type: NotifType;
  message: string;
}

export function Notifications({ items, dismiss }: { items: Notif[]; dismiss: (id: string) => void }) {
  if (!items.length) return null;
  return (
    <div className="px-4 py-1.5 space-y-1.5">
      {items.map(n => <NotifItem key={n.id} notif={n} dismiss={dismiss} />)}
    </div>
  );
}

function NotifItem({ notif, dismiss }: { notif: Notif; dismiss: (id: string) => void }) {
  const [out, setOut] = useState(false);

  useEffect(() => {
    if (notif.type !== 'loading') {
      const t = setTimeout(() => { setOut(true); setTimeout(() => dismiss(notif.id), 200); }, 4000);
      return () => clearTimeout(t);
    }
  }, [notif, dismiss]);

  const colors: Record<string, string> = {
    success: 'border-emerald-500/20 bg-emerald-500/5 text-emerald-400',
    error:   'border-red-500/20 bg-red-500/5 text-red-400',
    warning: 'border-amber-500/20 bg-amber-500/5 text-amber-400',
    loading: 'border-blue-500/20 bg-blue-500/5 text-blue-400',
    info:    'border-sky-500/20 bg-sky-500/5 text-sky-400',
  };

  return (
    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs transition-opacity duration-200 ${colors[notif.type]} ${out ? 'opacity-0' : 'opacity-100'}`}>
      {notif.type === 'loading' && <span className="w-3 h-3 border-2 border-current border-t-transparent rounded-full animate-spin" />}
      <span className="flex-1">{notif.message}</span>
      <button onClick={() => { setOut(true); setTimeout(() => dismiss(notif.id), 200); }} className="opacity-40 hover:opacity-80">✕</button>
    </div>
  );
}

export function useNotifications() {
  const [items, setItems] = useState<Notif[]>([]);
  const add = (type: NotifType, message: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setItems(p => [...p, { id, type, message }]);
    return id;
  };
  const dismiss = (id: string) => setItems(p => p.filter(n => n.id !== id));
  return { items, add, dismiss };
}
