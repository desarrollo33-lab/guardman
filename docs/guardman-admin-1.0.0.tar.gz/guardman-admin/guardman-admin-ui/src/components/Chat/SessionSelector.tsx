// GuardMan v12 — Session Selector (multi-session history panel)
// Item 19: Historial multi-sesión UI
// Fetches sessions from D1 via backend API, allows switching between sessions

import { useState, useEffect, useCallback, useRef } from 'react';
import { getToken } from '../../hooks/useApi';

const API_HOST = 'guardman.oficinadesarrollo33.workers.dev';

interface ChatSession {
  id: number;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

interface SessionSelectorProps {
  activeSessionId: number | null;
  onSelectSession: (sessionId: number) => void;
  onNewSession: () => void;
  onDeleteSession: (sessionId: number) => void;
  onClose: () => void;
}

export function SessionSelector({
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onClose,
}: SessionSelectorProps) {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  // Fetch sessions on mount
  useEffect(() => {
    loadSessions();
  }, []);

  // Close on click outside
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [onClose]);

  // Close on Escape
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const loadSessions = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const token = getToken();
      if (!token) throw new Error('No auth token');

      const res = await fetch(`https://${API_HOST}/api/chat/sessions`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) {
        setSessions(data.data.sessions || []);
      } else {
        throw new Error(data.error || 'Failed to load sessions');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleDelete = useCallback(async (e: React.MouseEvent, sessionId: number) => {
    e.stopPropagation();
    setDeletingId(sessionId);
    try {
      const token = getToken();
      if (!token) return;

      const res = await fetch(`https://${API_HOST}/api/chat/sessions/${sessionId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok) {
        setSessions(prev => prev.filter(s => s.id !== sessionId));
        onDeleteSession(sessionId);
      }
    } catch {
      // Silently fail
    } finally {
      setDeletingId(null);
    }
  }, [onDeleteSession]);

  const formatDate = (isoStr: string) => {
    try {
      const d = new Date(isoStr);
      const now = new Date();
      const diffMs = now.getTime() - d.getTime();
      const diffMin = Math.floor(diffMs / 60000);
      const diffHr = Math.floor(diffMs / 3600000);
      const diffDay = Math.floor(diffMs / 86400000);

      if (diffMin < 1) return 'Ahora';
      if (diffMin < 60) return `Hace ${diffMin}m`;
      if (diffHr < 24) return `Hace ${diffHr}h`;
      if (diffDay < 7) return `Hace ${diffDay}d`;
      return d.toLocaleDateString('es-CL', { day: 'numeric', month: 'short' });
    } catch {
      return '';
    }
  };

  return (
    <div
      ref={panelRef}
      className="absolute left-16 bottom-16 z-50 w-80 bg-[#0f1729] border border-white/[0.08] 
        rounded-xl shadow-2xl overflow-hidden flex flex-col"
      style={{ maxHeight: '70vh' }}
    >
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 py-3 border-b border-white/[0.06]">
        <div className="flex items-center gap-2">
          <span className="text-sm">💬</span>
          <span className="text-xs font-medium text-white/70">Sesiones</span>
          <span className="text-[10px] text-white/30 bg-white/5 px-1.5 py-0.5 rounded">
            {sessions.length}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => { onNewSession(); onClose(); }}
            className="px-2 py-1 text-[10px] bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 
              rounded transition-colors"
          >
            + Nueva
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-white/[0.06] text-white/30 hover:text-white/60 transition-colors"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      </div>

      {/* Sessions list */}
      <div className="flex-1 overflow-y-auto min-h-0">
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="w-5 h-5 border-2 border-white/20 border-t-blue-400 rounded-full animate-spin" />
          </div>
        ) : error ? (
          <div className="px-4 py-6 text-center">
            <p className="text-xs text-red-400/70">{error}</p>
            <button
              onClick={loadSessions}
              className="mt-2 text-[10px] text-blue-400/60 hover:text-blue-400 transition-colors"
            >
              Reintentar
            </button>
          </div>
        ) : sessions.length === 0 ? (
          <div className="px-4 py-8 text-center">
            <span className="text-2xl block mb-2">📭</span>
            <p className="text-xs text-white/25">No hay sesiones guardadas</p>
          </div>
        ) : (
          <div className="py-1">
            {sessions.map(session => (
              <div
                key={session.id}
                onClick={() => { onSelectSession(session.id); onClose(); }}
                className={`group px-4 py-2.5 cursor-pointer transition-colors border-l-2
                  ${session.id === activeSessionId
                    ? 'bg-blue-500/10 border-l-blue-400'
                    : 'border-l-transparent hover:bg-white/[0.03]'
                  }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs truncate ${
                      session.id === activeSessionId ? 'text-white/90' : 'text-white/60'
                    }`}>
                      {session.title || 'Sin título'}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-white/25">
                        {session.message_count} msgs
                      </span>
                      <span className="text-[10px] text-white/20">
                        {formatDate(session.updated_at)}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={(e) => handleDelete(e, session.id)}
                    disabled={deletingId === session.id}
                    className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-500/20 
                      text-white/20 hover:text-red-400 transition-all shrink-0"
                    title="Eliminar sesión"
                  >
                    {deletingId === session.id ? (
                      <div className="w-3 h-3 border border-white/20 border-t-red-400 rounded-full animate-spin" />
                    ) : (
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
