// GuardMan v12.2 — ChatView with Agentic Panels
// Chat + Preview + Editor + Approval + Charts in a unified layout
import { useState, useRef, useEffect, useCallback } from 'react';
import { useAgent } from 'agents/react';
import { useAgentChat } from '@cloudflare/ai-chat/react';
import { getToken } from '../../hooks/useApi';
import type { UIMessage } from 'ai';
import { MiniDashboard } from './MiniDashboard';
import { MobileQuickActions } from '../Mobile/MobileQuickActions';
import { PreviewFrame } from '../Preview/PreviewFrame';
import { ChartPanel } from '../Chart/ChartPanel';
import { MonacoEditor, SimpleEditor, isShortField } from '../Editor/MonacoEditor';
import { SessionSelector } from './SessionSelector';

const API_HOST = 'guardman.oficinadesarrollo33.workers.dev';
const STORAGE_KEY = 'gm_chat_history_v12';
const SESSION_ID_KEY = 'gm_session_id';

// ── Types ────────────────────────────────────────
type PanelType = 'preview' | 'editor' | 'approval' | 'chart' | null;

interface PreviewState { type: string; slug: string; serviceSlug?: string; locationSlug?: string; }
interface EditState { serviceSlug: string; locationSlug: string; field: string; value: string; }
interface ApprovalItem { id: number; entity_type: string; entity_slug: string; title: string; score: number; status: string; }
interface PendingApproval { id: string; action_type: string; description: string; item_count: number; params: any; options: { id: string; label: string; action: string; params: any }[]; }

export function ChatView({ onToggleHistory, historyOpen }: { onToggleHistory?: () => void; historyOpen?: boolean }) {
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');
  const [inputValue, setInputValue] = useState('');
  const [isReady, setIsReady] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  // ── Panel state ────────────────────────────────
  const [activePanel, setActivePanel] = useState<PanelType>(null);
  const [previewState, setPreviewState] = useState<PreviewState>({ type: '', slug: '' });
  const [editState, setEditState] = useState<EditState | null>(null);
  const [editDisplayValue, setEditDisplayValue] = useState('');
  const [approvalItems, setApprovalItems] = useState<ApprovalItem[]>([]);
  const [pendingApprovals, setPendingApprovals] = useState<PendingApproval[]>([]);
  const [chartData, setChartData] = useState<any>(null);
  const [chartType, setChartType] = useState<string | null>(null);

  // ── Messages ───────────────────────────────────
  const [sessionId, setSessionId] = useState<number | null>(() => {
    const stored = localStorage.getItem(SESSION_ID_KEY);
    return stored ? parseInt(stored) : null;
  });
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);

  const [showHistory, setShowHistory] = useState(false);
  const [messages, setMessages] = useState<UIMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) { const p = JSON.parse(saved); if (Array.isArray(p) && p.length) return p; }
    } catch {}
    return [];
  });

  // Save to localStorage (immediate) + D1 (debounced)
  const saveMessagesLocal = useCallback((m: UIMessage[]) => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(m.slice(-50))); } catch {}
  }, []);

  const saveMessagesRemote = useCallback(async (m: UIMessage[]) => {
    try {
      const token = getToken() || '';
      const messagesPayload = m.slice(-50).map(msg => ({
        role: msg.role,
        parts: (msg as any).parts || [{ type: 'text', text: (msg as any).content || '' }],
      }));

      const res = await fetch(`https://${API_HOST}/api/chat/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          session_id: sessionId,
          messages: messagesPayload,
        }),
      });
      const data = await res.json();
      if (data.ok && data.data?.session_id && !sessionId) {
        setSessionId(data.data.session_id);
        localStorage.setItem(SESSION_ID_KEY, String(data.data.session_id));
      }
    } catch {
      // Silently fail — localStorage is the fallback
    }
  }, [sessionId]);

  // Debounced remote save (2s after last change)
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const saveMessages = useCallback((m: UIMessage[]) => {
    saveMessagesLocal(m);
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => saveMessagesRemote(m), 2000);
  }, [saveMessagesLocal, saveMessagesRemote]);

  // Load history from D1 on mount (if session exists)
  useEffect(() => {
    if (!sessionId) return;
    const token = getToken();
    if (!token) return;

    setIsLoadingHistory(true);
    fetch(`https://${API_HOST}/api/chat/sessions/${sessionId}`, {
      headers: { 'Authorization': `Bearer ${token}` },
    })
      .then(r => r.json())
      .then(data => {
        if (data.ok && data.data?.messages?.length > 0) {
          const restored: UIMessage[] = data.data.messages.map((m: any) => ({
            id: `db-${m.id}`,
            role: m.role,
            parts: typeof m.parts === 'string' ? JSON.parse(m.parts) : m.parts,
            createdAt: m.created_at,
          }) as UIMessage);
          setMessages(restored);
          saveMessagesLocal(restored);
        }
      })
      .catch(() => { /* localStorage is fallback */ })
      .finally(() => setIsLoadingHistory(false));
  }, []); // Only on mount

  const getAuthQuery = useCallback(async () => {
    const token = getToken() || '';
    return { token } as Record<string, string>;
  }, []);

  const agent = useAgent({
    agent: 'ORCHESTRATOR',
    name: 'default',
    host: API_HOST,
    protocol: 'wss',
    query: getAuthQuery,
    onIdentity: () => { setConnectionStatus('connected'); setIsReady(true); },
    onStateUpdateError: () => { setConnectionStatus('disconnected'); setIsReady(false); },
  });

  useEffect(() => {
    agent.ready.then(() => { setConnectionStatus('connected'); setIsReady(true); }).catch(() => setConnectionStatus('disconnected'));
  }, [agent.ready]);

  const { sendMessage, clearHistory, status, messages: agentMessages } = useAgentChat({ agent });
  const isStreaming = status === 'streaming';

  useEffect(() => {
    if (agentMessages && Array.isArray(agentMessages)) {
      setMessages(agentMessages as UIMessage[]);
      saveMessages(agentMessages as UIMessage[]);
    }
  }, [agentMessages, saveMessages]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  useEffect(() => {
    const h = (e: Event) => { const d = (e as CustomEvent<string>).detail; if (d) setInputValue(d); };
    window.addEventListener('gm:send-message', h);
    // Listen for history toggle from Sidebar
    const toggleHistory = () => setShowHistory(prev => !prev);
    window.addEventListener('gm:toggle-history', toggleHistory);
    return () => {
      window.removeEventListener('gm:send-message', h);
      window.removeEventListener('gm:toggle-history', toggleHistory);
    };
  }, []);

  // ── Panel helpers ──────────────────────────────
  const openPanel = useCallback((type: PanelType) => {
    setActivePanel(prev => prev === type ? null : type);
  }, []);

  const closePanel = useCallback(() => {
    setActivePanel(null);
  }, []);

  // ── Tool result detection ──────────────────────
  useEffect(() => {
    if (messages.length === 0) return;
    const lastMsg = messages[messages.length - 1];
    if (lastMsg.role !== 'assistant') return;

    const msgParts = (lastMsg as any).parts || [];

    for (const part of msgParts as any[]) {
      // Only process parts with output (completed tool calls)
      const isDynamicTool = part.type === 'dynamic-tool' && part.state === 'output-available';
      const isNamedTool = typeof part.type === 'string' && part.type.startsWith('tool-') && part.type !== 'tool-call' && part.type !== 'tool-result' && part.state === 'output-available';
      if (!isDynamicTool && !isNamedTool) continue;

      const toolName = part.toolName || part.type?.replace(/^tool-/, '') || '';
      const result = part.output;
      if (!result) continue;

      // Detect open_panel tool result
      if (result.panel_action && result.panel_type) {
        const { panel_action, panel_type, params } = result;
        if (panel_action === 'open' || panel_action === 'toggle') {
          switch (panel_type) {
            case 'preview':
              if (params?.service_slug) {
                setPreviewState({
                  type: 'combo',
                  slug: params.location_slug ? `${params.service_slug}-${params.location_slug}` : params.service_slug,
                  serviceSlug: params.service_slug,
                  locationSlug: params.location_slug,
                });
                setActivePanel('preview');
              }
              break;
            case 'editor':
              if (params?.service_slug) {
                setEditState({
                  serviceSlug: params.service_slug,
                  locationSlug: params.location_slug || '',
                  field: params.field || 'h1',
                  value: params.content || '',
                });
                setEditDisplayValue(params.content || '');
                setActivePanel('editor');
              }
              break;
            case 'approval':
              setActivePanel('approval');
              break;
            case 'chart':
              if (result.chart_data) {
                setChartData(result.chart_data);
                setChartType(result.params?.chart_type || null);
              }
              setActivePanel('chart');
              break;
          }
        }
        continue;
      }

      // Detect read_content → auto-open preview
      if (toolName === 'read_content' && result.found === true && result.type === 'combo') {
        setPreviewState({
          type: 'combo',
          slug: `${result.service}-${result.location}`,
          serviceSlug: result.service,
          locationSlug: result.location,
        });
        setActivePanel('preview');
        continue;
      }

      // Detect publish_preview → show approval
      if (toolName === 'publish_preview' && result.items && Array.isArray(result.items)) {
        setApprovalItems(result.items);
        setActivePanel('approval');
        continue;
      }

      // Detect request_approval
      if (toolName === 'request_approval' && result.pending_approval === true) {
        const approval: PendingApproval = {
          id: result.approval_options?.[0]?.id || `approval_${Date.now()}`,
          action_type: result.action_type,
          description: result.description,
          item_count: result.item_count || 1,
          params: result.params || {},
          options: result.approval_options || [],
        };
        setPendingApprovals(prev => [...prev, approval]);
        setActivePanel('approval');
        continue;
      }

      // Detect generate_chart with chart_data
      if (toolName === 'generate_chart' && result.chart_data) {
        setChartData(result.chart_data);
        setChartType(result.params?.chart_type || null);
        setActivePanel('chart');
        continue;
      }
    }
  }, [messages]);

  // ── Handlers ───────────────────────────────────
  const handleSend = useCallback((text?: string) => {
    const msg = (text || inputValue).trim();
    if (!msg || isStreaming) return;
    sendMessage({ role: 'user', parts: [{ type: 'text', text: msg }] });
    setInputValue('');
  }, [inputValue, isStreaming, sendMessage]);

  const handleClear = useCallback(() => {
    clearHistory();
    setMessages([]);
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(SESSION_ID_KEY);
    // Delete remote session
    if (sessionId) {
      const token = getToken();
      if (token) {
        fetch(`https://${API_HOST}/api/chat/sessions/${sessionId}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` },
        }).catch(() => {});
      }
    }
    setSessionId(null);
  }, [clearHistory, sessionId]);

  // ── Session management (Item 19) ────────────
  const handleSelectSession = useCallback(async (targetSessionId: number) => {
    const token = getToken();
    if (!token) return;
    try {
      const res = await fetch(`https://${API_HOST}/api/chat/sessions/${targetSessionId}`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.ok && data.data?.messages?.length > 0) {
        const restored: UIMessage[] = data.data.messages.map((m: any) => ({
          id: `db-${m.id}`,
          role: m.role,
          parts: typeof m.parts === 'string' ? JSON.parse(m.parts) : m.parts,
          createdAt: m.created_at,
        }) as UIMessage);
        setMessages(restored);
        saveMessagesLocal(restored);
        setSessionId(targetSessionId);
        localStorage.setItem(SESSION_ID_KEY, String(targetSessionId));
      } else if (data.ok) {
        // Empty session
        setMessages([]);
        setSessionId(targetSessionId);
        localStorage.setItem(SESSION_ID_KEY, String(targetSessionId));
      }
    } catch {
      // Keep current messages on error
    }
  }, [saveMessagesLocal]);

  const handleNewSession = useCallback(() => {
    clearHistory();
    setMessages([]);
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(SESSION_ID_KEY);
    setSessionId(null);
    setShowHistory(false);
  }, [clearHistory]);

  const handleDeleteSession = useCallback((deletedId: number) => {
    if (deletedId === sessionId) {
      // Deleted current session — reset
      clearHistory();
      setMessages([]);
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(SESSION_ID_KEY);
      setSessionId(null);
    }
  }, [sessionId, clearHistory]);

  const handleSubmit = useCallback((e: React.FormEvent) => { e.preventDefault(); handleSend(); }, [handleSend]);

  const handleEditorSave = useCallback((newValue: string) => {
    if (!editState) return;
    const instruction = `Actualiza el campo ${editState.field} de ${editState.serviceSlug} en ${editState.locationSlug || 'general'} con este contenido:\n\n${newValue}`;
    sendMessage({ role: 'user', parts: [{ type: 'text', text: instruction }] });
    setActivePanel(null);
    setEditState(null);
  }, [editState, sendMessage]);

  const handleApproveItem = useCallback((item: ApprovalItem) => {
    sendMessage({ role: 'user', parts: [{ type: 'text', text: `Publica "${item.entity_slug}"` }] });
    setApprovalItems(prev => prev.filter(i => i.id !== item.id));
  }, [sendMessage]);

  const handlePendingApproval = useCallback((approval: PendingApproval, option: any) => {
    if (option.action === 'cancel') {
      sendMessage({ role: 'user', parts: [{ type: 'text', text: `Rechazado: ${approval.description}` }] });
    } else {
      sendMessage({ role: 'user', parts: [{ type: 'text', text: `Aprobado: ${approval.description}` }] });
    }
    setPendingApprovals(prev => prev.filter(a => a.id !== approval.id));
  }, [sendMessage]);

  // ── Connection dot ─────────────────────────────
  const dotColor = connectionStatus === 'connected' ? 'bg-emerald-400' : connectionStatus === 'connecting' ? 'bg-amber-400 animate-pulse' : 'bg-red-400';

  // ── Panel open count (for badge) ───────────────
  const panelBadge = (pendingApprovals.length + approvalItems.length) > 0
    ? (pendingApprovals.length + approvalItems.length) : 0;

  return (
    <div className="flex h-full min-h-0 relative">
      {/* Session Selector Panel */}
      {showHistory && (
        <SessionSelector
          activeSessionId={sessionId}
          onSelectSession={handleSelectSession}
          onNewSession={handleNewSession}
          onDeleteSession={handleDeleteSession}
          onClose={() => setShowHistory(false)}
        />
      )}
      {/* ── Chat column ──────────────────────────── */}
      <div className="flex flex-col flex-1 min-w-0">
        {/* Slim header */}
        <div className="h-11 shrink-0 flex items-center justify-between px-4 bg-[#0f1729] border-b border-white/[0.04]">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${dotColor}`} />
            <span className="text-xs text-white/30 truncate">
              {connectionStatus === 'connected' ? 'Orchestrator conectado' : connectionStatus === 'connecting' ? 'Conectando...' : 'Desconectado'}
            </span>
            {isStreaming && (
              <span className="text-[10px] text-blue-400 ml-1">● procesando</span>
            )}
          </div>
          <div className="flex items-center gap-1">
            {/* Panel toggle buttons */}
            <button onClick={() => openPanel('preview')} title="Preview"
              className={`p-1.5 rounded-md transition-colors ${activePanel === 'preview' ? 'bg-blue-500/20 text-blue-400' : 'text-white/20 hover:text-white/60 hover:bg-white/[0.06]'}`}>
              <EyeIcon />
            </button>
            <button onClick={() => openPanel('editor')} title="Editor"
              className={`p-1.5 rounded-md transition-colors ${activePanel === 'editor' ? 'bg-blue-500/20 text-blue-400' : 'text-white/20 hover:text-white/60 hover:bg-white/[0.06]'}`}>
              <EditIcon />
            </button>
            <button onClick={() => openPanel('approval')} title="Aprobaciones"
              className={`p-1.5 rounded-md transition-colors relative ${activePanel === 'approval' ? 'bg-blue-500/20 text-blue-400' : 'text-white/20 hover:text-white/60 hover:bg-white/[0.06]'}`}>
              <ClipboardIcon />
              {panelBadge > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-orange-500 text-[8px] text-white flex items-center justify-center font-bold">{panelBadge > 9 ? '9+' : panelBadge}</span>
              )}
            </button>
            <button onClick={() => openPanel('chart')} title="Gráficos"
              className={`p-1.5 rounded-md transition-colors ${activePanel === 'chart' ? 'bg-blue-500/20 text-blue-400' : 'text-white/20 hover:text-white/60 hover:bg-white/[0.06]'}`}>
              <ChartIcon />
            </button>
            <div className="w-px h-4 bg-white/[0.06] mx-1" />
            <button onClick={handleClear} className="p-1.5 rounded-md hover:bg-white/[0.06] text-white/20 hover:text-white/60 transition-colors" title="Limpiar">
              <TrashIcon />
            </button>
          </div>
        </div>

        {/* Collapsible Mini Dashboard */}
        <MiniDashboard />

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {messages.length === 0 ? (
            <Welcome onSend={handleSend} />
          ) : (
            <div className="p-4 space-y-3">
              {messages.map((msg: UIMessage, idx: number) => {
                if (msg.role === 'user') return <UserBubble key={msg.id || idx} message={msg} />;
                if (msg.role === 'assistant') return (
                  <AssistantBubble
                    key={msg.id || idx}
                    message={msg}
                    isLatest={idx === messages.length - 1}
                    isStreaming={isStreaming}
                    onOpenPreview={(type, slug) => { setPreviewState({ type, slug: slug.replace(/\//g, '-') }); setActivePanel('preview'); }}
                    onEditField={(svc, loc, field, val) => {
                      setEditState({ serviceSlug: svc, locationSlug: loc, field, value: val });
                      setEditDisplayValue(val);
                      setActivePanel('editor');
                    }}
                  />
                );
                return null;
              })}
              <div ref={bottomRef} />
            </div>
          )}
        </div>

        {/* Bottom bar */}
        <MobileQuickActions onAction={(m) => handleSend(m)} />
        <div className="shrink-0 p-3 bg-[#0f1729] border-t border-white/[0.04]">
          <form onSubmit={handleSubmit} className="flex gap-2 items-end">
            <textarea
              value={inputValue}
              onChange={e => setInputValue(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(e); } }}
              placeholder={isReady ? 'Escribe un mensaje…' : 'Conectando…'}
              disabled={isStreaming || !isReady}
              rows={1}
              className="flex-1 bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2 text-sm text-white
                placeholder-white/20 focus:outline-none focus:border-blue-500/40 resize-none min-h-[40px] max-h-[100px]"
            />
            <button
              type="submit"
              disabled={isStreaming || !inputValue.trim() || !isReady}
              className="w-9 h-9 shrink-0 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-20
                flex items-center justify-center transition-colors"
            >
              {isStreaming ? (
                <svg className="animate-spin h-4 w-4 text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
              ) : (
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
                </svg>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* ── Side Panel ───────────────────────────── */}
      {activePanel && (
        <div className="w-[420px] shrink-0 border-l border-white/[0.04] bg-[#0a0e1a] flex flex-col overflow-hidden">
          {/* Panel header */}
          <div className="h-11 shrink-0 flex items-center justify-between px-3 border-b border-white/[0.04]">
            <span className="text-xs text-white/50">
              {activePanel === 'preview' && '👁️ Preview'}
              {activePanel === 'editor' && '✏️ Editor'}
              {activePanel === 'approval' && '📋 Aprobaciones'}
              {activePanel === 'chart' && '📊 Gráficos'}
            </span>
            <button onClick={closePanel} className="p-1 rounded hover:bg-white/[0.06] text-white/30 hover:text-white/70 transition-colors">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          {/* Panel content */}
          <div className="flex-1 overflow-y-auto min-h-0">
            {activePanel === 'preview' && previewState.slug && (
              <PreviewFrame entityType={previewState.type} entitySlug={previewState.slug} />
            )}
            {activePanel === 'preview' && !previewState.slug && (
              <div className="flex flex-col items-center justify-center h-full text-white/20 text-sm">
                <span className="text-2xl mb-2">👁️</span>
                <p>Genera contenido para ver el preview</p>
              </div>
            )}

            {activePanel === 'editor' && editState && (
              <div className="p-3 flex flex-col gap-3">
                <div className="text-xs text-white/40">
                  <span className="text-white/60">{editState.serviceSlug}</span>
                  {editState.locationSlug && <span> + <span className="text-white/60">{editState.locationSlug}</span></span>}
                  <span className="ml-2 text-blue-400/60">→ {editState.field}</span>
                </div>
                {/* Lección #39: SimpleEditor para campos cortos, Monaco solo para textos largos */}
                {isShortField(editState.field) ? (
                  <SimpleEditor
                    value={editDisplayValue}
                    onChange={setEditDisplayValue}
                    field={editState.field}
                    placeholder={`Edita ${editState.field}...`}
                    onSave={handleEditorSave}
                  />
                ) : (
                  <MonacoEditor
                    value={editDisplayValue}
                    onChange={setEditDisplayValue}
                    language="markdown"
                    height={300}
                    maxHeight={500}
                    placeholder={`Edita ${editState.field}...`}
                    onSave={handleEditorSave}
                  />
                )}
                <div className="flex gap-2">
                  <button onClick={() => handleEditorSave(editDisplayValue)}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs text-white transition-colors">
                    Guardar cambios
                  </button>
                  <button onClick={() => { setActivePanel(null); setEditState(null); }}
                    className="px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-xs text-white/50 transition-colors">
                    Cancelar
                  </button>
                </div>
              </div>
            )}
            {activePanel === 'editor' && !editState && (
              <div className="flex flex-col items-center justify-center h-full text-white/20 text-sm">
                <span className="text-2xl mb-2">✏️</span>
                <p>Pide editar un campo para abrir el editor</p>
              </div>
            )}

            {activePanel === 'approval' && (
              <ApprovalPanel
                items={approvalItems}
                pendingApprovals={pendingApprovals}
                onApproveItem={handleApproveItem}
                onPendingApproval={handlePendingApproval}
              />
            )}

            {activePanel === 'chart' && (
              <ChartPanel onClose={closePanel} chartData={chartData} activeChart={chartType as any} />
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ── Approval Panel ──────────────────────────── */

function ApprovalPanel({ items, pendingApprovals, onApproveItem, onPendingApproval }: {
  items: ApprovalItem[];
  pendingApprovals: PendingApproval[];
  onApproveItem: (item: ApprovalItem) => void;
  onPendingApproval: (approval: PendingApproval, option: any) => void;
}) {
  const total = items.length + pendingApprovals.length;

  if (total === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-white/20 text-sm">
        <span className="text-2xl mb-2">📋</span>
        <p>No hay items pendientes</p>
        <p className="text-white/10 mt-1 text-xs">Usa "Ver cola de publicación" para cargar</p>
      </div>
    );
  }

  return (
    <div className="p-3 space-y-3">
      {pendingApprovals.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] text-orange-400 uppercase tracking-wide">Aprobaciones Pendientes</p>
          {pendingApprovals.map(approval => (
            <div key={approval.id} className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3">
              <p className="text-xs text-orange-300 font-medium">{approval.description}</p>
              <p className="text-[10px] text-white/40 mt-0.5">{approval.item_count} item(s) • {approval.action_type}</p>
              <div className="flex gap-2 mt-2">
                {approval.options.map(option => (
                  <button key={option.id} onClick={() => onPendingApproval(approval, option)}
                    className={`px-3 py-1 rounded text-xs transition-colors ${
                      option.action === 'cancel' ? 'bg-white/5 hover:bg-white/10 text-white/50' : 'bg-green-600/30 hover:bg-green-600/50 text-green-400'
                    }`}>
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {items.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] text-blue-400 uppercase tracking-wide">Cola de Publicación</p>
          {items.map(item => (
            <div key={item.id} className="bg-white/[0.03] rounded-lg p-2.5">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white/80 font-medium truncate">{item.title || item.entity_slug}</p>
                  <p className="text-[10px] text-white/30">{item.entity_slug}</p>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded mt-1 inline-block ${
                    item.score >= 85 ? 'bg-green-500/20 text-green-400' :
                    item.score >= 75 ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    Score: {item.score}
                  </span>
                </div>
                <button onClick={() => onApproveItem(item)}
                  className="px-2 py-1 bg-green-600/30 hover:bg-green-600/50 rounded text-[10px] text-green-400 transition-colors">
                  Publicar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Message bubbles ──────────────────────────── */

function UserBubble({ message }: { message: UIMessage }) {
  const text = extractText(message);
  return (
    <div className="flex justify-end">
      <div className="max-w-[80%] rounded-2xl rounded-br-sm px-3.5 py-2 bg-blue-600 text-white text-sm whitespace-pre-wrap leading-relaxed">
        {text}
      </div>
    </div>
  );
}

function AssistantBubble({ message, isLatest, isStreaming, onOpenPreview, onEditField }: {
  message: UIMessage; isLatest: boolean; isStreaming: boolean;
  onOpenPreview: (type: string, slug: string) => void;
  onEditField: (svc: string, loc: string, field: string, val: string) => void;
}) {
  const text = extractText(message);
  const tools = extractTools(message);
  const toolResults = extractToolResults(message);
  const hasTools = tools.length > 0;
  const thinking = !text && isLatest && isStreaming;

  // Detect generate result → offer preview + edit
  const generateResult = toolResults.find((r: any) => r?.entity && !r?.error && r?.score);
  // Detect read_content result → offer preview + edit
  const readResult = toolResults.find((r: any) => r?.found === true && r?.type === 'combo');

  const resultForActions = readResult || generateResult;

  return (
    <div className="flex justify-start">
      <div className="max-w-[85%] rounded-2xl rounded-bl-sm px-3.5 py-2.5 bg-white/[0.03] border border-white/[0.05]">
        {thinking ? (
          <div className="flex items-center gap-2 py-0.5">
            <div className="flex gap-1">
              <span className="w-1 h-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1 h-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '120ms' }} />
              <span className="w-1 h-1 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '240ms' }} />
            </div>
            <span className="text-[11px] text-white/25">
              {hasTools ? `🔧 ${tools[tools.length - 1]}…` : 'Pensando…'}
            </span>
          </div>
        ) : (
          <>
            <div className="msg-md text-sm leading-relaxed text-white/90">
              <MarkdownRenderer content={text} />
            </div>
            {/* Quick actions after content generation */}
            {resultForActions && !thinking && (
              <div className="mt-2 flex gap-1.5 flex-wrap">
                {readResult && (
                  <>
                    <button onClick={() => onOpenPreview('combo', `${readResult.service}-${readResult.location}`)}
                      className="text-[10px] px-2 py-1 bg-blue-500/15 hover:bg-blue-500/25 text-blue-400/80 rounded transition-colors">
                      👁️ Preview
                    </button>
                    <button onClick={() => onEditField(readResult.service, readResult.location, 'h1', readResult.h1 || '')}
                      className="text-[10px] px-2 py-1 bg-white/5 hover:bg-white/10 text-white/50 rounded transition-colors">
                      ✏️ H1
                    </button>
                    <button onClick={() => onEditField(readResult.service, readResult.location, 'intro_paragraph', readResult.intro_paragraph || '')}
                      className="text-[10px] px-2 py-1 bg-white/5 hover:bg-white/10 text-white/50 rounded transition-colors">
                      ✏️ Intro
                    </button>
                    <button onClick={() => onEditField(readResult.service, readResult.location, 'seo_title', readResult.seo_title || '')}
                      className="text-[10px] px-2 py-1 bg-white/5 hover:bg-white/10 text-white/50 rounded transition-colors">
                      ✏️ SEO Title
                    </button>
                  </>
                )}
                {!readResult && generateResult && (
                  <button onClick={() => onOpenPreview('combo', String(generateResult.entity || ''))}
                    className="text-[10px] px-2 py-1 bg-blue-500/15 hover:bg-blue-500/25 text-blue-400/80 rounded transition-colors">
                    {'\u{1F441}\uFE0F'} Preview
                  </button>
                )}
              </div>
            )}
          </>
        )}
        {hasTools && !thinking && (
          <div className="mt-1.5 flex gap-1 flex-wrap">
            {tools.map(t => (
              <span key={t} className="text-[10px] bg-blue-500/10 text-blue-400/80 px-1.5 py-0.5 rounded-md">🔧 {t}</span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Welcome ──────────────────────────── */

function Welcome({ onSend }: { onSend: (s: string) => void }) {
  const items = [
    { icon: '📊', text: 'Status del sistema' },
    { icon: '🚀', text: 'Generar contenido para guardias en Las Condes' },
    { icon: '📈', text: 'Qué servicios no tienen contenido?' },
    { icon: '📋', text: 'Ver cola de publicación' },
  ];
  return (
    <div className="flex flex-col items-center justify-center h-full px-6">
      <span className="text-3xl mb-3">🛡️</span>
      <p className="text-sm text-white/30 mb-1">GuardMan Orchestrator</p>
      <p className="text-[11px] text-white/15 mb-8">Escribe o elige una acción</p>
      <div className="w-full max-w-xs space-y-2">
        {items.map((s, i) => (
          <button
            key={i}
            onClick={() => onSend(s.text)}
            className="w-full text-left text-[13px] text-white/50 hover:text-white/80
              px-3.5 py-2.5 rounded-lg bg-white/[0.02] hover:bg-white/[0.05]
              border border-white/[0.03] hover:border-white/[0.08] transition-colors"
          >
            <span className="mr-2">{s.icon}</span>{s.text}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Icon components ──────────────────────────── */

function EyeIcon() {
  return <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>;
}

function EditIcon() {
  return <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>;
}

function ClipboardIcon() {
  return <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>;
}

function ChartIcon() {
  return <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
}

function TrashIcon() {
  return <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>;
}

/* ── Helpers ──────────────────────────── */

function extractText(m: UIMessage): string {
  if (!m.parts) return (m as any).content || '';
  return m.parts.filter((p: any) => p.type === 'text').map((p: any) => p.text).join('');
}

function extractTools(m: UIMessage): string[] {
  if (!m.parts) return [];
  return m.parts
    .filter((p: any) => {
      if (p.type === 'dynamic-tool') return true;
      if (typeof p.type === 'string' && p.type.startsWith('tool-') && p.type !== 'tool-call' && p.type !== 'tool-result') return true;
      return false;
    })
    .map((p: any) => p.toolName || p.type?.replace(/^tool-/, '') || '')
    .filter(Boolean);
}

function extractToolResults(m: UIMessage): any[] {
  if (!m.parts) return [];
  return m.parts
    .filter((p: any) => {
      // Dynamic tool parts (Think SDK)
      if (p.type === 'dynamic-tool' && p.state === 'output-available') return true;
      // Named tool parts (AI SDK v4+)
      if (typeof p.type === 'string' && p.type.startsWith('tool-') && p.type !== 'tool-call' && p.type !== 'tool-result' && p.state === 'output-available') return true;
      return false;
    })
    .map((p: any) => p.output)
    .filter(Boolean);
}

/* ── Inline Markdown ──────────────────── */

function MarkdownRenderer({ content }: { content: string }) {
  if (!content) return null;
  const lines = content.split('\n');
  const html: string[] = [];
  let inTable = false, inCode = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.startsWith('```')) {
      if (inCode) { html.push('</code></pre>'); inCode = false; } else { html.push('<pre><code>'); inCode = true; }
      continue;
    }
    if (inCode) { html.push(esc(line)); continue; }

    if (line.includes('|') && line.trim().startsWith('|')) {
      if (!inTable) { html.push('<table><tbody>'); inTable = true; }
      if (/^\|[\s\-:|]+\|$/.test(line)) continue;
      const cells = line.split('|').filter(c => c.trim()).map(c => c.trim());
      const tag = (i === 0 || /^\|[\s\-:|]+\|$/.test(lines[i - 1] || '')) ? 'th' : 'td';
      html.push(`<tr>${cells.map(c => `<${tag}>${imd(c)}</${tag}>`).join('')}</tr>`);
      continue;
    } else if (inTable) { html.push('</tbody></table>'); inTable = false; }

    if (line.startsWith('### ')) { html.push(`<h3>${imd(line.slice(4))}</h3>`); continue; }
    if (line.startsWith('## '))  { html.push(`<h2>${imd(line.slice(3))}</h2>`); continue; }
    if (line.startsWith('# '))   { html.push(`<h1>${imd(line.slice(2))}</h1>`); continue; }
    if (/^---+$/.test(line))     { html.push('<hr/>'); continue; }
    if (/^\d+\.\s/.test(line))   { html.push(`<div class="ol-item"><span>${line.match(/^\d+/)?.[0]}.</span><span>${imd(line.replace(/^\d+\.\s/, ''))}</span></div>`); continue; }
    if (line.startsWith('- '))    { html.push(`<div class="ul-item"><span>•</span><span>${imd(line.slice(2))}</span></div>`); continue; }
    if (!line.trim())             { html.push('<br/>'); continue; }
    html.push(`<p>${imd(line)}</p>`);
  }
  if (inTable) html.push('</tbody></table>');
  if (inCode) html.push('</code></pre>');
  return <div dangerouslySetInnerHTML={{ __html: html.join('\n') }} />;
}

function esc(s: string) { return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function imd(s: string) {
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank">$1</a>');
}
