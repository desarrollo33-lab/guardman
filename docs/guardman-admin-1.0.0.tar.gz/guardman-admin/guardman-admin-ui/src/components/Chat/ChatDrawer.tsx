// GuardMan v11.3 — Chat Drawer (WebSocket native + Agentic UI v2.0 + Monaco Editor)
// FASE 1-3: useAgent + useAgentChat + PreviewPanel + CodeEditor + Approval + Persistence
import { useState, useRef, useEffect, useCallback } from 'react';
import { useAgent } from 'agents/react';
import { useAgentChat } from '@cloudflare/ai-chat/react';
import { getToken } from '../../hooks/useApi';
import type { UIMessage } from 'ai';
import { PreviewFrame } from '../Preview/PreviewFrame';
import { ChartPanel } from '../Chart/ChartPanel';
import { MonacoEditor } from '../Editor/MonacoEditor';

interface ChatDrawerProps {
  open: boolean;
  onClose: () => void;
  fullPage?: boolean;
}

interface ChartData {
  chart_type: string;
  title: string;
  labels: string[];
  datasets: any[];
}

const API_HOST = 'guardman.oficinadesarrollo33.workers.dev';
const STORAGE_KEY = 'gm_chat_history';

interface PendingEdit {
  serviceSlug: string;
  locationSlug: string;
  field: string;
  currentValue: string;
  displayValue: string;
}

interface ApprovalItem {
  id: number;
  entity_type: string;
  entity_slug: string;
  title: string;
  score: number;
  status: string;
}

interface PendingApproval {
  id: string;
  action_type: string;
  description: string;
  item_count: number;
  params: any;
  options: { id: string; label: string; action: string; params: any }[];
}

export function ChatDrawer({ open, onClose, fullPage }: ChatDrawerProps) {
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');
  const [showPreview, setShowPreview] = useState(false);
  const [previewEntity, setPreviewEntity] = useState({ type: '', slug: '' });
  const [showEditor, setShowEditor] = useState(false);
  const [pendingEdit, setPendingEdit] = useState<PendingEdit | null>(null);
  const [showApproval, setShowApproval] = useState(false);
  const [approvalItems, setApprovalItems] = useState<ApprovalItem[]>([]);
  const [showChart, setShowChart] = useState(false);
  const [chartData, setChartData] = useState<ChartData | null>(null);
  const [chartType, setChartType] = useState<'coverage' | 'scores' | 'gaps'>('coverage');
  const [pendingApprovals, setPendingApprovals] = useState<PendingApproval[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isReady, setIsReady] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);

  // ── Persistence: Load saved messages ──────────────────────
  const [messages, setMessages] = useState<UIMessage[]>([]);

  useEffect(() => {
    if (!open) return;
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setMessages(parsed);
        }
      }
    } catch (e) {
      console.warn('[ChatDrawer] Failed to load history:', e);
    }
  }, [open]);

  // ── Persistence: Save messages ───────────────────────────
  const saveMessages = useCallback((msgs: UIMessage[]) => {
    try {
      const toSave = msgs.slice(-50);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
    } catch (e) {
      console.warn('[ChatDrawer] Failed to save history:', e);
    }
  }, []);

  // ── Auth query for WebSocket ───────────────────────────────
  const getAuthQuery = useCallback(async () => {
    const token = getToken() || '';
    return { token } as Record<string, string>;
  }, []);

  // ── Connect to GMOrchestrator DO via WebSocket ────────────
  const agent = useAgent({
    agent: 'ORCHESTRATOR',
    name: 'default',
    host: API_HOST,
    protocol: 'wss',
    query: getAuthQuery,
    onIdentity: (name, agentClass) => {
      console.log('[ChatDrawer] Connected:', agentClass, name);
      setConnectionStatus('connected');
      setIsReady(true);
    },
    onStateUpdate: (state) => {
      console.log('[ChatDrawer] State update:', state);
    },
    onStateUpdateError: (error) => {
      console.error('[ChatDrawer] State update error:', error);
      setConnectionStatus('disconnected');
    },
  });

  // Wait for agent to be ready
  useEffect(() => {
    if (!open) return;
    agent.ready
      .then(() => {
        console.log('[ChatDrawer] Agent ready');
        setConnectionStatus('connected');
        setIsReady(true);
      })
      .catch((err) => {
        console.error('[ChatDrawer] Agent ready error:', err);
        setConnectionStatus('disconnected');
      });
  }, [open, agent.ready]);

  const { sendMessage, clearHistory, status, messages: agentMessages } = useAgentChat({
    agent,
    onToolCall: async ({ toolCall, addToolOutput }) => {
      // Handle tool results here if needed
      console.log('[ChatDrawer] Tool call:', toolCall.toolName);
    },
  });

  const isStreaming = status === 'streaming';

  // ── Sync messages from useAgentChat ──────────────────────
  useEffect(() => {
    if (agentMessages && Array.isArray(agentMessages)) {
      setMessages(agentMessages as UIMessage[]);
      saveMessages(agentMessages as UIMessage[]);
    }
  }, [agentMessages, saveMessages]);

  // ── Auto-scroll to bottom ─────────────────────────────────
  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ── Detect tool outputs: read_content, publish_preview, open_panel, etc ──
  useEffect(() => {
    if (messages.length === 0) return;
    const lastMsg = messages[messages.length - 1];
    if (lastMsg.role !== 'assistant') return;

    const parts = lastMsg.parts || [];
    for (const part of parts as any[]) {
      if (part.type === 'tool-result') {
        const result = part.result;
        if (!result) continue;

        // Detect open_panel → agent-driven panel opening
        if (result.panel_action && result.panel_type) {
          const { panel_action, panel_type, params } = result;
          
          if (panel_action === 'open' || panel_action === 'toggle') {
            switch (panel_type) {
              case 'preview':
                if (params?.service_slug) {
                  setPreviewEntity({ 
                    type: 'combo', 
                    slug: params.location_slug 
                      ? `${params.service_slug}/${params.location_slug}`
                      : params.service_slug
                  });
                  setShowPreview(true);
                }
                break;
              case 'approval':
                setShowApproval(true);
                break;
              case 'editor':
                if (params?.service_slug && params?.field) {
                  // Get current value from tool result content or use placeholder
                  setPendingEdit({
                    serviceSlug: params.service_slug,
                    locationSlug: params.location_slug || '',
                    field: params.field,
                    currentValue: params.content || '',
                    displayValue: params.content || '',
                  });
                  setShowEditor(true);
                } else if (params?.service_slug) {
                  // Open editor without specific field, show h1 by default
                  setPendingEdit({
                    serviceSlug: params.service_slug,
                    locationSlug: params.location_slug || '',
                    field: 'h1',
                    currentValue: params.content || '',
                    displayValue: params.content || '',
                  });
                  setShowEditor(true);
                }
                break;
              case 'coverage':
                // Coverage panel - could integrate with chart or show matrix
                console.log('[ChatDrawer] Coverage panel requested', params);
                break;
              case 'chart':
                // Open chart panel with optional pre-loaded data
                if (result.chart_data) {
                  setChartData(result.chart_data);
                  setChartType((params?.chart_type as any) || 'coverage');
                }
                setShowChart(true);
                break;
              case 'status':
                // Status dashboard - could show stats panel
                console.log('[ChatDrawer] Status panel requested', params);
                break;
            }
          } else if (panel_action === 'close') {
            switch (panel_type) {
              case 'preview':
                setShowPreview(false);
                break;
              case 'approval':
                setShowApproval(false);
                break;
              case 'editor':
                setShowEditor(false);
                break;
              case 'chart':
                setShowChart(false);
                break;
            }
          }
          continue;
        }

        // Detect read_content → open preview (legacy support)
        if (result.found === true && result.type === 'combo') {
          setPreviewEntity({ type: 'combo', slug: `${result.service}/${result.location}` });
          setShowPreview(true);
          continue;
        }

        // Detect publish_preview → show approval panel (legacy support)
        if (result.items && Array.isArray(result.items)) {
          setApprovalItems(result.items);
          setShowApproval(true);
          continue;
        }
        
        // Detect request_approval → show pending approval
        if (result.pending_approval === true) {
          const approval: PendingApproval = {
            id: result.approval_options?.[0]?.id || `approval_${Date.now()}`,
            action_type: result.action_type,
            description: result.description,
            item_count: result.item_count || 1,
            params: result.params || {},
            options: result.approval_options || [],
          };
          setPendingApprovals(prev => [...prev, approval]);
          setShowApproval(true);
          continue;
        }
      }
    }
  }, [messages]);

  // ── Handlers ──────────────────────────────────────────────
  const handleClear = useCallback(async () => {
    clearHistory();
    setMessages([]);
    localStorage.removeItem(STORAGE_KEY);
  }, [clearHistory]);

  const handleSend = useCallback((text: string) => {
    if (!text.trim() || isStreaming) return;
    sendMessage({
      role: 'user',
      parts: [{ type: 'text', text }],
    });
    setInputValue('');
  }, [isStreaming, sendMessage]);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    handleSend(inputValue);
  }, [inputValue, handleSend]);

  const handleQuickSend = useCallback((text: string) => {
    handleSend(text);
  }, [handleSend]);

  // ── Edit flow: user says "cambia X" ──────────────────────
  const handleFieldEdit = useCallback((serviceSlug: string, locationSlug: string, field: string, currentValue: string) => {
    setPendingEdit({ serviceSlug, locationSlug, field, currentValue, displayValue: currentValue });
    setShowEditor(true);
  }, []);

  const handleEditorSave = useCallback((newValue: string) => {
    if (!pendingEdit) return;
    // Build the instruction for the agent via tool call
    const instruction = `update_content("${pendingEdit.serviceSlug}", "${pendingEdit.locationSlug}", "${pendingEdit.field}", "${newValue.replace(/"/g, '\\"')}")`;
    handleQuickSend(instruction);
    setShowEditor(false);
    setPendingEdit(null);
  }, [pendingEdit, handleQuickSend]);

  // ── Approval: approve items ────────────────────────────────
  const handleApproveItem = useCallback((item: ApprovalItem) => {
    handleQuickSend(`publish "${item.entity_slug}"`);
    setApprovalItems(prev => prev.filter(i => i.id !== item.id));
  }, [handleQuickSend]);

  // ── Approval: handle pending approvals ─────────────────────
  const handlePendingApproval = useCallback((approval: PendingApproval, option: any) => {
    if (option.action === 'cancel') {
      // User rejected
      handleQuickSend(`Rechazado: ${approval.description}`);
    } else {
      // User approved - execute the action
      const { action, params } = option;
      switch (action) {
        case 'bulk_generate':
          handleQuickSend(`bulk_generate(${JSON.stringify(params || {})})`);
          break;
        case 'publish':
          handleQuickSend('publish');
          break;
        case 'bulk_publish':
          handleQuickSend(`bulk_generate(${JSON.stringify({ ...params, publish: true })})`);
          break;
        default:
          handleQuickSend(action);
      }
    }
    setPendingApprovals(prev => prev.filter(a => a.id !== approval.id));
  }, [handleQuickSend]);

  if (!open) return null;

  const isFullPage = fullPage;
  
  return (
    <>
      {/* Overlay (only in drawer mode) */}
      {!isFullPage && <div className="fixed inset-0 bg-black/40 z-40" onClick={onClose} />}
      
      {/* Full-page header with navigation */}
      {isFullPage && (
        <div className="flex items-center justify-between px-6 py-3 border-b border-white/5 bg-[#0a0e1a]">
          <div className="flex items-center gap-4">
            <button 
              onClick={onClose}
              className="text-sm text-white/50 hover:text-white transition-colors flex items-center gap-1"
            >
              ← Dashboard
            </button>
            <div className="w-px h-4 bg-white/10" />
            <span className="text-lg">🛡️</span>
            <h2 className="text-white font-semibold">GuardMan Orchestrator</h2>
            <ConnectionBadge status={connectionStatus} />
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs text-white/20">⌘0 para volver al chat</span>
            <button
              onClick={() => setShowApproval(true)}
              className="text-xs text-white/50 hover:text-yellow-400 px-3 py-1.5 rounded transition-colors bg-white/5 hover:bg-white/10"
              title="Ver cola de publicación"
            >
              📋 Publicación
            </button>
            <button onClick={handleClear} className="text-xs text-white/50 hover:text-red-400 px-3 py-1.5 rounded transition-colors bg-white/5 hover:bg-white/10">
              Limpiar
            </button>
          </div>
        </div>
      )}
      
      {/* Main container */}
      <div className={isFullPage 
        ? "flex flex-col h-[calc(100vh-52px)]" 
        : "fixed right-0 top-0 h-full w-[440px] max-w-full bg-[#0c1222] border-l border-white/5 z-50 flex flex-col shadow-2xl"
      }>
        {/* Header (only in drawer mode) */}
        {!isFullPage && (
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
            <div className="flex items-center gap-2">
              <span className="text-lg">🛡️</span>
              <h3 className="text-white font-semibold text-sm">Orchestrator</h3>
              <ConnectionBadge status={connectionStatus} />
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowApproval(true)}
                className="text-xs text-white/30 hover:text-yellow-400 px-2 py-1 rounded transition-colors"
                title="Ver cola de publicación"
              >
                📋
              </button>
              <button onClick={handleClear} className="text-xs text-white/30 hover:text-red-400 px-2 py-1 rounded transition-colors">
                Limpiar
              </button>
              {isStreaming && (
                <button onClick={() => {/* stop not available */}} className="text-xs text-orange-400 hover:text-orange-300 px-2 py-1 rounded transition-colors">
                  ⏹
                </button>
              )}
              <button onClick={onClose} className="text-white/40 hover:text-white text-lg leading-none">&times;</button>
            </div>
          </div>
        )}
        
        {/* Side Panel: Preview / Editor / Approval */}
        {showPreview && (
          <div className="border-b border-white/5 h-64 flex-shrink-0">
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#131D33] border-b border-white/5">
              <span className="text-xs text-white/50">👁️ Preview</span>
              <button
                onClick={() => setShowPreview(false)}
                className="text-white/30 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>
            <PreviewFrame entityType={previewEntity.type} entitySlug={previewEntity.slug} />
          </div>
        )}
        
        {/* Editor Panel */}
        {showEditor && pendingEdit && (
          <div className="border-b border-white/5 flex-shrink-0">
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#131D33] border-b border-white/5">
              <span className="text-xs text-white/50">✏️ Editar: {pendingEdit.field}</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-white/20">⌘S para guardar</span>
                <button
                  onClick={() => { setShowEditor(false); setPendingEdit(null); }}
                  className="text-white/30 hover:text-white text-xs"
                >
                  ✕
                </button>
              </div>
            </div>
            <div className="p-3">
              <p className="text-xs text-white/30 mb-2">
                Combo: {pendingEdit.serviceSlug} + {pendingEdit.locationSlug}
              </p>
              <MonacoEditor
                value={pendingEdit.displayValue}
                onChange={(value) => setPendingEdit(prev => prev ? { ...prev, displayValue: value } : null)}
                language="markdown"
                minHeight={100}
                maxHeight={180}
                placeholder={`Edita el ${pendingEdit.field}...`}
                onSave={(value) => {
                  if (pendingEdit) {
                    handleEditorSave(value);
                  }
                }}
              />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => pendingEdit && handleEditorSave(pendingEdit.displayValue)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 rounded-lg text-xs text-white transition-colors"
                >
                  Guardar
                </button>
                <button
                  onClick={() => { setShowEditor(false); setPendingEdit(null); }}
                  className="px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-xs text-white/50 transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Approval Panel */}
        {showApproval && (
          <div className="border-b border-white/5 flex-shrink-0 max-h-80 overflow-y-auto">
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#131D33] border-b border-white/5 sticky top-0">
              <span className="text-xs text-yellow-400">📋 Pendiente ({approvalItems.length + pendingApprovals.length})</span>
              <button
                onClick={() => setShowApproval(false)}
                className="text-white/30 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>
            
            {/* Pending Approvals (from request_approval tool) */}
            {pendingApprovals.length > 0 && (
              <div className="p-2 space-y-2 border-b border-white/5">
                <p className="text-[10px] text-orange-400 uppercase tracking-wide px-2">Aprobaciones Pendientes</p>
                {pendingApprovals.map((approval) => (
                  <div key={approval.id} className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3">
                    <div className="flex items-start gap-2">
                      <div className="flex-1">
                        <p className="text-xs text-orange-300 font-medium">{approval.description}</p>
                        <p className="text-[10px] text-white/40 mt-0.5">
                          {approval.item_count} item(s) • {approval.action_type}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-2">
                      {approval.options.map((option) => (
                        <button
                          key={option.id}
                          onClick={() => handlePendingApproval(approval, option)}
                          className={`px-3 py-1 rounded text-xs transition-colors ${
                            option.action === 'cancel'
                              ? 'bg-white/5 hover:bg-white/10 text-white/50'
                              : 'bg-green-600/30 hover:bg-green-600/50 text-green-400'
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Publish Queue Items */}
            {approvalItems.length === 0 && pendingApprovals.length === 0 ? (
              <div className="p-4 text-center text-xs text-white/30">
                No hay items pendientes
              </div>
            ) : (
              <div className="p-2 space-y-2">
                {approvalItems.map((item) => (
                  <div key={item.id} className="bg-white/[0.03] rounded-lg p-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-white/80 font-medium truncate">{item.title || item.entity_slug}</p>
                        <p className="text-[10px] text-white/30">{item.entity_slug}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                            item.score >= 85 ? 'bg-green-500/20 text-green-400' :
                            item.score >= 75 ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                          }`}>
                            Score: {item.score}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleApproveItem(item)}
                        className="px-2 py-1 bg-green-600/30 hover:bg-green-600/50 rounded text-[10px] text-green-400 transition-colors"
                      >
                        Publicar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Chart Panel */}
        {showChart && (
          <div className="border-b border-white/5 flex-shrink-0 max-h-72 overflow-hidden">
            <div className="flex items-center justify-between px-3 py-1.5 bg-[#131D33] border-b border-white/5">
              <span className="text-xs text-purple-400">📊 Gráfico</span>
              <button
                onClick={() => setShowChart(false)}
                className="text-white/30 hover:text-white text-xs"
              >
                ✕
              </button>
            </div>
            <div className="h-56 overflow-y-auto">
              <ChartPanel 
                initialChart={chartType} 
                onClose={() => setShowChart(false)} 
              />
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.length === 0 && <Welcome onSend={handleQuickSend} />}

          {messages.map((msg: UIMessage, idx: number) => {
            if (msg.role === 'user') {
              return <UserMessage key={msg.id || idx} message={msg} />;
            }
            if (msg.role === 'assistant') {
              return (
                <AssistantMessage
                  key={msg.id || idx}
                  message={msg}
                  isLatest={idx === messages.length - 1}
                  onOpenPreview={(type, slug) => {
                    setPreviewEntity({ type, slug });
                    setShowPreview(true);
                  }}
                  onEditField={(svc, loc, field, value) => {
                    handleFieldEdit(svc, loc, field, value);
                  }}
                />
              );
            }
            return null;
          })}
          <div ref={bottom} />
        </div>

        {/* Input */}
        <div className="border-t border-white/5 p-3">
          <form onSubmit={handleSubmit} className="flex gap-2 items-end">
            <textarea
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
              placeholder={isReady ? "Escribe un mensaje..." : "Conectando..."}
              className="flex-1 bg-white/[0.03] border border-white/[0.06] rounded-xl px-3 py-2.5 text-sm text-white placeholder-white/20 focus:outline-none focus:border-blue-500/30 resize-none min-h-[42px] max-h-[100px]"
              rows={1}
              disabled={isStreaming || !isReady}
            />
            <button
              type="submit"
              disabled={isStreaming || !inputValue.trim() || !isReady}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-25 w-10 h-10 rounded-xl text-white flex items-center justify-center shrink-0 transition-colors"
            >
              {isStreaming ? (
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
                </svg>
              )}
            </button>
          </form>
        </div>
      </div>
    </>
  );
}

// ── Sub-components ──────────────────────────────────────

function ConnectionBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    connected: 'bg-green-400',
    connecting: 'bg-yellow-400 animate-pulse',
    disconnected: 'bg-red-400',
  };
  return (
    <div className="flex items-center gap-1.5 ml-1">
      <div className={`w-1.5 h-1.5 rounded-full ${colors[status] || 'bg-gray-400'}`} />
      <span className="text-[10px] text-white/30">{status === 'connected' ? 'WS' : status}</span>
    </div>
  );
}

function UserMessage({ message }: { message: UIMessage }) {
  const text = extractText(message);
  return (
    <div className="flex justify-end">
      <div className="max-w-[88%] rounded-2xl rounded-br-md px-3.5 py-2.5 bg-blue-600 text-white">
        <p className="text-sm whitespace-pre-wrap">{text}</p>
      </div>
    </div>
  );
}

interface AssistantMessageProps {
  message: UIMessage;
  isLatest: boolean;
  onOpenPreview: (type: string, slug: string) => void;
  onEditField: (serviceSlug: string, locationSlug: string, field: string, value: string) => void;
}

function AssistantMessage({ message, isLatest, onOpenPreview, onEditField }: AssistantMessageProps) {
  const text = extractText(message);
  const tools = extractTools(message);
  const toolResults = extractToolResults(message);
  const hasToolCalls = tools.length > 0;
  const isThinking = !text && isLatest;

  // Check for read_content result
  const readContentResult = toolResults.find((r: any) => r?.found === true && r?.type === 'combo');

  // Check for generate result (to offer preview)
  const generateResult = toolResults.find((r: any) => r?.entity && !r?.error && (r?.score || r?.word_count));

  return (
    <div className="flex justify-start">
      <div className="max-w-[88%] rounded-2xl rounded-bl-md px-3.5 py-2.5 bg-white/[0.04] text-white/90 border border-white/[0.06]">
        {isThinking ? (
          <div className="flex items-center gap-2 py-1">
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
            <span className="text-xs text-white/30">
              {hasToolCalls ? `🔧 ${tools[tools.length - 1]}...` : 'Pensando...'}
            </span>
          </div>
        ) : (
          <>
            <div className="text-sm leading-relaxed prose prose-invert prose-sm max-w-none">
              <MarkdownRenderer content={text} />
            </div>

            {/* Quick actions after generate */}
            {generateResult && !readContentResult && (
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => {
                    const entity = generateResult.entity as string;
                    const [svc, loc] = entity.includes('/') ? entity.split('/') : [entity, ''];
                    if (loc) {
                      onOpenPreview('combo', `${svc}/${loc}`);
                    }
                  }}
                  className="text-xs px-2 py-1 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 rounded transition-colors"
                >
                  👁️ Ver Preview
                </button>
                {generateResult.entity && String(generateResult.entity).includes('/') && (
                  <button
                    onClick={() => {
                      const entity = String(generateResult.entity);
                      const [svc, loc] = entity.split('/');
                      onEditField(svc, loc, 'h1', generateResult.details?.h1 || '');
                    }}
                    className="text-xs px-2 py-1 bg-white/5 hover:bg-white/10 text-white/50 rounded transition-colors"
                  >
                    ✏️ Editar
                  </button>
                )}
              </div>
            )}

            {/* Read content quick actions */}
            {readContentResult && (
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => {
                    onOpenPreview('combo', `${readContentResult.service}/${readContentResult.location}`);
                  }}
                  className="text-xs px-2 py-1 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 rounded transition-colors"
                >
                  👁️ Ver Preview
                </button>
                <button
                  onClick={() => {
                    onEditField(
                      readContentResult.service,
                      readContentResult.location,
                      'h1',
                      readContentResult.h1 || ''
                    );
                  }}
                  className="text-xs px-2 py-1 bg-white/5 hover:bg-white/10 text-white/50 rounded transition-colors"
                >
                  ✏️ Editar H1
                </button>
                <button
                  onClick={() => {
                    onEditField(
                      readContentResult.service,
                      readContentResult.location,
                      'intro_paragraph',
                      readContentResult.intro_paragraph || ''
                    );
                  }}
                  className="text-xs px-2 py-1 bg-white/5 hover:bg-white/10 text-white/50 rounded transition-colors"
                >
                  ✏️ Editar Intro
                </button>
              </div>
            )}
          </>
        )}
        {hasToolCalls && !isThinking && (
          <div className="mt-1.5 flex gap-1 flex-wrap">
            {tools.map(t => (
              <span key={t} className="text-[10px] bg-blue-500/15 text-blue-400 px-1.5 py-0.5 rounded-full">
                🔧 {t}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Helpers ──────────────────────────────────────

function extractText(message: UIMessage): string {
  if (!message.parts) {
    return (message as any).content || '';
  }
  return message.parts
    .filter((p: any) => p.type === 'text')
    .map((p: any) => p.text)
    .join('');
}

function extractTools(message: UIMessage): string[] {
  if (!message.parts) return [];
  return message.parts
    .filter((p: any) => p.type === 'tool-invocation' || p.type === 'tool-call')
    .map((p: any) => p.toolName || p.toolCall?.toolName || '')
    .filter(Boolean);
}

function extractToolResults(message: UIMessage): any[] {
  if (!message.parts) return [];
  return message.parts
    .filter((p: any) => p.type === 'tool-result')
    .map((p: any) => p.result)
    .filter(Boolean);
}

/**
 * Simple markdown renderer for agent messages.
 */
function MarkdownRenderer({ content }: { content: string }) {
  if (!content) return null;

  const lines = content.split('\n');
  const html: string[] = [];
  let inTable = false;
  let inCodeBlock = false;

  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];

    if (line.startsWith('```')) {
      if (inCodeBlock) { html.push('</code></pre>'); inCodeBlock = false; }
      else { html.push('<pre class="bg-black/30 rounded-lg p-3 my-2 overflow-x-auto text-xs"><code>'); inCodeBlock = true; }
      continue;
    }
    if (inCodeBlock) { html.push(escapeHtml(line)); continue; }

    if (line.includes('|') && line.trim().startsWith('|')) {
      if (!inTable) { html.push('<table class="w-full text-xs my-2 border-collapse"><tbody>'); inTable = true; }
      if (line.match(/^\|[\s\-:|]+\|$/)) continue;
      const cells = line.split('|').filter(c => c.trim()).map(c => c.trim());
      const tag = i === 0 || (lines[i-1]?.match(/^\|[\s\-:|]+\|$/)) ? 'th' : 'td';
      const cls = tag === 'th' ? 'text-left font-medium text-white/50 py-0.5 px-1.5 border-b border-white/10' : 'py-0.5 px-1.5 border-b border-white/5';
      html.push(`<tr>${cells.map(c => `<${tag} class="${cls}">${inlineMd(c)}</${tag}>`).join('')}</tr>`);
      continue;
    } else if (inTable) { html.push('</tbody></table>'); inTable = false; }

    if (line.startsWith('### ')) { html.push(`<h3 class="text-xs font-bold mt-2 mb-0.5 text-white/90">${inlineMd(line.slice(4))}</h3>`); continue; }
    if (line.startsWith('## ')) { html.push(`<h2 class="text-sm font-bold mt-2 mb-0.5 text-white/90">${inlineMd(line.slice(3))}</h2>`); continue; }
    if (line.startsWith('# ')) { html.push(`<h1 class="text-sm font-bold mt-2 mb-0.5 text-white/90">${inlineMd(line.slice(2))}</h1>`); continue; }
    if (line.match(/^---+$/)) { html.push('<hr class="border-white/10 my-2"/>'); continue; }
    if (line.match(/^\d+\.\s/)) { html.push(`<div class="flex gap-1.5 ml-1.5"><span class="text-white/30 shrink-0 text-xs">${line.match(/^\d+/)?.[0]}.</span><span>${inlineMd(line.replace(/^\d+\.\s/, ''))}</span></div>`); continue; }
    if (line.startsWith('- ')) { html.push(`<div class="flex gap-1.5 ml-1.5"><span class="text-blue-400 shrink-0 text-xs">•</span><span>${inlineMd(line.slice(2))}</span></div>`); continue; }
    if (!line.trim()) { html.push('<div class="h-1.5"></div>'); continue; }
    html.push(`<p class="leading-relaxed">${inlineMd(line)}</p>`);
  }
  if (inTable) html.push('</tbody></table>');
  if (inCodeBlock) html.push('</code></pre>');
  return <div dangerouslySetInnerHTML={{ __html: html.join('\n') }} />;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function inlineMd(s: string): string {
  return escapeHtml(s)
    .replace(/\*\*(.+?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code class="bg-white/10 px-1 py-0.5 rounded text-blue-300 text-[10px]">$1</code>')
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" class="text-blue-400 underline" target="_blank">$1</a>');
}

function Welcome({ onSend }: { onSend: (s: string) => void }) {
  const items = [
    { icon: '📊', text: 'Dame el status del sistema' },
    { icon: '🔍', text: 'Detalle de guardias de seguridad' },
    { icon: '📈', text: 'Qué servicios no tienen contenido?' },
    { icon: '📋', text: 'Ver cola de publicación' },
  ];
  return (
    <div className="py-8 text-center">
      <p className="text-2xl mb-1">🤖</p>
      <p className="text-sm text-white/30 mb-6">¿Qué quieres hacer?</p>
      <div className="space-y-2">
        {items.map((s, i) => (
          <button
            key={i}
            onClick={() => onSend(s.text)}
            className="block w-full text-left text-sm text-white/60 bg-white/[0.03] hover:bg-white/[0.06] rounded-xl px-4 py-3 transition-colors"
          >
            <span className="mr-2">{s.icon}</span>{s.text}
          </button>
        ))}
      </div>
    </div>
  );
}
