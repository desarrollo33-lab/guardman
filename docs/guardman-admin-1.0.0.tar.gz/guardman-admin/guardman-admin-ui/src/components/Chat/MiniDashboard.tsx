// GuardMan v12 — Mini Dashboard (compact strip)
import { useState, useEffect, useCallback } from 'react';
import { getToken } from '../../hooks/useApi';

interface Metrics {
  services: number;
  locations: number;
  content: number;
  score: number;
}

export function MiniDashboard() {
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [collapsed, setCollapsed] = useState(false);

  const fetchMetrics = useCallback(async () => {
    try {
      const token = getToken();
      const r = await fetch('https://guardman.oficinadesarrollo33.workers.dev/api/orchestrator/status', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!r.ok) return;
      const d = await r.json();
      setMetrics({
        services: d.data?.services?.length || d.data?.total_services || 9,
        locations: d.data?.locations?.length || d.data?.total_locations || 14,
        content: d.data?.total_content || d.data?.content_count || 0,
        score: d.data?.avg_score || 0,
      });
    } catch {}
  }, []);

  useEffect(() => { fetchMetrics(); const t = setInterval(fetchMetrics, 60000); return () => clearInterval(t); }, [fetchMetrics]);

  if (collapsed) return (
    <button
      onClick={() => setCollapsed(false)}
      className="w-full h-8 flex items-center justify-center text-[10px] text-white/15 hover:text-white/30 hover:bg-white/[0.02] transition-colors border-b border-white/[0.03]"
    >
      ▼ metrics
    </button>
  );

  return (
    <div className="shrink-0 border-b border-white/[0.04]">
      <div className="flex items-center justify-between px-4 py-2">
        <div className="flex items-center gap-4 text-[11px]">
          <Metric pill="bg-blue-500/10 text-blue-400/70" value={metrics?.services ?? '–'} label="serv" />
          <Metric pill="bg-purple-500/10 text-purple-400/70" value={metrics?.locations ?? '–'} label="com" />
          <Metric pill="bg-emerald-500/10 text-emerald-400/70" value={metrics?.content ?? '–'} label="cont" />
          {metrics?.score ? <Metric pill="bg-amber-500/10 text-amber-400/70" value={`${metrics.score}%`} label="score" /> : null}
        </div>
        <button
          onClick={() => setCollapsed(true)}
          className="text-[10px] text-white/10 hover:text-white/30 transition-colors"
        >
          ▲
        </button>
      </div>
    </div>
  );
}

function Metric({ pill, value, label }: { pill: string; value: string | number; label: string }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md ${pill} font-medium`}>
      {value}
      <span className="opacity-50">{label}</span>
    </span>
  );
}
