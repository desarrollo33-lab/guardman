// GuardMan v12 — Mobile Quick Actions (bottom bar)
const ACTIONS = [
  { id: 'status', icon: '📊' },
  { id: 'generate', icon: '🚀' },
  { id: 'coverage', icon: '📈' },
  { id: 'publish', icon: '📋' },
  { id: 'search', icon: '🔍' },
];

const TEMPLATES: Record<string, string> = {
  status: 'Muestra el estado del sistema',
  generate: 'Generar contenido nuevo',
  coverage: 'Muestra el coverage',
  publish: 'Muestra la cola de publicación',
  search: 'Buscar en el conocimiento',
};

export function MobileQuickActions({ onAction }: { onAction: (msg: string) => void }) {
  return (
    <div className="md:hidden shrink-0 border-t border-white/[0.04] bg-[#0f1729]">
      <div className="flex justify-center gap-1 px-2 py-1.5">
        {ACTIONS.map(a => (
          <button
            key={a.id}
            onClick={() => onAction(TEMPLATES[a.id] || a.id)}
            className="flex items-center justify-center w-10 h-10 rounded-lg text-base
              text-white/30 hover:text-white/70 hover:bg-white/[0.05] transition-colors"
          >
            {a.icon}
          </button>
        ))}
      </div>
    </div>
  );
}
