// GuardMan v12 — Drawer Menu para Mobile
import { useEffect, useRef } from 'react';

interface DrawerMenuProps {
  open: boolean;
  onClose: () => void;
  onAction: (action: string) => void;
}

const MENU_ITEMS = [
  { id: 'status', icon: '📊', label: 'Status' },
  { id: 'generate', icon: '🚀', label: 'Generar' },
  { id: 'coverage', icon: '📈', label: 'Coverage' },
  { id: 'publish', icon: '📋', label: 'Publicar' },
  { id: 'search', icon: '🔍', label: 'Buscar' },
  { id: 'cms', icon: '📝', label: 'CMS Editor' },
  { id: 'media', icon: '🖼️', label: 'Medios' },
  { id: 'reports', icon: '📑', label: 'Reportes' },
];

export function DrawerMenu({ open, onClose, onAction }: DrawerMenuProps) {
  const drawerRef = useRef<HTMLDivElement>(null);

  // Close on escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (open) {
      document.addEventListener('keydown', handler);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.removeEventListener('keydown', handler);
      document.body.style.overflow = '';
    };
  }, [open, onClose]);

  // Close on backdrop click
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!open) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
      onClick={handleBackdropClick}
    >
      <div
        ref={drawerRef}
        className="absolute left-0 top-0 bottom-0 w-64 bg-[#131D33] border-r border-white/10 
          flex flex-col animate-in slide-in-from-left duration-300"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 h-14 border-b border-white/5">
          <div className="flex items-center gap-2">
            <span className="text-lg">🛡️</span>
            <span className="font-medium">GuardMan</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Menu Items */}
        <nav className="flex-1 py-4 px-3 space-y-1">
          {MENU_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => onAction(item.id)}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl 
                bg-white/5 hover:bg-white/10 border border-transparent hover:border-white/10
                text-white/70 hover:text-white transition-all"
            >
              <span className="text-lg">{item.icon}</span>
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-white/5">
          <button
            onClick={() => onAction('open_settings')}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl 
              bg-white/5 hover:bg-white/10 text-white/50 hover:text-white transition-all"
          >
            <span className="text-lg">⚙️</span>
            <span className="font-medium">Ajustes</span>
          </button>
        </div>
      </div>
    </div>
  );
}
