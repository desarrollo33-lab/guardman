// GuardMan v1.1 — Monaco Editor (FIXED: container height + position + theme)
// Rich text/code editor with syntax highlighting, autocomplete
// Uses @monaco-editor/react
// Lección #38: Monaco requiere contenedor con height explícita y position: relative
// Lección #39: Para edits cortos (H1, title), usar SimpleEditor en vez de Monaco
import { useRef, useCallback, useEffect, useState } from 'react';
import Editor, { OnMount } from '@monaco-editor/react';
import type { editor } from 'monaco-editor';

// ── Shared theme definition (defined once outside component) ────────────
const GM_DARK_THEME = {
  base: 'vs-dark' as const,
  inherit: true,
  rules: [
    { token: '', foreground: '94a3b8', background: '1e293b' },
    { token: 'comment', foreground: '64748b', fontStyle: 'italic' as const },
    { token: 'keyword', foreground: '60a5fa' },
    { token: 'string', foreground: '34d399' },
  ],
  colors: {
    'editor.background': '#1e293b',
    'editor.foreground': '#94a3b8',
    'editor.lineHighlightBackground': '#334155',
    'editor.selectionBackground': '#3b82f640',
    'editorCursor.foreground': '#60a5fa',
    'editorLineNumber.foreground': '#475569',
    'editorLineNumber.activeForeground': '#94a3b8',
  },
};

// Define theme globally so it's ready before any editor mounts
let themeRegistered = false;
function registerTheme(monaco: any) {
  if (themeRegistered) return;
  monaco.editor.defineTheme('gm-dark', GM_DARK_THEME);
  themeRegistered = true;
}

// ── Fields that are "short" (single line / few words) → SimpleEditor ────
const SHORT_FIELDS = new Set(['h1', 'seo_title', 'meta_description', 'cta_text', 'cta_button']);

export function isShortField(field: string): boolean {
  return SHORT_FIELDS.has(field);
}

// ── MonacoEditor (for long-form content) ────────────────────────────────

interface MonacoEditorProps {
  value: string;
  onChange: (value: string) => void;
  language?: string;
  readOnly?: boolean;
  height?: number;
  minHeight?: number;
  maxHeight?: number;
  placeholder?: string;
  onSave?: (value: string) => void;
}

export function MonacoEditor({
  value,
  onChange,
  language = 'markdown',
  readOnly = false,
  height: explicitHeight,
  minHeight = 200,
  maxHeight = 400,
  placeholder = 'Escribe aquí...',
  onSave,
}: MonacoEditorProps) {
  const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null);
  // FIX: Calcular height explícita. Monaco NECESITA un contenedor con altura definida.
  // minHeight como fallback si no se pasa height explícito.
  const containerHeight = explicitHeight ?? minHeight;

  const handleEditorDidMount: OnMount = useCallback((editor, monaco) => {
    editorRef.current = editor;

    // FIX: Registrar tema ANTES de setearlo
    registerTheme(monaco);
    monaco.editor.setTheme('gm-dark');

    // Configure editor
    editor.updateOptions({
      minimap: { enabled: false },
      lineNumbers: 'off',
      glyphMargin: false,
      folding: false,
      lineDecorationsWidth: 0,
      lineNumbersMinChars: 0,
      wordWrap: 'on',
      scrollBeyondLastLine: false,
      overviewRulerLanes: 0,
      hideCursorInOverviewRuler: true,
      overviewRulerBorder: false,
      scrollbar: {
        vertical: 'auto',
        horizontal: 'hidden',
        verticalScrollbarSize: 6,
      },
      padding: { top: 8, bottom: 8 },
    });

    // Save on Ctrl+S / Cmd+S
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
      if (onSave) onSave(editor.getValue());
    });

    // Save on Escape
    editor.addCommand(monaco.KeyCode.Escape, () => {
      if (onSave) onSave(editor.getValue());
      // Focus out of editor
      const dom = editor.getDomNode();
      if (dom) dom.blur();
    });
  }, [onSave]);

  const handleChange = useCallback((val: string | undefined) => {
    onChange(val || '');
  }, [onChange]);

  return (
    <div
      className="monaco-editor-wrapper rounded-lg overflow-hidden border border-white/10 relative"
      style={{ height: containerHeight, minHeight, maxHeight }}
    >
      {/* FIX: Placeholder posicionado relativo al wrapper (position: relative) */}
      {!value && (
        <div className="absolute top-2 left-3 text-white/20 text-sm pointer-events-none z-10">
          {placeholder}
        </div>
      )}
      <Editor
        height="100%"
        language={language}
        value={value}
        onChange={handleChange}
        onMount={handleEditorDidMount}
        theme="gm-dark"
        options={{
          readOnly,
          fontSize: 13,
          fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
          lineHeight: 1.5,
          automaticLayout: true,
          scrollBeyondLastLine: false,
          wordWrap: 'on',
          minimap: { enabled: false },
          renderLineHighlight: 'none',
          overviewRulerLanes: 0,
          hideCursorInOverviewRuler: true,
          scrollbar: {
            vertical: 'auto',
            horizontal: 'hidden',
          },
        }}
        loading={
          <div className="flex items-center justify-center h-full text-white/30 text-sm">
            Cargando editor...
          </div>
        }
      />
    </div>
  );
}

// ── SimpleEditor (for short fields: H1, SEO Title, CTA, etc.) ───────────
// Lección #39: Para edits cortos (H1, title), textarea estilizado > Monaco
// Monaco es overkill para campos de 1 línea, requiere configuración compleja.

interface SimpleEditorProps {
  value: string;
  onChange: (value: string) => void;
  field: string;
  placeholder?: string;
  onSave?: (value: string) => void;
}

export function SimpleEditor({
  value,
  onChange,
  field,
  placeholder,
  onSave,
}: SimpleEditorProps) {
  const ref = useRef<HTMLTextAreaElement>(null);
  const isMultiline = field === 'intro_paragraph' || field === 'local_context';
  const rows = isMultiline ? 6 : 2;

  // Focus on mount
  useEffect(() => {
    if (ref.current) {
      ref.current.focus();
      ref.current.setSelectionRange(value.length, value.length);
    }
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      onSave?.(value);
    }
    if (e.key === 'Escape') {
      onSave?.(value);
    }
    // Single-line fields: Enter triggers save
    if (e.key === 'Enter' && !e.shiftKey && !isMultiline) {
      e.preventDefault();
      onSave?.(value);
    }
  };

  const label = field.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

  return (
    <div className="flex flex-col gap-1.5">
      <label className="text-[11px] text-white/30 uppercase tracking-wider">{label}</label>
      <textarea
        ref={ref}
        value={value}
        onChange={e => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder || `Edita ${label}...`}
        rows={rows}
        className="w-full bg-[#1e293b] border border-white/10 rounded-lg px-3 py-2.5
          text-sm text-slate-300 placeholder-white/15
          focus:outline-none focus:border-blue-500/40 focus:ring-1 focus:ring-blue-500/20
          resize-y font-mono leading-relaxed
          transition-colors"
      />
      <span className="text-[10px] text-white/15">
        {isMultiline ? 'Ctrl+Enter para guardar · Esc para guardar y cerrar' : 'Enter para guardar · Esc para guardar y cerrar'}
      </span>
    </div>
  );
}
