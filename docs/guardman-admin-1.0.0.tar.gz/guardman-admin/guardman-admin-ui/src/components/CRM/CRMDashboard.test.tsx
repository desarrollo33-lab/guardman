import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { CRMDashboard } from './CRMDashboard';
import { MOCK_DASHBOARD_RESPONSE } from '../../../../tests/mocks/crm-mocks';

// Mock useApi
vi.mock('../../hooks/useApi', () => ({
  useApi: () => ({
    api: vi.fn(async () => MOCK_DASHBOARD_RESPONSE.data),
    loading: false,
    error: null,
  }),
}));

describe('CRMDashboard', () => {
  it('renders KPI cards', async () => {
    render(<CRMDashboard onNavigate={() => {}} onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('💼 CRM')).toBeInTheDocument();
    });
    // Should show pipeline value
    expect(screen.getByText('Pipeline $')).toBeInTheDocument();
    expect(screen.getByText('Ingresos Mensuales Contratados')).toBeInTheDocument();
  });

  it('renders sales funnel', async () => {
    render(<CRMDashboard onNavigate={() => {}} onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('Embudo de Ventas')).toBeInTheDocument();
    });
    expect(screen.getByText('🆕 Nuevo')).toBeInTheDocument();
    expect(screen.getByText('📞 Contactado')).toBeInTheDocument();
    expect(screen.getByText('🏢 Visita Técnica')).toBeInTheDocument();
    expect(screen.getByText('📋 Cotización')).toBeInTheDocument();
    expect(screen.getByText('🤝 Negociación')).toBeInTheDocument();
    expect(screen.getByText('✅ Ganado')).toBeInTheDocument();
    expect(screen.getByText('❌ Perdido')).toBeInTheDocument();
  });

  it('shows recent leads section', async () => {
    render(<CRMDashboard onNavigate={() => {}} onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('Leads Recientes')).toBeInTheDocument();
    });
  });

  it('shows recent activity section', async () => {
    render(<CRMDashboard onNavigate={() => {}} onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('Actividad Reciente')).toBeInTheDocument();
    });
  });
});
