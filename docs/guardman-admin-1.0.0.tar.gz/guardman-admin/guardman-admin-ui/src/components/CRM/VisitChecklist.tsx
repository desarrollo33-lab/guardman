import { useState, useEffect } from 'react';
import { useApi } from '../../hooks/useApi';

interface Props {
  leadId: number;
  onComplete: () => void;
}

export function VisitChecklist({ leadId, onComplete }: Props) {
  const { api } = useApi();
  const [visit, setVisit] = useState<any>(null);
  const [form, setForm] = useState<any>({
    facility_type: '', facility_sqm: '', num_access_points: '',
    has_current_security: 0, current_competitor: '', current_contract_end: '',
    shifts_needed: '', armed_service: 0, risks_noted: '', notes: '',
  });
  const [photos, setPhotos] = useState<File[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api(`/api/crm/visits/${leadId}`).then((res: any) => {
      if (res?.visit) {
        setVisit(res.visit);
        setForm({
          facility_type: res.visit.facility_type || '',
          facility_sqm: res.visit.facility_sqm || '',
          num_access_points: res.visit.num_access_points || '',
          has_current_security: res.visit.has_current_security || 0,
          current_competitor: res.visit.current_competitor || '',
          current_contract_end: res.visit.current_contract_end || '',
          shifts_needed: res.visit.shifts_needed || '',
          armed_service: res.visit.armed_service || 0,
          risks_noted: res.visit.risks_noted || '',
          notes: res.visit.notes || '',
        });
      }
    }).catch(() => {});
  }, [leadId]);

  const handleSave = async (complete = false) => {
    setSaving(true);
    try {
      const payload = {
        lead_id: leadId,
        visit_date: new Date().toISOString().split('T')[0],
        ...form,
        facility_sqm: form.facility_sqm ? parseInt(form.facility_sqm) : null,
        num_access_points: form.num_access_points ? parseInt(form.num_access_points) : null,
        shifts_needed: form.shifts_needed ? parseInt(form.shifts_needed) : null,
        has_current_security: form.has_current_security ? 1 : 0,
        armed_service: form.armed_service ? 1 : 0,
        completed_at: complete ? new Date().toISOString() : null,
        id: visit?.id || undefined,
      };
      const res: any = await api('/api/crm/visits', { method: 'POST', body: JSON.stringify(payload) });
      if (res?.data) setVisit(res.data);

      if (complete && res?.data?.id) {
        for (const file of photos) {
          const fd = new FormData();
          fd.append('photo', file);
          fd.append('caption', '');
          await api(`/api/crm/visits/${res.data.id}/photos`, { method: 'POST', body: fd });
        }
        onComplete();
      }
    } catch (e) { /* ignore */ }
    setSaving(false);
  };

  const canComplete = form.facility_type && form.shifts_needed;

  return (
    <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5 space-y-4">
      <h3 className="text-sm font-medium text-white/50 mb-2">🏢 Checklist Visita Técnica</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <select value={form.facility_type} onChange={e => setForm(f => ({ ...f, facility_type: e.target.value }))} className="input-base">
          <option value="">Tipo de recinto *</option>
          <option value="Oficina">Oficina</option>
          <option value="Bodega">Bodega</option>
          <option value="Retail">Retail / Local comercial</option>
          <option value="Industrial">Industrial / Planta</option>
          <option value="Residencial">Residencial / Condominio</option>
          <option value="Evento">Evento</option>
          <option value="Otro">Otro</option>
        </select>
        <input type="number" value={form.facility_sqm} onChange={e => setForm(f => ({ ...f, facility_sqm: e.target.value }))}
          placeholder="Metros cuadrados" className="input-base" />
        <input type="number" value={form.num_access_points} onChange={e => setForm(f => ({ ...f, num_access_points: e.target.value }))}
          placeholder="Puntos de acceso" className="input-base" />
        <select value={form.shifts_needed} onChange={e => setForm(f => ({ ...f, shifts_needed: e.target.value }))} className="input-base">
          <option value="">Turnos necesarios *</option>
          <option value="1">1 turno</option>
          <option value="2">2 turnos</option>
          <option value="3">3 turnos</option>
          <option value="4">4 turnos (24h)</option>
        </select>
        <label className="flex items-center gap-2 text-sm text-white/60">
          <input type="checkbox" checked={!!form.has_current_security} onChange={e => setForm(f => ({ ...f, has_current_security: e.target.checked ? 1 : 0 }))} />
          Tiene seguridad actual
        </label>
        <label className="flex items-center gap-2 text-sm text-white/60">
          <input type="checkbox" checked={!!form.armed_service} onChange={e => setForm(f => ({ ...f, armed_service: e.target.checked ? 1 : 0 }))} />
          Servicio armado
        </label>
        <input value={form.current_competitor} onChange={e => setForm(f => ({ ...f, current_competitor: e.target.value }))}
          placeholder="Competidor actual" className="input-base" />
        <input type="date" value={form.current_contract_end} onChange={e => setForm(f => ({ ...f, current_contract_end: e.target.value }))}
          placeholder="Vencimiento contrato" className="input-base" />
        <textarea value={form.risks_noted} onChange={e => setForm(f => ({ ...f, risks_noted: e.target.value }))}
          placeholder="Riesgos observados" className="input-base col-span-2" rows={2} />
        <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
          placeholder="Notas generales" className="input-base col-span-2" rows={2} />
      </div>

      <div className="border-t border-white/5 pt-3">
        <label className="text-xs text-white/40 block mb-1">Fotos de la visita</label>
        <input type="file" multiple accept="image/*" onChange={e => setPhotos(Array.from(e.target.files || []))} className="text-sm text-white/50" />
        {photos.length > 0 && <p className="text-xs text-white/30 mt-1">{photos.length} foto(s) seleccionada(s)</p>}
      </div>

      <div className="flex gap-2">
        <button onClick={() => handleSave(false)} disabled={saving}
          className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white/70 text-sm rounded-lg transition-colors">
          {saving ? 'Guardando...' : 'Guardar borrador'}
        </button>
        <button onClick={() => handleSave(true)} disabled={saving || !canComplete}
          className="px-4 py-2 bg-orange-600 hover:bg-orange-700 disabled:bg-white/10 text-white text-sm rounded-lg font-medium transition-colors">
          {saving ? 'Guardando...' : 'Completar Visita y Avanzar'}
        </button>
      </div>
      {!canComplete && <p className="text-xs text-red-400/60">Complete tipo de recinto y turnos para avanzar.</p>}
    </div>
  );
}
