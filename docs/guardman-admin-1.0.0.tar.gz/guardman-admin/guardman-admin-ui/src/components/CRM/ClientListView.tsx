// GuardMan CRM — Client List
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { fmt } from './CRMPage';
import { toast } from '../UI/Toast';

interface Props {
  onSelectClient: (id: number) => void;
}

export function ClientListView({ onSelectClient }: Props) {
  const { api, loading } = useApi();
  const [clients, setClients] = useState<any[]>([]);

  useEffect(() => {
    api('/api/crm/clients').then((data: any) => {
      setClients(Array.isArray(data) ? data : []);
    }).catch(() => { toast('Error al cargar clientes', 'error'); });
  }, []);

  if (loading && clients.length === 0) return <div className="flex items-center justify-center h-64 text-white/30">Cargando clientes...</div>;

  const totalMRR = clients.filter(c => c.status === 'active').reduce((s, c) => s + (c.monthly_value || 0), 0);
  const activeCount = clients.filter(c => c.status === 'active').length;

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Clientes</h2>
          <p className="text-xs text-white/30">{activeCount} activos · Ingresos Mensuales Contratados: {fmt(totalMRR)}</p>
        </div>
      </div>

      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/5">
              <th className="text-left p-3 text-white/40 text-xs">Empresa</th>
              <th className="text-left p-3 text-white/40 text-xs">Contacto</th>
              <th className="text-center p-3 text-white/40 text-xs">Servicios</th>
              <th className="text-center p-3 text-white/40 text-xs">Mensual</th>
              <th className="text-center p-3 text-white/40 text-xs">Contrato</th>
              <th className="text-center p-3 text-white/40 text-xs">Estado</th>
            </tr>
          </thead>
          <tbody>
            {clients.map((c: any) => (
              <tr key={c.id} className="border-b border-white/[0.03] hover:bg-white/[0.02] cursor-pointer" onClick={() => onSelectClient(c.id)}>
                <td className="p-3">
                  <p className="text-white/70">{c.company_name || '—'}</p>
                  <p className="text-xs text-white/30">{c.industry || ''}</p>
                </td>
                <td className="p-3">
                  <p className="text-white/60 text-xs">{c.primary_contact_name || '—'}</p>
                  <p className="text-white/30 text-xs">{c.primary_contact_email || ''}</p>
                </td>
                <td className="p-3 text-center text-white/50">{c.active_services || 0}</td>
                <td className="p-3 text-center text-white/70 font-medium">{fmt(c.monthly_value)}</td>
                <td className="p-3 text-center">
                  <p className="text-xs text-white/40">{c.contract_type || '—'}</p>
                  <p className="text-[10px] text-white/20">{c.contract_end ? `Hasta ${new Date(c.contract_end).toLocaleDateString('es-CL', { month: 'short', year: 'numeric' })}` : ''}</p>
                </td>
                <td className="p-3 text-center">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${clientStatusColors(c.status)}`}>
                    {clientStatusLabel(c.status)}
                  </span>
                </td>
              </tr>
            ))}
            {clients.length === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-white/20">No hay clientes registrados aún. Convierte leads ganados en clientes.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function clientStatusColors(status: string): string {
  const map: Record<string, string> = {
    active: 'bg-emerald-500/15 text-emerald-300',
    paused: 'bg-yellow-500/15 text-yellow-300',
    churned: 'bg-red-500/15 text-red-300',
    prospect: 'bg-blue-500/15 text-blue-300',
  };
  return map[status] || 'bg-gray-500/15 text-gray-300';
}

function clientStatusLabel(status: string): string {
  const map: Record<string, string> = { active: 'Activo', paused: 'Pausado', churned: 'Churned', prospect: 'Prospecto' };
  return map[status] || status;
}
