import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MockDataLoader } from './MockDataLoader';

describe('MockDataLoader', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.restoreAllMocks();
  });

  it('renders "Cargar Demo" button when demo is off', () => {
    render(<MockDataLoader />);
    expect(screen.getByText('🧪 Cargar Demo')).toBeInTheDocument();
  });

  it('opens dropdown when clicked', () => {
    render(<MockDataLoader />);
    fireEvent.click(screen.getByText('🧪 Cargar Demo'));
    expect(screen.getByText('🧪 Modo Demo CRM')).toBeInTheDocument();
    expect(screen.getByText('✅ Activar Demo')).toBeInTheDocument();
  });

  it('shows demo stats in dropdown', () => {
    render(<MockDataLoader />);
    fireEvent.click(screen.getByText('🧪 Cargar Demo'));
    expect(screen.getByText('12')).toBeInTheDocument();
    expect(screen.getByText('5')).toBeInTheDocument();
    expect(screen.getByText('4')).toBeInTheDocument();
    expect(screen.getByText('$31.3M')).toBeInTheDocument();
  });

  it('dropdown shows correct description', () => {
    render(<MockDataLoader />);
    fireEvent.click(screen.getByText('🧪 Cargar Demo'));
    expect(screen.getByText(/Carga 12 leads/)).toBeInTheDocument();
  });
});
