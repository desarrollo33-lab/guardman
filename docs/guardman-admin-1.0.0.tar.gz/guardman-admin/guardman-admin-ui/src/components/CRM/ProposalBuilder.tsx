import { useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { fmt } from './CRMPage';

const SERVICE_TYPES = [
  { id: 'guardias', label: 'Guardias de Seguridad' },
  { id: 'cctv', label: 'CCTV / Video vigilancia' },
  { id: 'accesos', label: 'Control de Accesos' },
  { id: 'monitoreo', label: 'Central de Monitoreo' },
  { id: 'guardpod', label: 'GuardPod' },
  { id: 'ajax', label: 'Ajax Systems' },
];

interface Props {
  leadId: number;
  onClose: () => void;
  onCreated: () => void;
  version?: number;
}

export function ProposalBuilder({ leadId, onClose, onCreated, version }: Props) {
  const { api } = useApi();
  const [items, setItems] = useState<any[]>([]);
  const [conditions, setConditions] = useState({
    contract_period_months: 12,
    payment_terms: '30 días',
    annual_adjustment: 'IPC + 3%',
    sla_response_minutes: 15,
    valid_until: '',
    executive_notes: '',
  });
  const [saving, setSaving] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const addItem = (type: string) => {
    setItems(prev => [...prev, { service_type: type, quantity: 1, unit_price: 0, details: '' }]);
  };

  const updateItem = (idx: number, patch: any) => {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, ...patch, total: (patch.quantity || it.quantity) * (patch.unit_price || it.unit_price) } : it));
  };

  const removeItem = (idx: number) => setItems(prev => prev.filter((_, i) => i !== idx));

  const totalMonthly = items.reduce((sum, it) => sum + (it.total || 0), 0);

  const handleSave = async (status: string) => {
    setSaving(true);
    try {
      await api(`/api/crm/leads/${leadId}/proposals`, {
        method: 'POST',
        body: JSON.stringify({
          status,
          total_monthly: totalMonthly,
          total_setup: 0,
          valid_until: conditions.valid_until,
          notes: conditions.executive_notes,
          contract_period_months: conditions.contract_period_months,
          payment_terms: conditions.payment_terms,
          annual_adjustment: conditions.annual_adjustment,
          sla_response_minutes: conditions.sla_response_minutes,
          executive_notes: conditions.executive_notes,
          items,
        }),
      });
      onCreated();
    } catch {}
    setSaving(false);
  };

  if (showPreview) {
    return (
      <ProposalPreview
        leadName="Cliente"
        items={items}
        conditions={conditions}
        totalMonthly={totalMonthly}
        version={version}
        onBack={() => setShowPreview(false)}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1A2744] rounded-2xl border border-white/10 w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-white/5 flex items-center justify-between">
          <h3 className="text-lg font-medium text-white">Nueva Cotización {version ? `(Versión ${version})` : ''}</h3>
          <button onClick={onClose} className="text-white/30 hover:text-white">✕</button>
        </div>
        <div className="p-6 space-y-5">
          {/* Service type quick-add */}
          <div>
            <p className="text-xs text-white/40 mb-2">Agregar ítem por tipo de servicio</p>
            <div className="flex flex-wrap gap-2">
              {SERVICE_TYPES.map(s => (
                <button key={s.id} onClick={() => addItem(s.label)}
                  className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-white/60 text-xs rounded-lg transition-colors">
                  + {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Items */}
          {items.length > 0 && (
            <div className="space-y-2">
              {items.map((it, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center bg-white/[0.03] rounded-lg p-3">
                  <div className="col-span-4 text-sm text-white/70 truncate">{it.service_type}</div>
                  <input type="number" value={it.quantity} min={1}
                    onChange={e => updateItem(idx, { quantity: parseInt(e.target.value) || 1 })}
                    className="col-span-2 input-base text-xs" placeholder="Cant." />
                  <input type="number" value={it.unit_price}
                    onChange={e => updateItem(idx, { unit_price: parseFloat(e.target.value) || 0 })}
                    className="col-span-3 input-base text-xs" placeholder="Precio unit." />
                  <div className="col-span-2 text-sm text-white/50 text-right">{fmt(it.total || 0)}</div>
                  <button onClick={() => removeItem(idx)} className="col-span-1 text-red-400/60 hover:text-red-400 text-xs">✕</button>
                  <input value={it.details} onChange={e => updateItem(idx, { details: e.target.value })}
                    className="col-span-12 input-base text-xs mt-1" placeholder="Detalles (ej: uniforme, supervisor...)" />
                </div>
              ))}
              <div className="flex justify-between items-center pt-2">
                <span className="text-sm text-white/40">Total mensual estimado</span>
                <span className="text-lg font-bold text-white">{fmt(totalMonthly)}</span>
              </div>
            </div>
          )}

          {/* Conditions */}
          <div className="grid grid-cols-2 gap-3">
            <input type="number" value={conditions.contract_period_months}
              onChange={e => setConditions(c => ({ ...c, contract_period_months: parseInt(e.target.value) || 12 }))}
              placeholder="Período contrato (meses)" className="input-base text-xs" />
            <input value={conditions.payment_terms}
              onChange={e => setConditions(c => ({ ...c, payment_terms: e.target.value }))}
              placeholder="Forma de pago" className="input-base text-xs" />
            <input value={conditions.annual_adjustment}
              onChange={e => setConditions(c => ({ ...c, annual_adjustment: e.target.value }))}
              placeholder="Ajuste anual" className="input-base text-xs" />
            <input type="number" value={conditions.sla_response_minutes}
              onChange={e => setConditions(c => ({ ...c, sla_response_minutes: parseInt(e.target.value) || 15 }))}
              placeholder="SLA respuesta (min)" className="input-base text-xs" />
            <input type="date" value={conditions.valid_until}
              onChange={e => setConditions(c => ({ ...c, valid_until: e.target.value }))}
              placeholder="Vigencia hasta" className="input-base text-xs" />
          </div>
          <textarea value={conditions.executive_notes}
            onChange={e => setConditions(c => ({ ...c, executive_notes: e.target.value }))}
            placeholder="Notas ejecutivas / resumen para el cliente" className="input-base text-xs" rows={3} />

          {/* Actions */}
          <div className="flex gap-2">
            <button onClick={() => handleSave('draft')} disabled={saving || items.length === 0}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-white/70 text-sm rounded-lg transition-colors disabled:opacity-30">
              {saving ? 'Guardando...' : 'Guardar Borrador'}
            </button>
            <button onClick={() => setShowPreview(true)} disabled={items.length === 0}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg font-medium transition-colors disabled:opacity-30">
              Previsualizar
            </button>
            <button onClick={() => handleSave('sent')} disabled={saving || items.length === 0 || !conditions.valid_until}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-lg font-medium transition-colors disabled:opacity-30">
              {saving ? 'Guardando...' : 'Enviar Cotización'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProposalPreview({ leadName, items, conditions, totalMonthly, version, onBack }: {
  leadName: string; items: any[]; conditions: any; totalMonthly: number; version?: number; onBack: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white text-black rounded-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-8 space-y-6" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-2xl font-bold">GuardMan Chile</h2>
            <p className="text-sm text-gray-600">RUT: 77.123.456-K · Giro: Seguridad privada OS-10</p>
            <p className="text-sm text-gray-600">Dirección comercial · Santiago, Chile</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-bold text-gray-800">COTIZACIÓN</p>
            <p className="text-sm text-gray-600">N° COT-{new Date().getFullYear()}-{String(Math.floor(Math.random()*9000)+1000)}</p>
            {version ? <p className="text-xs text-gray-500">Versión {version}</p> : null}
            <p className="text-xs text-gray-500">{new Date().toLocaleDateString('es-CL')}</p>
          </div>
        </div>

        <div className="border-t pt-4">
          <p className="text-sm font-semibold text-gray-800">Cliente: {leadName}</p>
          <p className="text-sm text-gray-600">Resumen ejecutivo: {conditions.executive_notes || 'Propuesta comercial personalizada de servicios de seguridad privada.'}</p>
        </div>

        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-gray-100 text-left">
              <th className="p-2 border">Servicio</th>
              <th className="p-2 border">Cant.</th>
              <th className="p-2 border">Precio Unit.</th>
              <th className="p-2 border">Total</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => (
              <tr key={i} className="border-b">
                <td className="p-2 border">
                  <div className="font-medium">{it.service_type}</div>
                  {it.details && <div className="text-xs text-gray-500">{it.details}</div>}
                </td>
                <td className="p-2 border">{it.quantity}</td>
                <td className="p-2 border">{fmt(it.unit_price)}</td>
                <td className="p-2 border font-medium">{fmt(it.total || 0)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex justify-between items-center border-t pt-4">
          <div className="text-sm text-gray-600 space-y-1">
            <p><strong>Inversión total mensual:</strong> {fmt(totalMonthly)}</p>
            <p><strong>Período mínimo:</strong> {conditions.contract_period_months} meses</p>
            <p><strong>Forma de pago:</strong> {conditions.payment_terms}</p>
            <p><strong>Ajuste anual:</strong> {conditions.annual_adjustment}</p>
            <p><strong>SLA respuesta:</strong> {conditions.sla_response_minutes} minutos</p>
            <p><strong>Vigencia:</strong> {conditions.valid_until ? new Date(conditions.valid_until).toLocaleDateString('es-CL') : '—'}</p>
          </div>
        </div>

        <div className="border-t pt-4 text-xs text-gray-500">
          <p>Condiciones comerciales sujetas a evaluación técnica. Para aceptar esta cotización, responda este correo o contacte a su ejecutivo.</p>
        </div>

        <div className="flex gap-2 pt-2">
          <button onClick={onBack} className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 text-sm rounded-lg">← Volver al editor</button>
          <button onClick={() => window.print()} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg font-medium">Imprimir / Guardar PDF</button>
        </div>
      </div>
    </div>
  );
}
