import { useEffect, useState, useCallback } from 'react';
import { useApi } from '../../hooks/useApi';
import { fmt } from './CRMPage';
import { toast } from '../UI/Toast';

interface Props {
  onSelectLead: (id: number) => void;
}

export function CRMMiDia({ onSelectLead }: Props) {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);

  const load = useCallback(() => {
    api('/api/crm/dashboard').then(setData).catch(() => toast('Error al cargar Mi Día', 'error'));
  }, []);

  useEffect(() => { load(); }, [load]);

  if (loading && !data) return <div className="flex items-center justify-center h-64 text-white/30">Cargando Mi Día...</div>;

  const mi = data?.mi_dia || {};
  const summary = data || {};

  return (
    <div className="p-4 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">📞 Mi Día</h2>
          <p className="text-xs text-white/30">{new Date().toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
        </div>
        <div className="flex gap-4 text-right">
          <div>
            <p className="text-2xl font-bold text-white">{summary.leads ? Object.values(summary.leads).reduce((a: number, b: any) => a + (b.cnt || 0), 0) : 0}</p>
            <p className="text-[10px] text-white/30 uppercase tracking-wider">Leads totales</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-emerald-400">{fmt(summary.pipeline_weighted_value || 0)}</p>
            <p className="text-[10px] text-white/30 uppercase tracking-wider">Pipeline ponderado</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <Block title="🔴 URGENTE" items={mi.urgent || []} onSelect={onSelectLead} color="border-red-500/20" />
        <Block title="📞 REINTENTAR" items={mi.retry || []} onSelect={onSelectLead} color="border-yellow-500/20" />
        <Block title="🏢 VISITAS HOY" items={mi.visits || []} onSelect={onSelectLead} color="border-orange-500/20" />
        <Block title="📋 SEGUIMIENTO COTIZ." items={mi.followup || []} onSelect={onSelectLead} color="border-purple-500/20" />
        <Block title="⚠️ CONGELADOS" items={mi.frozen || []} onSelect={onSelectLead} color="border-cyan-500/20" />
        <Block title="🔄 RENOVACIONES 60 DÍAS" items={summary.upcoming_renewals || []} onSelect={onSelectLead} color="border-green-500/20" />
      </div>
    </div>
  );
}

function Block({ title, items, onSelect, color }: { title: string; items: any[]; onSelect: (id: number) => void; color: string }) {
  return (
    <div className={`bg-[#0f1729] rounded-xl border ${color} p-4`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-white/70">{title}</h3>
        <span className="text-xs bg-white/5 text-white/40 px-2 py-0.5 rounded-full">{items.length}</span>
      </div>
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {items.length === 0 && <p className="text-xs text-white/10 text-center py-6">Nada pendiente</p>}
        {items.map((item: any) => (
          <div
            key={item.id}
            onClick={() => onSelect(item.lead_id || item.id)}
            className="p-2.5 bg-white/[0.03] hover:bg-white/[0.06] rounded-lg cursor-pointer transition-colors"
          >
            <div className="flex items-center justify-between">
              <p className="text-sm text-white font-medium truncate">{item.contact_name || item.company_name || 'Sin nombre'}</p>
              {item.estimated_value ? <span className="text-xs text-white/40">{fmt(item.estimated_value)}</span> : null}
            </div>
            {item.company_name && item.contact_name && <p className="text-xs text-white/30 truncate">{item.company_name}</p>}
            {item.next_follow_up && <p className="text-[10px] text-red-400/60 mt-0.5">📞 vencido {new Date(item.next_follow_up).toLocaleDateString('es-CL')}</p>}
            {item.created_at && !item.next_follow_up && <p className="text-[10px] text-white/20 mt-0.5">{new Date(item.created_at).toLocaleDateString('es-CL')}</p>}
            {item.no_contact_attempts ? <p className="text-[10px] text-yellow-400/60 mt-0.5">No contesta {item.no_contact_attempts}/3</p> : null}
            {item.contract_end ? <p className="text-[10px] text-green-400/60 mt-0.5">Vence {new Date(item.contract_end).toLocaleDateString('es-CL')}</p> : null}
          </div>
        ))}
      </div>
    </div>
  );
}
