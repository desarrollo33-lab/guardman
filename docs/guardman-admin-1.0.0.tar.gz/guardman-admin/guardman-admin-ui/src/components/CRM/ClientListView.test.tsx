import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { ClientListView } from './ClientListView';
import { MOCK_CLIENTS } from '../../../../tests/mocks/crm-mocks';

vi.mock('../../hooks/useApi', () => ({
  useApi: () => ({
    api: vi.fn(async () => MOCK_CLIENTS),
    loading: false,
    error: null,
  }),
}));

describe('ClientListView', () => {
  it('renders client table headers', async () => {
    render(<ClientListView onSelectClient={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('Empresa')).toBeInTheDocument();
    });
    expect(screen.getByText('Contacto')).toBeInTheDocument();
    expect(screen.getByText('Servicios')).toBeInTheDocument();
    expect(screen.getByText('Mensual')).toBeInTheDocument();
    expect(screen.getByText('Contrato')).toBeInTheDocument();
    expect(screen.getByText('Estado')).toBeInTheDocument();
  });

  it('renders client names', async () => {
    render(<ClientListView onSelectClient={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('Bodega Central Seis')).toBeInTheDocument();
    });
    expect(screen.getByText('Minera del Norte')).toBeInTheDocument();
    expect(screen.getByText('Supermercados Sur')).toBeInTheDocument();
  });

  it('shows MRR summary', async () => {
    render(<ClientListView onSelectClient={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText(/activos/)).toBeInTheDocument();
    });
  });
});
