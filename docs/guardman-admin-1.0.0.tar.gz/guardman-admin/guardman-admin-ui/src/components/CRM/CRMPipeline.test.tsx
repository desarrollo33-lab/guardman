import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { CRMPipeline } from './CRMPipeline';
import { MOCK_PIPELINE_RESPONSE } from '../../../../tests/mocks/crm-mocks';

vi.mock('../../hooks/useApi', () => ({
  useApi: () => ({
    api: vi.fn(async () => MOCK_PIPELINE_RESPONSE.data),
    loading: false,
    error: null,
  }),
}));

describe('CRMPipeline', () => {
  it('renders all 7 kanban columns', async () => {
    render(<CRMPipeline onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('🆕 Nuevo')).toBeInTheDocument();
    });
    expect(screen.getByText('📞 Contactado')).toBeInTheDocument();
    expect(screen.getByText('🏢 Visita Técnica')).toBeInTheDocument();
    expect(screen.getByText('📋 Cotización Enviada')).toBeInTheDocument();
    expect(screen.getByText('🤝 Negociación')).toBeInTheDocument();
    expect(screen.getByText('✅ Ganado')).toBeInTheDocument();
    expect(screen.getByText('❌ Perdido')).toBeInTheDocument();
  });

  it('shows lead cards with contact names', async () => {
    render(<CRMPipeline onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('Juan Pérez')).toBeInTheDocument();
    });
    expect(screen.getByText('María González')).toBeInTheDocument();
    expect(screen.getByText('Carlos Ruiz')).toBeInTheDocument();
  });

  it('shows estimated values on cards', async () => {
    render(<CRMPipeline onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('$1.8M')).toBeInTheDocument();
    });
  });

  it('has "Nuevo Lead" button', async () => {
    render(<CRMPipeline onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('+ Nuevo Lead')).toBeInTheDocument();
    });
  });

  it('opens new lead modal on click', async () => {
    render(<CRMPipeline onSelectLead={() => {}} />);
    await waitFor(() => {
      expect(screen.getByText('+ Nuevo Lead')).toBeInTheDocument();
    });
    fireEvent.click(screen.getByText('+ Nuevo Lead'));
    await waitFor(() => {
      expect(screen.getByText('Nuevo Lead')).toBeInTheDocument();
    });
  });
});
