// GuardMan CRM — Dashboard Comercial Puro (sin SEO)
// FASE CRM-6: KPIs orientados a ventas
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { toast } from '../UI/Toast';

interface Props {
  onNavigate: (tab: string) => void;
  onSelectLead: (id: number) => void;
}

export function CRMDashboard({ onNavigate, onSelectLead }: Props) {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    api('/api/crm/dashboard').then(setData).catch(() => toast('Error al cargar CRM', 'error'));
  }, []);

  if (loading && !data) return <div className="flex items-center justify-center h-64 text-white/30">Cargando CRM...</div>;
  if (!data) return <div className="p-6 text-red-400">Error cargando datos.</div>;

  const leads = data.leads || {};
  const clients = data.clients || {};
  const activeLeads = (leads.new?.cnt || 0) + (leads.contacted?.cnt || 0) + (leads.visit_scheduled?.cnt || 0) + (leads.proposal_sent?.cnt || 0) + (leads.negotiation?.cnt || 0);
  const totalPipelineValue = (leads.new?.total_value || 0) + (leads.contacted?.total_value || 0) + (leads.visit_scheduled?.total_value || 0) + (leads.proposal_sent?.total_value || 0) + (leads.negotiation?.total_value || 0);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">💼 CRM</h1>
          <p className="text-sm text-white/40 mt-1">Dashboard comercial</p>
        </div>
        <span className="text-xs text-white/20">{new Date().toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <KPICard icon="🆕" label="Nuevos este mes" value={leads.new?.cnt || 0} color="blue" />
        <KPICard icon="💼" label="Pipeline Activo" value={activeLeads} color="purple" />
        <KPICard icon="💰" label="Pipeline $" value={fmt(totalPipelineValue)} color="green" />
        <KPICard icon="🏆" label="Ganados" value={leads.won?.cnt || 0} color="emerald" />
        <KPICard icon="🏢" label="Ingresos Mensuales Contratados" value={fmt(clients.monthly_revenue || 0)} color="orange" />
      </div>

      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider">Embudo de Ventas</h3>
          <button onClick={() => onNavigate('pipeline')} className="text-xs text-blue-400 hover:text-blue-300">Ver Pipeline →</button>
        </div>
        <div className="space-y-3">
          {([
            { key: 'new', label: '🆕 Nuevo', color: 'bg-blue-500/40' },
            { key: 'contacted', label: '📞 Contactado', color: 'bg-yellow-500/40' },
            { key: 'visit_scheduled', label: '🏢 Visita Técnica', color: 'bg-orange-500/40' },
            { key: 'proposal_sent', label: '📋 Cotización', color: 'bg-purple-500/40' },
            { key: 'negotiation', label: '🤝 Negociación', color: 'bg-cyan-500/40' },
            { key: 'won', label: '✅ Ganado', color: 'bg-green-500/40' },
            { key: 'lost', label: '❌ Perdido', color: 'bg-red-500/30' },
          ] as const).map(stage => {
            const s = leads[stage.key] || { cnt: 0, total_value: 0 };
            const maxCnt = Math.max(...Object.values(leads).map((v: any) => v.cnt || 0), 1);
            return (
              <div key={stage.key} className="flex items-center gap-3">
                <span className="text-sm text-white/70 w-40">{stage.label}</span>
                <div className="flex-1 h-6 bg-white/5 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${stage.color}`} style={{ width: `${Math.max(4, ((s.cnt || 0) / maxCnt) * 100)}%` }} />
                </div>
                <span className="text-sm font-medium text-white w-8 text-right">{s.cnt || 0}</span>
                <span className="text-xs text-white/30 w-24 text-right">{fmt(s.total_value || 0)}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider">Leads Recientes</h3>
            <button onClick={() => onNavigate('pipeline')} className="text-xs text-blue-400 hover:text-blue-300">Ver todos →</button>
          </div>
          <div className="space-y-2">
            {(data.recent_leads || []).length === 0 ? (
              <div className="text-center py-8">
                <p className="text-white/20 text-sm mb-2">Sin leads aún</p>
              </div>
            ) : (data.recent_leads || []).map((lead: any) => (
              <div key={lead.id} onClick={() => onSelectLead(lead.id)}
                className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] hover:bg-white/[0.05] cursor-pointer transition-colors">
                <div className="flex items-center gap-3">
                  <StatusBadge status={lead.status} />
                  <div>
                    <p className="text-sm text-white">{lead.contact_name}{lead.company_name ? ` — ${lead.company_name}` : ''}</p>
                    <p className="text-xs text-white/30">{(lead.service_slug || '').replace(/-/g, ' ')} · {(lead.location_slug || '').replace(/-/g, ' ')}</p>
                  </div>
                </div>
                <span className="text-sm font-medium text-white/60">{lead.estimated_value ? fmt(lead.estimated_value) : ''}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
          <h3 className="text-sm font-medium text-white/60 uppercase tracking-wider mb-4">Actividad Reciente</h3>
          {(data.recent_interactions || []).length === 0 ? (
            <p className="text-sm text-white/20 text-center py-8">Sin interacciones registradas</p>
          ) : (
            <div className="space-y-3">
              {(data.recent_interactions || []).map((i: any) => (
                <div key={i.id} className="border-l-2 border-white/10 pl-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-white/20">{new Date(i.created_at).toLocaleDateString('es-CL', { day: 'numeric', month: 'short' })}</span>
                    <span className="text-[10px] bg-white/5 px-1.5 py-0.5 rounded text-white/40">{i.type}</span>
                  </div>
                  <p className="text-sm text-white/60 mt-1">{i.summary}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function KPICard({ icon, label, value, color }: {
  icon: string; label: string; value: string | number; color: string;
}) {
  const borders: Record<string, string> = {
    blue: 'border-blue-500/20', green: 'border-emerald-500/20', emerald: 'border-emerald-500/20',
    purple: 'border-purple-500/20', orange: 'border-orange-500/20', red: 'border-red-500/20',
  };
  const texts: Record<string, string> = {
    blue: 'text-blue-400', green: 'text-emerald-400', emerald: 'text-emerald-400',
    purple: 'text-purple-400', orange: 'text-orange-400', red: 'text-red-400',
  };
  return (
    <div className={`bg-[#1A2744]/60 rounded-xl border ${borders[color] || 'border-white/5'} p-4`}>
      <div className="flex items-center gap-2 mb-2"><span>{icon}</span><span className="text-xs text-white/40 uppercase tracking-wider">{label}</span></div>
      <div className={`text-2xl font-bold ${texts[color] || 'text-white'}`}>{value}</div>
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { bg: string; text: string; label: string }> = {
    new: { bg: 'bg-blue-500/15', text: 'text-blue-300', label: 'Nuevo' },
    contacted: { bg: 'bg-yellow-500/15', text: 'text-yellow-300', label: 'Contactado' },
    visit_scheduled: { bg: 'bg-orange-500/15', text: 'text-orange-300', label: 'Visita' },
    proposal_sent: { bg: 'bg-purple-500/15', text: 'text-purple-300', label: 'Cotización' },
    negotiation: { bg: 'bg-cyan-500/15', text: 'text-cyan-300', label: 'Negociación' },
    won: { bg: 'bg-green-500/15', text: 'text-green-300', label: 'Ganado' },
    lost: { bg: 'bg-red-500/15', text: 'text-red-300', label: 'Perdido' },
  };
  const c = config[status] || { bg: 'bg-gray-500/15', text: 'text-gray-300', label: status };
  return <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${c.bg} ${c.text}`}>{c.label}</span>;
}

export function DifficultyBadge({ difficulty }: { difficulty?: string }) {
  if (!difficulty) return null;
  const map: Record<string, string> = {
    easy: 'pill pill-success',
    medium: 'pill pill-warning',
    hard: 'pill pill-error',
  };
  return <span className={map[difficulty] || 'pill pill-neutral'}>{difficulty === 'easy' ? 'Fácil' : difficulty === 'medium' ? 'Medio' : 'Difícil'}</span>;
}

export function fmt(n: number): string {
  if (!n || n === 0) return '—';
  if (n >= 1000000) return `$${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `$${(n / 1000).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}
