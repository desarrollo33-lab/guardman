import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { fmt } from './CRMPage';
import { toast } from '../UI/Toast';

interface Props {
  onSelectLead: (id: number) => void;
}

export function ProposalListView({ onSelectLead }: Props) {
  const { api, loading } = useApi();
  const [proposals, setProposals] = useState<any[]>([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    api('/api/crm/proposals').then((res: any) => {
      setProposals(Array.isArray(res) ? res : []);
    }).catch(() => { toast('Error al cargar cotizaciones', 'error'); });
  }, []);

  const filtered = filter
    ? proposals.filter(p => (p.status || '').toLowerCase() === filter.toLowerCase())
    : proposals;

  const total = filtered.reduce((s, p) => s + (p.total_monthly || 0), 0);

  if (loading && proposals.length === 0) return <div className="flex items-center justify-center h-64 text-white/30">Cargando cotizaciones...</div>;

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white">Cotizaciones</h2>
          <p className="text-xs text-white/30">{filtered.length} cotizaciones · Total mensual: {fmt(total)}</p>
        </div>
        <select value={filter} onChange={e => setFilter(e.target.value)} className="input-base text-xs">
          <option value="">Todos los estados</option>
          <option value="draft">Borrador</option>
          <option value="sent">Enviada</option>
          <option value="accepted">Aceptada</option>
          <option value="rejected">Rechazada</option>
          <option value="expired">Vencida</option>
        </select>
      </div>

      <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/5">
              <th className="text-left p-3 text-white/40 text-xs">N°</th>
              <th className="text-left p-3 text-white/40 text-xs">Cliente</th>
              <th className="text-center p-3 text-white/40 text-xs">Estado</th>
              <th className="text-center p-3 text-white/40 text-xs">Versión</th>
              <th className="text-center p-3 text-white/40 text-xs">Total/mes</th>
              <th className="text-center p-3 text-white/40 text-xs">Vigencia</th>
              <th className="text-center p-3 text-white/40 text-xs">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p: any) => (
              <tr key={p.id} className="border-b border-white/[0.03] hover:bg-white/[0.02]">
                <td className="p-3 text-white/50 text-xs">{p.slug}</td>
                <td className="p-3">
                  <p className="text-white/70 text-sm">{p.company_name || p.contact_name || '—'}</p>
                </td>
                <td className="p-3 text-center">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${statusColors(p.status)}`}>{p.status || 'draft'}</span>
                </td>
                <td className="p-3 text-center text-white/50 text-xs">V{p.version || 1}</td>
                <td className="p-3 text-center text-white/70 font-medium">{fmt(p.total_monthly)}</td>
                <td className="p-3 text-center text-white/40 text-xs">{p.valid_until ? new Date(p.valid_until).toLocaleDateString('es-CL') : '—'}</td>
                <td className="p-3 text-center">
                  <button onClick={() => onSelectLead(p.lead_id)} className="text-xs text-blue-400 hover:text-blue-300">Ver lead</button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={7} className="p-8 text-center text-white/20">No hay cotizaciones</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function statusColors(status: string): string {
  const map: Record<string, string> = {
    draft: 'bg-gray-500/15 text-gray-300',
    sent: 'bg-blue-500/15 text-blue-300',
    accepted: 'bg-green-500/15 text-green-300',
    rejected: 'bg-red-500/15 text-red-300',
    expired: 'bg-yellow-500/15 text-yellow-300',
  };
  return map[status] || 'bg-gray-500/15 text-gray-300';
}
