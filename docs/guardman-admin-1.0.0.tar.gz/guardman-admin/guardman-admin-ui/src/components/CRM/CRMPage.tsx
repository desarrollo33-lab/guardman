// GuardMan Admin v3.0 — CRM Page
import { useState } from 'react';
import { CRMDashboard } from './CRMDashboard';
import { CRMPipeline } from './CRMPipeline';
import { LeadDetail } from './LeadDetail';
import { ClientListView } from './ClientListView';
import { ClientDetailView } from './ClientDetailView';
import { ProposalListView } from './ProposalListView';
import { CRMMiDia } from './CRMMiDia';
import { MockDataLoader } from './MockDataLoader';

type CRMTab = 'miDia' | 'pipeline' | 'proposals' | 'clients' | 'dashboard';

const TABS: { id: CRMTab; label: string }[] = [
  { id: 'miDia', label: '📞 Mi día' },
  { id: 'pipeline', label: 'Pipeline' },
  { id: 'proposals', label: 'Cotizaciones' },
  { id: 'clients', label: 'Clientes' },
  { id: 'dashboard', label: 'Dashboard' },
];

const isDemo = typeof window !== 'undefined' && localStorage.getItem('gm_demo_mode') === 'crm';

export function CRMPage() {
  const [tab, setTab] = useState<CRMTab>('miDia');
  const [selectedLeadId, setSelectedLeadId] = useState<number | null>(null);
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);

  if (selectedLeadId !== null) {
    return (
      <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
        <div style={{display:'flex',alignItems:'center',gap:'8px',padding:'8px 0',marginBottom:'16px'}}>
          <button onClick={() => setSelectedLeadId(null)} className="btn btn-ghost btn-sm">← Volver</button>
          <span style={{color:'var(--fg-dim)',fontSize:'13px'}}>Lead #{selectedLeadId}</span>
        </div>
        <LeadDetail leadId={selectedLeadId} onUpdate={() => setSelectedLeadId(null)} />
      </div>
    );
  }

  if (selectedClientId !== null) {
    return (
      <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
        <ClientDetailView clientId={selectedClientId} onBack={() => setSelectedClientId(null)} />
      </div>
    );
  }

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%'}}>
      {isDemo && (
        <div style={{
          background: 'linear-gradient(90deg, #f59e0b, #d97706)',
          color: '#fff',
          padding: '6px 12px',
          fontSize: '12px',
          fontWeight: 600,
          textAlign: 'center',
          letterSpacing: '0.05em',
          textTransform: 'uppercase',
        }}>
          🧪 MODO DEMO — Datos de prueba (no persisten)
        </div>
      )}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 4px' }}>
        <div className="tabs" style={{ flex: 1 }}>
          {TABS.map(t => (
            <div key={t.id} className={`tab${tab === t.id ? ' active' : ''}`} onClick={() => setTab(t.id)}>
              {t.label}
            </div>
          ))}
        </div>
        <div style={{ padding: '0 8px' }}>
          <MockDataLoader />
        </div>
      </div>
      {tab === 'miDia' && <CRMMiDia onSelectLead={setSelectedLeadId} />}
      {tab === 'dashboard' && <CRMDashboard onNavigate={(t: any) => setTab(t)} onSelectLead={setSelectedLeadId} />}
      {tab === 'pipeline' && <CRMPipeline onSelectLead={setSelectedLeadId} />}
      {tab === 'clients' && <ClientListView onSelectClient={setSelectedClientId} />}
      {tab === 'proposals' && <ProposalListView onSelectLead={setSelectedLeadId} />}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; className: string }> = {
    new: { label: 'Nuevo', className: 'pill pill-info' },
    contacted: { label: 'Contactado', className: 'pill pill-warning' },
    contactado: { label: 'Contactado', className: 'pill pill-warning' },
    visit_scheduled: { label: 'Visita Técnica', className: 'pill pill-warning' },
    proposal_sent: { label: 'Cotización', className: 'pill pill-info' },
    negotiation: { label: 'Negociación', className: 'pill pill-success' },
    qualified: { label: 'Calificado', className: 'pill pill-success' },
    proposal: { label: 'Propuesta', className: 'pill pill-info' },
    won: { label: 'Ganado', className: 'pill pill-success' },
    lost: { label: 'Perdido', className: 'pill pill-error' },
    active: { label: 'Activo', className: 'pill pill-success' },
  };
  const m = map[status] || { label: status, className: 'pill pill-neutral' };
  return <span className={m.className}>{m.label}</span>;
}

export function DifficultyBadge({ difficulty }: { difficulty?: string }) {
  if (!difficulty) return null;
  const map: Record<string, string> = {
    easy: 'pill pill-success',
    medium: 'pill pill-warning',
    hard: 'pill pill-error',
  };
  return <span className={map[difficulty] || 'pill pill-neutral'}>{difficulty === 'easy' ? 'Fácil' : difficulty === 'medium' ? 'Medio' : 'Difícil'}</span>;
}

export function fmt(n: number): string {
  if (n >= 1000000) return `$${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `$${(n / 1000).toFixed(1)}K`;
  return `$${n}`;
}
