import { useState } from 'react';
import { useApi } from '../../hooks/useApi';

interface Props {
  leadId: number;
  leadName: string;
  onClose: () => void;
  onCreated: () => void;
}

export function ConvertToClientModal({ leadId, leadName, onClose, onCreated }: Props) {
  const { api } = useApi();
  const [form, setForm] = useState({
    company_name: leadName,
    company_rut: '',
    industry: '',
    contract_start: '',
    contract_end: '',
    contract_type: '',
    monthly_value: '',
    primary_contact_name: '',
    primary_contact_email: '',
    primary_contact_phone: '',
    address: '',
    services: [{ service_slug: '', quantity: 1, unit: '', monthly_price: '' }],
  });
  const [saving, setSaving] = useState(false);

  const updateService = (idx: number, patch: any) => {
    setForm(f => ({
      ...f,
      services: f.services.map((s, i) => i === idx ? { ...s, ...patch } : s),
    }));
  };

  const addService = () => {
    setForm(f => ({ ...f, services: [...f.services, { service_slug: '', quantity: 1, unit: '', monthly_price: '' }] }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.contract_start || !form.contract_end || !form.monthly_value) return;
    setSaving(true);
    try {
      await api('/api/crm/clients', {
        method: 'POST',
        body: JSON.stringify({
          lead_id: leadId,
          company_name: form.company_name,
          company_rut: form.company_rut || null,
          industry: form.industry || null,
          contract_start: form.contract_start,
          contract_end: form.contract_end,
          contract_type: form.contract_type || null,
          monthly_value: parseFloat(form.monthly_value) || 0,
          primary_contact_name: form.primary_contact_name || null,
          primary_contact_email: form.primary_contact_email || null,
          primary_contact_phone: form.primary_contact_phone || null,
          address: form.address || null,
          services: form.services
            .filter(s => s.service_slug)
            .map(s => ({ ...s, quantity: parseInt(s.quantity as any) || 1, monthly_price: parseFloat(s.monthly_price as any) || 0 })),
          status: 'active',
        }),
      });
      onCreated();
    } catch {}
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1A2744] rounded-2xl border border-white/10 w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-white/5"><h3 className="text-lg font-medium text-white">Convertir a Cliente</h3></div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <input required value={form.company_name} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))}
            placeholder="Nombre empresa *" className="input-base" />
          <div className="grid grid-cols-2 gap-3">
            <input value={form.company_rut} onChange={e => setForm(f => ({ ...f, company_rut: e.target.value }))}
              placeholder="RUT" className="input-base" />
            <input value={form.industry} onChange={e => setForm(f => ({ ...f, industry: e.target.value }))}
              placeholder="Industria" className="input-base" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input type="date" required value={form.contract_start} onChange={e => setForm(f => ({ ...f, contract_start: e.target.value }))}
              placeholder="Inicio contrato *" className="input-base" />
            <input type="date" required value={form.contract_end} onChange={e => setForm(f => ({ ...f, contract_end: e.target.value }))}
              placeholder="Fin contrato *" className="input-base" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input value={form.contract_type} onChange={e => setForm(f => ({ ...f, contract_type: e.target.value }))}
              placeholder="Tipo contrato" className="input-base" />
            <input type="number" required value={form.monthly_value} onChange={e => setForm(f => ({ ...f, monthly_value: e.target.value }))}
              placeholder="Valor mensual *" className="input-base" />
          </div>
          <input value={form.primary_contact_name} onChange={e => setForm(f => ({ ...f, primary_contact_name: e.target.value }))}
            placeholder="Contacto principal" className="input-base" />
          <div className="grid grid-cols-2 gap-3">
            <input value={form.primary_contact_email} onChange={e => setForm(f => ({ ...f, primary_contact_email: e.target.value }))}
              placeholder="Email" className="input-base" />
            <input value={form.primary_contact_phone} onChange={e => setForm(f => ({ ...f, primary_contact_phone: e.target.value }))}
              placeholder="Teléfono" className="input-base" />
          </div>
          <input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))}
            placeholder="Dirección" className="input-base" />

          <div className="border-t border-white/5 pt-3">
            <p className="text-xs text-white/40 mb-2">Servicios contratados</p>
            {form.services.map((s, idx) => (
              <div key={idx} className="grid grid-cols-12 gap-2 mb-2">
                <input value={s.service_slug} onChange={e => updateService(idx, { service_slug: e.target.value })}
                  placeholder="Servicio" className="col-span-5 input-base text-xs" />
                <input type="number" value={s.quantity} onChange={e => updateService(idx, { quantity: e.target.value })}
                  placeholder="Cant." className="col-span-2 input-base text-xs" />
                <input value={s.unit} onChange={e => updateService(idx, { unit: e.target.value })}
                  placeholder="Unidad" className="col-span-2 input-base text-xs" />
                <input type="number" value={s.monthly_price} onChange={e => updateService(idx, { monthly_price: e.target.value })}
                  placeholder="$/mes" className="col-span-3 input-base text-xs" />
              </div>
            ))}
            <button type="button" onClick={addService} className="text-xs text-blue-400 hover:text-blue-300">+ Agregar servicio</button>
          </div>

          <button type="submit" disabled={saving}
            className="w-full py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors">
            {saving ? 'Guardando...' : '✅ Confirmar Conversión'}
          </button>
        </form>
      </div>
    </div>
  );
}
