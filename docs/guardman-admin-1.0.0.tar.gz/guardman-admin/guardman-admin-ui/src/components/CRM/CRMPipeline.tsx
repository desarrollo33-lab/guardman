// GuardMan Intel — CRM Pipeline (Kanban view)
import { useEffect, useState, useCallback } from 'react';
import { useApi } from '../../hooks/useApi';
import { StatusBadge, DifficultyBadge, fmt } from './CRMDashboard';
import { toast } from '../UI/Toast';

const STAGES = [
  { id: 'new', label: '🆕 Nuevo', color: 'border-blue-500/30' },
  { id: 'contacted', label: '📞 Contactado', color: 'border-yellow-500/30' },
  { id: 'visit_scheduled', label: '🏢 Visita Técnica', color: 'border-orange-500/30' },
  { id: 'proposal_sent', label: '📋 Cotización Enviada', color: 'border-purple-500/30' },
  { id: 'negotiation', label: '🤝 Negociación', color: 'border-cyan-500/30' },
  { id: 'won', label: '✅ Ganado', color: 'border-green-500/30' },
  { id: 'lost', label: '❌ Perdido', color: 'border-red-500/30' },
] as const;

interface Props {
  onSelectLead: (id: number) => void;
}

export function CRMPipeline({ onSelectLead }: Props) {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);
  const [showNewLead, setShowNewLead] = useState(false);

  const loadPipeline = useCallback(() => {
    api('/api/crm/pipeline').then(setData).catch(() => toast('Error al cargar Pipeline', 'error'));
  }, []);

  useEffect(() => { loadPipeline(); }, [loadPipeline]);

  const handleMoveLead = async (leadId: number, newStatus: string) => {
    try {
      await api(`/api/crm/leads/${leadId}`, {
        method: 'PUT',
        body: JSON.stringify({ status: newStatus, last_activity_at: new Date().toISOString() }),
      });
      loadPipeline();
    } catch { toast('Error al mover lead', 'error'); }
  };

  if (loading && !data) return <div className="flex items-center justify-center h-64 text-white/30">Cargando pipeline...</div>;

  const pipeline = data?.pipeline || {};
  const summary = data?.summary || {};

  return (
    <div className="p-4 h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 shrink-0">
        <div>
          <h2 className="text-lg font-bold text-white">CRM Pipeline</h2>
          <p className="text-xs text-white/30">
            {summary.total || 0} leads · Pipeline ponderado: {fmt(summary.weighted_value || 0)}
          </p>
        </div>
        <button
          onClick={() => setShowNewLead(true)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg font-medium transition-colors"
        >
          + Nuevo Lead
        </button>
      </div>

      {/* Kanban */}
      <div className="flex-1 overflow-x-auto">
        <div className="flex gap-3 h-full min-w-max pb-4">
          {STAGES.map(stage => {
            const leads = pipeline[stage.id] || [];
            return (
              <div key={stage.id} className={`w-72 flex flex-col bg-[#0f1729] rounded-xl border ${stage.color} shrink-0`}>
                {/* Stage header */}
                <div className="px-3 py-2.5 border-b border-white/5 flex items-center justify-between">
                  <span className="text-sm font-medium text-white/70">{stage.label}</span>
                  <span className="text-xs bg-white/5 text-white/40 px-2 py-0.5 rounded-full">{leads.length}</span>
                </div>

                {/* Leads */}
                <div className="flex-1 overflow-y-auto p-2 space-y-2">
                  {leads.map((lead: any) => (
                    <LeadCard
                      key={lead.id}
                      lead={lead}
                      onClick={() => onSelectLead(lead.id)}
                      onMoveNext={stage.id !== 'won' && stage.id !== 'lost' ? () => {
                        const nextStage = STAGES[STAGES.findIndex(s => s.id === stage.id) + 1];
                        if (nextStage) handleMoveLead(lead.id, nextStage.id);
                      } : undefined}
                      onMovePrev={stage.id !== 'new' ? () => {
                        const prevStage = STAGES[STAGES.findIndex(s => s.id === stage.id) - 1];
                        if (prevStage) handleMoveLead(lead.id, prevStage.id);
                      } : undefined}
                    />
                  ))}
                  {leads.length === 0 && (
                    <p className="text-xs text-white/10 text-center py-8">Sin leads</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* New Lead Modal */}
      {showNewLead && <NewLeadModal onClose={() => setShowNewLead(false)} onCreated={loadPipeline} />}
    </div>
  );
}

function daysSince(dateStr?: string | null): number {
  if (!dateStr) return 999;
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return 999;
  return Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
}

function LeadCard({ lead, onClick, onMoveNext, onMovePrev }: {
  lead: any; onClick: () => void; onMoveNext?: () => void; onMovePrev?: () => void;
}) {
  const inactiveDays = daysSince(lead.last_activity_at || lead.last_contact_at || lead.created_at);
  const isFrozen = inactiveDays > 7;
  const noAnswer = (lead.no_contact_attempts || 0) > 0;

  return (
    <div className={`rounded-lg p-3 cursor-pointer transition-colors group ${isFrozen ? 'bg-red-500/10 hover:bg-red-500/15 border border-red-500/20' : 'bg-white/[0.03] hover:bg-white/[0.06]'}`}>
      <div onClick={onClick}>
        <div className="flex items-center justify-between mb-1">
          <p className="text-sm text-white font-medium truncate">{lead.contact_name}</p>
          <div className="flex items-center gap-1.5">
            {noAnswer && (
              <span className="text-[10px] bg-red-500/20 text-red-300 px-1.5 py-0.5 rounded">No contesta {lead.no_contact_attempts}/3</span>
            )}
            <DifficultyBadge difficulty={lead.market_difficulty} />
          </div>
        </div>
        {lead.company_name && <p className="text-xs text-white/40 truncate">{lead.company_name}</p>}
        <div className="flex items-center gap-2 mt-1.5">
          <span className="text-[10px] text-white/25 bg-white/5 px-1.5 py-0.5 rounded">
            {(lead.service_slug || '').replace(/-/g, ' ')}
          </span>
          {lead.location_slug && (
            <span className="text-[10px] text-white/25 bg-white/5 px-1.5 py-0.5 rounded">
              {(lead.location_slug || '').replace(/-/g, ' ')}
            </span>
          )}
        </div>
        <div className="flex items-center justify-between mt-2">
          <span className="text-sm font-medium text-white/50">{lead.estimated_value ? fmt(lead.estimated_value) : ''}</span>
          <div className="flex items-center gap-2">
            {isFrozen && (
              <span className="text-[10px] text-red-400/70">🔴 {inactiveDays}d sin actividad</span>
            )}
            {lead.next_follow_up && (
              <span className="text-[10px] text-yellow-400/60">📞 {new Date(lead.next_follow_up).toLocaleDateString('es-CL', { day: 'numeric', month: 'short' })}</span>
            )}
          </div>
        </div>
      </div>
      {/* Move buttons */}
      <div className="flex gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
        {onMovePrev && (
          <button onClick={(e) => { e.stopPropagation(); onMovePrev(); }}
            className="text-[10px] px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-white/30 hover:text-white/60">
            ←
          </button>
        )}
        {onMoveNext && (
          <button onClick={(e) => { e.stopPropagation(); onMoveNext(); }}
            className="text-[10px] px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-white/30 hover:text-white/60">
            →
          </button>
        )}
      </div>
    </div>
  );
}

function NewLeadModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { api } = useApi();
  const [services, setServices] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [form, setForm] = useState({
    contact_name: '', contact_email: '', contact_phone: '',
    company_name: '', service_slug: '', location_slug: '',
    message: '', estimated_value: 0, source: 'manual',
  });

  useEffect(() => {
    Promise.all([
      api('/api/services').catch(() => { toast('Error al cargar servicios', 'error'); return []; }),
      api('/api/locations').catch(() => { toast('Error al cargar ubicaciones', 'error'); return []; }),
    ]).then(([svcs, locs]) => {
      setServices(Array.isArray(svcs) ? svcs : []);
      setLocations(Array.isArray(locs) ? locs : []);
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api('/api/crm/leads', {
        method: 'POST',
        body: JSON.stringify(form),
      });
      onCreated();
      onClose();
    } catch { toast('Error al crear lead', 'error'); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1A2744] rounded-2xl border border-white/10 w-full max-w-lg overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
          <h3 className="text-lg font-medium text-white">Nuevo Lead</h3>
          <button onClick={onClose} className="text-white/30 hover:text-white">✕</button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <input required value={form.contact_name} onChange={e => setForm(f => ({ ...f, contact_name: e.target.value }))}
              placeholder="Nombre *" className="col-span-2 input-base" />
            <input value={form.contact_email} onChange={e => setForm(f => ({ ...f, contact_email: e.target.value }))}
              placeholder="Email" className="input-base" />
            <input value={form.contact_phone} onChange={e => setForm(f => ({ ...f, contact_phone: e.target.value }))}
              placeholder="Teléfono" className="input-base" />
            <input value={form.company_name} onChange={e => setForm(f => ({ ...f, company_name: e.target.value }))}
              placeholder="Empresa" className="col-span-2 input-base" />
            <select value={form.service_slug} onChange={e => setForm(f => ({ ...f, service_slug: e.target.value }))} className="input-base">
              <option value="">Servicio</option>
              {services.map(s => <option key={s.slug} value={s.slug}>{s.name}</option>)}
            </select>
            <select value={form.location_slug} onChange={e => setForm(f => ({ ...f, location_slug: e.target.value }))} className="input-base">
              <option value="">Comuna</option>
              {locations.map(l => <option key={l.slug} value={l.slug}>{l.name}</option>)}
            </select>
            <input type="number" value={form.estimated_value || ''} onChange={e => setForm(f => ({ ...f, estimated_value: parseFloat(e.target.value) || 0 }))}
              placeholder="Valor estimado ($)" className="col-span-2 input-base" />
            <textarea value={form.message} onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
              placeholder="Mensaje / descripción" className="col-span-2 input-base" rows={3} />
          </div>
          <button type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">
            Crear Lead
          </button>
        </form>
      </div>
    </div>
  );
}
