import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { CRMPage, StatusBadge, DifficultyBadge, fmt } from './CRMPage';

// Mock child components to isolate CRMPage
vi.mock('./CRMDashboard', () => ({ CRMDashboard: () => <div data-testid="dashboard">Dashboard</div> }));
vi.mock('./CRMPipeline', () => ({ CRMPipeline: () => <div data-testid="pipeline">Pipeline</div> }));
vi.mock('./CRMMiDia', () => ({ CRMMiDia: ({ onSelectLead }: any) => <div data-testid="midia">MiDia</div> }));
vi.mock('./ClientListView', () => ({ ClientListView: ({ onSelectClient }: any) => <div data-testid="clients">Clients</div> }));
vi.mock('./ProposalListView', () => ({ ProposalListView: ({ onSelectLead }: any) => <div data-testid="proposals">Proposals</div> }));
vi.mock('./LeadDetail', () => ({ LeadDetail: ({ leadId, onUpdate }: any) => <div data-testid="lead-detail">Lead {leadId}</div> }));
vi.mock('./ClientDetailView', () => ({ ClientDetailView: ({ clientId, onBack }: any) => <div data-testid="client-detail">Client {clientId}</div> }));

describe('CRMPage', () => {
  it('renders all tabs', () => {
    render(<CRMPage />);
    expect(screen.getByText('📞 Mi día')).toBeInTheDocument();
    expect(screen.getByText('Pipeline')).toBeInTheDocument();
    expect(screen.getByText('Cotizaciones')).toBeInTheDocument();
    expect(screen.getByText('Clientes')).toBeInTheDocument();
    expect(screen.getByText('Dashboard')).toBeInTheDocument();
  });

  it('shows MiDia by default', () => {
    render(<CRMPage />);
    expect(screen.getByTestId('midia')).toBeInTheDocument();
  });

  it('switches to Pipeline tab', () => {
    render(<CRMPage />);
    fireEvent.click(screen.getByText('Pipeline'));
    expect(screen.getByTestId('pipeline')).toBeInTheDocument();
  });

  it('switches to Clients tab', () => {
    render(<CRMPage />);
    fireEvent.click(screen.getByText('Clientes'));
    expect(screen.getByTestId('clients')).toBeInTheDocument();
  });

  it('switches to Dashboard tab', () => {
    render(<CRMPage />);
    fireEvent.click(screen.getByText('Dashboard'));
    expect(screen.getByTestId('dashboard')).toBeInTheDocument();
  });

  it('switches to Proposals tab', () => {
    render(<CRMPage />);
    fireEvent.click(screen.getByText('Cotizaciones'));
    expect(screen.getByTestId('proposals')).toBeInTheDocument();
  });
});

describe('StatusBadge', () => {
  it.each([
    ['new', 'Nuevo'],
    ['contacted', 'Contactado'],
    ['visit_scheduled', 'Visita Técnica'],
    ['proposal_sent', 'Cotización'],
    ['negotiation', 'Negociación'],
    ['won', 'Ganado'],
    ['lost', 'Perdido'],
    ['active', 'Activo'],
  ])('renders correct label for %s', (status, label) => {
    render(<StatusBadge status={status} />);
    expect(screen.getByText(label)).toBeInTheDocument();
  });

  it('falls back to raw status for unknown', () => {
    render(<StatusBadge status="weird_status" />);
    expect(screen.getByText('weird_status')).toBeInTheDocument();
  });
});

describe('DifficultyBadge', () => {
  it('renders nothing when difficulty is undefined', () => {
    const { container } = render(<DifficultyBadge />);
    expect(container.firstChild).toBeNull();
  });

  it.each([
    ['easy', 'Fácil'],
    ['medium', 'Medio'],
    ['hard', 'Difícil'],
  ])('renders %s as "%s"', (diff, label) => {
    render(<DifficultyBadge difficulty={diff} />);
    expect(screen.getByText(label)).toBeInTheDocument();
  });
});

describe('fmt', () => {
  it('formats millions', () => {
    expect(fmt(1500000)).toBe('$1.5M');
  });
  it('formats thousands', () => {
    expect(fmt(85000)).toBe('$85.0K');
  });
  it('formats small numbers', () => {
    expect(fmt(500)).toBe('$500');
  });
});
