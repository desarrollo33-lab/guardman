// GuardMan CRM — Mock Data Loader Button
// One-click load/unload of demo data

import { useState, useEffect } from 'react';

export function MockDataLoader() {
  const [isDemo, setIsDemo] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    setIsDemo(localStorage.getItem('gm_demo_mode') === 'crm');
  }, []);

  const enableDemo = () => {
    localStorage.setItem('gm_demo_mode', 'crm');
    window.location.reload();
  };

  const disableDemo = () => {
    localStorage.removeItem('gm_demo_mode');
    window.location.reload();
  };

  if (isDemo) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <span style={{
          fontSize: '11px',
          fontWeight: 600,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
          color: '#fbbf24',
          background: 'rgba(251, 191, 36, 0.1)',
          padding: '4px 10px',
          borderRadius: '6px',
          border: '1px solid rgba(251, 191, 36, 0.2)',
        }}>
          🧪 Demo
        </span>
        <button
          onClick={disableDemo}
          title="Volver a datos reales del servidor"
          style={{
            fontSize: '11px',
            padding: '4px 10px',
            borderRadius: '6px',
            border: '1px solid rgba(239, 68, 68, 0.3)',
            background: 'rgba(239, 68, 68, 0.1)',
            color: '#ef4444',
            cursor: 'pointer',
            fontWeight: 500,
          }}
          onMouseEnter={e => { (e.target as HTMLElement).style.background = 'rgba(239, 68, 68, 0.2)'; }}
          onMouseLeave={e => { (e.target as HTMLElement).style.background = 'rgba(239, 68, 68, 0.1)'; }}
        >
          ❌ Desactivar
        </button>
      </div>
    );
  }

  return (
    <div style={{ position: 'relative' }}>
      <button
        onClick={() => setShowDropdown(!showDropdown)}
        style={{
          fontSize: '12px',
          padding: '6px 14px',
          borderRadius: '8px',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          background: 'rgba(59, 130, 246, 0.1)',
          color: '#60a5fa',
          cursor: 'pointer',
          fontWeight: 600,
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
        }}
        onMouseEnter={e => { (e.target as HTMLElement).style.background = 'rgba(59, 130, 246, 0.2)'; }}
        onMouseLeave={e => { (e.target as HTMLElement).style.background = 'rgba(59, 130, 246, 0.1)'; }}
      >
        🧪 Cargar Demo
      </button>

      {showDropdown && (
        <>
          <div
            style={{ position: 'fixed', inset: 0, zIndex: 40 }}
            onClick={() => setShowDropdown(false)}
          />
          <div style={{
            position: 'absolute',
            top: 'calc(100% + 8px)',
            right: 0,
            zIndex: 50,
            width: '280px',
            background: '#1A2744',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: '12px',
            padding: '16px',
            boxShadow: '0 20px 40px rgba(0,0,0,0.4)',
          }}>
            <h4 style={{ fontSize: '13px', fontWeight: 600, color: '#fff', marginBottom: '8px' }}>
              🧪 Modo Demo CRM
            </h4>
            <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.5)', marginBottom: '12px', lineHeight: 1.5 }}>
              Carga 12 leads, 5 clientes, 8 interacciones y 4 cotizaciones de prueba para explorar el CRM sin conexión al servidor.
            </p>
            <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginBottom: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span>Leads</span><span style={{ color: '#60a5fa' }}>12</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span>Clientes</span><span style={{ color: '#60a5fa' }}>5</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span>Cotizaciones</span><span style={{ color: '#60a5fa' }}>4</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Pipeline total</span><span style={{ color: '#60a5fa' }}>$31.3M</span>
              </div>
            </div>
            <button
              onClick={enableDemo}
              style={{
                width: '100%',
                padding: '8px',
                borderRadius: '8px',
                border: 'none',
                background: '#2563eb',
                color: '#fff',
                fontSize: '12px',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              ✅ Activar Demo
            </button>
            <p style={{ fontSize: '10px', color: 'rgba(255,255,255,0.3)', marginTop: '8px', textAlign: 'center' }}>
              La página se recargará automáticamente
            </p>
          </div>
        </>
      )}
    </div>
  );
}
