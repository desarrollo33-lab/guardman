// GuardMan CRM — Lead Detail with contextual intelligence
import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { StatusBadge, DifficultyBadge, fmt } from './CRMDashboard';
import { VisitChecklist } from './VisitChecklist';
import { ProposalBuilder } from './ProposalBuilder';
import { ConvertToClientModal } from './ConvertToClientModal';
import { toast } from '../UI/Toast';

interface Props {
  leadId: number;
  onUpdate: () => void;
}

export function LeadDetail({ leadId, onUpdate }: Props) {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);
  const [showInteraction, setShowInteraction] = useState(false);
  const [showProposal, setShowProposal] = useState(false);
  const [showLossModal, setShowLossModal] = useState(false);
  const [showConvertModal, setShowConvertModal] = useState(false);

  useEffect(() => {
    api(`/api/crm/leads/${leadId}`).then(setData).catch(() => toast('Error al cargar lead', 'error'));
  }, [leadId]);

  const handleStatusChange = async (newStatus: string) => {
    try {
      if (newStatus === 'lost') {
        setShowLossModal(true);
        return;
      }
      await api(`/api/crm/leads/${leadId}`, {
        method: 'PUT',
        body: JSON.stringify({ status: newStatus, last_activity_at: new Date().toISOString() }),
      });
      api(`/api/crm/leads/${leadId}`).then(setData).catch(() => toast('Error al actualizar lead', 'error'));
    } catch { toast('Error al cambiar estado del lead', 'error'); }
  };

  if (loading && !data) return <div className="p-6 text-white/30">Cargando lead...</div>;
  if (!data) return <div className="p-6 text-red-400">Lead no encontrado</div>;

  const lead = data.lead;
  const interactions = data.interactions || [];
  const proposals = data.proposals || [];
  const intel = data.intel;

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <StatusBadge status={lead.status} />
            <DifficultyBadge difficulty={lead.market_difficulty} />
          </div>
          <h2 className="text-xl font-bold text-white">{lead.contact_name}</h2>
          {lead.company_name && <p className="text-white/50">{lead.company_name}</p>}
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-white">{lead.estimated_value ? fmt(lead.estimated_value) : '—'}</p>
          <p className="text-xs text-white/30">Prob: {Math.round((lead.probability || 0) * 100)}%</p>
        </div>
      </div>

      {/* Quick actions */}
      <div className="flex gap-2 flex-wrap">
        {lead.status === 'new' && (
          <button onClick={() => handleStatusChange('contacted')} className="px-4 py-2 bg-yellow-500/20 text-yellow-300 text-sm rounded-lg hover:bg-yellow-500/30">
            📞 Marcar Contactado
          </button>
        )}
        {lead.status === 'contacted' && (
          <button onClick={() => handleStatusChange('visit_scheduled')} className="px-4 py-2 bg-orange-500/20 text-orange-300 text-sm rounded-lg hover:bg-orange-500/30">
            🏢 Agendar Visita
          </button>
        )}
        {lead.status === 'visit_scheduled' && (
          <span className="px-3 py-2 bg-orange-500/10 text-orange-300/60 text-sm rounded-lg">
            🏢 En visita técnica
          </span>
        )}
        {lead.status === 'proposal_sent' && (
          <>
            <button onClick={() => handleStatusChange('negotiation')} className="px-4 py-2 bg-cyan-500/20 text-cyan-300 text-sm rounded-lg hover:bg-cyan-500/30">
              🤝 A Negociación
            </button>
            <button onClick={() => handleStatusChange('lost')} className="px-4 py-2 bg-red-500/20 text-red-300 text-sm rounded-lg hover:bg-red-500/30">
              ❌ Perdido
            </button>
          </>
        )}
        {lead.status === 'negotiation' && (
          <>
            <button onClick={() => handleStatusChange('won')} className="px-4 py-2 bg-green-500/20 text-green-300 text-sm rounded-lg hover:bg-green-500/30">
              ✅ Ganado
            </button>
            <button onClick={() => handleStatusChange('lost')} className="px-4 py-2 bg-red-500/20 text-red-300 text-sm rounded-lg hover:bg-red-500/30">
              ❌ Perdido
            </button>
          </>
        )}
        {lead.status === 'won' && (
          <button onClick={() => setShowConvertModal(true)} className="px-4 py-2 bg-green-600/20 text-green-300 text-sm rounded-lg hover:bg-green-600/30">
            🏢 Convertir a Cliente
          </button>
        )}
        {(lead.status === 'proposal_sent' || lead.status === 'negotiation') && (
          <button onClick={() => setShowProposal(true)} className="px-4 py-2 bg-purple-500/20 text-purple-300 text-sm rounded-lg hover:bg-purple-500/30">
            📋 Crear Propuesta
          </button>
        )}
        <button onClick={() => setShowInteraction(true)} className="px-4 py-2 bg-white/5 text-white/60 text-sm rounded-lg hover:bg-white/10">
          + Nota / Interacción
        </button>
      </div>

      {lead.status === 'visit_scheduled' && (
        <VisitChecklist leadId={leadId} onComplete={() => {
          api(`/api/crm/leads/${leadId}`, {
            method: 'PUT',
            body: JSON.stringify({ status: 'proposal_sent', last_activity_at: new Date().toISOString() }),
          }).then(() => {
            api(`/api/crm/leads/${leadId}`).then(setData);
          });
        }} />
      )}

      {/* Main grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Lead info */}
        <div className="space-y-4">
          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">Contacto</h3>
            <div className="space-y-2 text-sm">
              {lead.contact_email && <p className="text-white/70">📧 {lead.contact_email}</p>}
              {lead.contact_phone && <p className="text-white/70">📱 {lead.contact_phone}</p>}
              {lead.company_rut && <p className="text-white/70">🏷️ RUT: {lead.company_rut}</p>}
              {lead.company_industry && <p className="text-white/70">🏭 {lead.company_industry}</p>}
            </div>
          </div>

          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">Cualificación Comercial</h3>
            <div className="space-y-2 text-sm">
              <p className="text-white/70">🏢 Recinto: {lead.facility_type || '—'}</p>
              <p className="text-white/70">📐 M²: {lead.facility_sqm || '—'}</p>
              <p className="text-white/70">🔒 Seguridad actual: {lead.has_current_security ? 'Sí' : 'No'}</p>
              {lead.current_competitor && <p className="text-white/70">⚔️ Competidor: {lead.current_competitor}</p>}
              {lead.current_contract_end && <p className="text-white/70">📅 Vence contrato: {new Date(lead.current_contract_end).toLocaleDateString('es-CL')}</p>}
              <p className="text-white/70">🕐 Turnos: {lead.shifts_needed || '—'}</p>
              <p className="text-white/70">🔫 Armado: {lead.armed_service ? 'Sí' : 'No'}</p>
            </div>
          </div>

          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">Servicio Solicitado</h3>
            <div className="space-y-2 text-sm">
              <p className="text-white/70">🔧 {(lead.service_slug || '—').replace(/-/g, ' ')}</p>
              <p className="text-white/70">📍 {(lead.location_slug || '—').replace(/-/g, ' ')}</p>
              {lead.location_address && <p className="text-white/50 text-xs">{lead.location_address}</p>}
            </div>
            {lead.message && (
              <div className="mt-3 p-3 bg-white/[0.03] rounded-lg">
                <p className="text-sm text-white/60 italic">"{lead.message}"</p>
              </div>
            )}
          </div>

          {/* Market Intel */}
          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">🧠 Intel de Mercado</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-white/40">Oportunidad</span>
                <span className="text-white/70">{Math.round(lead.serper_opportunity_score || 0)}/100</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/40">Competidores</span>
                <span className="text-white/70">{lead.competitor_density || 0} dominios</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/40">Posición GuardMan</span>
                <span className="text-white/70">{lead.guardman_position && lead.guardman_position < 999 ? `#${lead.guardman_position}` : 'Sin presencia'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/40">Dificultad</span>
                <DifficultyBadge difficulty={lead.market_difficulty} />
              </div>
              {/* Opportunity bar */}
              <div className="mt-2">
                <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${lead.serper_opportunity_score >= 70 ? 'bg-emerald-500' : lead.serper_opportunity_score >= 40 ? 'bg-yellow-500' : 'bg-red-500'}`}
                    style={{ width: `${Math.max(4, lead.serper_opportunity_score || 0)}%` }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Center + Right: Interactions + Intel */}
        <div className="lg:col-span-2 space-y-4">
          {/* Competitor Intel for this combo */}
          {intel && (
            <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
              <h3 className="text-sm font-medium text-white/50 mb-3">⚔️ Top Competidores en este Combo</h3>
              {(intel.topCompetitors || []).length === 0 ? (
                <p className="text-xs text-white/20">Sin datos de competencia para este combo</p>
              ) : (
                <div className="space-y-2">
                  {(intel.topCompetitors || []).map((c: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-white/[0.02] rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-white/20">#{c.position}</span>
                        <span className="text-sm text-white/70">{c.domain}</span>
                      </div>
                      <p className="text-xs text-white/30 max-w-xs truncate">{c.title}</p>
                    </div>
                  ))}
                </div>
              )}
              {(intel.contentGaps || []).length > 0 && (
                <div className="mt-3 pt-3 border-t border-white/5">
                  <p className="text-xs text-white/30 mb-1">Content Gaps detectados:</p>
                  {(intel.contentGaps || []).map((g: any, i: number) => (
                    <p key={i} className="text-xs text-yellow-400/60">• {g.query_text}</p>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Proposals */}
          {proposals.length > 0 && (
            <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
              <h3 className="text-sm font-medium text-white/50 mb-3">📋 Propuestas</h3>
              <div className="space-y-2">
                {proposals.map((p: any) => (
                  <div key={p.id} className="flex items-center justify-between p-3 bg-white/[0.02] rounded-lg">
                    <div>
                      <p className="text-sm text-white/70">{p.slug}</p>
                      <p className="text-xs text-white/30">{p.status} · {new Date(p.created_at).toLocaleDateString('es-CL')}</p>
                    </div>
                    <span className="text-sm font-medium text-white/60">{fmt(p.total_monthly)}/mes</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Interaction Timeline */}
          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">📝 Historial ({interactions.length})</h3>
            {interactions.length === 0 ? (
              <p className="text-xs text-white/20 text-center py-4">Sin interacciones registradas</p>
            ) : (
              <div className="space-y-3">
                {interactions.map((i: any) => (
                  <div key={i.id} className="border-l-2 border-white/10 pl-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-white/20">{new Date(i.created_at).toLocaleString('es-CL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                      <span className="text-[10px] bg-white/5 px-1.5 py-0.5 rounded text-white/40">{i.type}</span>
                      {i.direction && <span className="text-[10px] text-white/20">{i.direction === 'inbound' ? '←' : '→'}</span>}
                    </div>
                    <p className="text-sm text-white/60 mt-1">{i.summary}</p>
                    {i.outcome && <p className="text-xs text-white/30 mt-0.5">Resultado: {i.outcome}</p>}
                    {i.next_action && <p className="text-xs text-yellow-400/50 mt-0.5">Próximo: {i.next_action}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modals */}
      {showInteraction && (
        <InteractionModal
          leadId={leadId}
          onClose={() => setShowInteraction(false)}
          onCreated={() => { setShowInteraction(false); api(`/api/crm/leads/${leadId}`).then(setData); }}
        />
      )}
      {showProposal && (
        <ProposalBuilder
          leadId={leadId}
          onClose={() => setShowProposal(false)}
          onCreated={() => { setShowProposal(false); api(`/api/crm/leads/${leadId}`).then(setData); }}
          version={lead.proposals?.length ? lead.proposals.length + 1 : undefined}
        />
      )}
      {showLossModal && (
        <LossModal
          leadId={leadId}
          onClose={() => setShowLossModal(false)}
          onCreated={() => { setShowLossModal(false); api(`/api/crm/leads/${leadId}`).then(setData); }}
        />
      )}
      {showConvertModal && (
        <ConvertToClientModal
          leadId={leadId}
          leadName={lead.company_name || lead.contact_name}
          onClose={() => setShowConvertModal(false)}
          onCreated={() => { setShowConvertModal(false); onUpdate(); }}
        />
      )}
    </div>
  );
}

function InteractionModal({ leadId, onClose, onCreated }: { leadId: number; onClose: () => void; onCreated: () => void }) {
  const { api } = useApi();
  const [form, setForm] = useState({ type: 'call', direction: 'outbound', summary: '', outcome: '', next_action: '', next_action_date: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api(`/api/crm/leads/${leadId}/interactions`, {
        method: 'POST',
        body: JSON.stringify(form),
      });
      onCreated();
    } catch { toast('Error al crear interacción', 'error'); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1A2744] rounded-2xl border border-white/10 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-white/5"><h3 className="text-lg font-medium text-white">Registrar Interacción</h3></div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))} className="input-base">
              <option value="call">📞 Llamada</option>
              <option value="email">📧 Email</option>
              <option value="whatsapp">💬 WhatsApp</option>
              <option value="visit">🏢 Visita</option>
              <option value="note">📝 Nota</option>
            </select>
            <select value={form.direction} onChange={e => setForm(f => ({ ...f, direction: e.target.value }))} className="input-base">
              <option value="outbound">Saliente</option>
              <option value="inbound">Entrante</option>
            </select>
          </div>
          <textarea required value={form.summary} onChange={e => setForm(f => ({ ...f, summary: e.target.value }))}
            placeholder="Resumen de la interacción *" className="input-base" rows={3} />
          <select value={form.outcome} onChange={e => setForm(f => ({ ...f, outcome: e.target.value }))} className="input-base">
            <option value="">Resultado...</option>
            <option value="interested">Interesado</option>
            <option value="not_interested">No interesado</option>
            <option value="callback">Callback</option>
            <option value="proposal_requested">Solicita propuesta</option>
          </select>
          <input value={form.next_action} onChange={e => setForm(f => ({ ...f, next_action: e.target.value }))}
            placeholder="Próxima acción" className="input-base" />
          <input type="date" value={form.next_action_date} onChange={e => setForm(f => ({ ...f, next_action_date: e.target.value }))}
            className="input-base" />
          <button type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium">Guardar</button>
        </form>
      </div>
    </div>
  );
}

function NewProposalModal({ leadId, onClose, onCreated, competitorPriceRef }: {
  leadId: number; onClose: () => void; onCreated: () => void; competitorPriceRef?: number;
}) {
  const { api } = useApi();
  const [form, setForm] = useState({
    total_monthly: competitorPriceRef || 0, total_setup: 0, discount_pct: 0,
    notes: '', valid_until: '', win_probability: 0.5,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api(`/api/crm/leads/${leadId}/proposals`, {
        method: 'POST',
        body: JSON.stringify({ ...form, status: 'draft', ai_generated: false, competitor_price_ref: competitorPriceRef }),
      });
      onCreated();
    } catch { toast('Error al crear propuesta', 'error'); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1A2744] rounded-2xl border border-white/10 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-white/5"><h3 className="text-lg font-medium text-white">Nueva Propuesta</h3></div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <input type="number" value={form.total_monthly || ''} onChange={e => setForm(f => ({ ...f, total_monthly: parseFloat(e.target.value) || 0 }))}
            placeholder="Total mensual ($)" className="input-base" />
          <input type="number" value={form.total_setup || ''} onChange={e => setForm(f => ({ ...f, total_setup: parseFloat(e.target.value) || 0 }))}
            placeholder="Setup / instalación ($)" className="input-base" />
          <input type="number" step="0.1" value={form.discount_pct || ''} onChange={e => setForm(f => ({ ...f, discount_pct: parseFloat(e.target.value) || 0 }))}
            placeholder="Descuento (%)" className="input-base" />
          <input type="date" value={form.valid_until} onChange={e => setForm(f => ({ ...f, valid_until: e.target.value }))} className="input-base" />
          <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            placeholder="Notas" className="input-base" rows={2} />
          {competitorPriceRef && <p className="text-xs text-orange-400/50">💡 Precio ref. competencia: ~{fmt(competitorPriceRef)}</p>}
          <button type="submit" className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium">Crear Propuesta</button>
        </form>
      </div>
    </div>
  );
}

function LossModal({ leadId, onClose, onCreated }: { leadId: number; onClose: () => void; onCreated: () => void }) {
  const { api } = useApi();
  const [form, setForm] = useState({ loss_reason: '', loss_competitor: '', loss_price_ref: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.loss_reason) return;
    try {
      await api(`/api/crm/leads/${leadId}`, {
        method: 'PUT',
        body: JSON.stringify({
          status: 'lost',
          loss_reason: form.loss_reason,
          loss_competitor: form.loss_competitor || null,
          loss_price_ref: form.loss_price_ref ? parseFloat(form.loss_price_ref) : null,
          last_activity_at: new Date().toISOString(),
        }),
      });
      onCreated();
    } catch { toast('Error al registrar pérdida', 'error'); }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-[#1A2744] rounded-2xl border border-white/10 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-white/5"><h3 className="text-lg font-medium text-white">Registrar Pérdida</h3></div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <select required value={form.loss_reason} onChange={e => setForm(f => ({ ...f, loss_reason: e.target.value }))} className="input-base">
            <option value="">Motivo de pérdida *</option>
            <option value="Precio">Precio</option>
            <option value="Competencia">Competencia</option>
            <option value="Plazo">Plazo</option>
            <option value="Postergado">Postergado</option>
            <option value="No contactable">No contactable</option>
            <option value="No califica">No califica</option>
          </select>
          <input value={form.loss_competitor} onChange={e => setForm(f => ({ ...f, loss_competitor: e.target.value }))}
            placeholder="¿Quién ganó? (competencia)" className="input-base" />
          <input type="number" value={form.loss_price_ref} onChange={e => setForm(f => ({ ...f, loss_price_ref: e.target.value }))}
            placeholder="Precio referencia ($)" className="input-base" />
          <button type="submit" className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium">Confirmar Pérdida</button>
        </form>
      </div>
    </div>
  );
}
