import { useEffect, useState } from 'react';
import { useApi } from '../../hooks/useApi';
import { fmt } from './CRMPage';
import { toast } from '../UI/Toast';

interface Props {
  clientId: number;
  onBack: () => void;
}

export function ClientDetailView({ clientId, onBack }: Props) {
  const { api, loading } = useApi();
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    api(`/api/crm/clients/${clientId}`).then(setData).catch(() => toast('Error al cargar cliente', 'error'));
  }, [clientId]);

  if (loading && !data) return <div className="p-6 text-white/30">Cargando cliente...</div>;
  if (!data) return <div className="p-6 text-red-400">Cliente no encontrado</div>;

  const client = data.client;
  const services = data.services || [];
  const interactions = data.interactions || [];

  const daysToRenewal = client.contract_end
    ? Math.ceil((new Date(client.contract_end).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="btn btn-ghost btn-sm">← Volver</button>
      </div>

      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">{client.company_name || '—'}</h2>
          <p className="text-white/50">{client.primary_contact_name} · {client.primary_contact_email} · {client.primary_contact_phone}</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-white">{fmt(client.monthly_value || 0)}/mes</p>
          {daysToRenewal !== null && daysToRenewal <= 60 && (
            <p className={`text-xs ${daysToRenewal <= 30 ? 'text-red-400' : 'text-yellow-400'}`}>
              🔄 Renovación en {daysToRenewal} días
            </p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">Ficha Empresa</h3>
            <div className="space-y-2 text-sm">
              <p className="text-white/70">🏷️ RUT: {client.company_rut || '—'}</p>
              <p className="text-white/70">🏭 {client.industry || '—'}</p>
              <p className="text-white/70">📍 {client.address || '—'}</p>
              <p className="text-white/70">📐 Tamaño: {client.size || '—'}</p>
            </div>
          </div>

          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">Contrato</h3>
            <div className="space-y-2 text-sm">
              <p className="text-white/70">📝 Tipo: {client.contract_type || '—'}</p>
              <p className="text-white/70">📅 Inicio: {client.contract_start ? new Date(client.contract_start).toLocaleDateString('es-CL') : '—'}</p>
              <p className="text-white/70">📅 Fin: {client.contract_end ? new Date(client.contract_end).toLocaleDateString('es-CL') : '—'}</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">Servicios Contratados ({services.length})</h3>
            {services.length === 0 ? (
              <p className="text-xs text-white/20 text-center py-4">Sin servicios registrados</p>
            ) : (
              <div className="space-y-2">
                {services.map((s: any) => (
                  <div key={s.id} className="flex items-center justify-between p-3 bg-white/[0.02] rounded-lg">
                    <div>
                      <p className="text-sm text-white/70">{(s.service_slug || '').replace(/-/g, ' ')}</p>
                      <p className="text-xs text-white/30">{s.status} · {s.quantity} {s.unit || 'unidad(es)'}</p>
                    </div>
                    <span className="text-sm font-medium text-white/60">{fmt(s.monthly_price)}/mes</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-[#1A2744]/60 rounded-xl border border-white/5 p-5">
            <h3 className="text-sm font-medium text-white/50 mb-3">Historial ({interactions.length})</h3>
            {interactions.length === 0 ? (
              <p className="text-xs text-white/20 text-center py-4">Sin interacciones</p>
            ) : (
              <div className="space-y-3">
                {interactions.map((i: any) => (
                  <div key={i.id} className="border-l-2 border-white/10 pl-3">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-white/20">{new Date(i.created_at).toLocaleString('es-CL', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                      <span className="text-[10px] bg-white/5 px-1.5 py-0.5 rounded text-white/40">{i.type}</span>
                    </div>
                    <p className="text-sm text-white/60 mt-1">{i.summary}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
