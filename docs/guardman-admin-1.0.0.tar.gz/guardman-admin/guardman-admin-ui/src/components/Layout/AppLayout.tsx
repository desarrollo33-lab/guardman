// GuardMan Admin v3.0 — AppLayout
import { useCallback, useEffect, useState } from 'react';
import { Sidebar } from './Sidebar';

interface AppLayoutProps {
  onSendMessage: (message: string) => void;
  onAction: (action: string) => void;
  activeView: string;
  onToggleHistory?: () => void;
  children: React.ReactNode;
}

const VIEW_TITLES: Record<string, [string, string]> = {
  cms: ['CMS', 'Editor de Contenido'],
  media: ['Biblioteca de Medios', 'Galería de Imágenes'],
  adn: ['ADN de Marca', 'Identidad Corporativa'],
  crm: ['CRM', 'Pipeline de Leads'],
  intel: ['Intel Hub', 'Inteligencia Competitiva'],
};

export function AppLayout({ onAction, activeView, children }: AppLayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [bc, title] = VIEW_TITLES[activeView] || ['Dashboard', 'Panel General'];

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleSidebarAction = useCallback((actionId: string) => {
    if (actionId === 'open_settings') {
      onAction('open_settings');
    } else {
      onAction(actionId);
    }
  }, [onAction]);

  return (
    <div id="app-shell" className="active">
      {/* Desktop Sidebar */}
      {!isMobile && <Sidebar onAction={handleSidebarAction} activeView={activeView} />}

      {/* Mobile menu overlay */}
      {isMobile && mobileMenuOpen && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 35, background: 'rgba(0,0,0,0.5)'
        }} onClick={() => setMobileMenuOpen(false)}>
          <div style={{ width: '56px', height: '100vh', background: 'var(--surface-3)', borderRight: '1px solid var(--border-subtle)' }}
            onClick={e => e.stopPropagation()}>
            <Sidebar onAction={(id) => { handleSidebarAction(id); setMobileMenuOpen(false); }} activeView={activeView} />
          </div>
        </div>
      )}

      {/* Topbar */}
      <header id="topbar">
        {isMobile && (
          <button className="btn-icon" onClick={() => setMobileMenuOpen(true)}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 12h18M3 6h18M3 18h18"/></svg>
          </button>
        )}
        <div className="breadcrumb">
          <span id="bc-section">{bc}</span>
        </div>
        <div className="title-area">
          <h1>{title}</h1>
        </div>
        <div className="top-actions">
          <div className="deploy-status">
            <span className="dot" /> Live
          </div>
          <div className="user-avatar" title="admin@guardman.cl">AD</div>
        </div>
      </header>

      {/* Main Content */}
      <main id="main-content">
        <div id="view-area">
          <div className="view active" style={{ padding: '24px' }}>
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
