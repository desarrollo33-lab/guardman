// GuardMan Admin v3.0 — Sidebar
import { useState, useEffect } from 'react';
import { getToken } from '../../hooks/useApi';

interface SidebarProps {
  onAction: (action: string) => void;
  activeView: string;
  onToggleHistory?: () => void;
}

const ACTIONS = [
  { id: 'cms', label: 'CMS — Editor de Contenido', icon: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
  )},
  { id: 'adn', label: 'ADN de Marca — Identidad Corporativa', icon: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
  )},
  { id: 'crm', label: 'CRM — Pipeline de Leads', icon: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
  )},
  { id: 'intel', label: 'Intel Hub — Inteligencia Competitiva', icon: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
  )},
  { id: 'media', label: 'Biblioteca de Medios', icon: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
  )},
];

export function Sidebar({ onAction, activeView }: SidebarProps) {
  const [leadCount, setLeadCount] = useState<number | null>(null);

  useEffect(() => {
    const fetchLeadCount = async () => {
      try {
        const token = getToken();
        const headers: Record<string, string> = {};
        if (token) headers['Authorization'] = `Bearer ${token}`;
        const res = await fetch('https://guardman.oficinadesarrollo33.workers.dev/api/intel/leads?limit=1', { headers });
        const data = await res.json();
        if (data.ok) setLeadCount(data.total ?? 0);
      } catch { /* silently ignore */ }
    };
    fetchLeadCount();
    const interval = setInterval(fetchLeadCount, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <aside id="sidebar">
      <div className="sb-logo">GM</div>
      <nav>
        {ACTIONS.map(a => (
          <div
            key={a.id}
            className={`nav-item${activeView === a.id ? ' active' : ''}`}
            data-tooltip={a.label}
            onClick={() => onAction(a.id)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === 'Enter' && onAction(a.id)}
          >
            {a.icon}
            {a.id === 'crm' && leadCount !== null && <span className="badge">{leadCount}</span>}
          </div>
        ))}
      </nav>
      <div className="nav-spacer" />
      <div
        className="nav-item"
        data-tooltip="Configuración"
        onClick={() => onAction('open_settings')}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && onAction('open_settings')}
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
      </div>
    </aside>
  );
}
