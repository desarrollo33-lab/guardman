// GuardMan CMS Editor - Headless CMS Interface
import { useState, useEffect } from 'react';
import { SEOPanel } from './SEOPanel';
import { MediaPicker } from '../Media/MediaPicker';
import { LiteYouTube } from '../Media/LiteYouTube';
import { useSectionGenerator } from '../../hooks/useSectionGenerator';

interface ContentItem {
  slug: string;
  type: 'service' | 'location' | 'sector' | 'combo' | 'home' | 'static';
  name: string;
  score: number;
  published: boolean;
}

interface CMSContent {
  slug?: string;
  type?: string;
  version: number;
  last_modified?: string;
  seo: { title: string; description: string; canonical?: string };
  content: any;
  related_content?: any;
  meta: { author: string; quality_score: number; published: boolean };
}

const SITE_URL = 'https://guardman.oficinadesarrollo33.workers.dev';
const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

// Client-side SEO scoring (mirrors backend scoring.ts for instant feedback)
function calcBackendScore(content: any): { score: number; warnings: string[] } {
  const warnings: string[] = [];
  const sections = content?.content || content?.sections || {};
  const hero = sections.hero || {};
  const intro = sections.intro || {};
  const features = sections.features || {};
  const issues = sections.issues || {};
  const faqs = sections.faqs || {};
  const cta = sections.cta || {};
  const meta = sections.meta || content?.seo || {};
  let score = 0;

  // Title
  const title = meta.title || hero.heading || '';
  if (title.length >= 30 && title.length <= 60) score += 12;
  else if (title.length > 0) { score += 6; warnings.push('Title debe tener 30-60 caracteres'); }
  else warnings.push('Sin title');

  // Description
  const desc = meta.description || hero.subheading || '';
  if (desc.length >= 80 && desc.length <= 160) score += 12;
  else if (desc.length > 0) { score += 6; warnings.push('Description debe tener 80-160 caracteres'); }
  else warnings.push('Sin description');

  // Hero
  if (hero.heading) score += 5;
  if (hero.image) score += 5;
  else warnings.push('Sin imagen hero');

  // Intro
  const introParas = intro.paragraphs || [];
  const introText = introParas.join(' ');
  if (introText.length > 200) score += 10;
  else if (introText.length > 50) score += 5;

  // Features
  const featItems = features.items || [];
  if (featItems.length >= 6) score += 10;
  else if (featItems.length > 0) score += 5;

  // Issues
  const issueItems = issues.items || [];
  if (issueItems.length >= 4) score += 5;
  else if (issueItems.length > 0) score += 3;

  // FAQs
  const faqItems = faqs.items || [];
  if (faqItems.length >= 4) score += 10;
  else if (faqItems.length > 0) score += 5;

  // CTA
  if (cta.heading) score += 5;
  if (cta.button) score += 3;

  // Word count
  const allText = [introText, ...featItems, ...issueItems, ...faqItems.map((f: any) => (f.question||'')+' '+(f.answer||'')), cta.heading||'', cta.subheading||''].join(' ');
  const words = allText.split(/\s+/).filter(Boolean).length;
  if (words >= 300) score += 8;
  else if (words >= 150) score += 4;
  else warnings.push(`Solo ${words} palabras (minimo 300 recomendado)`);

  // TTR check (basic)
  const meaningfulWords = allText.toLowerCase().split(/\s+/).filter((w: string) => w.length > 4);
  if (meaningfulWords.length > 20) {
    const uniqueWords = new Set(meaningfulWords);
    const ttr = uniqueWords.size / meaningfulWords.length;
    if (ttr < 0.35) { warnings.push(`TTR ${(ttr*100).toFixed(0)}% — texto repetitivo`); score -= 5; }
    else if (ttr < 0.45) warnings.push(`TTR ${(ttr*100).toFixed(0)}% — diversidad baja`);
  }

  // Foreign word check
  const foreign = ['vandalism', 'residential', 'operate', 'склад', 'documentação', 'advisable', 'protegé', 'handlear'];
  const lower = allText.toLowerCase();
  for (const fw of foreign) {
    if (lower.includes(fw)) {
      warnings.push(`Palabra extranjera: "${fw}"`);
      score -= 3;
    }
  }

  return { score: Math.max(0, Math.min(100, score)), warnings };
}

function HomepageSection({ title, color, children }: { title: string; color: string; children: React.ReactNode }) {
  return (
    <div className="bg-gray-800 rounded-xl p-4">
      <h4 className={`font-semibold mb-3 text-${color}-400`}>{title}</h4>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function FieldInput({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="text-xs text-gray-400 block mb-1">{label}</label>
      <input type="text" value={value} onChange={e => onChange(e.target.value)} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" />
    </div>
  );
}

function FieldTextarea({ label, value, onChange, rows = 3 }: { label: string; value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <div>
      <label className="text-xs text-gray-400 block mb-1">{label}</label>
      <textarea value={value} onChange={e => onChange(e.target.value)} rows={rows} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" />
    </div>
  );
}


function ImageField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  const [uploading, setUploading] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);

  // Detect YouTube reference (yt:VIDEO_ID)
  const ytMatch = value?.match(/^yt:([a-zA-Z0-9_-]{11})$/);
  const isYoutube = !!ytMatch;
  const youtubeId = ytMatch ? ytMatch[1] : null;
  const isVideoPath = value?.startsWith('/videos/');
  const isMedia = isYoutube || isVideoPath;

  const previewUrl = value
    ? (value.startsWith('http') ? value : isYoutube ? '' : `${SITE_URL}/${value.replace(/^\//, '')}`)
    : '';

  return (
    <div>
      <label className="text-xs text-gray-400 block mb-1">{label}</label>
      <div className="flex gap-2">
        <input type="text" value={value} onChange={e => onChange(e.target.value)}
          placeholder={isYoutube ? 'yt:VIDEO_ID' : '/images/name.webp'}
          className="flex-1 bg-gray-700 rounded px-3 py-2 text-sm" />
        <button onClick={() => setPickerOpen(true)} className="px-3 py-2 bg-purple-600 hover:bg-purple-500 rounded text-sm cursor-pointer shrink-0" title="Seleccionar de biblioteca">📷</button>
        <label className="px-3 py-2 bg-blue-600 hover:bg-blue-500 rounded text-sm cursor-pointer shrink-0">
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              setUploading(true);
              try {
                const formData = new FormData();
                formData.append('file', file);
                formData.append('category', 'generic');
                const res = await fetch(`${API_BASE}/api/media`, {
                  method: 'POST',
                  headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` },
                  body: formData
                });
                const data = await res.json();
                if (data.ok) onChange(`/${data.data.key}`);
              } catch (err: any) { console.error('Upload failed:', err); }
              setUploading(false);
            }}
          />
          {uploading ? '...' : '📤'}
        </label>
      </div>
      {/* Preview */}
      {value && (
        <div className="mt-2 relative">
          {isYoutube ? (
            <LiteYouTube videoId={youtubeId!} className="rounded border border-gray-600" />
          ) : isVideoPath ? (
            <video src={previewUrl} controls className="h-24 w-full object-cover rounded border border-gray-600"
              preload="metadata" />
          ) : previewUrl ? (
            <img src={previewUrl} alt={label} className="h-24 w-full object-cover rounded border border-gray-600" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          ) : null}
          <span className={`absolute bottom-1 right-1 text-[10px] bg-black/60 px-1.5 py-0.5 rounded ${isYoutube ? 'text-red-400' : 'text-gray-300'}`}>
            {isYoutube ? `🎬 YT: ${youtubeId}` : value}
          </span>
        </div>
      )}
      {pickerOpen && (
        <MediaPicker
          mode="picker"
          currentImage={value}
          onSelect={(path: string) => { onChange(path); setPickerOpen(false); }}
          onClose={() => setPickerOpen(false)}
        />
      )}
    </div>
  );
}

const TYPE_LABELS: Record<string, string> = {
  services: 'service',
  locations: 'location',
  sectors: 'sector',
  combos: 'combo',
  pages: 'static_page',
};

const SERVICE_SLUGS = ['guardias-de-seguridad', 'cctv-videovigilancia', 'control-de-accesos', 'escoltas-privados', 'monitoreo-24-7', 'seguridad-eventos', 'seguridad-industrial', 'auditoria-seguridad', 'guard-pod'];
const LOCATION_SLUGS = ['las-condes', 'vitacura', 'santiago-centro', 'huechuraba', 'la-reina', 'lo-barnechea', 'pudahuel', 'quilicura', 'renca', 'la-pintana', 'lampa', 'san-felipe', 'los-andes', 'conchali'];
const SECTOR_SLUGS = ['comercial', 'industrial', 'residencial', 'salud', 'educacion', 'eventos', 'construccion', 'automotriz', 'hoteleria'];

const STATIC_SECTIONS: Record<string, string[]> = {
  'nosotros': ['stats','timeline','values','differentiators','certifications','staff','cta'],
  'guard-pod': ['features','problems','faqs','stats','hero_ctas','intro','cta'],
  'ajax-systems': ['features','problems','faqs','stats','hero_ctas','intro','cta'],
  'contacto': ['hero','contact_info','cta'],
  'cotizacion': ['hero','trust_badges','cta'],
  'privacidad': ['body_content'],
  'terminos': ['body_content'],
  'hub-servicios': ['hero','cta'],
  'hub-sectores': ['hero','cta'],
  'hub-ubicaciones': ['hero','cta'],
  'gracias': ['hero'],
};

export function CMSPage() {
  const [contentType, setContentType] = useState<'pages' | 'services' | 'locations' | 'sectors' | 'combos'>('services');
  const [items, setItems] = useState<ContentItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<ContentItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<ContentItem | null>(null);
  const [content, setContent] = useState<CMSContent | null>(null);
  const [seoScore, setSeoScore] = useState<{ score: number; warnings: string[] }>({ score: 0, warnings: [] });
  const [loading, setLoading] = useState(true);
  const [loadingContent, setLoadingContent] = useState(false);
  const [saving, setSaving] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [noContent, setNoContent] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [comboFilter, setComboFilter] = useState('');
  const [homeLoaded, setHomeLoaded] = useState(false);

  useEffect(() => {
    if (contentType === 'pages') {
      // Pages don't need list fetch — items are hardcoded
      setLoading(false);
      return;
    }
    loadContentList();
  }, [contentType]);

  useEffect(() => {
    if (contentType === 'combos' && comboFilter) {
      const filtered = items.filter(item =>
        item.name.toLowerCase().includes(comboFilter.toLowerCase())
      );
      setFilteredItems(filtered);
    } else {
      setFilteredItems(items);
    }
  }, [comboFilter, items, contentType]);

  // Listen for section generation reload events
  useEffect(() => {
    const handler = (e: any) => {
      const reloadSlug = e.detail;
      if (reloadSlug && selectedItem?.slug === reloadSlug) {
        loadContent(selectedItem);
      }
    };
    window.addEventListener('gm:reload-static-content', handler);
    return () => window.removeEventListener('gm:reload-static-content', handler);
  }, [selectedItem]);

  const formatName = (slug: string) => slug.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

  const loadContentList = async () => {
    setLoading(true);
    setSelectedItem(null);
    setContent(null);

    const type = TYPE_LABELS[contentType];

    try {
      const res = await fetch(`${API_BASE}/api/cms/list?type=${type}`);
      const data = await res.json();
      if (data.ok && data.items) {
        const list: ContentItem[] = data.items.map((item: any) => ({
          slug: item.slug,
          type: type === 'combo' ? 'combo' : type,
          name: item.name || formatName(item.slug),
          score: 0,
          published: false
        }));
        setItems(list);
        setFilteredItems(list);
      }
    } catch {
      setItems([]);
      setFilteredItems([]);
    }
    setLoading(false);
  };

  const loadHomepage = async () => {
    setLoading(true);
    setSelectedItem({ slug: 'home', type: 'home', name: 'Homepage', score: 0, published: false });
    setLoadingContent(true);
    setMessage(null);

    try {
      const res = await fetch(`${API_BASE}/api/cms/homepage`);
      const data = await res.json();
      if (data.ok && data.content) {
        setContent(data.content);
        setSeoScore(calcBackendScore(data.content));
      } else {
        setMessage({ type: 'error', text: data.error || 'Error cargando homepage' });
        setContent(null);
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
      setContent(null);
    }
    setLoadingContent(false);
    setLoading(false);
    setHomeLoaded(true);
  };

  const saveHomepage = async () => {
    if (!content) return;
    setSaving(true);
    setMessage(null);

    try {
      const result = await fetch(`${API_BASE}/api/cms/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}`
        },
        body: JSON.stringify({ path: 'homepage.json', content })
      });

      const data = await result.json();
      if (data.ok) {
        setMessage({ type: 'success', text: 'Homepage guardado correctamente' });
      } else {
        setMessage({ type: 'error', text: data.error || 'Error al guardar' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    }
    setSaving(false);
  };

  const loadContent = async (item: ContentItem) => {
    setSelectedItem(item);
    setLoadingContent(true);
    setMessage(null);
    setNoContent(false);

    try {
      const type = TYPE_LABELS[contentType];
      let url = `${API_BASE}/api/cms/content?type=${type}&slug=${item.slug}`;
      if (type === 'combo') {
        const [service, location] = item.slug.split('/');
        url = `${API_BASE}/api/cms/content?type=combo&slug=${service}&location=${location}`;
      }

      const res = await fetch(url);
      const data = await res.json();

      if (data.ok) {
        const normalized = normalizeContent(data.content);
        setContent(normalized);
        setSeoScore(calcBackendScore(normalized));
        setNoContent(false);
      } else if (data.error === 'Content not found') {
        setContent(null);
        setNoContent(true);
      } else {
        setMessage({ type: 'error', text: data.error || 'Error loading content' });
        setContent(null);
        setNoContent(false);
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
      setContent(null);
      setNoContent(false);
    }
    setLoadingContent(false);
  };

  const loadStaticContent = async (slug: string) => {
    setLoadingContent(true);
    setMessage(null);

    try {
      const res = await fetch(`${API_BASE}/api/cms/content?type=static_page&slug=${slug}`);
      const data = await res.json();

      // Also fetch media assignments for this static page
      let heroAssignment: string | null = null;
      try {
        const mediaRes = await fetch(`${API_BASE}/api/media?entity_type=static_page&entity_slug=${slug}&usage=hero&limit=1`, {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` }
        });
        const mediaData = await mediaRes.json();
        if (mediaData.ok && mediaData.data?.length > 0) {
          const m = mediaData.data[0];
          heroAssignment = m.youtube_id ? `yt:${m.youtube_id}` : `/${m.key}`;
        }
      } catch { /* ignore */ }

      if (data.ok && data.content) {
        // Normalize to editor format
        const c = data.content;
        const heroImage = c.content?.hero?.image || heroAssignment || '';
        const normalized = {
          seo: c.seo || { title: c.meta_title || '', description: c.meta_description || '' },
          content: { ...c.content, hero: { ...c.content.hero, image: heroImage } },
          meta: c.meta || { author: 'GuardMan Chile', quality_score: 0, published: false },
          version: c.version || 1,
        };
        setContent(normalized);
        setSeoScore(calcBackendScore(normalized));
        setNoContent(false);
      } else {
        // Create default content for this page
        const names: Record<string,string> = {
          'nosotros': 'Nosotros', 'guard-pod': 'Guard Pod', 'ajax-systems': 'Ajax Systems',
          'contacto': 'Contacto', 'cotizacion': 'Cotización', 'privacidad': 'Privacidad', 'terminos': 'Términos',
          'hub-servicios': 'Servicios', 'hub-sectores': 'Sectores', 'hub-ubicaciones': 'Ubicaciones',
          'gracias': 'Gracias'
        };
        setContent({
          seo: { title: '', description: '' },
          content: { hero: { headline: '', subheadline: '', image: heroAssignment || '' } },
          meta: { author: 'GuardMan Chile', quality_score: 0, published: false },
          version: 0,
        });
        setNoContent(true);
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
      setContent(null);
    }
    setLoadingContent(false);
  };

  const saveContent = async () => {
    if (!content || !selectedItem) return;
    setSaving(true);
    setMessage(null);

    try {
      // Static pages: exact same format as services/sectors
      if (contentType === 'pages') {
        const result = await fetch(`${API_BASE}/api/cms/save`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}`
          },
          body: JSON.stringify({
            path: `static/${selectedItem.slug}.json`,
            content
          })
        });

        const data = await result.json();
        if (data.ok) {
          setMessage({ type: 'success', text: '✓ Página guardada' });
          syncHeroToMedia(content, selectedItem.slug);
        } else {
          setMessage({ type: 'error', text: data.error || 'Error al guardar' });
        }
        setSaving(false);
        return;
      }

      const type = TYPE_LABELS[contentType];
      let path = '';
      if (type === 'service') path = `services/${selectedItem.slug}.json`;
      else if (type === 'location') path = `locations/${selectedItem.slug}.json`;
      else if (type === 'sector') path = `sectors/${selectedItem.slug}.json`;
      else if (type === 'combo') {
        const [service, location] = selectedItem.slug.split('/');
        path = `combos/${service}/${location}.json`;
      }

      const result = await fetch(`${API_BASE}/api/cms/save`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}`
        },
        body: JSON.stringify({ path, content })
      });

      const data = await result.json();
      if (data.ok) {
        setMessage({ type: 'success', text: '✓ Contenido guardado' });
      } else {
        setMessage({ type: 'error', text: data.error || 'Error al guardar' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    }
    setSaving(false);
  };

  const regenerateContent = async () => {
    if (!content || !selectedItem) return;
    setRegenerating(true);
    setMessage(null);

    try {
      // Determine type for API
      let apiType = TYPE_LABELS[contentType];
      if (contentType === 'pages') {
        apiType = 'static_page';
      }
      if (selectedItem.type === 'home') {
        apiType = 'homepage';
      }

      const result = await fetch(`${API_BASE}/api/cms/regenerate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}`
        },
        body: JSON.stringify({
          type: apiType,
          slug: selectedItem.slug,
          content
        })
      });

      const data = await result.json();
      if (data.ok && data.improved) {
        const improved = data.improved;
        const newSeo = {
          title: improved.meta?.title || content.seo?.title || '',
          description: improved.meta?.description || content.seo?.description || '',
          canonical: content.seo?.canonical || ''
        };
        // Safe merge: only replace sections the AI generated, preserving everything else
        const originalContent = content.content || {};
        const mergedContent = { ...originalContent };

        // Keys the AI is expected to generate (replace fully)
        const aiGeneratedKeys = ['features', 'issues', 'faqs', 'stats', 'problems', 'whyUs', 'values', 'differentiators', 'certifications', 'timeline', 'trust_badges', 'body_content'];
        // Keys that need shallow merge (objects where we want to preserve user-set sub-fields)
        const aiMergeKeys = ['hero', 'intro', 'cta', 'nosotros', 'guardpod', 'ajax', 'servicios', 'sectores', 'ubicaciones', 'clientes', 'cta_final'];

        for (const key of Object.keys(improved)) {
          if (key === 'meta') continue;
          const impVal = improved[key];
          const origVal = originalContent[key];

          if (aiGeneratedKeys.includes(key)) {
            // Replace arrays/complex sections entirely with AI output
            mergedContent[key] = impVal;
          } else if (aiMergeKeys.includes(key) && typeof impVal === 'object' && !Array.isArray(impVal) && impVal !== null) {
            // Shallow merge: AI fields win, but original fields the AI didn't send are kept
            mergedContent[key] = { ...(origVal || {}), ...impVal };
          } else {
            mergedContent[key] = impVal;
          }
        }

        // Unconditionally preserve critical media / user-configured fields
        if (originalContent.hero?.image) {
          mergedContent.hero = { ...(mergedContent.hero || {}), image: originalContent.hero.image };
        }
        if (originalContent.hero?.badge) {
          mergedContent.hero = { ...(mergedContent.hero || {}), badge: originalContent.hero.badge };
        }
        if (originalContent.hero?.cta1_text) {
          mergedContent.hero = { ...(mergedContent.hero || {}), cta1_text: originalContent.hero.cta1_text, cta1_href: originalContent.hero.cta1_href };
        }
        if (originalContent.hero?.cta2_text) {
          mergedContent.hero = { ...(mergedContent.hero || {}), cta2_text: originalContent.hero.cta2_text, cta2_href: originalContent.hero.cta2_href };
        }
        if (originalContent.intro?.image) {
          mergedContent.intro = { ...(mergedContent.intro || {}), image: originalContent.intro.image };
        }
        if (originalContent.nosotros?.image) {
          mergedContent.nosotros = { ...(mergedContent.nosotros || {}), image: originalContent.nosotros.image };
        }
        if (originalContent.guardpod?.image) {
          mergedContent.guardpod = { ...(mergedContent.guardpod || {}), image: originalContent.guardpod.image };
        }
        if (originalContent.ajax?.image) {
          mergedContent.ajax = { ...(mergedContent.ajax || {}), image: originalContent.ajax.image };
        }
        if (originalContent.clientes?.items?.length) {
          mergedContent.clientes = { ...(mergedContent.clientes || {}), items: originalContent.clientes.items };
        }
        const updatedContent = {
          ...content,
          seo: newSeo,
          content: mergedContent
        };
        setContent(updatedContent);
        setSeoScore(calcBackendScore(updatedContent));
        setMessage({ type: 'success', text: 'Contenido mejorado con IA. Guarda los cambios.' });
      } else {
        setMessage({ type: 'error', text: data.error || 'Error al regenerar' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    }
    setRegenerating(false);
  };

  const generateContent = async () => {
    if (!selectedItem) return;
    setGenerating(true);
    setMessage(null);
    try {
      const type = TYPE_LABELS[contentType];
      const result = await fetch(`${API_BASE}/api/cms/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}`
        },
        body: JSON.stringify({ type, slug: selectedItem.slug })
      });
      const data = await result.json();
      if (data.ok) {
        setMessage({ type: 'success', text: 'Contenido generado. Cargando...' });
        setNoContent(false);
        loadContent(selectedItem);
      } else {
        setMessage({ type: 'error', text: data.error || 'Error al generar' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    }
    setGenerating(false);
  };

  // Normalize API content to ensure all sections exist
  const normalizeContent = (c: any): CMSContent => {
    const cont = c.content || {};
    return {
      slug: c.slug || '',
      type: c.type || '',
      version: c.version || 0,
      last_modified: c.last_modified || '',
      seo: c.seo || { title: '', description: '', canonical: '' },
      content: {
        hero: cont.hero || {},
        intro: cont.intro || {},
        features: cont.features || undefined,
        issues: cont.issues || undefined,
        faqs: cont.faqs || undefined,
        cta: cont.cta || undefined,
        stats: cont.stats || undefined,
        staff: cont.staff || undefined,
        ...cont,
      },
      related_content: c.related_content || null,
      meta: c.meta || { author: '', quality_score: 0, published: false },
    };
  };

  const updateSEO = (field: string, value: string) => {
    if (!content) return;
    setContent({ ...content, seo: { ...(content.seo || {}), [field]: value } });
  };

  const updateHomeSection = (section: string, field: string, value: string) => {
    if (!content) return;
    setContent({
      ...content,
      content: { ...content.content, [section]: { ...content.content[section], [field]: value } }
    });
  };

  const updateHomeNested = (section: string, nested: string, field: string, value: string) => {
    if (!content) return;
    setContent({
      ...content,
      content: {
        ...content.content,
        [section]: {
          ...content.content[section],
          [nested]: { ...(content.content[section][nested] || {}), [field]: value }
        }
      }
    });
  };

  const updateHomeFeature = (section: string, idx: number, field: string, value: string) => {
    if (!content) return;
    const features = [...(content.content[section]?.features || [])];
    features[idx] = { ...features[idx], [field]: value };
    setContent({
      ...content,
      content: { ...content.content, [section]: { ...content.content[section], features } }
    });
  };

  const addHomeFeature = (section: string) => {
    if (!content) return;
    const features = [...(content.content[section]?.features || []), { title: '', description: '' }];
    setContent({
      ...content,
      content: { ...content.content, [section]: { ...content.content[section], features } }
    });
  };

  const removeHomeFeature = (section: string, idx: number) => {
    if (!content) return;
    const features = (content.content[section]?.features || []).filter((_: any, i: number) => i !== idx);
    setContent({
      ...content,
      content: { ...content.content, [section]: { ...content.content[section], features } }
    });
  };

  const updateHero = (field: string, value: string) => {
    if (!content) return;
    setContent({
      ...content,
      content: { ...content.content, hero: { ...(content.content?.hero || {}), [field]: value } }
    });
  };

  const updateIntro = (field: string, value: string) => {
    if (!content) return;
    setContent({
      ...content,
      content: { ...content.content, intro: { ...content.content.intro, [field]: value } }
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-900 text-white">
      {/* Left Panel: Content List */}
      <div className="w-80 border-r border-gray-700 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-gray-700">
          <h2 className="text-lg font-bold mb-3">CMS Editor</h2>
          <div className="flex gap-2 flex-wrap">
            {(['services', 'locations', 'sectors', 'combos'] as const).map(type => (
              <button key={type}
                onClick={() => { setContentType(type); setComboFilter(''); setHomeLoaded(false); setSelectedItem(null); setContent(null); }}
                className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                  contentType === type ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                {type === 'services' ? 'Servicios' : type === 'locations' ? 'Ubicaciones' : type === 'sectors' ? 'Sectores' : 'Combos'}
              </button>
            ))}
            <button
              onClick={() => { setContentType('pages'); setSelectedItem(null); setContent(null); }}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                contentType === 'pages' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              Páginas
            </button>
          </div>
          {contentType === 'combos' && (
            <div className="mt-2">
              <input
                type="text"
                value={comboFilter}
                onChange={(e) => setComboFilter(e.target.value)}
                placeholder="Buscar combo..."
                className="w-full bg-gray-700 rounded px-3 py-1.5 text-sm"
              />
            </div>
          )}
        </div>

        <div className="flex-1 overflow-auto p-2">
          {contentType === 'pages' ? (
            // Páginas: Homepage first, then static pages
            <>
              <div
                className={`p-3 rounded-lg mb-1 cursor-pointer transition-colors ${
                  selectedItem?.slug === 'homepage' ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-750'
                }`}
                onClick={() => {
                  setSelectedItem({ slug: 'homepage', type: 'home', name: 'Homepage', score: 0, published: false });
                  loadHomepage();
                }}
              >
                <div className="font-medium text-sm">🏠 Homepage</div>
                <div className="text-xs text-gray-400 mt-1">Página principal</div>
              </div>
              <div className="px-3 py-2 mt-2 mb-1 text-xs text-gray-500 uppercase tracking-wider border-t border-gray-700">Páginas estáticas</div>
              {['nosotros', 'guard-pod', 'ajax-systems', 'contacto', 'cotizacion', 'privacidad', 'terminos', 'hub-servicios', 'hub-sectores', 'hub-ubicaciones', 'gracias'].map(slug => {
                const names: Record<string,string> = {
                  'nosotros': 'Nosotros', 'guard-pod': 'Guard Pod', 'ajax-systems': 'Ajax Systems',
                  'contacto': 'Contacto', 'cotizacion': 'Cotización', 'privacidad': 'Privacidad', 'terminos': 'Términos',
                  'hub-servicios': 'Hub Servicios', 'hub-sectores': 'Hub Sectores', 'hub-ubicaciones': 'Hub Ubicaciones',
                  'gracias': 'Gracias'
                };
                return (
                  <div key={slug}
                    className={`p-3 rounded-lg mb-1 cursor-pointer transition-colors ${
                      selectedItem?.slug === slug ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-750'
                    }`}
                    onClick={() => {
                      const item: ContentItem = { slug, type: 'static', name: names[slug] || slug, score: 0, published: false };
                      setSelectedItem(item);
                      loadStaticContent(slug);
                    }}
                  >
                    <div className="font-medium text-sm">{names[slug] || slug}</div>
                    <div className="text-xs text-gray-400 mt-1">Página estática</div>
                  </div>
                );
              })}
            </>
          ) : loading ? (
            <div className="text-center text-gray-400 py-8">Cargando...</div>
          ) : (
            (contentType === 'combos' ? filteredItems : items).map(item => (
              <div key={item.slug}
                className={`p-3 rounded-lg mb-1 cursor-pointer transition-colors ${
                  selectedItem?.slug === item.slug ? 'bg-blue-600' : 'bg-gray-800 hover:bg-gray-750'
                }`}
                onClick={() => loadContent(item)}
              >
                <div className="font-medium text-sm">{item.name}</div>
                <div className="text-xs text-gray-400 mt-1">{item.type}</div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Center Panel: Editor */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedItem?.type === 'home' ? (
          homeLoaded && content ? (
            <>
              <div className="p-4 border-b border-gray-700 flex items-center justify-between shrink-0">
                <div>
                  <h3 className="font-bold">Homepage</h3>
                  <p className="text-xs text-gray-400">
                    {content.type} · v{content.version} · Editando secciones del home
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={saveHomepage}
                    disabled={saving}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 rounded-lg text-sm font-medium"
                  >
                    {saving ? 'Guardando...' : 'Guardar'}
                  </button>
                </div>
              </div>

              {message && (
                <div className={`mx-4 mt-4 p-3 rounded-lg text-sm shrink-0 ${
                  message.type === 'success' ? 'bg-green-600/20 text-green-400' : 'bg-red-600/20 text-red-400'
                }`}>
                  {message.text}
                </div>
              )}

              <div className="flex-1 flex overflow-hidden">
                <div className="flex-1 overflow-y-auto p-4">
                <div className="max-w-4xl space-y-6 pb-8">
                  {/* SEO */}
                  <HomepageSection title="SEO" color="blue">
                    <FieldInput label="Title" value={content.seo?.title || ''} onChange={v => setContent({...content, seo: {...content.seo, title: v}})} />
                    <FieldTextarea label="Description" value={content.seo?.description || ''} onChange={v => setContent({...content, seo: {...content.seo, description: v}})} rows={3} />
                  </HomepageSection>

                  {/* Hero */}
                  <HomepageSection title="Hero" color="green">
                    <FieldInput label="Headline" value={content.content?.hero?.headline || ''} onChange={v => updateHomeSection('hero', 'headline', v)} />
                    <FieldInput label="Subheadline" value={content.content?.hero?.subheadline || ''} onChange={v => updateHomeSection('hero', 'subheadline', v)} />
                    <ImageField label="Background Image" value={content.content?.hero?.background_image || ''} onChange={v => updateHomeSection('hero', 'background_image', v)} />
                    <FieldInput label="Phone" value={content.content?.hero?.phone || ''} onChange={v => updateHomeSection('hero', 'phone', v)} />
                    <ImageField label="Badge Image" value={content.content?.hero?.badge_image || ''} onChange={v => updateHomeSection('hero', 'badge_image', v)} />
                  </HomepageSection>

                  {/* Nosotros */}
                  <HomepageSection title="Nosotros" color="purple">
                    <FieldInput label="Badge" value={content.content?.nosotros?.badge || ''} onChange={v => updateHomeSection('nosotros', 'badge', v)} />
                    <FieldInput label="Title" value={content.content?.nosotros?.title || ''} onChange={v => updateHomeSection('nosotros', 'title', v)} />
                    <FieldTextarea label="Paragraph" value={content.content?.nosotros?.paragraph || ''} onChange={v => updateHomeSection('nosotros', 'paragraph', v)} rows={4} />
                    <ImageField label="Image" value={content.content?.nosotros?.image || ''} onChange={v => updateHomeSection('nosotros', 'image', v)} />
                    <FieldInput label="Image Badge" value={content.content?.nosotros?.image_badge || ''} onChange={v => updateHomeSection('nosotros', 'image_badge', v)} />
                    <FieldInput label="CTA Text" value={content.content?.nosotros?.cta_text || ''} onChange={v => updateHomeSection('nosotros', 'cta_text', v)} />
                    <FieldInput label="CTA Link" value={content.content?.nosotros?.cta_link || ''} onChange={v => updateHomeSection('nosotros', 'cta_link', v)} />
                    <FieldInput label="Stat Guards" value={content.content?.nosotros?.stats?.guards || ''} onChange={v => updateHomeNested('nosotros', 'stats', 'guards', v)} />
                    <FieldInput label="Stat Clients" value={content.content?.nosotros?.stats?.clients || ''} onChange={v => updateHomeNested('nosotros', 'stats', 'clients', v)} />
                    <FieldInput label="Stat Locations" value={content.content?.nosotros?.stats?.locations || ''} onChange={v => updateHomeNested('nosotros', 'stats', 'locations', v)} />
                    <FieldInput label="Stat Years" value={content.content?.nosotros?.stats?.years || ''} onChange={v => updateHomeNested('nosotros', 'stats', 'years', v)} />
                    {(content.content?.nosotros?.features || []).map((f: any, idx: number) => (
                      <div key={idx} className="bg-gray-700 rounded-lg p-3 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-400">Feature {idx + 1}</span>
                          <button onClick={() => removeHomeFeature('nosotros', idx)} className="text-red-400 text-xs">Eliminar</button>
                        </div>
                        <FieldInput label="Title" value={f.title || ''} onChange={v => updateHomeFeature('nosotros', idx, 'title', v)} />
                        <FieldInput label="Description" value={f.description || ''} onChange={v => updateHomeFeature('nosotros', idx, 'description', v)} />
                      </div>
                    ))}
                    <button onClick={() => addHomeFeature('nosotros')} className="text-sm text-blue-400 hover:text-blue-300">+ Agregar feature</button>
                  </HomepageSection>

                  {/* Servicios */}
                  <HomepageSection title="Servicios" color="yellow">
                    <FieldInput label="Title" value={content.content?.servicios?.title || ''} onChange={v => updateHomeSection('servicios', 'title', v)} />
                    <FieldTextarea label="Subtitle" value={content.content?.servicios?.subtitle || ''} onChange={v => updateHomeSection('servicios', 'subtitle', v)} rows={3} />
                    <FieldInput label="CTA Text" value={content.content?.servicios?.cta_text || ''} onChange={v => updateHomeSection('servicios', 'cta_text', v)} />
                    <FieldInput label="CTA Link" value={content.content?.servicios?.cta_link || ''} onChange={v => updateHomeSection('servicios', 'cta_link', v)} />
                  </HomepageSection>

                  {/* Guard Pod */}
                  <HomepageSection title="Guard Pod" color="cyan">
                    <FieldInput label="Badge" value={content.content?.guardpod?.badge || ''} onChange={v => updateHomeSection('guardpod', 'badge', v)} />
                    <FieldInput label="Title" value={content.content?.guardpod?.title || ''} onChange={v => updateHomeSection('guardpod', 'title', v)} />
                    <FieldTextarea label="Paragraph" value={content.content?.guardpod?.paragraph || ''} onChange={v => updateHomeSection('guardpod', 'paragraph', v)} rows={3} />
                    <ImageField label="Image" value={content.content?.guardpod?.image || ''} onChange={v => updateHomeSection('guardpod', 'image', v)} />
                    <FieldInput label="Image Badge" value={content.content?.guardpod?.image_badge || ''} onChange={v => updateHomeSection('guardpod', 'image_badge', v)} />
                    <FieldInput label="CTA Text" value={content.content?.guardpod?.cta_text || ''} onChange={v => updateHomeSection('guardpod', 'cta_text', v)} />
                    <FieldInput label="CTA Link" value={content.content?.guardpod?.cta_link || ''} onChange={v => updateHomeSection('guardpod', 'cta_link', v)} />
                    {(content.content?.guardpod?.features || []).map((f: any, idx: number) => (
                      <div key={idx} className="bg-gray-700 rounded-lg p-3 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-400">Feature {idx + 1}</span>
                          <button onClick={() => removeHomeFeature('guardpod', idx)} className="text-red-400 text-xs">Eliminar</button>
                        </div>
                        <FieldInput label="Title" value={f.title || ''} onChange={v => updateHomeFeature('guardpod', idx, 'title', v)} />
                        <FieldInput label="Description" value={f.description || ''} onChange={v => updateHomeFeature('guardpod', idx, 'description', v)} />
                      </div>
                    ))}
                    <button onClick={() => addHomeFeature('guardpod')} className="text-sm text-blue-400 hover:text-blue-300">+ Agregar feature</button>
                  </HomepageSection>

                  {/* Sectores */}
                  <HomepageSection title="Sectores" color="orange">
                    <FieldInput label="Title" value={content.content?.sectores?.title || ''} onChange={v => updateHomeSection('sectores', 'title', v)} />
                    <FieldTextarea label="Subtitle" value={content.content?.sectores?.subtitle || ''} onChange={v => updateHomeSection('sectores', 'subtitle', v)} rows={2} />
                    <FieldInput label="CTA Text" value={content.content?.sectores?.cta_text || ''} onChange={v => updateHomeSection('sectores', 'cta_text', v)} />
                    <FieldInput label="CTA Link" value={content.content?.sectores?.cta_link || ''} onChange={v => updateHomeSection('sectores', 'cta_link', v)} />
                  </HomepageSection>

                  {/* Ajax */}
                  <HomepageSection title="Ajax Systems" color="indigo">
                    <FieldInput label="Badge" value={content.content?.ajax?.badge || ''} onChange={v => updateHomeSection('ajax', 'badge', v)} />
                    <FieldInput label="Title" value={content.content?.ajax?.title || ''} onChange={v => updateHomeSection('ajax', 'title', v)} />
                    <FieldTextarea label="Paragraph" value={content.content?.ajax?.paragraph || ''} onChange={v => updateHomeSection('ajax', 'paragraph', v)} rows={4} />
                    <ImageField label="Image" value={content.content?.ajax?.image || ''} onChange={v => updateHomeSection('ajax', 'image', v)} />
                    <FieldInput label="Image Badge" value={content.content?.ajax?.image_badge || ''} onChange={v => updateHomeSection('ajax', 'image_badge', v)} />
                    <FieldInput label="CTA Text" value={content.content?.ajax?.cta_text || ''} onChange={v => updateHomeSection('ajax', 'cta_text', v)} />
                    <FieldInput label="CTA Link" value={content.content?.ajax?.cta_link || ''} onChange={v => updateHomeSection('ajax', 'cta_link', v)} />
                    {(content.content?.ajax?.features || []).map((f: any, idx: number) => (
                      <div key={idx} className="bg-gray-700 rounded-lg p-3 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-400">Feature {idx + 1}</span>
                          <button onClick={() => removeHomeFeature('ajax', idx)} className="text-red-400 text-xs">Eliminar</button>
                        </div>
                        <FieldInput label="Title" value={f.title || ''} onChange={v => updateHomeFeature('ajax', idx, 'title', v)} />
                        <FieldInput label="Description" value={f.description || ''} onChange={v => updateHomeFeature('ajax', idx, 'description', v)} />
                      </div>
                    ))}
                    <button onClick={() => addHomeFeature('ajax')} className="text-sm text-blue-400 hover:text-blue-300">+ Agregar feature</button>
                  </HomepageSection>

                  {/* Clientes */}
                  <HomepageSection title="Clientes" color="teal">
                    <FieldInput label="Title" value={content.content?.clientes?.title || ''} onChange={v => updateHomeSection('clientes', 'title', v)} />
                    <FieldInput label="Subtitle" value={content.content?.clientes?.subtitle || ''} onChange={v => updateHomeSection('clientes', 'subtitle', v)} />
                    <FieldInput label="CTA Text" value={content.content?.clientes?.cta_text || ''} onChange={v => updateHomeSection('clientes', 'cta_text', v)} />
                    <FieldInput label="CTA Link" value={content.content?.clientes?.cta_link || ''} onChange={v => updateHomeSection('clientes', 'cta_link', v)} />
                    {(content.content?.clientes?.items || []).map((c: any, idx: number) => (
                      <div key={idx} className="bg-gray-700 rounded-lg p-3 space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-400">Cliente {idx + 1}</span>
                          <button onClick={() => {
                            const items = content.content.clientes.items.filter((_: any, i: number) => i !== idx);
                            setContent({ ...content, content: { ...content.content, clientes: { ...content.content.clientes, items } } });
                          }} className="text-red-400 text-xs">Eliminar</button>
                        </div>
                        <FieldInput label="Nombre" value={c.name || ''} onChange={v => {
                          const items = [...content.content.clientes.items];
                          items[idx] = { ...items[idx], name: v };
                          setContent({ ...content, content: { ...content.content, clientes: { ...content.content.clientes, items } } });
                        }} />
                        <ImageField label="Logo" value={c.image || ''} onChange={v => {
                          const items = [...content.content.clientes.items];
                          items[idx] = { ...items[idx], image: v };
                          setContent({ ...content, content: { ...content.content, clientes: { ...content.content.clientes, items } } });
                        }} />
                        <FieldInput label="Iniciales (2 letras)" value={c.initials || ''} onChange={v => {
                          const items = [...content.content.clientes.items];
                          items[idx] = { ...items[idx], initials: v.substring(0, 2).toUpperCase() };
                          setContent({ ...content, content: { ...content.content, clientes: { ...content.content.clientes, items } } });
                        }} />
                        <div>
                          <label className="text-xs text-gray-400 block mb-1">Color (fallback sin logo)</label>
                          <input type="color" value={c.color || '#3B82F6'} onChange={e => {
                            const items = [...content.content.clientes.items];
                            items[idx] = { ...items[idx], color: e.target.value };
                            setContent({ ...content, content: { ...content.content, clientes: { ...content.content.clientes, items } } });
                          }} className="w-full h-8 bg-gray-600 rounded cursor-pointer" />
                        </div>
                      </div>
                    ))}
                    <button onClick={() => {
                      const items = [...(content.content?.clientes?.items || []), { name: '', initials: '', color: '#3B82F6' }];
                      setContent({ ...content, content: { ...content.content, clientes: { ...content.content.clientes, items } } });
                    }} className="text-sm text-blue-400 hover:text-blue-300">+ Agregar cliente</button>
                  </HomepageSection>

                  {/* Ubicaciones */}
                  <HomepageSection title="Ubicaciones" color="emerald">
                    <FieldInput label="Badge" value={content.content?.ubicaciones?.badge || ''} onChange={v => updateHomeSection('ubicaciones', 'badge', v)} />
                    <FieldInput label="Title" value={content.content?.ubicaciones?.title || ''} onChange={v => updateHomeSection('ubicaciones', 'title', v)} />
                    <FieldInput label="Subtitle" value={content.content?.ubicaciones?.subtitle || ''} onChange={v => updateHomeSection('ubicaciones', 'subtitle', v)} />
                    <FieldInput label="CTA Text" value={content.content?.ubicaciones?.cta_text || ''} onChange={v => updateHomeSection('ubicaciones', 'cta_text', v)} />
                    <FieldInput label="CTA Link" value={content.content?.ubicaciones?.cta_link || ''} onChange={v => updateHomeSection('ubicaciones', 'cta_link', v)} />
                  </HomepageSection>

                  {/* CTA Final */}
                  <HomepageSection title="CTA Final" color="pink">
                    <FieldInput label="Badge" value={content.content?.cta_final?.badge || ''} onChange={v => updateHomeSection('cta_final', 'badge', v)} />
                    <FieldInput label="Title" value={content.content?.cta_final?.title || ''} onChange={v => updateHomeSection('cta_final', 'title', v)} />
                    <FieldTextarea label="Subtitle" value={content.content?.cta_final?.subtitle || ''} onChange={v => updateHomeSection('cta_final', 'subtitle', v)} rows={3} />
                    <FieldInput label="CTA 1 Text" value={content.content?.cta_final?.cta1_text || ''} onChange={v => updateHomeSection('cta_final', 'cta1_text', v)} />
                    <FieldInput label="CTA 1 Link" value={content.content?.cta_final?.cta1_link || ''} onChange={v => updateHomeSection('cta_final', 'cta1_link', v)} />
                    <FieldInput label="CTA 2 Text" value={content.content?.cta_final?.cta2_text || ''} onChange={v => updateHomeSection('cta_final', 'cta2_text', v)} />
                    <FieldInput label="CTA 2 Link" value={content.content?.cta_final?.cta2_link || ''} onChange={v => updateHomeSection('cta_final', 'cta2_link', v)} />
                    <ImageField label="Badge Image" value={content.content?.cta_final?.badge_image || ''} onChange={v => updateHomeSection('cta_final', 'badge_image', v)} />
                  </HomepageSection>
                </div>
              </div>
              {/* Right Panel: SEO sidebar */}
              <div className="w-80 border-l border-gray-700 overflow-y-auto shrink-0">
                {content && (
                  <SEOPanel
                    content={content}
                    onRegenerate={regenerateContent}
                    regenerating={regenerating}
                    backendScore={seoScore.score}
                    scoreWarnings={seoScore.warnings}
                  />
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-400">
            <div className="text-center">
              <div className="text-4xl mb-4">Cargando homepage...</div>
            </div>
          </div>
        )
      ) : (contentType === 'pages' && selectedItem?.slug !== 'homepage' && content) ? (
        <div className="flex flex-1 overflow-hidden">
          <StaticPageEditor content={content} setContent={setContent} saveContent={saveContent} saving={saving} selectedItem={selectedItem} message={message} />
          <div className="w-80 border-l border-gray-700 overflow-y-auto shrink-0">
            <SEOPanel
              content={content}
              onRegenerate={regenerateContent}
              regenerating={regenerating}
              backendScore={seoScore.score}
              scoreWarnings={seoScore.warnings}
            />
          </div>
        </div>
      ) : (contentType === 'pages' && selectedItem?.slug !== 'homepage') ? (
        <div className="flex-1 flex items-center justify-center text-gray-400"><div className="text-center"><div className="text-4xl mb-4">Cargando...</div></div></div>
      ) : selectedItem ? (
          <>
            <div className="p-4 border-b border-gray-700 flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold">{selectedItem.name}</h3>
                <p className="text-xs text-gray-400">
                  {content ? `${content.type||selectedItem.type} · v${content.version||'?'} · Score: ${content.meta?.quality_score||0}` : 'Cargando...'}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={saveContent}
                  disabled={saving || !content}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 rounded-lg text-sm font-medium"
                >
                  {saving ? 'Guardando...' : '💾 Guardar'}
                </button>
              </div>
            </div>

            {message && (
              <div className={`mx-4 mt-4 p-3 rounded-lg text-sm shrink-0 ${
                message.type === 'success' ? 'bg-green-600/20 text-green-400' : 'bg-red-600/20 text-red-400'
              }`}>
                {message.text}
              </div>
            )}

            <div className="flex-1 flex overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4">
                {loadingContent ? (
                  <div className="text-center text-gray-400 py-8">Cargando contenido...</div>
                ) : content ? (
                  <div className="max-w-4xl space-y-6 pb-8">
                    {/* SEO Section */}
                    <div className="bg-gray-800 rounded-xl p-4">
                      <h4 className="font-semibold mb-3 text-blue-400">SEO</h4>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-400 block mb-1">Title</label>
                          <input
                            type="text"
                            value={content.seo?.title || ''}
                            onChange={e => updateSEO('title', e.target.value)}
                            className="w-full bg-gray-700 rounded px-3 py-2 text-sm"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-400 block mb-1">Description</label>
                          <textarea
                            value={content.seo?.description || ''}
                            onChange={e => updateSEO('description', e.target.value)}
                            rows={3}
                            className="w-full bg-gray-700 rounded px-3 py-2 text-sm"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-400 block mb-1">Canonical</label>
                          <input
                            type="text"
                            value={content.seo?.canonical || ''}
                            onChange={e => updateSEO('canonical', e.target.value)}
                            className="w-full bg-gray-700 rounded px-3 py-2 text-sm"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Hero Section */}
                    <div className="bg-gray-800 rounded-xl p-4">
                      <h4 className="font-semibold mb-3 text-green-400">Hero</h4>
                      <div className="space-y-3">
                        <FieldInput label="Heading" value={content.content.hero?.heading || ''} onChange={v => updateHero('heading', v)} />
                        <FieldTextarea label="Subheading" value={content.content.hero?.subheading || ''} onChange={v => updateHero('subheading', v)} rows={2} />
                        <ImageField label="Imagen Hero" value={content.content.hero?.image || ''} onChange={v => updateHero('image', v)} />
                      </div>
                    </div>

                    {/* Intro Section */}
                    <div className="bg-gray-800 rounded-xl p-4">
                      <h4 className="font-semibold mb-3 text-purple-400">Intro</h4>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-400 block mb-1">Heading</label>
                          <input
                            type="text"
                            value={content.content.intro?.heading || content.content.intro?.title || ''}
                            onChange={e => setContent({ ...content, content: { ...content.content, intro: { ...content.content.intro, heading: e.target.value } } })}
                            className="w-full bg-gray-700 rounded px-3 py-2 text-sm"
                          />
                        </div>
                        {(content.content.intro?.paragraphs || []).map((p: string, idx: number) => (
                          <div key={idx}>
                            <div className="flex justify-between items-center mb-1">
                              <label className="text-xs text-gray-400">Párrafo {idx + 1}</label>
                              <button onClick={() => {
                                const paragraphs = content.content.intro.paragraphs.filter((_: any, i: number) => i !== idx);
                                setContent({ ...content, content: { ...content.content, intro: { ...content.content.intro, paragraphs } } });
                              }} className="text-red-400 text-xs">Eliminar</button>
                            </div>
                            <textarea
                              value={p}
                              onChange={e => {
                                const paragraphs = [...content.content.intro.paragraphs];
                                paragraphs[idx] = e.target.value;
                                setContent({ ...content, content: { ...content.content, intro: { ...content.content.intro, paragraphs } } });
                              }}
                              rows={4}
                              className="w-full bg-gray-700 rounded px-3 py-2 text-sm"
                            />
                          </div>
                        ))}
                        {content.content.intro?.content && (
                          <div>
                            <label className="text-xs text-gray-400 block mb-1">Content (texto plano)</label>
                            <textarea
                              value={content.content.intro.content}
                              onChange={e => setContent({ ...content, content: { ...content.content, intro: { ...content.content.intro, content: e.target.value } } })}
                              rows={6}
                              className="w-full bg-gray-700 rounded px-3 py-2 text-sm"
                            />
                          </div>
                        )}
                        <button onClick={() => {
                          const paragraphs = [...(content.content.intro?.paragraphs || []), ''];
                          setContent({ ...content, content: { ...content.content, intro: { ...content.content.intro, paragraphs } } });
                        }} className="text-sm text-blue-400 hover:text-blue-300">+ Agregar párrafo</button>
                      </div>
                    </div>

                    {/* Features Section */}
                    {content.content.features && (
                      <div className="bg-gray-800 rounded-xl p-4">
                        <h4 className="font-semibold mb-3 text-yellow-400">Features</h4>
                        <div className="space-y-2">
                          {(content.content.features.items || []).map((item: string, idx: number) => (
                            <div key={idx} className="flex gap-2">
                              <input
                                type="text"
                                value={item}
                                onChange={e => {
                                  const items = [...content.content.features.items];
                                  items[idx] = e.target.value;
                                  setContent({
                                    ...content,
                                    content: { ...content.content, features: { ...content.content.features, items } }
                                  });
                                }}
                                className="flex-1 bg-gray-700 rounded px-3 py-2 text-sm"
                              />
                              <button
                                onClick={() => {
                                  const items = content.content.features.items.filter((_: any, i: number) => i !== idx);
                                  setContent({
                                    ...content,
                                    content: { ...content.content, features: { ...content.content.features, items } }
                                  });
                                }}
                                className="px-2 py-1 bg-red-600/20 text-red-400 rounded text-sm"
                              >
                                ✕
                              </button>
                            </div>
                          ))}
                          <button
                            onClick={() => {
                              const items = [...(content.content.features.items || []), ''];
                              setContent({
                                ...content,
                                content: { ...content.content, features: { ...content.content.features, items } }
                              });
                            }}
                            className="text-sm text-blue-400 hover:text-blue-300"
                          >
                            + Agregar feature
                          </button>
                        </div>
                      </div>
                    )}

                    {/* FAQ Section */}
                    {content.content.faqs && (
                      <div className="bg-gray-800 rounded-xl p-4">
                        <h4 className="font-semibold mb-3 text-cyan-400">Preguntas Frecuentes (FAQs)</h4>
                        <div className="space-y-4">
                          {(content.content.faqs.items || content.content.faqs || []).map((faq: { question: string; answer: string }, idx: number) => (
                            <div key={idx} className="bg-gray-700 rounded-lg p-3">
                              <div className="flex gap-2 mb-2">
                                <input
                                  type="text"
                                  value={faq.question}
                                  onChange={e => {
                                    const arr = content.content.faqs.items || content.content.faqs;
                                    const newFaq = [...arr];
                                    newFaq[idx] = { ...newFaq[idx], question: e.target.value };
                                    setContent({
                                      ...content,
                                      content: { ...content.content, faqs: Array.isArray(content.content.faqs) ? newFaq : { ...content.content.faqs, items: newFaq } }
                                    });
                                  }}
                                  placeholder="Pregunta"
                                  className="flex-1 bg-gray-600 rounded px-3 py-2 text-sm"
                                />
                                <button
                                  onClick={() => {
                                    const arr = content.content.faqs.items || content.content.faqs;
                                    const newFaq = arr.filter((_: any, i: number) => i !== idx);
                                    setContent({
                                      ...content,
                                      content: { ...content.content, faqs: Array.isArray(content.content.faqs) ? newFaq : { ...content.content.faqs, items: newFaq } }
                                    });
                                  }}
                                  className="px-2 py-1 bg-red-600/20 text-red-400 rounded text-sm"
                                >
                                  ✕
                                </button>
                              </div>
                              <textarea
                                value={faq.answer}
                                onChange={e => {
                                  const arr = content.content.faqs.items || content.content.faqs;
                                  const newFaq = [...arr];
                                  newFaq[idx] = { ...newFaq[idx], answer: e.target.value };
                                  setContent({
                                    ...content,
                                    content: { ...content.content, faqs: Array.isArray(content.content.faqs) ? newFaq : { ...content.content.faqs, items: newFaq } }
                                  });
                                }}
                                placeholder="Respuesta"
                                rows={2}
                                className="w-full bg-gray-600 rounded px-3 py-2 text-sm"
                              />
                            </div>
                          ))}
                          <button
                            onClick={() => {
                              const arr = content.content.faqs.items || content.content.faqs || [];
                              const newFaq = [...arr, { question: '', answer: '' }];
                              setContent({
                                ...content,
                                content: { ...content.content, faqs: Array.isArray(content.content.faqs) ? newFaq : { ...content.content.faqs, items: newFaq } }
                              });
                            }}
                            className="text-sm text-blue-400 hover:text-blue-300"
                          >
                            + Agregar pregunta
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Issues Section */}
                    {content.content.issues && (content.content.issues.items || content.content.issues).length > 0 && (
                      <div className="bg-gray-800 rounded-xl p-4">
                        <h4 className="font-semibold mb-3 text-red-400">Problemas que Resolvemos</h4>
                        <div className="space-y-2">
                          {(content.content.issues.items || content.content.issues || []).map((item: any, idx: number) => (
                            typeof item === 'string' ? (
                              <div key={idx} className="flex gap-2">
                                <input
                                  type="text"
                                  value={item}
                                  onChange={e => {
                                    const arr = content.content.issues.items || content.content.issues;
                                    const newItems = [...arr];
                                    newItems[idx] = e.target.value;
                                    setContent({
                                      ...content,
                                      content: { ...content.content, issues: Array.isArray(content.content.issues) ? newItems : { ...content.content.issues, items: newItems } }
                                    });
                                  }}
                                  className="flex-1 bg-gray-700 rounded px-3 py-2 text-sm"
                                />
                                <button
                                  onClick={() => {
                                    const arr = content.content.issues.items || content.content.issues;
                                    const newItems = arr.filter((_: any, i: number) => i !== idx);
                                    setContent({
                                      ...content,
                                      content: { ...content.content, issues: Array.isArray(content.content.issues) ? newItems : { ...content.content.issues, items: newItems } }
                                    });
                                  }}
                                  className="px-2 py-1 bg-red-600/20 text-red-400 rounded text-sm"
                                >✕</button>
                              </div>
                            ) : (
                              <div key={idx} className="bg-gray-700 rounded-lg p-3 space-y-2">
                                <div className="flex justify-between">
                                  <span className="text-xs text-gray-400">Issue {idx + 1}</span>
                                  <button onClick={() => {
                                    const arr = content.content.issues.items || content.content.issues;
                                    const newItems = arr.filter((_: any, i: number) => i !== idx);
                                    setContent({ ...content, content: { ...content.content, issues: Array.isArray(content.content.issues) ? newItems : { ...content.content.issues, items: newItems } } });
                                  }} className="text-red-400 text-xs">Eliminar</button>
                                </div>
                                <input type="text" value={item.title || ''} onChange={e => {
                                  const arr = content.content.issues.items || content.content.issues;
                                  const newItems = [...arr]; newItems[idx] = { ...newItems[idx], title: e.target.value };
                                  setContent({ ...content, content: { ...content.content, issues: Array.isArray(content.content.issues) ? newItems : { ...content.content.issues, items: newItems } } });
                                }} placeholder="Title" className="w-full bg-gray-600 rounded px-3 py-2 text-sm" />
                                <textarea value={item.description || ''} onChange={e => {
                                  const arr = content.content.issues.items || content.content.issues;
                                  const newItems = [...arr]; newItems[idx] = { ...newItems[idx], description: e.target.value };
                                  setContent({ ...content, content: { ...content.content, issues: Array.isArray(content.content.issues) ? newItems : { ...content.content.issues, items: newItems } } });
                                }} placeholder="Descripcion" rows={2} className="w-full bg-gray-600 rounded px-3 py-2 text-sm" />
                              </div>
                            )
                          ))}
                          <button onClick={() => {
                            const arr = content.content.issues.items || content.content.issues || [];
                            const newItems = [...arr, ''];
                            setContent({ ...content, content: { ...content.content, issues: Array.isArray(content.content.issues) ? newItems : { ...content.content.issues, items: newItems } } });
                          }} className="text-sm text-blue-400 hover:text-blue-300">+ Agregar issue</button>
                        </div>
                      </div>
                    )}

                    {/* Staff Section */}
                    <div className="bg-gray-800 rounded-xl p-4">
                      <h4 className="font-semibold mb-3 text-amber-400">Personal (Staff)</h4>
                      <div className="space-y-3">
                        <FieldInput label="Título" value={content.content.staff?.title || ''} onChange={v => setContent({ ...content, content: { ...content.content, staff: { ...content.content.staff, title: v } } })} />
                        <FieldTextarea label="Descripción" value={content.content.staff?.description || ''} onChange={v => setContent({ ...content, content: { ...content.content, staff: { ...content.content.staff, description: v } } })} rows={3} />
                        <ImageField label="Imagen del Personal" value={content.content.staff?.image || ''} onChange={v => setContent({ ...content, content: { ...content.content, staff: { ...content.content.staff, image: v } } })} />
                        {(content.content.staff?.traits || []).map((trait: string, idx: number) => (
                          <div key={idx} className="flex gap-2">
                            <input type="text" value={trait} onChange={e => {
                              const traits = [...content.content.staff.traits]; traits[idx] = e.target.value;
                              setContent({ ...content, content: { ...content.content, staff: { ...content.content.staff, traits } } });
                            }} className="flex-1 bg-gray-700 rounded px-3 py-2 text-sm" />
                            <button onClick={() => {
                              const traits = content.content.staff.traits.filter((_: any, i: number) => i !== idx);
                              setContent({ ...content, content: { ...content.content, staff: { ...content.content.staff, traits } } });
                            }} className="px-2 py-1 bg-red-600/20 text-red-400 rounded text-sm">✕</button>
                          </div>
                        ))}
                        <button onClick={() => {
                          const staff = content.content.staff || {};
                          const traits = [...(staff.traits || []), ''];
                          setContent({ ...content, content: { ...content.content, staff: { ...staff, traits } } });
                        }} className="text-sm text-blue-400 hover:text-blue-300">+ Agregar trait</button>
                        {!content.content.staff && (
                          <p className="text-xs text-gray-500">Sección vacía — se usará el personal global por defecto. Edita para personalizar.</p>
                        )}
                      </div>
                    </div>

                    {/* CTA */}
                    <div className="bg-gray-800 rounded-xl p-4">
                      <h4 className="font-semibold mb-3 text-pink-400">CTA Final</h4>
                      <div className="space-y-3">
                        <FieldInput label="Heading" value={content.content.cta?.heading || content.content.cta?.headline || ''} onChange={v => setContent({ ...content, content: { ...content.content, cta: { ...content.content.cta, heading: v } } })} />
                        <FieldTextarea label="Subheading" value={content.content.cta?.subheading || ''} onChange={v => setContent({ ...content, content: { ...content.content, cta: { ...content.content.cta, subheading: v } } })} rows={2} />
                        <FieldInput label="Texto Botón" value={content.content.cta?.button_text || content.content.cta?.button || ''} onChange={v => setContent({ ...content, content: { ...content.content, cta: { ...content.content.cta, button_text: v } } })} />
                        <FieldInput label="Link Botón" value={content.content.cta?.button_href || ''} onChange={v => setContent({ ...content, content: { ...content.content, cta: { ...content.content.cta, button_href: v } } })} />
                      </div>
                    </div>

                    {/* Sidebar CTA */}
                    <div className="bg-gray-800 rounded-xl p-4">
                      <h4 className="font-semibold mb-3 text-teal-400">Sidebar CTA</h4>
                      <div className="space-y-3">
                        <FieldInput label="Heading" value={content.content.sidebar?.cta_heading || ''} onChange={v => setContent({ ...content, content: { ...content.content, sidebar: { ...content.content.sidebar, cta_heading: v } } })} />
                      </div>
                    </div>
                  </div>
                ) : noContent ? (
                  <div className="text-center text-gray-400 py-12">
                    <div className="text-4xl mb-4">📭</div>
                    <p className="mb-2">Este contenido aun no existe</p>
                    <button
                      onClick={generateContent}
                      disabled={generating}
                      className="px-6 py-3 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 rounded-lg text-sm font-medium mt-4"
                    >
                      {generating ? 'Generando...' : 'Generar con IA'}
                    </button>
                  </div>
                ) : (
                  <div className="text-center text-gray-400 py-8">No se pudo cargar el contenido</div>
                )}
              </div>
              {/* Right Panel: SEO - Fixed sidebar */}
              <div className="w-80 border-l border-gray-700 overflow-y-auto shrink-0">
                {content && (
                  <SEOPanel
                    content={content}
                    onRegenerate={regenerateContent}
                    regenerating={regenerating}
                    backendScore={seoScore.score}
                    scoreWarnings={seoScore.warnings}
                  />
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-400">
            <div className="text-center">
              <div className="text-4xl mb-4">📝</div>
              <p>Selecciona un contenido para editar</p>
              <p className="text-sm mt-2">{items.length} items disponibles</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Helper: normalize {heading, items} or array to always be an array
const toArray = (v: any): any[] => {
  if (!v) return [];
  if (Array.isArray(v)) return v;
  if (v.items && Array.isArray(v.items)) return v.items;
  return [];
};

// Sync hero image from CMS editor to media_entities assignment
async function syncHeroToMedia(content: any, slug: string) {
  const heroImage = content?.content?.hero?.image;
  if (!heroImage) return;
  const token = localStorage.getItem('gm_token') || '';
  try {
    // Determine media key from heroImage value
    let mediaKey: string | null = null;
    const ytMatch = heroImage.match(/^yt:([a-zA-Z0-9_-]{11})$/);
    if (ytMatch) {
      // Look up by youtube_id
      const res = await fetch(`${API_BASE}/api/media?entity_type=static_page&entity_slug=${slug}&usage=hero&limit=50`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      // Unassign existing hero for this static page
      if (data.ok && data.data?.length) {
        for (const m of data.data) {
          await fetch(`${API_BASE}/api/media/${m.id}/unassign`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ entity_type: 'static_page', entity_slug: slug, usage: 'hero' })
          });
        }
      }
      // Find media by youtube_id and assign
      const ytRes = await fetch(`${API_BASE}/api/media?limit=500`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const ytData = await ytRes.json();
      if (ytData.ok && ytData.data) {
        const ytMedia = ytData.data.find((m: any) => m.youtube_id === ytMatch[1]);
        if (ytMedia) {
          await fetch(`${API_BASE}/api/media/${ytMedia.id}/assign`, {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ entity_type: 'static_page', entity_slug: slug, usage: 'hero' })
          });
        }
      }
    }
  } catch { /* sync is best-effort */ }
}

// Static Page Editor for non-homepage static pages
function StaticPageEditor({ content, setContent, saveContent, saving, selectedItem, message }: any) {
  const slug = selectedItem?.slug || '';
  const sections = STATIC_SECTIONS[slug] || [];
  const { generate, generateAll, isGenerating } = useSectionGenerator(slug);

  // Handle AI generation for a specific section
  const handleGenerateSection = async (sectionKey: string) => {
    const result = await generate(sectionKey);
    if (result) {
      // Reload the content to get the updated data
      // The backend already saved it, so we fetch fresh
      window.dispatchEvent(new CustomEvent('gm:reload-static-content', { detail: slug }));
    }
  };

  const handleGenerateAll = async () => {
    const genSections = sections.filter(s => ['stats','timeline','values','differentiators','certifications','staff','cta','faqs','features','problems','whyUs'].includes(s));
    await generateAll(genSections);
    window.dispatchEvent(new CustomEvent('gm:reload-static-content', { detail: slug }));
  };

  const SectionGenBtn = ({ section, label }: { section: string; label: string }) => {
    const busy = isGenerating(section);
    return (
      <button
        onClick={(e) => { e.preventDefault(); handleGenerateSection(section); }}
        disabled={busy}
        className="ml-2 px-2 py-0.5 text-[10px] rounded bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/20 disabled:opacity-50"
        title={`Generar ${label} con IA`}
      >
        {busy ? '⏳' : '🤖 Generar'}
      </button>
    );
  };

  // Normalize all section data to arrays
  const stats = toArray(content.content?.stats);
  const timeline = toArray(content.content?.timeline);
  const features = toArray(content.content?.features);
  const faqs = toArray(content.content?.faqs);
  // Helpers to update array sections
  const updateArr = (field: string, arr: any[]) => setContent({...content, content: {...content.content, [field]: arr}});
  const updateItem = (field: string, idx: number, changes: any) => {
    const arr = [...toArray(content.content?.[field])];
    arr[idx] = {...arr[idx], ...changes};
    updateArr(field, arr);
  };
  const removeItem = (field: string, idx: number) => {
    const arr = toArray(content.content?.[field]).filter((_: any, i: number) => i !== idx);
    updateArr(field, arr);
  };
  const addItem = (field: string, item: any) => {
    const arr = [...toArray(content.content?.[field]), item];
    updateArr(field, arr);
  };
  return <div className="flex-1 flex flex-col overflow-hidden">
    <div className="p-4 border-b border-gray-700 flex items-center justify-between shrink-0">
      <div>
        <h3 className="font-bold">{selectedItem?.name}</h3>
        <p className="text-xs text-gray-400">Editando página estática · {slug}</p>
      </div>
      <button onClick={saveContent} disabled={saving} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 rounded-lg text-sm font-medium">{saving ? 'Guardando...' : '💾 Guardar'}</button>
      <button onClick={handleGenerateAll} className="px-4 py-2 bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/20 text-purple-300 rounded-lg text-sm font-medium">🤖 Generar Todo</button>
    </div>
    {message && (
      <div className={`mx-4 mt-4 p-3 rounded-lg text-sm shrink-0 ${
        message.type === 'success' ? 'bg-green-600/20 text-green-400' : 'bg-red-600/20 text-red-400'
      }`}>
        {message.text}
      </div>
    )}
    <div className="flex-1 overflow-y-auto p-4"><div className="max-w-4xl space-y-6 pb-8">
      <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-blue-400">SEO</h4><div className="space-y-3">
        <div><label className="text-xs text-gray-400 block mb-1">Title</label><input type="text" value={content.seo?.title||''} onChange={e=>setContent({...content,seo:{...content.seo,title:e.target.value}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div>
        <div><label className="text-xs text-gray-400 block mb-1">Description</label><textarea value={content.seo?.description||''} onChange={e=>setContent({...content,seo:{...content.seo,description:e.target.value}})} rows={3} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div>
      </div></div>
      <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-green-400">Hero</h4><div className="space-y-3">
        <div><label className="text-xs text-gray-400 block mb-1">Badge</label><input type="text" value={content.content?.hero?.badge||''} onChange={e=>setContent({...content,content:{...content.content,hero:{...content.content.hero,badge:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div>
        <div><label className="text-xs text-gray-400 block mb-1">Headline</label><input type="text" value={content.content?.hero?.headline||''} onChange={e=>setContent({...content,content:{...content.content,hero:{...content.content.hero,headline:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div>
        <div><label className="text-xs text-gray-400 block mb-1">Subheadline</label><textarea value={content.content?.hero?.subheadline||''} onChange={e=>setContent({...content,content:{...content.content,hero:{...content.content.hero,subheadline:e.target.value}}})} rows={3} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div>
        <ImageField label="Imagen Hero" value={content.content?.hero?.image||''} onChange={v=>setContent({...content,content:{...content.content,hero:{...content.content.hero,image:v}}})} />
      </div></div>
      {sections.includes('stats') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-yellow-400">Stats <SectionGenBtn section="stats" label="Stats" /></h4>{stats.map((s:any,i:number)=><div key={i} className="flex gap-2 mb-2"><input value={s.value||''} onChange={e=>updateItem('stats',i,{value:e.target.value})} className="flex-1 bg-gray-700 rounded px-2 py-1 text-sm" placeholder="Valor"/><input value={s.label||''} onChange={e=>updateItem('stats',i,{label:e.target.value})} className="flex-[2] bg-gray-700 rounded px-2 py-1 text-sm" placeholder="Label"/><button onClick={()=>removeItem('stats',i)} className="text-red-400 text-xs">✕</button></div>)}<button onClick={()=>addItem('stats',{value:'',label:''})} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('timeline') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-purple-400">Timeline <SectionGenBtn section="timeline" label="Timeline" /></h4>{timeline.map((t:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Año</label><input value={t.year||''} onChange={e=>updateItem('timeline',i,{year:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Título</label><input value={t.title||''} onChange={e=>updateItem('timeline',i,{title:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Descripción</label><textarea value={t.description||''} onChange={e=>updateItem('timeline',i,{description:e.target.value})} rows={2} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('timeline',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('timeline',{year:'',title:'',description:''})} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('features') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-cyan-400">Features <SectionGenBtn section="features" label="Features" /></h4>{features.map((f:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Título</label><input value={f.title||''} onChange={e=>updateItem('features',i,{title:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Descripción</label><textarea value={f.description||''} onChange={e=>updateItem('features',i,{description:e.target.value})} rows={2} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('features',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('features',{title:'',description:''})} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('faqs') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-indigo-400">FAQ <SectionGenBtn section="faqs" label="FAQ" /></h4>{faqs.map((f:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Pregunta</label><input value={f.question||''} onChange={e=>updateItem('faqs',i,{question:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Respuesta</label><textarea value={f.answer||''} onChange={e=>updateItem('faqs',i,{answer:e.target.value})} rows={3} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('faqs',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('faqs',{question:'',answer:''})} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('values') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-emerald-400">Valores <SectionGenBtn section="values" label="Valores" /></h4>{toArray(content.content?.values).map((v:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Título</label><input value={v.title||''} onChange={e=>updateItem('values',i,{title:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Descripción</label><textarea value={v.description||''} onChange={e=>updateItem('values',i,{description:e.target.value})} rows={2} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('values',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('values',{title:'',description:''})} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('differentiators') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-violet-400">Diferenciadores <SectionGenBtn section="differentiators" label="Diferenciadores" /></h4>{toArray(content.content?.differentiators).map((d:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Título</label><input value={d.title||''} onChange={e=>updateItem('differentiators',i,{title:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Descripción</label><textarea value={d.description||''} onChange={e=>updateItem('differentiators',i,{description:e.target.value})} rows={2} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('differentiators',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('differentiators',{title:'',description:''})} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('certifications') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-amber-400">Certificaciones <SectionGenBtn section="certifications" label="Certificaciones" /></h4>{toArray(content.content?.certifications).map((c:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Título</label><input value={c.title||''} onChange={e=>updateItem('certifications',i,{title:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Descripción</label><textarea value={c.description||''} onChange={e=>updateItem('certifications',i,{description:e.target.value})} rows={2} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('certifications',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('certifications',{title:'',description:''})} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('staff') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-rose-400">Staff <SectionGenBtn section="staff" label="Staff" /></h4><div className="space-y-3"><ImageField label="Imagen" value={content.content?.staff?.image||''} onChange={v=>setContent({...content,content:{...content.content,staff:{...content.content.staff,image:v}}})} /><div><label className="text-xs text-gray-400 block mb-1">Traits</label>{(toArray(content.content?.staff?.traits)).map((t:any,i:number)=><div key={i} className="flex gap-2 mb-2"><input value={typeof t==='string'?t:t.text||''} onChange={e=>{const arr=[...toArray(content.content?.staff?.traits)];arr[i]=e.target.value;setContent({...content,content:{...content.content,staff:{...content.content.staff,traits:arr}}})}} className="flex-1 bg-gray-700 rounded px-2 py-1 text-sm" /><button onClick={()=>{const arr=toArray(content.content?.staff?.traits).filter((_:any,j:number)=>j!==i);setContent({...content,content:{...content.content,staff:{...content.content.staff,traits:arr}}})}} className="text-red-400 text-xs">✕</button></div>)}<button onClick={()=>{const arr=[...toArray(content.content?.staff?.traits),''];setContent({...content,content:{...content.content,staff:{...content.content.staff,traits:arr}}})}} className="text-sm text-blue-400">+ Agregar trait</button></div></div></div>}
      {sections.includes('problems') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-red-400">Problemas <SectionGenBtn section="problems" label="Problemas" /></h4>{toArray(content.content?.problems).map((p:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Texto</label><input value={typeof p==='string'?p:p.title||p.description||''} onChange={e=>updateItem('problems',i,{title:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('problems',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('problems','')} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('whyUs') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-red-400">¿Por qué elegirnos? <SectionGenBtn section="whyUs" label="WhyUs" /></h4>{toArray(content.content?.whyUs).map((w:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2 space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Texto</label><input value={typeof w==='string'?w:w.title||w.description||''} onChange={e=>updateItem('whyUs',i,{title:e.target.value})} className="w-full bg-gray-600 rounded px-2 py-1 text-sm" /></div><button onClick={()=>removeItem('whyUs',i)} className="text-red-400 text-xs">Eliminar</button></div>)}<button onClick={()=>addItem('whyUs','')} className="text-sm text-blue-400">+ Agregar</button></div>}
      {sections.includes('body_content') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-pink-400">Contenido HTML</h4><div><label className="text-xs text-gray-400 block mb-1">Body HTML</label><textarea value={content.content?.body_content||''} onChange={e=>setContent({...content,content:{...content.content,body_content:e.target.value}})} rows={15} className="w-full bg-gray-700 rounded px-3 py-2 text-sm font-mono" /></div></div>}
      {sections.includes('hero_ctas') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-orange-400">Hero CTAs</h4><div className="space-y-2"><div><label className="text-xs text-gray-400 block mb-1">Botón Primario Texto</label><input type="text" value={content.content?.hero?.cta1_text||'Cotizar'} onChange={e=>setContent({...content,content:{...content.content,hero:{...content.content.hero,cta1_text:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Botón Primario Link</label><input type="text" value={content.content?.hero?.cta1_href||'/cotizacion'} onChange={e=>setContent({...content,content:{...content.content,hero:{...content.content.hero,cta1_href:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Botón Secundario Texto</label><input type="text" value={content.content?.hero?.cta2_text||'Ver características'} onChange={e=>setContent({...content,content:{...content.content,hero:{...content.content.hero,cta2_text:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Botón Secundario Link</label><input type="text" value={content.content?.hero?.cta2_href||'#features'} onChange={e=>setContent({...content,content:{...content.content,hero:{...content.content.hero,cta2_href:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div></div></div>}
      {sections.includes('intro') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-lime-400">Intro (Split Layout)</h4><div className="space-y-3"><div><label className="text-xs text-gray-400 block mb-1">Label</label><input type="text" value={content.content?.intro?.label||''} onChange={e=>setContent({...content,content:{...content.content,intro:{...content.content.intro,label:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Título</label><input type="text" value={content.content?.intro?.title||''} onChange={e=>setContent({...content,content:{...content.content,intro:{...content.content.intro,title:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><ImageField label="Imagen (video o imagen)" value={content.content?.intro?.image||''} onChange={v=>setContent({...content,content:{...content.content,intro:{...content.content.intro,image:v}}})} />{(toArray(content.content?.intro?.paragraphs)).map((p:any,i:number)=><div key={i} className="bg-gray-700 rounded-lg p-3 mb-2"><div className="flex justify-between items-center mb-2"><label className="text-xs text-gray-400">Párrafo {i+1}</label><button onClick={()=>{const arr=toArray(content.content?.intro?.paragraphs).filter((_:any,j:number)=>j!==i);setContent({...content,content:{...content.content,intro:{...content.content.intro,paragraphs:arr}}})}} className="text-red-400 text-xs">Eliminar</button></div><textarea value={typeof p==='string'?p:p.text||''} onChange={e=>{const arr=[...toArray(content.content?.intro?.paragraphs)];arr[i]=typeof p==='string'?e.target.value:{...p,text:e.target.value};setContent({...content,content:{...content.content,intro:{...content.content.intro,paragraphs:arr}}})}} rows={3} className="w-full bg-gray-600 rounded px-3 py-2 text-sm" /></div>)}<button onClick={()=>{const arr=[...toArray(content.content?.intro?.paragraphs),''];setContent({...content,content:{...content.content,intro:{...content.content.intro,paragraphs:arr}}})}} className="text-sm text-blue-400">+ Agregar párrafo</button></div></div>}
      {sections.includes('cta') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-pink-400">CTA Final <SectionGenBtn section="cta" label="CTA" /></h4><div className="space-y-3"><div><label className="text-xs text-gray-400 block mb-1">Heading</label><input type="text" value={content.content?.cta?.heading||''} onChange={e=>setContent({...content,content:{...content.content,cta:{...content.content.cta,heading:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Subheading</label><textarea value={content.content?.cta?.subheading||''} onChange={e=>setContent({...content,content:{...content.content,cta:{...content.content.cta,subheading:e.target.value}}})} rows={3} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Texto Botón</label><input type="text" value={content.content?.cta?.button_text||''} onChange={e=>setContent({...content,content:{...content.content,cta:{...content.content.cta,button_text:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Link Botón</label><input type="text" value={content.content?.cta?.button_href||''} onChange={e=>setContent({...content,content:{...content.content,cta:{...content.content.cta,button_href:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div></div></div>}
      {sections.includes('contact_info') && <div className="bg-gray-800 rounded-xl p-4"><h4 className="font-semibold mb-3 text-teal-400">Información de Contacto</h4><div className="space-y-3"><div><label className="text-xs text-gray-400 block mb-1">Teléfono</label><input type="text" value={content.content?.contact_info?.phone||''} onChange={e=>setContent({...content,content:{...content.content,contact_info:{...content.content.contact_info,phone:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Email</label><input type="text" value={content.content?.contact_info?.email||''} onChange={e=>setContent({...content,content:{...content.content,contact_info:{...content.content.contact_info,email:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div><label className="text-xs text-gray-400 block mb-1">Dirección</label><input type="text" value={content.content?.contact_info?.address||''} onChange={e=>setContent({...content,content:{...content.content,contact_info:{...content.content.contact_info,address:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div className="flex gap-2"><div className="flex-1"><label className="text-xs text-gray-400 block mb-1">Latitud</label><input type="text" value={content.content?.contact_info?.lat||''} onChange={e=>setContent({...content,content:{...content.content,contact_info:{...content.content.contact_info,lat:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div><div className="flex-1"><label className="text-xs text-gray-400 block mb-1">Longitud</label><input type="text" value={content.content?.contact_info?.lng||''} onChange={e=>setContent({...content,content:{...content.content,contact_info:{...content.content.contact_info,lng:e.target.value}}})} className="w-full bg-gray-700 rounded px-3 py-2 text-sm" /></div></div></div></div>}
    </div></div>
  </div>;
}
