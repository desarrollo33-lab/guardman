// GuardMan Admin v13 — SEO Score Panel
// Real-time heuristic SEO analysis for CMS editor

import { useMemo } from 'react';
import { calculateSEOScore, SEOScoreResult } from '../../utils/seo-scorer';

interface ContentData {
  title?: string;
  description?: string;
  h1?: string;
  h2?: string[];
  bodyText?: string;
  images?: { alt?: string }[];
  internalLinks?: string[];
  keyword?: string;
}

interface Props {
  data: ContentData;
  onRegenerate?: () => void;
}

const gradeConfig: Record<SEOScoreResult['grade'], { color: string; bg: string; label: string }> = {
  excellent: { color: '#34D399', bg: 'rgba(52,211,153,0.1)', label: 'Excelente' },
  good: { color: '#10B981', bg: 'rgba(16,185,129,0.1)', label: 'Bueno' },
  fair: { color: '#F59E0B', bg: 'rgba(245,158,11,0.1)', label: 'Regular' },
  poor: { color: '#F87171', bg: 'rgba(248,113,113,0.1)', label: 'Mejorable' },
};

export function SEOScorePanel({ data, onRegenerate }: Props) {
  const result = useMemo(() => calculateSEOScore(data), [
    data.title, data.description, data.h1, data.h2, data.bodyText,
    data.images, data.internalLinks, data.keyword,
  ]);

  const gc = gradeConfig[result.grade];
  const circumference = 2 * Math.PI * 34; // r=34
  const dashOffset = circumference - (result.score / 100) * circumference;

  return (
    <div style={{
      width: 300, flexShrink: 0, height: 'calc(100vh - 200px)', overflowY: 'auto',
      background: 'var(--surface-1)', borderRadius: 'var(--radius-lg)',
      border: '1px solid var(--border-light)', padding: 20,
    }}>
      {/* Score Ring */}
      <div style={{ textAlign: 'center', marginBottom: 16 }}>
        <div style={{ position: 'relative', width: 80, height: 80, margin: '0 auto 12px' }}>
          <svg width={80} height={80} viewBox="0 0 80 80" style={{ transform: 'rotate(-90deg)' }}>
            <circle cx={40} cy={40} r={34} fill="none" stroke="var(--surface-2)" strokeWidth={6} />
            <circle
              cx={40} cy={40} r={34} fill="none" stroke={gc.color} strokeWidth={6}
              strokeDasharray={circumference} strokeDashoffset={dashOffset}
              strokeLinecap="round"
              style={{ transition: 'stroke-dashoffset 0.5s ease' }}
            />
          </svg>
          <div style={{
            position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 24, fontWeight: 700, color: 'var(--fg)',
          }}>
            {result.score}
          </div>
        </div>
        <span style={{
          display: 'inline-block', padding: '2px 12px', borderRadius: 999,
          background: gc.bg, color: gc.color, fontSize: 12, fontWeight: 600,
          border: `1px solid ${gc.color}33`,
        }}>
          {gc.label}
        </span>
      </div>

      {/* Breakdown */}
      <div style={{ marginBottom: 20 }}>
        <h5 style={{ fontSize: 11, color: 'var(--fg-dim)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 10 }}>
          Breakdown
        </h5>
        <BreakdownBar label="Contenido" pct={result.breakdown.content} />
        <BreakdownBar label="SEO Técnico" pct={result.breakdown.technical} />
        <BreakdownBar label="Conversión" pct={result.breakdown.conversion} />
      </div>

      {/* Quality Checks */}
      <div style={{ marginBottom: 16 }}>
        <h5 style={{ fontSize: 11, color: 'var(--fg-dim)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 10 }}>
          Quality Checks
        </h5>
        {result.checks.slice(0, 8).map((check, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, padding: '5px 0', fontSize: 12 }}>
            <span style={{
              width: 18, height: 18, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 10, flexShrink: 0, marginTop: 1,
              background: check.status === 'pass' ? 'rgba(16,185,129,0.12)' : check.status === 'warn' ? 'rgba(245,158,11,0.12)' : 'rgba(239,68,68,0.12)',
              color: check.status === 'pass' ? 'var(--success)' : check.status === 'warn' ? 'var(--warning)' : '#fca5a5',
            }}>
              {check.status === 'pass' ? '✓' : check.status === 'warn' ? '!' : '✗'}
            </span>
            <div>
              <div style={{ color: 'var(--fg-muted)', fontSize: 12 }}>{check.name}</div>
              <div style={{ color: 'var(--fg-dim)', fontSize: 11 }}>{check.detail}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Actions */}
      {onRegenerate && (
        <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
          <button
            onClick={onRegenerate}
            className="btn btn-primary btn-sm"
            style={{ flex: 1 }}
          >
            🤖 Regenerar con IA
          </button>
        </div>
      )}
    </div>
  );
}

function BreakdownBar({ label, pct }: { label: string; pct: number }) {
  const color = pct >= 80 ? 'var(--success)' : pct >= 60 ? '#F59E0B' : '#F87171';
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--fg-muted)', marginBottom: 4 }}>
        <span>{label}</span>
        <span>{pct}%</span>
      </div>
      <div style={{ height: 6, background: 'var(--surface-2)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{
          height: '100%', borderRadius: 3, background: color,
          width: `${pct}%`, transition: 'width 0.6s ease',
        }} />
      </div>
    </div>
  );
}
