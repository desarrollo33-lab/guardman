// GuardMan Admin v3.0 — SEO Panel (supports homepage + generic pages)
import { useState } from 'react';

interface SEOPanelProps {
  content: any;
  onRegenerate: () => void;
  regenerating: boolean;
  scoreWarnings?: string[];
  backendScore?: number;
  serpIntel?: any;
  pipelineStatus?: any;
  leadsInfo?: any;
  onPublish?: () => void;
  publishing?: boolean;
  onNavigateToIntel?: () => void;
}

function computeScore(content: any): { score: number; titleOk: boolean; descOk: boolean; hasHero: boolean; hasIntro: boolean; hasFeatures: boolean; hasFAQ: boolean; hasCTA: boolean; wordCount: number; titleLen: number; descLen: number; isHomepage: boolean; checks: { label: string; ok: boolean; detail: string }[] } {
  const s = content?.content || content?.sections || {};
  const hero = s.hero || {};
  const meta = s.meta || content?.seo || {};

  // Detect homepage format
  const isHomepage = !!(s.nosotros || s.servicios || s.guardpod || s.cta_final);
  
  // Detect static page format (nosotros, guard-pod, ajax-systems, etc.)
  const isStaticPage = !!(s.stats || s.timeline || s.features || s.faqs || s.whyUs || s.body_content);
  const staticSlug = (content as any)?._slug || '';

  const title = meta.title || hero.headline || hero.heading || '';
  const desc = meta.description || hero.subheadline || hero.subheading || '';
  const titleLen = title.length;
  const descLen = desc.length;

  let score = 0;
  const checks: { label: string; ok: boolean; detail: string }[] = [];

  // Title
  const titleOk = titleLen >= 30 && titleLen <= 60;
  if (titleOk) score += 12;
  else if (titleLen > 0) score += 6;
  checks.push({ label: 'Title', ok: titleOk, detail: `${titleLen} chars` });

  // Description
  const descOk = descLen >= 80 && descLen <= 160;
  if (descOk) score += 12;
  else if (descLen > 0) score += 6;
  checks.push({ label: 'Description', ok: descOk, detail: `${descLen} chars` });

  // Hero
  const heroHeadline = hero.headline || hero.heading || '';
  const heroImage = hero.background_image || hero.image || '';
  const hasHero = !!heroHeadline;
  if (hasHero) score += 5;
  const heroHasImage = !!heroImage && !heroImage.includes('/name.');
  if (heroHasImage) score += 5;
  checks.push({ label: 'Hero', ok: hasHero, detail: hasHero ? '✓' : '✗' });

  let wordCount = 0;

  if (isHomepage) {
    // Homepage-specific
    const nosotros = s.nosotros || {};
    const paragraph = nosotros.paragraph || '';
    const hasIntro = paragraph.length > 50;
    if (paragraph.length > 500) score += 10;
    else if (paragraph.length > 100) score += 5;
    checks.push({ label: 'Nosotros', ok: hasIntro, detail: hasIntro ? `${paragraph.split(/\s+/).length} palabras` : '✗' });

    const nFeatures = nosotros.features || [];
    const hasFeatures = nFeatures.length >= 3;
    if (nFeatures.length >= 4) score += 8;
    else if (nFeatures.length > 0) score += 4;
    checks.push({ label: 'Features', ok: hasFeatures, detail: `${nFeatures.length}` });

    const guardpod = s.guardpod || {};
    const gpOk = !!guardpod.paragraph;
    if (gpOk) score += 5;
    const gpFeatures = guardpod.features || [];
    if (gpFeatures.length >= 3) score += 5;
    else if (gpFeatures.length > 0) score += 3;
    checks.push({ label: 'Guard Pod', ok: gpOk, detail: gpOk ? `${gpFeatures.length} features` : '✗' });

    const ajax = s.ajax || {};
    const ajaxOk = !!ajax.paragraph;
    if (ajaxOk) score += 5;
    const ajaxFeatures = ajax.features || [];
    if (ajaxFeatures.length >= 3) score += 5;
    else if (ajaxFeatures.length > 0) score += 3;
    checks.push({ label: 'Ajax Systems', ok: ajaxOk, detail: ajaxOk ? `${ajaxFeatures.length} features` : '✗' });

    const ctaFinal = s.cta_final || {};
    const hasCTA = !!(ctaFinal.title);
    if (ctaFinal.title) score += 5;
    if (ctaFinal.subtitle) score += 3;
    checks.push({ label: 'CTA Final', ok: hasCTA, detail: hasCTA ? '✓' : '✗' });

    const ubicaciones = s.ubicaciones || {};
    if (ubicaciones.title) score += 3;

    wordCount = [
      heroHeadline, hero.subheadline || hero.subheading || '',
      paragraph, ...nFeatures.map((f: any) => `${f.title||''} ${f.description||''}`),
      guardpod.paragraph || '', ...gpFeatures.map((f: any) => `${f.title||''} ${f.description||''}`),
      ajax.paragraph || '', ...ajaxFeatures.map((f: any) => `${f.title||''} ${f.description||''}`),
      ctaFinal.title || '', ctaFinal.subtitle || '',
    ].join(' ').split(/\s+/).filter(Boolean).length;

    // Fake hasFAQ/hasFeatures for the return
    const hasFAQ = false; // homepage doesn't have FAQ section
    return { score, titleOk, descOk, hasHero, hasIntro, hasFeatures, hasFAQ, hasCTA, wordCount, titleLen, descLen, isHomepage, checks };

  } else if (isStaticPage) {
    // Static page scoring (nosotros, guard-pod, ajax, etc.)
    const stats = Array.isArray(s.stats) ? s.stats : (s.stats?.items || []);
    const timeline = Array.isArray(s.timeline) ? s.timeline : (s.timeline?.items || []);
    const features = Array.isArray(s.features) ? s.features : (s.features?.items || []);
    const faqs = Array.isArray(s.faqs) ? s.faqs : (s.faqs?.items || []);
    const problems = Array.isArray(s.problems) ? s.problems : (s.problems?.items || []);
    const whyUs = Array.isArray(s.whyUs) ? s.whyUs : (s.whyUs?.items || []);

    if (stats.length >= 3) score += 8;
    else if (stats.length > 0) score += 4;
    checks.push({ label: 'Stats', ok: stats.length > 0, detail: `${stats.length}` });

    if (timeline.length >= 4) score += 8;
    else if (timeline.length > 0) score += 4;
    checks.push({ label: 'Timeline', ok: timeline.length > 0, detail: `${timeline.length}` });

    if (features.length >= 6) score += 10;
    else if (features.length > 0) score += 5;
    checks.push({ label: 'Features', ok: features.length > 0, detail: `${features.length}` });

    if (faqs.length >= 3) score += 10;
    else if (faqs.length > 0) score += 5;
    checks.push({ label: 'FAQs', ok: faqs.length > 0, detail: `${faqs.length}` });

    if (problems.length >= 3) score += 6;
    else if (problems.length > 0) score += 3;
    if (problems.length > 0) checks.push({ label: 'Problems', ok: true, detail: `${problems.length}` });

    if (whyUs.length >= 2) score += 6;
    else if (whyUs.length > 0) score += 3;
    if (whyUs.length > 0) checks.push({ label: 'Why Us', ok: true, detail: `${whyUs.length}` });

    const bodyContent = s.body_content || '';
    if (bodyContent.length > 500) score += 10;
    else if (bodyContent.length > 100) score += 5;
    if (bodyContent) checks.push({ label: 'HTML Body', ok: bodyContent.length > 100, detail: `${bodyContent.length} chars` });

    const hasIntro = stats.length > 0 || timeline.length > 0;
    const hasFeatures = features.length > 0;
    const hasFAQ = faqs.length > 0;
    const hasCTA = true; // static pages always have CTA

    wordCount = [
      ...stats.map((s:any)=>`${s.value||''} ${s.label||''}`),
      ...timeline.map((t:any)=>`${t.title||''} ${t.description||''}`),
      ...features.map((f:any)=>`${f.title||''} ${f.description||''}`),
      ...faqs.map((f:any)=>`${f.question||''} ${f.answer||''}`),
      ...problems.map((p:any)=>typeof p==='string'?p:p.description||''),
      ...whyUs.map((w:any)=>`${w.title||''} ${w.description||''}`),
      bodyContent
    ].join(' ').split(/\s+/).filter(Boolean).length;

    return { score, titleOk, descOk, hasHero, hasIntro, hasFeatures, hasFAQ, hasCTA, wordCount, titleLen, descLen, isHomepage, checks };

  } else {
    // Generic page scoring
    const intro = s.intro || {};
    const features = s.features || {};
    const faqs = s.faqs || {};
    const cta = s.cta || {};

    const introParas = intro.paragraphs || [];
    const introText = introParas.join(' ');
    const hasIntro = introText.length > 0;
    if (introText.length > 200) score += 10;
    else if (introText.length > 50) score += 5;
    checks.push({ label: 'Intro', ok: hasIntro, detail: hasIntro ? '✓' : '✗' });

    const featItems = features.items || [];
    const hasFeatures = featItems.length > 0;
    if (featItems.length >= 6) score += 10;
    else if (featItems.length > 0) score += 5;
    checks.push({ label: 'Features', ok: hasFeatures, detail: `${featItems.length}` });

    const faqItems = faqs.items || [];
    const hasFAQ = faqItems.length > 0;
    if (faqItems.length >= 4) score += 10;
    else if (faqItems.length > 0) score += 5;
    checks.push({ label: 'FAQs', ok: hasFAQ, detail: `${faqItems.length}` });

    const hasCTA = !!(cta.heading || cta.button);
    if (cta.heading) score += 5;
    if (cta.button) score += 3;
    checks.push({ label: 'CTA', ok: hasCTA, detail: hasCTA ? '✓' : '✗' });

    wordCount = [introText, ...featItems, ...faqItems.map((f: any) => (f.question||'')+' '+(f.answer||'')), cta.heading||'', cta.subheading||''].join(' ').split(/\s+/).filter(Boolean).length;

    return { score, titleOk, descOk, hasHero, hasIntro, hasFeatures, hasFAQ, hasCTA, wordCount, titleLen, descLen, isHomepage, checks };
  }
}

export function SEOPanel({ content, onRegenerate, regenerating, scoreWarnings, serpIntel, pipelineStatus, onPublish, publishing }: SEOPanelProps) {
  const result = computeScore(content);
  const { score, checks, wordCount, isHomepage } = result;

  const scoreColor = score >= 70 ? 'var(--success)' : score >= 50 ? 'var(--warning)' : 'var(--error)';
  const scoreLabel = score >= 70 ? 'Excelente' : score >= 50 ? 'Mejorable' : 'Deficiente';
  const circumference = 2 * Math.PI * 42;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="panel" style={{position:'sticky',top:'24px'}}>
      <div className="panel-header"><h3>SEO Score</h3></div>

      {/* Score Ring */}
      <div style={{position:'relative',width:'80px',height:'80px',margin:'0 auto 16px'}}>
        <svg viewBox="0 0 100 100" style={{width:'100%',height:'100%',transform:'rotate(-90deg)'}}>
          <circle cx="50" cy="50" r="42" fill="none" stroke="var(--border-light)" strokeWidth="6"/>
          <circle cx="50" cy="50" r="42" fill="none" stroke={scoreColor} strokeWidth="6"
            strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round"
            style={{transition:'stroke-dashoffset 0.6s ease'}}/>
        </svg>
        <div style={{position:'absolute',inset:0,display:'grid',placeItems:'center',fontSize:'28px',fontWeight:700,color:scoreColor}}>{score}</div>
      </div>

      {/* Breakdown */}
      <div style={{marginBottom:'20px'}}>
        <div style={{display:'flex',justifyContent:'space-between',fontSize:'12px',marginBottom:'4px'}}><span>Contenido</span><span style={{color:'var(--fg-dim)'}}>{Math.round((score/100)*85)}%</span></div>
        <div className="progress-bar"><div className="fill" style={{width:Math.round((score/100)*85)+'%',background:score>=50?'var(--success)':'var(--warning)'}}/></div>
        <div style={{display:'flex',justifyContent:'space-between',fontSize:'12px',marginBottom:'4px'}}><span>SEO Técnico</span><span style={{color:'var(--fg-dim)'}}>{Math.round((score/100)*72)}%</span></div>
        <div className="progress-bar"><div className="fill" style={{width:Math.round((score/100)*72)+'%',background:score>=50?'var(--success)':'var(--warning)'}}/></div>
        <div style={{display:'flex',justifyContent:'space-between',fontSize:'12px',marginBottom:'4px'}}><span>Conversión</span><span style={{color:'var(--fg-dim)'}}>{Math.round((score/100)*80)}%</span></div>
        <div className="progress-bar"><div className="fill" style={{width:Math.round((score/100)*80)+'%',background:score>=50?'var(--success)':'var(--warning)'}}/></div>
      </div>

      {/* SERP Preview */}
      {serpIntel && (
        <>
          <div className="panel-header"><h3>Datos SERP</h3></div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:'8px',marginBottom:'16px',fontSize:'12px'}}>
            <div style={{background:'var(--surface-2)',borderRadius:'var(--radius-sm)',padding:'8px',textAlign:'center'}}>
              <div style={{fontWeight:600,color:'var(--fg)'}}>{serpIntel.query_volume || 0}</div>
              <div style={{color:'var(--fg-dim)',fontSize:'10px'}}>queries</div>
            </div>
            <div style={{background:'var(--surface-2)',borderRadius:'var(--radius-sm)',padding:'8px',textAlign:'center'}}>
              <div style={{fontWeight:600,color:'var(--fg)'}}>{serpIntel.competitor_count || 0}</div>
              <div style={{color:'var(--fg-dim)',fontSize:'10px'}}>compet.</div>
            </div>
            <div style={{background:'var(--surface-2)',borderRadius:'var(--radius-sm)',padding:'8px',textAlign:'center'}}>
              <div style={{fontWeight:600,color:'var(--fg)'}}>{serpIntel.position ? '#'+serpIntel.position : '—'}</div>
              <div style={{color:'var(--fg-dim)',fontSize:'10px'}}>posición</div>
            </div>
          </div>
        </>
      )}

      {/* Pipeline Status */}
      {pipelineStatus && (
        <div style={{display:'flex',justifyContent:'space-between',fontSize:'12px',padding:'8px 0',borderTop:'1px solid var(--border-light)',marginBottom:'12px'}}>
          <span style={{color:'var(--fg-dim)'}}>Estado</span>
          <span style={{color:'var(--fg)'}}>{pipelineStatus.deployed ? '✅ Live' : pipelineStatus.in_d1 ? '📝 D1' : '—'}</span>
        </div>
      )}

      {/* Content Quality Checks */}
      <div style={{borderTop:'1px solid var(--border-light)',paddingTop:'12px',marginBottom:'12px'}}>
        <div style={{fontSize:'11px',color:'var(--fg-dim)',textTransform:'uppercase',letterSpacing:'0.05em',marginBottom:'8px',fontWeight:600}}>
          Calidad {isHomepage ? '(Homepage)' : ''}
        </div>
        {checks.map((c, i) => (
          <CheckItem key={i} label={c.label} ok={c.ok} detail={c.detail} />
        ))}
        <CheckItem label="Palabras" ok={wordCount >= 200} detail={`${wordCount}`} />
      </div>

      {scoreWarnings && scoreWarnings.length > 0 && (
        <div style={{marginBottom:'12px'}}>
          {scoreWarnings.map((w, i) => (
            <div key={i} style={{fontSize:'11px',color:'var(--warning)',background:'var(--warning-soft)',borderRadius:'var(--radius-sm)',padding:'4px 8px',marginBottom:'4px'}}>{w}</div>
          ))}
        </div>
      )}

      {/* Quality Pipeline (BUG-11) */}
      {pipelineStatus && (pipelineStatus.score !== undefined) && (
        <div style={{borderTop:'1px solid var(--border-light)',paddingTop:'12px',marginBottom:'12px'}}>
          <div style={{fontSize:'11px',color:'var(--fg-dim)',textTransform:'uppercase',letterSpacing:'0.05em',marginBottom:'8px',fontWeight:600}}>
            Pipeline de Calidad
          </div>
          <div style={{display:'flex',alignItems:'center',gap:'8px',marginBottom:'8px'}}>
            <span style={{fontSize:'24px',fontWeight:700,color:pipelineStatus.passed?'var(--success)':'var(--error)'}}>
              {pipelineStatus.score}
            </span>
            <span style={{fontSize:'12px',color:pipelineStatus.passed?'var(--success)':'var(--error)'}}>
              {pipelineStatus.passed ? '✅ Pasó' : '❌ Falló'}
            </span>
          </div>
          {pipelineStatus.violations?.length > 0 && (
            <div style={{marginBottom:'6px'}}>
              <div style={{fontSize:'10px',color:'var(--fg-dim)',marginBottom:'4px'}}>Violaciones:</div>
              {pipelineStatus.violations.map((v: string, i: number) => (
                <div key={i} style={{fontSize:'11px',color:'var(--error)',marginBottom:'2px'}}>• {v}</div>
              ))}
            </div>
          )}
          {pipelineStatus.genericPhrases?.length > 0 && (
            <div style={{marginBottom:'6px'}}>
              <div style={{fontSize:'10px',color:'var(--fg-dim)',marginBottom:'4px'}}>Frases genéricas:</div>
              {pipelineStatus.genericPhrases.map((p: string, i: number) => (
                <div key={i} style={{fontSize:'11px',color:'var(--warning)',marginBottom:'2px'}}>• {p}</div>
              ))}
            </div>
          )}
          {pipelineStatus.review && (
            <div style={{fontSize:'11px',color:'var(--fg-muted)',marginTop:'4px',fontStyle:'italic'}}>
              {pipelineStatus.review}
            </div>
          )}
        </div>
      )}

      {/* Actions */}
      <div style={{display:'flex',flexDirection:'column',gap:'8px',borderTop:'1px solid var(--border-light)',paddingTop:'12px'}}>
        <button onClick={onRegenerate} disabled={regenerating} className="btn btn-secondary" style={{justifyContent:'center',width:'100%'}}>
          {regenerating ? 'Regenerando...' : '🤖 Regenerar con IA'}
        </button>
        {onPublish && (
          <button onClick={onPublish} disabled={publishing}
            className={pipelineStatus?.deployed ? 'btn btn-secondary' : 'btn btn-primary'}
            style={{justifyContent:'center',width:'100%'}}>
            {pipelineStatus?.deployed ? '✅ Publicado' : publishing ? '⏳ Publicando...' : '🚀 Publicar'}
          </button>
        )}
      </div>
    </div>
  );
}

function CheckItem({ label, ok, detail }: { label: string; ok: boolean; detail: string }) {
  return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'3px 0'}}>
      <div style={{display:'flex',alignItems:'center',gap:'8px'}}>
        <span style={{width:'16px',height:'16px',borderRadius:'50%',display:'grid',placeItems:'center',fontSize:'10px',background:ok?'var(--success)':'var(--error)',color:'#fff'}}>
          {ok ? '✓' : '✗'}
        </span>
        <span style={{fontSize:'13px',color:'var(--fg-muted)'}}>{label}</span>
      </div>
      <span style={{fontSize:'11px',color:'var(--fg-dim)',fontFamily:'var(--font-mono)'}}>{detail}</span>
    </div>
  );
}
