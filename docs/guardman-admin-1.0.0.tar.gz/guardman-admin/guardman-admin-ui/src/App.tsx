// GuardMan Admin v12 — Chat + CMS Interface
import { useState, useCallback } from 'react';
import { setToken, clearToken } from './hooks/useApi';
import { AppLayout } from './components/Layout/AppLayout';
import { ChatView } from './components/Chat/ChatView';
import { CMSPage } from './components/CMS/CMSPage';
import { MediaEditor } from './components/Media/MediaEditor';
import { ADNPage } from './components/Brand/ADNPage';
import { IntelPage } from './components/Intel/IntelPage';
import { CRMPage } from './components/CRM/CRMPage';
import { ToastProvider } from './components/UI/Toast';

type ViewType = 'cms' | 'media' | 'adn' | 'crm' | 'intel';

export default function App() {
  const isDemoMode = typeof window !== 'undefined' && localStorage.getItem('gm_demo_mode') === 'crm';
  const [authToken, setAuthToken] = useState<string | null>(
    () => {
      if (isDemoMode) return 'demo-token';
      const stored = localStorage.getItem('gm_token');
      if (stored && stored !== 'undefined' && stored !== 'null') return stored;
      localStorage.removeItem('gm_token');
      return null;
    }
  );
  const [showSettings, setShowSettings] = useState(false);
  const [currentView, setCurrentView] = useState<ViewType>(isDemoMode ? 'crm' : 'cms');

  const isLoggedIn = !!authToken || isDemoMode;

  const handleSendMessage = useCallback((message: string) => {
    window.dispatchEvent(new CustomEvent('gm:send-message', { detail: message }));
  }, []);

  const handleAction = useCallback((action: string) => {
    if (action === 'open_settings') {
      setShowSettings(true);
    } else if (action === 'cms') {
      setCurrentView('cms');
    } else if (action === 'media') {
      setCurrentView('media');
    } else if (action === 'adn') {
      setCurrentView('adn');
    } else if (action === 'intel') {
      setCurrentView('intel');
    } else if (action === 'crm') {
      setCurrentView('crm');
    }
  }, []);

  const handleToggleHistory = useCallback(() => {
    window.dispatchEvent(new CustomEvent('gm:toggle-history'));
  }, []);

  const handleLogin = useCallback((token: string) => {
    setToken(token);
    setAuthToken(token);
  }, []);

  const handleLogout = useCallback(() => {
    clearToken();
    setAuthToken(null);
  }, []);

  if (!isLoggedIn) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <ToastProvider>
      <AppLayout onSendMessage={handleSendMessage} onAction={handleAction} activeView={currentView} onToggleHistory={handleToggleHistory}>
        {currentView === 'media' ? <MediaEditor mode="full" /> : currentView === 'adn' ? <ADNPage /> : currentView === 'crm' ? <CRMPage /> : currentView === 'intel' ? <IntelPage /> : <CMSPage />}
      </AppLayout>

      {showSettings && (
        <SettingsModal onClose={() => setShowSettings(false)} onLogout={handleLogout} />
      )}
    </ToastProvider>
  );
}

function LoginForm({ onLogin }: { onLogin: (token: string) => void }) {
  const [email, setEmail] = useState('admin@guardman.oficinadesarrollo33.workers.dev');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch(
        'https://guardman.oficinadesarrollo33.workers.dev/api/login',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        }
      );

      const data = await response.json();

      if (!data.ok) {
        throw new Error(data.error || 'Credenciales inválidas');
      }

      // FIX: API response is { ok: true, data: { token: "...", user: {...} } }
      const token = data.data?.token;
      if (!token) {
        throw new Error('Token no recibido del servidor');
      }

      onLogin(token);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{
      background: 'radial-gradient(ellipse at 50% 0%, rgba(59,130,246,0.12) 0%, rgba(13,21,37,1) 70%)'
    }}>
      <form 
        onSubmit={handleSubmit} 
        className="bg-[#131D33] p-12 px-10 rounded-[18px] shadow-2xl w-[420px] max-w-[calc(100vw-32px)] border border-white/5"
      >
        <div className="text-center mb-8">
          <div style={{
            width: 56, height: 56, borderRadius: 10,
            background: 'linear-gradient(135deg, #3B82F6, #1d4ed8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 20px', fontSize: 24, fontWeight: 700, color: '#fff',
            boxShadow: '0 4px 16px rgba(59,130,246,0.3)'
          }}>🛡️</div>
          <h1 className="text-xl font-semibold text-white">GuardMan Admin</h1>
          <p className="text-sm text-white/40 mt-1">Panel de Administración v13</p>
        </div>

        {error && (
          <div className="bg-error/10 text-error p-3 rounded-lg mb-5 text-sm border border-error/20 flex items-center gap-2">
            <span>⚠️</span> {error}
          </div>
        )}

        <div className="mb-5">
          <label className="block text-xs text-white/50 mb-1.5 font-medium uppercase tracking-wider">Correo Electrónico</label>
          <input 
            type="email" 
            value={email} 
            onChange={e => setEmail(e.target.value)} 
            placeholder="admin@guardman.cl"
            className="w-full p-2.5 bg-[#1A2744] text-white rounded-lg border border-white/5
              placeholder-white/20 focus:outline-none focus:border-[#3B82F6] focus:shadow-[0_0_0_3px_rgba(59,130,246,0.15)] text-sm" 
          />
        </div>
        <div className="mb-7">
          <label className="block text-xs text-white/50 mb-1.5 font-medium uppercase tracking-wider">Contraseña</label>
          <input 
            type="password" 
            value={password} 
            onChange={e => setPassword(e.target.value)} 
            placeholder="••••••••"
            className="w-full p-2.5 bg-[#1A2744] text-white rounded-lg border border-white/5
              placeholder-white/20 focus:outline-none focus:border-[#3B82F6] focus:shadow-[0_0_0_3px_rgba(59,130,246,0.15)] text-sm" 
          />
        </div>
        
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-[#3B82F6] hover:bg-[#2563eb] disabled:opacity-50 disabled:bg-[#2563eb]
            text-white p-3 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Conectando...
            </>
          ) : (
            'Iniciar Sesión'
          )}
        </button>

        <div className="text-center mt-6">
          <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold border border-emerald-500/20">
            OS-10 Autorizado
          </span>
        </div>
      </form>
    </div>
  );
}

function SettingsModal({ onClose, onLogout }: { onClose: () => void; onLogout: () => void }) {
  const handleLogout = () => { onLogout(); };
  const [demoMode, setDemoMode] = useState(() => localStorage.getItem('gm_demo_mode') === 'crm');

  const toggleDemo = () => {
    const next = !demoMode;
    setDemoMode(next);
    if (next) localStorage.setItem('gm_demo_mode', 'crm');
    else localStorage.removeItem('gm_demo_mode');
    window.location.reload();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div 
        className="bg-[#1A2744] rounded-2xl border border-white/10 w-full max-w-md overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
          <h2 className="text-lg font-medium">⚙️ Ajustes</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-white/10">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-white/5 rounded-xl p-4">
            <h3 className="text-sm font-medium mb-2">Sesión</h3>
            <p className="text-xs text-white/40 mb-3">admin@guardman.oficinadesarrollo33.workers.dev</p>
            <button
              onClick={handleLogout}
              className="w-full px-4 py-2 rounded-lg bg-error/10 border border-error/20 
                text-error hover:bg-error/20 text-sm transition-colors"
            >
              Cerrar sesión
            </button>
          </div>

          <div className="bg-white/5 rounded-xl p-4">
            <h3 className="text-sm font-medium mb-2">🧪 Modo Demo CRM</h3>
            <p className="text-xs text-white/40 mb-3">
              Activa datos mock para probar el CRM sin conexión al backend.
            </p>
            <button
              onClick={toggleDemo}
              className={`w-full px-4 py-2 rounded-lg border text-sm transition-colors ${
                demoMode
                  ? 'bg-green-500/10 border-green-500/20 text-green-400 hover:bg-green-500/20'
                  : 'bg-white/5 border-white/10 text-white/60 hover:bg-white/10'
              }`}
            >
              {demoMode ? '✅ Modo Demo ACTIVADO (click para desactivar)' : 'Activar Modo Demo CRM'}
            </button>
          </div>

          <div className="bg-white/5 rounded-xl p-4">
            <h3 className="text-sm font-medium mb-2">Información</h3>
            <div className="space-y-1 text-xs text-white/40">
              <p>Backend: guardman.oficinadesarrollo33.workers.dev</p>
              <p>UI: guardman-admin.pages.dev</p>
              <p>Versión: v12</p>
              {demoMode && <p className="text-green-400 font-medium">🔧 Usando API Mock (CRM)</p>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
