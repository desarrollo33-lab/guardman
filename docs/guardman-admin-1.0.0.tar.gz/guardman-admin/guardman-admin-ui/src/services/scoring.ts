// GuardMan Admin — Unified Content Score (frontend version)
// Mirrors scoring.ts backend. Single source of truth for all scores.

export function unifiedScore(content: any, serpIntel?: any): { total: number; breakdown: { content: number; seo: number; conversion: number }; label: string } {
  const sections = content?.content || content?.sections || content || {};
  const meta = content?.seo || sections?.meta || {};
  const hero = sections.hero || {};
  const intro = sections.intro || {};
  const features = sections.features || {};
  const faqs = sections.faq || sections.faqs || {};
  const cta = sections.cta || {};

  let c = 0, s = 0, v = 0;

  // Content quality (max 60)
  const title = meta.title || hero.heading || '';
  c += title.length >= 30 && title.length <= 60 ? 12 : title.length >= 20 ? 6 : 0;
  const desc = meta.description || hero.subheading || '';
  c += desc.length >= 80 && desc.length <= 160 ? 12 : desc.length >= 60 ? 6 : 0;
  if (hero.heading) c += 5;
  if (hero.image) c += 5;
  const introText = Array.isArray(intro.paragraphs) ? intro.paragraphs.join(' ') : (intro.content || '');
  c += introText.length > 200 ? 10 : introText.length > 100 ? 5 : 0;
  const feat = features.items?.length || 0;
  c += feat >= 6 ? 8 : feat >= 3 ? 4 : 0;
  const faq = Array.isArray(faqs) ? faqs.length : (faqs.items?.length || 0);
  c += faq >= 4 ? 8 : faq >= 2 ? 4 : 0;

  // SEO (max 25)
  if (serpIntel) {
    const pos = serpIntel.position;
    if (pos && pos <= 3) s += 15;
    else if (pos && pos <= 10) s += 8;
    else if (pos && pos > 10) s += 3;
    s += (serpIntel.query_volume || 0) >= 20 ? 5 : (serpIntel.query_volume || 0) >= 10 ? 3 : 0;
    s += (serpIntel.competitor_count || 0) <= 3 ? 5 : (serpIntel.competitor_count || 0) <= 8 ? 2 : 0;
  }

  // Conversion (max 15)
  if (cta.heading || cta.headline || cta.button) v += 6;
  if (serpIntel?.deployed) v += 5;
  if (faq >= 3) v += 4;

  const total = Math.min(100, c + s + v);
  return {
    total,
    breakdown: { content: c, seo: s, conversion: v },
    label: total >= 70 ? 'excelente' : total >= 50 ? 'bueno' : total >= 30 ? 'mejorable' : 'deficiente',
  };
}

/** Replaces old calcBackendScore — kept for backward compat */
export function calcBackendScore(content: any): { score: number; warnings: string[] } {
  const result = unifiedScore(content);
  return { score: result.total, warnings: [] };
}
