import '@testing-library/jest-dom';
import { vi } from 'vitest';

// Mock localStorage
global.localStorage = {
  getItem: vi.fn(),
  setItem: vi.fn(),
  removeItem: vi.fn(),
  clear: vi.fn(),
} as any;

// Mock console methods to reduce noise during tests
// global.console = { ...console, log: vi.fn(), warn: vi.fn() };
