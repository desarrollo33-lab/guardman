// GuardMan Admin v2.0 — usePublish hook
// 100% cloud state — D1 is the source of truth, no localStorage

import { useState, useEffect, useCallback } from 'react';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

// ── Types ──
export interface PendingItem {
  entity_type: string; entity_slug: string;
  current_version: number; published_version: number;
  score: number; words: number;
  changes: { field: string; before: string; after: string }[];
  modified_at: string; modified_by: string; is_new: boolean;
}

export interface DeployStage { name: string; status: string; started_on?: string; ended_on?: string; }

export interface DeployState {
  phase: 'idle' | 'exporting' | 'deploying' | 'success' | 'failure';
  deployment_id?: string; deploy_url?: string;
  exported?: number; entity_count?: number;
  errors?: string[];
  startedAt: number;
  stages?: DeployStage[];
}

// ── Global module state (in-memory cache only, refreshed from API) ──
let globalPending: PendingItem[] = [];
let globalSummary: any = null;
let globalDeploy: DeployState = { phase: 'idle', startedAt: 0 };
let globalLastFetch = 0;
let listeners: (() => void)[] = [];
function notify() { listeners.forEach(l => l()); }

// ── Background poller ──
let pollTimer: any = null;
let initialRecoveryDone = false;

async function checkActiveDeploy(): Promise<DeployState | null> {
  try {
    const res = await fetch(`${API_BASE}/api/publish/active-deploy`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` }
    });
    const data = await res.json();
    if (data.ok && data.active) {
      return {
        phase: data.status === 'success' ? 'success' : 'deploying',
        deployment_id: data.deployment_id,
        deploy_url: data.url || data.deploy_url,
        entity_count: data.entity_count,
        stages: data.stages || [],
        startedAt: data.created_on ? new Date(data.created_on).getTime() : Date.now(),
      };
    }
  } catch {}
  return null;
}

async function pollDeployStatus() {
  // If we're in deploying phase, check active-deploy for updates
  if (globalDeploy.phase === 'deploying' || globalDeploy.phase === 'exporting') {
    const active = await checkActiveDeploy();
    if (active) {
      if (active.phase === 'success') {
        globalDeploy = { ...active, phase: 'success' };
        notify();
        // Refresh pending list since entities are now deployed
        fetchPending();
      } else {
        globalDeploy = { ...globalDeploy, ...active, phase: 'deploying' };
        notify();
      }
    } else if (globalDeploy.phase === 'deploying') {
      // No active deploy found — it probably finished
      globalDeploy = { ...globalDeploy, phase: 'success' };
      notify();
      fetchPending();
    }
  } else if (!initialRecoveryDone) {
    // On first load, check if there's an active deploy we should track
    initialRecoveryDone = true;
    const active = await checkActiveDeploy();
    if (active) {
      globalDeploy = active.phase === 'success' ? { ...active, phase: 'success' } : { ...active, phase: 'deploying' };
      notify();
    }
  }

  // Also get deploy-status for the URL
  try {
    const res = await fetch(`${API_BASE}/api/publish/deploy-status`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` }
    });
    const data = await res.json();
    if (data.ok && data.url && !globalDeploy.deploy_url) {
      globalDeploy = { ...globalDeploy, deploy_url: data.url, deployment_id: data.deployment_id };
      notify();
    }
  } catch {}
}

function startPolling() {
  if (pollTimer) return;
  pollDeployStatus();
  pollTimer = setInterval(pollDeployStatus, 8000);
}

async function fetchPending(filter?: string, search?: string) {
  const params = new URLSearchParams();
  if (filter) params.set('filter', filter);
  if (search) params.set('search', search);
  params.set('limit', '50');
  try {
    const res = await fetch(`${API_BASE}/api/publish/pending?${params}`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}` }
    });
    const data = await res.json();
    if (data.ok) {
      globalPending = data.pending || [];
      globalSummary = data.summary || null;
      globalLastFetch = Date.now();
      notify();
    }
  } catch {}
}

// ── Hook ──
export function usePublish() {
  const [tick, setTick] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const filterRef = { current: '' };
  const searchRef = { current: '' };

  useEffect(() => {
    const fn = () => setTick(t => t + 1);
    listeners.push(fn);
    startPolling();
    if (globalPending.length === 0 && globalDeploy.phase === 'idle') fetchPending();
    return () => { listeners = listeners.filter(l => l !== fn); };
  }, []);

  // Counter tick every second during deploy
  useEffect(() => {
    if (globalDeploy.phase === 'exporting' || globalDeploy.phase === 'deploying') {
      setElapsed(Math.floor((Date.now() - globalDeploy.startedAt) / 1000));
      const iv = setInterval(() => {
        setElapsed(Math.floor((Date.now() - globalDeploy.startedAt) / 1000));
      }, 1000);
      return () => clearInterval(iv);
    } else {
      setElapsed(0);
    }
  }, [tick, globalDeploy.phase]);

  const load = useCallback((filter?: string, search?: string) => {
    filterRef.current = filter || '';
    searchRef.current = search || '';
    fetchPending(filter, search);
  }, []);

  const deployAction = useCallback(async (entities?: { entity_type: string; entity_slug: string }[], mode?: string) => {
    globalDeploy = { phase: 'exporting', startedAt: Date.now() };
    notify();

    try {
      const body: any = {};
      if (mode === 'all') body.mode = 'all';
      else if (entities?.length) body.entities = entities;

      const res = await fetch(`${API_BASE}/api/publish/deploy`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('gm_token') || ''}`
        },
        body: JSON.stringify(body)
      });
      const data = await res.json();

      if (data.ok) {
        globalDeploy = {
          phase: 'deploying',
          exported: data.exported,
          errors: data.errors,
          deployment_id: data.deploy?.deployment_id,
          deploy_url: data.deploy?.url,
          startedAt: globalDeploy.startedAt,
          stages: [],
        };
      } else {
        globalDeploy = { phase: 'failure', errors: data.errors || [data.error], startedAt: globalDeploy.startedAt };
      }
      notify();
      return data;
    } catch (e: any) {
      globalDeploy = { phase: 'failure', errors: [e.message], startedAt: globalDeploy.startedAt };
      notify();
      return null;
    }
  }, []);

  const resetDeploy = useCallback(() => {
    globalDeploy = { phase: 'idle', startedAt: 0 };
    initialRecoveryDone = false;
    notify();
    fetchPending(filterRef.current, searchRef.current);
  }, []);

  return {
    pending: globalPending,
    summary: globalSummary,
    deploy: globalDeploy,
    elapsed,
    load,
    deployAction,
    resetDeploy,
    lastFetch: globalLastFetch,
  };
}
