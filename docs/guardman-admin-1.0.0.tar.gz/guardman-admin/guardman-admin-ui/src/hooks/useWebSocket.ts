// GuardMan v5.2 — WebSocket Hook (Disabled)
// WebSocket is not available on the Workers plan.
// Chat works via HTTP POST + SSE (/api/orchestrator/chat).
// This hook returns a no-op connection state.

interface WSMessage {
  type: string;
  data?: any;
}

interface UseWebSocketReturn {
  messages: WSMessage[];
  connected: boolean;
  send: (message: any) => void;
  lastMessage: WSMessage | null;
}

export function useWebSocket(_path: string): UseWebSocketReturn {
  return {
    messages: [],
    connected: false,
    send: () => {},
    lastMessage: null,
  };
}

export function useAgentEvents(_eventTypes: string[]): {
  events: Array<{ type: string; data: any; timestamp: number }>;
  connected: boolean;
} {
  return { events: [], connected: false };
}
