// GuardMan Admin — Section Generator Hook
// Calls /api/cms/generate-section for individual sections.
// Supports single section generation and bulk "Generate All".
// NOTE: useRealApi throws on error (data.ok === false) and returns data.data on success.
// We NEVER check result.ok — try/catch is sufficient.

import { useState, useCallback } from 'react';
import { useApi } from './useApi';
import { useToast } from '../components/UI/Toast';

export interface SectionGenerationState {
  generating: Set<string>;
  errors: Map<string, string>;
}

export function useSectionGenerator(slug: string) {
  const { api } = useApi();
  const { showToast } = useToast();
  const [generating, setGenerating] = useState<Set<string>>(new Set());
  const [errors, setErrors] = useState<Map<string, string>>(new Map());

  const generate = useCallback(async (section: string): Promise<boolean> => {
    setGenerating(prev => new Set(prev).add(section));
    setErrors(prev => {
      const next = new Map(prev);
      next.delete(section);
      return next;
    });

    try {
      // useRealApi throws if response.ok === false
      await api('/api/cms/generate-section', {
        method: 'POST',
        body: JSON.stringify({ slug, section }),
      });
      showToast(`✅ Sección "${section}" generada`, 'success');
      return true;
    } catch (err: any) {
      const msg = err.message || 'Error desconocido';
      showToast(`❌ "${section}": ${msg}`, 'error');
      setErrors(prev => new Map(prev).set(section, msg));
      return false;
    } finally {
      setGenerating(prev => {
        const next = new Set(prev);
        next.delete(section);
        return next;
      });
    }
  }, [api, slug, showToast]);

  const generateAll = useCallback(async (sections: string[]): Promise<{ successes: string[]; failures: string[] }> => {
    setGenerating(new Set(sections));
    setErrors(new Map());

    try {
      // useRealApi returns data.data (the inner payload) on success
      const result = await api('/api/cms/generate-all-sections', {
        method: 'POST',
        body: JSON.stringify({ slug, sections }),
      });

      showToast(
        `✅ ${result.generated || 0}/${result.total || sections.length} secciones generadas`,
        (result.failures?.length || 0) === 0 ? 'success' : 'info'
      );

      if (result.failures?.length > 0) {
        const errMap = new Map<string, string>();
        for (const f of result.failures) {
          errMap.set(f.section, f.error);
        }
        setErrors(errMap);
      }

      return {
        successes: result.successes || [],
        failures: (result.failures || []).map((f: any) => f.section),
      };
    } catch (err: any) {
      showToast(`❌ Bulk error: ${err.message}`, 'error');
      return { successes: [], failures: sections };
    } finally {
      setGenerating(new Set());
    }
  }, [api, slug, showToast]);

  const isGenerating = useCallback((section: string) => generating.has(section), [generating]);
  const getError = useCallback((section: string) => errors.get(section), [errors]);

  return { generate, generateAll, isGenerating, getError, generating: generating.size > 0, errors };
}
