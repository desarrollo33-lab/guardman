// GuardMan Admin UI - API Hook (Switcher: Real / Mock)
// Set localStorage.setItem('gm_demo_mode', 'crm') to enable mock mode
// Remove it or set to '' to use real API

import { useRealApi, setToken, clearToken, getToken } from './useRealApi';
import { useMockApi } from './useMockApi';

export { setToken, clearToken, getToken };

export function useApi() {
  const isDemo = typeof window !== 'undefined' && localStorage.getItem('gm_demo_mode') === 'crm';
  const real = useRealApi();
  const mock = useMockApi();
  return isDemo ? mock : real;
}
