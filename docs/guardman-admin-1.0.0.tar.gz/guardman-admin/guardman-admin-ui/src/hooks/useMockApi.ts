// GuardMan Admin UI — Mock API Hook (CRM Demo Mode)
// Same interface as useApi but returns mock data for all CRM endpoints

import { useState, useCallback } from 'react';
import {
  MOCK_LEADS,
  MOCK_CLIENTS,
  MOCK_INTERACTIONS,
  MOCK_PROPOSALS,
  MOCK_VISITS,
  MOCK_CLIENT_SERVICES,
  MOCK_DASHBOARD_RESPONSE,
  MOCK_PIPELINE_RESPONSE,
} from '../mocks/crm-data';

export function useMockApi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const api = useCallback(async <T = any>(path: string, options?: RequestInit, suffix?: string): Promise<T> => {
    setLoading(true);
    setError(null);

    // Simulate network latency
    await new Promise(r => setTimeout(r, 300));

    try {
      const method = options?.method || 'GET';
      const body = options?.body ? JSON.parse(options.body as string) : null;

      // ===== DASHBOARD =====
      if (path === '/api/crm/dashboard') {
        return MOCK_DASHBOARD_RESPONSE as unknown as T;
      }

      // ===== PIPELINE =====
      if (path === '/api/crm/pipeline') {
        return MOCK_PIPELINE_RESPONSE as unknown as T;
      }

      // ===== LEADS LIST =====
      if (path === '/api/crm/leads' && method === 'GET') {
        const url = new URL('https://x.com' + path + (suffix || ''));
        const status = url.searchParams.get('status');
        let results = [...MOCK_LEADS];
        if (status) results = results.filter(l => l.status === status);
        return { data: results, total: results.length } as unknown as T;
      }

      // ===== LEAD CREATE =====
      if (path === '/api/crm/leads' && method === 'POST') {
        const newLead = { ...body, id: Date.now(), slug: 'ld-' + Math.random().toString(36).slice(2, 8), created_at: new Date().toISOString() };
        MOCK_LEADS.unshift(newLead as any);
        return newLead as unknown as T;
      }

      // ===== LEAD GET/UPDATE =====
      const leadIdMatch = path.match(/^\/api\/crm\/leads\/(\d+)$/);
      if (leadIdMatch) {
        const leadId = parseInt(leadIdMatch[1]);
        const lead = MOCK_LEADS.find(l => l.id === leadId);
        if (!lead) throw new Error('Lead not found');

        if (method === 'GET') {
          const interactions = MOCK_INTERACTIONS.filter(i => i.lead_id === leadId);
          const proposals = MOCK_PROPOSALS.filter(p => p.lead_id === leadId);
          return {
            lead,
            interactions,
            proposals,
            intel: { topCompetitors: [], ourPositions: [], contentGaps: [] },
          } as unknown as T;
        }

        if (method === 'PUT') {
          Object.assign(lead, body);
          return lead as unknown as T;
        }
      }

      // ===== LEAD INTERACTIONS =====
      const interactMatch = path.match(/^\/api\/crm\/leads\/(\d+)\/interactions$/);
      if (interactMatch) {
        const leadId = parseInt(interactMatch[1]);
        if (method === 'GET') {
          return MOCK_INTERACTIONS.filter(i => i.lead_id === leadId) as unknown as T;
        }
        if (method === 'POST') {
          const newInteraction = { ...body, id: Date.now(), lead_id: leadId, created_at: new Date().toISOString() };
          MOCK_INTERACTIONS.unshift(newInteraction as any);
          return newInteraction as unknown as T;
        }
      }

      // ===== LEAD PROPOSALS =====
      const proposalMatch = path.match(/^\/api\/crm\/leads\/(\d+)\/proposals$/);
      if (proposalMatch) {
        const leadId = parseInt(proposalMatch[1]);
        if (method === 'GET') {
          return MOCK_PROPOSALS.filter(p => p.lead_id === leadId) as unknown as T;
        }
        if (method === 'POST') {
          const newProposal = { ...body, id: Date.now(), lead_id: leadId, slug: 'cot-' + Date.now(), created_at: new Date().toISOString() };
          MOCK_PROPOSALS.unshift(newProposal as any);
          return newProposal as unknown as T;
        }
      }

      // ===== ALL PROPOSALS =====
      if (path === '/api/crm/proposals' && method === 'GET') {
        return [...MOCK_PROPOSALS] as unknown as T;
      }

      // ===== CLIENTS LIST =====
      if (path === '/api/crm/clients' && method === 'GET') {
        const url = new URL('https://x.com' + path + (suffix || ''));
        const status = url.searchParams.get('status');
        let results = [...MOCK_CLIENTS];
        if (status) results = results.filter(c => c.status === status);
        return results as unknown as T;
      }

      // ===== CLIENT CREATE =====
      if (path === '/api/crm/clients' && method === 'POST') {
        const newClient = { ...body, id: 1000 + MOCK_CLIENTS.length, slug: 'cl-' + Math.random().toString(36).slice(2, 8), created_at: new Date().toISOString() };
        MOCK_CLIENTS.unshift(newClient as any);
        return newClient as unknown as T;
      }

      // ===== CLIENT GET/UPDATE =====
      const clientIdMatch = path.match(/^\/api\/crm\/clients\/(\d+)$/);
      if (clientIdMatch) {
        const clientId = parseInt(clientIdMatch[1]);
        const client = MOCK_CLIENTS.find(c => c.id === clientId);
        if (!client) throw new Error('Client not found');

        if (method === 'GET') {
          const services = MOCK_CLIENT_SERVICES.filter(s => s.client_id === clientId);
          const interactions = MOCK_INTERACTIONS.filter(i => i.client_id === clientId);
          return { client, services, interactions } as unknown as T;
        }

        if (method === 'PUT') {
          Object.assign(client, body);
          return client as unknown as T;
        }
      }

      // ===== SERVICES & LOCATIONS (for dropdowns) =====
      if (path === '/api/services') {
        return [
          { slug: 'guardias-de-seguridad', name: 'Guardias de Seguridad' },
          { slug: 'cctv-videovigilancia', name: 'CCTV Videovigilancia' },
          { slug: 'control-de-accesos', name: 'Control de Accesos' },
          { slug: 'escoltas-privados', name: 'Escoltas Privados' },
          { slug: 'monitoreo-24-7', name: 'Monitoreo 24/7' },
          { slug: 'seguridad-eventos', name: 'Seguridad Eventos' },
          { slug: 'seguridad-industrial', name: 'Seguridad Industrial' },
          { slug: 'auditoria-seguridad', name: 'Auditoría de Seguridad' },
          { slug: 'guard-pod', name: 'Guard Pod' },
        ] as unknown as T;
      }

      if (path === '/api/locations') {
        return [
          { slug: 'las-condes', name: 'Las Condes' },
          { slug: 'vitacura', name: 'Vitacura' },
          { slug: 'lo-barnechea', name: 'Lo Barnechea' },
          { slug: 'santiago-centro', name: 'Santiago Centro' },
          { slug: 'huechuraba', name: 'Huechuraba' },
          { slug: 'quilicura', name: 'Quilicura' },
          { slug: 'la-reina', name: 'La Reina' },
          { slug: 'conchali', name: 'Conchalí' },
          { slug: 'pudahuel', name: 'Pudahuel' },
          { slug: 'renca', name: 'Renca' },
          { slug: 'lampa', name: 'Lampa' },
          { slug: 'la-pintana', name: 'La Pintana' },
          { slug: 'los-andes', name: 'Los Andes' },
          { slug: 'san-felipe', name: 'San Felipe' },
        ] as unknown as T;
      }

      // ===== HEALTH =====
      if (path === '/health') {
        return { ok: true, version: 'mock' } as unknown as T;
      }

      console.warn('[MockApi] Unhandled path:', path, method);
      throw new Error('Mock not implemented for ' + path);
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return { api, loading, error };
}
