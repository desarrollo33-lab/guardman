// GuardMan Admin UI - API Hook (Real)
import { useState, useCallback } from 'react';

const API_BASE = 'https://guardman.oficinadesarrollo33.workers.dev';

let authToken: string | null = localStorage.getItem('gm_token');

console.log('[useApi] Initial authToken:', authToken ? 'SET' : 'NULL');

export function setToken(token: string) {
  console.log('[useApi] setToken called:', token ? 'SET' : 'NULL');
  authToken = token;
  localStorage.setItem('gm_token', token);
  console.log('[useApi] After setToken, authToken:', authToken ? 'SET' : 'NULL');
}

export function clearToken() {
  authToken = null;
  localStorage.removeItem('gm_token');
}

export function getToken(): string | null {
  const result = authToken || localStorage.getItem('gm_token');
  console.log('[useApi] getToken:', result ? 'SET' : 'NULL');
  return result;
}

export function useRealApi() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const api = useCallback(async <T = any>(path: string, options?: RequestInit, suffix?: string): Promise<T> => {
    setLoading(true);
    setError(null);
    try {
      const headers: any = { ...options?.headers };
      const isFormData = options?.body instanceof FormData;
      if (!isFormData) headers['Content-Type'] = 'application/json';
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
      
      const url = `${API_BASE}${path}${suffix || ''}`;
      const res = await fetch(url, { ...options, headers });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'API Error');
      return data.data as T;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return { api, loading, error };
}
