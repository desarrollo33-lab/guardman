# 🧪 Demo CRM — Botón de Carga/Datos Mock

## Cómo usar (3 pasos)

### 1. Inicia el servidor
```bash
cd guardman-admin-ui
npm run dev
```

### 2. Abre el CRM
Ve a `http://localhost:5173/admin/` e inicia sesión.

### 3. Activa los datos demo
En la pestaña **CRM**, verás un botón azul en la esquina superior derecha:

> **🧪 Cargar Demo**

Haz click → se abre un panel con el resumen de datos → click **"✅ Activar Demo"**

La página se recargará automáticamente y verás:
- Un banner naranja: `🧪 MODO DEMO — Datos de prueba`
- El botón cambia a: `🧪 Demo` + `❌ Desactivar`

### 4. Desactivar
Click en **❌ Desactivar** para volver a datos reales del servidor.

---

## Datos incluidos

| Entidad | Cantidad |
|---------|----------|
| Leads | 12 |
| Clientes | 5 |
| Interacciones | 8 |
| Propuestas/Cotizaciones | 4 |
| Visitas técnicas | 3 |
| Servicios contratados | 5 |

### Pipeline

| Estado | Leads | Valor |
|--------|-------|-------|
| 🆕 Nuevo | 3 | $8.1M |
| 📞 Contactado | 2 | $4.75M |
| 🏢 Visita Técnica | 1 | $3.2M |
| 📋 Cotización Enviada | 2 | $8.7M |
| 🤝 Negociación | 1 | $2.8M |
| ✅ Ganado | 1 | $1.5M |
| ❌ Perdido | 1 | $2.2M |

**MRR Clientes Activos:** $13.200.000

---

## Qué funciona en modo demo

- ✅ Dashboard con KPIs y embudo
- ✅ Mi Día (urgentes, reintentar, visitas, seguimientos)
- ✅ Pipeline Kanban con leads reales
- ✅ Lista de clientes con MRR
- ✅ Detalle de leads (interacciones, propuestas, intel)
- ✅ Detalle de clientes (servicios, renovaciones)
- ✅ Crear nuevo lead (se guarda en memoria)
- ✅ Crear interacciones
- ✅ Crear propuestas/cotizaciones
- ✅ Mover leads entre etapas

---

## Limitaciones

- Los cambios se guardan solo en memoria (se pierden al recargar)
- No envía emails/WhatsApp reales
- No requiere autenticación real

---

## Alternativa: LocalStorage manual

```js
// Activar
localStorage.setItem('gm_demo_mode', 'crm');
location.reload();

// Desactivar
localStorage.removeItem('gm_demo_mode');
location.reload();
```
