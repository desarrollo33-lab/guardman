#!/bin/bash
# Test del ciclo completo: guardar → cerrar → reabrir → recuperar
API="https://guardman.oficinadesarrollo33.workers.dev"
TMP=/tmp/guardman-persistence
mkdir -p $TMP

passed=0
failed=0

ok() { echo "  ✓ $1"; passed=$((passed+1)); }
ko() { echo "  ✗ $1"; failed=$((failed+1)); }

# ============================================================
# SETUP: limpiar
# ============================================================
echo "=== SETUP: limpieza ==="
cd "C:/Users/56930/OneDrive/Escritorio/guardman-admin"
npx wrangler d1 execute guardman-seo --command="DELETE FROM ceo_questionnaire_services; DELETE FROM ceo_questionnaire_answers; DELETE FROM ceo_questionnaire_audit; DELETE FROM ceo_questionnaire_session; DELETE FROM ceo_questionnaire_conversation; UPDATE ceo_questionnaire_sections SET status = 'pending', completed_at = NULL;" --remote > /dev/null 2>&1
echo "  Limpieza completa"

# ============================================================
# TEST 1: Persistencia de cada tipo de campo
# ============================================================
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  TEST 1: Persistencia de cada tipo de campo"
echo "═══════════════════════════════════════════════════════════"

# 1.1 - free_text
cat > $TMP/t1.json <<'JSON_EOF'
{
  "question_id": "id_01",
  "section_id": "identidad",
  "free_text": "GuardMan es la empresa que cuida a tu familia mientras tú no estás",
  "notes": "Esta frase se la oí a un cliente el mes pasado",
  "confidence": 5
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t1.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar free_text" || ko "Guardar free_text: $res"

# 1.2 - scale_value
cat > $TMP/t2.json <<'JSON_EOF'
{
  "question_id": "srv_04",
  "section_id": "servicios",
  "selected_values": ["Sí, una región adicional"]
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t2.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar single_choice (selected_values)" || ko "Guardar single_choice: $res"

# 1.3 - scale_value
cat > $TMP/t3.json <<'JSON_EOF'
{
  "question_id": "srv_03",
  "section_id": "servicios",
  "selected_values": ["Las Condes"]
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t3.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar single_choice" || ko "Guardar single_choice: $res"

# 1.4 - scale_1_10
cat > $TMP/t4.json <<'JSON_EOF'
{
  "question_id": "id_06",
  "section_id": "identidad",
  "free_text": "El error más común es contratar por precio, sin verificar si los guardias están certificados",
  "confidence": 5
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t4.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar scale_1_10" || ko "Guardar scale_1_10: $res"

# 1.5 - binary
cat > $TMP/t5.json <<'JSON_EOF'
{
  "question_id": "srv_09",
  "section_id": "servicios",
  "binary_value": 1,
  "free_text": "Sí, son más de 50 clientes activos"
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t5.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar binary" || ko "Guardar binary: $res"

# 1.6 - comparison
cat > $TMP/t6.json <<'JSON_EOF'
{
  "question_id": "dif_04",
  "section_id": "diferenciacion",
  "comparison_choice": "B",
  "comparison_why": "Porque conocemos a cada familia"
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t6.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar comparison" || ko "Guardar comparison: $res"

# 1.7 - multiple_choice
cat > $TMP/t7.json <<'JSON_EOF'
{
  "question_id": "srv_01",
  "section_id": "servicios",
  "selected_values": ["Las Condes", "Vitacura", "Lo Barnechea", "Providencia"]
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t7.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar multiple_choice" || ko "Guardar multiple_choice: $res"

# 1.8 - ranking
cat > $TMP/t8.json <<'JSON_EOF'
{
  "question_id": "srv_02",
  "section_id": "servicios",
  "selected_values": ["Las Condes, Vitacura y Lo Barnechea", "Providencia, Ñuñoa y Santiago Centro", "La Florida, Macul, Peñalolén"]
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t8.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar ranking" || ko "Guardar ranking: $res"

# 1.9 - tags
cat > $TMP/t9.json <<'JSON_EOF'
{
  "question_id": "id_04",
  "section_id": "identidad",
  "free_text": "Absolutamente, vale la pena. La tranquilidad no tiene precio.",
  "tags": ["objeción", "precio", "tranquilidad"],
  "confidence": 5
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t9.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Guardar tags" || ko "Guardar tags: $res"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  TEST 2: Recuperar respuestas después de 'cerrar'"
echo "  (simulamos: el usuario cierra el navegador y vuelve)"
echo "═══════════════════════════════════════════════════════════"

# 2.1 - GET principal debe devolver todas las respuestas
res=$(curl -s $API/api/cuestionario-ceo)
saved=$(echo "$res" | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
print(len(d['answers']))
")
[ "$saved" -ge "9" ] && ok "9+ respuestas en GET principal" || ko "Solo $saved respuestas guardadas"

# 2.2 - GET por sección
res=$(curl -s $API/api/cuestionario-ceo/section/servicios)
recuperadas=$(echo "$res" | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
print(sum(1 for q in d['questions'] if q.get('answer')))
")
[ "$recuperadas" -ge "5" ] && ok "5+ respuestas recuperadas en sección servicios" || ko "Solo $recuperadas recuperadas"

# 2.3 - Verificar contenido específico (id_01 debe tener el free_text)
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='id_01':
        print(a.get('free_text',''))
        break
")
[ -n "$val" ] && ok "id_01 free_text recuperado: '$val'" || ko "id_01 no se recuperó"

# 2.4 - Verificar ranking (srv_02 debe tener 3 elementos)
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='srv_02':
        print(len(a.get('selected_values',[])))
        break
")
[ "$val" = "3" ] && ok "Ranking srv_02 con 3 elementos recuperado" || ko "Ranking srv_02 recuperado con $val elementos"

# 2.5 - Verificar binary (srv_09 debe tener binary_value=1)
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='srv_09':
        print(a.get('binary_value'))
        break
")
[ "$val" = "1" ] && ok "Binary srv_09 = 1 recuperado" || ko "Binary srv_09 = $val"

# 2.6 - Verificar comparison
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='dif_04':
        print(a.get('comparison_choice'))
        break
")
[ "$val" = "B" ] && ok "Comparison dif_04 = B recuperado" || ko "Comparison dif_04 = $val"

# 2.7 - Verificar scale_value
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='srv_03':
        print(a.get('selected_values',[None])[0])
        break
")
[ "$val" = "Las Condes" ] && ok "Single choice srv_03 = Las Condes recuperado" || ko "srv_03 = $val"

# 2.8 - Verificar tags
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='id_04':
        print(len(a.get('tags',[])))
        break
")
[ "$val" = "3" ] && ok "Tags id_04 = 3 elementos recuperado" || ko "Tags = $val"

# 2.9 - Verificar notas (id_01 debe tener notes)
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='id_01':
        print(a.get('notes','')[:30])
        break
")
[ -n "$val" ] && ok "Notes id_01 recuperado: '$val...'" || ko "Notes id_01 vacío"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  TEST 3: Upsert (modificar respuesta existente)"
echo "═══════════════════════════════════════════════════════════"

# Modificar id_01
cat > $TMP/t10.json <<'JSON_EOF'
{
  "question_id": "id_01",
  "section_id": "identidad",
  "free_text": "GuardMan es tu escudo invisible",
  "notes": "Cambié la respuesta",
  "confidence": 4
}
JSON_EOF
res=$(curl -s -X POST $API/api/cuestionario-ceo/answer \
  -H "Content-Type: application/json; charset=utf-8" \
  --data-binary @$TMP/t10.json)
ok_test=$(echo "$res" | python3 -c "import sys,json;print(json.load(sys.stdin)['ok'])")
[ "$ok_test" = "True" ] && ok "Modificar respuesta existente (UPSERT)" || ko "Modificar: $res"

# Verificar que el cambio se guardó
val=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
for a in d['answers']:
    if a['question_id']=='id_01':
        print(a.get('free_text',''))
        break
")
[ "$val" = "GuardMan es tu escudo invisible" ] && ok "Cambio persistido: '$val'" || ko "No se actualizó: '$val'"

# Verificar que NO se duplicó
count=$(curl -s $API/api/cuestionario-ceo | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
print(sum(1 for a in d['answers'] if a['question_id']=='id_01'))
")
[ "$count" = "1" ] && ok "No se duplicó (count=1)" || ko "Duplicado! count=$count"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  TEST 4: Section endpoint devuelve respuestas embebidas"
echo "═══════════════════════════════════════════════════════════"

# Esto es lo que el HTML usa al cargar: /api/cuestionario-ceo/section/:id
# Cada pregunta debe traer su `answer` field si tiene respuesta

for sid in identidad servicios comercial diferenciacion; do
  res=$(curl -s $API/api/cuestionario-ceo/section/$sid)
  count_with_answer=$(echo "$res" | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
print(sum(1 for q in d['questions'] if q.get('answer')))
")
  total=$(echo "$res" | python3 -c "import sys,json;d=json.load(sys.stdin)['data'];print(len(d['questions']))")
  ok "Sección $sid: $count_with_answer/$total preguntas con respuesta embebida"
done

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  TEST 5: El estado del cuestionario refleja avance"
echo "═══════════════════════════════════════════════════════════"

res=$(curl -s $API/api/cuestionario-ceo)
stats=$(echo "$res" | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']['stats']
print(f\"answered={d['answered']}, completion={d['completion_pct']}%\")
")
echo "  Stats: $stats"
echo "$stats" | grep -q "answered=" && ok "Stats globales disponibles" || ko "Stats faltantes"

# Verificar que las secciones reflejan avance
res=$(curl -s $API/api/cuestionario-ceo/sections)
in_progress=$(echo "$res" | python3 -c "
import sys,json
d=json.load(sys.stdin)['data']
print(sum(1 for s in d if s.get('status')=='in_progress'))
")
[ "$in_progress" -ge "1" ] && ok "Sección marcada como in_progress" || ko "Ninguna sección in_progress"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  RESUMEN"
echo "═══════════════════════════════════════════════════════════"
total=$((passed+failed))
echo "  Total: $total"
echo "  ✓ Pasados: $passed"
echo "  ✗ Fallados: $failed"
[ "$failed" -eq "0" ] && echo "  🎉 TODOS PASARON" || echo "  ⚠ Hay fallos"

# ============================================================
# LIMPIEZA
# ============================================================
echo ""
echo "=== LIMPIEZA ==="
cd "C:/Users/56930/OneDrive/Escritorio/guardman-admin"
npx wrangler d1 execute guardman-seo --command="DELETE FROM ceo_questionnaire_services; DELETE FROM ceo_questionnaire_answers; DELETE FROM ceo_questionnaire_audit; DELETE FROM ceo_questionnaire_session; DELETE FROM ceo_questionnaire_conversation; UPDATE ceo_questionnaire_sections SET status = 'pending', completed_at = NULL;" --remote > /dev/null 2>&1
echo "  Base de datos limpia"
rm -f "C:/Users/56930/OneDrive/Escritorio/guardman-admin/qs.json" "C:/Users/56930/OneDrive/Escritorio/guardman-admin/seo.json" "C:/Users/56930/OneDrive/Escritorio/guardman-admin/dist.json" 2>/dev/null

exit $failed
