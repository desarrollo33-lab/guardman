# Plan de Rediseño: Media Editor v4
## De monolito inusable a sistema modular intuitivo

**Fecha:** 2026-05-11  
**Estado actual:** Media Editor v3 - Monolito de 1883 líneas, 74 hooks, 13 problemas críticos  
**Objetivo:** v4 - Modular, 2 paneles, flujos de 1-2 clics, HTTP 200 OK  
**Tiempo estimado:** 3-4 sesiones + fixes operativos  

---

## 1. DIAGNÓSTICO: 13 PROBLEMAS CRÍTICOS

### P1: Monolito de 1883 líneas
**Síntoma:** Todo en `MediaEditor.tsx`. Grid, preview, AI tools, batch, picker, lightbox, history, upload, SEO, asignación - todo en un archivo.  
**Impacto:** Imposible de mantener. Un bug en el grid rompe el batch. Un cambio en SEO afecta a AI.  
**Fix:** Separar en 6 componentes independientes.

### P2: 74 hooks - Estado explosivo
**Síntoma:** `useState` para cada campo de formulario, cada toggle, cada panel. Re-renders en cascada.  
**Impacto:** UI lenta. Cada tipeo en un input re-renderiza TODO el componente (1883 líneas).  
**Fix:** Usar `useReducer` para estado global del editor + `React.memo` para sub-componentes.

### P3: Toggle Biblioteca/Staff escondido
**Síntoma:** Botón naranja de 80px en la esquina superior derecha del panel izquierdo.  
**Impacto:** El usuario no sabe que existe modo Staff. Nunca lo encuentra.  
**Fix:** Tabs principales visibles en la parte superior (como navegación de app).

### P4: 3 paneles horizontales
**Síntoma:** Grid (384px) | Preview (flex) | AI Tools (288px). Total: 1366px mínimo.  
**Impacto:** En laptop 1366x768, el preview se comprime a 400px. En 1280x800, es inusable.  
**Fix:** 2 paneles: Grid (40%) | Workspace (60%). AI tools integrados en workspace.

### P5: AI Tools panel SIEMPPE visible
**Síntoma:** Panel derecho de 288px con prompts, categorías, batch, historia - SIEMPRE renderizado.  
**Impacto:** Ocupa 20% de la pantalla para algo que se usa 5% del tiempo.  
**Fix:** AI Tools como tab dentro del panel de preview. Se abre solo cuando se necesita.

### P6: Upload de staff escondido
**Síntoma:** Botón "⬆ Subir foto" que abre un formulario colapsado con 4 campos.  
**Impacto:** Nadie lo ve. El formulario colapsado parece decoración.  
**Fix:** Botón "Subir" prominente en la parte superior del grid. Formulario en modal centrado.

### P7: Edición img2img requiere 3 clics
**Síntoma:** Seleccionar foto → Tab "AI" → Scrollear a "Herramientas sobre imagen" → Click "Generar variante".  
**Impacto:** Flujo de 4 pasos para algo que debería ser 1 click.  
**Fix:** Botón "✨ Editar" directo en cada thumbnail de staff. Abre modal de edición dedicado.

### P8: No hay jerarquía visual
**Síntoma:** Todo es gris `#1f2937` sobre gris `#111827`. Sin color para distinguir estados.  
**Impacto:** El usuario no distingue qué es interactivo vs decorativo. No sabe qué está seleccionado.  
**Fix:** Sistema de colores semántico: Azul=acción, Naranja=staff, Verde=éxito, Rojo=error, Morado=IA.

### P9: Picker mode acoplado a full mode
**Síntoma:** Picker y Full comparten el mismo componente con condicionales `mode === 'picker'`.  
**Impacto:** Cambios en picker rompen full. Código difícil de seguir.  
**Fix:** `MediaPicker.tsx` componente separado. Solo grid + click.

### P10: Batch panel siempre renderizado
**Síntoma:** `BatchPanel` con checkboxes, progress bar, concurrency slider - siempre en el DOM.  
**Impacto:** Carga visual innecesaria. El 95% de las sesiones no usan batch.  
**Fix:** Batch como tab separado "📦 Batch" en la navegación principal.

### P11: Admin devuelve HTTP 307 (redirect)
**Síntoma:** `curl -I https://guardman.oficinadesarrollo33.workers.dev/admin/index.html` devuelve HTTP 307 en vez de 200.  
**Impacto:** El navegador puede cachear el redirect o no cargar el admin correctamente.  
**Fix:** Verificar configuración de `ASSETS` binding en `wrangler.jsonc`. Asegurar que `run_worker_first: true` sirva el admin correctamente.

### P12: 0 fotos staff en D1
**Síntoma:** `GET /api/media/staff-raw` devuelve 0 resultados.  
**Impacto:** El panel "📸 Staff" aparece completamente vacío. El usuario no entiende qué hacer.  
**Fix:** Agregar fotos de ejemplo o seed data, o instrucciones claras de cómo subir la primera foto.

### P13: Potencial cache de bundle viejo
**Síntoma:** El navegador puede tener cacheado `main-DUZI9km3.js` (build anterior).  
**Impacto:** El usuario ve una versión vieja del Media Editor sin las funcionalidades nuevas.  
**Fix:** Agregar cache-busting con hash en el nombre del bundle (ya implementado) + headers `Cache-Control: no-cache` para `index.html`.

---

## 2. NUEVA ARQUITECTURA: 6 COMPONENTES

```
📁 src/components/Media/
├── MediaEditor.tsx           (orquestador, ~150 líneas)
├── MediaPicker.tsx           (selector rápido, ~200 líneas) ← NUEVO
├── panels/
│   ├── MediaGrid.tsx         (grid + filtros + upload, ~250 líneas)
│   ├── MediaWorkspace.tsx    (preview + tabs + AI, ~300 líneas)
│   ├── StaffPanel.tsx        (grid staff + upload modal, ~200 líneas) ← NUEVO
│   ├── GeneratePanel.tsx     (generación desde cero, ~200 líneas)
│   └── BatchPanel.tsx        (batch generation, ~150 líneas)
└── shared/
    ├── MediaCard.tsx         (thumbnail individual, ~80 líneas)
    ├── Lightbox.tsx          (visor fullscreen, ~100 líneas)
    ├── CompareSlider.tsx     (comparador antes/después, ~80 líneas)
    ├── AssignForm.tsx        (asignación a servicios, ~100 líneas)
    ├── SeoEditor.tsx         (editor de metadatos SEO, ~150 líneas)
    └── UploadModal.tsx       (modal de upload con formulario, ~150 líneas)
```

### MediaEditor.tsx (orquestador)
```tsx
// Solo orquesta qué panel mostrar
export function MediaEditor() {
  const [activeTab, setActiveTab] = useState<'biblioteca' | 'staff' | 'generar' | 'batch'>('biblioteca');
  const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
  
  return (
    <div className="flex flex-col h-full">
      <TopNav activeTab={activeTab} onChange={setActiveTab} />
      {activeTab === 'biblioteca' && <BibliotecaView selected={selectedMedia} onSelect={setSelectedMedia} />}
      {activeTab === 'staff' && <StaffView selected={selectedMedia} onSelect={setSelectedMedia} />}
      {activeTab === 'generar' && <GenerateView />}
      {activeTab === 'batch' && <BatchView />}
    </div>
  );
}
```

### MediaPicker.tsx (selector rápido, SEPARADO)
```tsx
// Componente dedicado para CMS
export function MediaPicker({ onSelect, onClose }: { onSelect: (url: string) => void; onClose: () => void }) {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  
  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center">
      <div className="bg-gray-900 rounded-xl w-[800px] h-[600px] flex flex-col">
        <header>Búsqueda + filtros</header>
        <MediaGrid items={items} onSelect={onSelect} mode="picker" />
        <footer>Cancelar / Seleccionar</footer>
      </div>
    </div>
  );
}
```

---

## 3. NUEVO LAYOUT: 2 PANELES

### Vista Biblioteca (default)

```
┌─────────────────────────────────────────────────────────────────┐
│  🏠 Inicio    📁 Biblioteca    📸 Staff    🎨 Generar    📦 Batch│  ← TopNav
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌────────────────────────┐  ┌──────────────────────────────┐  │
│  │  🔍 Buscar...          │  │  [Preview de imagen]         │  │
│  │  [Filtros ▼] [⬆ Subir] │  │                              │  │
│  │                        │  │  ┌────────────────────────┐  │  │
│  │  ┌──┐ ┌──┐ ┌──┐ ┌──┐  │  │  │  📋 Info  🔍 SEO  ✨ AI │  │  │
│  │  │🖼│ │🖼│ │🖼│ │🖼│  │  │  │                        │  │  │
│  │  └──┘ └──┘ └──┘ └──┘  │  │  │  [contenido del tab]   │  │  │
│  │                        │  │  │                        │  │  │
│  │  ┌──┐ ┌──┐ ┌──┐ ┌──┐  │  │  └────────────────────────┘  │  │
│  │  │🖼│ │🖼│ │🖼│ │🖼│  │  │                              │  │
│  │  └──┘ └──┘ └──┘ └──┘  │  │                              │  │
│  │                        │  │                              │  │
│  │  Página 1 de 5        │  │                              │  │
│  └────────────────────────┘  └──────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Vista Staff (dedicada)

```
┌─────────────────────────────────────────────────────────────────┐
│  🏠 Inicio    📁 Biblioteca    📸 Staff    🎨 Generar    📦 Batch│
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  [⬆ Subir foto del personal]  ← Botón prominente, arriba        │
│                                                                 │
│  🔍 Buscar por nombre...    📍 Ubicación    📅 Fecha            │
│                                                                 │
│  ┌────────────────────────┐  ┌──────────────────────────────┐  │
│  │  ┌──┐ ┌──┐ ┌──┐ ┌──┐  │  │  👤 Juan Pérez            │  │
│  │  │👤│ │👤│ │👤│ │👤│  │  │  📍 Huechuraba            │  │
│  │  │  │ │✨│ │  │ │  │  │  │  📅 2026-05-10            │  │
│  │  └──┘ └──┘ └──┘ └──┘  │  │                             │  │
│  │                        │  │  [Preview grande]           │  │
│  │  Leyenda:              │  │                             │  │
│  │  🟠 = Staff  🔵 = AI   │  │  [✨ Editar con IA]        │  │
│  │                        │  │  [🗑 Eliminar]             │  │
│  └────────────────────────┘  └──────────────────────────────┘  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Vista Generar (dedicada)

```
┌─────────────────────────────────────────────────────────────────┐
│  🏠 Inicio    📁 Biblioteca    📸 Staff    🎨 Generar    📦 Batch│
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌───────────────────────────────────────────────────────────┐ │
│  │  CAPA 1: Style Guide GuardMan (automático, colapsado)    │ │
│  ├───────────────────────────────────────────────────────────┤ │
│  │  CAPA 2: Categoría [Guard Pod ▼]  Prompt [Hero ▼]        │ │
│  ├───────────────────────────────────────────────────────────┤ │
│  │  CAPA 3: Instrucciones adicionales [________________]    │ │
│  ├───────────────────────────────────────────────────────────┤ │
│  │  Modelo [Nano Banana 2 ▼]  Tamaño [16:9 ▼]               │ │
│  │  [🎨 Generar imagen]                                     │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                 │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                         │
│  │      │ │      │ │      │ │      │  ← Resultados            │
│  └──────┘ └──────┘ └──────┘ └──────┘                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. FLUJOS DE USUARIO SIMPLIFICADOS

### Flujo A: Subir foto del staff (ahora: 2 clics)
```
Antes (v3):
1. Click "📸 Staff" (toggle escondido)
2. Click "⬆ Subir foto" (botón pequeño)
3. Llenar 4 campos en formulario colapsado
4. Seleccionar archivo
= 4 pasos, 10 segundos

Después (v4):
1. Click "📸 Staff" (tab visible)
2. Click "[⬆ Subir foto del personal]" (botón grande arriba)
3. Modal centrado con formulario
= 2 pasos, 5 segundos
```

### Flujo B: Editar foto con Style Guide (ahora: 2 clics)
```
Antes (v3):
1. Seleccionar foto
2. Click tab "🤖 Editar con IA"
3. Scrollear a "Variante (img2img)"
4. Escribir prompt
5. Ajustar strength
6. Click "🔄 Generar variante"
= 6 pasos, 15 segundos

Después (v4):
1. Hover sobre foto → click "✨ Editar"
2. Modal de edición se abre con foto original + controles
3. Seleccionar categoría + escribir instrucciones
4. Click "✨ Generar"
= 3 pasos, 8 segundos
```

### Flujo C: Asignar imagen a servicio (ahora: 1 click)
```
Antes (v3):
1. Seleccionar imagen
2. Tab "📋 Info"
3. Scrollear a "Asignaciones"
4. Select entity_type
5. Select entity_slug
6. Select usage
7. Click "Asignar"
= 7 pasos

Después (v4):
1. Click botón "🔗 Asignar" en el preview
2. Dropdown rápido: Servicio + uso
3. Click "Asignar"
= 3 pasos
```

---

## 5. ESPECIFICACIÓN TÉCNICA

### 5.1 Estado global con useReducer

```typescript
interface MediaEditorState {
  activeTab: 'biblioteca' | 'staff' | 'generar' | 'batch';
  selectedId: number | null;
  searchQuery: string;
  filters: { category?: string; mediaType?: 'image' | 'video'; staffName?: string; location?: string };
  uploadModal: { open: boolean; mode: 'generic' | 'staff' };
  editModal: { open: boolean; mediaId: number | null; sourceUrl: string };
  lightbox: { open: boolean; url: string };
  aiState: {
    generating: boolean;
    model: string;
    strength: number;
    guidanceScale: number;
    category: string;
    promptId: string;
    userPrompt: string;
    results: Array<{ url: string; width: number; height: number }>;
  };
}

type Action =
  | { type: 'SET_TAB'; tab: MediaEditorState['activeTab'] }
  | { type: 'SELECT_MEDIA'; id: number | null }
  | { type: 'SET_SEARCH'; query: string }
  | { type: 'SET_FILTER'; key: string; value: string | undefined }
  | { type: 'OPEN_UPLOAD'; mode: 'generic' | 'staff' }
  | { type: 'CLOSE_UPLOAD' }
  | { type: 'OPEN_EDIT'; mediaId: number; sourceUrl: string }
  | { type: 'CLOSE_EDIT' }
  | { type: 'OPEN_LIGHTBOX'; url: string }
  | { type: 'CLOSE_LIGHTBOX' }
  | { type: 'AI_START_GENERATING' }
  | { type: 'AI_SET_RESULTS'; results: MediaEditorState['aiState']['results'] }
  | { type: 'AI_SET_PARAM'; key: string; value: any }
  | { type: 'AI_RESET' };
```

### 5.2 Navegación por tabs (TopNav)

```tsx
const TABS = [
  { id: 'biblioteca', label: '📁 Biblioteca', description: 'Todas las imágenes y videos' },
  { id: 'staff', label: '📸 Staff', description: 'Fotos del personal de GuardMan' },
  { id: 'generar', label: '🎨 Generar', description: 'Crear imágenes con IA' },
  { id: 'batch', label: '📦 Batch', description: 'Generar múltiples imágenes' },
] as const;
```

### 5.3 MediaCard (thumbnail optimizado)

```tsx
interface MediaCardProps {
  item: MediaItem;
  selected: boolean;
  onSelect: (item: MediaItem) => void;
  onEdit?: (item: MediaItem) => void;      // Solo para staff
  onDelete?: (item: MediaItem) => void;
  mode: 'grid' | 'picker';
}

// Hover actions: aparecen sobre la thumbnail
// - Grid mode: [👁 Ver] [✨ Editar] [🔗 Asignar]
// - Picker mode: [✓ Seleccionar]
```

### 5.4 UploadModal (centrado, prominente)

```tsx
interface UploadModalProps {
  open: boolean;
  mode: 'generic' | 'staff';
  onClose: () => void;
  onUpload: (formData: FormData) => Promise<void>;
}

// Staff mode: 3 campos obligatorios (nombre, ubicación, archivo)
// Generic mode: 1 campo (archivo) + categoría opcional
```

### 5.5 EditModal (dedicado a img2img)

```tsx
interface EditModalProps {
  open: boolean;
  sourceItem: MediaItem;        // Foto original
  onClose: () => void;
  onGenerate: (params: GenerateParams) => Promise<void>;
  onSave: (result: FalImageResult) => Promise<void>;
}

// Layout:
// ┌────────────────────────────────────┐
// │  [Original]          [Preview]     │
// │  ┌────────┐         ┌────────┐    │
// │  │        │  [→]    │        │    │
// │  │ Source │         │ Result │    │
// │  │        │         │        │    │
// │  └────────┘         └────────┘    │
// │                                    │
// │  Categoría: [▼]  Prompt: [▼]      │
// │  Instrucciones: [________________] │
// │  Modelo: [▼]  Strength: [━━●━━]   │
// │                                    │
// │  [✨ Generar]  [💾 Guardar] [✕]   │
// └────────────────────────────────────┘
```

---

## 6. CHECKLIST DE IMPLEMENTACIÓN

### Fase A: Extracción (1 sesión)
- [ ] Crear `MediaPicker.tsx` (separado de MediaEditor)
- [ ] Crear `shared/MediaCard.tsx`
- [ ] Crear `shared/Lightbox.tsx`
- [ ] Crear `shared/CompareSlider.tsx`
- [ ] Crear `shared/AssignForm.tsx`
- [ ] Crear `shared/SeoEditor.tsx`
- [ ] Crear `shared/UploadModal.tsx`
- [ ] Extraer `useMediaEditorReducer` hook
- [ ] Actualizar `CMSPage.tsx` para usar `MediaPicker` separado

### Fase B: Nuevo Layout (1 sesión)
- [ ] Crear `TopNav.tsx` (tabs principales)
- [ ] Crear `panels/MediaGrid.tsx` (grid + filtros + upload button)
- [ ] Crear `panels/MediaWorkspace.tsx` (preview + tabs)
- [ ] Crear `panels/StaffPanel.tsx` (grid staff + filtros staff)
- [ ] Crear `panels/GeneratePanel.tsx` (generación desde cero)
- [ ] Crear `panels/BatchPanel.tsx` (batch, extraído del monolito)
- [ ] Reescribir `MediaEditor.tsx` como orquestador

### Fase C: Flujos de Staff (1 sesión)
- [ ] Implementar `UploadModal` con formulario staff
- [ ] Implementar hover actions en `MediaCard` (✨ Editar)
- [ ] Implementar `EditModal` para img2img
- [ ] Conectar flujo: Staff Grid → Click Editar → Modal → Generar → Guardar
- [ ] Test: subir foto → editar → guardar en biblioteca

### Fase D: Polish (1 sesión)
- [ ] Responsive design (grid 2 cols en tablet, 1 col en móvil)
- [ ] Empty states ("No hay fotos del staff", "Selecciona una imagen")
- [ ] Loading states (skeletons en vez de "Cargando...")
- [ ] Keyboard navigation (Tab, Enter, Escape)
- [ ] Toast notifications (éxito/error en vez de alerts)
- [ ] Test completo + deploy

**Total: 4 sesiones**

---

## 7. DECISIONES DE DISEÑO

| # | Decisión | Valor | Razón |
|---|----------|-------|-------|
| 1 | Layout | 2 paneles (40/60) | Cabe en 1366x768 |
| 2 | Tabs | Arriba, visibles | Usuario siempre sabe dónde está |
| 3 | AI Tools | Tab dentro de preview, no panel fijo | Menos espacio, más limpio |
| 4 | Upload | Modal centrado | Obvio, prominente, no escondido |
| 5 | Editar staff | Hover action + modal dedicado | 2 clics vs 6 |
| 6 | Estado | useReducer | Menos re-renders, más predecible |
| 7 | Picker | Componente separado | No acoplar con MediaEditor |
| 8 | Batch | Tab separado | No renderizar si no se usa |
| 9 | Colores | Semánticos | Azul=acción, Naranja=staff, Morado=IA |
| 10 | Mobile | Grid 1 col + modal preview | Usable en tablet |

---

## 8. CÓDIGO DE REFERENCIA: TopNav

```tsx
function TopNav({ activeTab, onChange }: { activeTab: string; onChange: (t: string) => void }) {
  return (
    <nav className="flex items-center gap-1 px-4 py-2 border-b border-gray-700 bg-gray-900">
      <span className="text-sm font-bold text-white mr-4">🖼 Media</span>
      {TABS.map(tab => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
            activeTab === tab.id
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/30'
              : 'text-gray-400 hover:text-white hover:bg-gray-800'
          }`}
          title={tab.description}
        >
          <span>{tab.label.split(' ')[0]}</span>
          <span className="hidden sm:inline">{tab.label.split(' ')[1]}</span>
        </button>
      ))}
    </nav>
  );
}
```

## 9. CÓDIGO DE REFERENCIA: MediaCard con hover actions

```tsx
function MediaCard({ item, selected, onSelect, onEdit, onDelete, mode }: MediaCardProps) {
  const [hovered, setHovered] = useState(false);
  const isStaff = item.category === 'staff-raw';
  
  return (
    <div
      onClick={() => onSelect(item)}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={`relative rounded-lg overflow-hidden cursor-pointer transition-all aspect-square ${
        selected
          ? isStaff ? 'ring-2 ring-orange-500 shadow-lg shadow-orange-900/20' : 'ring-2 ring-blue-500 shadow-lg shadow-blue-900/20'
          : 'hover:ring-1 hover:ring-gray-500'
      }`}
    >
      <img src={imgUrl(item.key)} className="w-full h-full object-cover" loading="lazy" />
      
      {/* Hover overlay */}
      {hovered && mode === 'grid' && (
        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-2">
          <button onClick={(e) => { e.stopPropagation(); onSelect(item); }} className="px-3 py-1.5 bg-blue-600 rounded text-xs text-white">👁 Ver</button>
          {isStaff && onEdit && (
            <button onClick={(e) => { e.stopPropagation(); onEdit(item); }} className="px-3 py-1.5 bg-orange-600 rounded text-xs text-white">✨ Editar</button>
          )}
          <button onClick={(e) => { e.stopPropagation(); onDelete?.(item); }} className="px-3 py-1.5 bg-red-600 rounded text-xs text-white">🗑 Eliminar</button>
        </div>
      )}
      
      {/* Category badge */}
      <div className="absolute top-1 left-1">
        <span className={`text-[9px] px-1.5 py-0.5 rounded font-medium ${
          isStaff ? 'bg-orange-600 text-white' : 'bg-blue-600/80 text-white'
        }`}>
          {isStaff ? '👤 Staff' : item.category}
        </span>
      </div>
    </div>
  );
}
```

---

## 10. MÉTRICAS DE ÉXITO + PROBLEMAS OPERATIVOS

| Métrica | Antes (v3) | Objetivo (v4) |
|---------|-----------|---------------|
| Líneas de código | 1883 | < 600 (orquestador) + 6×200 = 1800 total pero modular |
| Hooks por archivo | 74 | < 15 por archivo |
| Clicks para subir foto staff | 4 | 2 |
| Clicks para editar con IA | 6 | 3 |
| Clicks para asignar a servicio | 7 | 3 |
| Paneles visibles simultáneos | 3 | 2 |
| Tiempo para generar imagen | 15s | 8s |
| % usuarios que encuentran modo Staff | ~5% | > 80% |
| HTTP status admin | 307 (redirect) | 200 (OK) |
| Fotos staff en D1 | 0 | > 1 (seed data) |

### Problemas operativos detectados

| # | Problema | Severidad | Fix rápido |
|---|----------|-----------|-----------|
| P11 | Admin HTTP 307 redirect | 🔴 Alta | Verificar ASSETS binding en wrangler.jsonc |
| P12 | 0 fotos staff en D1 | 🔴 Alta | Subir foto de ejemplo o agregar seed data |
| P13 | Cache de bundle viejo | 🟡 Media | Agregar `Cache-Control: no-cache` a index.html |

---

*Plan creado el 2026-05-11. Estado: listo para implementación.*
