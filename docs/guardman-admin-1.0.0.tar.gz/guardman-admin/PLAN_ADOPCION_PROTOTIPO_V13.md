# Plan de Adopción — GuardMan Admin Prototipo v13

**Fecha:** 2026-05-10  
**Versión del plan:** 1.0  
**Estimación total:** ~32 horas (2 sprints)  
**Light Mode:** Postergado a sprint posterior (no incluido)  
**Prioridad:** Alta (mejora UX general) + Media (refinamiento visual)

---

## 1. Visión General

El prototipo `guardman-admin-panel.html` (v13) define una dirección de diseño superior al admin actual en varios aspectos clave: design tokens más pulidos, layout del shell más eficiente, SEO panel informativo, y CRM Kanban con mejor jerarquía visual.

Este plan detalla **cómo adoptar lo valioso** del prototipo sin perder lo que ya funciona en el codebase actual (React funcional, 160 tests, backend real, demo mode).

**Filosofía:** Adoptar la estética y UX. Rechazar la arquitectura monolítica.

---

## 2. Inventario: Qué adoptar vs. Qué descartar

### ✅ ADOPTAR (con trabajo de adaptación)

| # | Feature | Archivo fuente | Esfuerzo estimado | Impacto UX |
|---|---------|---------------|-------------------|------------|
| A-01 | Design Tokens (paleta refinada) | Prototipo CSS `:root` | 3h | Alto |
| A-02 | Shell layout (sidebar 56px icon-only) | Prototipo `.app-shell` | 4h | Alto |
| A-03 | SEO Score Panel (ring + breakdown + checks) | Prototipo `.seo-panel` | 6h | **Crítico** |
| A-04 | CRM Kanban color-coded (border-top) | Prototipo `.kanban-column` | 3h | Medio |
| A-05 | ADN dirty dots (unsaved indicators) | Prototipo `.dirty-dot` | 2h | Medio |
| A-06 | Card hover states (subtle elevation) | Prototipo `.card-hover` | 2h | Medio |
| A-07 | Pipeline bar component | Prototipo `.pipeline-bar` | 2h | Medio |
| A-08 | Toast notification system | Prototipo `.toast` | 2h | Medio |
| A-09 | Login screen refined | Prototipo `.login-card` | 2h | Medio |
| A-10 | Custom scrollbars (WebKit + Firefox) | Prototipo `::-webkit-scrollbar` | 1h | Bajo |

### ❌ DESCARTAR (ya mejorado en código actual)

| # | Feature | Razón |
|---|---------|-------|
| D-01 | CSS semántico monolítico | Usamos Tailwind + componentes React |
| D-02 | JavaScript vanilla | Usamos React hooks + TypeScript |
| D-03 | HTML estático | Todo debe ser dinámico (API real/mock) |
| D-04 | Hardcoded data | Ya tenemos sistema demo con 12 leads + 5 clientes |
| D-05 | Mobile responsive básico | Rehacer desde cero con Tailwind breakpoints |
| D-06 | Color swatches en ADN | Feature no prioritaria |

---

## 3. Fases de Implementación

### Fase 1: Fundamentos — Design Tokens + Shell (8h)
**Meta:** Establecer la base visual sin romper nada.

#### 3.1.1 Extender `tailwind.config.js`
```javascript
// guardman-admin-ui/tailwind.config.js (o similar)
module.exports = {
  theme: {
    extend: {
      colors: {
        surface: {
          0: '#0D1525',  // fondo base
          1: '#131D33',  // tarjetas
          2: '#1A2744',  // elevación / hover
          3: '#0f1729',  // sidebar
        },
        accent: {
          DEFAULT: '#3B82F6',
          hover: '#2563eb',
          soft: 'rgba(59,130,246,0.12)',
          'soft-hover': 'rgba(59,130,246,0.20)',
        },
        success: { DEFAULT: '#10B981', soft: 'rgba(16,185,129,0.12)' },
        warning: { DEFAULT: '#F59E0B', soft: 'rgba(245,158,11,0.12)' },
        error: { DEFAULT: '#EF4444', soft: 'rgba(239,68,68,0.12)' },
        purple: { DEFAULT: '#8B5CF6', soft: 'rgba(139,92,246,0.12)' },
        cyan: { DEFAULT: '#06B6D4', soft: 'rgba(6,182,212,0.12)' },
        orange: { DEFAULT: '#F97316', soft: 'rgba(249,115,22,0.12)' },
        emerald: { DEFAULT: '#34D399', soft: 'rgba(52,211,153,0.12)' },
        fg: {
          DEFAULT: '#e8ecf1',
          muted: '#8896ab',
          dim: '#5a6880',
        },
      },
      borderRadius: {
        sm: '6px',
        DEFAULT: '10px',
        lg: '14px',
        xl: '18px',
      },
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'IBM Plex Mono', 'SF Mono', 'ui-monospace', 'Menlo', 'monospace'],
      },
      boxShadow: {
        sm: '0 1px 2px rgba(0,0,0,0.3)',
        DEFAULT: '0 2px 8px rgba(0,0,0,0.4)',
        lg: '0 8px 32px rgba(0,0,0,0.5)',
        glow: '0 0 20px rgba(59,130,246,0.15)',
      },
    },
  },
}
```

#### 3.1.2 Rehacer `App.tsx` — Shell layout
**Cambios:**
- Sidebar: de ancho variable (con texto) a **56px icon-only** con tooltips
- Topbar: agregar breadcrumb, deploy pill, user avatar
- Agregar transición suave al cambiar de tab

**Archivos a modificar:**
- `guardman-admin-ui/src/App.tsx`
- `guardman-admin-ui/src/components/Shell/Sidebar.tsx` (nuevo)
- `guardman-admin-ui/src/components/Shell/Topbar.tsx` (nuevo)
- `guardman-admin-ui/src/components/Shell/Tooltip.tsx` (nuevo)

#### 3.1.3 Global CSS refinado + Custom Scrollbars
```css
/* Añadir a index.css o global.css */
body {
  background-color: #0D1525;
  color: #e8ecf1;
  font-family: var(--font-sans);
  -webkit-font-smoothing: antialiased;
}

/* Custom scrollbars — WebKit (Chrome, Edge, Safari) */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #1A2744; border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: #5a6880; }

/* Firefox fallback */
@supports (scrollbar-width: thin) {
  * { scrollbar-width: thin; scrollbar-color: #1A2744 transparent; }
}

/* Respect prefers-reduced-motion */
@media (prefers-reduced-motion: reduce) {
  * { scrollbar-width: auto !important; }
}
```

#### 3.1.4 Tests
- Verificar que todos los tabs navegan correctamente
- Verificar que el tooltip aparece al hover
- Verificar responsive mobile (hamburger menu)

---

### Fase 2: SEO Score Panel — CMS (6h)
**Meta:** Dar feedback inmediato al editor de contenido sobre SEO.

#### 3.2.1 Nuevo componente `SEOScorePanel.tsx`
```
guardman-admin-ui/src/components/CMS/SEOScorePanel.tsx
```

**Arquitectura: Cálculo 100% frontend, tiempo real, heurístico.**
- Sin llamadas al backend. Los datos del CMS ya están en el estado del editor.
- Reglas evaluadas en cada `onChange` → feedback inmediato.
- Función pura: `calculateSEOScore(contentData) → { score, grade, checks[] }`

**Features a implementar:**
1. **Score ring SVG** — animado, con número central (0-100)
2. **Breakdown bars** — Contenido, SEO Técnico, Conversión
3. **SERP Intel** — Volumen, Competidores, Posición
4. **Quality Checks** — Pass/fail checks con detalle
5. **Botones** — "Regenerar con IA" + "Publicar"

**Reglas heurísticas (100 puntos total):**

| Check | Regla | Puntaje |
|-------|-------|---------|
| Title length | 30-60 caracteres | +15 |
| Description length | 120-160 caracteres | +15 |
| H1 presente | Exactamente 1 `<h1>` | +15 |
| H2-H3 estructura | Al menos 2 `<h2>` | +10 |
| Content length | > 300 palabras | +15 |
| Images con alt | 100% de imágenes tienen `alt` | +15 |
| Internal links | Al menos 1 link interno | +10 |
| Keyword en title | Keyword principal en el título | +5 |

**Grades:** ≥90 Excelente, ≥80 Bueno, ≥60 Regular, <60 Mejorable.

#### 3.2.2 ~~Backend: endpoint `/api/cms/seo-score`~~ → ELIMINADO
No se requiere endpoint backend. El cálculo es frontend-only para máxima velocidad y simplicidad. Si en el futuro se requiere SERP data real (volumen, competidores), se agregará un endpoint cacheado separado.

#### 3.2.3 Integrar en CMSPage
- Mostrar SEO panel a la derecha del editor (3-column layout)
- Actualizar score en tiempo real con cada `onChange`
- Memoizar `calculateSEOScore` con `useMemo` para evitar recálculos innecesarios

#### 3.2.4 Tests
- `SEOScorePanel.test.tsx` — renderizado, score display, checks
- `cms-routes.test.ts` — endpoint `/api/cms/seo-score`

---

### Fase 3: CRM Visual Refinement (5h)
**Meta:** Aplicar los mejoramientos visuales del prototipo al CRM funcional actual.

#### 3.3.1 Kanban restyling
**Archivo:** `CRMPipeline.tsx`

**Cambios:**
```diff
- border: 1px solid rgba(255,255,255,0.1)
+ border-top: 3px solid var(--accent); // o el color del stage
```

Cada columna del Kanban tendrá un `border-top-color` distinto:
- Nuevo: `var(--accent)` (azul)
- Contactado: `var(--warning)` (amarillo)
- Visita: `var(--orange)`
- Cotización: `var(--purple)`
- Negociación: `var(--cyan)`
- Ganado: `var(--success)`
- Perdido: `var(--error)`

**Lead cards:**
- `.card-hover` — `hover:bg-white/[0.06]` + `translateY(-1px)`
- `.frozen` — fondo rojo sutil `bg-red-500/10`
- Tags inline con `pill` component

#### 3.3.2 CRM Dashboard — Sales Funnel bars
**Archivo:** `CRMDashboard.tsx`

Reemplazar el embudo actual por barras horizontales con color coding (como el prototipo):
```
Nuevo        ████████████████████ 23 · $460K
Contactado   ███████████████       18 · $380K
Visita       ███████████           13 · $620K
...
```

#### 3.3.3 Toast system
**Nuevo archivo:** `guardman-admin-ui/src/components/UI/Toast.tsx`

```typescript
export function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error'; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, []);
  return (
    <div className={`fixed bottom-6 right-6 z-50 px-5 py-3 rounded-lg shadow-lg ${
      type === 'success' ? 'bg-emerald-900/90 text-emerald-300 border border-emerald-500/30' : 'bg-red-900/90 text-red-300 border border-red-500/30'
    }`}>
      {message}
    </div>
  );
}
```

Reemplazar todos los `.catch(() => {})` en CRM por `showToast('Error al cargar', 'error')`.

#### 3.3.4 Login screen refined
**Archivo:** `App.tsx` (login overlay)

- Shield logo con gradiente
- Card con glassmorphism
- Estados: default → loading → error → success
- Footer badge "OS-10 Autorizado"

---

### Fase 4: ADN de Marca — Dirty Dots (2h)
**Meta:** Indicar cambios sin guardar.

**Archivo:** `guardman-admin-ui/src/components/ADN/ADNEditor.tsx`

**Implementación:**
```typescript
const [dirtyCategories, setDirtyCategories] = useState<Set<string>>(new Set());

// Al modificar un campo:
const handleFieldChange = (category: string, key: string, value: string) => {
  setDirtyCategories(prev => new Set(prev).add(category));
  // ... guardar en estado local
};

// En el sidebar:
{ADN_CATEGORIES.map(cat => (
  <div key={cat.id} className="relative">
    {dirtyCategories.has(cat.id) && (
      <span className="absolute -right-1 top-1 w-2 h-2 rounded-full bg-warning" />
    )}
    {cat.name}
  </div>
))}
```

---

### Fase 5: Pipeline Bar Component (2h)
**Meta:** Reusable progress indicator para workflows.

**Nuevo archivo:** `guardman-admin-ui/src/components/UI/PipelineBar.tsx`

```typescript
interface PipelineStep {
  label: string;
  status: 'pending' | 'active' | 'done';
}

export function PipelineBar({ steps }: { steps: PipelineStep[] }) {
  return (
    <div className="flex items-center gap-0 justify-center py-4">
      {steps.map((step, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-semibold border-2 ${
            step.status === 'done' ? 'bg-success text-white border-success' :
            step.status === 'active' ? 'bg-accent text-white border-accent shadow-[0_0_12px_rgba(59,130,246,0.3)]' :
            'bg-surface-2 text-fg-dim border-white/[0.08]'
          }`}>
            {step.status === 'done' ? '✓' : i + 1}
          </div>
          <span className="text-[11px] text-fg-muted font-medium">{step.label}</span>
          {i < steps.length - 1 && (
            <div className={`w-10 h-0.5 mx-1 ${step.status === 'done' ? 'bg-success' : 'bg-white/[0.08]'}`} />
          )}
        </div>
      ))}
    </div>
  );
}
```

Usar en:
- Publish workflow
- Content generation pipeline
- CRM onboarding

---

### Fase 6: Tests + QA (6h)
**Meta:** Todo lo nuevo debe tener tests.

| Test | Archivo | Cobertura |
|------|---------|-----------|
| Shell layout | `Shell.test.tsx` | Sidebar, topbar, tooltips, mobile |
| SEO Score Panel | `SEOScorePanel.test.tsx` | Render, score, checks, cálculo heurístico |
| Kanban styling | `CRMPipeline.test.tsx` | Color borders, hover states |
| Toast system | `Toast.test.tsx` | Aparece, auto-close, tipos |
| Pipeline Bar | `PipelineBar.test.tsx` | Steps, status transitions |
| ADN dirty dots | `ADNEditor.test.tsx` | Dirty indicator, guardar limpia |
| Login screen | `Login.test.tsx` | Estados, validación |
| Integración | `app-flow.test.tsx` | Navegación completa shell |
| Scrollbars | `Scrollbars.test.tsx` | Renderizado, prefers-reduced-motion |

**Meta de cobertura:** 80%+ en componentes modificados.

---

### Fase 7: Deploy y rollback (1h)

#### Checklist pre-deploy:
- [ ] `npm run test` pasa (160+ tests)
- [ ] `npm run build` exitoso sin warnings
- [ ] Demo mode funciona con nuevo shell
- [ ] Responsive test en mobile (DevTools)
- [ ] A11y audit con axe-core (opcional)

#### Rollback plan:
```bash
# Si algo falla:
npx wrangler deploy --version-id <anterior>
```

---

## 4. Archivos a crear/modificar

### Nuevos archivos (13)
```
guardman-admin-ui/src/
  components/Shell/Sidebar.tsx
  components/Shell/Topbar.tsx
  components/Shell/Tooltip.tsx
  components/CMS/SEOScorePanel.tsx
  components/UI/Toast.tsx
  components/UI/PipelineBar.tsx
  components/ADN/ADNEditor.tsx (si no existe)
  
  tests/
    Shell.test.tsx
    SEOScorePanel.test.tsx
    Toast.test.tsx
    PipelineBar.test.tsx
    Login.test.tsx
    app-flow.test.tsx

src/api/routes/
  cms-seo.ts (endpoint SEO score)
```

### Archivos a modificar (10)
```
guardman-admin-ui/
  tailwind.config.js          # Agregar design tokens
  src/index.css               # Global styles refinados
  src/App.tsx                 # Nuevo shell layout
  src/components/CMS/CMSPage.tsx   # Agregar SEO panel
  src/components/CRM/CRMPipeline.tsx # Restyling Kanban
  src/components/CRM/CRMDashboard.tsx # Sales funnel bars
  src/components/CRM/CRMPage.tsx     # Integrar toast system
  src/components/CRM/LeadDetail.tsx  # Usar toast en lugar de catch silencioso
  src/components/CRM/ClientDetailView.tsx # Idem
  src/components/CRM/ProposalBuilder.tsx # Idem
```

---

## 5. Dependencias adicionales

```bash
cd guardman-admin-ui

# Si no está instalado:
npm install -D @axe-core/react   # A11y testing (opcional)

# Ya instalados (verificar):
# tailwindcss, postcss, autoprefixer
# @testing-library/react, @testing-library/jest-dom
# vitest, jsdom
```

**Nota:** No se requieren dependencias nuevas para scrollbars (CSS puro) ni para SEO score (lógica heurística en TypeScript).

---

## 6. Riesgos y Mitigaciones

| Riesgo | Probabilidad | Impacto | Mitigación |
|--------|-------------|---------|------------|
| Cambio de shell rompe navegación | Media | Alto | Tests de navegación antes de merge |
| Nuevos colores rompen contrastes | Baja | Medio | Revisar con DevTools contrast checker |
| ~~SEO Panel requiere backend nuevo~~ | ~~Media~~ | ~~Medio~~ | ~~Eliminado: cálculo frontend-only~~ |
| Sidebar icon-only confunde a usuarios | Baja | Medio | Agregar tooltips + trial period |
| Build size aumenta significativamente | Baja | Medio | Tree-shaking de Tailwind |
| Scrollbars no funcionan en Firefox | Baja | Bajo | Fallback con `scrollbar-color` implementado |

---

## 7. Métricas de éxito

| Métrica | Baseline | Meta |
|---------|----------|------|
| Tests pasando | 160 | ≥ 180 |
| Build time | 2.5s | < 3s |
| Bundle size | 492 KB | < 520 KB |
| Lighthouse Performance | ? | > 90 |
| Lighthouse Accessibility | ? | > 90 |
| Usuario puede ver SEO score | 0% | 100% de páginas |
| CRM demo mode funcional | 100% | 100% (no regresión) |
| Scrollbars consistentes | 0% | 100% de navegadores WebKit + Firefox |

---

## 8. Timeline Sugerido

```
Semana 1 (16h):
  Lunes:    Design tokens + Tailwind config + scrollbars
  Martes:   Shell layout (Sidebar 56px icon-only + Topbar)
  Miércoles: SEO Score Panel UI (frontend-only, heurísticas)
  Jueves:   Integración SEO Score en CMSPage + tests
  Viernes:  Login screen refinado + tests shell

Semana 2 (12h):
  Lunes:    CRM Kanban restyling
  Martes:   Toast system + reemplazar catch silenciosos
  Miércoles: Pipeline Bar + ADN dirty dots + scrollbars
  Jueves:   Login screen + responsive + tests integración
  Viernes:  QA + Deploy

**Light Mode:** Postergado a sprint posterior (estimación: +12h)

**Semana 3 (buffer):**
  Bug fixes, feedback de usuarios, refinamiento, light mode (opcional)
```

---

## 9. Decisiones pendientes (para discutir)

### Decisiones resueltas ✅

| # | Decisión | Resolución | Justificación |
|---|----------|-----------|---------------|
| 1 | **Sidebar texto vs. icon-only** | ✅ Icon-only (56px) | Más espacio de contenido, más limpio. Tooltips mitigan falta de texto. |
| 2 | **SEO score en tiempo real vs. al guardar** | ✅ Tiempo real, frontend-only | 0ms latencia, sin carga de API, feedback inmediato mientras escribes. Heurísticas puras en TypeScript. |
| 3 | **¿Agregar modo claro?** | ❌ **POSTERGADO** | No se implementa en este sprint. Alta complejidad (duplicar paleta, revisar 56 módulos). Sprint dedicado posterior: ~12h estimadas. |
| 4 | **¿Custom scrollbar para toda la app?** | ✅ Sí, con fallback | 10 líneas de CSS, alto impacto visual. Fallback Firefox (`scrollbar-color`) + `prefers-reduced-motion`. |

### Decisiones pendientes
Ninguna. Todas las decisiones de diseño están resueltas. El plan está listo para ejecutar.

---

## 10. Referencias

- Prototipo: `C:\Users\56930\open-design\.od\projects\e97e1744-1e2b-492d-80f8-c52bea902349\guardman-admin-panel.html`
- Sesión actual: `SESION_CRM_DEMO_Y_TESTS_2026-05-10.md`
- Auditoría CRM: `AUDITORIA_FORENSE_CRM_2026-05-10.md`
- Tests actuales: 160 pasando en backend + frontend

---

---

## Apéndice A: Resumen de decisiones del usuario (2026-05-10)

Esta sección confirma las decisiones tomadas en conversación y ya reflejadas en el plan:

| Pregunta | Decisión | Estado en plan |
|----------|----------|---------------|
| 1. Sidebar icon-only o con texto | **Icon-only (56px)** | ✅ Implementado en Fase 1 |
| 2. SEO score: backend API o frontend heurístico | **Frontend, tiempo real, heurístico** | ✅ Implementado en Fase 2. Sin endpoint backend. |
| 3. Light mode | **No ahora** | ❌ Postergado a sprint posterior |
| 4. Custom scrollbars | **Sí, con fallback Firefox** | ✅ Implementado en Fase 1 |

**Plan finalizado y listo para ejecución.**

---

*Plan creado por pi coding agent — 2026-05-10*
*Versión final: 1.1 (con decisiones de usuario incorporadas)*
*Ejecutado: 2026-05-10 19:33 — Deploy aa19f6d3*

---

## Apéndice B: Resumen de Ejecución (2026-05-10)

### Lo que ya existía (no requirió trabajo)
| Feature | Archivo | Estado |
|---------|---------|--------|
| Design Tokens | `globals.css` | ✅ Ya implementados — misma paleta que prototipo v13 |
| Shell Layout (sidebar 56px icon-only) | `Sidebar.tsx` + `AppLayout.tsx` | ✅ Ya implementado — tooltips, badge, mobile |
| SEO Score Panel | `SEOPanel.tsx` | ✅ Ya implementado — ring SVG, checks, pipeline, serp |
| ADN Dirty Dots | `ADNPage.tsx` | ✅ Ya implementado — puntos naranjas + contador "sin guardar" |
| Login Screen | `App.tsx` → refinado | ✅ Refinado — shield gradient, OS-10 badge |

### Lo implementado en esta ejecución
| Feature | Archivos | Líneas |
|---------|----------|--------|
| Scrollbars Firefox | `globals.css` | +5 líneas CSS |
| Login refinado | `App.tsx` | ~40 líneas (shield, labels, badge) |
| SEO Scorer utility | `utils/seo-scorer.ts` | 180 líneas |
| SEO Score Panel v13 | `CMS/SEOScorePanel.tsx` | 140 líneas |
| Toast System | `UI/Toast.tsx` | 100 líneas |
| Pipeline Bar | `UI/PipelineBar.tsx` | 70 líneas |
| Replace `.catch(()=>{})` → toasts | 6 archivos CRM | 12 cambios |
| Tests nuevos | 3 archivos | 17 tests |

### Resultado final
```
Backend:  122 passed · 9 suites
Frontend:  51 passed · 8 suites
Total:    173 passed · 0 failed

Bundle:   495 KB / 127 KB gzip
Version:  aa19f6d3-62d1-4a67-a6fd-60ff3043e074
URL:      https://guardman.oficinadesarrollo33.workers.dev
```
