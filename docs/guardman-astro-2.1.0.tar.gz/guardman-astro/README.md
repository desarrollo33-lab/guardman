# GuardMan Chile — Astro 6 v2.1.0 (Cloudflare Workers)

Migración 1:1 de `guardman-admin v1.0.0` (Cloudflare Worker monolítico + Vite/React SPA) a **Astro 6** desplegado en **Cloudflare Workers** (no Pages). Mantiene **todo** el contenido, el design system y la integración con el Worker API existente.

## Stack

- **Framework:** Astro 6 (SSR + adapter `@astrojs/cloudflare` en `mode: 'advanced'`)
- **Hosting:** **Cloudflare Workers** (no Pages) — Worker con bindings completos
- **UI interactiva:** React 19 (islas con `client:only="react"`)
- **CSS:** Tailwind v4 + los 3 CSS vanilla del original (`site.css`, `dark.css`, `main.css`) preservados 1:1
- **Backend:** Worker API existente (no se toca D1, R2, KV, DO, Workflows)

## Estructura

```
guardman-astro/
├── AUDITORA_FORENSE.md         # Informe de auditoría consolidado
├── README.md                   # Este archivo
├── astro.config.mjs            # Astro + Cloudflare Workers (advanced mode)
├── tsconfig.json
├── package.json
├── wrangler.jsonc              # Worker config (no Pages)
├── env.d.ts
├── .env.example
├── public/
│   ├── favicon.svg / .ico
│   ├── fonts/inter-*.ttf       # Inter (5 pesos)
│   ├── styles/                 # CSS vanilla originales preservados 1:1
│   │   ├── site.css            # 318 líneas — design system público
│   │   ├── dark.css            # 78 líneas — override para Guard Pod / Ajax
│   │   └── main.css            # 155 líneas — legacy
│   ├── scripts/
│   │   ├── main.js             # JS vanilla del original (mobile toggle + analytics)
│   │   └── admin-auth-guard.js # Auth redirect si no hay token
│   ├── _headers                # Cloudflare cache rules
│   └── _redirects
└── src/
    ├── styles/global.css       # Tailwind v4 + estilos del shell admin
    ├── lib/
    │   ├── constants.ts        # SITE, servicios, ubicaciones (con coords), sectores, zonas
    │   ├── api.ts              # Cliente HTTP unificado
    │   ├── auth.ts             # Token con expiración 8h
    │   ├── mocks.ts            # Mocks CRM
    │   └── icons.ts            # TODOS los iconos SVG del original (I.shield, I.phone, etc.)
    ├── types/index.ts
    ├── layouts/
    │   ├── BaseLayout.astro    # Shell público (Header + Footer + main.js)
    │   └── AdminLayout.astro   # Shell admin (Sidebar + Topbar + auth guard)
    ├── components/
    │   ├── Header.astro        # Dropdowns Servicios/Ubicaciones/Sectores
    │   ├── Footer.astro        # Con iconos sociales (Instagram + YouTube)
    │   └── CoverageMap.astro   # Mapa Leaflet reutilizable
    │   └── admin/
    │       ├── AdminSidebar.astro
    │       └── AdminTopbar.astro
    ├── islands/                # React (client:only)
    │   ├── cms/CMSEditor.tsx
    │   ├── crm/CRMView.tsx
    │   ├── media/MediaEditor.tsx
    │   ├── intel/IntelView.tsx
    │   ├── brand/BrandEditor.tsx
    │   └── chat/ChatView.tsx
    └── pages/
        ├── index.astro         # Homepage con mapa Leaflet de 14 comunas
        ├── nosotros.astro
        ├── guard-pod.astro     # Dark theme
        ├── ajax-systems.astro  # Dark theme
        ├── contacto.astro      # Form que POST a /api/crm/leads/capture
        ├── cotizacion.astro
        ├── gracias.astro
        ├── privacidad.astro
        ├── terminos.astro
        ├── 404.astro
        ├── robots.txt.ts
        ├── api/health.ts
        ├── servicios/{index,[slug]}.astro
        ├── ubicaciones/{index,[slug]}.astro  # Con mapa Leaflet por comuna
        └── sectores/{index,[slug]}.astro
        └── admin/{login,index,crm,media,intel,brand,chat,settings}.astro
```

## Qué incluye v2.1 (vs v2.0)

| Aspecto | v2.0 | v2.1 (esta) |
|---|---|---|
| Hosting | Cloudflare Pages | **Cloudflare Workers** (advanced mode) |
| CSS original | Reescrito en Tailwind @theme | **Preservado 1:1** (`site.css` + `dark.css` + `main.css` — 551 líneas) |
| Iconos SVG | Solo emojis | **Todos los SVG del original** (`I.shield`, `I.phone`, `I.wifi`, `I.monitor`, `I.device`, `I.doc`, `I.clock`, `I.eye`, `I.check`, `I.warn` + `SERVICE_ICONS` por slug + Instagram + YouTube) |
| Header | Solo nav simple | **Dropdowns exactos** (Servicios, Ubicaciones, Sectores + link Nosotros) |
| Footer | Sin redes sociales | **Con Instagram + YouTube** (links a @grupo_guardman y youtu.be/mqpLsKrwjAI) |
| Mapa | No incluido | **Leaflet 1.9.4 con 14 marcadores** (con coords exactas y colores por zona) |
| Layouts | Custom Astro | **Réplica 1:1** del `hdr()` + `ftr()` del original |
| main.js | No incluido | **Copiado del original** (mobile toggle + FAQ scrollIntoView + analytics) |
| Páginas con mapa | Solo homepage | Homepage + `/ubicaciones` + `/ubicaciones/[slug]` (mapa centrado) |

## Setup

```bash
# 1. Instalar deps
npm install

# 2. Variables de entorno (dev local)
cp .env.example .env

# 3. Dev
npm run dev

# 4. Build (produce dist/ con _worker.js/index.js + assets/)
npm run build

# 5. Deploy a Cloudflare Workers
npm run deploy
# (equivalente a: astro build && wrangler deploy)
```

## Configuración del Worker (`wrangler.jsonc`)

```jsonc
{
  "name": "guardman-astro",
  "main": "./dist/_worker.js/index.js",
  "compatibility_date": "2026-06-01",
  "compatibility_flags": ["nodejs_compat"],
  "assets": {
    "directory": "./dist",
    "binding": "ASSETS",
    "not_found_handling": "single-page-application"
  },
  "vars": {
    "PUBLIC_API_URL": "https://guardman.oficinadesarrollo33.workers.dev",
    "PUBLIC_SITE_URL": "https://guardman.cl"
  }
}
```

Para conectar bindings adicionales (D1, R2, KV, DO), agrégalos al `wrangler.jsonc`. El adapter `@astrojs/cloudflare` los expone vía `Astro.locals.runtime.env`.

## Auth flow

1. Usuario visita `/admin/*`
2. `admin-auth-guard.js` (inline) chequea `localStorage.gm_token` + expiración
3. Si no hay token válido → redirige a `/admin/login?redirect=...`
4. Login form POST a `${API_URL}/api/login` (Worker existente)
5. Token guardado con `gm_token_expires_at` (8h)
6. Cada request a la API incluye `Authorization: Bearer <token>`
7. Si API responde 401 → `api.ts` limpia token y lanza error

## Mapa Leaflet

- **Homepage** (`/`): mapa con los 14 marcadores de las comunas, agrupados por zona (Oriente=red, Centro=blue, Norte=yellow, Poniente=purple, Sur=blue, Valparaíso=green)
- **Hub de ubicaciones** (`/ubicaciones`): mapa interactivo con todos los marcadores
- **Detalle de ubicación** (`/ubicaciones/[slug]`): mapa centrado en la comuna con zoom 13

Leaflet se carga desde `unpkg.com/leaflet@1.9.4` (CSS + JS) con integrity hashes.

## Modo demo CRM

- Activar desde `/admin/settings` → "Modo Demo CRM"
- Solo afecta a endpoints CRM (usa `src/lib/mocks.ts`)
- CMS, Media, Intel, Brand y Chat siguen usando el backend real

## Limitaciones conocidas

- Monaco Editor no se migró (era ~2MB sin lazy). El CMS usa editor de formularios plano. Si se necesita Monaco, agregar como `React.lazy` en `CMSEditor.tsx`.
- Chat WebSocket asume endpoint `/api/agents/chat` en el Worker.
- Las páginas dinámicas usan `getStaticPaths` con datos de `lib/constants.ts`. En producción, hidratar con `fetch` a `/api/cms/content` para obtener datos reales de D1.
- Las imágenes referenciadas (`/images/hero-home.webp`, `/images/nosotros_seccion.webp`, etc.) se sirven desde R2 vía `/api/images/*` en el Worker API existente. Copiar las imágenes a R2 si aún no están.

## Licencia

Propietario — GuardMan Chile.
