// /robots.txt — generado dinámicamente.
import { SITE } from '../lib/constants';

const robots = `# GuardMan Chile — robots.txt
User-agent: *
Allow: /
Disallow: /admin
Disallow: /api

Sitemap: ${SITE.URL}/sitemap-index.xml
`;

export const GET = () =>
  new Response(robots, {
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  });
