// /api/health — healthcheck.
export const GET = () =>
  new Response(
    JSON.stringify({
      ok: true,
      service: 'guardman-astro',
      version: '2.1.0',
      hosting: 'cloudflare-workers',
      timestamp: new Date().toISOString(),
    }),
    { status: 200, headers: { 'Content-Type': 'application/json' } },
  );
