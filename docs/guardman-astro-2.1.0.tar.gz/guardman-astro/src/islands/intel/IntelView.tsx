// IntelView — Intel Hub simplificado.
import { useEffect, useState } from 'react';
import { intel, ApiError } from '../../lib/api';

export default function IntelView() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        await intel.dashboard();
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Error cargando Intel');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--fg-muted)' }}><span className="spinner" /> Cargando Intel...</div>;
  if (error) return (
    <div className="panel" style={{ borderColor: 'var(--color-error)' }}>
      <p style={{ color: 'var(--color-error)' }}>⚠️ {error}</p>
      <p style={{ color: 'var(--fg-muted)', fontSize: 13, marginTop: 8 }}>
        Verifica que el backend del Worker esté disponible y que tu token tenga permisos.
      </p>
    </div>
  );

  const kpis = [
    { label: 'Combos analizados', value: 126, color: 'blue', icon: '📊' },
    { label: 'Presencia propia', value: '38%', color: 'green', icon: '🎯' },
    { label: 'Competidores críticos', value: 7, color: 'amber', icon: '⚠️' },
    { label: 'Content gaps urgentes', value: 12, color: 'amber', icon: '🚨' },
  ];

  return (
    <div>
      <div className="kpi-row">
        {kpis.map((kpi) => (
          <div className="kpi-card" key={kpi.label}>
            <div className="kpi-top"><span className="kpi-icon">{kpi.icon}</span></div>
            <div className={`kpi-value ${kpi.color}`}>{kpi.value}</div>
            <div className="kpi-label">{kpi.label}</div>
          </div>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="panel">
          <div className="panel-header"><h3>🎯 Posiciones SERP</h3></div>
          <p style={{ color: 'var(--fg-muted)', fontSize: 14 }}>
            Tracking de posiciones en Google para keywords estratégicas por servicio y ubicación.
          </p>
          <div style={{ marginTop: 16, display: 'grid', gap: 8, fontSize: 13 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 8, background: 'var(--surface-2)', borderRadius: 6 }}>
              <span>guardias de seguridad las condes</span>
              <span className="pill pill-success">Pos 3</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 8, background: 'var(--surface-2)', borderRadius: 6 }}>
              <span>cctv vitacura</span>
              <span className="pill pill-warning">Pos 7</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: 8, background: 'var(--surface-2)', borderRadius: 6 }}>
              <span>seguridad industrial lampa</span>
              <span className="pill pill-error">Pos 24</span>
            </div>
          </div>
        </div>
        <div className="panel">
          <div className="panel-header"><h3>🔍 Competidores</h3></div>
          <p style={{ color: 'var(--fg-muted)', fontSize: 14 }}>Top competidores orgánicos detectados.</p>
          <div style={{ marginTop: 16, display: 'grid', gap: 8, fontSize: 13 }}>
            {['prosegur.cl', 'brink.cl', 'adt.cl', 'veritas.cl'].map((domain, i) => (
              <div key={domain} style={{ display: 'flex', justifyContent: 'space-between', padding: 8, background: 'var(--surface-2)', borderRadius: 6 }}>
                <span>{domain}</span>
                <span className="pill pill-neutral">{20 - i * 3} apariciones</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
