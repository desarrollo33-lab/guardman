// MediaEditor — galería de medios.
import { useEffect, useState, useCallback } from 'react';
import { media, ApiError } from '../../lib/api';
import type { MediaItem } from '../../types';

export default function MediaEditor() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<MediaItem | null>(null);
  const [uploading, setUploading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await media.list();
      setItems((data as { items: MediaItem[] }).items ?? []);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Error cargando medios');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      await media.upload(file, { alt: file.name });
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Error al subir');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Eliminar este medio?')) return;
    try {
      await media.delete(id);
      await load();
      setSelected(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Error al eliminar');
    }
  };

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--fg-muted)' }}><span className="spinner" /> Cargando medios...</div>;

  return (
    <div>
      {error && (
        <div className="panel" style={{ borderColor: 'var(--color-error)', background: 'rgba(239,68,68,0.15)', marginBottom: 16 }}>
          <p style={{ color: 'var(--color-error)', fontSize: 14 }}>⚠️ {error}</p>
        </div>
      )}
      <div className="panel">
        <div className="panel-header">
          <h3>Biblioteca de Medios</h3>
          <label className="admin-btn admin-btn-primary" style={{ cursor: uploading ? 'wait' : 'pointer' }}>
            {uploading ? <><span className="spinner" /> Subiendo...</> : '⬆️ Subir imagen'}
            <input type="file" accept="image/*" onChange={handleUpload} style={{ display: 'none' }} disabled={uploading} />
          </label>
        </div>
        {items.length === 0 ? (
          <div style={{ padding: 60, textAlign: 'center', color: 'var(--fg-muted)' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📁</div>
            <p>No hay medios. Sube tu primera imagen.</p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 12 }}>
            {items.map((item) => (
              <button
                key={item.id}
                onClick={() => setSelected(item)}
                style={{ background: 'var(--surface-2)', border: '1px solid rgba(255,255,255,0.06)', borderRadius: 'var(--radius)', overflow: 'hidden', cursor: 'pointer', padding: 0, fontFamily: 'inherit' }}
              >
                <div style={{ aspectRatio: '1', background: 'var(--surface-3)', display: 'grid', placeItems: 'center' }}>
                  <img src={item.url} alt={item.alt} style={{ width: '100%', height: '100%', objectFit: 'cover' }} loading="lazy" />
                </div>
                <div style={{ padding: 10, textAlign: 'left' }}>
                  <div style={{ fontSize: 12, color: 'var(--fg)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.filename}</div>
                  <div style={{ fontSize: 11, color: 'var(--fg-dim)' }}>{item.type}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
      {selected && (
        <div onClick={() => setSelected(null)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 50, display: 'grid', placeItems: 'center', padding: 16 }}>
          <div onClick={(e) => e.stopPropagation()} className="panel" style={{ maxWidth: 600, width: '100%', margin: 0 }}>
            <div className="panel-header">
              <h3>{selected.filename}</h3>
              <button onClick={() => setSelected(null)} style={{ color: 'var(--fg-dim)', fontSize: 20, background: 'none', border: 'none', cursor: 'pointer' }}>×</button>
            </div>
            <img src={selected.url} alt={selected.alt} style={{ width: '100%', borderRadius: 'var(--radius)', marginBottom: 16 }} />
            <div style={{ display: 'grid', gap: 12, fontSize: 13 }}>
              <div><strong style={{ color: 'var(--fg-dim)' }}>URL:</strong> <code>{selected.url}</code></div>
              <div><strong style={{ color: 'var(--fg-dim)' }}>Alt:</strong> {selected.alt}</div>
              <div><strong style={{ color: 'var(--fg-dim)' }}>Subido:</strong> {selected.uploaded_at}</div>
              {selected.size && <div><strong style={{ color: 'var(--fg-dim)' }}>Tamaño:</strong> {(selected.size / 1024).toFixed(1)} KB</div>}
            </div>
            <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>
              <button className="admin-btn admin-btn-secondary" onClick={() => navigator.clipboard.writeText(selected.url)}>Copiar URL</button>
              <button className="admin-btn admin-btn-secondary" style={{ color: 'var(--color-error)' }} onClick={() => handleDelete(selected.id)}>🗑️ Eliminar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
