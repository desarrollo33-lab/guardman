// CRMView — Dashboard + Pipeline Kanban + Clients.
import { useEffect, useState } from 'react';
import { crm, ApiError } from '../../lib/api';
import { isDemoMode } from '../../lib/auth';
import type { Lead, Client, Dashboard, PipelineColumn } from '../../lib/mocks';

type Tab = 'dashboard' | 'pipeline' | 'clients';

export default function CRMView() {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [pipeline, setPipeline] = useState<PipelineColumn[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const [dash, pipe, cli] = await Promise.all([
          crm.dashboard(),
          crm.pipeline(),
          crm.clients.list(),
        ]);
        if (cancelled) return;
        setDashboard(dash as Dashboard);
        setPipeline(pipe as PipelineColumn[]);
        setClients(cli as Client[]);
      } catch (err) {
        if (cancelled) return;
        setError(err instanceof ApiError ? err.message : 'Error cargando CRM');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return <div style={{ padding: 40, textAlign: 'center', color: 'var(--fg-muted)' }}><span className="spinner" /> Cargando CRM...</div>;
  }
  if (error) {
    return (
      <div className="panel" style={{ borderColor: 'var(--color-error)' }}>
        <h3 style={{ color: 'var(--color-error)', marginBottom: 8 }}>Error</h3>
        <p style={{ color: 'var(--fg-muted)', fontSize: 14 }}>{error}</p>
        <button className="admin-btn admin-btn-primary" onClick={() => window.location.reload()}>Reintentar</button>
      </div>
    );
  }

  return (
    <div>
      {isDemoMode() && (
        <div className="panel" style={{ borderColor: 'var(--color-success)', background: 'rgba(16,185,129,0.15)' }}>
          <strong style={{ color: 'var(--color-success)' }}>🧪 Modo Demo activado</strong>
          <span style={{ color: 'var(--fg-muted)', fontSize: 13 }}> — usando datos mock. Desactívalo en Configuración.</span>
        </div>
      )}
      <div className="tabs">
        <button className={`tab ${tab === 'dashboard' ? 'active' : ''}`} onClick={() => setTab('dashboard')}>Dashboard</button>
        <button className={`tab ${tab === 'pipeline' ? 'active' : ''}`} onClick={() => setTab('pipeline')}>Pipeline</button>
        <button className={`tab ${tab === 'clients' ? 'active' : ''}`} onClick={() => setTab('clients')}>Clientes</button>
      </div>
      {tab === 'dashboard' && <DashboardView data={dashboard!} />}
      {tab === 'pipeline' && <PipelineView columns={pipeline} />}
      {tab === 'clients' && <ClientsView clients={clients} />}
    </div>
  );
}

function DashboardView({ data }: { data: Dashboard }) {
  const kpis = [
    { label: 'Leads nuevos (30 días)', value: data.kpis.new_leads_30d, color: 'blue', icon: '📥' },
    { label: 'Valor pipeline', value: formatCLP(data.kpis.pipeline_value), color: 'amber', icon: '💰' },
    { label: 'Ganados este mes', value: data.kpis.won_this_month, color: 'green', icon: '✅' },
    { label: 'Revenue mensual', value: formatCLP(data.kpis.monthly_revenue), color: 'green', icon: '📊' },
  ];
  return (
    <div>
      <div className="kpi-row">
        {kpis.map((kpi) => (
          <div className="kpi-card" key={kpi.label}>
            <div className="kpi-top"><span className="kpi-icon">{kpi.icon}</span></div>
            <div className={`kpi-value ${kpi.color}`}>{kpi.value}</div>
            <div className="kpi-label">{kpi.label}</div>
          </div>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="panel">
          <div className="panel-header"><h3>📅 Mi Día</h3></div>
          {data.today_agenda.length === 0 ? (
            <p style={{ color: 'var(--fg-muted)', fontSize: 14 }}>Sin actividades agendadas para hoy.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {data.today_agenda.map((item, i) => (
                <div key={i} style={{ display: 'flex', gap: 16, padding: 12, background: 'var(--surface-2)', borderRadius: 'var(--radius)' }}>
                  <div style={{ fontWeight: 700, color: 'var(--color-accent)', minWidth: 50 }}>{item.time}</div>
                  <div>
                    <div style={{ fontSize: 14, color: 'var(--fg)' }}>{item.title}</div>
                    <span className={`pill pill-${item.type === 'visit' ? 'info' : item.type === 'call' ? 'warning' : 'success'}`}>
                      {item.type === 'visit' ? 'Visita' : item.type === 'call' ? 'Llamada' : 'Reunión'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="panel">
          <div className="panel-header"><h3>🔄 Actividad reciente</h3></div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {data.recent_activity.map((a) => (
              <div key={a.id} style={{ padding: 10, background: 'var(--surface-2)', borderRadius: 'var(--radius)', fontSize: 13 }}>
                <div style={{ color: 'var(--fg)' }}>{a.text}</div>
                <div style={{ color: 'var(--fg-dim)', fontSize: 11, marginTop: 4 }}>{a.when}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PipelineView({ columns }: { columns: PipelineColumn[] }) {
  const [selected, setSelected] = useState<Lead | null>(null);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 12, overflowX: 'auto', paddingBottom: 16 }}>
      {columns.map((col) => (
        <div key={col.status} style={{ minWidth: 220 }}>
          <div style={{ padding: '10px 12px', background: 'var(--surface-2)', borderRadius: 'var(--radius) var(--radius) 0 0', borderTop: `3px solid ${col.color}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>{col.label}</span>
            <span className="pill pill-neutral">{col.leads.length}</span>
          </div>
          <div style={{ background: 'var(--surface-1)', padding: 8, borderRadius: '0 0 var(--radius) var(--radius)', minHeight: 200, display: 'flex', flexDirection: 'column', gap: 8 }}>
            {col.leads.length === 0 ? (
              <div style={{ color: 'var(--fg-dim)', fontSize: 12, textAlign: 'center', padding: 20 }}>Sin leads</div>
            ) : (
              col.leads.map((lead) => (
                <button
                  key={lead.id}
                  onClick={() => setSelected(lead)}
                  style={{
                    textAlign: 'left', background: 'var(--surface-2)',
                    border: '1px solid rgba(255,255,255,0.06)', borderRadius: 6,
                    padding: 10, cursor: 'pointer', color: 'inherit', fontFamily: 'inherit',
                  }}
                >
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--fg)' }}>{lead.name}</div>
                  <div style={{ fontSize: 11, color: 'var(--fg-dim)', marginTop: 4 }}>{formatCLP(lead.value)}</div>
                </button>
              ))
            )}
          </div>
        </div>
      ))}
      {selected && <LeadDetailModal lead={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}

function LeadDetailModal({ lead, onClose }: { lead: Lead; onClose: () => void }) {
  return (
    <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 50, display: 'grid', placeItems: 'center', padding: 16 }}>
      <div onClick={(e) => e.stopPropagation()} className="panel" style={{ maxWidth: 480, width: '100%', margin: 0 }}>
        <div className="panel-header">
          <h3>{lead.name}</h3>
          <button onClick={onClose} style={{ color: 'var(--fg-dim)', fontSize: 20, background: 'none', border: 'none', cursor: 'pointer' }}>×</button>
        </div>
        <div style={{ display: 'grid', gap: 12, fontSize: 14 }}>
          <Field label="Email" value={lead.email} />
          <Field label="Teléfono" value={lead.phone} />
          <Field label="Servicio" value={lead.service} />
          <Field label="Ubicación" value={lead.location} />
          <Field label="Valor estimado" value={formatCLP(lead.value)} />
          <Field label="Estado" value={lead.status} />
          <Field label="Creado" value={lead.created_at} />
        </div>
      </div>
    </div>
  );
}

function ClientsView({ clients }: { clients: Client[] }) {
  return (
    <div className="panel">
      <table className="data-table">
        <thead>
          <tr>
            <th>Cliente</th>
            <th>Contacto</th>
            <th>Servicio</th>
            <th>Ubicación</th>
            <th>Desde</th>
            <th style={{ textAlign: 'right' }}>Mensual</th>
          </tr>
        </thead>
        <tbody>
          {clients.map((c) => (
            <tr key={c.id}>
              <td style={{ color: 'var(--fg)', fontWeight: 600 }}>{c.name}</td>
              <td>
                <div style={{ fontSize: 12 }}>{c.email}</div>
                <div style={{ fontSize: 11, color: 'var(--fg-dim)' }}>{c.phone}</div>
              </td>
              <td>{c.service}</td>
              <td>{c.location}</td>
              <td>{c.since}</td>
              <td className="num" style={{ color: 'var(--color-success)', fontWeight: 600 }}>{formatCLP(c.monthly_value)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div style={{ color: 'var(--fg-dim)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 2 }}>{label}</div>
      <div style={{ color: 'var(--fg)' }}>{value}</div>
    </div>
  );
}

function formatCLP(value: number): string {
  return new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(value);
}
