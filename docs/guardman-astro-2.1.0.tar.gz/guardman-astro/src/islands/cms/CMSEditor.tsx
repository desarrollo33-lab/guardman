// CMSEditor — editor de contenido del CMS.
import { useEffect, useState, useCallback } from 'react';
import { cms, ApiError } from '../../lib/api';
import { SERVICE_NAMES, LOCATION_SLUGS } from '../../lib/constants';

type EntityType = 'service' | 'location' | 'sector' | 'static_page' | 'combo';

interface ContentData {
  content: Record<string, unknown>;
  seo: { title: string; description: string };
  version?: number;
}

export default function CMSEditor() {
  const [type, setType] = useState<EntityType>('service');
  const [slug, setSlug] = useState<string>('guardias-de-seguridad');
  const [data, setData] = useState<ContentData | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const result = await cms.get(type, slug);
      setData(result as ContentData);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'No se pudo cargar el contenido. Verifica que el backend esté disponible.');
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [type, slug]);

  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!data) return;
    setSaving(true);
    setError(null);
    try {
      await cms.save(type, slug, data.content, data.seo);
      setSuccess('✅ Contenido guardado');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Error al guardar');
    } finally {
      setSaving(false);
    }
  };

  const regenerate = async () => {
    if (!confirm('¿Regenerar contenido con IA? Esto puede sobrescribir ediciones manuales.')) return;
    setGenerating(true);
    setError(null);
    try {
      await cms.regenerate(type, slug);
      await load();
      setSuccess('✅ Contenido regenerado');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Error al regenerar');
    } finally {
      setGenerating(false);
    }
  };

  const updateContent = (path: string, value: unknown) => {
    if (!data) return;
    const newContent = JSON.parse(JSON.stringify(data.content));
    const parts = path.split('.');
    let target: Record<string, unknown> = newContent;
    for (let i = 0; i < parts.length - 1; i++) {
      target = target[parts[i]] as Record<string, unknown>;
    }
    target[parts[parts.length - 1]] = value;
    setData({ ...data, content: newContent });
  };

  const options = type === 'service' ? Object.keys(SERVICE_NAMES) : type === 'location' ? LOCATION_SLUGS : [];

  return (
    <div>
      {error && (
        <div className="panel" style={{ borderColor: 'var(--color-error)', background: 'rgba(239,68,68,0.15)' }}>
          <p style={{ color: 'var(--color-error)', fontSize: 14 }}>⚠️ {error}</p>
        </div>
      )}
      {success && (
        <div className="panel" style={{ borderColor: 'var(--color-success)', background: 'rgba(16,185,129,0.15)' }}>
          <p style={{ color: 'var(--color-success)', fontSize: 14 }}>{success}</p>
        </div>
      )}
      <div className="panel">
        <div className="panel-header"><h3>Selector de contenido</h3></div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto auto', gap: 12, alignItems: 'end' }}>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Tipo</label>
            <select className="form-input" value={type} onChange={(e) => setType(e.target.value as EntityType)}>
              <option value="service">Servicio</option>
              <option value="location">Ubicación</option>
              <option value="sector">Sector</option>
              <option value="static_page">Página estática</option>
              <option value="combo">Combo</option>
            </select>
          </div>
          <div className="form-group" style={{ margin: 0 }}>
            <label>Slug</label>
            {options.length > 0 ? (
              <select className="form-input" value={slug} onChange={(e) => setSlug(e.target.value)}>
                {options.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            ) : (
              <input className="form-input" value={slug} onChange={(e) => setSlug(e.target.value)} />
            )}
          </div>
          <button className="admin-btn admin-btn-secondary" onClick={load} disabled={loading}>
            {loading ? <span className="spinner" /> : 'Cargar'}
          </button>
          <button className="admin-btn admin-btn-primary" onClick={save} disabled={!data || saving}>
            {saving ? <span className="spinner" /> : '💾 Guardar'}
          </button>
        </div>
        <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
          <button className="admin-btn admin-btn-secondary" onClick={regenerate} disabled={!data || generating}>
            {generating ? <><span className="spinner" /> Regenerando...</> : '🤖 Regenerar con IA'}
          </button>
        </div>
      </div>
      {data && (
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 }}>
          <div className="panel">
            <div className="panel-header"><h3>Editor de contenido</h3></div>
            <ContentFields content={data.content} onChange={updateContent} />
          </div>
          <div className="panel">
            <div className="panel-header"><h3>SEO</h3></div>
            <div className="form-group">
              <label>Meta title</label>
              <input className="form-input" value={data.seo.title} onChange={(e) => setData({ ...data, seo: { ...data.seo, title: e.target.value } })} />
            </div>
            <div className="form-group">
              <label>Meta description</label>
              <textarea className="form-input" rows={3} value={data.seo.description} onChange={(e) => setData({ ...data, seo: { ...data.seo, description: e.target.value } })} />
            </div>
            {data.version && <p style={{ color: 'var(--fg-dim)', fontSize: 12 }}>Versión: {data.version}</p>}
          </div>
        </div>
      )}
    </div>
  );
}

function ContentFields({ content, onChange }: { content: Record<string, unknown>; onChange: (path: string, value: unknown) => void }) {
  const hero = (content.hero as Record<string, string>) ?? {};
  const intro = (content.intro as Record<string, unknown>) ?? {};
  return (
    <div style={{ display: 'grid', gap: 16 }}>
      <div>
        <h4 style={{ fontSize: 13, color: 'var(--color-accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Hero</h4>
        <div className="form-group">
          <label>Heading</label>
          <input className="form-input" value={hero.heading ?? ''} onChange={(e) => onChange('hero.heading', e.target.value)} />
        </div>
        <div className="form-group">
          <label>Subheading</label>
          <textarea className="form-input" rows={2} value={hero.subheading ?? ''} onChange={(e) => onChange('hero.subheading', e.target.value)} />
        </div>
      </div>
      <div>
        <h4 style={{ fontSize: 13, color: 'var(--color-accent)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Intro</h4>
        <div className="form-group">
          <label>Heading</label>
          <input className="form-input" value={(intro.heading as string) ?? ''} onChange={(e) => onChange('intro.heading', e.target.value)} />
        </div>
        <div className="form-group">
          <label>Párrafos (uno por línea)</label>
          <textarea className="form-input" rows={4} value={Array.isArray(intro.paragraphs) ? (intro.paragraphs as string[]).join('\n') : ''} onChange={(e) => onChange('intro.paragraphs', e.target.value.split('\n').filter(Boolean))} />
        </div>
      </div>
      <details>
        <summary style={{ cursor: 'pointer', padding: 8, color: 'var(--fg-muted)' }}>Ver JSON completo</summary>
        <pre style={{ background: 'var(--surface-2)', padding: 16, borderRadius: 'var(--radius)', fontSize: 12, overflow: 'auto', color: 'var(--fg-muted)' }}>
          {JSON.stringify(content, null, 2)}
        </pre>
      </details>
    </div>
  );
}
