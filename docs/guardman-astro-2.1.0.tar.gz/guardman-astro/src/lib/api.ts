// ════════════════════════════════════════════════════════════════
// GuardMan — Cliente HTTP unificado para el Worker API.
// Reemplaza a `guardman-admin-ui/src/hooks/{useApi,useMockApi,useRealApi}.ts`.
// ════════════════════════════════════════════════════════════════

import { SITE, API_TIMEOUT_MS } from './constants';
import { getToken, clearToken } from './auth';
import { crmMocks } from './mocks';

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public endpoint?: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T = unknown>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (token) headers.Authorization = `Bearer ${token}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), API_TIMEOUT_MS);

  try {
    const res = await fetch(`${SITE.API_URL}${path}`, {
      ...options,
      headers,
      signal: controller.signal,
    });

    if (res.status === 401) {
      clearToken();
      throw new ApiError('Sesión expirada. Vuelve a iniciar sesión.', 401, path);
    }

    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      throw new ApiError(
        data.error ?? `Error ${res.status} en ${path}`,
        res.status,
        path,
      );
    }
    return (data.data ?? data) as T;
  } finally {
    clearTimeout(timeout);
  }
}

const isDemoMode = () =>
  typeof window !== 'undefined' && localStorage.getItem('gm_demo_mode') === 'crm';

export const auth = {
  login: (email: string, password: string) =>
    request<{ token: string; user: { email: string } }>('/api/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  logout: () => clearToken(),
};

export const cms = {
  list: (type: string) => request(`/api/cms/list?type=${type}`),
  get: (type: string, slug: string, location?: string) => {
    const params = new URLSearchParams({ type, slug });
    if (location) params.set('location', location);
    return request(`/api/cms/content?${params}`);
  },
  homepage: () => request('/api/cms/homepage'),
  save: (type: string, slug: string, content: unknown, seo?: unknown) =>
    request('/api/cms/save', {
      method: 'POST',
      body: JSON.stringify({ type, slug, content, seo }),
    }),
  generate: (type: string, slug: string, location?: string) =>
    request('/api/cms/generate', {
      method: 'POST',
      body: JSON.stringify({ type, slug, location }),
    }),
  regenerate: (type: string, slug: string, location?: string) =>
    request('/api/cms/regenerate', {
      method: 'POST',
      body: JSON.stringify({ type, slug, location }),
    }),
};

export const crm = {
  dashboard: () =>
    isDemoMode() ? Promise.resolve(crmMocks.dashboard) : request('/api/crm/dashboard'),
  pipeline: () =>
    isDemoMode() ? Promise.resolve(crmMocks.pipeline) : request('/api/crm/pipeline'),
  leads: {
    list: () =>
      isDemoMode() ? Promise.resolve(crmMocks.leads) : request('/api/crm/leads'),
    get: (id: string) =>
      isDemoMode()
        ? Promise.resolve(crmMocks.leads.find((l) => l.id === id) ?? null)
        : request(`/api/crm/leads/${id}`),
    create: (data: unknown) =>
      request('/api/crm/leads', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: string, data: unknown) =>
      request(`/api/crm/leads/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  },
  clients: {
    list: () =>
      isDemoMode() ? Promise.resolve(crmMocks.clients) : request('/api/crm/clients'),
    get: (id: string) => request(`/api/crm/clients/${id}`),
  },
  proposals: {
    list: () => request('/api/crm/proposals'),
    create: (leadId: string, data: unknown) =>
      request(`/api/crm/leads/${leadId}/proposals`, {
        method: 'POST',
        body: JSON.stringify(data),
      }),
  },
};

export const media = {
  list: (params: { type?: string; page?: number } = {}) => {
    const qs = new URLSearchParams();
    if (params.type) qs.set('type', params.type);
    if (params.page) qs.set('page', String(params.page));
    return request(`/api/media?${qs}`);
  },
  upload: (file: File, metadata: Record<string, string> = {}) => {
    const form = new FormData();
    form.append('file', file);
    Object.entries(metadata).forEach(([k, v]) => form.append(k, v));
    return request('/api/media/upload', { method: 'POST', body: form });
  },
  delete: (id: string) => request(`/api/media/${id}`, { method: 'DELETE' }),
};

export const intel = {
  dashboard: () => request('/api/intel/dashboard'),
  competitors: () => request('/api/intel/competitors'),
  market: () => request('/api/intel/market'),
  reports: () => request('/api/intel/reports'),
};

export const brand = {
  get: () => request('/api/brand'),
  save: (data: unknown) =>
    request('/api/brand', { method: 'POST', body: JSON.stringify(data) }),
};

export const agents = {
  history: () => request('/api/chat-history'),
  clear: () => request('/api/chat-history', { method: 'DELETE' }),
};

export const imageUrl = (key: string) => `${SITE.API_URL}/api/images/${key}`;
