// ════════════════════════════════════════════════════════════════
// GuardMan — Constantes unificadas del sitio y el admin.
// Reemplaza a `src/types/index.ts` y `src/ssr/site-data.ts`.
// Una sola fuente de verdad.
// ════════════════════════════════════════════════════════════════

export const SITE = {
  NAME: 'GuardMan Chile',
  LEGAL_NAME: 'GuardMan Chile',
  TAGLINE: 'Seguridad Privada OS-10 | 8+ años protegiendo empresas y residencias',
  DESCRIPTION:
    'GuardMan Chile — Seguridad privada con certificación OS-10. Guardias, CCTV, control de accesos, escoltas, monitoreo 24/7, Guard Pod y Ajax Systems. Cobertura en 14 comunas de la Región Metropolitana.',
  URL: import.meta.env.PUBLIC_SITE_URL ?? 'https://guardman.cl',
  API_URL: import.meta.env.PUBLIC_API_URL ?? 'https://guardman.oficinadesarrollo33.workers.dev',
  PHONE: '+56 9 300 000 10',
  PHONE_TEL: '+56930000010',
  EMAIL_INFO: 'info@guardman.cl',
  EMAIL_VENTAS: 'ventas@guardman.cl',
  ADDRESS: 'Av. Américo Vespucio Norte 1980, Providencia, Santiago, Chile',
  RUT: '77.123.456-7',
  FOUNDED_YEAR: 2017,
  INSTAGRAM_URL: 'https://www.instagram.com/grupo_guardman',
  YOUTUBE_URL: 'https://youtu.be/mqpLsKrwjAI',
  CERTIFICATIONS: [
    'Certificación OS-10 vigente verificada por Carabineros de Chile',
    'Capacitación continua en protocolos de seguridad y emergencias',
    'Centro de monitoreo propio 24/7 con operadores especializados',
    '8+ años de experiencia protegiendo empresas y residencias',
  ],
} as const;

export const STATS = {
  GUARDIAS: '500+',
  EMPRESAS: '200+',
  COMUNAS: '14',
  ANOS: '8+',
} as const;

export const SERVICE_NAMES: Record<string, string> = {
  'guardias-de-seguridad': 'Guardias de Seguridad',
  'cctv-videovigilancia': 'CCTV Videovigilancia',
  'control-de-accesos': 'Control de Accesos',
  'escoltas-privados': 'Escoltas Privados',
  'monitoreo-24-7': 'Monitoreo 24/7',
  'seguridad-eventos': 'Seguridad Eventos',
  'seguridad-industrial': 'Seguridad Industrial',
  'auditoria-seguridad': 'Auditoría de Seguridad',
  'guard-pod': 'Guard Pod',
};

export const SERVICE_SLUGS = Object.keys(SERVICE_NAMES);

export const SERVICE_DESCRIPTIONS: Record<string, string> = {
  'guardias-de-seguridad': 'Personal certificado OS-10 para protección de empresas, residencias y eventos.',
  'cctv-videovigilancia': 'Sistemas de cámaras IP con monitoreo remoto y respaldo en la nube.',
  'control-de-accesos': 'Control de ingreso biométrico, tarjetas y QR para edificios y oficinas.',
  'escoltas-privados': 'Escoltas armados con entrenamiento táctico para ejecutivos y valores.',
  'monitoreo-24-7': 'Centro de monitoreo propio con respuesta inmediata a alarmas.',
  'seguridad-eventos': 'Cobertura de seguridad para eventos masivos y privados.',
  'seguridad-industrial': 'Vigilancia perimetral y control de acceso para industrias y obras.',
  'auditoria-seguridad': 'Diagnóstico de vulnerabilidades y plan de mejora de seguridad.',
  'guard-pod': 'Vigilancia autónoma con energía solar y cámaras PTZ 360°.',
};

export const SECTOR_NAMES: Record<string, string> = {
  residencial: 'Residencial',
  comercial: 'Comercial',
  industrial: 'Industrial',
  construccion: 'Construcción',
  educacion: 'Educación',
  eventos: 'Eventos',
  hoteleria: 'Hotelería',
  salud: 'Salud',
  automotriz: 'Automotriz',
};

export const SECTOR_TO_SERVICE: Record<string, string> = {
  comercial: 'guardias-de-seguridad',
  construccion: 'seguridad-industrial',
  educacion: 'guardias-de-seguridad',
  eventos: 'seguridad-eventos',
  industrial: 'seguridad-industrial',
  residencial: 'guardias-de-seguridad',
  salud: 'guardias-de-seguridad',
};

// Ubicaciones con coordenadas exactas (para el mapa Leaflet)
export interface Location {
  slug: string;
  name: string;
  lat: number;
  lng: number;
  zone: 'Oriente' | 'Centro' | 'Norte' | 'Sur' | 'Poniente' | 'Valparaíso';
}

export const LOCATIONS: Location[] = [
  { slug: 'santiago-centro', name: 'Santiago Centro', lat: -33.4378, lng: -70.6505, zone: 'Centro' },
  { slug: 'huechuraba', name: 'Huechuraba', lat: -33.3586, lng: -70.6773, zone: 'Norte' },
  { slug: 'lampa', name: 'Lampa', lat: -33.2786, lng: -70.8764, zone: 'Norte' },
  { slug: 'quilicura', name: 'Quilicura', lat: -33.3586, lng: -70.7406, zone: 'Norte' },
  { slug: 'la-reina', name: 'La Reina', lat: -33.4473, lng: -70.5459, zone: 'Oriente' },
  { slug: 'las-condes', name: 'Las Condes', lat: -33.4189, lng: -70.5464, zone: 'Oriente' },
  { slug: 'lo-barnechea', name: 'Lo Barnechea', lat: -33.3536, lng: -70.5219, zone: 'Oriente' },
  { slug: 'vitacura', name: 'Vitacura', lat: -33.4028, lng: -70.5969, zone: 'Oriente' },
  { slug: 'conchali', name: 'Conchalí', lat: -33.3917, lng: -70.6658, zone: 'Poniente' },
  { slug: 'pudahuel', name: 'Pudahuel', lat: -33.4364, lng: -70.7406, zone: 'Poniente' },
  { slug: 'renca', name: 'Renca', lat: -33.4056, lng: -70.6969, zone: 'Poniente' },
  { slug: 'la-pintana', name: 'La Pintana', lat: -33.5836, lng: -70.6347, zone: 'Sur' },
  { slug: 'los-andes', name: 'Los Andes', lat: -32.8339, lng: -70.5981, zone: 'Valparaíso' },
  { slug: 'san-felipe', name: 'San Felipe', lat: -32.7483, lng: -70.7244, zone: 'Valparaíso' },
];

export const LOCATION_SLUGS = LOCATIONS.map((l) => l.slug) as readonly string[];
export const LOCATION_NAMES: Record<string, string> = Object.fromEntries(
  LOCATIONS.map((l) => [l.slug, l.name]),
);

export const ZONE_CONTEXT: Record<string, string> = {
  'las-condes':
    'sector oriente premium de Santiago, oficinas corporativas, residencias de lujo y embajadas',
  vitacura: 'sector oriente premium, casas de alto valor y clinicas privadas',
  'santiago-centro':
    'centro de Santiago, area comercial y turistica con alta concentracion de oficinas',
  huechuraba: 'sector norte de Santiago, centros comerciales y empresas',
  'la-reina': 'sector oriente residencial, tranquilo y familiar',
  'lo-barnechea': 'sector oriente, areas residenciales y propriedades rurales',
  conchali: 'sector poniente de Santiago, area residencial y comercial',
  pudahuel: 'sector poniente, cercano al aeropuerto y zonas industriales',
  renca: 'sector poniente, area industrial y residencial',
  quilicura: 'sector norte, zona industrial y centros logisticos',
  lampa: 'sector norte, area de expansion y parques industriales',
  'la-pintana': 'sector sur de Santiago, area predominantemente residencial',
  'los-andes': 'ciudad en la region de Valparaiso, area urbana y turistica',
  'san-felipe': 'ciudad en la region de Valparaiso, area comercial y residencial',
};

export const ZONE_COLORS: Record<string, string> = {
  Oriente: 'red',
  Centro: 'blue',
  Norte: 'yellow',
  Sur: 'blue',
  Poniente: 'purple',
  Occidente: 'purple',
  Valparaíso: 'green',
};

export const ZONE_DOT_COLORS: Record<string, string> = {
  red: '#EF4444',
  blue: '#3B82F6',
  yellow: '#F59E0B',
  purple: '#8B5CF6',
  green: '#10B981',
};

export const NAV_LINKS = [
  { href: '/', label: 'Inicio' },
  { href: '/servicios', label: 'Servicios' },
  { href: '/ubicaciones', label: 'Ubicaciones' },
  { href: '/sectores', label: 'Sectores' },
  { href: '/guard-pod', label: 'Guard Pod' },
  { href: '/ajax-systems', label: 'Ajax Systems' },
  { href: '/nosotros', label: 'Nosotros' },
  { href: '/contacto', label: 'Contacto' },
];

export const ADMIN_NAV = [
  { id: 'cms', label: 'CMS — Editor de Contenido', href: '/admin', icon: 'edit' },
  { id: 'adn', label: 'ADN de Marca — Identidad Corporativa', href: '/admin/brand', icon: 'dna' },
  { id: 'crm', label: 'CRM — Pipeline de Leads', href: '/admin/crm', icon: 'users' },
  { id: 'intel', label: 'Intel Hub — Inteligencia Competitiva', href: '/admin/intel', icon: 'radar' },
  { id: 'media', label: 'Biblioteca de Medios', href: '/admin/media', icon: 'image' },
  { id: 'chat', label: 'Chat con Agentes IA', href: '/admin/chat', icon: 'chat' },
] as const;

export const API_TIMEOUT_MS = 15_000;

// Versión del bundle (para cache-busting).
export const BUNDLE_VERSION = 'v2.1.0';
