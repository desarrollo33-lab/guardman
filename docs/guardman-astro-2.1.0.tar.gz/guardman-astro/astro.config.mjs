// GuardMan Astro 6 — Configuración para Cloudflare WORKERS (no Pages).
// Usamos `mode: 'advanced'` del adapter @astrojs/cloudflare, que produce
// un Worker con bindings completos (D1, R2, KV, DO, Queues, Workflows).
// Los assets estáticos se sirven vía el binding `ASSETS` (Workers Static Assets).

import { defineConfig } from 'astro/config';
import cloudflare from '@astrojs/cloudflare';
import react from '@astrojs/react';
import tailwindcss from '@tailwindcss/vite';

const SITE_URL = process.env.PUBLIC_SITE_URL ?? 'https://guardman.cl';

export default defineConfig({
  site: SITE_URL,
  output: 'server',
  adapter: cloudflare({
    mode: 'advanced', // ← Workers puro, no Pages
    platformProxy: { enabled: true },
  }),
  integrations: [react()],
  vite: {
    plugins: [tailwindcss()],
    ssr: { external: ['node:fs', 'node:path'] },
  },
  image: { service: { entrypoint: 'astro/assets/services/sharp' } },
  devToolbar: { enabled: false },
  prefetch: { prefetchAll: true, defaultStrategy: 'viewport' },
});
