# Auditoría Forense — GuardMan Admin v1.0.0

**Fecha:** 2026-06-27  
**Alcance:** `guardman-admin-1.0.0.tar.gz` — 348 archivos, ~44.500 LOC TypeScript/TSX  
**Stack analizado:** Cloudflare Worker monolítico + Vite/React 19 SPA + D1 + R2 + KV + Queues + Durable Objects + Workflows + Cron  
**Auditor:** Super Z (GLM)

---

## 0. Resumen Ejecutivo

El proyecto **GuardMan Admin** es funcionalmente ambicioso — un CMS, CRM, Intel Hub, Media Editor y panel de agentes IA en una sola aplicación — pero arrastra **deuda técnica crítica acumulada** por más de 6 meses de iteración aditiva sin refactorización estructural. Los hallazgos previos documentados en `AUDITORIA_FORENSE_CMS_2026-05-10.md`, `AUDITORIA_FORENSE_CRM_2026-05-10.md`, `AUDITORIA_FORENSE_MEDIA_EDITOR_2026-05-11.md` y `AUDITORIA_FORENSE_TEST_2026-05-10.md` ya identificaron la mayoría de los problemas. Esta auditoría los consolida y añade nuevos hallazgos estructurales.

**Estado de salud general:** 🔴 Crítico — funciona en producción por compensación constante (parches, fallbacks, dobles rutas), no por diseño robusto.

**Top 5 problemas que justifican la migración:**

1. **Dual AI provider chaos** — `callMiniMaxAI()` en realidad llama a DeepSeek usando `MINIMAX_API_KEY`. Confusión nominal que hace imposible debuguear generación fallida.
2. **3 formatos de persistencia incompatibles** — `content_versions`, `static_page_content` y `combo_content` con shapes distintos que el SSR normaliza ad-hoc con `content?.sections || content || {}`.
3. **Código muerto masivo** — `PipelineBar` (2 copias), `SEOScorePanel`, `api.ts` legacy, hooks duplicados (`useMockApi`/`useRealApi`/`useApi`), `GMContentAgent` (500 LOC) sin uso desde el frontend.
4. **Index.ts monolítico** — 1.250 LOC con router + 5 builders HTML inline + manejo de cron + queue consumer + agents router + static assets. Mezcla 7 responsabilidades.
5. **Secretos y CORS débiles** — `AUTH_TOKEN` reutilizado como password de login, bearer de API y token de WebSocket. `Access-Control-Allow-Origin: '*'` en endpoints sensibles.

---

## 1. Arquitectura Actual — Anatomía del Monolito

```
guardman-admin/                       # Raíz — 348 archivos
├── src/                              # Cloudflare Worker (backend)
│   ├── index.ts                      # 1,250 LOC — Router principal + SSR + builders inline
│   ├── api.ts                        # 275 LOC — Router legacy v7 (DUPLICADO de src/api/)
│   ├── api/                          # Router modular v5.2 (el bueno)
│   │   ├── index.ts
│   │   ├── middleware/{auth,cors}.ts
│   │   ├── routes/ (22 archivos)     # ~6,000 LOC — admin, agents, ai, brand, cms, content,
│   │   │                              # content-extra, cuestionario-ceo, crm/* (8), intel/* (8),
│   │   │                              # media, memory, monitor, orchestrator, preview, search,
│   │   │                              # serper, seo, workflows
│   │   └── services/ (4 archivos)
│   ├── agents/ (8 archivos)          # ~3,200 LOC — Durable Objects
│   ├── core/scheduler.ts             # Cron dispatcher
│   ├── durable/ (2 archivos)         # ai-generator, rate-limiter
│   ├── mcp/server.ts                 # MCP endpoint
│   ├── queues/ (2 archivos)          # consumer, content-queue
│   ├── serper/ (5 archivos)          # Search intelligence pipeline
│   ├── services/ (17 archivos)       # ~2,800 LOC — ai, banned-patterns, brand-context, cache,
│   │                                  # content-generation, db-session, de-generic-pass, guardrails,
│   │                                  # image-prompts, inference, memory, pipeline, preview,
│   │                                  # quality-review, rate-limit, scoring, search, search-seed,
│   │                                  # section-generation, section-merge, section-validators
│   ├── ssr/ (13 archivos)            # ~2,000 LOC — site-data, site-renderer, static-pages,
│   │                                  # 7 HTML builders (string concatenation), 4 content .txt
│   ├── types/index.ts                # Tipos compartidos + constantes
│   ├── utils/location.ts
│   └── workflows/ (6 archivos)       # ~1,200 LOC
├── guardman-admin-ui/                # React SPA (frontend)
│   └── src/
│       ├── App.tsx                   # 280 LOC — Entry + LoginForm + SettingsModal inline
│       ├── components/ (8 carpetas)  # 64 archivos ~12,000 LOC
│       │   ├── Brand/                # 1 archivo
│       │   ├── Chart/                # 1 archivo
│       │   ├── Chat/                 # 5 archivos
│       │   ├── CMS/                  # 3 archivos (CMSPage 1,580 LOC!)
│       │   ├── CRM/                  # 16 archivos ~3,000 LOC
│       │   ├── Editor/               # 1 archivo (Monaco)
│       │   ├── Intel/                # 8 archivos
│       │   ├── Layout/               # 2 archivos
│       │   ├── Media/                # 14 archivos ~2,100 LOC
│       │   ├── Mobile/               # 2 archivos
│       │   ├── Preview/              # 1 archivo
│       │   ├── Publish/              # 4 archivos
│       │   ├── Shared/               # 1 archivo (PipelineBar HUÉRFANO)
│       │   └── UI/                   # 4 archivos (incluye OTRO PipelineBar)
│       ├── hooks/ (6 archivos)       # useApi, useMockApi, useRealApi (DUPLICADOS)
│       ├── lib/falai.ts
│       ├── mocks/crm-data.ts         # 800 LOC
│       └── services/scoring.ts       # Frontend SEO scoring (DUPLICADO de backend)
├── public/                           # Assets estáticos servidos por Worker
│   ├── styles/{site,main,dark}.css   # 3 CSS con tokens duplicados
│   ├── admin/assets/main-*.css|js    # Build del admin SPA servido como ASSETS binding
│   ├── fonts/inter-*.ttf             # 5 pesos
│   └── scripts/main.js
├── sql/ (60+ archivos .sql)          # Migrations sueltas, no versionadas
├── tests/ (unit + integration + forensic)
├── docs/ (20+ .md)                   # Planes, sesiones, lighthouse reports
└── 20+ .md sueltos en raíz           # Sesiones, planes, auditorías previas
```

---

## 2. Hallazgos Críticos (Bloqueantes)

### 🔴 C-01 — Dual AI Provider Chaos

**Archivos:** `src/services/ai.ts`, `src/api/routes/cms.ts`, `src/services/inference.ts`, `src/agents/content-agent.ts`

| Endpoint | Proveedor real | URL destino | Variable de entorno |
|---|---|---|---|
| `/api/cms/generate` | DeepSeek | `api.deepseek.com/v1/chat/completions` | `MINIMAX_API_KEY` |
| `/api/cms/regenerate` | DeepSeek | `api.deepseek.com` vía `callMiniMaxAI()` | `MINIMAX_API_KEY` |
| Review (Workers AI) | Cloudflare | `gateway.ai.cloudflare.com` | `AI_GATEWAY_TOKEN` |
| Fallback `inferDirect` | MiniMax | `api.minimax.io/anthropic/v1/messages` | `MINIMAX_API_KEY` |
| Content Agent DO | DeepSeek | `api.deepseek.com` vía `callMiniMaxAI()` | `MINIMAX_API_KEY` |

La función `callMiniMaxAI()` **no llama a MiniMax**. Llama a DeepSeek usando una variable llamada `MINIMAX_API_KEY`. Si la key almacenada en el secret es realmente de MiniMax, todo falla con `401`. Si es de DeepSeek, los fallbacks a MiniMax fallan. Imposible de razonar sin inspeccionar el dashboard de Cloudflare.

```ts
// src/services/ai.ts:298 — el nombre miente
const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${env.MINIMAX_API_KEY}` }, // ← key de MiniMax, URL de DeepSeek
```

### 🔴 C-02 — JSON.parse sin blindaje en el servicio de IA

**Archivo:** `src/services/ai.ts:310-315`

```ts
const data = await response.json() as any;
let text = data.choices?.[0]?.message?.content || '';
// ... stripping markdown ...
const parsed = JSON.parse(text) as GeneratedContent; // ← SIN try/catch
```

Si DeepSeek devuelve JSON truncado por límite de tokens, comentarios `//`, markdown mal cerrado o un error empaquetado como texto 200 OK, `JSON.parse` lanza excepción no capturada dentro de `callMiniMaxAI`. El caller recibe un `500` opaco sin contexto.

### 🔴 C-03 — Merge destructivo en `CMSPage.tsx` (regeneración IA)

**Archivo:** `guardman-admin-ui/src/components/CMS/CMSPage.tsx:535-620`

`regenerateContent` hace `deepMerge` para preservar campos críticos, pero la lista de preservados es **incompleta**:

**Preserva:** `hero.image`, `intro.image`, `hero.badge`, `hero.cta1_text/cta1_href`, `hero.cta2_text/cta2_href`, `clientes.items`, `nosotros.image`, `guardpod.image`, `ajax.image`.

**Pierde:** `homeServices`, `homeSectors`, `homeZones`, `homeClientLogos`, `stats` (en estáticas), `hero_ctas`, `trust_badges`, `body_content`.

Hacer clic en "Regenerar con IA" borra ediciones manuales en esas secciones. El usuario no recibe advertencia.

### 🔴 C-04 — Doble fuente de verdad en Homepage

**Archivos:** `src/api/routes/cms.ts:230-280`, `src/services/content-generation.ts`

La homepage se guarda simultáneamente en:
1. `content_versions` (`entity_type='page'`, `entity_slug='homepage'`)
2. `static_page_content` (`slug='homepage'`)

Si la inserción en `content_versions` falla, el CMS responde `ok: true` igualmente porque el `catch` solo hace `console.warn`. El frontend cree que guardó. El SSR lee de `static_page_content` (funciona), pero el Content Agent y el pipeline de calidad leen de `content_versions` (no funciona). Caché invalidada con `invalidateCache(env, 'homepage')` sin distinguir cuál de las dos fuentes.

### 🔴 C-05 — Auth Token reutilizado como password, bearer y WebSocket token

**Archivos:** `src/api/middleware/auth.ts`, `src/index.ts`, `src/types/index.ts`

```ts
// login endpoint
if (body.password === env.AUTH_TOKEN) { ... }
```

El mismo `AUTH_TOKEN` se usa como:
- Contraseña del panel admin (comparación directa, sin hash)
- Bearer token para todas las APIs (`Authorization: Bearer <AUTH_TOKEN>`)
- Token de WebSocket para agents

Si se filtra (logs, frontend en localStorage, repo público), un atacante obtiene acceso total sin posibilidad de rotación selectiva.

### 🔴 C-06 — CORS abierto en endpoints sensibles

**Archivo:** `src/types/index.ts`

```ts
export const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};
```

Aplicado globalmente a `/api/cms/*`, `/api/content/*`, `/api/media/*`, `/api/crm/*`, `/api/intel/*`. Aunque requieren auth, un sitio malicioso puede:
- Hacer preflight requests y medir timing (timing attacks)
- Intentar CSRF con credenciales si el navegador cachea el token
- Descubrir estructura de endpoints mediante OPTIONS probing

---

## 3. Código Muerto y Duplicación

### 🟠 D-01 — `PipelineBar` duplicado y huérfano

**Archivos:** `guardman-admin-ui/src/components/Shared/PipelineBar.tsx`, `guardman-admin-ui/src/components/UI/PipelineBar.tsx`, `guardman-admin-ui/src/components/UI/PipelineBar.test.tsx`

Existen **dos copias** del mismo componente en dos carpetas distintas. Ninguna es importada por ninguna página. El test prueba el componente huérfano.

### 🟠 D-02 — `SEOScorePanel` creado pero no integrado

**Archivo:** `guardman-admin-ui/src/components/CMS/SEOScorePanel.tsx` (140 LOC)

Componente que muestra score SEO calculado. Nunca importado por `CMSPage.tsx`. Código muerto.

### 🟠 D-03 — `src/api.ts` legacy vs `src/api/index.ts` modular

**Archivos:** `src/api.ts` (275 LOC, router v7 legacy), `src/api/index.ts` (80 LOC, router v5.2 modular)

`src/index.ts` importa y usa `handleModularRoutes` de `src/api/index.ts`. El archivo `src/api.ts` ya no se usa pero sigue en el repo y compila, generando ruido en búsquedas.

### 🟠 D-04 — Hooks de API triplicados

**Archivos:** `guardman-admin-ui/src/hooks/{useApi,useMockApi,useRealApi}.ts`

`useApi` es un switch que delega a `useMockApi` o `useRealApi` según `localStorage.getItem('gm_demo_mode')`. Los 3 hooks implementan la misma interfaz con código 80% duplicado. Patrón frágil: agregar un endpoint requiere cambios en 3 archivos.

### 🟠 D-05 — `GMContentAgent` (Durable Object) huérfano

**Archivo:** `src/agents/content-agent.ts` (~500 LOC)

Durable Object sofisticado con:
- Fibers para recuperación ante crashes
- Iteración hasta 3 intentos con feedback
- Auto-approve si score ≥ 85
- Broadcasting por WebSocket

El frontend del CMS no lo usa. Llama a endpoints REST (`/api/cms/generate`, `/api/cms/regenerate`) que ejecutan lógica paralela. El Content Agent solo se activaría vía WebSocket directo o workflows. ~500 LOC de código complejo sin uso en el flujo principal.

### 🟠 D-06 — `Env` type duplicado

**Archivos:** `src/types/index.ts`, `src/api.ts`

La interfaz `Env` (bindings de Cloudflare) está definida en ambos archivos con pequeñas diferencias. TS no alerta porque se usan en contextos distintos, pero al cambiar un binding hay que actualizar ambos.

### 🟠 D-07 — CSS_V hardcoded en 5 lugares

**Archivos:** `src/index.ts` (5 ocurrencias), `src/ssr/site-renderer.ts` (centralizado)

`CSS_V = '1778255342'` se hardcodea inline en `src/index.ts` al construir el HTML del admin SPA wrapper, además de estar exportado desde `site-renderer.ts`. Si solo se actualiza uno, las caches del navegador sirven CSS stale.

### 🟠 D-08 — Rutas de CRM duplicadas con Intel

**Archivos:** `src/api/routes/crm/leads.ts` (`POST /api/crm/leads/capture`), `src/api/routes/intel/crud.ts` (`POST /api/intel/leads/capture`)

Dos endpoints que hacen lo mismo: recibir un lead del formulario público y guardarlo. Cada uno inserta en `crm_leads` con schemas ligeramente distintos. Los leads pueden quedar duplicados o con campos faltantes según cuál reciba el request.

### 🟠 D-09 — Frontend SEO scoring duplica backend

**Archivos:** `guardman-admin-ui/src/services/scoring.ts` (80 LOC), `src/services/scoring.ts` (backend), `guardman-admin-ui/src/utils/seo-scorer.ts` (otra copia frontend)

Tres implementaciones del scorer SEO. Backend es la autoritativa. Las dos del frontend divergen en criterios y pesos.

### 🟠 D-10 — `static-pages.ts` y builders HTML inline

**Archivos:** `src/ssr/static-pages.ts`, `src/ssr/{nosotros,contacto,cotizacion,guardpod,ajax,privacidad,terminos}-html.ts`, `src/index.ts` (`buildGraciasPage`, `build404Page`, `build500Page` inline)

Cada página estática tiene:
1. Un archivo `-content.txt` con el HTML del `<main>` como string
2. Un archivo `-html.ts` que envuelve el contenido con `hdr()` + `ftr()`
3. Builders adicionales inline en `src/index.ts` para `gracias`, `404`, `500`

Patrón frágil — el contenido vive como string HTML en archivos `.txt` que el bundler no type-checkea ni tree-shakea.

---

## 4. Inconexiones y Bugs Lógicos

### 🟠 B-01 — `useEffect` en Sidebar dispara fetch cada 30s sin cleanup real

**Archivo:** `guardman-admin-ui/src/components/Layout/Sidebar.tsx:32-46`

```tsx
useEffect(() => {
  const fetchLeadCount = async () => { ... };
  fetchLeadCount();
  const interval = setInterval(fetchLeadCount, 30000);
  return () => clearInterval(interval);
}, []);
```

Funciona, pero el `fetch` no tiene abort signal. Si el componente se desmonta antes de que termine el fetch, se llama `setLeadCount` sobre componente desmontado (warning React). Además, el polling sigue aunque el usuario esté inactivo o el tab en background.

### 🟠 B-02 — Modo demo CRM requiere recarga manual

**Archivo:** `guardman-admin-ui/src/App.tsx:202-208`

```tsx
const toggleDemo = () => {
  const next = !demoMode;
  setDemoMode(next);
  if (next) localStorage.setItem('gm_demo_mode', 'crm');
  else localStorage.removeItem('gm_demo_mode');
  window.location.reload(); // ← UX brusca
};
```

Activar modo demo recarga la página completa. Desactivar también. No hay transición.

### 🟠 B-03 — `onSendMessage` global event sin cleanup

**Archivo:** `guardman-admin-ui/src/App.tsx:31-33`

```tsx
const handleSendMessage = useCallback((message: string) => {
  window.dispatchEvent(new CustomEvent('gm:send-message', { detail: message }));
}, []);
```

Patrón event-emitter global. Si `ChatView` se monta y desmonta, los listeners deben gestionarse manualmente. No hay rastro de cuántos componentes escuchan `gm:send-message` — búsqueda con grep muestra 3 archivos pero el acoplamiento es invisible.

### 🟠 B-04 — AppLayout no usa `onSendMessage` ni `onToggleHistory`

**Archivo:** `guardman-admin-ui/src/components/Layout/AppLayout.tsx:21`

```tsx
export function AppLayout({ onAction, activeView, children }: AppLayoutProps) {
```

El componente recibe `onSendMessage` y `onToggleHistory` como props pero los ignora en la firma. TypeScript no alerta porque el tipo está declarado. Las funciones se pierden.

### 🟠 B-05 — Hook `useApi` no maneja 401

**Archivo:** `guardman-admin-ui/src/hooks/useRealApi.ts`

Cualquier fetch con token expirado retorna 401. El hook deja el state en `error` pero no redirige al login ni limpia el token. El usuario ve "Error" sin contexto.

### 🟠 B-06 — Build script de Worker usa `cp -r src/dist/* dist/`

**Archivo:** `package.json:9`

```json
"build": "vite build && cp -r src/dist/* dist/"
```

El `cp -r` falla en Windows. Asume Unix. No hay script cross-platform. Además, `src/dist` es una carpeta de build dentro del source — contamina el árbol de código.

### 🟠 B-07 — Cron de Workflows sin idempotencia

**Archivo:** `src/core/scheduler.ts`

Los 5 crons semanales lanzan workflows. Si el cron falla y se re-ejecuta, el workflow se instancia de nuevo sin verificar si ya hay uno en curso. Los workflows `BulkGenerateWorkflow` y `SerperScanWorkflow` consumen cuota de API de IA y Serper sin control.

### 🟠 B-08 — `wrangler.jsonc` expone bindings sin dependencia circular clara

**Archivo:** `wrangler.jsonc`

El Worker declara bindings para `DB`, `IMAGES`, `CACHE`, `SEO_CONTENT_QUEUE`, 5 Durable Objects, 6 Workflows, 5 crons. Cambiar un binding requiere deploy completo. No hay dev mode con mocks — todo depende del remote.

### 🟠 B-09 — CSS admin references `--accent-soft` sin declararlo en `:root`

**Archivo:** `guardman-admin-ui/src/styles/globals.css:45`

```css
--accent-soft: rgba(59,130,246,0.12);
```

Declarado en `:root` pero Tailwind v4 `@theme` solo registra `--color-accent`. Al usar `bg-accent/10` se resuelve distinto que `var(--accent-soft)`. Dos sistemas de tokens coexisten sin sincronía.

### 🟠 B-10 — `data-od-id` atributos sin consumidor

Los `data-od-id="hero"`, `data-od-id="stats"`, etc. en los .txt de contenido público son marcadores del Open Design prototype para edición visual. **No hay código que los lea**. Sobreviven como muertos en producción.

---

## 5. Problemas de Diseño y UX

### 🟡 U-01 — Sitio público sin dark mode consistente

`guard-pod` y `ajax-systems` usan `class="bg-dark"` y `class="section-dark"`. `nosotros` mezcla `bg-white`, `bg-neutral`, `staff-section` (dark). Sin toggle de tema, solo clases hardcoded. CSS define tokens light y dark pero solo se aplican vía clase.

### 🟡 U-02 — Admin sin responsive en CRM Pipeline

`CRMPipeline.tsx` renderiza un kanban con 6 columnas. En móvil aparece scroll horizontal sin indicador. Las tarjetas no colapsan.

### 🟡 U-03 — Login hardcodea URL del backend

**Archivo:** `guardman-admin-ui/src/App.tsx:94-101`

```tsx
const response = await fetch(
  'https://guardman.oficinadesarrollo33.workers.dev/api/login',
  ...
);
```

URL del Worker hardcoded en el código del frontend. Sin variable de entorno. Sin fallback. Para cambiar de ambiente (staging/prod) hay que editar el código.

### 🟡 U-04 — ToastProvider sin animación de salida

**Archivo:** `guardman-admin-ui/src/components/UI/Toast.tsx`

Los toasts aparecen y desaparecen sin transición. El `setTimeout` los elimina del DOM abruptamente.

### 🟡 U-05 — Monaco Editor carga ~2MB sin lazy loading

**Archivo:** `guardman-admin-ui/src/components/Editor/MonacoEditor.tsx`

Import directo de `@monaco-editor/react` en `CMSPage.tsx`. Sin `lazy()` ni `Suspense`. Cada visita al CMS descarga Monaco aunque el usuario no abra el editor de código.

---

## 6. Seguridad

### 🟡 S-01 — LocalStorage para token de sesión (sin expiración)

**Archivo:** `guardman-admin-ui/src/hooks/useApi.ts`

```ts
const stored = localStorage.getItem('gm_token');
if (stored && stored !== 'undefined' && stored !== 'null') return stored;
```

Token permanente en localStorage. Vulnerable a XSS. No expira. No se refresca. Las verificaciones `!== 'undefined'` revelan que en algún momento se guardaron strings `'undefined'` y `'null'` — bug previo no resuelto, solo mitigado.

### 🟡 S-02 — Secretos en `wrangler.jsonc` y `.dev.vars` sin `.gitignore` claro

No hay `.gitignore` visible en la raíz del proyecto. Los archivos `.dev.vars` (con `MINIMAX_API_KEY`, `FAL_API_KEY`, etc.) podrían haberse commiteado en algún punto.

### 🟡 S-03 — Sin rate limiting en `/api/login`

**Archivo:** `src/index.ts`

El endpoint de login no usa el `RateLimiter` Durable Object que sí está implementado. Brute force del `AUTH_TOKEN` es posible.

### 🟡 S-04 — Comparación de password sin constant-time

**Archivo:** `src/api/middleware/auth.ts`

```ts
if (body.password === env.AUTH_TOKEN) { ... }
```

Comparación directa con `===`. Vulnerable a timing attacks teóricos (aunque mitigado por red y Node internals).

---

## 7. Performance

### 🟡 P-01 — CSS_V cache-busting manual

`CSS_V = '1778255342'` se actualiza a mano. Build automatizado no lo incrementa. Deploy de fix de CSS requiere editar manualmente el string o los navegadores servirán versión stale.

### 🟡 P-02 — Sin code splitting en admin SPA

`App.tsx` importa los 5 componentes principales (`CMSPage`, `MediaEditor`, `ADNPage`, `IntelPage`, `CRMPage`) de forma estática. Bundle inicial ~495KB incluye código de las 5 vistas aunque el usuario solo use una.

### 🟡 P-03 — `CRMPage.tsx` re-renderiza toda la página al cambiar de sub-vista

El CRM usa `useState` para sub-vista (pipeline / dashboard / mi-día / clients / proposals). Cambiar de tab desmonta y vuelve a montar. Sin memoización ni persistencia de estado.

### 🟡 P-04 — Monaco Editor y Media Editor son islas pesadas sin lazy

En `CMSPage.tsx` y `MediaEditor.tsx` se importan componentes pesados sin `React.lazy`. Bundle de la página supera 1MB.

### 🟡 P-05 — Sin ISR ni cache HTTP en endpoints públicos

`/api/cms/content` y `/api/cms/list` retornan JSON sin `Cache-Control`. Cada request hit D1. Cloudflare CDN no cachea.

---

## 8. Documentación y Procesos

### 🟢 X-01 — 20+ archivos .md sueltos en la raíz del proyecto

`SESION_2026-05-08.md`, `SESION_2026-05-08_COMPLETA.md`, `AUDITORIA_FORENSE_CMS_2026-05-10.md`, `AUDITORIA_FORENSE_CRM_2026-05-10.md`, `PLAN_ADOPCION_PROTOTIPO_V13.md`, `PLAN_GENERACION_MODULAR_V1.md`, `PLAN_IMAGENES_GUARDMAN_COMPLETO.md`, `PLAN_REDISEÑO_MEDIA_EDITOR_V4.md`, `INVESTIGACION_CMS_FRONTEND.md`, etc. Sin índice. Sin orden. Sesiones repetidas. Planes superseded pero no archivados.

### 🟢 X-02 — 60+ archivos SQL sin sistema de migraciones

**Directorio:** `sql/`

`faqs-batch-0.sql` hasta `faqs-batch-12.sql`, `auditoria-exhaustiva.sql`, `auditoria-final.sql`, `auditoria-terminos.sql`, `cuestionario-ceo-v2.sql`, `v3-migrations.sql`, `v4-frontend.sql`, `v5-static-pages.sql`, `v6-indexes.sql`, `v12-intel-snapshots.sql`, etc. No hay tabla `_migrations`. No hay manera de saber qué se aplicó. Los nombres sugieren versiones pero no hay orden estricto.

### 🟢 X-03 — Carpeta `sql/migrations/` coexiste con `sql/` suelto

`sql/migrations/{v6-indexes,section-versions,log-session,intel-tables,crm-commercial,published-versions}.sql` — migraciones "estructuradas" que conviven con 60 archivos sueltos. Dos convenciones en el mismo repo.

### 🟢 X-04 — `tests/forensic/audit.test.ts` documenta bugs en código de producción

**Archivo:** `tests/forensic/audit.test.ts`

El test de auditoría forense existe. Si falla, los bugs siguen en producción. Los tests son de documentación, no de regresión.

### 🟢 X-05 — `gm_test.json` y `build_log.txt` commiteados

Archivos de output de build y test commiteados en el repo. Contaminan el árbol y rompen `git blame`.

---

## 9. Métricas de Deuda Técnica

| Métrica | Valor actual | Objetivo post-migración |
|---|---|---|
| LOC totales TypeScript/TSX | ~44.500 | ~22.000 (-50%) |
| Archivos TypeScript | 204 | ~120 (-41%) |
| Archivos CRM | 16 | 6 (-62%) |
| LOC CRM | ~3.000 | ~1.200 (-60%) |
| Archivos .md sueltos en raíz | 20+ | 0 (movidos a `docs/sesiones/`) |
| Archivos .sql sin versionar | 60+ | 0 (consolidados en `migrations/`) |
| Duplicados de PipelineBar | 2 | 0 |
| Hooks de API duplicados | 3 (`useApi`+`useMockApi`+`useRealApi`) | 1 |
| CSS_V hardcoded en index.ts | 5 ocurrencias | 0 (un solo source) |
| Endpoints CRM duplicados con Intel | 1 (`/leads/capture`) | 0 |
| Componentes muertos confirmados | 3 (`PipelineBar` x2, `SEOScorePanel`) | 0 |
| LocalStorage para token | Sí | Sí (con expiración y refresh) |
| CORS `*` en endpoints sensibles | Sí | No (origen específico) |
| Bundle admin SPA | ~495KB | < 350KB con code splitting |
| Lighthouse homepage | 85+ | 95+ |

---

## 10. Recomendaciones (priorizadas)

### P0 — Bloqueantes (resolver antes de migrar o durante)

1. **Unificar proveedor de IA.** Renombrar `MINIMAX_API_KEY` → `AI_API_KEY`. Crear `callAI(provider, ...)` con switch explícito. Eliminar el fallback `inferDirect` a MiniMax si no se usa.
2. **Blindar `JSON.parse`** en `src/services/ai.ts:310` con try/catch que loguee el texto crudo y devuelva error estructurado.
3. **Completar preservación en `regenerateContent`** del CMS o invertir el merge: "inyectar solo los campos que la IA debe tocar" en vez de "preservar los que sabemos".
4. **Eliminar doble fuente de homepage.** Decidir UNA tabla (`static_page_content` o `content_versions`). Eliminar la otra.
5. **Separar Auth Token de password.** Tabla `admin_users` con hashes bcrypt. JWT de 2h con refresh. `AUTH_TOKEN` solo para API worker→worker.
6. **CORS restrictivo.** Lista de orígenes permitidos en `ALLOWED_ORIGINS` env var. Rechazar otros.
7. **Rate limiting en `/api/login`.** 5 intentos por IP cada 15min usando el `RateLimiter` DO existente.

### P1 — Alta prioridad (durante migración Astro)

8. **Eliminar código muerto:** `PipelineBar` x2, `SEOScorePanel`, `src/api.ts` legacy, `useMockApi`+`useRealApi` (unificar en `useApi`).
9. **Evaluar `GMContentAgent`** — integrar al CMS vía WebSocket o eliminar.
10. **Centralizar constantes:** un solo `src/lib/constants.ts` con `SITE_URL`, `PHONE`, `SERVICE_NAMES`, `LOCATION_SLUGS`, `ZONE_CONTEXT`. Sin hardcoded URLs en componentes.
11. **Sistema de migraciones SQL:** tabla `_migrations` + script `npm run migrate`. Aplicar en orden.
12. **Archivar `sql/` sueltos** a `sql/archive/` después de migrar a `migrations/`.
13. **Mover .md sueltos a `docs/sesiones/`** con índice en `docs/README.md`.

### P2 — Media prioridad (post-migración)

14. **Code splitting en admin SPA** con `React.lazy` para Monaco, MediaEditor, CRMPipeline.
15. **Cache HTTP en endpoints públicos** — `Cache-Control: public, max-age=300` en `/api/cms/content`.
16. **ISR para páginas públicas** — Astro + Cloudflare KV con revalidación on-demand.
17. **Idempotencia en workflows** — verificar si ya hay instancia en curso antes de lanzar.
18. **`.gitignore` estricto** — `.dev.vars`, `dist/`, `src/dist/`, `build_log.txt`, `gm_test.json`.

### P3 — Mejora continua

19. **Renombrar archivos** — `MINIMAX_API_KEY` env var, `callMiniMaxAI` → `callAI`, `useMockApi` eliminar.
20. **Tests de regresión** — reemplazar `tests/forensic/audit.test.ts` por tests que validen que los bugs NO existen (positivos).
21. **CI/CD** — GitHub Actions con build + test + lighthouse check en cada PR.
22. **Documentación viva** — README con setup, scripts, arquitectura actualizada.

---

## 11. Conclusión

El proyecto es **técnicamente rescatable**. La infraestructura Cloudflare (D1, R2, KV, Durable Objects, Workflows, Queues) es sólida y no necesita migración. Los problemas están en la **capa de presentación y API del Worker**, que mezcla responsabilidades, acumula código muerto y arrastra bugs conocidos sin fix estructural.

La migración a **Astro 6** es la oportunidad para:

1. **Separar frontend de API** — Astro en Cloudflare Pages, Worker como API pura.
2. **Eliminar código muerto** — no migrar lo que no se usa.
3. **Unificar constantes y tipos** — un solo `src/lib/`, un solo `src/types/`.
4. **Simplificar CRM** — de 16 a 6 archivos, eliminando features redundantes.
5. **Preservar diseño** — tokens de `globals.css` y `site.css` migrados a Tailwind v4 `@theme`.
6. **Code splitting nativo** — islas React solo donde se necesita interactividad.

La nueva versión entregada en `guardman-astro.tar` aplica estas correcciones sin tocar la infraestructura backend (D1, R2, DO, Workflows siguen funcionando contra el Worker existente).

---

*Fin del reporte. 357 líneas. Preparado para discusión con el equipo.*
