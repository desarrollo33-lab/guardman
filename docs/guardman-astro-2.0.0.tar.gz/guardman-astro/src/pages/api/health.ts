// API endpoint: /api/health — healthcheck simple para monitoreo.
export const GET = () =>
  new Response(
    JSON.stringify({
      ok: true,
      service: 'guardman-astro',
      version: '2.0.0',
      timestamp: new Date().toISOString(),
    }),
    {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    },
  );
