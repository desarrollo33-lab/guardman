// ChatView — chat con agentes IA vía WebSocket.
// Migración de 5 archivos (800 LOC) a 1 archivo (~200 LOC).
// Usa PartySocket para WebSocket a Durable Object en el Worker.

import { useEffect, useRef, useState } from 'react';
import { SITE } from '../../lib/constants';
import { getToken } from '../../lib/auth';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

const WS_URL = `${SITE.API_URL.replace('https', 'wss')}/api/agents/chat`;

export default function ChatView() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [connected, setConnected] = useState(false);
  const [sending, setSending] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const token = getToken();
    if (!token) {
      setMessages([{ id: '1', role: 'assistant', content: 'Debes iniciar sesión para usar el chat.', timestamp: Date.now() }]);
      return;
    }

    try {
      const ws = new WebSocket(`${WS_URL}?token=${encodeURIComponent(token)}`);
      wsRef.current = ws;

      ws.onopen = () => {
        setConnected(true);
        setMessages([{
          id: 'welcome',
          role: 'assistant',
          content: '👋 Hola, soy el agente IA de GuardMan. ¿En qué puedo ayudarte?',
          timestamp: Date.now(),
        }]);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'message' || data.type === 'response') {
            setMessages((prev) => [...prev, {
              id: String(Date.now()),
              role: 'assistant',
              content: data.content ?? data.message ?? '',
              timestamp: Date.now(),
            }]);
            setSending(false);
          }
        } catch {
          // Mensaje plano
          setMessages((prev) => [...prev, {
            id: String(Date.now()),
            role: 'assistant',
            content: event.data,
            timestamp: Date.now(),
          }]);
          setSending(false);
        }
      };

      ws.onerror = () => {
        setConnected(false);
        setMessages((prev) => [...prev, {
          id: 'err',
          role: 'assistant',
          content: '⚠️ No se pudo conectar al agente. Verifica tu conexión.',
          timestamp: Date.now(),
        }]);
      };

      ws.onclose = () => setConnected(false);

      return () => ws.close();
    } catch (err) {
      setMessages([{ id: 'err', role: 'assistant', content: 'Error inicializando WebSocket.', timestamp: Date.now() }]);
    }
  }, []);

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !wsRef.current || sending) return;
    const msg = input.trim();
    setMessages((prev) => [...prev, { id: String(Date.now()), role: 'user', content: msg, timestamp: Date.now() }]);
    wsRef.current.send(JSON.stringify({ type: 'message', content: msg }));
    setInput('');
    setSending(true);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 140px)' }}>
      <div className="panel" style={{ flex: 1, overflow: 'auto', marginBottom: 12 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {messages.map((m) => (
            <div key={m.id} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
              <div style={{
                maxWidth: '70%',
                padding: '10px 14px',
                borderRadius: 'var(--radius)',
                background: m.role === 'user' ? 'var(--color-accent)' : 'var(--color-surface-2)',
                color: m.role === 'user' ? '#fff' : 'var(--color-fg)',
                fontSize: 14,
                lineHeight: 1.5,
              }}>
                {m.content}
              </div>
            </div>
          ))}
          {sending && (
            <div style={{ display: 'flex' }}>
              <div style={{ padding: '10px 14px', borderRadius: 'var(--radius)', background: 'var(--color-surface-2)', color: 'var(--color-fg-muted)', fontSize: 14 }}>
                <span className="spinner" /> Pensando...
              </div>
            </div>
          )}
        </div>
      </div>

      <form onSubmit={send} style={{ display: 'flex', gap: 8 }}>
        <input
          className="form-input"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={connected ? 'Escribe tu mensaje...' : 'Conectando...'}
          disabled={!connected || sending}
          style={{ flex: 1 }}
        />
        <button type="submit" className="btn btn-primary" disabled={!connected || sending || !input.trim()}>
          Enviar
        </button>
      </form>

      <div style={{ marginTop: 8, fontSize: 12, color: 'var(--color-fg-dim)' }}>
        {connected ? '🟢 Conectado' : '🔴 Desconectado'} · WebSocket a Durable Object
      </div>
    </div>
  );
}
