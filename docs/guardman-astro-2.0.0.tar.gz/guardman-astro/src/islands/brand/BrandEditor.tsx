// BrandEditor — ADN de Marca. Migración de ADNPage.tsx (300 LOC) a ~150 LOC.
import { useEffect, useState } from 'react';
import { brand, ApiError } from '../../lib/api';

interface BrandDNA {
  mission?: string;
  vision?: string;
  values?: string[];
  tone?: string;
  audience?: string;
  differentiators?: string[];
  keywords?: string[];
}

const DEFAULT_BRAND: BrandDNA = {
  mission: 'Proteger lo que más te importa con estándares profesionales que superen las expectativas del mercado chileno de seguridad privada.',
  vision: 'Ser la empresa de seguridad privada más confiable de Chile, reconocida por su tecnología propia, personal certificado y compromiso con la excelencia.',
  values: ['Compromiso', 'Profesionalismo', 'Innovación', 'Transparencia'],
  tone: 'Profesional, cercano, confidente. Sin tecnicismos innecesarios. Español de Chile.',
  audience: 'Empresas y residencias de la Región Metropolitana que valoran la certificación OS-10 y la tecnología propia.',
  differentiators: ['Academia OS-10 propia', 'Centro de monitoreo 24/7 propio', 'Guard Pod V1', 'Instalador oficial Ajax Systems'],
  keywords: ['seguridad privada santiago', 'guardias os-10', 'cctv chile', 'monitoreo 24/7', 'ajax systems chile'],
};

export default function BrandEditor() {
  const [brand_dna, setBrandDna] = useState<BrandDNA>(DEFAULT_BRAND);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const data = await brand.get();
        if (data && typeof data === 'object') setBrandDna({ ...DEFAULT_BRAND, ...(data as BrandDNA) });
      } catch (err) {
        // Si falla, usamos DEFAULT_BRAND — el editor sigue siendo funcional
        if (err instanceof ApiError && err.status !== 404) setError(err.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      await brand.save(brand_dna);
      setSuccess('✅ ADN de marca guardado');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Error al guardar');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: 'var(--color-fg-muted)' }}><span className="spinner" /> Cargando...</div>;

  return (
    <div style={{ maxWidth: 720 }}>
      {error && (
        <div className="panel" style={{ borderColor: 'var(--color-error)', background: 'var(--color-error-soft)' }}>
          <p style={{ color: 'var(--color-error)', fontSize: 14 }}>⚠️ {error}</p>
        </div>
      )}
      {success && (
        <div className="panel" style={{ borderColor: 'var(--color-success)', background: 'var(--color-success-soft)' }}>
          <p style={{ color: 'var(--color-success)', fontSize: 14 }}>{success}</p>
        </div>
      )}

      <div className="panel">
        <div className="panel-header">
          <h3>ADN de Marca</h3>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? <><span className="spinner" /> Guardando...</> : '💾 Guardar'}
          </button>
        </div>

        <div className="form-group">
          <label>Misión</label>
          <textarea
            className="form-input"
            rows={3}
            value={brand_dna.mission}
            onChange={(e) => setBrandDna({ ...brand_dna, mission: e.target.value })}
          />
        </div>

        <div className="form-group">
          <label>Visión</label>
          <textarea
            className="form-input"
            rows={3}
            value={brand_dna.vision}
            onChange={(e) => setBrandDna({ ...brand_dna, vision: e.target.value })}
          />
        </div>

        <div className="form-group">
          <label>Tono de comunicación</label>
          <textarea
            className="form-input"
            rows={2}
            value={brand_dna.tone}
            onChange={(e) => setBrandDna({ ...brand_dna, tone: e.target.value })}
          />
        </div>

        <div className="form-group">
          <label>Audiencia objetivo</label>
          <textarea
            className="form-input"
            rows={2}
            value={brand_dna.audience}
            onChange={(e) => setBrandDna({ ...brand_dna, audience: e.target.value })}
          />
        </div>

        <div className="form-group">
          <label>Valores (uno por línea)</label>
          <textarea
            className="form-input"
            rows={4}
            value={(brand_dna.values ?? []).join('\n')}
            onChange={(e) => setBrandDna({ ...brand_dna, values: e.target.value.split('\n').filter(Boolean) })}
          />
        </div>

        <div className="form-group">
          <label>Diferenciadores (uno por línea)</label>
          <textarea
            className="form-input"
            rows={4}
            value={(brand_dna.differentiators ?? []).join('\n')}
            onChange={(e) => setBrandDna({ ...brand_dna, differentiators: e.target.value.split('\n').filter(Boolean) })}
          />
        </div>

        <div className="form-group">
          <label>Keywords estratégicos (uno por línea)</label>
          <textarea
            className="form-input"
            rows={4}
            value={(brand_dna.keywords ?? []).join('\n')}
            onChange={(e) => setBrandDna({ ...brand_dna, keywords: e.target.value.split('\n').filter(Boolean) })}
          />
        </div>
      </div>
    </div>
  );
}
