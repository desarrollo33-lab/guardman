// Mocks para modo demo CRM. Reemplaza a `guardman-admin-ui/src/mocks/crm-data.ts` (800 LOC)
// con una versión más compacta y tipada. Solo se usa cuando
// `localStorage.getItem('gm_demo_mode') === 'crm'`.

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  service: string;
  location: string;
  status: 'new' | 'contacted' | 'visit' | 'proposal' | 'negotiation' | 'won' | 'lost';
  value: number;
  created_at: string;
  notes?: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  service: string;
  location: string;
  since: string;
  monthly_value: number;
}

export interface PipelineColumn {
  status: Lead['status'];
  label: string;
  color: string;
  leads: Lead[];
}

export interface Dashboard {
  kpis: {
    new_leads_30d: number;
    pipeline_value: number;
    won_this_month: number;
    monthly_revenue: number;
  };
  today_agenda: Array<{ time: string; title: string; type: 'visit' | 'call' | 'meeting' }>;
  recent_activity: Array<{ id: string; text: string; when: string }>;
}

const baseDate = '2026-06-';

export const crmMocks = {
  dashboard: {
    kpis: {
      new_leads_30d: 24,
      pipeline_value: 18_500_000,
      won_this_month: 4,
      monthly_revenue: 9_800_000,
    },
    today_agenda: [
      { time: '09:30', title: 'Visita técnica — Condominio Las Vertientes', type: 'visit' as const },
      { time: '11:00', title: 'Llamada seguimiento — Grupo Delta', type: 'call' as const },
      { time: '15:00', title: 'Reunión cotización — Inmobiliaria Andes', type: 'meeting' as const },
    ],
    recent_activity: [
      { id: '1', text: 'Lead convertido: Clínica San Borja', when: 'hace 2h' },
      { id: '2', text: 'Cotización enviada: Hotel Plaza', when: 'hace 4h' },
      { id: '3', text: 'Visita técnica agendada: Condominio Las Vertientes', when: 'ayer' },
    ],
  } satisfies Dashboard,

  leads: [
    { id: 'L001', name: 'María González', email: 'maria@condominiovertientes.cl', phone: '+56930000010', service: 'guardias-de-seguridad', location: 'las-condes', status: 'new', value: 850_000, created_at: `${baseDate}25` },
    { id: 'L002', name: 'Carlos Pérez', email: 'cperez@grupodelta.cl', phone: '+56930000011', service: 'cctv-videovigilancia', location: 'huechuraba', status: 'contacted', value: 1_200_000, created_at: `${baseDate}23` },
    { id: 'L003', name: 'Inmobiliaria Andes', email: 'contacto@iandes.cl', phone: '+56930000012', service: 'control-de-accesos', location: 'santiago-centro', status: 'visit', value: 2_400_000, created_at: `${baseDate}20` },
    { id: 'L004', name: 'Hotel Plaza', email: 'gerencia@hotelplaza.cl', phone: '+56930000013', service: 'seguridad-eventos', location: 'vitacura', status: 'proposal', value: 3_500_000, created_at: `${baseDate}18` },
    { id: 'L005', name: 'Clínica San Borja', email: 'seguridad@clinicasanborja.cl', phone: '+56930000014', service: 'guardias-de-seguridad', location: 'santiago-centro', status: 'negotiation', value: 4_800_000, created_at: `${baseDate}15` },
    { id: 'L006', name: 'Mall Premium', email: 'ops@mallpremium.cl', phone: '+56930000015', service: 'monitoreo-24-7', location: 'las-condes', status: 'won', value: 5_200_000, created_at: `${baseDate}10` },
    { id: 'L007', name: 'Constructora Norte', email: 'ssconstr@cnorte.cl', phone: '+56930000016', service: 'seguridad-industrial', location: 'lampa', status: 'new', value: 1_800_000, created_at: `${baseDate}26` },
    { id: 'L008', name: 'Colegio San Patricio', email: 'rector@sanpatricio.cl', phone: '+56930000017', service: 'guardias-de-seguridad', location: 'la-reina', status: 'lost', value: 900_000, created_at: `${baseDate}12` },
  ] satisfies Lead[],

  clients: [
    { id: 'C001', name: 'Mall Premium', email: 'ops@mallpremium.cl', phone: '+56930000015', service: 'monitoreo-24-7', location: 'las-condes', since: '2024-08-15', monthly_value: 5_200_000 },
    { id: 'C002', name: 'Banco Regional', email: 'compras@bancoregional.cl', phone: '+56930000020', service: 'control-de-accesos', location: 'santiago-centro', since: '2023-11-01', monthly_value: 4_100_000 },
    { id: 'C003', name: 'Hotel Plaza', email: 'gerencia@hotelplaza.cl', phone: '+56930000013', service: 'seguridad-eventos', location: 'vitacura', since: '2025-02-10', monthly_value: 3_200_000 },
    { id: 'C004', name: 'Clínica Las Condes', email: 'facil@clc.cl', phone: '+56930000030', service: 'guardias-de-seguridad', location: 'las-condes', since: '2022-05-20', monthly_value: 6_800_000 },
  ] satisfies Client[],

  get pipeline(): PipelineColumn[] {
    const columns: Array<{ status: Lead['status']; label: string; color: string }> = [
      { status: 'new', label: 'Nuevo', color: '#3B82F6' },
      { status: 'contacted', label: 'Contactado', color: '#8B5CF6' },
      { status: 'visit', label: 'Visita', color: '#F59E0B' },
      { status: 'proposal', label: 'Cotización', color: '#06B6D4' },
      { status: 'negotiation', label: 'Negociación', color: '#EC4899' },
      { status: 'won', label: 'Ganado', color: '#10B981' },
      { status: 'lost', label: 'Perdido', color: '#EF4444' },
    ];
    return columns.map((c) => ({
      ...c,
      leads: this.leads.filter((l) => l.status === c.status),
    }));
  },
};
