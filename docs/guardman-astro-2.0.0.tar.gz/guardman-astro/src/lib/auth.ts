// ════════════════════════════════════════════════════════════════
// GuardMan — Auth helpers.
//
// Token en localStorage con timestamp de expiración (renovación
// automática al detectar 401 desde el API client). En el sistema
// anterior el token era permanente y sin expiración — bug S-01.
// ════════════════════════════════════════════════════════════════

const TOKEN_KEY = 'gm_token';
const TOKEN_EXPIRY_KEY = 'gm_token_expires_at';
const MAX_AGE_MS = 8 * 60 * 60 * 1000; // 8 horas

export function getToken(): string | null {
  if (typeof window === 'undefined') return null;

  const token = localStorage.getItem(TOKEN_KEY);
  if (!token || token === 'undefined' || token === 'null') {
    localStorage.removeItem(TOKEN_KEY);
    return null;
  }

  const expiresAt = Number(localStorage.getItem(TOKEN_EXPIRY_KEY) ?? 0);
  if (expiresAt && Date.now() > expiresAt) {
    clearToken();
    return null;
  }
  return token;
}

export function setToken(token: string): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(TOKEN_EXPIRY_KEY, String(Date.now() + MAX_AGE_MS));
}

export function clearToken(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(TOKEN_EXPIRY_KEY);
}

export function isLoggedIn(): boolean {
  return getToken() !== null;
}

export function requireAuth(): string {
  const token = getToken();
  if (!token) {
    // Redirige al login preservando la URL intentada.
    if (typeof window !== 'undefined') {
      const redirect = encodeURIComponent(window.location.pathname);
      window.location.href = `/admin/login?redirect=${redirect}`;
    }
    throw new Error('Auth required');
  }
  return token;
}

/** Modo demo para CRM (datos mock sin backend). */
export function isDemoMode(): boolean {
  if (typeof window === 'undefined') return false;
  return localStorage.getItem('gm_demo_mode') === 'crm';
}

export function setDemoMode(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  if (enabled) localStorage.setItem('gm_demo_mode', 'crm');
  else localStorage.removeItem('gm_demo_mode');
}
