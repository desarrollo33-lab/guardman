// ════════════════════════════════════════════════════════════════
// GuardMan — Constantes unificadas del sitio y el admin.
// Reemplaza a `src/types/index.ts` (que mezclaba tipos + constantes),
// `guardman-admin-ui/src/App.tsx` (URLs hardcoded) y `src/ssr/site-data.ts`
// (constantes duplicadas). Una sola fuente de verdad.
// ════════════════════════════════════════════════════════════════

export const SITE = {
  NAME: 'GuardMan Chile',
  LEGAL_NAME: 'GuardMan Chile SpA',
  TAGLINE: 'Seguridad Privada OS-10 | 8+ años protegiendo empresas y residencias',
  DESCRIPTION:
    'GuardMan Chile — Seguridad privada con certificación OS-10. Guardias, CCTV, control de accesos, escoltas, monitoreo 24/7, Guard Pod y Ajax Systems. Cobertura en 14 comunas de la Región Metropolitana.',
  URL: import.meta.env.PUBLIC_SITE_URL ?? 'https://guardman.cl',
  API_URL: import.meta.env.PUBLIC_API_URL ?? 'https://guardman.oficinadesarrollo33.workers.dev',
  PHONE: '+56 9 300 000 10',
  PHONE_TEL: '+56930000010',
  EMAIL_INFO: 'info@guardman.cl',
  EMAIL_VENTAS: 'ventas@guardman.cl',
  ADDRESS: 'Av. Américo Vespucio Norte 1980, Providencia, Santiago, Chile',
  FOUNDED_YEAR: 2017,
  CERTIFICATIONS: [
    'Certificación OS-10 vigente verificada por Carabineros de Chile',
    'Capacitación continua en protocolos de seguridad y emergencias',
    'Centro de monitoreo propio 24/7 con operadores especializados',
    '8+ años de experiencia protegiendo empresas y residencias',
  ],
} as const;

export const STATS = {
  GUARDIAS: '500+',
  EMPRESAS: '200+',
  COMUNAS: '14',
  ANOS: '8+',
} as const;

export const SERVICE_NAMES: Record<string, string> = {
  'guardias-de-seguridad': 'Guardias de Seguridad',
  'cctv-videovigilancia': 'CCTV Videovigilancia',
  'control-de-accesos': 'Control de Accesos',
  'escoltas-privados': 'Escoltas Privados',
  'monitoreo-24-7': 'Monitoreo 24/7',
  'seguridad-eventos': 'Seguridad Eventos',
  'seguridad-industrial': 'Seguridad Industrial',
  'auditoria-seguridad': 'Auditoría de Seguridad',
  'guard-pod': 'Guard Pod',
};

export const SERVICE_SLUGS = Object.keys(SERVICE_NAMES);

export const SECTOR_NAMES: Record<string, string> = {
  residencial: 'Residencial',
  comercial: 'Comercial',
  industrial: 'Industrial',
  construccion: 'Construcción',
  educacion: 'Educación',
  eventos: 'Eventos',
  hoteleria: 'Hotelería',
  salud: 'Salud',
  automotriz: 'Automotriz',
};

export const SECTOR_TO_SERVICE: Record<string, string> = {
  comercial: 'guardias-de-seguridad',
  construccion: 'seguridad-industrial',
  educacion: 'guardias-de-seguridad',
  eventos: 'seguridad-eventos',
  industrial: 'seguridad-industrial',
  residencial: 'guardias-de-seguridad',
  salud: 'guardias-de-seguridad',
};

export const LOCATION_SLUGS = [
  'santiago-centro',
  'huechuraba',
  'lampa',
  'quilicura',
  'la-reina',
  'las-condes',
  'lo-barnechea',
  'vitacura',
  'conchali',
  'pudahuel',
  'renca',
  'la-pintana',
  'los-andes',
  'san-felipe',
] as const;

export const LOCATION_NAMES: Record<string, string> = {
  'santiago-centro': 'Santiago Centro',
  huechuraba: 'Huechuraba',
  lampa: 'Lampa',
  quilicura: 'Quilicura',
  'la-reina': 'La Reina',
  'las-condes': 'Las Condes',
  'lo-barnechea': 'Lo Barnechea',
  vitacura: 'Vitacura',
  conchali: 'Conchalí',
  pudahuel: 'Pudahuel',
  renca: 'Renca',
  'la-pintana': 'La Pintana',
  'los-andes': 'Los Andes',
  'san-felipe': 'San Felipe',
};

export const ZONE_CONTEXT: Record<string, string> = {
  'las-condes':
    'sector oriente premium de Santiago, oficinas corporativas, residencias de lujo y embajadas',
  vitacura: 'sector oriente premium, casas de alto valor y clinicas privadas',
  'santiago-centro':
    'centro de Santiago, area comercial y turistica con alta concentracion de oficinas',
  huechuraba: 'sector norte de Santiago, centros comerciales y empresas',
  'la-reina': 'sector oriente residencial, tranquilo y familiar',
  'lo-barnechea': 'sector oriente, areas residenciales y propriedades rurales',
  conchali: 'sector poniente de Santiago, area residencial y comercial',
  pudahuel: 'sector poniente, cercano al aeropuerto y zonas industriales',
  renca: 'sector poniente, area industrial y residencial',
  quilicura: 'sector norte, zona industrial y centros logisticos',
  lampa: 'sector norte, area de expansion y parques industriales',
  'la-pintana': 'sector sur de Santiago, area predominantemente residencial',
  'los-andes': 'ciudad en la region de Valparaiso, area urbana y turistica',
  'san-felipe': 'ciudad en la region de Valparaiso, area comercial y residencial',
};

export const NAV_LINKS = [
  { href: '/', label: 'Inicio' },
  { href: '/servicios', label: 'Servicios' },
  { href: '/ubicaciones', label: 'Ubicaciones' },
  { href: '/sectores', label: 'Sectores' },
  { href: '/guard-pod', label: 'Guard Pod' },
  { href: '/ajax-systems', label: 'Ajax Systems' },
  { href: '/nosotros', label: 'Nosotros' },
  { href: '/contacto', label: 'Contacto' },
];

export const ADMIN_NAV = [
  { id: 'cms', label: 'CMS — Editor de Contenido', href: '/admin', icon: 'edit' },
  { id: 'adn', label: 'ADN de Marca — Identidad Corporativa', href: '/admin/brand', icon: 'dna' },
  { id: 'crm', label: 'CRM — Pipeline de Leads', href: '/admin/crm', icon: 'users' },
  { id: 'intel', label: 'Intel Hub — Inteligencia Competitiva', href: '/admin/intel', icon: 'radar' },
  { id: 'media', label: 'Biblioteca de Medios', href: '/admin/media', icon: 'image' },
  { id: 'chat', label: 'Chat con Agentes IA', href: '/admin/chat', icon: 'chat' },
] as const;

// Headers CORS para el cliente (cuando llama al Worker API).
export const API_TIMEOUT_MS = 15_000;

// Versión del bundle para cache-busting (autoincremental en build).
export const BUNDLE_VERSION = import.meta.env.BUILD_ID ?? 'v2.0.0';
