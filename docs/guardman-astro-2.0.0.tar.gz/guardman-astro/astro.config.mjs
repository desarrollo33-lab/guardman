// GuardMan Astro 6 — Configuración del framework.
// SSR con adapter Cloudflare (Pages). Islas React solo donde se necesita.
import { defineConfig } from 'astro/config';
import cloudflare from '@astrojs/cloudflare';
import react from '@astrojs/react';
import tailwindcss from '@tailwindcss/vite';
import sitemap from '@astrojs/sitemap';

const SITE_URL = process.env.PUBLIC_SITE_URL ?? 'https://guardman.cl';

export default defineConfig({
  site: SITE_URL,
  output: 'server',
  adapter: cloudflare({
    mode: 'directory',
    imageService: 'compile',
    platformProxy: { enabled: true },
  }),
  integrations: [react(), sitemap()],
  vite: {
    plugins: [tailwindcss()],
    ssr: { external: ['node:fs', 'node:path'] },
  },
  image: { service: { entrypoint: 'astro/assets/services/sharp' } },
  devToolbar: { enabled: false },
  prefetch: { prefetchAll: true, defaultStrategy: 'viewport' },
});
