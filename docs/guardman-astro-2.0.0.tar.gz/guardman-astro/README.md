# GuardMan Chile — Astro 6 (v2.0.0)

Migración limpia de `guardman-admin v1.0.0` (Cloudflare Worker monolítico + Vite/React SPA) a **Astro 6** con islas React. Mantiene todo el contenido, el design system y la integración con el Worker API existente.

## Stack

- **Framework:** Astro 6 (SSR + Cloudflare adapter)
- **UI interactiva:** React 19 (islas con `client:only`)
- **Estilos:** Tailwind v4 (`@theme` con tokens GuardMan)
- **Backend:** Worker existente (no se toca D1, R2, KV, DO, Workflows)

## Estructura

```
guardman-astro/
├── AUDITORA_FORENSE.md         # Informe de auditoría (consolidado)
├── README.md                   # Este archivo
├── astro.config.mjs            # Astro + Cloudflare + React + Tailwind
├── tsconfig.json
├── package.json
├── wrangler.jsonc              # Deploy a Cloudflare Pages
├── env.d.ts
├── public/
│   ├── favicon.svg
│   ├── fonts/inter-*.ttf       # Copiar desde v1.0.0
│   └── scripts/admin-auth-guard.js
└── src/
    ├── styles/global.css       # Design system (Tailwind v4 @theme)
    ├── lib/
    │   ├── constants.ts        # SITE, servicios, ubicaciones, sectores — una sola fuente
    │   ├── api.ts              # Cliente HTTP unificado (reemplaza useApi/useMockApi/useRealApi)
    │   ├── auth.ts             # Token con expiración (8h)
    │   └── mocks.ts            # Mocks CRM para modo demo
    ├── types/index.ts          # Tipos del frontend
    ├── layouts/
    │   ├── BaseLayout.astro    # Sitio público (light/dark theme)
    │   └── AdminLayout.astro   # Shell admin (sidebar + topbar)
    ├── components/             # Astro puro
    │   ├── Header.astro
    │   ├── Footer.astro
    │   ├── Hero.astro
    │   ├── CTASection.astro
    │   ├── FeatureGrid.astro
    │   ├── FAQ.astro
    │   └── admin/
    │       ├── AdminSidebar.astro
    │       └── AdminTopbar.astro
    ├── islands/                # React (client:only)
    │   ├── cms/CMSEditor.tsx
    │   ├── crm/CRMView.tsx
    │   ├── media/MediaEditor.tsx
    │   ├── intel/IntelView.tsx
    │   ├── brand/BrandEditor.tsx
    │   └── chat/ChatView.tsx
    └── pages/
        ├── index.astro         # Homepage
        ├── nosotros.astro
        ├── guard-pod.astro
        ├── ajax-systems.astro
        ├── contacto.astro      # Con form que POST a /api/crm/leads/capture
        ├── cotizacion.astro
        ├── gracias.astro
        ├── privacidad.astro
        ├── terminos.astro
        ├── 404.astro
        ├── robots.txt.ts
        ├── api/health.ts
        ├── servicios/
        │   ├── index.astro
        │   └── [slug].astro
        ├── ubicaciones/
        │   ├── index.astro
        │   └── [slug].astro
        ├── sectores/
        │   ├── index.astro
        │   └── [slug].astro
        └── admin/
            ├── login.astro
            ├── index.astro     # CMS
            ├── crm.astro
            ├── media.astro
            ├── intel.astro
            ├── brand.astro
            ├── chat.astro
            └── settings.astro
```

## Qué cambió vs v1.0.0

| Aspecto | v1.0.0 | v2.0.0 |
|---|---|---|
| Framework | Vite + React SPA | Astro 6 + islas React |
| Backend SSR | Worker con string builders | Astro SSR (Cloudflare adapter) |
| CSS | 3 archivos con tokens duplicados | 1 `@theme` Tailwind v4 |
| Hook API | 3 (`useApi` + `useMockApi` + `useRealApi`) | 1 (`src/lib/api.ts`) |
| URLs hardcoded | 5+ ocurrencias (`guardman.oficinadesarrollo33.workers.dev`) | 1 en `lib/constants.ts` |
| Token auth | localStorage permanente | localStorage con expiración 8h |
| CORS | `*` global | No aplica (Astro en mismo dominio) |
| CRM | 16 archivos (~3,000 LOC) | 1 archivo (~350 LOC) |
| Media Editor | 14 archivos (~2,100 LOC) | 1 archivo (~150 LOC) |
| Código muerto | `PipelineBar` x2, `SEOScorePanel`, `api.ts` legacy, `GMContentAgent` huérfano | Eliminado |
| Bundle inicial | ~495KB (SPA completo) | < 100KB (solo islas cargan JS) |
| Build | Vite + `cp -r` cross-platform issue | `astro build` |
| Lighthouse homepage | 85+ | 95+ esperado |

## Setup

```bash
# 1. Instalar deps
npm install

# 2. Variables de entorno (para dev local)
cp .env.example .env
# Editar .env con:
#   PUBLIC_API_URL=https://guardman.oficinadesarrollo33.workers.dev
#   PUBLIC_SITE_URL=http://localhost:4321

# 3. Copiar fuentes desde v1.0.0
cp ../guardman-admin/public/fonts/inter-*.ttf public/fonts/

# 4. Dev
npm run dev

# 5. Build
npm run build

# 6. Deploy (Cloudflare Pages)
npx wrangler pages deploy dist --project-name=guardman-astro
```

## Auth flow

1. Usuario visita `/admin/*`
2. `admin-auth-guard.js` (inline script) chequea `localStorage.gm_token`
3. Si no hay token, redirige a `/admin/login?redirect=...`
4. Login form hace POST a `${API_URL}/api/login` (Worker existente)
5. Token guardado con `gm_token_expires_at` (8h)
6. Cada request a la API incluye `Authorization: Bearer <token>`
7. Si API responde 401, `api.ts` limpia el token y lanza error

## Modo demo CRM

- Activar desde `/admin/settings` → "Modo Demo CRM"
- Solo afecta a endpoints CRM (usa `src/lib/mocks.ts`)
- CMS, Media, Intel, Brand y Chat siguen usando el backend real

## Limitaciones conocidas

- Monaco Editor no se migró (era ~2MB sin lazy load). El CMS usa un editor de formularios plano más eficiente. Si se necesita Monaco, agregar como `React.lazy` en `CMSEditor.tsx`.
- Chat WebSocket asume endpoint `/api/agents/chat` en el Worker. Verificar que el DO `GMOrchestrator` acepte conexiones con `?token=`.
- Las páginas dinámicas (`servicios/[slug]`, `ubicaciones/[slug]`, `sectores/[slug]`) usan `getStaticPaths` con fallback estático. En producción, hidratar con `fetch` a `/api/cms/content` desde el servidor Astro para obtener datos reales de D1.
- Los tests de la v1.0.0 (`tests/`) no se migraron. La nueva arquitectura debería tener sus propios tests.

## Auditoría forense

Ver `AUDITORA_FORENSE.md` para el informe completo (357 líneas, 11 secciones). Cubre:

- Hallazgos críticos (dual AI provider, JSON.parse sin blindaje, merge destructivo, doble fuente homepage, AUTH_TOKEN reutilizado, CORS `*`)
- Código muerto y duplicación (PipelineBar x2, SEOScorePanel, hooks triplicados, GMContentAgent huérfano, CSS_V hardcoded, rutas CRM/Intel duplicadas)
- Inconexiones y bugs lógicos (10 hallazgos B-01 a B-10)
- Problemas de diseño/UX, seguridad, performance
- Métricas de deuda técnica
- Recomendaciones priorizadas P0-P3

## Licencia

Propietario — GuardMan Chile SpA.
