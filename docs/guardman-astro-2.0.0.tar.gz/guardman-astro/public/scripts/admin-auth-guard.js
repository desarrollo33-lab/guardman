// /public/scripts/admin-auth-guard.js
// Ejecutado inline antes de render. Redirige a login si no hay token.
// Solo aplica a páginas con `requireAuth: true` en AdminLayout.
(function () {
  try {
    var token = localStorage.getItem('gm_token');
    var demo = localStorage.getItem('gm_demo_mode') === 'crm';
    if (!token || token === 'undefined' || token === 'null') {
      if (!demo) {
        var redirect = encodeURIComponent(window.location.pathname);
        window.location.href = '/admin/login?redirect=' + redirect;
      }
    }
  } catch (e) {
    // localStorage disponible solo en browser
  }
})();
